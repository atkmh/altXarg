import java.io.*;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.util.Date;
import java.awt.*;

public class Employee extends Frame
//member variables
{	
	double dbMIN = .75;	
	int VacationNumbers;
	int	intNumberDaysTaken;
	Date doh;
	DataInputStream OpenForNumber;
	DataInputStream OpenFile;
	PrintStream FilePrint;
	Date Year;  
	String EmployeeName;
	String strName;	
	String VacationString1;
	String VacationString2;
	String VacationFile ="Not Null"; 
	String RVacationFile; 
	String Filename;
	String PrintFilename;
	long loAccuredTotal;
	long ThisYear;
	long DateOfHire;
	Date printPageDate;

	
	Employee (String m)
	{
		EmployeeName = m;
	}//constructor 1

	Employee (String N, int Y, int M, int D,  String F, String P)//int Da
	{
		strName = N;
		doh = new Date(Y,M,D);
		Year = new Date (98,00,01);
		Filename = F;
		PrintFilename = P;
	
	}//constructor 2
	
	//this is a constructor for setting up a simple GUI object
	//used for viewing and eventually selecting individual resources
	//for vacation availability
	


    // this method takes the current date and subtracts the start date
	// places into a monthly format and then multiples the monthly vacation accural rate
	// intYear intMonth intDay were initialized when constructor was called
	// by instantiation of this class.
	public long VacationAccuralCalc ()
	{		Date curdate = new Date();
			long dayMill = curdate.getTime();
			long mill = doh.getTime();
			long loAccuredTotal = dayMill - mill;
			loAccuredTotal /= 2505600000L;
			loAccuredTotal *= dbMIN;
			loAccuredTotal += 1;
			return (loAccuredTotal);
	}//end of VacationAccuralCalc method

    //this method takes the accural and subtracts the accural taken and 
	//returns available vacation
	
	public long VacationAvailableCalc ()
	{		Date curdate = new Date();
			// intYear intMonth intDay were initialized when constructor was called
			// by instantiation of this class.
			long dayMill = curdate.getTime();
			long mill = doh.getTime();
			long loAccuredTotal = dayMill - mill;
			loAccuredTotal /= 2505600000L;
			loAccuredTotal *= dbMIN;
			loAccuredTotal += 1;
			long loAvailableTotal = loAccuredTotal - intNumberDaysTaken;
			return (loAvailableTotal);
	}//end of VacationAvailableCalc method

	public long ThisYearCalc ()
	{		Date currentdate = new Date();
			long dayMill = currentdate.getTime();
			long DateOfHire = doh.getTime();
			long ThisYear = Year.getTime ();
		//	if (DateOfHire < ThisYear)
		//	{
			long loAccuredTotal = dayMill - ThisYear;
			loAccuredTotal /= 2505600000L;
			loAccuredTotal *= dbMIN;
			loAccuredTotal += 1;
		//	return (loAccuredTotal);
		//	}
			return (loAccuredTotal);
	}

	public String CurrentDate ()
	{		Date printDate = new Date();
		//	printDate.getDate();
		//	printDate.toString();
			return printDate.toString();
	}
	

	//  this method  reads employee vacation file and prints to TextArea UI Objectthe 
	// individual days
	// (TextArea UIvac) is a set variable to let this method know to use UIvac textobject
	// as the place to recieve the data
	public void ReadVacationFile(TextArea UIvac)
	{	
		try
		{
			OpenFile = new DataInputStream(new FileInputStream(Filename));
		}
		catch (FileNotFoundException fe)
		{
			System.out.println("Individual Human Resource File not Found");
		}
		do 
		{
			try
			{
				RVacationFile = OpenFile.readLine(); 
			}

			catch(IOException ioe)
			{
				System.out.println("Individual Human Resource File Problem");
			}
			
			if(RVacationFile != null)
			{		
			UIvac.appendText("   " + RVacationFile + getVacationString2() + "\n");
			}
		} while (RVacationFile != null);			
	}//end of ReadVacationFile method

	//this method  reads employee vacation file and stores the number of 
	//lines in the file into a member variable to be used as the integer for number
	//of vacation dats taken in method VacationAvailableCalc.
	//The  return(intNumberDaysTaken);	
	public int VacNumberTaken() 
	{
		try
		{
			OpenForNumber = new DataInputStream(new FileInputStream(Filename));
		}
		catch (FileNotFoundException fe)
		{
			System.out.println("Individual Human Resource File not Found");
		}
		
		for(intNumberDaysTaken=-1;VacationFile != null;intNumberDaysTaken++ )
		{
			try
			{
				VacationFile = OpenForNumber.readLine(); 
			}

			catch(IOException ioe)
			{
				System.out.println("Individual Human Resource File Problem");
			}
		}
		VacationFile="Not Null";
		return(intNumberDaysTaken);		
	}//end of VacNumberTaken method	
			


	public void PrintVacationFile(TextArea UIvac)
	{	
			try
			{
			OpenFile = new DataInputStream(new FileInputStream(Filename));
			}
			catch (FileNotFoundException fe)
			{
			System.out.println("Individual Human Resource File not Found");
			}


			try
			{
		//	FilePrint = new DataOutputStream(new FileOutputStream(PrintFilename));
			FilePrint = new PrintStream(new FileOutputStream(PrintFilename));
			}
			catch (FileNotFoundException Pe)
			{
			System.out.println("Print Human Resource File not Found");
			}
			catch(IOException Pio)
			{
			System.out.println("Print Human Resource problem");
			}

			try
			{
			FilePrint.println( CurrentDate () + "\n\r" + getName() +" was hired on " +  getHireDate() + "\n\r"  
				+ "Accurred " + VacationAccuralCalc() + " Vacation Days since hire date." + "\n\r"
				+ "Has Accurred " + ThisYearCalc()  + " Vacation Days this year." + "\n\r"
				+ "Has taken " + VacNumberTaken() + " Vacation Days since hire date." + "\n\r"
				+ "Has " + VacationAvailableCalc() + " Vacation Days Available." + "\n\r");
			}
			catch(IOException fio)
			{
			System.out.println("Individual Human Resource File not Found");
			}	

	
		do 
		{	
			try
			{
			RVacationFile = OpenFile.readLine(); 
			}
			catch(IOException ioe)
			{
			System.out.println("Individual Human Resource File Problem");
			}

			try
			{
				FilePrint.println(RVacationFile + getVacationString2() + "\n\r");
			}
			catch(IOException fio)
			{
			System.out.println("Individual Human Resource File not Found");
			}	
		} while (RVacationFile != null);
		
	}//end of PrintVacationFile method







	//gives string name from constructor	
	public String getName ()
	{
		return (strName);
	}

	//gives date of hire from constructor
	public Date getHireDate()
	{
		return (doh);
	}

	
	//Sets a string variable 1
	public String getVacationString1()
	{
		VacationString1 = ("Has taken ");
		return (VacationString1);	
	}

	//Sets a string variable 2
	public String getVacationString2()
	{
		VacationString2 = ("  as a vacation day.");
		return (VacationString2);	
	}



}//end of class Employee