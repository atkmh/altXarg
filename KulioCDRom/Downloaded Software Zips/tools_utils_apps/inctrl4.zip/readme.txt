________________________________________________________________ 

InCtrl4, Version 1.1
Copyright (c) 1999 Ziff-Davis, Inc.
Written by Neil J. Rubenking and Rick Knoblaugh
First Published in PC Magazine, US Edition, January 19, 1999
http://www.zdnet.com/pcmag/pctech/content/18/02/ut1802.001.html
________________________________________________________________ 

PLATFORMS:
Windows 95, Windows 98, Windows NT 4

DESCRIPTION:
When you install a new program, the installation utility adds some files to your 
system, replaces other files, and changes elements of the Registry and essential 
INI files. You hope it will make those changes cleanly and correctly, and record 
them for use by the program's uninstall utility. But in case it doesn't, InCtrl4 
can provide a record of exactly what the install program did. The fourth major 
release of this popular utility, InCtrl4 adds a high speed, real-time reporting 
mode for Windows 95 and Windows 98. 

REVISION HISTORY:
Enhancements in Version 1.1:
- Under version 4.0, the "Real-time reporting" tracking mode was available only 
for 32-bit install programs. Now it can be used for any install program, even a 
.COM or .BAT file.
- The comma-separated values reports now use the list-separator character 
defined by the system's regional settings, rather than always using a comma.
- Rather than halting when it encounters a corrupted Registry value, InCtrl4 now 
ignores it and continues.
- The program now remembers the tracking mode you used during its previous run, 
and restores that mode as the initial default.
- The "Install complete" button is enabled as soon as the install program has 
launched.
- The report for a deleted Registry key now includes the value the key had 
before deletion, except when using real-time reporting. (The real-time reporting 
VxD does not have access to the value of a deleted key). 

Bug Fixes in Version 1.1:
- Some install programs locked up or ran sluggishly, notably those created with 
Visual Basic's setup kit and certain InstallShield-based programs. This was due 
to an interaction with InCtrl4's attempt to track the launching of secondary 
install programs. Since certain install programs manage to subvert the secondary 
install program tracking already, that feature has simply been removed.
- If a new INI file section was alphabetically the very last section, InCtrl4 
would enter an endless loop when comparing INI files. Eventually the system 
would report "Out of memory". 
- In the comma-separated values report, the section names and key names for INI 
keys were placed incorrectly.
- InCtrl4 did not correctly remember the list of Registry keys to ignore.
- During certain DOS-based installs, an internal flag was mis-set, resulting in 
the message "I/O error 103".
- If a Registry value had a non-standard data type and a length of zero, InCtrl4 
would halt during Registry comparison with the message "Stored Registry data 
corrupted".

INSTALLATION:
InCtrl4's self-contained installation utility, Install.exe, will install the 
program in the directory of your choice and put it on your Start menu. To 
uninstall InCtrl4, use the Add/Remove programs applet from Control Panel.
For details on program operation, refer to the program's online help file.

SUPPORT:
Help for PC Magazine's free utilities can be obtained in our online discussion 
area on the World Wide Web (www.pcmag.com/discuss.htm). You may find an answer 
to your question simply by reading the posted messages. The authors of current 
utilities generally visit this forum daily. If the author is not available and 
the forum sysops can't answer your question, the Utilities column editor, who 
also checks the forum each day, will contact the author for you.

LICENSE INFORMATION:
PC Magazine programs are copyrighted and cannot be distributed, whether modified 
or unmodified. Use is subject to the terms and conditions of the license 
agreement distributed with the programs.

----

Neil J. Rubenking, the main author of InCtrl4, is a Contributing Technical 
Editor of PC Magazine. Rick Knoblaugh, who wrote the VxD used for real-time 
reporting, is a systems programmer and frequent contributor to PC Magazine. 
Sheryl Canter is the editor of the Utilities column and a Contributing Editor of 
PC Magazine.

