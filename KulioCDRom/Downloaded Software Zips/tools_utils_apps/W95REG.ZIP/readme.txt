Thank you very much for downloading the Windows 95 Registry FAQ. We sincerely hope you enjoy it, and that it gives you the same hours upon hours of frantic Windows tweaking it has given us.

__________________________________________________________

THE NEXT VERSION...

Imaginations UNlimited will be releasing a brand new ebook on customizing and tweaking Windows 95. This new version will be have three times the information and tips as the current RegFAQ. We are also working with a number of shareware and freeware programmers to include some rather innovative programs and tools with the next version.

The next version is slated for release very early next year. We have been delaying its release in hopes of including tips and information on Nashville, the next major upgrade to Windows95 and Microsoft Internet Explorer. We were supposed to receive pre-release versions of Nashville and the ActiveThemes SDK in July, but Microsoft has not yet released them as of this writing.

Regardless of whether we can include info on Nashville, we will be releasing a new FAQ/ebook. Not only will it contain tips and tricks for tweaking the Registry, but will present thousands of productivity and shortcut tips about Windows 95, Microsoft Office applications, and much, much more. It's going to be huge.

Because the next version will be so massive, however, and because our researchers and programmers put in so much time to write it, we will be releasing the next version as shareware. When we began this project, the idea was to keep it freeware, but it has grown so large and involves such a commitment of time and talent to keep it updated and layout new versions, that we are forced to find a way to offset some of the time.

The version you just downloaded is freeware. The next version will be shareware.

We'd like to get your opinion about the shareware version. As a user of the FAQ, would you pay a small charge of $15 for an FAQ three times the size of the current one? We've heard from people all over the world--from the U.S. to Israel, Australia to Japan--about how useful the FAQ is to them. If that useability were tripled, with a coupon for a free upgrade to the  next version beyond that, would it be worth $15 to you?

We're sincerely interested in your opinion, so, after you've used the RegFAQ a little, please take a moment to drop us an e-mail with your thoughts on the above question. Please send them to Registry95@aol.com.

If enough people feel that the next version is worth a few bucks, we'll go ahead and finish it and release it. If not, then we'll shelve it.

Thank you again for your interest in the FAQ. We hope it gives you the control and useability of Win95 that you're after.

Sincerely,

--The Imaginations UNlimited Reg95 Team