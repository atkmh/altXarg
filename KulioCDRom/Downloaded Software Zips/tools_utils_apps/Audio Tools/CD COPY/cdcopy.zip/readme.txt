                  CDCOPY.EXE V4.708 (C) by Markus Barth
                  =====================================

    This module allows you to write audio-tracks from CD
    to disk. Registered users are able to write these files
    to a CD-Writer.

    Running under Windows-95/98 the program only works
    with SCSI or ATAPI-CDROM/CD-R, which support this
    special mode.

    Using WINDOWS-NT it is possible to use the generic WIN32
    interface to read the CDDA-tracks. By default, the module
    starts detecting an ASPI-interface. If it is not available
    the generic interface is used.

    The following hardware was tested:          Speed
    Adaptec 2940, Plextor CD-ROM 8XCS,             8X
                  RICOH 14020C,                    2X
                  TOSHIBA 3401                     1X
                  TOSHIBA 6002B                    1X
                  TOSHIBA 6201                    12X
                  PIONEER DR-U24X                  4X
                  UltraPlex                       25X
                  UltraPlex 40 max                30X
                  Sony CDU711                     10X
                  Philips CDRW3610                 7X
                  CyberDrive                       8X
                  Yamaha CDRW 4260                 7X
                  TEAC CDR55S                     13X
                  Philips PCS403CD                11X
                  Liteon LTN382                   10X

    These are not all supported drives, but those I test with!     

    It's fully functional under Windows-95/98 and Windows-NT 3.51/4.x.

    For both operating systems I used EZ-SCSI 4.00, 4.01
    as ASPI-interfaces.

    The following versions were tested:

    WNASPI32.DLL    22528  -> EZ-SCSI 4.01
    WNASPI32.DLL    21504  -> EZ-SCSI 4.00
    WNASPI32.DLL    48128  -> EZ-SCSI 4.57

    Attention - please copy the CDCOPY.INI file to the Windows / Winnt
    directory!
    Information about the configuration and usage of the module is
    located in the attached helpfile (CDCOPY.HLP) Troubleshooting.

    The multilanguage supprt covers at the moment only menues and tooltips,
    helpfiles etc. are following
    Supported languages:
    English
    German
    Norwegian
    Spanish
    Swedish
    Italian
    Netherlands
    Slovenian
    Slovakian
    Bulgarian
    Portuguese
    Hungarian
    French

    A german and hungarian helpfile and an engl. documentation in
    Word 7 format you can download from my homepages!


    If you have any suggestions or errors reports please feel free
    to send me an e-mail. The actual version of CDCOPY is always
    available at:
    http://www.cdcopy.sk
    http://cdcopy.actadivina.com
    http://members.aol.com/mbarth2193
    http://come.to/cdcopy
    Please send feedback about supported drives!

    If you report any problems, please send the following
    information:

    Version of CDCOPY you use
    Vendor of your CDROM/CDR
    Operating system
    Which interface you use ASPI or WIN32 for Windows-NT


    Credits:
    Special thanks to A. Katranis (A.Katranis@gmx.net) for
    excessive testing and permanent incentive.


                               Attention!

    Starting with version 3.701 I have to change the Freeware
    status to Shareware. Excessive bills for my internet
    activities doesn't allow me to improve CDCOPY for free.
    Answering many e-mails, updates etc. are too expensive.

    So if you want to make the CDCOPY-project go further
    send 20 US $ to:

    Markus Barth
    Holzmarkt 2
    52511 Geilenkirchen
    (Germany)

    Profit-making organizations may use this software only with
    explicit written permission with payment to the author.

    M. Barth - mbarth2193@aol.com
               mbarth@home.ivm.de

    Versions:
    4.710 - Compression path, decompression, conversion with subdirectories,
            addtional VQF modes
    4.708 - VQF deompression, Retrieve lyrics from MP3 ID Tag
    4.707 - lyrics server field (new server is named search.lyrics.ch), 
            support for small bitrates
    4.705 - AAC encoding through Quartex compressor
    4.704 - Windows port of Cdrdao, later name binding
    4.702 - copy compressed files
    4.701 - MPx Bitrate conversion
    4.700 - Support for BladeEnc.DLL, improved "design"
    4.600 - Separate VQF compressor path, perfectionist mode (rereading
            of sectors), channel swapping, enhanced infrared remote
            controll support for smp3p, shortcut tracklist (smp3p)
    4.532 - Separate channel normalizing, infrared controll support
            for MP3-Player
    4.530 - Realaudio G2 support, format conversions MPx -> Realaudio,
            MPx -> Yamaha VQF
    4.521 - Error MPA files and ID3V2, playlists, LRC file format
    4.519 - Error batchname, Replace slashes by dashes
    4.518 - Playlists without path, command line mode
    4.517 - hungarian, french translation, error corrections 
            writer modul (TEAC), normalization before writing,
            small MP3 player
    4.515 - Support for Plugger, error corrections
    4.514 - CDDB category - ID3 Tag matching
    4.513 - error corrections sleeve editor, writing speed,
            scanning
    4.512 - error corrections, minor enhancements
    4.511 - error corrections, minor enhancements, crc32 check,
            Joint stereo support for decompressor, separate file
            normalization
    4.508 - saving of sampled CD information and writer options,
            error corrections, cycling batchmode
    4.507 - minor optimizations of the MP3 compressor, support of the generic SCSI
            interface (Windows-NT) 
    4.506 - minor error corrections, portuguese and bulgarian, x3enc support
    4.505 - Neumann factor
    4.503 - Integrated MP3 decompressor, additional VQF formats
    4.501 - some error corrections
    4.500 - Built in MP3 compressor
    4.201 - Separate file compression, BladeEnc MP3 compressor support,
            Changed Listbox type
    4.200 - VQF and Realaudio format, temporary decompression path for writing,
            generate CDDB file for new CD, load/save options
    4.100 - Error writing ATAPI CD-Writer, priority setting for compressors,
            Correct end sector, additional command line options, different
            Mono file types
    4.009 - Decode MP3-WAV to normal WAV format, CD-R writing from MP3-WAV format
            automatically writing of CDPLAYER.INI after CDDB query
    4.008 - Priority for L3CODEC, error options dialog with old COMCTL32.DLL
    4.007 - error corrections in sleeve editor, ID3V2 - standard corrections
            drive spin up
    4.006 - error corrections in sleeve editor, eject CD in autorip mode,
            minimize TOMPG window, MP3ENC support, MP3-Producer batch file
    4.005 - MP3 ID Tag V2, context help and menue
    4.002 - MP3 ID Tag V1.1, autorip without CDDB access
    4.001 - Saving of MP3 ID Tag Comment, redesign options
            disable CD-title on frontpage
    4.000 - Integrated sleeve editor, support for the most common graphics formats
            TWAIN scanner interface, support for proxy authorization
    3.905 - MP3 decompression, CD-writing from MP3-format
            Support for Enhanced CDs, improved cache management
            for Windows-NT
    3.900 - Multilanguage support, replace space by underscore
            error jitter correction with ATAPI drives
    3.808 - Save default MP3 Tag information, CDDB -> CDPLAYER.INI
    3.807 - TOMPG support, error Toshiba speed setting
    3.806 - conversion from the CDDB format to CSV
            error l3codec compression
    3.805 - sound normalization, delete CDDB batch files
            direct L3Codec support, speed up Xing encoding
    3.804 - minor corrections
    3.803 - Writing lyrics to MP3-WAV, MPA, MP3-file, Alert function
            improved Xing encoding speed
    3.802 - Batchmdoe for CDDB queries, invert selection
            support for lyricsserver www.lyrics.ch
    3.800 - Batchmdoe for several drives, pregab setting
    3.711 - minor error corrections
    3.710 - Playlistgeneration, MITSUMI CD-R, alternate Matsushita mode,
            error proxyserver, time information, filename template
    3.709 - minor error corrections, and enhancements
    3.706 - Extended ATAPI-support - many new drives, tracktime
            Support for Xing MPEG Encoder, Proxyserver support,
    3.703 - Albumname, http-port modification
    3.702 - Error Toshiba-Powermode
            Some error-corrections
    3.701 - http-protocoll for cddb access, quickmode option
            powermode, speed information, advanced options
    3.608 - Supress 0 samples, SCSI-Info, error NEC drives,
            minor enhancements, speedselection, support
            for IBM, Cyber drives
    3.606 - error corrections
    3.605 - RICOH MP drives, MP3-ID TAG, DAO-CUE-Sheet
            generation
    3.603 - Corrected some bugs
    3.602 - Jitter correction using WIN32 interface,
            statusinformation during CDDB communication
    3.600 - Writing of MP3-WAV files through L3CODEC of
            Fraunhofer Inst., Path for CDDB-files,
            Options "Save tracknumber", "Save artist"
    3.505 - Submission of new CD-information to CDDB
    3.502 - Buffered reading for some drive-types
            fixed some minor bugs
            MP3CompPath - variable in CDCOPY.INI
    3.500 - Read artist, title etc. from internet-database
            CDDB, support for ATAPI-interface for Windows-95,
            support for MATSHITA/PANASONIC drives.
    3.001 - Call MP3-Compressor to generate MP3 - format
    3.000 - Save options
            Jitter correction for some drives
    2.005 - Select/Deselect whole CD, retry failed reads
            speed up reading ASPI-interface for some drive-types
    2.003 - Corrected some bugs
    2.002 - Select down to frame using track excerption
    2.001 - Support for TEAC (SCSI) drives
    2.000 - Support of MPG format (MPEG 1 layer 2)
            Extreme small files and extreme slow when packing
    1.700 - Added space information for tracks
    1.604 - Corrected error reading non-buffered mode using generic
            interface
    1.603 - Added support for HITACHI drives
    1.602 - Corrected some bugs
    1.600 - Support for RICOH drives (ASPI)
    1.500 - Choice of CDROMs/CDRs using a combobox and
            buffered reading using generic interface
    1.400 - Save tracks using title of CDPLAYER.INI or chosen name
    1.300 - Added tooltips, nicer buttons
            Dialog to save a part of a track
    1.200 - Saving soundfiles as WAV, AU or RAW
            Classic-mode (Writing subsequent tracks of live or
            classic-CD in one file without pause)
    1.100 - IDE-Support using generic WIN32 interface
    1.005 - Support for HP-Writer
    1.004 - Overread defect sectors
            Show content of CDPLAYER.INI if available
