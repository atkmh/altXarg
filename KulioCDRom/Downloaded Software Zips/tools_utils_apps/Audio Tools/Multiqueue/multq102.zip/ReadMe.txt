          ***************
          * Multiquence *
          *    v1.02    *
  *********************************
  *      1       *       4        *
  *              *                *
  *********************************
      *          2           *
      *                      *
      ************************ TM

--------------------------------------------------------------
Table of Contents
--------------------------------------------------------------

1.0 Multiquence Features
2.0 Requirements, Installation, Uninstall
3.0 Important Additional Notes
4.0 Shareware, Copyright & Distribution, Warranty
5.0 Contacting the Author


--------------------------------------------------------------
1.0 Multiquence Features
--------------------------------------------------------------

Multiquence is a multitrack digital audio processor with
unique multimedia extensions.

Features:
  * Fast virtual editing with an unlimited number of tracks
  * 100% "real time" processing
  * Master volume, track volume, Mute and Solo controls
  * Editing commands: Undo, Copy, Mute, Trim, Split, Delete
  * Editing/playback Marker
  * Drag-and-drop editing
  * Multiple levels of Undo
  * Instant effects: Dynamic volume, Flange, Equalizer, Pan
  * Sequence digital audio, CD audio, MIDI, video
  * Supports multiple recording sections
  * Full zooming for accurate positioning
  * Context menus
  * Configurable playback rate
  * Combine all digital audio tracks to a single wave file
  * Complete help on all commands
  * Shareware, with no features disabled!


--------------------------------------------------------------
2.0 Requirements, Installation, Uninstall
--------------------------------------------------------------

2.1) Requirements

Multiquence requires a Pentium (or better) processor.  It
will not work on 486 systems.  For recording, you must
have a stereo 16-bit full duplex sound card or more than
one sound card.  Windows 95 or Windows NT 4.0 is required.

2.2) Installation

Simply create a "Multiquence" folder and unzip or copy
all files into that folder.  Create a shortcut to 
"multique.exe".  See Windows help for information about
creating a shortcut.

2.3) Uninstall

Delete the "Multiquence" folder and delete the following
files from your Windows (or WinNT) folder:
    Multique.ini
    MQPreset.ini

--------------------------------------------------------------
3.0 Important Additional Notes
--------------------------------------------------------------

3.1) Windows 95 or Windows NT 4.0 or later is required to
run this application.

3.2) If Multiquence terminates during playback, you should
restart your system to prevent further problems with your
audio driver.  Contact your sound card manufacturer to see
if an updated driver is available.

3.3) Updates for Multiquence can be downloaded from the
Multiquence Web page:
	http://www.goldwave.com/multiquence/


--------------------------------------------------------------
4.0 Shareware, Copyright & Distribution, Warranty
--------------------------------------------------------------

4.1 Shareware
-------------
Multiquence is a shareware program.  To register and encourage
further development, please follow the directions in the
Order.doc file included with this program or see Multiquence
Help for additional information.

4.2 Copyright & Distribution
----------------------------
Multiquence v1.02 ("the package") includes the following
software and documentation:
	Multique.exe    Multiquence application
	Multique.hlp    Multiquence help
	MQPreset.ini    Effects presets
	Order.doc       Order form (Word format)
	ReadMe.txt      Important information
	WhatsNew.txt    A list of new features
	BWCC32.DLL      Borland's control library

The package is copyright (C) 1997 by Chris S. Craig.
Multiquence is a trademark of Chris S. Craig.

You may copy and distribute the package through Web and ftp
sites.  Only the unmodified "zipped" file may be distributed
or copied.
You are prohibited from:
   charging a fee or requesting donations for the package;
   defeating shareware limits or using unauthorized passwords;
   distributing/including the package in commercial products;
   modifying or reverse engineering the package.

The package may be distributed on a CD-ROM in the case where
ftp sites issue CD-ROMs of their collections.  This includes
SimTel, Garbo, Sound Site, CICA, and other similar large
collections.  The package may be distributed on a CD-ROM
included with a book or magazine, provided that the shareware
conceptis clearly explained.  A complimentary copy of the book
or magazine would be welcome.

All trademarks/registered names acknowledged.

4.3 Warranty
------------
The package is provided as is, without warranty of any kind.
The author shall not be liable for damages of any kind.  Use
of this software indicates you agree to this.


--------------------------------------------------------------
5.0 Contacting the Author
--------------------------------------------------------------

E-mail: chris3@cs.mun.ca
Please refer to Multiquence Help for further information.
