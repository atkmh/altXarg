
*******************************************************
     CoffeeCup HTML Editor++ 4.0
*******************************************************


Some features of this Software:

* 100 animated Gifs to choose from for your pages. 
* 20 Javascripts at the touch of a button.
* 10 VBscripts w/ActiveX at the touch of a button for I.E. users.
* Internal Browser for Surfing or Testing your pages.
* 30 Cool Backgrounds to add to your pages.
* Image Preview of selected .gifs or .jpgs now included.
* Drag and Drop from your hard drive and/or document to document.
* Hot Stuff Tricks (HTML Already done). 
* Work on and test multiple pages at once. 
* 5 Stand Alone Application Buttons.
* A Great Online Imagemap for Interface Help.
* A Table Wizard for the perfect look.
* A Color Wizard means no more hunting for code.
* Grab anything and move it around one document or to others.
* Customize your editor with pictures and backgrounds.
* E-mail Help & Low cost upgrades for Registered users.
* Especially designed for Windows 95, Netscape, & I.E.
* Great for the Web and Intranets.

We are proud to offer this Shareware at $30. U.S.
and downloading and payment methods can be found via
our Website at:

http://www.coffeecup.com

*******************************************************

