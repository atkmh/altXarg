/* this ALWAYS GENERATED file contains the RPC client stubs */


/* File created by MIDL compiler version 3.00.15 */
/* at Thu Apr 17 17:09:09 1997
 */
/* Compiler settings for prrpc.idl:
    Os, W4, Zp1, env=Win16, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )

#include <string.h>
#if defined( _ALPHA_ )
#include <stdarg.h>
#endif

#include <malloc.h>
#include "prrpc16.h"

#define TYPE_FORMAT_STRING_SIZE   349                               
#define PROC_FORMAT_STRING_SIZE   437                               

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDLTypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDLProcFormatString;

/* Standard interface: ABTServer, ver. 2.0,
   GUID={0x4d4b2df0,0x5590,0x11ce,{0xb7,0x3b,0x00,0x00,0xc0,0x3e,0xef,0x83}} */



extern RPC_DISPATCH_TABLE ABTServer_v2_0_DispatchTable;

static const RPC_CLIENT_INTERFACE ABTServer___RpcClientInterface =
    {
    sizeof(RPC_CLIENT_INTERFACE),
    {{0x4d4b2df0,0x5590,0x11ce,{0xb7,0x3b,0x00,0x00,0xc0,0x3e,0xef,0x83}},{2,0}},
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    &ABTServer_v2_0_DispatchTable,
    0,
    0,
    0,
    0,
    0
    };
RPC_IF_HANDLE ABTServer_v2_0_c_ifspec = (RPC_IF_HANDLE)& ABTServer___RpcClientInterface;

extern const MIDL_STUB_DESC ABTServer_StubDesc;

static RPC_BINDING_HANDLE ABTServer__MIDL_AutoBindHandle;

void __RPC_STUB
ABTServer_rpcDebug(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    MIDL_STUB_MESSAGE _StubMsg;
    const char __RPC_FAR *__MIDL_0000;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    __MIDL_0000 = 0;
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[0] );
        
        NdrConformantStringUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0000,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2],
                                       (unsigned char)0 );
        
        
        rpcDebug(IDL_handle,__MIDL_0000);
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
ABTServer_rpcRaise(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    short _RetVal;
    MIDL_STUB_MESSAGE _StubMsg;
    exception_t __MIDL_0001;
    void __RPC_FAR *_p___MIDL_0001;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    _p___MIDL_0001 = &__MIDL_0001;
    MIDL_memset(
               _p___MIDL_0001,
               0,
               sizeof( exception_t  ));
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[8] );
        
        NdrComplexStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR * __RPC_FAR *)&_p___MIDL_0001,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[4],
                                    (unsigned char)0 );
        
        
        _RetVal = rpcRaise(IDL_handle,__MIDL_0001);
        
        _StubMsg.BufferLength = 2U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        *(( short __RPC_FAR * )_StubMsg.Buffer)++ = _RetVal;
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
ABTServer_rpcProgressCreate(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    hProgress _RetVal;
    MIDL_STUB_MESSAGE _StubMsg;
    const char __RPC_FAR *__MIDL_0002;
    unsigned short __MIDL_0003;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    __MIDL_0002 = 0;
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[16] );
        
        NdrConformantStringUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0002,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2],
                                       (unsigned char)0 );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        __MIDL_0003 = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        
        _RetVal = rpcProgressCreate(
                            IDL_handle,
                            __MIDL_0002,
                            __MIDL_0003);
        
        _StubMsg.BufferLength = 4U;
        _StubMsg.BufferLength += 16;
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        *(( hProgress __RPC_FAR * )_StubMsg.Buffer)++ = _RetVal;
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
ABTServer_rpcProgressRelease(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    MIDL_STUB_MESSAGE _StubMsg;
    hProgress __RPC_FAR *__MIDL_0004;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    __MIDL_0004 = 0;
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[26] );
        
        __MIDL_0004 = ( hProgress __RPC_FAR * )_StubMsg.Buffer;
        _StubMsg.Buffer += sizeof( hProgress  );
        
        
        rpcProgressRelease(IDL_handle,__MIDL_0004);
        
        _StubMsg.BufferLength = 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        *(( hProgress __RPC_FAR * )_StubMsg.Buffer)++ = *__MIDL_0004;
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
ABTServer_rpcProgressTitle(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    MIDL_STUB_MESSAGE _StubMsg;
    hProgress __MIDL_0005;
    const char __RPC_FAR *__MIDL_0006;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    __MIDL_0006 = 0;
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[34] );
        
        __MIDL_0005 = *(( hProgress __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrConformantStringUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0006,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2],
                                       (unsigned char)0 );
        
        
        rpcProgressTitle(
                    IDL_handle,
                    __MIDL_0005,
                    __MIDL_0006);
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
ABTServer_rpcProgressReset(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    short _RetVal;
    MIDL_STUB_MESSAGE _StubMsg;
    hProgress __MIDL_0007;
    const char __RPC_FAR *__MIDL_0008;
    unsigned short __MIDL_0009;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    __MIDL_0008 = 0;
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[44] );
        
        __MIDL_0007 = *(( hProgress __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrConformantStringUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0008,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2],
                                       (unsigned char)0 );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        __MIDL_0009 = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        
        _RetVal = rpcProgressReset(
                           IDL_handle,
                           __MIDL_0007,
                           __MIDL_0008,
                           __MIDL_0009);
        
        _StubMsg.BufferLength = 2U;
        _StubMsg.BufferLength += 16;
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        *(( short __RPC_FAR * )_StubMsg.Buffer)++ = _RetVal;
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
ABTServer_rpcProgressCount(
    PRPC_MESSAGE _pRpcMessage )
{
    handle_t IDL_handle;
    short _RetVal;
    MIDL_STUB_MESSAGE _StubMsg;
    hProgress __MIDL_0010;
    const char __RPC_FAR *__MIDL_0011;
    unsigned short __MIDL_0012;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &ABTServer_StubDesc);
    
    NdrRpcSsEnableAllocate(&_StubMsg);
    IDL_handle = _pRpcMessage->Handle;
    __MIDL_0011 = 0;
    RpcTryFinally
        {
        if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[44] );
        
        __MIDL_0010 = *(( hProgress __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrConformantStringUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0011,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2],
                                       (unsigned char)0 );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        __MIDL_0012 = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        
        _RetVal = rpcProgressCount(
                           IDL_handle,
                           __MIDL_0010,
                           __MIDL_0011,
                           __MIDL_0012);
        
        _StubMsg.BufferLength = 2U;
        _StubMsg.BufferLength += 16;
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        *(( short __RPC_FAR * )_StubMsg.Buffer)++ = _RetVal;
        
        }
    RpcFinally
        {
        NdrRpcSsDisableAllocate(&_StubMsg);
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}


unsigned long rpcVersion( 
    /* [in] */ handle_t IDL_handle)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned long _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          0);
        
        
        _Handle = IDL_handle;
        
        
        _StubMsg.BufferLength = 0U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[56] );
        
        _RetVal = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hDriver rpcDriver( 
    /* [in] */ handle_t IDL_handle)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hDriver _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          1);
        
        
        _Handle = IDL_handle;
        
        
        _StubMsg.BufferLength = 0U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[60] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcDriverRelease( 
    /* [out][in] */ hDriver __RPC_FAR *__MIDL_0013)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          2);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )*__MIDL_0013);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )*__MIDL_0013,
                            0);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[66] );
        
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )__MIDL_0013,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


hSession rpcDriverLogin( 
    /* [in] */ hDriver __MIDL_0014,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0015,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0016,
    /* [out] */ error_t __RPC_FAR *__MIDL_0017)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hSession _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          3);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0014);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 13U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0015,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0016,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0014,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0015,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0016,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[72] );
        
        *__MIDL_0017 = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hSession rpcDriverShare( 
    /* [in] */ hDriver __MIDL_0018,
    /* [in] */ unsigned long __MIDL_0019)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hSession _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          4);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0018);;
        
        
        _StubMsg.BufferLength = 20U + 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0018,
                            1);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0019;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[92] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcSessionInfo( 
    /* [in] */ hSession __MIDL_0020,
    /* [out] */ session_t __RPC_FAR *__MIDL_0021)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          5);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0020);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0020,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[102] );
        
        NdrSimpleStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                   (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0021,
                                   (PFORMAT_STRING) &__MIDLTypeFormatString.Format[62],
                                   (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void rpcSessionRelease( 
    /* [out][in] */ hSession __RPC_FAR *__MIDL_0022)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          6);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )*__MIDL_0022);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )*__MIDL_0022,
                            0);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[112] );
        
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )__MIDL_0022,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


double rpcSessionTime( 
    /* [in] */ hSession __MIDL_0023)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    double _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          7);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0023);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0023,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[118] );
        
        _RetVal = *(( double __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hRepository rpcSessionConnect( 
    /* [in] */ hSession __MIDL_0024,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0025)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hRepository _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          8);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0024);;
        
        
        _StubMsg.BufferLength = 20U + 12U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0025,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0024,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0025,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[124] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hRepository rpcSessionSystem( 
    /* [in] */ hSession __MIDL_0026)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hRepository _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          9);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0026);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0026,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[136] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hCursor rpcSessionDefaults( 
    /* [in] */ hSession __MIDL_0027)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hCursor _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          10);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0027);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0027,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[144] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hCursor rpcSessionRights( 
    /* [in] */ hSession __MIDL_0028)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hCursor _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          11);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0028);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0028,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[144] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hCursor rpcSessionEvents( 
    /* [in] */ hSession __MIDL_0029)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hCursor _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          12);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0029);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0029,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[144] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


short rpcUserConnected( 
    /* [in] */ hSession __MIDL_0030,
    /* [in] */ unsigned long __MIDL_0031)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    short _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          13);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0030);;
        
        
        _StubMsg.BufferLength = 20U + 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0030,
                            1);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0031;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[152] );
        
        _RetVal = *(( short __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


error_t rpcUserDisconnect( 
    /* [in] */ hSession __MIDL_0032,
    /* [in] */ unsigned long __MIDL_0033)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          14);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0032);;
        
        
        _StubMsg.BufferLength = 20U + 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0032,
                            1);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0033;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[152] );
        
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcRepositoryInfo( 
    /* [in] */ hRepository __MIDL_0034,
    /* [out] */ repository_t __RPC_FAR *__MIDL_0035)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          15);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0034);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0034,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[160] );
        
        NdrSimpleStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                   (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0035,
                                   (PFORMAT_STRING) &__MIDLTypeFormatString.Format[122],
                                   (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void rpcRepositoryRelease( 
    /* [out][in] */ hRepository __RPC_FAR *__MIDL_0036)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          16);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )*__MIDL_0036);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )*__MIDL_0036,
                            0);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[170] );
        
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )__MIDL_0036,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


unsigned long rpcRepositoryCounter( 
    /* [in] */ hRepository __MIDL_0037,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0038,
    /* [in] */ unsigned short __MIDL_0039)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned long _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          17);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0037);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 5U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0038,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0037,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0038,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0039;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[176] );
        
        _RetVal = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


unsigned short rpcRepositoryExecute( 
    /* [in] */ hRepository __MIDL_0040,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0041)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned short _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          18);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0040);;
        
        
        _StubMsg.BufferLength = 20U + 12U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0041,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0040,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0041,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[188] );
        
        _RetVal = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hCursor rpcRepositorySelect( 
    /* [in] */ hRepository __MIDL_0042,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0043,
    /* [in] */ short __MIDL_0044)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hCursor _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          19);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0042);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 5U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0043,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0042,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0043,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        *(( short __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0044;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[198] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


error_t rpcRepositoryPassword( 
    /* [in] */ hRepository __MIDL_0045,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0046,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0047,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0048)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          20);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0045);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 13U + 13U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0046,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0047,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0048,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0045,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0046,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0047,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0048,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[212] );
        
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


unsigned long rpcRepositoryLockedBy( 
    /* [in] */ hRepository __MIDL_0049,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0050,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0051,
    /* [in] */ unsigned long __MIDL_0052)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned long _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          21);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0049);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 13U + 11U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0050,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0051,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0049,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0050,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0051,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 3) & ~ 0x3);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0052;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[230] );
        
        _RetVal = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


unsigned long rpcRepositoryLock( 
    /* [in] */ hRepository __MIDL_0053,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0054,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0055,
    /* [in] */ unsigned long __MIDL_0056)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned long _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          22);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0053);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 13U + 11U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0054,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0055,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0053,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0054,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0055,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 3) & ~ 0x3);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0056;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[230] );
        
        _RetVal = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


unsigned long rpcRepositoryUnlock( 
    /* [in] */ hRepository __MIDL_0057,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0058,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0059,
    /* [in] */ unsigned long __MIDL_0060)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned long _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          23);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0057);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 13U + 11U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0058,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0059,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0057,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0058,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0059,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 3) & ~ 0x3);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0060;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[230] );
        
        _RetVal = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hBuffer rpcCursorInfo( 
    /* [in] */ hCursor __MIDL_0061,
    /* [out] */ cursor_t __RPC_FAR *__MIDL_0062)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hBuffer _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          24);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0061);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0061,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[246] );
        
        NdrSimpleStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                   (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0062,
                                   (PFORMAT_STRING) &__MIDLTypeFormatString.Format[162],
                                   (unsigned char)0 );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcCursorRelease( 
    /* [out][in] */ hCursor __RPC_FAR *__MIDL_0063)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          25);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )*__MIDL_0063);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )*__MIDL_0063,
                            0);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[258] );
        
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )__MIDL_0063,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


hBuffer rpcCursorOpen( 
    /* [in] */ hCursor __MIDL_0064,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0065,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0066)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hBuffer _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          26);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0064);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 13U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0065,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0066,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0064,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0065,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0066,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[264] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


error_t rpcCursorClose( 
    /* [in] */ hCursor __MIDL_0067)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          27);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0067);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0067,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[280] );
        
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


error_t rpcCursorUpdate( 
    /* [in] */ hCursor __MIDL_0068,
    /* [in] */ short __MIDL_0069,
    /* [in] */ short __MIDL_0070,
    /* [in] */ list_t __MIDL_0071,
    /* [in] */ list_t __MIDL_0072,
    /* [out] */ list_t __RPC_FAR *__MIDL_0073)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          28);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0068);;
        
        
        _StubMsg.BufferLength = 20U + 2U + 2U + 0U + 0U;
        NdrComplexStructBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR *)&__MIDL_0071,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264] );
        
        NdrComplexStructBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR *)&__MIDL_0072,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0068,
                            1);
        *(( short __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0069;
        
        *(( short __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0070;
        
        NdrComplexStructMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                  (unsigned char __RPC_FAR *)&__MIDL_0071,
                                  (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264] );
        
        NdrComplexStructMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                  (unsigned char __RPC_FAR *)&__MIDL_0072,
                                  (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[286] );
        
        NdrComplexStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0073,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264],
                                    (unsigned char)0 );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


error_t rpcCursorProcedure( 
    /* [in] */ hCursor __MIDL_0074,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0075,
    /* [in] */ variant_t __MIDL_0076,
    /* [in] */ list_t __MIDL_0077,
    /* [out] */ list_t __RPC_FAR *__MIDL_0078)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          29);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0074);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 0U + 0U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0075,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrComplexStructBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR *)&__MIDL_0076,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[284] );
        
        NdrComplexStructBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR *)&__MIDL_0077,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0074,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0075,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrComplexStructMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                  (unsigned char __RPC_FAR *)&__MIDL_0076,
                                  (PFORMAT_STRING) &__MIDLTypeFormatString.Format[284] );
        
        NdrComplexStructMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                  (unsigned char __RPC_FAR *)&__MIDL_0077,
                                  (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[308] );
        
        NdrComplexStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0078,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[264],
                                    (unsigned char)0 );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


hSession rpcPerfLogin( 
    /* [in] */ hDriver __MIDL_0079)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    hSession _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          30);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0079);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0079,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[330] );
        
        _RetVal = 0;
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )&_RetVal,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcPerfWait( 
    /* [in] */ hSession __MIDL_0080,
    /* [in] */ unsigned long __MIDL_0081,
    /* [size_is][string][out] */ char __RPC_FAR *__MIDL_0082,
    /* [in] */ unsigned short size)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          31);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0080);;
        
        
        _StubMsg.BufferLength = 20U + 4U + 2U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0080,
                            1);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0081;
        
        *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++ = size;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[338] );
        
        NdrConformantStringUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0082,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[308],
                                       (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


error_t rpcPerfDone( 
    /* [in] */ hSession __MIDL_0083,
    /* [in] */ error_t __MIDL_0084)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          32);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0083);;
        
        
        _StubMsg.BufferLength = 20U + 2U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0083,
                            1);
        *(( error_t __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0084;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[352] );
        
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


unsigned short rpcPerfWaiting( 
    /* [in] */ hSession __MIDL_0085)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    unsigned short _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          33);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0085);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0085,
                            1);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[360] );
        
        _RetVal = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


error_t rpcPerfSignal( 
    /* [in] */ hSession __MIDL_0086,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0087,
    /* [in] */ unsigned short __MIDL_0088,
    /* [in] */ unsigned long __MIDL_0089)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          34);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0086);;
        
        
        _StubMsg.BufferLength = 20U + 12U + 5U + 10U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0087,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0086,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0087,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0088;
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 3) & ~ 0x3);
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0089;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[366] );
        
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcPerfRPC( 
    /* [in] */ hSession __MIDL_0090,
    /* [in] */ unsigned short __MIDL_0091,
    /* [out] */ variant_t __RPC_FAR *__MIDL_0092)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          35);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0090);;
        
        
        _StubMsg.BufferLength = 20U + 2U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0090,
                            1);
        *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++ = __MIDL_0091;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[380] );
        
        NdrComplexStructUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                    (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0092,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[284],
                                    (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


error_t rpcPerfODBC( 
    /* [in] */ hSession __MIDL_0093,
    /* [string][in] */ const char __RPC_FAR *__MIDL_0094)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    error_t _RetVal;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          36);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0093);;
        
        
        _StubMsg.BufferLength = 20U + 12U;
        NdrConformantStringBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                       (unsigned char __RPC_FAR *)__MIDL_0094,
                                       (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0093,
                            1);
        NdrConformantStringMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                     (unsigned char __RPC_FAR *)__MIDL_0094,
                                     (PFORMAT_STRING) &__MIDLTypeFormatString.Format[2] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[392] );
        
        _RetVal = *(( error_t __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
    return _RetVal;
}


void rpcBufferRelease( 
    /* [out][in] */ hBuffer __RPC_FAR *__MIDL_0095)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          37);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )*__MIDL_0095);;
        
        
        _StubMsg.BufferLength = 20U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )*__MIDL_0095,
                            0);
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[402] );
        
        NdrClientContextUnmarshall(
                              ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                              ( NDR_CCONTEXT __RPC_FAR * )__MIDL_0095,
                              _Handle);
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void rpcBufferRead( 
    /* [in] */ hBuffer __MIDL_0096,
    /* [size_is][out] */ char __RPC_FAR *__MIDL_0097,
    /* [out][in] */ unsigned short __RPC_FAR *size)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          38);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0096);;
        
        
        _StubMsg.BufferLength = 20U + 2U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0096,
                            1);
        *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++ = *size;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[408] );
        
        NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR * __RPC_FAR *)&__MIDL_0097,
                                      (PFORMAT_STRING) &__MIDLTypeFormatString.Format[334],
                                      (unsigned char)0 );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        *size = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void rpcBufferWrite( 
    /* [in] */ hBuffer __MIDL_0098,
    /* [size_is][in] */ char __RPC_FAR *__MIDL_0099,
    /* [out][in] */ unsigned short __RPC_FAR *size)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&ABTServer_StubDesc,
                          39);
        
        
        _Handle = NDRCContextBinding(( NDR_CCONTEXT  )__MIDL_0098);;
        
        
        _StubMsg.BufferLength = 20U + 4U + 5U;
        _StubMsg.MaxCount = size ? *size : 0;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)__MIDL_0099,
                                      (PFORMAT_STRING) &__MIDLTypeFormatString.Format[334] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        NdrClientContextMarshall(
                            ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                            ( NDR_CCONTEXT  )__MIDL_0098,
                            1);
        _StubMsg.MaxCount = size ? *size : 0;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)__MIDL_0099,
                                    (PFORMAT_STRING) &__MIDLTypeFormatString.Format[334] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 1) & ~ 0x1);
        *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++ = *size;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[422] );
        
        *size = *(( unsigned short __RPC_FAR * )_StubMsg.Buffer)++;
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}

extern MALLOC_FREE_STRUCT _MallocFreeStruct;

static const MIDL_STUB_DESC ABTServer_StubDesc = 
    {
    (void __RPC_FAR *)& ABTServer___RpcClientInterface,
    NdrRpcSmClientAllocate,
    NdrRpcSmClientFree,
    &ABTServer__MIDL_AutoBindHandle,
    0,
    0,
    0,
    0,
    __MIDLTypeFormatString.Format,
    0, /* -error bounds_check flag */
    0x10001, /* Ndr library version */
    &_MallocFreeStruct,
    0x300000f, /* MIDL Version 3.0.15 */
    0,
    0,
    0,  /* Reserved1 */
    0,  /* Reserved2 */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

static RPC_DISPATCH_FUNCTION ABTServer_table[] =
    {
    ABTServer_rpcDebug,
    ABTServer_rpcRaise,
    ABTServer_rpcProgressCreate,
    ABTServer_rpcProgressRelease,
    ABTServer_rpcProgressTitle,
    ABTServer_rpcProgressReset,
    ABTServer_rpcProgressCount,
    0
    };
RPC_DISPATCH_TABLE ABTServer_v2_0_DispatchTable = 
    {
    7,
    ABTServer_table
    };

void __RPC_FAR * __RPC_USER
ABTServer_malloc_wrapper( size_t _Size )
{
    return( _fmalloc( _Size ) );
}

void  __RPC_USER
ABTServer_free_wrapper( void __RPC_FAR * _p )
{
    _ffree( _p );
}

static MALLOC_FREE_STRUCT _MallocFreeStruct = 
{
    ABTServer_malloc_wrapper,
    ABTServer_free_wrapper
};

#if !defined(__RPC_WIN16__) 
#error  Invalid build platform for this stub.
#endif

static const MIDL_PROC_FORMAT_STRING __MIDLProcFormatString =
    {
        0,
        {
			0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  2 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/*  4 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/*  6 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/*  8 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 10 */	
			0x4d,		/* FC_IN_PARAM */
			0x7,		/* Stack size = 7 */

/* 12 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */
/* 14 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 16 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 18 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 20 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 22 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 24 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 26 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 28 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 30 */	NdrFcShort( 0x16 ),	/* Type Offset=22 */
/* 32 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 34 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 36 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 38 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 40 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 42 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 44 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 46 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 48 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 50 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 52 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 54 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 56 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 58 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 60 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/* 62 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 64 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */
/* 66 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 68 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */
/* 70 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 72 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 74 */	NdrFcShort( 0x26 ),	/* Type Offset=38 */
/* 76 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 78 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 80 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 82 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 84 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 86 */	NdrFcShort( 0x2a ),	/* Type Offset=42 */
/* 88 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 90 */	NdrFcShort( 0x2e ),	/* Type Offset=46 */
/* 92 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 94 */	NdrFcShort( 0x26 ),	/* Type Offset=38 */
/* 96 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 98 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 100 */	NdrFcShort( 0x32 ),	/* Type Offset=50 */
/* 102 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 104 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 106 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 108 */	NdrFcShort( 0x3a ),	/* Type Offset=58 */
/* 110 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 112 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 114 */	NdrFcShort( 0x5e ),	/* Type Offset=94 */
/* 116 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 118 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 120 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 122 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0xc,		/* FC_DOUBLE */
/* 124 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 126 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 128 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 130 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 132 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 134 */	NdrFcShort( 0x66 ),	/* Type Offset=102 */
/* 136 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 138 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 140 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 142 */	NdrFcShort( 0x6a ),	/* Type Offset=106 */
/* 144 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 146 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 148 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 150 */	NdrFcShort( 0x6e ),	/* Type Offset=110 */
/* 152 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 154 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 156 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 158 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 160 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 162 */	NdrFcShort( 0x72 ),	/* Type Offset=114 */
/* 164 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 166 */	NdrFcShort( 0x76 ),	/* Type Offset=118 */
/* 168 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 170 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 172 */	NdrFcShort( 0x8e ),	/* Type Offset=142 */
/* 174 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 176 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 178 */	NdrFcShort( 0x72 ),	/* Type Offset=114 */
/* 180 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 182 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 184 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 186 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 188 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 190 */	NdrFcShort( 0x72 ),	/* Type Offset=114 */
/* 192 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 194 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 196 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 198 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 200 */	NdrFcShort( 0x72 ),	/* Type Offset=114 */
/* 202 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 204 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 206 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 208 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 210 */	NdrFcShort( 0x96 ),	/* Type Offset=150 */
/* 212 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 214 */	NdrFcShort( 0x72 ),	/* Type Offset=114 */
/* 216 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 218 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 220 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 222 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 224 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 226 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 228 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 230 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 232 */	NdrFcShort( 0x72 ),	/* Type Offset=114 */
/* 234 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 236 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 238 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 240 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 242 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 244 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 246 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 248 */	NdrFcShort( 0x9a ),	/* Type Offset=154 */
/* 250 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 252 */	NdrFcShort( 0x9e ),	/* Type Offset=158 */
/* 254 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 256 */	NdrFcShort( 0xcc ),	/* Type Offset=204 */
/* 258 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 260 */	NdrFcShort( 0xd0 ),	/* Type Offset=208 */
/* 262 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 264 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 266 */	NdrFcShort( 0x9a ),	/* Type Offset=154 */
/* 268 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 270 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 272 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 274 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 276 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 278 */	NdrFcShort( 0xd8 ),	/* Type Offset=216 */
/* 280 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 282 */	NdrFcShort( 0x9a ),	/* Type Offset=154 */
/* 284 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 286 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 288 */	NdrFcShort( 0x9a ),	/* Type Offset=154 */
/* 290 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 292 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 294 */	
			0x4d,		/* FC_IN_PARAM */
			0x3,		/* Stack size = 3 */

/* 296 */	NdrFcShort( 0x108 ),	/* Type Offset=264 */
/* 298 */	
			0x4d,		/* FC_IN_PARAM */
			0x3,		/* Stack size = 3 */

/* 300 */	NdrFcShort( 0x108 ),	/* Type Offset=264 */
/* 302 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 304 */	NdrFcShort( 0x118 ),	/* Type Offset=280 */
/* 306 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 308 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 310 */	NdrFcShort( 0x9a ),	/* Type Offset=154 */
/* 312 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 314 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 316 */	
			0x4d,		/* FC_IN_PARAM */
			0x5,		/* Stack size = 5 */

/* 318 */	NdrFcShort( 0x11c ),	/* Type Offset=284 */
/* 320 */	
			0x4d,		/* FC_IN_PARAM */
			0x3,		/* Stack size = 3 */

/* 322 */	NdrFcShort( 0x108 ),	/* Type Offset=264 */
/* 324 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 326 */	NdrFcShort( 0x118 ),	/* Type Offset=280 */
/* 328 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 330 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 332 */	NdrFcShort( 0x26 ),	/* Type Offset=38 */
/* 334 */	
			0x52,		/* FC_RETURN_PARAM */
			0x2,		/* Stack size = 2 */

/* 336 */	NdrFcShort( 0x12c ),	/* Type Offset=300 */
/* 338 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 340 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 342 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 344 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 346 */	NdrFcShort( 0x130 ),	/* Type Offset=304 */
/* 348 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 350 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 352 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 354 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 356 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 358 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 360 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 362 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 364 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 366 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 368 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 370 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 372 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 374 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 376 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 378 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 380 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 382 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 384 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 386 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 388 */	NdrFcShort( 0x13a ),	/* Type Offset=314 */
/* 390 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 392 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 394 */	NdrFcShort( 0x36 ),	/* Type Offset=54 */
/* 396 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 398 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */
/* 400 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x6,		/* FC_SHORT */
/* 402 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 404 */	NdrFcShort( 0x13e ),	/* Type Offset=318 */
/* 406 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 408 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 410 */	NdrFcShort( 0x146 ),	/* Type Offset=326 */
/* 412 */	
			0x51,		/* FC_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 414 */	NdrFcShort( 0x14a ),	/* Type Offset=330 */
/* 416 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 418 */	NdrFcShort( 0x158 ),	/* Type Offset=344 */
/* 420 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/* 422 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 424 */	NdrFcShort( 0x146 ),	/* Type Offset=326 */
/* 426 */	
			0x4d,		/* FC_IN_PARAM */
			0x2,		/* Stack size = 2 */

/* 428 */	NdrFcShort( 0x14a ),	/* Type Offset=330 */
/* 430 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x2,		/* Stack size = 2 */

/* 432 */	NdrFcShort( 0x158 ),	/* Type Offset=344 */
/* 434 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDLTypeFormatString =
    {
        0,
        {
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/*  2 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/*  4 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/*  6 */	NdrFcShort( 0xe ),	/* 14 */
/*  8 */	NdrFcShort( 0x0 ),	/* 0 */
/* 10 */	NdrFcShort( 0x8 ),	/* Offset= 8 (18) */
/* 12 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 14 */	0x6,		/* FC_SHORT */
			0x8,		/* FC_LONG */
/* 16 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 18 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 20 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 22 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 24 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 26 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 28 */	0x0,		/* 0 */
			0x1,		/* 1 */
/* 30 */	
			0x11, 0x0,	/* FC_RP */
/* 32 */	NdrFcShort( 0x2 ),	/* Offset= 2 (34) */
/* 34 */	0x30,		/* FC_BIND_CONTEXT */
			0xe0,		/* 224 */
/* 36 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 38 */	0x30,		/* FC_BIND_CONTEXT */
			0x40,		/* 64 */
/* 40 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 42 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 44 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 46 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 48 */	0x1,		/* 1 */
			0x4,		/* 4 */
/* 50 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 52 */	0x1,		/* 1 */
			0x2,		/* 2 */
/* 54 */	0x30,		/* FC_BIND_CONTEXT */
			0x40,		/* 64 */
/* 56 */	0x1,		/* 1 */
			0x0,		/* 0 */
/* 58 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 60 */	NdrFcShort( 0x2 ),	/* Offset= 2 (62) */
/* 62 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 64 */	NdrFcShort( 0x10 ),	/* 16 */
/* 66 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 68 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 70 */	NdrFcShort( 0x4 ),	/* 4 */
/* 72 */	NdrFcShort( 0x4 ),	/* 4 */
/* 74 */	0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 76 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 78 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 80 */	NdrFcShort( 0x8 ),	/* 8 */
/* 82 */	NdrFcShort( 0x8 ),	/* 8 */
/* 84 */	0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 86 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 88 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 90 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 92 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 94 */	
			0x11, 0x0,	/* FC_RP */
/* 96 */	NdrFcShort( 0x2 ),	/* Offset= 2 (98) */
/* 98 */	0x30,		/* FC_BIND_CONTEXT */
			0xe0,		/* 224 */
/* 100 */	0x1,		/* 1 */
			0x0,		/* 0 */
/* 102 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 104 */	0x2,		/* 2 */
			0x2,		/* 2 */
/* 106 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 108 */	0x2,		/* 2 */
			0x1,		/* 1 */
/* 110 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 112 */	0x3,		/* 3 */
			0x1,		/* 1 */
/* 114 */	0x30,		/* FC_BIND_CONTEXT */
			0x40,		/* 64 */
/* 116 */	0x2,		/* 2 */
			0x0,		/* 0 */
/* 118 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 120 */	NdrFcShort( 0x2 ),	/* Offset= 2 (122) */
/* 122 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 124 */	NdrFcShort( 0x8 ),	/* 8 */
/* 126 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 128 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 130 */	NdrFcShort( 0x0 ),	/* 0 */
/* 132 */	NdrFcShort( 0x0 ),	/* 0 */
/* 134 */	0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 136 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 138 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 140 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 142 */	
			0x11, 0x0,	/* FC_RP */
/* 144 */	NdrFcShort( 0x2 ),	/* Offset= 2 (146) */
/* 146 */	0x30,		/* FC_BIND_CONTEXT */
			0xe0,		/* 224 */
/* 148 */	0x2,		/* 2 */
			0x0,		/* 0 */
/* 150 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 152 */	0x3,		/* 3 */
			0x3,		/* 3 */
/* 154 */	0x30,		/* FC_BIND_CONTEXT */
			0x40,		/* 64 */
/* 156 */	0x3,		/* 3 */
			0x0,		/* 0 */
/* 158 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 160 */	NdrFcShort( 0x2 ),	/* Offset= 2 (162) */
/* 162 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 164 */	NdrFcShort( 0xc ),	/* 12 */
/* 166 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 168 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 172 */	NdrFcShort( 0x0 ),	/* 0 */
/* 174 */	0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 176 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 178 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 180 */	NdrFcShort( 0x4 ),	/* 4 */
/* 182 */	NdrFcShort( 0x4 ),	/* 4 */
/* 184 */	0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 186 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 188 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 190 */	NdrFcShort( 0x8 ),	/* 8 */
/* 192 */	NdrFcShort( 0x8 ),	/* 8 */
/* 194 */	0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 196 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/* 198 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 200 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 202 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 204 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 206 */	0x4,		/* 4 */
			0x2,		/* 2 */
/* 208 */	
			0x11, 0x0,	/* FC_RP */
/* 210 */	NdrFcShort( 0x2 ),	/* Offset= 2 (212) */
/* 212 */	0x30,		/* FC_BIND_CONTEXT */
			0xe0,		/* 224 */
/* 214 */	0x3,		/* 3 */
			0x0,		/* 0 */
/* 216 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 218 */	0x4,		/* 4 */
			0x3,		/* 3 */
/* 220 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 222 */	NdrFcShort( 0x1 ),	/* 1 */
/* 224 */	0x19,		/* 25 */
			0x0,		/*  */
/* 226 */	NdrFcShort( 0x2 ),	/* 2 */
/* 228 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 230 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 232 */	NdrFcShort( 0xa ),	/* 10 */
/* 234 */	NdrFcShort( 0x0 ),	/* 0 */
/* 236 */	NdrFcShort( 0x6 ),	/* Offset= 6 (242) */
/* 238 */	0x6,		/* FC_SHORT */
			0x8,		/* FC_LONG */
/* 240 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 242 */	
			0x12, 0x0,	/* FC_UP */
/* 244 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (220) */
/* 246 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 248 */	NdrFcShort( 0x0 ),	/* 0 */
/* 250 */	0x17,		/* 23 */
			0x0,		/*  */
/* 252 */	NdrFcShort( 0x0 ),	/* 0 */
/* 254 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 258 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 260 */	NdrFcShort( 0xffffffe2 ),	/* Offset= -30 (230) */
/* 262 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 264 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 266 */	NdrFcShort( 0x6 ),	/* 6 */
/* 268 */	NdrFcShort( 0x0 ),	/* 0 */
/* 270 */	NdrFcShort( 0x6 ),	/* Offset= 6 (276) */
/* 272 */	0x6,		/* FC_SHORT */
			0x36,		/* FC_POINTER */
/* 274 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 276 */	
			0x12, 0x0,	/* FC_UP */
/* 278 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (246) */
/* 280 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 282 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (264) */
/* 284 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 286 */	NdrFcShort( 0xa ),	/* 10 */
/* 288 */	NdrFcShort( 0x0 ),	/* 0 */
/* 290 */	NdrFcShort( 0x6 ),	/* Offset= 6 (296) */
/* 292 */	0x6,		/* FC_SHORT */
			0x8,		/* FC_LONG */
/* 294 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 296 */	
			0x12, 0x0,	/* FC_UP */
/* 298 */	NdrFcShort( 0xffffffb2 ),	/* Offset= -78 (220) */
/* 300 */	0x30,		/* FC_BIND_CONTEXT */
			0x30,		/* 48 */
/* 302 */	0x1,		/* 1 */
			0x1,		/* 1 */
/* 304 */	
			0x11, 0x0,	/* FC_RP */
/* 306 */	NdrFcShort( 0x2 ),	/* Offset= 2 (308) */
/* 308 */	
			0x22,		/* FC_C_CSTRING */
			0x44,		/* FC_STRING_SIZED */
/* 310 */	0x27,		/* 39 */
			0x0,		/*  */
/* 312 */	NdrFcShort( 0xc ),	/*  Stack size/offset = 12 */
/* 314 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 316 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (284) */
/* 318 */	
			0x11, 0x0,	/* FC_RP */
/* 320 */	NdrFcShort( 0x2 ),	/* Offset= 2 (322) */
/* 322 */	0x30,		/* FC_BIND_CONTEXT */
			0xe0,		/* 224 */
/* 324 */	0x4,		/* 4 */
			0x0,		/* 0 */
/* 326 */	0x30,		/* FC_BIND_CONTEXT */
			0x40,		/* 64 */
/* 328 */	0x4,		/* 4 */
			0x0,		/* 0 */
/* 330 */	
			0x11, 0x0,	/* FC_RP */
/* 332 */	NdrFcShort( 0x2 ),	/* Offset= 2 (334) */
/* 334 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 336 */	NdrFcShort( 0x1 ),	/* 1 */
/* 338 */	0x27,		/* 39 */
			0x54,		/* FC_DEREFERENCE */
/* 340 */	NdrFcShort( 0x8 ),	/*  Stack size/offset = 8 */
/* 342 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */
/* 344 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 346 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */

			0x0
        }
    };
