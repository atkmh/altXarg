import java.io.*;
import java.util.Date;

public class PartTime2 extends Employee
//member variables
{	
	double dbMIN = .56;	

	PartTime2 (String N, int Y, int M, int D,  String F, String P)//int Da
	{
	super(N,Y,M,D,F,P);
	}//constructor 2
	

    // this method takes the current date and subtracts the start date
	// places into a monthly format and then multiples the monthly vacation accural rate
	// intYear intMonth intDay were initialized when constructor was called
	// by instantiation of this class. This is overriding the method.
	public long VacationAccuralCalc ()
	{		Date curdate = new Date();
			long dayMill = curdate.getTime();
			long mill = doh.getTime();
			long loAccuredTotal = dayMill - mill;
			loAccuredTotal /= 2505600000L;
			loAccuredTotal *= dbMIN;
			loAccuredTotal += .65;
			return (loAccuredTotal);
	}//end of VacationAccuralCalc method

    //this method takes the accural and subtracts the accural taken and 
	//returns available vacation
	public long VacationAvailableCalc ()
	{		Date curdate = new Date();
			// intYear intMonth intDay were initialized when constructor was called
			// by instantiation of this class.
			long dayMill = curdate.getTime();
			long mill = doh.getTime();
			long loAccuredTotal = dayMill - mill;
			loAccuredTotal /= 2505600000L;
			loAccuredTotal *= dbMIN;
			loAccuredTotal += .65;
			long loAvailableTotal = loAccuredTotal - intNumberDaysTaken;
			return (loAvailableTotal);
	}//end of VacationAvailableCalc method
	


}//end of class Employee