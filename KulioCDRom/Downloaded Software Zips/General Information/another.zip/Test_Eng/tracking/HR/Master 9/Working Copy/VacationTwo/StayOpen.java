import java.io.*;

public class StayOpen
{
	public static void enterToContinue()
	{
		boolean bDone = false;

		System.out.println("Press ENTER to exit...");

		while( false == bDone )
		{
			try
			{
				int iInput = System.in.read( );
				bDone = true;

			}
			catch( IOException e )
			{
				bDone = true;
			}
		}
	}
}