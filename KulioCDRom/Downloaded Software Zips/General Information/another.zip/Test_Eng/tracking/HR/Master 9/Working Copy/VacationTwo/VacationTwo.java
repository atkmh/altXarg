//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// 
//  Copyright (c) 1997 
//
//  Purpose:    Resource vacation management
//
//  Author:     Christina Drukala
//
//  History:    971209  created
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


import java.awt.*;

class VacationTwo extends Frame
{//opens vacationtwo		
	
	//this is a constructor for setting up a simple GUI object
	//used for viewing and eventually selecting individual resources
	//for vacation availability
	TextArea UIvac;	
	Choice Pickemp;


	Employee[] holder = new Employee[23];

	VacationTwo()
	{//opens constructor vacation two
		setTitle("Vacation");
		setLayout(new FlowLayout());
		add(new Button("Display Total"));
		add(new Button("Display This Year"));
		add(new Button("Close"));
		add(new Button("Refresh"));
		add(new Button("Print"));
		add(UIvac = new TextArea(25, 80));	
		add(Pickemp = new Choice());
	
		Pickemp.addItem("Mark Atkinson");
		Pickemp.addItem("Martine Baechtel");
		Pickemp.addItem("Philippe Beaubois");
		Pickemp.addItem("Lee Brewster");
		Pickemp.addItem("Jim Cole");
		Pickemp.addItem("Anne Cook");
		Pickemp.addItem("Gautier De Marcy");
		Pickemp.addItem("Christina Drukala");
		Pickemp.addItem("Douglas Ewing");
		Pickemp.addItem("Robin Fair");
		Pickemp.addItem("Sridhar Goshike");
		Pickemp.addItem("Kimberly Kendell");
		Pickemp.addItem("Jim Lynch");
		Pickemp.addItem("Robert May");
		Pickemp.addItem("Arthur Meadows");
		Pickemp.addItem("Douglas Monroe");
		Pickemp.addItem("Fransico Montes");
		Pickemp.addItem("Eva Morrison");
		Pickemp.addItem("Amos Parlante");
		Pickemp.addItem("Ann Petrucci");
		Pickemp.addItem("Kurt Schutzmann");
		Pickemp.addItem("Terril Slocum");
		Pickemp.addItem("Mark Tankersley");
		Pickemp.addItem("All Employees");
	}//closes constructor vacation two


	
	public boolean handleEvent (Event evt)
	{ //opens handleEvent
		if(evt.id == Event.WINDOW_DESTROY) System.exit(0);
		return super.handleEvent(evt);	
	}//closes handleEvent

	public static void main(String args[])
	{	
		VacationTwo Vac = new VacationTwo();	
		Vac.resize(600,435);
		Vac.show();
	    //constuctor is initializing the object with data from employee object
		//using an array and constructors to detail each staff members hire 
		//detail and file where other vacation detail exists		
		Vac.holder[0]= new Employee("Mark Attkinson", 97,10,10,"Mark.txt","Markprint.txt");
		Vac.holder[1]= new Employee("Martine Baechtel", 98,01,02,"Martine.txt", "Martineprint.txt");
		Vac.holder[2]= new Employee("Philippe Beaubois", 97,04,26,"Philippe.txt", "Philippeprint.txt");
		Vac.holder[3]= new PartTime ("Lee Brewster", 98,04,04,"Lee.txt", "Leeprint.txt");
		Vac.holder[4]= new Employee ("Jim Cole", 97,10,03,"JimC.txt","JimCprint.txt");
		Vac.holder[5]= new PartTime ("Anne Cook", 98,01,98,"AnneC.txt","AnneCprint.txt");
		Vac.holder[6]= new Employee ("Gautier De Marcy", 98,00,29,"GautierD.txt","GautierDprint.txt");
		Vac.holder[7]= new Director ("Christina Drukala",96,8,19,"Christina.txt","Christinaprint.txt");
		Vac.holder[8]= new Employee ("Douglas Ewing", 98,00,01,"DougE.txt","DougEprint.txt");
		Vac.holder[9]= new Employee ("Robin Fair", 97,02,31,"Robin.txt","Robinprint.txt");
		Vac.holder[10]= new Employee ("Sridhar Goshike", 97,04,12,"Sridhar.txt","Sridharprint.txt");
		Vac.holder[11]= new Employee ("Kimberly Kendell", 97,00,27,"Kimberly.txt","Kimberlyprint.txt");
		Vac.holder[12]= new Employee ("Jim Lynch", 96,9,15,"Jim.txt","Jimprint.txt");
		Vac.holder[13]= new Employee ("Robert May", 97,06,05,"Robert.txt","Robertprint.txt");
		Vac.holder[14]= new Employee ("Arthur Meadows", 98,01,05,"ArthurM.txt","ArthurMprint.txt");
		Vac.holder[15]= new Employee ("Douglas Monroe", 97,06,01,"Douglas.txt","Douglasprint.txt");
		Vac.holder[16]= new Employee ("Fransico Montes", 96,9,25,"Francis.txt","Francisprint.txt");
		Vac.holder[17]= new PartTime2 ("Eva Morrison", 98,00,21,"Eva.txt","Evaprint.txt");
		Vac.holder[18]= new PartTime ("Amos Parlante", 98,00,05,"Amos.txt","Amosprint.txt");
		Vac.holder[19]= new Employee ("Ann Petrucci", 97,03,01,"Ann.txt","Annprint.txt");
		Vac.holder[20]= new Employee("Kurt Schutzmann", 97,06,21,"Kirt.txt","Kirtprint.txt");
		Vac.holder[21]= new PartTime ("Terril Slocum", 97,04,27,"Terrill.txt","Terrillprint.txt");
		Vac.holder[22]= new Employee ("Mark Tankersley", 98,00,12,"MarkT.txt","MarkTprint.txt");
	   
	}


	public boolean action (Event evt, Object arg)
	{ //Opens action
		if(arg.equals("Close"))
		{ //opens if
			System.exit(0);
		} //closes if
		
		else if ((arg.equals("Display Total"))) 
		{
		
		int i;
		i=Pickemp.getSelectedIndex();
		
		//	int VacationNumbers = 0;
		//	for(int i=0;i<18;i++)		
				
				//  exersizes vacation methods for days accured, days taken and days available to be taken
		
				int intNumberDaysTaken=holder[i].VacNumberTaken();
				long jmVacationAccural = holder[i].VacationAccuralCalc();
				long jmVacationAvailableCalc = holder[i].VacationAvailableCalc();

				//outputs the vacation method returns  to screen on days accured, days taken and days available to be taken
				//and adds two string method to concatinate variable data with strings
				UIvac.appendText( holder[i].getName() +" was hired on " +  holder[i].getHireDate() + "\n");
				UIvac.appendText("Accurred " + jmVacationAccural + " Vacation Days since hire date." + "\n");	
				UIvac.appendText("Has taken " + intNumberDaysTaken + " Vacation Days since hire date." + "\n");	
				UIvac.appendText("Has " + jmVacationAvailableCalc + " Vacation Days Available." + "\n");	
				UIvac.appendText( holder[i].getName() + " Vacation dates are: " + "\n" );
				
				//  (Vac.UIvac) is a variable stating which instance of the textArea onject to use 
				//(note that the Method ReadVactionFile uses this data
				holder[i].ReadVacationFile(UIvac);
				UIvac.appendText("\n");
				//	StayOpen.enterToContinue();
			//closes for loop

		}//if else execute button
	//	else return super.action(evt,arg);
	//	return true;

		else if ((arg.equals("Display This Year"))) 
		{	
		int i;
		i=Pickemp.getSelectedIndex();
		
		//	int VacationNumbers = 0;
		//	for(int i=0;i<19;i++)		
				
				//  exersizes vacation methods for days accured, days taken and days available to be taken
		
				int intNumberDaysTaken=holder[i].VacNumberTaken();
				long jmVacationAccural = holder[i].VacationAccuralCalc();
				long jmThisYearAccural = holder[i].ThisYearCalc ();
				long jmVacationAvailableCalc = holder[i].VacationAvailableCalc();

				//outputs the vacation method returns  to screen on days accured, days taken and days available to be taken
				//and adds two string method to concatinate variable data with strings
			
				UIvac.appendText( holder[i].getName() +" was hired on " +  holder[i].getHireDate() + "\n");
				UIvac.appendText("Accurred " + jmThisYearAccural + " Vacation Days this year." + "\n");	
				UIvac.appendText("Has taken " + intNumberDaysTaken + " Vacation Days since hire date." + "\n");	
				UIvac.appendText("Has " + jmVacationAvailableCalc + " unused Vacation Days Available." + "\n");	
		
				//	UIvac.appendText( holder[i].getName() + "Vacation dates are " + "\n" );
				//  (Vac.UIvac) is a variable stating which instance of the textArea onject to use 
				//(note that the Method ReadVactionFile uses this data
				holder[i].ReadVacationFile(UIvac);
				UIvac.appendText("\n");
				UIvac.selectAll();
				
				//	StayOpen.enterToContinue();
			//closes for loop

		}//if else execute button


		else if ((arg.equals("Print"))) 
		{	
		int i;
		i=Pickemp.getSelectedIndex();
	
		holder[i].VacNumberTaken();
		holder[i].VacationAccuralCalc();
		holder[i].ThisYearCalc ();
		holder[i].VacationAvailableCalc();	
		holder[i].PrintVacationFile(UIvac);
		holder[i].CurrentDate ();	

		}//if else execute button
		else return super.action(evt,arg);
		return true;
	}//boolean action			
		
}//closes vaction two

