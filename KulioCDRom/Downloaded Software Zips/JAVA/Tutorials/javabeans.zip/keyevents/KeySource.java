package keyevents;
import java.awt.*;
public class KeySource extends TextField {
  public KeySource() {
    super(10);
  }
}