package focusevents;
import java.awt.*;
public class FocusSource extends TextField {
  public FocusSource() {
    super(10);
  }
}