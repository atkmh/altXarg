package serial;

public class A {
  protected int a;
  public A() {
    a = 1;
  }
}