package serial;

public class D extends C {
  protected int d;
  public D() {
    d = 4;
  }
}