package serial;

public class E extends D {
  protected int e;
  public E() {
    e = 5;
  }
  public String toString() {
    return "a = " + a + "; b = " + b + "; c = " + c + "; d = " + d + "; e = " + e;
  }
}