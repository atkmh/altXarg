package serial;

public class B extends A {
  protected int b;
  public B() {
    b = 2;
  }
}