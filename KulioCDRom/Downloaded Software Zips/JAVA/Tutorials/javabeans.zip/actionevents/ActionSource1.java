package actionevents;
import java.awt.*;

public class ActionSource1 extends Button {

  public ActionSource1() {
    super("ActionSource1");
  }
}