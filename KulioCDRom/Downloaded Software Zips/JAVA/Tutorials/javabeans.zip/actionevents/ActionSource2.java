package actionevents;
import java.awt.*;

public class ActionSource2 extends List {

  public ActionSource2() {
    add("Item 1");
    add("Item 2");
    add("Item 3");
  }
}