package smtp;

public interface SmtpSource {

  public void respond(int code);
}