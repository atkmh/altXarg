package textevents;
import java.awt.*;

public class TextSource extends TextField {

  public TextSource() {
    super(10);
  }
}