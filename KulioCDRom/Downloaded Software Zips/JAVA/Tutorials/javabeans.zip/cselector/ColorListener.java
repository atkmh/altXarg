package cselector;
import java.util.*;

public interface ColorListener extends EventListener {

  public void changeColor(ColorEvent ce);
}