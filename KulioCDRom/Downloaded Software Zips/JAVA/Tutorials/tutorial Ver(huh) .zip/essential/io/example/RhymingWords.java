/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
import java.io.*;

public class RhymingWords {
    public static void main(String[] args) throws IOException {

        DataInputStream words = new DataInputStream(
				    new FileInputStream("words.txt"));

        // do the reversing and sorting
        InputStream rhymedWords = reverse(sort(reverse(words)));

        // write new list to standard out
        DataInputStream in = new DataInputStream(rhymedWords);
        String input;

        while ((input = in.readLine()) != null)
            System.out.println(input);
        in.close();
    }

    public static InputStream reverse(InputStream source) throws IOException {

        DataInputStream in = new DataInputStream(source);

        PipedOutputStream pipeOut = new PipedOutputStream();
        PipedInputStream pipeIn = new PipedInputStream(pipeOut);
        PrintStream out = new PrintStream(pipeOut);

        new ReverseThread(out, in).start();

        return pipeIn;
    }

    public static InputStream sort(InputStream source) throws IOException {

        DataInputStream in = new DataInputStream(source);

        PipedOutputStream pipeOut = new PipedOutputStream();
        PipedInputStream pipeIn = new PipedInputStream(pipeOut);
        PrintStream out = new PrintStream(pipeOut);

        new SortThread(out, in).start();

        return pipeIn;
    }
}
