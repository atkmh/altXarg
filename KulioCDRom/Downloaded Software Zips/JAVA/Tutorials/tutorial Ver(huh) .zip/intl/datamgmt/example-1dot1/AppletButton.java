/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
import java.awt.*;
import java.util.*;
import java.applet.Applet;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AppletButton extends Applet implements Runnable, ActionListener {
    int frameNumber = 1;
    String buttonText = "Click here to bring up AroundTheWorld";
    String windowTitle = "AroundTheWorld";
    int requestedWidth = 0;
    int requestedHeight = 0;
    Button button;
    Thread windowThread;
    Label label;
    boolean pleaseCreate = false;

    public void init() {

        String windowWidthString = getParameter("WINDOWWIDTH");
        if (windowWidthString != null) {
            try {
                requestedWidth = Integer.parseInt(windowWidthString);
            } catch (NumberFormatException e) {
                //Use default width.
            }
        }
 
        String windowHeightString = getParameter("WINDOWHEIGHT");
        if (windowHeightString != null) {
            try {
                requestedHeight = Integer.parseInt(windowHeightString);
            } catch (NumberFormatException e) {
                //Use default height.
            }
        }
 
        setLayout(new GridLayout(2,0));
        add(button = new Button(buttonText));
        button.setFont(new Font("Helvetica", Font.PLAIN, 14));

        add(label = new Label("", Label.CENTER));
	button.addActionListener(this);
    }

    public void start() {
        if (windowThread == null) {
            windowThread = new Thread(this, "Bringing Up AroundTheWorld");
            windowThread.start();
        }
    }

    public synchronized void run() {
        while (windowThread != null) {
            while (pleaseCreate == false) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }

            //We've been asked to bring up a window.
            pleaseCreate = false;
            Frame window = new IntlWindow(this);

	    if (frameNumber == 1) {
	        window.setTitle(windowTitle);
	    } else {
	        window.setTitle(windowTitle + ": " + frameNumber);
	    }
	    frameNumber++;

	    //Set the window's size.
	    window.pack();
	    if ((requestedWidth > 0) | (requestedHeight > 0)) {
	        window.setSize(Math.max(requestedWidth,
				   window.getSize().width),
			       Math.max(requestedHeight,
				   window.getSize().height));
	    }

	    window.show();
	    label.setText("");
	}
    }
                
    public synchronized void actionPerformed(ActionEvent event) {
	Dimension d = null;
	try {
	    d = getSize(); //1.1 code
            if (event.getSource() instanceof Button) {
                //signal the window thread to build a window
                label.setText("Please wait while the window comes up...");
                pleaseCreate = true;
                notify();
            } 
	} catch (NoSuchMethodError e) {
	    label.setText("Your browser can't run 1.1 applets.");
	}
    }
}
