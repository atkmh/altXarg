/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.applet.Applet;

import java.net.URL;
import java.net.MalformedURLException;

class SoundCanvas extends PictureCanvas {

    String audioClipName = null;
    Applet parentApplet = null;

    public SoundCanvas(Image image, LinguaPanel parent, 
		              int initialWidth, int initialHeight,
			      String audioClipName, Applet parentApplet) {
	super(image, parent, initialWidth, initialHeight);
	this.audioClipName = audioClipName;
	this.parentApplet = parentApplet;
	addMouseListener(new MyAdapter());
    }

    class MyAdapter extends MouseAdapter {
	public void mouseClicked(MouseEvent evt) {
	    if ((audioClipName != null) && (parentApplet != null)) {
	        try {
	            URL auURL = new URL(parentApplet.getCodeBase(), audioClipName);
	            parentApplet.play(auURL);
	        } catch (java.net.MalformedURLException e) {
	        }
	    }
	}
    }
}
