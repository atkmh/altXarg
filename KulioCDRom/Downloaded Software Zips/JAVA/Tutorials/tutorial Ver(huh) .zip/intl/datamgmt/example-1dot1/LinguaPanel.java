/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
import java.awt.*;

import java.applet.Applet;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import java.text.NumberFormat;
import java.text.DateFormat;
import java.text.MessageFormat;

import java.net.URL;

class LinguaPanel extends Panel implements Runnable {

    private Label localeLabel;
    private Label localeValue;

    private Label dateLabel;
    private Label dateValue;
    private Calendar cal;
    private Date date;
    private DateFormat dateFormatter;

    private Label timeLabel;
    private Label timeValue;
    private DateFormat timeFormatter;

    private Label gdpLabel;
    private Label gdpValue;
    private Double gdp;
    private NumberFormat gdpFormatter;

    private Label populationLabel;
    private Label populationValue;
    private Integer population;
    private NumberFormat populationFormatter;

    private Label literacyLabel;
    private Label literacyValue;
    private Double literacy;
    private NumberFormat literacyFormatter;

    private TextArea description;

    private SoundCanvas[] soundCanvases;
    private Panel soundPanel;

    private Font defaultFont;
    private Font boldFont;

    private Thread clockThread = null;
    private Locale currentLocale;

    LinguaPanel(Locale locale, Applet parentApplet,
                Font defaultFont, Font boldFont, Image[] soundImages, String[] soundNames)
		throws java.util.MissingResourceException {

	ResourceBundle labels = ResourceBundle.getBundle("LabelsBundle", locale);
	ResourceBundle paragraph = ResourceBundle.getBundle("ParagraphBundle", locale);
	ResourceBundle numbers = ResourceBundle.getBundle("NumbersBundle", locale);
	ResourceBundle soundBundle = ResourceBundle.getBundle("SoundBundle", locale);

	currentLocale = locale;

    // create the GUI elements for the locale name display
        localeLabel = new Label();
        localeLabel.setFont(boldFont);
        localeValue = new Label();

        add(localeLabel);
        add(localeValue);

    // create the GUI elements for the Date display and add them to the window
        dateLabel = new Label();
        dateLabel.setFont(boldFont);
        dateValue = new Label();

        add(dateLabel);
        add(dateValue);

        timeLabel = new Label();
        timeLabel.setFont(boldFont);
        timeValue = new Label();

        add(timeLabel);
        add(timeValue);

    // create the GUI elements for the gdp display and add them to the window
        gdpLabel = new Label();
        gdpLabel.setFont(boldFont);
        gdpValue = new Label();

        add(gdpLabel);
        add(gdpValue);

    // create the GUI elements for the population display and add them to the window
        populationLabel = new Label();
        populationLabel.setFont(boldFont);
        populationValue = new Label();

        add(populationLabel);
        add(populationValue);

    // create the GUI elements for the literacy display and add them to the window
        literacyLabel = new Label();
        literacyLabel.setFont(boldFont);
        literacyValue = new Label();

        add(literacyLabel);
        add(literacyValue);

    // create the sound canvases and add them to the window
	soundPanel = new Panel();
	soundPanel.setLayout(new FlowLayout());
	soundCanvases = new SoundCanvas[soundImages.length];
	for (int i = 0; i < soundCanvases.length; i++) {
	    soundCanvases[i] = new SoundCanvas(soundImages[i], this,
		soundImages[i].getHeight(this), soundImages[i].getWidth(this),
		soundBundle.getString(soundNames[i]), parentApplet);
	    soundPanel.add(soundCanvases[i]);
	}
	add(soundPanel);

    // create a text area
	description = new TextArea(paragraph.getString("LocaleDescription"),
		7, 10, TextArea.SCROLLBARS_VERTICAL_ONLY);
	description.setEditable(false);
        add(description);

    // set text for GUI items based on locale
        localeLabel.setText(labels.getString("LocaleLabel"));
        localeValue.setText(currentLocale.getDisplayName(currentLocale));

	Object[] args = { labels.getString("RepCity") };
	String result = MessageFormat.format(labels.getString("TimeLabel"), args);
        timeLabel.setText(result);

	timeFormatter = DateFormat.getTimeInstance(DateFormat.DEFAULT, locale);
	TimeZone tz = TimeZone.getTimeZone(labels.getString("TimeZone"));
	timeFormatter.setTimeZone(tz);

	updateTime(currentLocale);

        dateLabel.setText(labels.getString("DateLabel"));
	dateFormatter = DateFormat.getDateInstance(DateFormat.DEFAULT, currentLocale);
	dateFormatter.setTimeZone(tz);
        dateValue.setText(dateFormatter.format(date));

        gdpLabel.setText(labels.getString("GDPLabel"));
	gdpFormatter = NumberFormat.getCurrencyInstance(currentLocale);
	gdp = (Double) numbers.getObject("GDP");
        gdpValue.setText(gdpFormatter.format(gdp.doubleValue()));

        populationLabel.setText(labels.getString("PopulationLabel"));
	populationFormatter = NumberFormat.getNumberInstance(currentLocale);
	population = (Integer) numbers.getObject("Population");
        populationValue.setText(populationFormatter.format(population.intValue()));

        literacyLabel.setText(labels.getString("LiteracyLabel"));
	literacyFormatter = NumberFormat.getPercentInstance(currentLocale);
	literacy = (Double) numbers.getObject("Literacy");
        literacyValue.setText(literacyFormatter.format(literacy.doubleValue()));

	layoutGUI();

	if (clockThread == null) {
            clockThread = new Thread(this, "Clock");
            clockThread.start();
        }
    }

    private void updateTime(Locale locale) {
	cal = Calendar.getInstance();
	date = cal.getTime();
        timeValue.setText(timeFormatter.format(date));
    }

    private void layoutGUI() {
        GridBagConstraints c = new GridBagConstraints();
        GridBagLayout gridbag = new GridBagLayout();
        setLayout(gridbag);

        c.fill = GridBagConstraints.BOTH;

    // layout locale stuff
	c.insets = new Insets(5,5,0,5);
        c.anchor = GridBagConstraints.EAST;
	c.fill = GridBagConstraints.VERTICAL;
        c.gridwidth = 1; // reset to the default
        c.weightx = 1.0; // 2 columns of equal width
        gridbag.setConstraints(localeLabel, c);

        c.anchor = GridBagConstraints.CENTER; // reset to default
        c.fill = GridBagConstraints.BOTH; //reset to app default
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(localeValue, c);

    // layout time stuff
	c.insets = new Insets(0,5,0,5);
        c.anchor = GridBagConstraints.EAST;
	c.fill = GridBagConstraints.VERTICAL;
        c.gridwidth = 1; // reset to the default
        c.weightx = 1.0; // 2 columns of equal width
        gridbag.setConstraints(timeLabel, c);

        c.fill = GridBagConstraints.BOTH; //reset to app default
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(timeValue, c);

    // layout date stuff
	c.insets = new Insets(0,5,0,5);
        c.anchor = GridBagConstraints.EAST;
	c.fill = GridBagConstraints.VERTICAL;
        c.gridwidth = 1; // reset to the default
        c.weightx = 1.0; // 2 columns of equal width
        gridbag.setConstraints(dateLabel, c);

        c.anchor = GridBagConstraints.CENTER; // reset to default
        c.fill = GridBagConstraints.BOTH; //reset to app default
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(dateValue, c);

    // layout gdp stuff
        c.anchor = GridBagConstraints.EAST;
	c.fill = GridBagConstraints.VERTICAL;
        c.gridwidth = 1; //reset to the default
	c.weightx = 0.0; //reset to the default
        gridbag.setConstraints(gdpLabel, c);

        c.anchor = GridBagConstraints.CENTER; // reset to default
        c.fill = GridBagConstraints.BOTH; //reset to app default
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(gdpValue, c);

    // layout population stuff
        c.anchor = GridBagConstraints.EAST;
	c.fill = GridBagConstraints.VERTICAL;
        c.gridwidth = 1; //reset to the default
        gridbag.setConstraints(populationLabel, c);

        c.anchor = GridBagConstraints.CENTER; // reset to default
        c.fill = GridBagConstraints.BOTH; //reset to app default
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(populationValue, c);

    // layout population literacy stuff
        c.anchor = GridBagConstraints.EAST;
	c.fill = GridBagConstraints.VERTICAL;
        c.gridwidth = 1; //reset to the default
        gridbag.setConstraints(literacyLabel, c);

        c.anchor = GridBagConstraints.CENTER; // reset to default
        c.fill = GridBagConstraints.BOTH; //reset to app default
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(literacyValue, c);

    // layout image panel
	c.insets = new Insets(5,5,5,5);
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        gridbag.setConstraints(soundPanel, c);

    // layout text area
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER; // end of row
        c.weighty = 1.0; // as tall as possible
        gridbag.setConstraints(description, c);

    }

    // [PENDING: should stop this thread when applet is asked to stop]
    public synchronized void run() {
        // loop terminates when clockThread is set to null in stop()
        while (Thread.currentThread() == clockThread) {
            updateTime(currentLocale);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e){
            }
        }
    }

}
