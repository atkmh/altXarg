/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
/*
 * @(#)MessageFormatDemo.java	1.4 97/06/27
 *
 * (C) Copyright Taligent, Inc. 1996 - All Rights Reserved
 * (C) Copyright IBM Corp. 1996 - All Rights Reserved
 *
 * Portions copyright (c) 1996 Sun Microsystems, Inc. All Rights Reserved.
 *
 *   The original version of this source code and documentation is copyrighted
 * and owned by Taligent, Inc., a wholly-owned subsidiary of IBM. These
 * materials are provided under terms of a License Agreement between Taligent
 * and Sun. This technology is protected by multiple US and International
 * patents. This notice and attribution to Taligent may not be removed.
 *   Taligent is a registered trademark of Taligent, Inc.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

import java.applet.Applet;
import java.awt.*;
import java.lang.*;

import java.util.*;
import java.text.NumberFormat;
import java.text.MessageFormat;
import java.text.ChoiceFormat;
import java.text.SimpleDateFormat;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

/**
 * <P> Pattern formats are used to put together sequences of strings, numbers,
 * dates, and other formats to create messages.  The pattern formatters
 * facilitate localization because they prevent both hard-coding of message
 * strings, <I> and </I> hard-coding of the concatenation sequence for portions
 * of message strings.  This means localizers can change the content, format,
 * and order of any text as appropriate for any language.
 * </P>

 * @see        java.util.Format
 * @see        java.util.MessageFormat
 * @version    1.4 06/27/97
 * @author     Laura Werner, Mark Davis
*/

public class MessageFormatDemo extends DemoApplet
{
    /**
     * The main function which defines the behavior of the MessageFormatDemo
     * applet when an applet is started.
     */
    public static void main(String argv[]) {
        DemoApplet.showDemo(new MessageFormatFrame(null));
    }

    /**
     * This creates a MessageFormatFrame for the demo applet.
     */
    public Frame createDemoFrame(DemoApplet applet) {
        return new MessageFormatFrame(applet);
    }
}

/**
 * A Frame is a top-level window with a title. The default layout for a frame
 * is BorderLayout.  The MessageFormatFrame class defines the window layout of
 * MessageFormatDemo.
 */
 class MessageFormatFrame extends Frame implements ItemListener {

    /**
     * Constructs a new MessageFormatFrame that is initially invisible.
     */
    public MessageFormatFrame(DemoApplet applet)
    {
        super("Message Formatting Demo");
        this.applet = applet;
        init();

	// set up event handling
	MyKeyAdapter keyListener = new MyKeyAdapter();
        argText[0].addKeyListener(keyListener);
        argText[1].addKeyListener(keyListener);
        argText[2].addKeyListener(keyListener);
        patternText.addKeyListener(keyListener);

	localeMenu.addItemListener(this);

	addWindowListener(new MyWindowAdapter());

        start();
    }

    /**
     * Initializes the applet. You never need to call this directly, it
     * is called automatically by the system once the applet is created.
     */
    public void init() {

        //Get all locales for debugging, but only get G7 locales for demos.
        if (DEBUG == true)
             locales = NumberFormat.getAvailableLocales();
        else locales = Utility.getG7Locales();

        buildGUI();

    }

    /**
     * Called to start the applet. You never need to call this method
     * directly, it is called when the applet's document is visited.
     */
    public void start() {

        // Stick some initial data into the controls....
        argText[0].setText("3");
        argText[1].setText("MyDisk");
        argText[2].setText("3 Mar 96");

        patternText.setText("");
        resetFormat();
        doFormatting();
    }

    /**
     * Reset to the default message format using the ResourceBundle mechanism.
     * @see java.util.ResourceBundle
     * @see java.util.ListResourceBundle
     */
    public void resetFormat() {
        Locale locale = locales[localeMenu.getSelectedIndex()];

        ResourceBundle choiceResources =
             ResourceBundle.getBundle("ChoiceResource", locale);

	patternText.setText(choiceResources.getString("patternText"));
    }


    /**
     * Create a new format based on the selection changes and update the
     * output text area.
     */
    public void doFormatting() {

        // Now create the Message Formatter itself
        MessageFormat format = new MessageFormat(patternText.getText());

        format.setLocale(locales[localeMenu.getSelectedIndex()]);

        // Create the array of objects to format....
        Object[] objects = new Object[3];

        for(int i=0; i<objects.length; i++ ) {
             try {
                // Try parsing as a Date
                // LAURA Must do this first, because most dates start with
                // something that looks like a Double.

                // 1 millisecond is added to display the date correctly.
                // This is done to fix the following scenario, eg,
                // "27 Sept 96" ==> "26 Sept 96 12:00 AM PDT" which is
                // equvalent to "27 Sept 96 00:00 AM PDT".
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yy");
                objects[i]
                    = new Date((dateFormat.parse(argText[i].getText())).getTime()+1);
/*
                objects[i]
                    = new Date((new Date(argText[i].getText())).getTime()+1);
*/
            } catch( Exception e ) {
               try{
                    // Try parsing as a Double
                    objects[i] = new Double( argText[i].getText() );
                } catch( Exception e1 ) {
                    // If neither a Double or Date, assume its a String.
                    objects[i] = argText[i].getText();
                }
            }
        }

        String result = null;
        try {
            result = format.format(objects);
        }
        catch (Exception e)
        {
            errorText("format threw an exception: " + e.toString());
            result = "ERROR";
        }
        resultText.setText(result);
    }

    /**
     * Handles keyboard events for all text items
     */
    class MyKeyAdapter extends KeyAdapter {
        public void keyReleased(KeyEvent evt) {
	    if (evt.getSource() == argText[2])  {
		doFormattingEvent(evt);
	    } else if (evt.getSource() == argText[1])  {
		doFormattingEvent(evt);
	    } else if (evt.getSource() == argText[0])  {
		doFormattingEvent(evt);
	    } else if (evt.getSource() == patternText)  {
		doFormattingEvent(evt);
	    }
        }
    }

    /*
     * This method handles state changes that come from the locale menu
     */
    public void itemStateChanged(ItemEvent e) {
        resetFormat();
        doFormatting();
    }


    /**
     * Handles window events.
     */
    class MyWindowAdapter extends WindowAdapter {
	public void windowClosing(WindowEvent e) {
            setVisible(false);
            dispose();
            if (applet != null) {
                applet.demoClosed();
            } else
		System.exit(0);
	}
    }


    /**
     * Called when a formatting event has occured.
     */
    public void doFormattingEvent(KeyEvent event) {
        doFormatting();
    }

    //------------------------------------------------------------
    // package private
    //------------------------------------------------------------

    void addWithFont(Container container, Component foo, Font font) {
        if (font != null)
            foo.setFont(font);
        container.add(foo);
    }

    //{{DECLARE_CONTROLS

    Label demoTitle;
    Label creditLabel;

    TextArea resultText;
    TextArea patternText;

    Choice localeMenu;
    Label localeLabel;

    TextField[] argText = new TextField[3];
    //}}

    //------------------------------------------------------------
    // private
    //------------------------------------------------------------
    private void buildGUI() {

        //{{INIT_CONTROLS
        setLayout(new FlowLayout(FlowLayout.CENTER,2,2));
        setBackground(Utility.bgColor);

        // Main Title

        Panel titleCreditPanel = new Panel();
        demoTitle=new Label("Message Format Demo", Label.CENTER);
        demoTitle.setFont(Utility.titleFont);
        titleCreditPanel.add(demoTitle);

        Panel creditPanel = new Panel();
        creditLabel=new Label(creditString);
        creditLabel.setFont(Utility.creditFont);
        creditPanel.add(creditLabel);

        titleCreditPanel.add(creditPanel);

        Utility.fixGrid(titleCreditPanel,1);

        // result text

        Panel patternResultPanel = new Panel();

        addWithFont(patternResultPanel,new
            Label("Result", Label.RIGHT),Utility.labelFont);
        addWithFont(patternResultPanel,resultText= new
            TextArea(FIELD_ROWS, FIELD_COLUMNS),Utility.editFont);
	    resultText.setEditable(false);
//            resultText.setBackground(Color.white);

        addWithFont(patternResultPanel,new
            Label("Pattern", Label.RIGHT),Utility.labelFont);
        addWithFont(patternResultPanel,patternText=new
            TextArea(FIELD_ROWS, FIELD_COLUMNS),Utility.editFont);

        Utility.fixGrid(patternResultPanel,2);

        // Locale and Credits Panel

        Panel localeCreditPanel = new Panel();

        localeLabel=new Label("Locale:",Label.LEFT);
        localeLabel.setFont(Utility.labelFont);

        // LOCALE
        localeMenu= new Choice();
        localeMenu.setBackground(Utility.choiceColor);
        // Stick the names of the locales into the locale popup menu
        Locale displayLocale = Locale.getDefault();
        for (int i = 0; i < locales.length; i++) {
            if (locales[i].getCountry().length() > 0) {
                localeMenu.addItem( locales[i].getDisplayName(displayLocale) );
            }
        }
       localeMenu.setFont(Utility.choiceFont);
       localeMenu.select(Locale.US.getDisplayName());

        Panel localePanel=new Panel();
        localePanel.add(localeLabel);
        localePanel.add(localeMenu);
        localeCreditPanel.add(localePanel);

        // PUT THE ARGUMENTS/ FORMATS into GRID
        Panel allArgs = new Panel();

        addWithFont(allArgs,new Label(" "),Utility.labelFont);
        addWithFont(allArgs,new Label("Arguments", Label.LEFT),
                                      Utility.labelFont);
        addWithFont(allArgs,new Label("0",Label.RIGHT),Utility.labelFont);
        addWithFont(allArgs,argText[0]=new TextField(12),Utility.editFont);
        addWithFont(allArgs,new Label("1",Label.RIGHT),Utility.labelFont);
        addWithFont(allArgs,argText[1]=new TextField(12),Utility.editFont);
        addWithFont(allArgs,new Label("2",Label.RIGHT),Utility.labelFont);
        addWithFont(allArgs,argText[2]=new TextField(12),Utility.editFont);

        Utility.fixGrid(allArgs,2);

        add(titleCreditPanel);
        add(patternResultPanel);
        add(localeCreditPanel);
        Panel bottomPanel = new Panel();
        bottomPanel.add(allArgs);

//        Utility.fixGrid(bottomPanel,5);
//        Utility.setInsets(bottomPanel,x,new Insets(20,20,2,2));
//        Utility.setInsets(bottomPanel,x1,new Insets(20,20,2,20));

        add(bottomPanel);

        Panel copyrightPanel = new Panel();
        addWithFont (copyrightPanel,new Label(Utility.copyright1, Label.LEFT),
                     Utility.creditFont);
        addWithFont (copyrightPanel,new Label(Utility.copyright2, Label.LEFT),
                     Utility.creditFont);
        Utility.fixGrid(copyrightPanel,1);
        add(copyrightPanel);
    }

    private void errorText(String s)
    {
        if (DEBUG)
        {
           System.out.println(s);

        }
    }
    private static final String creditString =
        "v2.0, Demos";
    private static final int FIELD_COLUMNS = 50;
    private static final int FIELD_ROWS = 4;

    static private final int NUMBER = 0;
    static private final int DATE = 1;
    static private final int CHOICE = 2;
    static private final int NONE = 3;

    private static final boolean DEBUG = false;

    private Locale[] locales;

    private ChoiceFormat choiceFormat;    // XXX

    //------------------------------------------------------------
    // protected
    //------------------------------------------------------------

    /* this must be protected so that the window adapter can access it */
    protected DemoApplet applet;
}
