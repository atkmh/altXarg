/*
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
/* ************************************************************* */
/* (C) Copyright Taligent, Inc. 1996-All Rights Reserved.        */
/* (C) Copyright IBM Corporation 1996                            */
/*                                                               */
/* Permission is granted to copy, use, modify, and merge this    */
/* software into your applications  and to permit others to do 	 */
/* any of the foregoing. You must include this permission and 	 */
/* copyright notice in all copies and modified versions of this  */
/* software, and include attribution to Taligent in all splash 	 */
/* screens included in any application using this software. 	 */
/* THIS SOFTWARE IS PROVIDED IN ITS 'AS IS' CONDITION. TALIGENT  */
/* DISCLAIMS ANY LIABILITY OF ANY KIND FOR DAMAGES WHATSOEVER 	 */
/* RESULTING FROM THE USE OF THIS SOFTWARE.					     */
/* ************************************************************* */

import java.awt.*;
import java.util.Vector;

/**
 * Tabbed panel. Displays a series of cards that are selected
 * by clicking on the various tabs displayed on the panel.
 * Tabs can be arranged on the top, bottom, or either side of
 * the tabbed panel.
 *
 * @author  Andy Clark, Taligent Inc.
 * @version 1.0
 */
public class TabPanel
    extends Panel
    {
    // Constants
    final static int TOP    = 0;
    final static int BOTTOM = 1;
    final static int LEFT   = 2;
    final static int RIGHT  = 3;

    final static int DEFAULT_PLACEMENT = TOP;

    // Data
    TabCanvas tabcanvas;
    BorderPanel display;
    int style = TOP;
    Font font;

    /**
     * Constructor.
     */
    public TabPanel() {

        // setup display
        setLayout(new BorderLayout());
        display = new BorderPanel(BorderPanel.RAISED, 2);
        display.setLayout(new CardLayout());

        super.add("Center", display);
        tabcanvas = new TabCanvas(display);

        setPlacement(DEFAULT_PLACEMENT);
        }

    public boolean didCardChange() {
        return tabcanvas.cardChanged;
    }

    /**
     * Sets the placement of the tabs.
     *
     * @param placement Where to place the tabs.
     */
    public TabPanel setPlacement(int placement) {

        // remove old canvas from layout and then readd in new position
        remove(tabcanvas);
        switch (placement) {
            case BOTTOM: super.add("South", tabcanvas); break;
            case LEFT: super.add("West", tabcanvas); break;
            case RIGHT: super.add("East", tabcanvas); break;
            case TOP:
            default: // assume top if invalid
                super.add("North", tabcanvas); break;
            }

        return this;
        }

    /**
     * Add a panel to the deck of tabbed panels.
     *
     * @param label The tab label
     * @param comp  The component to add.
     */
    public Component add(String label, Component comp) {

        tabcanvas.add(label, comp);
        return display.add(label, comp);
        }

    /**
     * Paints the panel. First paints the raised border that we
     * inherited and then paints in the tabs.
     */
    public void paint(Graphics g) {

        // draw border
        super.paint(g);

        // draw tabs
        }

    }

class TabCanvas
    extends Canvas
    {
    public BorderPanel display;
    public boolean cardChanged = false;

    public Vector tabs = null;

    public int selected = -1;
    /**
     * Constructor.
     *
     * @param display   The display panel.
     */
    public TabCanvas(BorderPanel display) {

        // init data
        this.display = display;
        tabs = new Vector();
        }

    /**
     * Returns the minimum size of the tabs.
     */
    public Dimension getPreferredSize() { return getMinimumSize(); }
    public Dimension getMinimumSize() {

        return new Dimension(0, getGraphics().getFontMetrics().getHeight() + 4 * display.getThickness());
        }

    /**
     * Adds a tab.
     *
     * @param name  The tab caption.
     * @param comp  The component this tab is connected to.
     */
    public void add(String name, Component comp) {
        Tab tab = new Tab();
        tab.name = name;
        tab.comp = comp;
        tab.selected = tabs.size() < 1;

        tabs.addElement(tab);
        }

    /**
     * Paint the tabs.
     *
     * @param g The graphics context.
     */
    public void paint(Graphics g) {

        // calculate size, colors, etc.
        Dimension size = getSize();
        Color light = getBackground().brighter().brighter().brighter();
        Color dark = getBackground().darker().darker().darker();
        int thickness = display.getThickness();
        int offset = 5;

        //
        // Draw tabs
        //

        // redraw upper border
        Graphics displayg = display.getGraphics();
        displayg.setColor(light);
        for (int i = 0; i < thickness; i++)
            displayg.drawLine(i, i, size.width - i - 1, i);

        // set font
        Font oldfont = g.getFont();
        oldfont = new Font(oldfont.getName(),
                           oldfont.getStyle() & ~Font.BOLD,
                           oldfont.getSize());
        Font font = new Font(oldfont.getName(), oldfont.getStyle() | Font.BOLD, oldfont.getSize());
        FontMetrics fm;

        // draw each tab
        for (int index = 0; index < tabs.size(); index++) {
            Tab tab = (Tab)tabs.elementAt(index);

            g.setFont(oldfont);
            fm = g.getFontMetrics(oldfont);
            int strwidth = fm.stringWidth(tab.name);
            if (tab.selected) {
                g.setFont(font);
                fm = g.getFontMetrics(font);
                strwidth = fm.stringWidth(tab.name);
                displayg.setColor(getBackground());
                displayg.fillRect(offset + thickness, 0, strwidth + 10 - 2 * thickness + 1, thickness);
                }
            int adjustment = tab.selected ? 0 : thickness;
            for (int i = 0; i < thickness; i++) {
                g.setColor(light);
                g.drawLine(offset + i, i + adjustment, offset + strwidth + 10 - i, i + adjustment);
                g.drawLine(offset + i, i + 1, offset + i, size.height - 1);
                g.setColor(dark);
                g.drawLine(offset - i + strwidth + 10, i + 1, offset - i + strwidth + 10, size.height - 1);
                }
            displayg.setColor(dark);
            g.setColor(Color.black);
            g.drawString(tab.name, offset + 5, thickness + adjustment + fm.getAscent());

            tab.bounds = new Rectangle(offset, 0, strwidth + 10, size.height);

            offset += strwidth + 10 + thickness;
            }

        }

    /**
     * Event handler.
     *
     * @param evt   The event that occured.
     */
    public boolean handleEvent(Event evt) {

        // see where they clicked
        if (evt.id == Event.MOUSE_UP) {
            for (int index = 0; index < tabs.size(); index++) {
                Tab tab = (Tab)tabs.elementAt(index);
                if (tab.bounds.contains(evt.x, evt.y)) {
                    for (int i = 0; i < tabs.size(); i++)
                        ((Tab)tabs.elementAt(i)).selected = false;
                    tab.selected = true;
                    ((CardLayout)display.getLayout()).show(display, tab.name);
                    repaint();
                    cardChanged = true;
                    }
                }
            }else if(cardChanged == true) cardChanged = false;

        return super.handleEvent(evt);
        }

    }

class Tab
    extends Object
    {
    public Component comp = null;
    public String name = "";
    public boolean selected = false;
    public Rectangle bounds = new Rectangle();
    }
