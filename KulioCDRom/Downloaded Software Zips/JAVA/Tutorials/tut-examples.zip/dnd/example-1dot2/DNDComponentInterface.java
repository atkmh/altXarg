public interface DNDComponentInterface{
    
 public void addElement( Object s);
 public void removeElement();
   
}
