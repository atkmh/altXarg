/*
 * This example has no 1.0 equivalent. You can
 * find the 1.1 version in ../example-1dot1/MulticastServer.java.
 */
