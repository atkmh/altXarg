/*
 * File: ./HelloApp/Hello.java
 * From: Hello.idl
 * Date: Thu Sep  3 09:46:22 1998
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package HelloApp;
public interface Hello
    extends org.omg.CORBA.Object {
    String sayHello()
;
}
