public class EnumerateMain {
    public static void main(String[] args) {
        new EnumerateTest().listCurrentThreads();
    }
}
