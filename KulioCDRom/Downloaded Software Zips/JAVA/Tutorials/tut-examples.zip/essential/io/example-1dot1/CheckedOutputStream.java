/* 
 * This example requires no changes from the 1.0 version.  You can
 * find the 1.0 version in ../example/CheckedOutputStream.java.
 */
