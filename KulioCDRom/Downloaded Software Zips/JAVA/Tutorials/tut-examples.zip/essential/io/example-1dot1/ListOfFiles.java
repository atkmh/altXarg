/*
 * This file is part of the Concatenate example which
 * can only be implemented with a SequenceInputStream.
 * You can find the 1.0 version in ../example/ListOfFiles.java.
 */
