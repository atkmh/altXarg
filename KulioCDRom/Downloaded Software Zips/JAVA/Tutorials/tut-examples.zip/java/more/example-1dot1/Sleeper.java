public interface Sleeper {
    public void wakeUp();

    public long ONE_SECOND = 1000;	// in milliseconds
    public long ONE_MINUTE = 60000;	// in milliseconds
}
