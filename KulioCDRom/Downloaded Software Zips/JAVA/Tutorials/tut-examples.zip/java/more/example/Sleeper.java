public interface Sleeper {
    public void wakeUp();

    long ONE_SECOND = 1000;	// in milliseconds
    long ONE_MINUTE = 60000;	// in milliseconds
}
