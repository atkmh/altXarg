/**
  * This applet is the same in 1.1 as in 1.0.  To see the 1.0 version
  * of this applet, go to ../example/GetOpenProperties.java.
  */
