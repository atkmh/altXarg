class ParseException extends Exception {
    ParseException(String s) {
	super(s);
    }
}
