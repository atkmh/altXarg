/* 
 * This example has not changed since 1.0.  You can find the 1.0 version
 * in ../example/ScrollingSimple.java
 */
