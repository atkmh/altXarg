/*
 * The JDK does not have a comparable Reader class
 * for SequenceInputStream. So this example can only
 * be implemented with a SequenceInputStream. You can
 * find the 1.0 version in ../example/Concatenate.java.
 */
