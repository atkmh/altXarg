public class DisplaySystemProps {
    public static void main(String[] args) {
	System.getProperties().list(System.out);
    }
}
