/****
 * ABTWrapper.cpp
 *
 * Code for simple java wrappers
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */

#include <windows.h>
#include <string.h>

#include <jni.h>

#include "ABTWrapper.h"

ABTWrapper::ABTWrapper(char *mainClass, char *classPath = NULL, char *jrePath = NULL)
{
	mainClass_ = mainClass;
	options_ = new JavaVMOption[MAX_OPTIONS];
	argCount_ = 0;


	// Build the classpath
	char *buf1 = new char[1024];
	char *cp = getenv("CLASSPATH");
	sprintf(buf1, "-Djava.class.path=%s;%s", classPath != 0 ? classPath : "", cp != 0 ? cp : "");
	addVMOption(buf1);

	// Build the path
	char *buf2 = new char[1024];
	cp = getenv("PATH");
	sprintf(buf2, "-Djava.library.path=%s;%s", jrePath != 0 ? jrePath : "", cp != 0 ? cp : "");
	addVMOption(buf2);
}

void ABTWrapper::addVMOption(char *option)
{
	if (argCount_ < MAX_OPTIONS)
	{
		options_[argCount_].optionString = option;
		options_[argCount_++].extraInfo = NULL;
	}
	else
	{
		char *errorStr = "Couldn't add more options. Increase MAX_OPTIONS in ABTWrapper.h";
		MessageBox(NULL, errorStr, mainClass_, MB_OK | MB_ICONERROR);
	}
}

