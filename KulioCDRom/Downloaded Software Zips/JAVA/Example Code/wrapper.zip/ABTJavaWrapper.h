/* ABTJavaWrapper.h
 *
 * Gets values from the registry to start the Java VM
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */

#include <windows.h>
#include <jni.h>

#include "ABTRegistryValues.h"
#include "ABTBaseWrapper.h"

class ABTJavaWrapper : public ABTBaseWrapper
{
public:
	ABTJavaWrapper(char *productName);
	~ABTJavaWrapper();

	ABTRegistryValues *getRegistryValues()		{ return registry_; }

protected:
	ABTRegistryValues *registry_;

	LPCSTR getMainClass()						{ return registry_->getMainClass(); }
	JavaVMOption *getVMArgs()					{ return registry_->getVMArgs(); }
	int getVMArgsCount()						{ return registry_->getVMArgsCount(); }
};