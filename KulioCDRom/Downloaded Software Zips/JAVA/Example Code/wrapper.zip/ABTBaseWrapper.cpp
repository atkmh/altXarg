/****
 * ABTBaseWrapper.cpp
 *
 * This class is responsible for the following:
 * 1. Loading the Java DLL
 * 2. Setting variables for the Java Run Time Environment
 * 3. Creating the Java VM
 * 4. Loading the main class
 * 5. Building the array of arguments to pass to the main class
 * 6. Invoking the main method in main.class
 * 7. Destroying the VM
 *
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
*/

#include <windows.h>
#include <stdio.h>
#include <string.h>

#include <jni.h>

#include "ABTBaseWrapper.h"

// Function prototypes for the JNI functions needed from the java dll
typedef jint (JNICALL *JNI_CREATEJAVAVM)(JavaVM **, JNIEnv **, void *);
JNI_CREATEJAVAVM  CreateJavaVM;


ABTBaseWrapper::ABTBaseWrapper() : vmPtr(NULL)
{
}

/*
 * Invoke Java runtime.
 *
 * Returns an error string or NULL if no errors
 */
LPCSTR ABTBaseWrapper::run(int argc, char *argv[])
{
	LPCSTR errorStr = NULL;

	if (LoadJavaDLL())
	{
		// Create the VM
		if (createVM())
		{
			// Find the main class
			jclass mainClass = env->FindClass(getMainClass());
			if (mainClass)
			{
				// Find the main method
				jmethodID mID = env->GetStaticMethodID(mainClass, "main", "([Ljava/lang/String;)V");
				if (mID)
				{
					// Create the argument lists
					jobjectArray jargs = createArgList(argc, argv);
					// Invoke the main method
					env->CallStaticVoidMethod(mainClass, mID, jargs);
				}
				else errorStr = "Could not find main method";
			}
			else errorStr = "Could not find main class";

			vmPtr->DestroyJavaVM();
		}
		else  errorStr = "Could not create the Java Virtual Machine";

		FreeLibrary(hmod);
	}
	else errorStr = "Java DLL not found or invalid";

	return errorStr;
}

// Fills in JavaVMInitArgs struct and creates VM
bool ABTBaseWrapper::createVM()
{
	// IMPORTANT: specify vm_args version # if you use JDK1.1.2 and beyond
	vm_args.version = JNI_VERSION_1_2;
	vm_args.options = getVMArgs();
	vm_args.nOptions = getVMArgsCount();
	vm_args.ignoreUnrecognized = TRUE;
	
	return CreateJavaVM(&vmPtr, &env, &vm_args) == 0;
}
					
/*
* Create the String array of arguments for the main method
* argc and argv are standard dos-style with first argument being program name
*/
jobjectArray ABTBaseWrapper::createArgList(int argc, char *argv[])
{
	jclass strClass = env->FindClass("java/lang/String");
	jobjectArray jargs = env->NewObjectArray(argc-1, strClass, 0);
	
	// Skip the first arg (program name)
	for(int j = 1; j < argc; j++)
	{
		jstring str = env->NewStringUTF(argv[j]);
		env->SetObjectArrayElement(jargs, j-1, str);
	}

	return jargs;
}

// Loads java dll and gets function addresses
bool ABTBaseWrapper::LoadJavaDLL()
{
	bool loaded = false;

	hmod = LoadLibrary(JAVA_DLL);
	
	if (IsModuleValid(hmod)) {
		CreateJavaVM = (JNI_CREATEJAVAVM)GetProcAddress(hmod, "JNI_CreateJavaVM");
		if (CreateJavaVM != NULL) loaded = true;  
	}
	
	return loaded;
}
