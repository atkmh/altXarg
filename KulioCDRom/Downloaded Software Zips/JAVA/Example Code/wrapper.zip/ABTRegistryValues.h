/* ABTRegistryValues.h
 * 
 * Class for extracting imformation from the windows registry for ABT specific
 * java products.
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */

#include "windows.h"
#include <jni.h>

#define MEGA_BYTE	1024000  // 1000K
#define KILO_BYTE	1024     // 1K

static LPCSTR COMPANY_KEY		= "SOFTWARE\\ABT Corporation\\";
static LPTSTR JAVA_KEY			= "Java";
static LPCSTR JRE_PATH_KEY		= "JRE path";
static LPCSTR CLASSPATH_KEY		= "classpath";
static LPCSTR MAIN_CLASS_KEY	= "main";
static LPCSTR VM_ARGS_KEY		= "VM arguments";

class ABTRegistryValues
{
public:
	ABTRegistryValues(char *productName);
	~ABTRegistryValues();

	// Predefined convenience methods for accessing registry values
	LPCSTR	getProductName()				{ return name_; }
	LPCSTR	getJREPath();
	char *	getClasspath();
	LPCSTR	getMainClass()					{ return getRegistryValue(mainKey_, MAIN_CLASS_KEY); }
	LPTSTR	getVMArgsString();

	// Allows user access to other values in the product's registry section
	char *getRegistryValue(LPCSTR key)		{ return getRegistryValue(mainKey_, key); }
	
	JavaVMOption* getVMArgs();
	int getVMArgsCount()					{ return argCount_; }

protected:
	// Product name
	char *name_;
	// Array of options for JavaVMInitArgs 
	JavaVMOption *vmArgs_;
	// Numner of options
	int argCount_;
	// environment
	LPTSTR jrePath_;
	LPTSTR classpath_;
	// VM args from registry
	LPTSTR args_;
	
	bool openRegistry();
	char *getRegistryValue(HKEY hkey, LPCSTR key);

private:
	HKEY mainKey_;
	HKEY javaKey_;

	void parseVMArgs(char *args);
	void addOption(char *option);
	int  getTokenCount(char *args);
};