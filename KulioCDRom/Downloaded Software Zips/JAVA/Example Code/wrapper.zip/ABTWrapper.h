/****
 * ABTWrapper.h
 *
 * Code for simple java wrappers
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */


#include <windows.h>
#include <jni.h>

#include "ABTBaseWrapper.h"

// This determines how many VM options you can have
// It should be dynamic but this isn't Java you know!
static int MAX_OPTIONS = 6;

class ABTWrapper : public ABTBaseWrapper
{
public:
	ABTWrapper(char *mainClass, char *classPath, char *jrePath);
	~ABTWrapper()				{ if (options_) delete options_; }

	// Add options to the vm arguments
	void addVMOption(char *option);

protected:
	LPCSTR mainClass_;
	JavaVMOption *options_;
	int argCount_;

	LPCSTR getMainClass()		{ return mainClass_; }
	JavaVMOption *getVMArgs()	{ return options_;  }
	int getVMArgsCount()		{ return argCount_; }
};