/* 
 * Java wrapper for YOUR_PRODUCT_NAME_HERE
 *
 * This is for a Windows console application
 */

#include "ABTJavaWrapper.h"

/*
 * Change the product name to the key used in the registry for your product
 */
static char *PRODUCT_NAME = "YOUR_PRODUCT_REGISTRY_KEY";

void main(int argc, char *argv[])
{
	/*
	 * First instanciate an ABTJavaWrapper object
	 */
	printf("Initializing...\n\n");
	ABTJavaWrapper *wrapper = new ABTJavaWrapper(PRODUCT_NAME);

	// If you want to access values from the registry do it this way
	printf("%s\n", wrapper->getRegistryValues()->getClasspath());
	printf("%s\n", wrapper->getRegistryValues()->getJREPath());

	/*
	 * To start the java vm call the run method of the wrapper along with the arguments.
	 * If you have default arguments to pass to the main class add it to the argv array
	 * before calling run.
	 */
	printf("\nRunning %s\n\n", PRODUCT_NAME);
	wrapper->run(argc, argv);

	// Don't forget to delete the wrapper
	printf("Cleaning up\n");
	delete wrapper;

	printf("%s finished\n", PRODUCT_NAME);
}