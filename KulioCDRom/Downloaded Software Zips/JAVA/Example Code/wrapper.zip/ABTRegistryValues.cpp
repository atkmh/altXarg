/* ABTRegistryValues.cpp
 * 
 * Class for extracting imformation from the windows registry for ABT specific
 * java products.
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */

#include "ABTRegistryValues.h"
#include <winreg.h>

// productName = Name of the ABT product to get registry values for
ABTRegistryValues::ABTRegistryValues(char *productName) : name_(productName), vmArgs_(NULL), jrePath_(NULL),
			classpath_(NULL), args_(NULL), argCount_(0)
{
	openRegistry();
}

ABTRegistryValues::~ABTRegistryValues()
{
	RegCloseKey(mainKey_);
	RegCloseKey(javaKey_);
	if (classpath_) delete [] classpath_;
	if (jrePath_) delete [] jrePath_;
	if (args_) delete [] args_;
	if (vmArgs_) delete [] vmArgs_;
}

// Open the registry associated with the product key and common abt java settings
bool ABTRegistryValues::openRegistry()
{
	DWORD res;
	char subKey[1024];

	// Open the product registry
	strcpy(subKey, COMPANY_KEY);
	strcat(subKey, name_);
	long retval = RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, name_, REG_OPTION_NON_VOLATILE,
									KEY_ALL_ACCESS, NULL, &mainKey_, &res);
	// Open the ABT Java registry
	strcpy(subKey, COMPANY_KEY);
	strcat(subKey, JAVA_KEY);
	retval |= RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, JAVA_KEY, REG_OPTION_NON_VOLATILE,
									KEY_ALL_ACCESS, NULL, &javaKey_, &res);
   
	return retval == ERROR_SUCCESS;
}

// Returns the string value associated with the key for the specified section
char *ABTRegistryValues::getRegistryValue(HKEY hkey, LPCSTR key)
{
	long retval;
	char *value = NULL;
	char valuebuf[1024] = "";
	unsigned long valuelen = 1024;
	unsigned long typevar = REG_SZ;

	// Get the value if it exists
	retval = RegQueryValueEx(hkey, key, NULL, &typevar, (unsigned char *)&valuebuf, &valuelen);
	if (retval == ERROR_SUCCESS)
	{
		value = strdup(valuebuf);
	}

	return value;
}

/*
 * Returns the PATH environment variable in the form:
 * "[<product\JRE path | java\JRE path>;][<existing path>]"
 *
 * First checks product registry then abtjava registry and appends environment path
 */
LPCSTR ABTRegistryValues::getJREPath()
{
	if (jrePath_ == NULL)
	{
		jrePath_ = new char[1024];
		// Use one of the paths from registry
		char *cp = getRegistryValue(mainKey_, JRE_PATH_KEY);
		if (cp == NULL || cp[0] == '\0') cp = getRegistryValue(javaKey_, JRE_PATH_KEY);

		// build path from environment
		char *ecp = getenv("PATH");
		sprintf(jrePath_, "%s;%s", cp != 0 ? cp : ".", ecp != 0 ? ecp : ".");
	}

	return jrePath_;
}

/*
 * Returns the CLASSPATH environment variable in the form:
 * "[<product\classpath>;][<java\classpath>;][<existing path>]"
 *
 * First gets product classpath then appends abtjava classpath and environment classpath
 */
char *ABTRegistryValues::getClasspath()
{
	if (classpath_ == NULL)
	{
		classpath_ = new char[1024];
		// Build the classpath
		char *cp1 = getRegistryValue(mainKey_, CLASSPATH_KEY);
		char *cp2 = getRegistryValue(javaKey_, CLASSPATH_KEY);
		char *ecp = getenv("CLASSPATH");
		sprintf(classpath_, "%s;%s;%s", cp1 != 0 ? cp1 : ".", cp2 != 0 ? cp2 : ".", ecp != 0 ? ecp : ".");
	}
	
	return classpath_;
}

/*
 * Returns the VM arguments string which isn't really useful until parsed into an
 * JDK1_1InitArgs structure via parseVMArgs().
 *
 * "[<java\VM arguments>] [<product\VM arguments>]"
 *
 * First gets abtjava vm args then appends the vm args for product
 */
LPTSTR ABTRegistryValues::getVMArgsString()
{
	if (args_ == NULL)
	{
		args_ = new char[1024];
		// Build the vm args list
		char *cp1 = getRegistryValue(javaKey_, VM_ARGS_KEY);
		char *cp2 = getRegistryValue(mainKey_, VM_ARGS_KEY);
		sprintf(args_, "%s %s", cp1 != 0 ? cp1 : "", cp2 != 0 ? cp2 : "");
	}

	return args_;
}

/*
 * Returns an array of JavaVMOption to be added to a JavaVMInitArgs struct
 */
JavaVMOption *ABTRegistryValues::getVMArgs()
{
	if (vmArgs_ == NULL) parseVMArgs(getVMArgsString());
	return vmArgs_;
}

/*
 * Parses the vm args and puts them into the JavaVMOption array
 */
void ABTRegistryValues::parseVMArgs(char *args)
{
	argCount_ = 0;
	int tokenCount = 2 + getTokenCount(args);
	// create an array of options
	if (vmArgs_ == NULL) vmArgs_ = new JavaVMOption[tokenCount];

	// Add classpath
	char *cp = new char[1024];
	sprintf(cp, "-Djava.class.path=%s", getClasspath());
	addOption(cp);

	// Add path
	cp = new char[1024];
	sprintf(cp, "-Djava.library.path=%s", getJREPath());
	addOption(cp);
	
	// Parse out tokens and add to array
	char *token = strtok(args, " ");
	while (token)
	{
		addOption(token);
		token = strtok(NULL, " ");
	}
}

// Should only be called from parseVMArgs to initialize JavaVMOption struct
void ABTRegistryValues::addOption(char *option)
{
	vmArgs_[argCount_].optionString = option;
	vmArgs_[argCount_++].extraInfo = NULL;
}

// Should only be called from parseVMArgs to determine number of tokens in args registry value
int ABTRegistryValues::getTokenCount(char *args)
{
	int cnt = 0;
	char *token = strtok(args, " ");
	while (token)
	{
		cnt++;
		token = strtok(NULL, " ");
	}
	return cnt;
}