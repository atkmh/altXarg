/* 
 * Java wrapper for YOUR_PRODUCT_NAME_HERE
 */

#include "ABTJavaWrapper.h"

/*
 * Change the product name to the key used in the registry for your product
 */
static char *PRODUCT_NAME = "ErrorApp";

/* Takes one argument; the directory of where the config file resides.
 * If no directory is specified the directory from where this app was started is used.
 */
#ifdef _CONSOLE
void main(int argc, char *argv[])
{
	/*
	 * First instanciate an ABTJavaWrapper object
	 */
	printf("Initializing...\n\n");
	ABTJavaWrapper *wrapper = new ABTJavaWrapper(PRODUCT_NAME);

	// If you want to access values from the registry do it this way
	printf("%s\n", wrapper->getRegistryValues()->getClasspath());
	printf("\n");
	printf("%s\n", wrapper->getRegistryValues()->getJREPath());

	/*
	 * To start the java vm call the run method of the wrapper along with the arguments.
	 * If you have default arguments to pass to the main class add it to the argv array
	 * before calling run.
	 */
	printf("\nRunning %s\n\n", PRODUCT_NAME);
	wrapper->run(argc, argv);

	// Don't forget to delete the wrapper
	printf("Cleaning up\n");
	delete wrapper;

	printf("%s finished\n", PRODUCT_NAME);
}
#endif

#ifdef _WINDOWS

/*
 * Maximum number of arguments from command line
 */
#define MAX_ARGS 16

int argc;
char *argv[MAX_ARGS];

void parseCmdLine(LPSTR lpszCmdLine);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR lpszCmdLine, int nCmdShow)
{
	//parseCmdLine(lpszCmdLine);
	parseCmdLine("-log plannerlog.txt");

	ABTJavaWrapper *wrapper = new ABTJavaWrapper(PRODUCT_NAME);

	LPCSTR errorStr = wrapper->run(argc, argv);
	if (errorStr) MessageBox(NULL, errorStr, PRODUCT_NAME, MB_OK | MB_ICONERROR);

	delete wrapper;

	return(0);
}

/*
 * Parses command line into argc and argv
 */
void parseCmdLine(LPSTR lpszCmdLine)
{
	argc = 1;
	// Windows does not send program name as first argument so use the product name
	argv[0] = PRODUCT_NAME;

	char *token = strtok(lpszCmdLine, " ");
    // While there are tokens in "lpszCmdLine"
	while (token != NULL && argc < MAX_ARGS)   
	{
		argv[argc++] = token;
		// Get next token
		token = strtok(NULL, " ");
	}
}
#endif
