/* 
 * Java wrapper for YOUR_PRODUCT_NAME_HERE
 * 
 * This is a win32 application java wrapper which displays no window.
 * It just starts the javaVM and runs your java code.
 *
 * Note: To make the executable much smaller select Multithreaded DLL from
 * Project settings : C/C++ : Code Generation : Use run-time library
 */

#include <windows.h>
#include "ABTJavaWrapper.h"

/*
 * Change the product name to the key used in the registry for your product
 */
static char *PRODUCT_NAME = "YOUR_PRODUCT_REGISTRY_KEY";

/*
 * Maximum number of arguments from command line
 */
#define MAX_ARGS 16

int argc;
char *argv[MAX_ARGS];

void parseCmdLine(LPSTR lpszCmdLine);

/*
 * Entry point from Windows
 */
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
									 LPSTR lpszCmdLine, int cmdShow)
{
	parseCmdLine(lpszCmdLine);

	ABTJavaWrapper *wrapper = new ABTJavaWrapper(PRODUCT_NAME);

	LPCSTR errorStr = wrapper->run(argc, argv);
	if (errorStr) MessageBox(NULL, errorStr, PRODUCT_NAME, MB_OK | MB_ICONERROR);

	delete wrapper;

	return(0);
}

/*
 * Parses command line into argc and argv
 */
void parseCmdLine(LPSTR lpszCmdLine)
{
	argc = 1;
	// Windows does not send program name as first argument so use the product name
	argv[0] = MAIN_CLASS;

	char *token = strtok(lpszCmdLine, " ");
    // While there are tokens in "lpszCmdLine"
	while (token != NULL && argc < MAX_ARGS)   
	{
		// If user double-clicked a file that was associated with this app, there will be quotes
		if (token[0] == '\"')
		{
			// Remove the quotes from the token
			token++;
			int i = 0;
			while (token[i] != ' ' && token[i] != '\0')
			{
				if (token[i] == '\"') token[i] = '\0';
				else i++;
			}
		}

		argv[argc++] = token;
		// Get next token
		token = strtok(NULL, " ");
	}
}