/****
 * ABTJavaWrapper.cpp
 *
 * Gets values from the registry to start the Java VM
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */

#include <windows.h>
#include <string.h>

#include <jni.h>

#include "ABTJavaWrapper.h"

ABTJavaWrapper::ABTJavaWrapper(char *productName)
{
	registry_ = new ABTRegistryValues(productName);
	
	// set CLASSPATH.
	//putenv(registry_->getClasspath());
	// set PATH
	char s[1024];
	sprintf(s, "PATH=%s", registry_->getJREPath());
	putenv(s);
}

ABTJavaWrapper::~ABTJavaWrapper()
{
	delete registry_;
}

