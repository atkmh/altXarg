/* ABTBaseWrapper.h
 *
 * Abstract base class for all java executable wrappers
 *
 * Author: Jody Gustafson
 *
 * Version: 1.2
 */

#include <windows.h>
#include <jni.h>

#define JAVA_DLL "JVM.DLL"

class ABTBaseWrapper
{
public:
	ABTBaseWrapper();

	LPCSTR run(int argc, char *argv[]);

protected:
	JavaVM *vmPtr;			// The Java VM pointer
	JNIEnv *env;			// The Java Environment pointer
	JavaVMInitArgs vm_args; // The VM arguments
	HMODULE hmod;			// Pointer to dll module

	/*
	 * Abstract methods, must be defined in child classes
	 *
	 */
	// Return the name of the java class containing the main() method
	virtual LPCSTR getMainClass() = 0;
	// Return an array of additional VM arguments
	virtual JavaVMOption *getVMArgs() = 0;
	// Return the number of VM arguments in the array
	virtual int getVMArgsCount() = 0;

	/*
	 * Base methods
	 */
	virtual bool createVM();
	virtual jobjectArray createArgList(int argc, char *argv[]);
	virtual bool LoadJavaDLL();

private:
	bool IsModuleValid(HINSTANCE m)				{ return ((UINT)m) > HINSTANCE_ERROR; }
};