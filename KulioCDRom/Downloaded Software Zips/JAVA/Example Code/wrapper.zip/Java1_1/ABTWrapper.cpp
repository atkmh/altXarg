/****
 * ABTWrapper.cpp
 *
 */

#include <windows.h>
#include <string.h>

#include <jni.h>

#include "ABTWrapper.h"

ABTWrapper::ABTWrapper(char *mainClass, char *classPath = NULL, char *jrePath = NULL)
{
	mainClass_ = mainClass;

	char buf[1024];
	char *cp;
	if (classPath) // Build the classpath
	{
		cp = getenv("CLASSPATH");
		sprintf(buf, "CLASSPATH=%s;%s", classPath, cp != 0 ? cp : "");
		putenv(buf);
	}

	if (jrePath) // Build the path
	{
		cp = getenv("PATH");
		sprintf(buf, "PATH=%s;%s", jrePath, cp != 0 ? cp : "");
		putenv(buf);
	}
}
