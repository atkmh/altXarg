/* ABTBaseWrapper.h
 *
 * Abstract base class for all java executable wrappers
 */

#include <windows.h>
#include <jni.h>

#define JAVA_DLL "JVM.DLL"

class ABTBaseWrapper
{
public:
	ABTBaseWrapper();

	LPCSTR run(int argc, char *argv[]);

protected:
	JavaVM *vmPtr;	// The Java VM pointer
	JNIEnv *env;	// The Java Environment pointer
	JDK1_1InitArgs *vmArgs;
	HMODULE hmod;

	// Abstract methods, must be defined in child classes
	//
	// Return the name of the java class containing  the main() method
	virtual LPCSTR getMainClass() = 0;
	// Add any additional VM arguments to the initVMArgs
	virtual void getVMArgs(JDK1_1InitArgs *initVMArgs) = 0;

	virtual bool createVM();
	virtual jobjectArray createArgList(int argc, char *argv[]);
	virtual bool LoadJavaDLL();

private:
	bool IsModuleValid(HINSTANCE m)				{ return ((UINT)m) > HINSTANCE_ERROR; }
};