/* ABTRegistryValues.cpp
 * 
 * Class for extracting imformation from the windows registry for ABT specific
 * java products.
 *
 */

#include "ABTRegistryValues.h"
#include <winreg.h>

// productName = Name of the ABT product to get registry values for
ABTRegistryValues::ABTRegistryValues(char *productName) : name_(productName), vmArgs_(NULL), jrePath_(NULL),
			classpath_(NULL), args_(NULL)
{
	openRegistry();
}

ABTRegistryValues::~ABTRegistryValues()
{
	RegCloseKey(mainKey_);
	RegCloseKey(javaKey_);
	if (classpath_) delete [] classpath_;
	if (jrePath_) delete [] jrePath_;
	if (args_) delete [] args_;
}

/*
 * Returns the PATH environment variable in the form:
 * "PATH=[<product\JRE path | java\JRE path>;][<existing path>]"
 *
 * First checks product registry then abtjava registry and appends environment path
 */
LPCSTR ABTRegistryValues::getJREPath()
{
	if (jrePath_ == NULL)
	{
		jrePath_ = new char[1024];
		jrePath_[0] = '\0';
		// build path
		char *cp = getRegistryValue(mainKey_, JRE_PATH_KEY);
		if (cp == NULL || cp[0] == '\0') cp = getRegistryValue(javaKey_, JRE_PATH_KEY);
//		if (cp)
//		{
			char *ecp = getenv("PATH");
			sprintf(jrePath_, "PATH=%s;%s", cp != 0 ? cp : "", ecp != 0 ? ecp : "");
//		}
	}

	return jrePath_;
}

/*
 * Returns the CLASSPATH environment variable in the form:
 * "CLASSPATH=[<product\classpath>;][<java\classpath>;][<existing path>]"
 *
 * First gets product classpath then appends abtjava classpath and environment classpath
 */
char *ABTRegistryValues::getClasspath()
{
	if (classpath_ == NULL)
	{
		classpath_ = new char[1024];
		classpath_[0] = '\0';
		// Build the classpath
		char *cp = getenv("CLASSPATH");
		sprintf(classpath_, "CLASSPATH=%s;%s;%s", getRegistryValue(mainKey_, CLASSPATH_KEY),
					getRegistryValue(javaKey_, CLASSPATH_KEY), cp != 0 ? cp : "");
	}
	
	return classpath_;
}

/*
 * Returns the VM arguments string which isn't really useful until parsed into an
 * JDK1_1InitArgs structure via parseVMArgs().
 *
 * "[<java\VM arguments>] [<product\VM arguments>]"
 *
 * First gets abtjava vm args then appends the vm args for product
 */
LPTSTR ABTRegistryValues::getVMArgsString()
{
	if (args_ == NULL)
	{
		args_ = new char[1024];
		// Build the vm args list
		sprintf(args_, "%s %s %s", getRegistryValue(javaKey_, VM_ARGS_KEY), getRegistryValue(mainKey_, VM_ARGS_KEY), getClasspath());
	}

	return args_;
}

/*
 * If you pass initVMArgs it will use those initial values (recommended),
 * otherwise it starts with an uninitialized struct
 */
JDK1_1InitArgs *ABTRegistryValues::getVMArgs(JDK1_1InitArgs *initVMArgs)
{
	if (initVMArgs != NULL) vmArgs_ = initVMArgs;
	parseVMArgs(getVMArgsString());
	char *s = strchr(getClasspath(), '=') + 1;
	return vmArgs_;
}

// Open the registry associated with the product key and common abt java settings
bool ABTRegistryValues::openRegistry()
{
	DWORD res;
	char subKey[1024];

	// Open the product registry
	strcpy(subKey, COMPANY_KEY);
	strcat(subKey, name_);
	long retval = RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, name_, REG_OPTION_NON_VOLATILE,
									KEY_ALL_ACCESS, NULL, &mainKey_, &res);
	// Open the ABT Java registry
	strcpy(subKey, COMPANY_KEY);
	strcat(subKey, JAVA_KEY);
	retval |= RegCreateKeyEx(HKEY_LOCAL_MACHINE, subKey, 0, JAVA_KEY, REG_OPTION_NON_VOLATILE,
									KEY_ALL_ACCESS, NULL, &javaKey_, &res);
   
	return retval == ERROR_SUCCESS;
}

// Returns the string value associated with the key for the specified section
char *ABTRegistryValues::getRegistryValue(HKEY hkey, LPCSTR key)
{
	long retval;
	char *value = NULL;
	char valuebuf[1024] = "";
	//const unsigned char blank[2] = "";
	unsigned long valuelen = 1024;
	unsigned long typevar = REG_SZ;

	// Get the value if it exists
	retval = RegQueryValueEx(hkey, key, NULL, &typevar, (unsigned char *)&valuebuf, &valuelen);
	if (retval == ERROR_SUCCESS)
	{
		value = strdup(valuebuf);
	}

	return value;
}

// Parses the vm args and puts them into the JDK1_1InitArgs struct
void ABTRegistryValues::parseVMArgs(char *args)
{
	if (vmArgs_ == NULL) vmArgs_ = new JDK1_1InitArgs;

	char *token = NULL;
	int multiplier = 1, saveValue = 0;

	token = strtok(args, " ");
	while (token) {
		if (*token == '-') {
			token++;
			
			char *temp = token;
			while(*temp) { // Convert the args string the lower case for easier comparison.
				*temp = tolower(*temp);
				temp++;
			}

			switch (*token) {
			case 's':
				if (strncmp(token,"ss",2) == 0) {
					token += 2;
					temp = token + (strlen(token) - 1);
					multiplier = getMultiplier(temp);

				   saveValue = vmArgs_->nativeStackSize;
					
					if (multiplier >= 1) {
						// Stack size can't be < 1000 bytes.
						vmArgs_->nativeStackSize = atoi(token) * multiplier;
						if (vmArgs_->nativeStackSize < 1000) vmArgs_->nativeStackSize = saveValue;
					}
				}
				break;
			case 'o':
				if (strncmp(token, "oss",3) == 0) {
					token += 3;
					temp = token + (strlen(token) - 1);
					multiplier = getMultiplier(temp);
					
					saveValue = vmArgs_->javaStackSize;

					if (multiplier >= 1) {
						// Stack size can't be < 1000 bytes
						vmArgs_->javaStackSize = atoi(token) * multiplier;
						if (vmArgs_->javaStackSize < 1000) vmArgs_->javaStackSize = saveValue;
					}
				}
				break;
			case 'm':
				if (strncmp(token, "mx", 2) == 0) {
					token += 2;
					temp = token + (strlen(token) - 1);
					multiplier = getMultiplier(temp);

					saveValue = vmArgs_->maxHeapSize;

					if (multiplier >= 1) {
						vmArgs_->maxHeapSize = atoi(token) * multiplier;
						// Heap size can't be < 1000 bytes;
						saveValue = vmArgs_->maxHeapSize;
						if (vmArgs_->maxHeapSize < 1000) vmArgs_->maxHeapSize = saveValue;
					}

				} else if (strncmp(token, "ms", 2) == 0) {
					token += 2;
					temp = token + (strlen(token) - 1);
					multiplier = getMultiplier(temp);

					saveValue = vmArgs_->minHeapSize;

					if (multiplier >= 1) {
						vmArgs_->minHeapSize = atoi(token) * multiplier;
						// Heap must be > 1000 bytes.
						if (vmArgs_->minHeapSize < 1000) vmArgs_->minHeapSize = saveValue;
					}
				}
				break;
			case 'v':
				if (strcmp(token, "verify") == 0) vmArgs_->verifyMode = 2;
				else if (strcmp(token, "verbosegc") == 0) vmArgs_->enableVerboseGC = 1;
				else if (strcmp(token, "verifyremote") == 0) vmArgs_->verifyMode = 1; 
				break;
			case 'n':
				if (strcmp(token, "noverify") == 0) vmArgs_->verifyMode = 0;
				else if (strcmp(token, "noclassgc") == 0) vmArgs_->enableClassGC = 0;
				else if (strcmp(token, "noasyncgc") == 0) vmArgs_->disableAsyncGC = 1;
				break;
			}
		}
		token = strtok(NULL," ");
	}
}

int ABTRegistryValues::getMultiplier(char *string)
{
	int multiplier = 1;

	if (*string == 'm') {
		multiplier = MEGA_BYTE;
		*string = 0;

	} else if (*string == 'k') {
		multiplier = KILO_BYTE;
		*string = 0;
	} else if (!isdigit(*string)) multiplier = -1;

	return multiplier;
}