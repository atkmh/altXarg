/* 
 * Java wrapper for YOUR_JAVA_APP
 *
 * This is for a Windows console application
 */

#include "ABTWrapper.h"

static char *MAIN_CLASS = "YOUR_MAIN_CLASS";

void main(int argc, char *argv[])
{
	/*
	 * First instanciate an ABTWinWrapper object
	 */
	printf("Initializing...\n\n");
	// Pass in any specific classpath and path info instead of the NULLs
	ABTWrapper *wrapper = new ABTWrapper(MAIN_CLASS, NULL, NULL);

	/*
	 * To start the java vm call the run method of the wrapper along with the arguments.
	 * If you have default arguments to pass to the main class add it to the argv array
	 * before calling run.
	 */
	printf("\nRunning %s\n\n", MAIN_CLASS);
	wrapper->run(argc, argv);

	// Don't forget to delete the wrapper
	printf("Cleaning up\n");
	delete wrapper;

	printf("%s finished\n", MAIN_CLASS);
}