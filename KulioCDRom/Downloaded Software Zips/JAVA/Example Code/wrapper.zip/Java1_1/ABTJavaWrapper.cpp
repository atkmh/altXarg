/****
 * ABTJavaWrapper.cpp
 *
 * This class is responsible for the following:
 * 1. Setting the CLASSPATH and PATH environment variables for the Tarrazu Java Run Time Environment
 * 2. Creating the Java VM
 * 3. Loading the main class
 * 4. Building the java.lang.String array to pass to the main class
 * 5. invoking the main method in main.class
 * 6. Shutting down the main.class
 *
 */

#include <windows.h>
#include <string.h>

#include <jni.h>

#include "ABTJavaWrapper.h"

ABTJavaWrapper::ABTJavaWrapper(char *productName)
{
	registry_ = new ABTRegistryValues(productName);
	
	// set CLASSPATH.
	putenv(registry_->getClasspath());
	// set PATH
	putenv(registry_->getJREPath());
}

ABTJavaWrapper::~ABTJavaWrapper()
{
	delete registry_;
}

