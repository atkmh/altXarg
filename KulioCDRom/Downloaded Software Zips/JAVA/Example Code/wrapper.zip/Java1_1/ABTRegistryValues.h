/* ABTRegistryValues.h
 * 
 * Class for extracting imformation from the windows registry for ABT specific
 * java products.
 *
 */

#include "windows.h"
#include <jni.h>

#define MEGA_BYTE	1024000  // 1000K
#define KILO_BYTE	1024     // 1K

static LPCSTR COMPANY_KEY		= "SOFTWARE\\ABT Corporation\\";
static LPTSTR JAVA_KEY			= "Java";
static LPCSTR JRE_PATH_KEY		= "JRE path";
static LPCSTR CLASSPATH_KEY		= "classpath";
static LPCSTR MAIN_CLASS_KEY	= "main";
static LPCSTR VM_ARGS_KEY		= "VM arguments";

class ABTRegistryValues
{
public:
	ABTRegistryValues(char *productName);
	~ABTRegistryValues();

	// Predefined convenience methods for accessing registry values
	LPCSTR	getProductName()				{ return name_; }
	LPCSTR	getJREPath();
	char *	getClasspath();
	LPCSTR	getMainClass()					{ return getRegistryValue(mainKey_, MAIN_CLASS_KEY); }
	LPTSTR	getVMArgsString();

	// Allows user access to other values in the product's registry section
	char *getRegistryValue(LPCSTR key)		{ return getRegistryValue(mainKey_, key); }
	
	JDK1_1InitArgs*	getVMArgs(JDK1_1InitArgs *initVMArgs = NULL);

protected:
	char *name_;
	JDK1_1InitArgs *vmArgs_;
	LPTSTR jrePath_;
	LPTSTR classpath_;
	LPTSTR args_;
	
	bool openRegistry();
	char *getRegistryValue(HKEY hkey, LPCSTR key);
	void parseVMArgs(char *args);
	int  getMultiplier(char *temp);

private:
	HKEY mainKey_;
	HKEY javaKey_;
};