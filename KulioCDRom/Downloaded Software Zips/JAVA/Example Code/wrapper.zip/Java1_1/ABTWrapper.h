// ABTWrapper.h

#include <windows.h>
#include <jni.h>

#include "ABTBaseWrapper.h"

#define JAVAI_DLL "JAVAI.DLL"

class ABTWrapper : public ABTBaseWrapper
{
public:
	ABTWrapper(char *mainClass, char *classPath, char *jrePath);

protected:
	LPCSTR mainClass_;

	LPCSTR getMainClass()						{ return mainClass_; }
	void getVMArgs(JDK1_1InitArgs *initVMArgs)	{ /* No additional args */  }
};