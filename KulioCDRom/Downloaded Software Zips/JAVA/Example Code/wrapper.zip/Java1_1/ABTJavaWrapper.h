// ABTJavaWrapper.h

#include <windows.h>
#include <jni.h>

#include "ABTRegistryValues.h"
#include "ABTBaseWrapper.h"

class ABTJavaWrapper : public ABTBaseWrapper
{
public:
	ABTJavaWrapper(char *productName);
	~ABTJavaWrapper();

	ABTRegistryValues *getRegistryValues()		{ return registry_; }

protected:
	ABTRegistryValues *registry_;

	LPCSTR getMainClass()						{ return registry_->getMainClass(); }
	void getVMArgs(JDK1_1InitArgs *initVMArgs)	{ registry_->getVMArgs(initVMArgs); }
};