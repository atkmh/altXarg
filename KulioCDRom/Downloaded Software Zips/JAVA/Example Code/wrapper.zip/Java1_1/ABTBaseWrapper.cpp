/****
 * ABTBaseWrapper.cpp
 *
 * This class is responsible for the following:
 * 1. Setting the CLASSPATH and PATH environment variables for the Tarrazu Java Run Time Environment
 * 2. Creating the Java VM
 * 3. Loading the main class
 * 4. Building the java.lang.String array to pass to the main class
 * 5. invoking the main method in main.class
 * 6. Shutting down the main.class
 *
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>

#include <jni.h>

#include "ABTBaseWrapper.h"

// Change this number to specify the JDK1_1InitArgs version you are using
static jint VM_ARGS_VERSION = 0x00010001;

// Function prototypes for the JNI functions needed from javai.dll
typedef jint (JNICALL *JNI_CREATEJAVAVM)(JavaVM **, JNIEnv **, void *);
typedef jint (JNICALL *JNI_GETDEFAULTJAVAVMINITARGS)(void *);

JNI_CREATEJAVAVM             CreateJavaVM;
JNI_GETDEFAULTJAVAVMINITARGS GetDefaultJavaVMInitArgs;


ABTBaseWrapper::ABTBaseWrapper() : vmPtr(NULL), vmArgs(NULL)
{
}

/*
 * Invoke Java runtime.
 *
 * Returns an error string or NULL if no errors
 */
LPCSTR ABTBaseWrapper::run(int argc, char *argv[])
{
	LPCSTR errorStr = NULL;

	if (LoadJavaDLL())
	{
		// Create the VM
		if (createVM())
		{
			// Find the main class
			jclass mainClass = env->FindClass(getMainClass());
			if (mainClass)
			{
				// Find the main method
				jmethodID mID = env->GetStaticMethodID(mainClass, "main", "([Ljava/lang/String;)V");
				if (mID)
				{
					// Create the argument lists
					jobjectArray jargs = createArgList(argc, argv);
					// Invoke the main method
					env->CallStaticVoidMethod(mainClass, mID, jargs);
				}
				else errorStr = "Could not find main method";
			}
			else errorStr = "Could not find main class";

			vmPtr->DestroyJavaVM();
			delete vmArgs;
		}
		else  errorStr = "Could not create the Java Virtual Machine";

		FreeLibrary(hmod);
	}
	else errorStr = "Java DLL not found or invalid";

	return errorStr;
}

bool ABTBaseWrapper::createVM()
{
	vmArgs = new JDK1_1InitArgs;
	GetDefaultJavaVMInitArgs(vmArgs);
	getVMArgs(vmArgs);
	// IMPORTANT: specify vm_args version # if you use JDK1.1.2 and beyond
	vmArgs->version = VM_ARGS_VERSION;
	vmArgs->classpath = getenv("CLASSPATH");
	
	return CreateJavaVM(&vmPtr, &env, vmArgs) == 0;
}
					
/*
* Create the String array of arguments for the main method
* argc and argv are standard dos-style with first argument being program name
*/
jobjectArray ABTBaseWrapper::createArgList(int argc, char *argv[])
{
	jclass strClass = env->FindClass("java/lang/String");
	jobjectArray jargs = env->NewObjectArray(argc-1, strClass, 0);
	
	// Skip the first arg (program name)
	for(int j = 1; j < argc; j++)
	{
		jstring str = env->NewStringUTF(argv[j]);
		env->SetObjectArrayElement(jargs, j-1, str);
	}

	return jargs;
}

bool ABTBaseWrapper::LoadJavaDLL()
{
	bool loaded = false;

	hmod = LoadLibrary(JAVA_DLL);
	
	if(IsModuleValid(hmod)) {
		
		GetDefaultJavaVMInitArgs = (JNI_GETDEFAULTJAVAVMINITARGS)GetProcAddress(hmod, "JNI_GetDefaultJavaVMInitArgs");
		
		CreateJavaVM = (JNI_CREATEJAVAVM)GetProcAddress(hmod, "JNI_CreateJavaVM");

		if(GetDefaultJavaVMInitArgs != NULL && CreateJavaVM != NULL) loaded = true;  
	}
	
	return loaded;
}
