//******************************************************************************
// -----------------------------------------------------------
// tMail.java		                 				  
// -----------------------------------------------------------
// Comments : very simple eMail applet
// -----------------------------------------------------------
// Author : R. BERTHOU
// E-Mail : rberthou@wanadoo.fr
// URL    : http://perso.wanadoo.fr/rberthou
// -----------------------------------------------------------
// 1.00 * R.BERTHOU  * 01/05/98 * samples tips
//******************************************************************************

// Standard Java Imports

import java.applet.Applet;

import java.net.*;
import java.io.*;
import java.awt.*;


public class tMail extends java.applet.Applet {
    TextArea	tMessage ;
	Button	    bEnvoie  ;
    TextField   tSubject ;
    TextField   tTo      ;
    TextField   tFrom    ;



// Applet initialisation routine
public void init() {

	GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints g = new GridBagConstraints();
    setFont(new Font("Helvetica", Font.PLAIN, 12));
    setLayout(gridbag);

    g.anchor	 = GridBagConstraints.NORTHEAST ;
    g.fill		 = GridBagConstraints.HORIZONTAL ;
    g.weightx	 = 1.0 ;
    g.weighty	 = 1.0;

	g.gridwidth = GridBagConstraints.REMAINDER; //end row
	bEnvoie = new Button("Envoie") ; 
    gridbag.setConstraints(bEnvoie, g);
	add(bEnvoie);

	g.gridwidth = GridBagConstraints.RELATIVE ;
	Label l0 = new Label("From :") ; 
    gridbag.setConstraints(l0, g);
	add(l0);

	tFrom = new TextField("moi@monserveur.com") ; 
    gridbag.setConstraints(tFrom, g);
	add(tFrom);

	g.gridwidth = GridBagConstraints.REMAINDER; //end row

	bEnvoie = new Button("Envoie") ; 
    gridbag.setConstraints(bEnvoie, g);
	add(bEnvoie);

	g.gridwidth = GridBagConstraints.RELATIVE ;
	Label l1 = new Label("To :") ; 
    gridbag.setConstraints(l1, g);
	add(l1);

	g.gridwidth = GridBagConstraints.REMAINDER; //end row
	tTo = new TextField("xxxx@yyyy.com") ; 
    gridbag.setConstraints(tTo, g);
	add(tTo);

	g.gridwidth = GridBagConstraints.RELATIVE ;
	Label l2 = new Label("Subject :") ; 
    gridbag.setConstraints(l2, g);
	add(l2);

	g.gridwidth = GridBagConstraints.REMAINDER; //end row
	tSubject = new TextField("Test tMail") ; 
    gridbag.setConstraints(tSubject, g);
	add(tSubject);

	g.gridwidth = GridBagConstraints.RELATIVE ;
	Label l3 = new Label("Message :") ; 
    gridbag.setConstraints(l3, g);
	add(l3);

    g.fill		 = GridBagConstraints.BOTH ;
	g.gridwidth  = GridBagConstraints.REMAINDER; //end row
	g.gridheight = GridBagConstraints.REMAINDER; //end col
	tMessage     = new TextArea("...",5,40) ; 
    gridbag.setConstraints(tMessage, g);
	add(tMessage);

} // end of init


public boolean action(Event evt, Object arg)
{
	if (evt.target instanceof Button) {
      try {	
 		 sendMail(tTo.getText(),  
				  tFrom.getText(),
                  tSubject.getText(),
                  tMessage.getText() ) ;
      }
      catch(UnknownHostException uhe)
	  {
		 Debug("-->uhe " + uhe ) ;
	  }
      catch(ProtocolException pe)
	  {
		 Debug("-->pe " + pe ) ;
	  }
      catch(IOException ioe)
	  {
		 Debug("-->ioe " + ioe ) ;
	  }
	}

	return true ;
}



public void sendMail(String to_address,   // Destinataire du message
                        String from_address, // Emeteur du message
                        String sSu,          // Sujet du message
                        String sMess)        // Message
         throws IOException, ProtocolException, UnknownHostException 
 {

	 tMessage.setText("") ;
	 Debug("--- Envoie de Mail----") ;
	 Debug("--- From : " + from_address) ;
	 Debug("--- To   : " + to_address) ;
	 Debug("--- Sujet: " + sSu) ;
	 Debug("--- Mess : " + sMess) ;
	 Debug("----------------------") ;

     Socket socket;       // Le Socket
     DataInputStream in;  // Le stream de lecture du Socket
     PrintStream out;     // Le stream d'ecriture du Socket
     String host;         // Identification du poste
     String str;          // Pour la lecture de donnees
     // Identification du poste
     // host = InetAddress.getLocalHost().toString() ;
	 host = new String("www.aol.com") ;

     // Ouverture du socket (connection au mailServer)
     //   et des streams de lecture et d'ecriture
     socket = new Socket(getDocumentBase().getHost(), 25);
     in     = new DataInputStream(socket.getInputStream());
     out    = new PrintStream(socket.getOutputStream()); 
     // lecture du message initial     
	 str = in.readLine();

	 Debug(str) ;

     if (!str.startsWith("220"))
		 throw new ProtocolException(str);
     while (str.indexOf('-') == 3) {         
		 str = in.readLine();
		 Debug(str) ;
         if (!str.startsWith("220"))
            throw new ProtocolException(str);  
	 }
     // fin message initial

     // Dialogue avec les Serveur de mail     
	 // Envoie de HELO au serveur SMTP
     out.println( "HELO " + host );     
	 out.flush() ; 
	 str = in.readLine();

	 Debug(str) ;

     if (!str.startsWith("250"))    throw new ProtocolException(str);
     // On est connecte au serveur de Mail...    
	 // Envoie du Mail
     out.println( "MAIL FROM: " + from_address ); 
	 out.flush() ;
     str = in.readLine();

	 Debug(str) ;

     if (!str.startsWith("250"))    throw new ProtocolException(str);
     // A qui envoie t on cela 
	 out.println( "RCPT TO: " + to_address );
     out.flush() ;
     str = in.readLine();

	 Debug(str) ;

     if (!str.startsWith("250"))    throw new ProtocolException(str);
     // Est on pret a envoyer les donnees  
	 out.println( "DATA" );
     out.flush() ;     
	 str = in.readLine();

	 Debug(str) ;

     if (!str.startsWith("354"))    throw new ProtocolException(str);
     // Emmeteur - Destinataire - Sujet
     out.println("From: " + from_address);     
	 out.println("To: " + to_address);
     out.println( "Subject: " + sSu + "\n" );     
	 out.flush() ;
     out.println("Comment: Unauthenticated sender");
     out.println("X-Mailer: Simple tSmtp");    
	 out.println("");
     out.println( sMess ) ;
     out.println(".") ;
	 out.flush() ;
     str = in.readLine();

	 Debug(str) ;

     if (!str.startsWith("250"))    throw new ProtocolException(str);

     out.println("QUIT"); 
	 out.flush();  
	 in.close() ;

	 Debug("Fin du Mail...") ;

     socket.close()  ;    
	 return ;   
}

public void Debug(String str) 
{
//	System.out.println(str) ;
	tMessage.appendText(str + "\n") ;

	return ;
}

public static void main(String args[])
{
	Frame f = new Frame("tMail");
	tMail tM = new tMail();
	tM.init();
	tM.start();

	f.add("Center", tM);
	f.resize(350, 200);
	f.pack();
	f.show();
   }

}