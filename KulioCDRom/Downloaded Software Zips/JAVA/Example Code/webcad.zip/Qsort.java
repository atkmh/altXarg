// Qsort.java v1.5

class Qsort {
    public static void qsort(Object[] data, Comparator comparator) {
        qsort(data, 0, data.length, comparator);
    }

    public static void qsort(Object[] data, int index, int length, Comparator comparator) {
        Qsort sort = new Qsort();
        sort.comparator = comparator;
        _qsort(data, index, length, sort);
    }

    private static void _qsort(Object[] data, int index, int length, Qsort sort) {
        if (length <= 1)
            return;

        int pivotIdx = findPivot(data, index, length, sort);
        if (pivotIdx == -1)
            return;     // all elements in the array subrange have the same value

        Object pivotVal = data[pivotIdx];
        int left = index;
        int right = index + length - 1;

        for (;;) {
            // place the elements less than the pivot value in the lefthand side of the array,
            // and elements greater than or equal to it on the right. Because findPivot
            // guarantees that the array contains at least one value less than the pivot value
            // and one equal to it, no bounds checking is required in the following two loops

            while (sort.comparator.compare(data[right], pivotVal) >= 0)
                --right;

            while (sort.comparator.compare(data[left], pivotVal) < 0)
                ++left;

            if (left > right)
                break;

            swap(data, left, right);
        }

        // Note: At this point, left must equal right + 1

        _qsort(data, index, left - index, sort);        // sort the left-half of the array
        _qsort(data, left, length - (left - index), sort);  // sort the right-half of the array
    }

    private static int findPivot(Object[] data, int index, int length, Qsort sort) {
        // return -1 if the indicated subrange of the array contains only identical values,
        // otherwise return the index of the larger leftmost two different elements

        for (int i = index + 1; i < index + length; ++i) {
            int n = sort.comparator.compare(data[index], data[i]);
            if (n < 0)
                return i;
            else if (n > 0)
                return index;
        }
        return -1;
    }

    private static void swap(Object[] data, int index1, int index2) {
        Object tmp = data[index1];
        data[index1] = data[index2];
        data[index2] = tmp;
    }

    private Comparator comparator;
}