// Point3D.java v1.5

class Point3D {
    double distance, rotation, elevation;
    double x, y, z;

    Point3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
        rectangular2polar();
    }

    void scale(double scaleFactor) {
        distance *= scaleFactor;
        polar2rectangular();
    }

    void rotate(double radians) {
        rotation += radians;
        polar2rectangular();
    }

    void elevate(double radians) {
        double yz = Math.sqrt(y * y + z * z);
        if (yz != 0) {
            double angle = Math.asin(y / yz);
            if (z < 0)
                angle = Math.PI - angle;
            angle -= radians;
            y = yz * Math.sin(angle);
            z = yz * Math.cos(angle);
            rectangular2polar();
        }
    }

    void move(double x, double y, double z) {
        this.x += x;
        this.y += y;
        this.z += z;
        rectangular2polar();
    }

    private void rectangular2polar() {
        double xz = Math.sqrt(x * x + z * z);
        distance = Math.sqrt(xz * xz + y * y);
        if (distance == 0)
            rotation = elevation = 0;
        else {
            rotation = xz == 0 ? 0 : Math.asin(z / xz);
            if (x < 0)
                rotation = Math.PI - rotation;
            elevation = Math.asin(y / distance);
        }
    }

    private void polar2rectangular() {
        double xz = distance * Math.cos(elevation);
        x = xz * Math.cos(rotation);
        y = distance * Math.sin(elevation);
        z = xz * Math.sin(rotation);
    }
}