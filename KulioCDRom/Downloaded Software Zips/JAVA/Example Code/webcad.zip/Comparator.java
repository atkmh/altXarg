// Comparator.java v1.5

public interface Comparator {
    public int compare(Object a, Object b);
}
