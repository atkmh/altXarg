// PlaneProperties.java v1.5

class PlaneProperties {
    int displayMode;
    double scaleFactor;
    double rotation;
    double elevation;

    PlaneProperties(int displayMode, double scaleFactor, double rotation, double elevation) {
        this.displayMode = displayMode;
        this.scaleFactor = scaleFactor;
        this.rotation = rotation;
        this.elevation = elevation;
    }
}