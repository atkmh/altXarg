// Plane.java v1.5

import java.awt.*;

class Plane {
    Plane(PlaneProperties planeProperties, Point[] points, double rotation, double elevation,
            double x, double y, double z, Color color) {
        this.planeProperties = planeProperties;
        this.color = color;

        this.points = new Point3D[points.length];

        for (int i = 0; i < points.length; ++i) {
            this.points[i] = new Point3D(points[i].x, points[i].y, 0);
            this.points[i].rotate(rotation);
            this.points[i].elevate(elevation);
            this.points[i].move(x, y, z);
        }

        normal = new Point3D(0, 0, Math.sqrt(Double.MAX_VALUE) / -2);
        normal.rotate(rotation);
        normal.elevate(elevation);
        normal.move(x, y, z);
    }

    void draw(Graphics g) {
        Polygon polygon = new Polygon();
        for (int i = 0; i < points.length; ++i) {
            Point3D point = spinPoint(points[i]);
            polygon.addPoint((int) point.x, (int) -point.y);
        }
        Point3D point = spinPoint(points[0]);
        polygon.addPoint((int) point.x, (int) -point.y);

        switch (planeProperties.displayMode) {
        case DM_WIRE_FRAME:
            g.setColor(Color.black);
            g.drawPolygon(polygon);
            break;
        case DM_SOLID_OBJECT:
            if (facesViewer()) {
                g.setColor(color);
                g.fillPolygon(polygon);
                g.setColor(Color.black);
                g.drawPolygon(polygon);
            }
            break;
        }
    }

    private Point3D spinPoint(Point3D point) {
        point = new Point3D(point.x, point.y, point.z);
        point.scale(planeProperties.scaleFactor);
        point.rotate(-planeProperties.rotation);
        point.elevate(-planeProperties.elevation);
        return point;
    }

    private boolean facesViewer() {
        Point3D n = new Point3D(normal.x, normal.y, normal.z);
        n.rotate(-planeProperties.rotation);
        n.elevate(-planeProperties.elevation);
        return n.z < 0;
    }

    private Point3D[] points;
    private Color color;

    private Point3D normal;     // for hidden line removal

    private PlaneProperties planeProperties;

    static final int DM_WIRE_FRAME = 0;
    static final int DM_SOLID_OBJECT = 1;
}