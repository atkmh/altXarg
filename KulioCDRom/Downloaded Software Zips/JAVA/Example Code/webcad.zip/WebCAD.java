// WebCAD.java v1.5

import java.applet.Applet;
import java.awt.*;
import java.util.Vector;

public class WebCAD extends Applet {
    public void init() {
        setBackground(Color.lightGray);

        displayModeButton = new Button("Solid Object");
        displayModeButton.setBackground(Color.lightGray);
        add("North", displayModeButton);

        scaleTextField = new TextField("1.0");
        scaleTextField.setBackground(Color.white);
        add("North", scaleTextField);

        planeProperties = new PlaneProperties(Plane.DM_WIRE_FRAME, 1.0, INITIAL_ROTATION,
                INITIAL_ELEVATION);

        cubes = new Cube[5];
        cubes[0] = new Cube(planeProperties, 60, 0, 0, 0);
        cubes[1] = new Cube(planeProperties, 60, 60, 0, 0);
        cubes[2] = new Cube(planeProperties, 60, -60, 0, 0);
        cubes[3] = new Cube(planeProperties, 60, 0, 60, 0);
        cubes[4] = new Cube(planeProperties, 60, -60, 0, -60);
    }

    public boolean action(Event evt, Object what) {
        if (evt.target.equals(displayModeButton)) {
            switch (planeProperties.displayMode) {
            case Plane.DM_WIRE_FRAME:
                displayModeButton.setLabel("Wire Frame");
                planeProperties.displayMode = Plane.DM_SOLID_OBJECT;
                break;
            case Plane.DM_SOLID_OBJECT:
                displayModeButton.setLabel("Solid Object");
                planeProperties.displayMode = Plane.DM_WIRE_FRAME;
                break;
            }
        } else if (evt.target.equals(scaleTextField)) {
            try {
                Double scaleFactor = Double.valueOf((String) what);
                planeProperties.scaleFactor = scaleFactor.doubleValue();
            } catch (NumberFormatException e) {
            }
        }

        repaint();
        return true;
    }

    public void paint(Graphics g) {
        update(g);
    }

    public void update(Graphics g) {
        Dimension size = size();
        if (image == null || image.getWidth(null) != size.width ||
                image.getHeight(null) != size.height) {
            image = createImage(size.width, size.height);
            gg = image.getGraphics();
            int adj = displayModeButton.size().height + displayModeButton.location().y;
            gg.translate(size.width / 2, (size.height - adj) / 2 + adj);
        }

        gg.setColor(getBackground());
        gg.fillRect(-size.width, -size.height, size.width * 2, size.height * 2);

        for (int i = cubes.length - 1; i >= 0; --i)
            cubes[i].reposition(planeProperties);

        // sort the cubes into increasing magnitude of their Z-values
        Qsort.qsort(cubes, new CubeComparator());

        for (int i = cubes.length - 1; i >= 0; --i)
            cubes[i].draw(gg);

        g.drawImage(image, 0, 0, null);
    }

    public boolean mouseDown(Event evt, int x, int y) {
        xx = x; yy = y;
        return true;
    }

    public boolean mouseDrag(Event evt, int x, int y) {
        planeProperties.rotation -= (x - xx) * SPEED;
        planeProperties.elevation += (y - yy) * SPEED;
        xx = x; yy = y;
        repaint();
        return true;
    }

    private Cube[] cubes;
    private PlaneProperties planeProperties;

    // for double-buffering of animation
    private Image image;
    private Graphics gg;

    // position of last mouse-down or mouse-drag
    private int xx, yy;

    static final double SPEED = 0.025;
    static final double INITIAL_ROTATION = 36 * Math.PI / 180;      // 36� anticlockwise
    static final double INITIAL_ELEVATION = 25 * Math.PI / 180;     // 25� elevation

    private Button displayModeButton;
    private TextField scaleTextField;
}