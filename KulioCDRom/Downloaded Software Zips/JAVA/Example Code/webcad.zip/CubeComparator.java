// CubeComparator.java v1.5

public class CubeComparator implements Comparator {
    public int compare(Object a, Object b) {
        double za = ((Cube) a).center.z;
        double zb = ((Cube) b).center.z;
        return za < zb ? -1 : za > zb ? 1 : 0;
    }
}
