// Cube.java v1.5

import java.awt.*;

class Cube {
    Cube(PlaneProperties planeProperties, double size, double x, double y, double z) {
        int hsize = (int) Math.round(size / 2);
        Point[] points = new Point[4];

        points[0] = new Point(-hsize, hsize);
        points[1] = new Point(hsize, hsize);
        points[2] = new Point(hsize, -hsize);
        points[3] = new Point(-hsize, -hsize);

        double qturn = Math.PI / 2;     // quarter turn (90�)
        double hturn = Math.PI;         // half turn (180�)
        PlaneProperties p = planeProperties;

        planes[0] = new Plane(p, points, 0, 0, x, y, z - hsize, Color.red);         // front
        planes[1] = new Plane(p, points, hturn, 0, x, y, z + hsize, Color.magenta); // back
        planes[2] = new Plane(p, points, -qturn, 0, x - hsize, y, z, Color.green);  // left
        planes[3] = new Plane(p, points, qturn, 0, x + hsize, y, z, Color.blue);    // right
        planes[4] = new Plane(p, points, 0, qturn, x, y + hsize, z, Color .yellow); // top
        planes[5] = new Plane(p, points, 0, -qturn, x, y - hsize, z, Color.orange); // bottom

        _center = center = new Point3D(x, y, z);
    }

    void reposition(PlaneProperties planeProperties) {
        center = new Point3D(_center.x, _center.y, _center.z);
        center.scale(planeProperties.scaleFactor);
        center.rotate(-planeProperties.rotation);
        center.elevate(-planeProperties.elevation);
    }

    void draw(Graphics g) {
        for (int i = 0; i < planes.length; ++i)
            planes[i].draw(g);
    }

    private Plane planes[] = new Plane[6];
    private Point3D _center;
    Point3D center;
}