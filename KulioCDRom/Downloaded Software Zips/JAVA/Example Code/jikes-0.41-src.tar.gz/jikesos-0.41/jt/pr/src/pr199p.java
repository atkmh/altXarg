class Test {
	void method() {
		label: int j=1;
			   j++;
			   return;
	}
}