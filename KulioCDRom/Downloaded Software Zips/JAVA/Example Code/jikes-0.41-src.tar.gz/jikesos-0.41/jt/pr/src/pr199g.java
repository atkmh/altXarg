class Test {
	abstract private void am() {}
}