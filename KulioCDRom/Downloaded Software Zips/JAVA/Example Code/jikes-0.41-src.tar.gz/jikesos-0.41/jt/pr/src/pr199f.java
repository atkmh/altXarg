class Test {
	void[] m(int i) {}
}