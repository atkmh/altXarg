class Test {
	byte b = 'b';
}
