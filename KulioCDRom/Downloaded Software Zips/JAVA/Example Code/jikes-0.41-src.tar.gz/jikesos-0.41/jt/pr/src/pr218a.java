// This software is subject to the terms of the IBM Jikes Compiler Open
// Source License Agreement available at the following URL:
// http://www.ibm.com/research/jikes.
// Copyright (C) 1996, 1998, International Business Machines Corporation
// and others.  All Rights Reserved.
// You must accept the terms of that agreement to use this software.

 /* Generated from 'test.nrx' 30 Jul 1998 19:48:12 [v1.140] *//*
Options: Crossref Decimal Logo Trace2 Verbose3 */public class
   test{private static final java.lang.String $0="test.nrx";public static
	void main(java.lang.String $0s[]){netrexx.lang.RexxIO.Say("hello world");return;}private test(){return;}}

 
