package java.lang.String;
class Illegal {
}
