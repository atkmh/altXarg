// This software is subject to the terms of the IBM Jikes Compiler Open
// Source License Agreement available at the following URL:
// http://www.ibm.com/research/jikes.
// Copyright (C) 1996, 1998, International Business Machines Corporation
// and others.  All Rights Reserved.
// You must accept the terms of that agreement to use this software.

// %GROUP initinter initintersuper 
// %TSR EE 25
// %MAIN


class bigi implements initinter {
  static int x = 5;
  static int y = 12;
  static int z = 2;
  public static void main(String args[]) {
    int answer;
    answer = 3;
    answer = answer + sum;
    System.out.println(answer);
    System.exit(answer);
  }
}
