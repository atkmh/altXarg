//
// This software is subject to the terms of the IBM Jikes Compiler Open
// Source License Agreement available at the following URL:
// http://www.ibm.com/research/jikes.
// Copyright (C) 1996, 1998, International Business Machines Corporation
// and others.  All Rights Reserved.
// You must accept the terms of that agreement to use this software.
//
#ifndef config_INCLUDED
#define config_INCLUDED

#include <new.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "string.h"
#include <stdio.h>
#include <sys/stat.h>   

#ifdef TEST
#define NO_LEAKS
#endif

//
// We need to set up certain environment information depending on
// the host OS.
//
// Jikes uses the stat() system call to query file status. Traditional
// unix systems use S_IFDIR and S_IFREG as names for constants used to
// see if file is directory or regular file, respectively. POSIX-based
// systems use __S_IFDIR and __S_IFREG, with S_IFDIR and S_IFREG being
// defined as macros
//
#ifdef STAT_POSIX
#define STAT_S_IFDIR __S_IFDIR
#define STAT_S_IFREG __S_IFREG
#else
#define STAT_S_IFDIR S_IFDIR
#define STAT_S_IFREG S_IFREG
#endif

//
// These definitions are correct for all the platforms that
// we are currently using. When porting this code, they should
// always be reviewed.
//
#include <limits.h>

#if ! (UINT_MAX == 0xFFFFFFFF)
#error unsigned int does not store values in the range 0..4294967295 in this system
#else
    typedef unsigned int u4;
#endif

#if ! ((INT_MAX == 2147483647) && (INT_MIN + 1 == -INT_MAX))
#error signed int does not store values in the range -2147483648..+2147483647 in this system
#else
    typedef signed int i4;
#endif

#if ! (USHRT_MAX == 0xFFFF)
#error unsigned short does not store values in the range 0..65535 in this system
#else
    typedef unsigned short u2;
#endif

#if ! ((SHRT_MAX == 32767) && (SHRT_MIN + 1 == -SHRT_MAX))
#error signed short does not store values in the range -32767..+32768 in this system
#else
    typedef signed short i2;
#endif

#if ! (UCHAR_MAX == 0xFF)
#error unsigned char does not store values in the range 0..255 in this system
#else
    typedef unsigned char u1;
#endif

#if ! ((SCHAR_MAX == 127) && (SCHAR_MIN + 1 == -SCHAR_MAX))
#error signed character does not store values in the range -128..+127 in this system
#else
    typedef signed char i1;
#endif

//
// Jikes can be compiled on systems using the EBCDIC character set, for which character and string
// literals are translated by the compiler to EBCDIC and not ASCII, and so cannot be used to represent
// ASCII/UNICODE values. Such values are constructed using the U_ values defined below. Thus
// 'a' is represented using U_a, and ".java" is represented by an explicit literal:
//    {U_DOT, U_j, U_a, U_v, U_a, U_NULL}
// Variables associated with such literals have names beginning with US_ if the value are 16-bits
// or U8S_ for 8 bits. The initial underscore is followed by the characters being represented, with
// letters and digits representing themselves, and other values, all of which have a two character code,
// surrounded by underscore. Thus the name used for the literal above is US__DO_java.
//
// All string-related values are represented internally in ASCII/UNICODE using the U_ values defined
// below. EBCDIC systems also require that arguments to system functions representing file names be
// converted from the internal form used by Jikes to EBCDIC, and such functions are referred to using
// their usual name prefixed with "system_"; for example, a call to "fopen(..." is written "system_fopen(..."
// The "system_" procedures are define in the file code.cpp.
//
enum U_chars
{
    U_NULL = 0,               U_NU = U_NULL,            // L'\0'
    U_BACKSPACE = 8,          U_BS = U_BACKSPACE,       // L'\b'
    U_HORIZONTAL_TAB = 9,     U_HT = U_HORIZONTAL_TAB,  // L'\t'
    U_LINE_FEED = 10,         U_LF = U_LINE_FEED,       // L'\n'
    U_FORM_FEED = 12,         U_FF = U_FORM_FEED,       // L'\f'
    U_CARRIAGE_RETURN = 13,   U_CR = U_CARRIAGE_RETURN, // L'\r'

    U_CTL_Z = 26,
    U_ESCAPE = 27,

    U_SPACE = 32,             U_SP = U_SPACE,             // L' '
    U_EXCLAMATION = 33,       U_EX = U_EXCLAMATION,       // L'!'
    U_DOUBLE_QUOTE = 34,      U_DQ = U_DOUBLE_QUOTE,      // L'"'
    U_POUND = 35,             U_SH = U_POUND,             // L'#'
    U_DOLLAR = 36,            U_DS = U_DOLLAR,            // L'$'
    U_PERCENT = 37,           U_PE = U_PERCENT,           // L'%'
    U_AMPERSAND = 38,         U_AM = U_AMPERSAND,         // L'&'
    U_SINGLE_QUOTE = 39,      U_SQ = U_SINGLE_QUOTE,      // L'\''
    U_LEFT_PARENTHESIS = 40,  U_LP = U_LEFT_PARENTHESIS,  // L'('
    U_RIGHT_PARENTHESIS = 41, U_RP = U_RIGHT_PARENTHESIS, // L')'
    U_STAR = 42,              U_ST = U_STAR,              // L'*'
    U_PLUS = 43,              U_PL = U_PLUS,              // L'+'
    U_COMMA = 44,             U_CM = U_COMMA,             // L'-'
    U_MINUS = 45,             U_MI = U_MINUS,             // L','
    U_DOT = 46,               U_DO = U_DOT,               // L'.'
    U_SLASH = 47,             U_SL = U_SLASH,             // L'/'

    U_0 = 48, // L'0'
    U_1 = 49, // L'1'
    U_2 = 50, // L'2'
    U_3 = 51, // L'3'
    U_4 = 52, // L'4'
    U_5 = 53, // L'5'
    U_6 = 54, // L'6'
    U_7 = 55, // L'7'
    U_8 = 56, // L'8'
    U_9 = 57, // L'9'

    U_COLON = 58,             U_CO = U_COLON,     // L':'
    U_SEMICOLON = 59,         U_SC = U_SEMICOLON, // L';'
    U_LESS = 60,              U_LT = U_LESS,      // L'<'
    U_EQUAL = 61,             U_EQ = U_EQUAL,     // L'='
    U_GREATER = 62,           U_GT = U_GREATER,   // L'>'
    U_QUESTION = 63,          U_QU = U_QUESTION,  // L'?'
    U_AT = 64,                                    // L'@'

    U_A = 65, // L'A'
    U_B = 66, // L'B'
    U_C = 67, // L'C'
    U_D = 68, // L'D'
    U_E = 69, // L'E'
    U_F = 70, // L'F'
    U_G = 71, // L'G'
    U_H = 72, // L'H'
    U_I = 73, // L'I'
    U_J = 74, // L'J'
    U_K = 75, // L'K'
    U_L = 76, // L'L'
    U_M = 77, // L'M'
    U_N = 78, // L'N'
    U_O = 79, // L'O'
    U_P = 80, // L'P'
    U_Q = 81, // L'Q'
    U_R = 82, // L'R'
    U_S = 83, // L'S'
    U_T = 84, // L'T'
    U_U = 85, // L'U'
    U_V = 86, // L'V'
    U_W = 87, // L'W'
    U_X = 88, // L'X'
    U_Y = 89, // L'Y'
    U_Z = 90, // L'Z'

    U_LEFT_BRACKET = 91,      U_LB = U_LEFT_BRACKET,  // L'['
    U_BACKSLASH = 92,         U_RS = U_BACKSLASH,     // L'\\'
    U_RIGHT_BRACKET = 93,     U_RB = U_RIGHT_BRACKET, // L']'
    U_CARET = 94,             U_CA = U_CARET,         // L'^'
    U_UNDERSCORE = 95,        U_UN = U_UNDERSCORE,    // L'_'

    U_a = 97, // L'a'
    U_b = 98, // L'b'
    U_c = 99, // L'c'
    U_d = 100, // L'd'
    U_e = 101, // L'e'
    U_f = 102, // L'f'
    U_g = 103, // L'g'
    U_h = 104, // L'h'
    U_i = 105, // L'i'
    U_j = 106, // L'j'
    U_k = 107, // L'k'
    U_l = 108, // L'l'
    U_m = 109, // L'm'
    U_n = 110, // L'n',
    U_o = 111, // L'o'
    U_p = 112, // L'p'
    U_q = 113, // L'q'
    U_r = 114, // L'r'
    U_s = 115, // L's'
    U_t = 116, // L't'
    U_u = 117, // L'u'
    U_v = 118, // L'v'
    U_w = 119, // L'w'
    U_x = 120, // L'x'
    U_y = 121, // L'y'
    U_z = 122, // L'z'

    U_LEFT_BRACE = 123,       U_OS = U_LEFT_BRACE,  // L'{'
    U_BAR = 124,              U_BA = U_BAR,         // L'|'
    U_RIGHT_BRACE = 125,      U_CS = U_RIGHT_BRACE, // L'}'
    U_TILDE = 126,            U_TI = U_TILDE,       // L'~'

    U_chars_size
};


//
// Constant strings used in the program.
//
class StringConstant
{
public:
    static wchar_t US_AND[], // "&"
                   US_AND_AND[], // "&&"
                   US_AND_EQUAL[], // "&="
                   US_COLON[], // ":"
                   US_COMMA[], // ","
                   US_DIVIDE[], // "/"
                   US_DIVIDE_EQUAL[], // "/="
                   US_DOT[], // "."
                   US_EMPTY[], // ""
                   US_EQUAL[], // "="
                   US_EQUAL_EQUAL[], // "=="
                   US_GREATER[], // ">"
                   US_GREATER_EQUAL[], // ">="
                   US_LBRACE[], // "{"
                   US_LBRACKET[], // "["
                   US_LEFT_SHIFT[], // "<<"
                   US_LEFT_SHIFT_EQUAL[], // "<<="
                   US_LESS[], // "<"
                   US_LESS_EQUAL[], // "<="
                   US_LPAREN[], // "("
                   US_MINUS[], // "-"
                   US_MINUS_EQUAL[], // "-="
                   US_MINUS_MINUS[], // "--"
                   US_MULTIPLY[], // "*"
                   US_MULTIPLY_EQUAL[], // "*="
                   US_NOT[], // "!"
                   US_NOT_EQUAL[], // "!="
                   US_OR[], // "|"
                   US_OR_EQUAL[], // "|="
                   US_OR_OR[], // "||"
                   US_PLUS[], // "+"
                   US_PLUS_EQUAL[], // "+="
                   US_PLUS_PLUS[], // "++"
                   US_QUESTION[], // "?"
                   US_RBRACE[], // "}"
                   US_RBRACKET[], // "]"
                   US_REMAINDER[], // "%"
                   US_REMAINDER_EQUAL[], // "%="
                   US_RIGHT_SHIFT[], // ">>"
                   US_RIGHT_SHIFT_EQUAL[], // ">>="
                   US_RPAREN[], // ")"
                   US_SEMICOLON[], // ";"
                   US_TWIDDLE[], // "~"
                   US_UNSIGNED_RIGHT_SHIFT[], // ">>>"
                   US_UNSIGNED_RIGHT_SHIFT_EQUAL[], // ">>>="
                   US_XOR[], // "^"
                   US_XOR_EQUAL[], // "^="

                   US_Boolean[], // "Boolean"
                   US_Byte[], // "Byte"
                   US_Character[], // "Character"
                   US_Class[], // "Class"
                   US_Cloneable[], // "Cloneable"
                   US_Double[], // "Double"
                   US_Error[], // "Error"
                   US_Float[],  // "Float"
                   US_Integer[], // "Integer"
                   US_L[], // "L"
                   US_Long[], // "Long"
                   US_Object[], // "Object"
                   US_PObject[], // "PObject"
                   US_RuntimeException[], // RuntimeException
                   US_Serializable[], // Serializable
                   US_Short[], // Short
                   US_StringBuffer[], // StringBuffer
                   US_String[], // String
                   US_TYPE[], // "TYPE"
                   US_Throwable[], // Throwable
                   US_Void[], // Void
                   US__DO_[], // "."
                   US__DO__DO_[], // ".."
                   US__DS_[], // "$"
                   US__LB__RB_[], // "[]"
                   US__LT_clinit_GT_[], // "<clinit>"
                   US__LT_init_GT_[], // "<init>"
                   US__QU__QU_[],  // "??"
                   US__SC_[], // ";"
                   US__SL_[], // "/"

                   US__array[], // "array"
                   US__access_DOLLAR[], // "access$"
                   US__class_DOLLAR[], // "class$"
                   US__constructor_DOLLAR[], // "constructor$"
                   US__this_DOLLAR[], // "this$"
                   US__val_DOLLAR[], // "val$"

                   US_abstract[], // "abstract"
                   US_block_DOLLAR[], // "block$"
                   US_boolean[], // "boolean"
                   US_break[], // "break"
                   US_byte[], // "byte"
                   US_case[], // "case"
                   US_catch[], // "catch"
                   US_char[], // "char"
                   US_class[], // "class"
                   US_clone[], // "clone"
                   US_const[], // "const"
                   US_continue[], // "continue"
                   US_default[], // "default"
                   US_do[], // "do"
                   US_double[], // "double"
                   US_else[], // "else"
                   US_extends[], // "extends"
                   US_false[], // "false"
                   US_final[], // "final"
                   US_finally[], // "finally"
                   US_float[], // "float"
                   US_for[], // "for"
                   US_goto[], // "goto"
                   US_if[], // "if"
                   US_implements[], // "implements"
                   US_import[], // "import"
                   US_instanceof[], // "instanceof"
                   US_int[], // "int"
                   US_interface[], // "interface"
                   US_java_SL_io[], // "java/io"
                   US_java_SL_lang[], // "java/lang"
                   US_length[], // "length"
                   US_long[], // "long"
                   US_native[], // "native"
                   US_new[], // "new"
                   US_null[], // "null"
                   US_package[], // "package"
                   US_private[], // "private"
                   US_protected[], // "protected"
                   US_public[], // "public"
                   US_return[], // "return"
                   US_short[], // "short"
                   US_static[], // "static"
                   US_super[], // "super"
                   US_switch[], // "switch"
                   US_synchronized[], // "synchronized"
                   US_this0[], // "this$0"
                   US_this[], // "this"
                   US_throw[], // "throw"
                   US_throws[], // "throws"
                   US_transient[], // "transient"
                   US_true[], // "true"
                   US_try[], // "try"
                   US_void[], // "void"
                   US_volatile[], // "volatile"
                   US_while[]; // "while"

    static char U8S_B[], // "B"
                U8S_C[], // "C"
                U8S_Code[], // "Code"
                U8S_ConstantValue[], // "ConstantValue"
                U8S_D[], // "D"
                U8S_Deprecated[], // "Deprecated"
                U8S_Exceptions[], // "Exceptions"
                U8S_F[], // "F"
                U8S_I[], // "I"
                U8S_InnerClasses[], // "InnerClasses"
                U8S_J[],  // "J"
                U8S_LP_Ljava_SL_lang_SL_String_SC_RP_Ljava_SL_lang_SL_Class_SC[], // "(Ljava/lang/String;)Ljava/lang/Class;"
                U8S_LP_Ljava_SL_lang_SL_String_SC_RP_V[], // "(Ljava/lang/String;)V"
                U8S_LP_RP_Ljava_SL_lang_SL_String_SC[], // "()_Ljava/lang/String;"
                U8S_LP_RP_V[], // "()V"
                U8S_LT_clinit_GT_[], // "<clinit>"
                U8S_LT_init_GT_[], // "<init>"
                U8S_LineNumberTable[], // "LineNumberTable"
                U8S_LocalVariableTable[], // "LocalVariableTable"
                U8S_S[], // "S"
                U8S_Sourcefile[], // "Sourcefile"
                U8S_Synthetic[], // "Synthetic"
                U8S_V[], // "V"
                U8S_Z[], // "Z"

                U8S__DO_[], // "."
                U8S__DO_class[], // ".class"
                U8S__DO_java[], // ".java"
                U8S__DO_tok[], // ".tok"
                U8S__LP_[], // "("
                U8S__RP_[], // ")"
                U8S__SL_[], // "/"
                U8S__ST_[], // "*"

                U8S_class[], // "class"
                U8S_forName[], // "forName"
                U8S_getMessage[], // "getMessage"
                U8S_java[], // "java"
                U8S_java_SL_lang_SL_ClassNotFoundException[], // "java/lang/ClassNotFoundException"
                U8S_java_SL_lang_SL_Class[], // "java/lang/Class"
                U8S_java_SL_lang_SL_CloneNotSupportedException[], // "java/lang/CloneNotSupportedException"
                U8S_java_SL_lang_SL_InternalError[], // "java/lang/InternalError"
                U8S_java_SL_lang_SL_NoClassDefFoundError[], // "java/lang/NoClassDefFoundError"
                U8S_java_SL_lang_SL_StringBuffer[], // "java/lang/StringBuffer"
                U8S_java_SL_lang_SL_Throwable[], // "java/lang/Throwable"
                U8S_null[], // "null"
                U8S_quit[], // "quit"
                U8S_this[], // "this"
                U8S_u[]; // "u"
};


//
// If the system runs out of memory, this function is invoked.
//
void SetNewHandler();
#ifdef MICROSOFT
    extern int OutOfMemory(size_t);
#else
    extern void OutOfMemory();
#endif


//
// When using the ICC compiler on Win95 or OS/2, we need to disable
// testing for various floating point exceptions. Default behavior
// was causing problems reading some standard class files. 
//
extern void FloatingPointCheck();


//
// variants of system functions requiring EBCDIC translation
// are declared here and defined in code.cpp
//
extern int SystemStat(const char *name, struct stat *stat_struct);
extern FILE *SystemFopen(char *name, char *mode);
extern size_t SystemFread(char *ptr, size_t element_size, size_t count, FILE *stream,int ascii_option = 0);
extern int SystemIsDirectory(char *name);


#ifdef UNIX
#define UNIX_FILE_SYSTEM
#endif


#if defined(GNU_LIBC5)
    extern size_t wcslen(wchar_t *);
    extern wchar_t *wcscpy(wchar_t *, wchar_t *);
    extern wchar_t *wcsncpy(wchar_t *, wchar_t *, int);
    extern wchar_t *wcscat(wchar_t *, wchar_t *);
    extern int wcscmp(wchar_t *, wchar_t *);
    extern int wcsncmp(wchar_t *, wchar_t *, int);
#endif


//
// The symbol used in this environment for separating argument in a system string. E.g., in a unix system
// directories specified in the CLASSPATH are separated by a ':', whereas in win95 it is ';'.
//
extern char PathSeparator();
extern int SystemMkdir(char *);

#endif // #ifndef config_INCLUDED
