//
// This software is subject to the terms of the IBM Jikes Compiler Open
// Source License Agreement available at the following URL:
// http://www.ibm.com/research/jikes.
// Copyright (C) 1996, 1998, International Business Machines Corporation
// and others.  All Rights Reserved.
// You must accept the terms of that agreement to use this software.
//
#ifndef lcase_INCLUDED
#define lcase_INCLUDED

#include "config.h"
#include <wchar.h>

//
// NOTE that this class is hard-wired to work on an ASCII machine.
// To make it universal, one should uncomment the constructor and
// make the array "lower" non-static. In such a case, each object
// of type Case that is declared will allocate its own "lower" array.
//
class Lcase
{
    static char lower[128];

public:

    static inline char ToLower(char c) { return (c & (char) 0x80) ? c : lower[c]; }
    static inline wchar_t ToLower(wchar_t c) { return (c < 128 ? (wchar_t) lower[c] : c); }

//  Lcase()
//  {
//      for (int c = 0; c < 256; c++)
//          lower[c] = c;
//
//      for (c = 'A'; c <= 'Z'; c++)
//      {
//          if (isalpha(c))
//              lower[c] = tolower(c);
//      }
//  }
};

#endif /* lcase_INCLUDED */
