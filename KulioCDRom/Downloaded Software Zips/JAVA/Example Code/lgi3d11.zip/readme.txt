lgimage3d is a free Java applet to make an image rotate in 3D.
You supply a JPG or GIF image. The applet rotates 
the image around either the X, Y, or Z axis. 
It has a very smooth animation.

Unzip the contents of this zip file into the directory of your choice.

Open up readme3d.html for instructions on the applet.

This applet is Freeware, and is freely distributable.

If there is a question or problem, contact Lawrence Goetz at:
goetz@lawrencegoetz.com
