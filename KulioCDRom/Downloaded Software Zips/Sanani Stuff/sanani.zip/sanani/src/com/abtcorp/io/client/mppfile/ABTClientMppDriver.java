package com.abtcorp.io.client.mppfile;


/**
 * ABTClientMppDriver.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 08-27-98    ATW             Initial Implementation
  * 09-18-98    ATW             Commented.
  *
  */

/**
 *  ABTClientMppDriver is called by applications to read, update and save
 *  project data from files created in Microsoft Project.
 *
 *
 * @version		1.0
 * @author		A. Waller
 * @see			ABTClientDriver
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.abtcorp.io.client.ABTClientDriver;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTObject;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject._MSProject;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTEmpty;


public class ABTClientMppDriver extends ABTClientDriver implements IABTPMRuleConstants,
																   IABTDriverConstants,
																   IABTClientMppDriverConstants
{

	private	com.abtcorp.autowrap.msproject._MSProject mspApp_;
	private String fileName_;
	private File mppFile_;

	/**
	*  Create an ABTClientMppDriver that is not associated with an object space.
	*  Associating an object space with this driver will be deferred until later.
	*/

	public ABTClientMppDriver() {/*implicit call to super() here*/}

	/**
	*  Constructs an ABTClientMppDriver. The driver constructed with this constructor
	*  is not associated to any particular file yet.
	*  @param space the IABTObjectSpace that this driver is associated with.
	*/
	public ABTClientMppDriver( IABTObjectSpace space )
	{
		super( space );
	}

	/**
	*  Constructs an ABTClientMppDriver. The driver constructed with this constructor
	*  is associated with the file specified by the file name passed in.
	*  @param space the IABTObjectSpace that this driver populates with project information.
	*  @param filename a String containing the name of the MPP file
	*/
	public ABTClientMppDriver( IABTObjectSpace space, String filename )
	{
		super( space );
		fileName_ = filename;
	}

    /**
    *  Opens the driver.  open() gets an interface to Microsoft Project which will 
    *  be passed to each of the helpers that populate different parts of the project.
    *  @param space an IABTObjectSpace reference to the object space which this driver will use
    *  @param args an IABTHashtable of input arguments
    *  @return an ABTError if an error occurs, returns null if successful.
    *  @exception ABTException  thrown if an unrecoverable error occurs.
    */
	public ABTValue open( IABTObjectSpace space, IABTHashTable args )
	{
		ABTValue ret = null;

		try
		{
			// make sure that the object space is set.
			if ( space != null )
			{
				if ( space instanceof IABTObjectSpace )
				{
					// The object space is ok, get an interface to MSP.
					mspApp_ = com.abtcorp.autowrap.msproject.Application.create_MSProject();
				}
				else
					ret = createErrorObject( this.getClass(), ERR_OPEN, ERR_OPEN_OBJ_SPACE );
			}
			else
				ret = createErrorObject( this.getClass(), ERR_OPEN, ERR_OPEN_BAD_OS );
		}
		catch ( Exception e )
		{
			ret = createErrorObject( this.getClass(), ERR_OPEN, ERR_OPEN_MSP );
		}
		finally
		{
			return ret;
		}
	}

	/**
	*  Populates a project object.	populate() opens the MPP file containing the project
	*  each of the helpers will read data from.
	*  @param space an IABTObjectSpace reference which this driver will use
	*  @param args an IABTHashtable of input arguments.  The KEY_SOURCENAME parameter is required.
	*  @return an ABTError if an error occurs, returns null if successful.
	*  @exception ABTException	thrown if an unrecoverable error occurs.
	*/
	public ABTValue populate( IABTObjectSpace space, IABTHashTable args ) 
	{
		ABTValue returnValue = null;
		ABTValue returnProjectValue = null;
		IABTObject val = null;

		try
		{
			// make sure that the object space is set.
			if ( space != null )
			{
				if ( space instanceof IABTObjectSpace )
				{
					// The object space is ok, validate the file -- the string should
					// be valid and the file MUST exist.  TO DO:  Modify this so that
					// if the filename isn't passed in, MSP creates a new, empty project.

					//
					// Now make sure the user passed a valid key/value combination.
					//
					fileName_ = getStringValue( args, KEY_SOURCENAME );
					if ( fileName_.length() == 0 )
						returnValue = createErrorObject( this.getClass(), ERR_POP, ERR_OPEN_BAD_KEY );

					//
					// Was that a real filename?   Sorry for the "magic number" 5.	It's
					// the length of the file extension, the "." and at least one char.
					//
					if ( fileName_ == null || fileName_.length() < 5 )
						returnValue = createErrorObject( this.getClass(), ERR_POP, ERR_OPEN_BADPATH );

					if ( returnValue == null )
					{
						// Were we already in an .MPP file?  Then it has to be dealt with.
						if ( mppFile_ != null )
						{
							File tempfile = new File( fileName_ );

							// Was it the same file?
							if ( mppFile_.equals( tempfile ) )
								returnValue = createErrorObject( this.getClass(), ERR_POP,
																 ERR_OPEN_FILE_OPEN1 +
																 mppFile_.toString() +
																 ERR_OPEN_FILE_OPEN2 );
							else // It's a different file.	What about the old one?
							{
								if ( tempfile.exists() )
									returnValue = createErrorObject( this.getClass(), ERR_POP,
																	 mppFile_.toString() +
																	 ERR_OPEN_CLOSEFIRST +
																	 tempfile.toString() );
								else	// Bad new filename.
									returnValue = createErrorObject( this.getClass(), ERR_POP,
																	 ERR_OPEN_BADPATH +
																	 tempfile.toString() );
							}
							tempfile = null;
						}
						else
						{
							//
							// Open the MPP file passed in.
							//
							mppFile_ = new File( fileName_ );

							if ( (!mppFile_.isAbsolute() && !mppFile_.isFile() ) )
								returnValue = createErrorObject( this.getClass(),
																 ERR_POP, ERR_OPEN_BADPATH +
																 mppFile_.toString() );
							if ( returnValue == null && !mppFile_.exists() )
								returnValue = createErrorObject( this.getClass(),
																 ERR_POP, ERR_OPEN_BADPATH +
																 mppFile_.toString() );

							// Have MSProject open the specified file.
							if ( returnValue == null )
							{
								if( mspApp_ instanceof _MSProject )
									mspApp_.FileOpen( new ABTString(mppFile_.toString()),
													new ABTBoolean(false),
													ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
													ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
													ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
													ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
													ABTEmpty.getEmpty(), ABTEmpty.getEmpty() );
								else
									returnValue = createErrorObject( this.getClass(), ERR_POP,
																	 ERR_OPEN_MSP );
							}
						}
					}
				}
				else  // Whatever was passed as an object space, it aint one.
					returnValue = createErrorObject( this.getClass(), ERR_POP, ERR_OPEN_BAD_OS );
			}
			else  // No object space was passed in.  Can't continue.
				returnValue = createErrorObject( this.getClass(), ERR_POP, ERR_OPEN_OBJ_SPACE );

			//
			// The object space and file name validate ok, so populate.
			//
			if ( returnValue == null )
			{
				ABTClientMppProject projPop = null;
				projPop = new ABTClientMppProject( space, this, mspApp_ );

				if ( projPop != null && projPop instanceof ABTClientMppProject )
					 returnProjectValue = projPop.populate();

				returnValue = returnProjectValue;

				mspApp_.FileClose( new ABTInteger(0), new ABTBoolean(true) ); // 0 means "no save"
			}
		}
		catch ( Exception e )
		{
			returnValue = new ABTError( this.getClass(), ERR_POP, ERR_JAVA_EXCEPTION, e );
		}
		finally
		{
			// Throw away the current file object.
			if ( mppFile_ != null )
				mppFile_ = null;

			return returnValue;
		}

	}

	/**
	*  Saves and closes the currently open MPP file.
	*  @param space an IABTObjectSpace reference which this driver will use
	*  @param args an IABTHashtable of input arguments.  KEY_DESTINATIONNAME is required
	*  @return an ABTValue an ABTError if an error occurs, returns null if successful.
	*  @exception ABTException	thrown if an unrecoverable error occurs.
	*/
	public ABTValue save( IABTObjectSpace space, IABTHashTable args )
	{
		ABTValue returnValue = null;
		ABTValue returnProjectValue = null;
		ABTValue projObj = null;
		boolean saveAs = false;

		try
		{
			// make sure that the object space is set.
			if ( space != null )
			{
				if ( space instanceof IABTObjectSpace )
				{
					// Retrieve the filename.
					if ( returnValue == null )
						fileName_ = getStringValue( args, KEY_DESTINATIONNAME );

					//
					// Was that a real filename?  Make sure it's a real file and that the
					// name has an absolute (fully qualified) path.
					//
					if ( fileName_ == null )
						returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_OPEN_NO_FILE );
					else
					{
						mppFile_ = new File( fileName_ );

						if ( (!mppFile_.isAbsolute() && !mppFile_.isFile() ) )
							returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_OPEN_BADPATH );
					}

					// Filename is ok.	If a project object was passed in, the driver is expected
					// to save it to the file regardless of whether or not it originated in that file.
					// If the MPP file to be saved is new and also not the file this project
					// originated in, it's a "save as."
					//
					if ( returnValue == null )
					{
						if ( args.containsKey( new ABTString(KEY_SOURCE ) ) )
						{
							projObj = args.getItemByString( KEY_SOURCE );
							if ( !(projObj instanceof IABTObject) )
								returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_NO_PROJ );
							else
								saveAs = !(mppFile_.exists());
						}

						// Have MSProject open the specified file.
						//
						if ( returnValue == null && mspApp_ != null )
						{
							if ( !saveAs )
								mspApp_.FileOpen(
									new ABTString(mppFile_.toString()), new ABTBoolean(false),
									ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
									ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
									ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
									ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
									ABTEmpty.getEmpty(), ABTEmpty.getEmpty() );
							else
								mspApp_.FileNew( null );
						}
					}
				}
				else  // Whatever was passed as an object space, it aint one.
					returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_OPEN_BAD_OS );
			}
			else  // No object space was passed in.  Can't continue.
				returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_OPEN_OBJ_SPACE );

			//
			// If the object space, project object and file name validated ok, save the project.
			//
			if ( returnValue == null )
			{
				ABTClientMppProject projSaver = null;
				projSaver = new ABTClientMppProject( space, this, mspApp_, (IABTObject)projObj );

				if ( projSaver != null && projSaver instanceof ABTClientMppProject )
					 returnProjectValue = projSaver.save();

				if ( ABTError.isError( returnProjectValue ) )
					throw new ABTException( ((ABTError)returnProjectValue).getMessage() );

				// If it was established above that this is a new file, set the filename.
				if ( saveAs )
					mspApp_.FileSaveAs( new ABTString(mppFile_.toString()),
										ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
										ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
										ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
										ABTEmpty.getEmpty(), ABTEmpty.getEmpty(),
										ABTEmpty.getEmpty(), ABTEmpty.getEmpty() );

				mspApp_.FileClose( new ABTInteger(1), new ABTBoolean(true) ); // 1 means "save"

				// This is the only place where the return value is set to something good.
				returnValue = returnProjectValue;
			}
		}

		catch ( ABTException e )
		{
			returnValue = createErrorObject( this.getClass(), ERR_SAVE, e.getMessage() );
		}
		catch ( Exception e )
		{
			returnValue = new ABTError( this.getClass(), ERR_SAVE, ERR_JAVA_EXCEPTION, e );
		}
		finally
		{
			// Throw away the current file object.
			if ( mppFile_ != null )
				mppFile_ = null;

			return returnValue;
		}
	}

	/**
	*  Releases the interface to Microsoft Project.
	*  @param space an IABTObjectSpace reference which this driver will use
	*  @param args an IABTHashtable of input arguments.  Optional - can be null or empty.
	*  @return an ABTError if an error occurs, returns null if successful.
	*/
	public ABTValue close( IABTObjectSpace space, IABTHashTable args )
	{
		//
		// We're done using MSProject.	Close the interface.  TO DO:  Check return from
		// the file close and MSP release and return an ABTError if there is a problem.
		//
		if ( mspApp_ != null )
		{
			// This simple close doesn't do a save.  For that, call the save method.
			mspApp_.release();

			// TO DO:  make sure the release works, otherwise WINPROJ stays open.
			mspApp_ = null;
		}

		return null;
	}

	/**
	*  Performs custom actions.  Currently unused.
	*  @param space an IABTObjectSpace reference which this driver will use
	*  @param args an IABTHashtable of input arguments.  These are currently undefined
    *  for this driver.
	*  @return an ABTError if an error occurs, returns null if successful.
	*/
	public ABTValue execute( IABTObjectSpace space, IABTHashTable args )
	{
		return null;
	}

	/***
	* Returns the file name for this driver.
	* @return a String containing the file name currently in use
	*/
	public String getFileName() { return fileName_; }

	/***
	* Returns the file object associated with this driver.
	* @return the File object that this driver will read from or write to
	*/
	public File getFile()  { return mppFile_; }

	/***
	*  Formats errors returned by the public methods of this driver class.
	*  @param method a String representing the method this error occurred in
	*  @param errMsg a String describing the error	
	*  @return an ABTError
	*/
	protected ABTError createErrorObject( Class cls, String method, String errMsg )
	{
		return new ABTError( cls, method, errMsg, null );
	}

}
