package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;

import com.abtcorp.blob.ABTCalendar;
import com.abtcorp.blob.ABTCurve;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ResourcePopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   public ResourcePopulator() {}
   public ResourcePopulator(ABTRepositoryDriver driver) {super(driver);}

   public ABTValue populate() throws ABTException
   {
      
   	// get a calendar cursor to optimize calendar retrieval for resources
   	ABTCursor calendars = getDriver().getRepository().select(CALENDAR_QUERY);
   	
   	// get set of all resources in the object space so that we can add to it
      ABTObjectSet resources = getObjectSet(OBJ_TW_RESOURCE);

      if (resources == null || cursor_ == null) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      int id = 0;
      
      total_ += 3; // For the user right processing.
      
      ABTObject user		 = null;
      ABTObject resource = null;
   	
   	if (resources_ == null) resources_ = new ObjectIDSortedArray(new TWObjectComparator(session_));

      // move through the resource cursor adding the resources
   	while(cursor_.moveNext()) {
         resource = null;
         if (cursor_.getFieldInt(FLD_ID) != id) {							// make sure we don't add the same resource twice
            resource = (ABTObject)addObject(resources,calendars);		// add the resource
         	resources_.add(resource);
         	user = linkToUser(user, resource); // link the resource to the appropriate user properties
            updateStatus(resource);
         }
         id = cursor_.getFieldInt(FLD_ID);
      }

      closePopulatorCursor();
      calendars.release();


      if (resources != null && resources.size(session_) > 0) updateStatus((ABTObject)resources.at(session_,0));

      return resources;
   }

   protected ABTValue addObject(ABTObjectSet resources, ABTCursor calendars)
   {
      ABTCalendar calendar = null;

      if (calendars.bsearchFirst(FLD_ID,cursor_.getField(FLD_CALENDARID))) calendar = (ABTCalendar)calendars.getField(FLD_VALUE);

      ABTObject resource = (ABTObject)resources.addNew(session_);
      resource.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
      resource.setValue(session_,FLD_TW_EXTERNALID,cursor_.getField(FLD_EXTERNALID));
      resource.setValue(session_,FLD_TW_NAME,cursor_.getField(FLD_NAME));
      resource.setValue(session_,FLD_TW_UNIT,cursor_.getField(FLD_UNIT));
      resource.setValue(session_,FLD_TW_HOURS_PER_DAY,cursor_.getField(FLD_HOURSPERDAY));
      resource.setValue(session_,FLD_TW_AVAILABILITY, cursor_.getField(FLD_AVAILCURVE));
      resource.setValue(session_,FLD_TW_CALENDAR, calendar);
      resource.setValue(session_,FLD_TW_COUNT, cursor_.getField(FLD_COUNT));
      resource.setValue(session_,FLD_TW_USERNAME, cursor_.getField(FLD_USERNAME));
      resource.setValue(session_,FLD_TW_DOH, cursor_.getField(FLD_DOH));
      resource.setValue(session_,FLD_TW_DOT, cursor_.getField(FLD_DOT));

   	// hook in the type code object
   	int index = typeCodes_.indexOf(new Integer(cursor_.getFieldInt(FLD_TYPECODEID)));
   	if (index != -1) resource.setValue(session_,FLD_TW_TYPECODE,(ABTValue)typeCodes_.at(index));

      // Scale the resource availability curve according to the unit.
      ABTValue value = resource.getValue(session_,FLD_TW_AVAILABILITY,null);

      if (!ABTValue.isEmpty(value) || !ABTError.isError(value)) {
         ABTCurve availability = (ABTCurve)value;

         switch (resource.getValue(session_,FLD_TW_UNIT,null).intValue()) {
            case RESOURCE_DAYS:   availability.scaleRate(1.0 / resource.getValue(session_,FLD_TW_HOURS_PER_DAY,null).doubleValue());
            case RESOURCE_HOURS:  availability.scaleRate(1.0 / 3600);
         }
      	
      	resource.setValue(session_,FLD_TW_AVAILABILITY,availability,null);
      }
   	
      RemoteID.setRemoteID(resource,session_);
      return resource;
   }

   protected ABTObject linkToUser(ABTObject user, ABTObject resource)
   {

      ABTObject currentUser = user;

   	// First, find the user that matches the RECORDID2 field in the cursor, if necessary.
      if (user == null || user.getValue(session_,FLD_ID,null).intValue() != cursor_.getFieldInt(FLD_RECORDID2)) {
         String userSelector = FLD_TW_ID + " = " + cursor_.getFieldInt(FLD_RECORDID2);
         ABTValue value = getDriver().getSpace().findObject(session_,OBJ_TW_USER,userSelector);

         if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) {
            ABTObjectSet users = (ABTObjectSet)value;
            if (users.size(session_) > 0) currentUser = (ABTObject)users.at(session_,0);
         }
      }

   	if (currentUser != null) {
   		if (cursor_.getFieldInt(FLD_FLAGS) >= APPROVE_RIGHT) {

	         ABTValue set = currentUser.getValue(session_,FLD_TW_RESOURCE_APPROVAL,null);
	         if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
	            // Maintain uniqueness of the set.
	            ABTObjectSet resources = (ABTObjectSet)set;
	         	if (!resources.contains(session_, resource)) resources.add(session_,resource);
	         }
  		   }
   		
  		   if (cursor_.getFieldInt(FLD_FLAGS) != APPROVE_RIGHT) {

	         ABTValue set = currentUser.getValue(session_,FLD_TW_RESOURCES,null);
	         if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
	            // Maintain uniqueness of the set.
	            ABTObjectSet resources = (ABTObjectSet)set;
	         	if (!resources.contains(session_, resource)) resources.add(session_,resource);
	         }
  		   }
	
      }
   	
   	return currentUser;
   }
}