/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;

class ABTPropertySetLocal extends ABTSessionObject implements IABTPropertySet
{
   protected ABTPropertySetLocal(ABTSessionObject s,com.abtcorp.hub.ABTPropertySet ar)
      {
      super(s,ar);
      _ps = ar;
      }

   private com.abtcorp.hub.ABTPropertySet _ps;
   private com.abtcorp.hub.ABTPropertySet ps() {
      if (_ps == null) _ps = (com.abtcorp.hub.ABTPropertySet)getObject();
      return _ps;
      }

   public int indexForName(String name){
      return ps().indexForName(name);
      }

   public int countNonVirtualProperties(){
      return ps().countNonVirtualProperties();
      }

   public int countProperties(){
      return ps().size();
      }

   public String nameForIndex(int index){
      return ps().nameForIndex(index);
      }

   public IABTProperty getPropertybyName(String name)
   {

      int index = ps().indexForName(name); 
      if (index < 0) return null;
      return new ABTPropertyLocal(this,(com.abtcorp.hub.ABTProperty)((ps().at(index))));
      }

   public IABTProperty getPropertybyIndex(int index){
      if ((index < 0) || (index >= ps().size()))
         return null;
      return new ABTPropertyLocal(this,(com.abtcorp.hub.ABTProperty)((ps().at(index))));
      }

   public IABTEnumerator getElements(){
      return new PropertyEnumerator(this,ps().elements());
      }

   private class PropertyEnumerator extends ABTSessionObject implements IABTEnumerator
     {
      java.util.Enumeration _en;
      public PropertyEnumerator(ABTSessionObject s, java.util.Enumeration en) {
         super(s,en);
         _en = en;
         }
      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }
      public ABTValue nextValue()
         { return (ABTValue)nextElement();  }
      public Object nextElement()
         { return new ABTPropertyLocal(this,(com.abtcorp.hub.ABTProperty)(_en.nextElement()));  }

     }

}
