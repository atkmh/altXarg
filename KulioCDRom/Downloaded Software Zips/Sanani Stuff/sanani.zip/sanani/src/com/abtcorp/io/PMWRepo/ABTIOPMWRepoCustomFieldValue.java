package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoCustomFieldValue.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-22-98    SOB            Initial Implementation
 * 07-09-98    SOB            transaction support
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support required params on create
 * 07-24-98    SOB            Mods to support save()
 * 10-09-98    SOB            Beginnings of progress reporting
 * 10-23-98    SOB            save() sets OFD_TABLENAME prior to saving each object to the repository
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoCustomFieldValue is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTCustomFieldValue object in the object space.
 *  <pre>
 *       ABTIOPMWRepoCustomFieldValue rd = new ABTIOPMWRepoDependency(ABTSession sess,
 *                                                          ABTRepository repo);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoCustomFieldValue extends ABTIOPMWHelper
{
   private static final int PROJECT = 1;
   private static final int TASK = 2;

   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private ABTObjectSet cfvos_ = null;
   private long projectID_ = -1;
   private Hashtable th_ = null;
   private int type_;

   public ABTIOPMWRepoCustomFieldValue() {/* implicit call to super() here */}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoCustomFieldValue(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable th,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_CUSTFIELDVALUE, OBJ_CUSTFIELDVALUE, progress);
      projObj_ = projObj;
      projectID_ = projID;
      th_ = th;
   }

   /**
    *    Constructor used by the save process
    *    @param space ABTObjectSpace reference
    *    @param driver ABTRepository reference
    *    @param project Project object reference
    *    @param forceAddNew true if to force additions to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoCustomFieldValue(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_CUSTFIELDVALUE, OBJ_CUSTFIELDVALUE, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates the object space with Custom Field Value objects
    *    @param parms an ABTArray of input parameters meaningful to the populate process (currently none)
    *    @return an ABTValue indicating the status of the populate process
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      populateCustomFields(PROJECT);
      
      //
      // If the input task object hashtable is null, we cannot populate task-related custom field
      // value objects.  Skip them if the task hashtable is absent.  The hashtable could be null
      // if we are populating projects thinly and only project-related custom field values are
      // being populated.
      //
      if (th_ != null)
         populateCustomFields(TASK);
      
      return (ABTValue) null;
   }

   private void populateCustomFields(int type) throws ABTException
   {
      ABTValue object;

      type_ = type;

      try
      {
         getCursor();

         //
         // For each custom field tuple in the result set, make sure one exists in the
         // object space.
         //
         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this custom field value object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the custom field value object already exists in the object space.
            //
            object = find(OBJ_CUSTFIELDVALUE, id_);

            //
            // If the object found is an ABTObject, then the custom field value object was
            // found in the object space.  Update (merge) its properties with those from the
            // repository.
            //
            // Otherwise, create a new custom field value object in the object space and
            // initialize its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }
         }              // end while (cursor_.moveNext())
      }                 // end try block
      finally
      {
         closeCursor();
      }
   }

   /**
    *    Creates a new Custom Field Value object
    *    @param parms an ABTArray of input parameters meaningful to the create process (currently none)
    *    @return an ABTValue which is the newly-created object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // To create a new custom field value object, no parms are required.
      //
      ABTValue object = createObject(OBJ_CUSTFIELDVALUE, id_, null);

      setValues((ABTObject) object);
      setReferences((ABTObject) object);

      return object;
   }

   /**
    *    Updates an existing Custom Field Value object
    *    @param parms an ABTArray of input parameters meaningful to the update process;
    *    currently, the object to be updated
    *    @return an ABTValue which is the updated object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
      setPropertyValues(ps_, cursor_, obj);
   }

   private void setReferences(ABTObject obj) throws ABTException
   {
      ABTObjectSet os = null;

      switch (type_)
      {
         case PROJECT:
            os = getObjectSet(projObj_, OFD_CUSTFIELDVALUES);
            break;

         case TASK:
            //
            // Place this custom field value object into its associated task's collection of
            // custom field value objects.
            //
            Long associatedTaskID = new Long(cursor_.getFieldInt(FLD_RECORDID));
            ABTObject associatedTask = (ABTObject) th_.get(associatedTaskID);
            if (associatedTask == null) 
               throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                    "CustomFieldValue->setReferences",
                                                    errorMessages.ERR_NO_TASK_FOR_CUSTOM_FIELD,
                                                    null) );
            os = getObjectSet(associatedTask, OFD_CUSTFIELDVALUES);
            break;
      }
      addListMember(os, obj);
   }

   private void getCursor()
   {
      closeCursor();
      switch (type_)
      {
         case PROJECT:
            //
            // Select the project-related custom field values for this project only.  Those
            // tuples will have a prTableName = 'prProject' and a
            // prRecordID = <this project's prID>
            //
            // Note the use of single quotation marks around the project table name.  This is
            // because prTableName is a text column.
            //
            cursor_ = repo_.select(TBL_CUSTFIELDVALUE);
            cursor_.andFilter(TBL_CUSTFIELDVALUE + "." + FLD_TABLENAME + " = '" + TBL_PROJECT + "'");
            cursor_.andFilter(TBL_CUSTFIELDVALUE + "." + FLD_RECORDID  + " = " + projectID_);
            break;

         case TASK:
            //
            // Select the task-related custom field values for all the tasks in the current
            // project.
            //
            cursor_ = repo_.select(QRY_TASKCUSTFIELDVALUES);
            cursor_.andFilter(TBL_TASK + "." + FLD_PROJECTID + " = " + projectID_);
            break;
      }
   }

   /**
    *    Saves Custom Field Value objects back to the repository
    *    @param parms   (currently not used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      saveCustomFields(PROJECT);
      saveCustomFields(TASK);
   }

   private ABTValue saveCustomFields(int type) throws ABTException
   {
      ABTObjectSet oSet;

      //
      // Set type of custome field value object being processed (PROJECT or TASK), get an appropriate cursor,
      // and order the result set by the prID of the PRCustFieldValue table.
      //
      type_ = type;
      getCursor();
      cursor_.setSort(TBL_CUSTFIELDVALUE + "." + FLD_ID);

      switch (type_)
      {
         case PROJECT:
            oSet = getObjectSet(projObj_, OFD_CUSTFIELDVALUES);
            ABTString tableName = new ABTString(TBL_PROJECT);
            setSomeProperties(oSet, projObj_, tableName);
            save(oSet);
            break;

         case TASK:
            saveTaskCustomFields();
            break;
      }

      return (ABTValue) null;
   }

   private ABTValue saveTaskCustomFields() throws ABTException
   {
      //
      // Get an object set of all the project's tasks.  Loop through all of those
      // tasks, looking for a non-null object set of custom field value objects.
      // For each set found, process all members of the set.
      //
      ABTObjectSet oSet = getObjectSet(projObj_, OFD_ALLTASKS);
      int size = size(oSet);

      ABTString tableName = new ABTString(TBL_TASK);
      
      for (int i = 0; i < size; i++)
      {
         ABTObject task = at(oSet, i);
         ABTObjectSet custFields = getObjectSet(task, OFD_CUSTFIELDVALUES);
         if (size(custFields) > 0)
         {
            setSomeProperties(custFields, task, tableName);
            save(custFields);
         }
      }

      return (ABTValue) null;
   }

   private void setSomeProperties(ABTObjectSet oSet, ABTObject ownerObj, ABTString tableName) throws ABTException
   {
      int size = size(oSet);

      ABTValue ownerID = getValue(ownerObj, OFD_ID);

      //
      // Loop through all of the custom field value objects.  These objects are owned by
      // by either a project object or by a task object.  Set the custom field value record ID
      // property to be the value of the prID of the owning object.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject custField = at(oSet, i);
         setValue(custField, OFD_RECORDID, getValue(ownerObj, OFD_ID));
         setValue(custField, OFD_TABLENAME, tableName);
      }
   }
}