package com.abtcorp.io.team.connect.data;

import java.util.*;

import com.abtcorp.io.team.*;
import com.abtcorp.core.*;

public class FileViewer 
{
   private String directory_;
   private String file_;
   
   public FileViewer() 
   {
      directory_ = "d:/java/html"; // Default directory
   }
   
   public void run(String[] args)
   {
      Argument parser = new Argument("d,f,?,h");
      
      parser.parse(args);
      
      String help = (String)parser.get("?");
      if (help != null && help.length() > 0) {
         usage();
         return;
      }
      
      help = (String)parser.get("h");
      if (help != null && help.length() > 0) {
         usage();
         return;
      }
      
      String directory = (String)parser.get("d");
      if (directory != null && directory.length() > 0) {
         directory_ = directory;
      }
      
      String file = (String)parser.get("f");
      if (file != null && file.length() > 0) {
         file_ = file;
      }
      
      if (file_ == null) return; // No file, nothing to do.
      
      try {
         FileManager.getManager(directory_).openFiles(directory_);
      
         int type = FileManager.mapType(file_);
         StructuredFile datfile = FileManager.getManager(directory_).getFile(type,false);
         for (Enumeration e = datfile.keys();e.hasMoreElements();) {
            ABTValue key = (ABTValue)e.nextElement();
            DataRow row = (DataRow)datfile.readObject(key);
            Hashtable values = row.getValues();
            System.out.println(" ");
            if (key instanceof ABTInteger) System.out.println("Key is ABTInteger");
            else if (key instanceof ABTString) System.out.println("Key is ABTString");
            else System.out.println("Key is ABTValue");
            System.out.println(" ");
            System.out.println("DataRow found at key entry " + key);
            System.out.println(" ");
            for (Enumeration e2 = values.keys();e2.hasMoreElements();) {
               Object field = e2.nextElement();
               Object value = values.get(field);
               System.out.println(" Field: " + field + " value = " + value);
            }
         }
         FileManager.getManager(directory_).closeFiles();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
   
   public static void main(String[] args)
   {
      FileViewer app = new FileViewer();
      app.run(args);
   }
   
   private void usage()
   {
      System.out.println("usage: java FileViewer [-options]");
      System.out.println(" ");
      System.out.println("options include:");
      System.out.println("  -d=directory     directory where the dat files reside. Default = d:/java/html");
      System.out.println("  -f=file          File to view. Possible file names are:");
      System.out.println("     team.Project");
      System.out.println("     team.Task");
      System.out.println("     team.ChargeCode");
      System.out.println("     team.TypeCode");
      System.out.println("     team.TimePeriod");
      System.out.println("     team.TimeSheet");
      System.out.println("     team.CategoryString");
      System.out.println("     team.Resource");
      System.out.println("     team.User");
      System.out.println("     team.Submitted");
      System.out.println("     team.Unplanned");
      System.out.println(" ");
      System.out.println("Example: java FileViewer -d=d:/java/data -f=team.Project");
      
   }
}