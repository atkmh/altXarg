package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileNote.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-1-98     MXA         Initial Implementation
 *
 */

/**
 *  ABTIOSiteFileNote is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOSiteFileDriver.
 *
 *  <pre>
 *       ABTIOSiteFileNote fr = new ABTIOSiteFileNote(driver,parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOSiteFileDriver
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;


public class ABTIOSiteFileNote extends ABTIOSiteFileHelper implements IABTRuleConstants
{
     private IABTObject resourceObj_ = null;
     
//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOSiteFileNote constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOSiteFileNote(ABTIOSiteFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_NOTE);
      site_ = parent;
   }


/**
 * Populate site resource's note.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
 protected ABTValue populate(IABTLocalID resourceId) throws ABTException
 {
        ABTValue     val           = null;
	    ABTValue     ret           = null;
        ABTRemoteID  remoteId      = null;      
        ABTObjectSetIDList noteIds = null;        
         
        Object obj = null;
        obj = driver_.lookupTableGet(resourceId);         
        if ( (obj != null) && (obj instanceof IABTObject))
            resourceObj_ =  (IABTObject)obj;
        else
            throw new ABTException("The resource object is not valid");
                   
        val = getIDs(resourceId, OBJ_RESOURCE, OFD_NOTES);        
	                                 
        if (val instanceof ABTObjectSetIDList) 
            noteIds  = (ABTObjectSetIDList)val;
            
        Enumeration itID = noteIds.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
           obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            id_ = (IABTLocalID)obj;           
           else
            throw new ABTException("Wrong Cast");
           ret = super.populate();   
        }
        return ret;
    
 }


/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {   
      // reqParams_.putItemByString(OFD_RESOURCE, parent_);
      // return (super.create(type, id, reqParams_));

      return (super.create(type, id, reqParams_));
   }


}
