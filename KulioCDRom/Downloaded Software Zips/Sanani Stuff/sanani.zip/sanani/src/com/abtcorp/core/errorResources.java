package com.abtcorp.core;

import java.util.ListResourceBundle;

public class errorResources extends ListResourceBundle implements errorMessages
   {
 	public Object[][] getContents() {
 		return contents;
 	}

 	// This section assigns message strings to the error constants
 	static final Object[][] contents = {
 	   // LOCALIZE THIS
 	    {CORE_ERR_INVALID_TYPE.getCode(),"encountered non-ABTValue element"},
        {CORE_ERR_INVALID_MOVE.getCode(),"Invalid Move Operation - new parent is current child"},
 	   // END OF MATERIAL TO LOCALIZE
      };
   }