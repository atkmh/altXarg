package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoTask.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-16-98    LZX         Initial Implementation
 * 06-30-98    LZX         Add to child task list while setting the parent task.
 * 07-02-98    LZX         Implemented "save()" to write task data back to the repository.
 * 07-07-98    LZX         Replaced "child tasks" property with "last child task", etc.
 * 07-10-98    LZX         Support transactions
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTIOMethRepoTask is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTIOMethRepoMethod object.
 *
 *  <pre>
 *       ABTIOMethRepoTask rt = new ABTIOMethRepoTask(driver, method);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTIOMethRepoMethod
 */

public class ABTIOMethRepoTask extends ABTIOMethRepoHelper 
{

   private Vector taskVector_ = null;
   private Hashtable taskHash_ = null;
   private ABTObject method_ = null;

/**
 *    ABTIOMethRepoTask constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the method object that owns all the tasks.
 */
   ABTIOMethRepoTask(ABTMMRepoDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_MRTASK, OBJ_MM_TASK);
      method_ = parent;
     	taskVector_ = new Vector();      // get a new Vector for these task objects
     	taskHash_ = new Hashtable();     // get a new Hashtable for these task objects
      component_ = "ABTIOMethRepoTask";
      // set required parameter method reference
      reqParams_.putItemByString(OFD_METHOD, method_);
   }
   
/**
 *  Set task property values.
 *  @param       ps: the task property hash.
 *  @param       cur: the task cursor.
 *  @param       obj: the task object.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps, ABTCursor cur, ABTObject taskObject) throws ABTException
   {	   
      setPropertyValues(ps, cur, taskObject);

      //
      // set the parent task object for the current task.  Since the tasks are
      // retrieved in WBS order, we can determine the parent task by looking at the
      // previous tasks that have been read and processed.
      //
      ABTValue parentTask = getParentTask(taskObject);
      
      // Set parent task.  Doing this will invoke the appropriate rules to wire-up the rest of 
      // the task-related links. if this task does not have a parent task, that means that it is 
      // "owned" by a method
      if (parentTask != null)
         setValue(taskObject, OFD_PARENTTASK, parentTask);

      // add to task vector and hashtable
      long taskID = cur.getFieldInt(FLD_ID);   
		taskVector_.addElement(taskObject);          // save for calculating parent task info
		taskHash_.put(new Long(taskID), taskObject); // save for quickly locating pred/succ task objects
   }

/**
 *  Set parent task.
 *  @param  obj: the task object.
 *  @return      the task object or error
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue getParentTask(ABTObject obj) throws ABTException
   {
      ABTValue parentTask = null;
      ABTObject parentObj = null;

      //
      // Get the input task object's WBSLevel value.  It will be used to compare against
      // WBSLevel values from task objects in the task Vector.
      //

      int   curObjLevel = getValue(obj, OFD_WBSLEVEL).intValue();

      //
      // Enter a loop which searches the taskVector_ collection of ABTObjects in reverse
      // order.  If the input task's WBSLevel is equal to the WBSLevel of the task being
      // inspected in the Vector, then the input task's parent is the same as the parent of the
      // one in the Vector.  If the input task's WBSLevel is less than the WBSLevel of the
      // task being inspected in the Vector, then the input task's parent is the task being
      // inspected in the Vector.
      //
      // It could happen that the beginning of the Vector is reached before any parent is
      // found for the input task.  In that case, assume the task is parentless.
      //

      for (int i = taskVector_.size() - 1; i > -1; i--)
      {
         ABTObject tmpObj = (ABTObject) taskVector_.elementAt(i);
         int vLevel = getValue(tmpObj, OFD_WBSLEVEL).intValue();  // get this element's WBSLevel value
         if (vLevel == curObjLevel)
         {
            parentTask = getValue(tmpObj, OFD_PARENTTASK);
            if( ABTError.isError( parentTask ) )
               return (ABTError)parentTask;
            break;
         }

         if (vLevel < curObjLevel)
         {
            parentTask = tmpObj;
            break;
         }
      }
      
      if (ABTValue.isEmpty(parentTask))
         return null;
      else
         return (parentTask);      
   }

/**
 *  Retrieves the task hash table.
 *  @return the task hash table
 *  @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public Hashtable getHash() throws ABTException
   {
      return taskHash_;
   }
   

/**
 * Sets cursor values and updates the repository.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// first set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);
		
		// for new records, get method id from the method object and set it in cursor.
		if (isNew)
   	   cursorSetField(cur, FLD_METHODID, getValue(method_, OFD_ID));
   }
   

/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         // prMethodID can not be modified after add-new
         if (!isNew && prapiName.equals(FLD_METHODID))    
            return true;
            
         return super.isSaveException(prapiName, obj, prapiFlags, isNew);            
   }


/**
 * Select tasks from the repository for "populate" (ordered by prWBSSequence).
 * @return the ABTCursor containing the selected rows.
 * @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForPopulate() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODTASKS + id + ORDERBY_WBSSEQUENCE));
   }
   
/**
 * Select tasks from the repository for "save" (ordered by prID).
 * @return the ABTCursor containing the selected rows.
 * @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForSave() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODTASKS + id));
   }
   
}