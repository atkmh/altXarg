package com.abtcorp.io
;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;

public class errorMessages extends ListResourceBundle
   {
 	public Object[][] getContents() {
 		return contents;
 	}

 	// This section defines error constants
 	public static final String Package = "com.abtcorp.io".intern();
   public static final ABTErrorCode IO_ERR_OBJECTSET_NOT_FOUND = new ABTErrorCode(Package, "100");

 	// This section assigns message strings to the error constants

 	static final Object[][] contents = {
 	   // LOCALIZE THIS
 	   {IO_ERR_OBJECTSET_NOT_FOUND.getCode(),"Object set not found"}
 	   // END OF MATERIAL TO LOCALIZE
      };
   }