package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class UserPopulator extends TWPopulator implements TWRepoDriverConstants, IABTTWRuleConstants, ABTNames
{
   public UserPopulator() {}

   public UserPopulator(ABTRepositoryDriver driver) {super(driver);}

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet users = getObjectSet(OBJ_TW_USER);

      if (users == null || cursor_ == null) return null;

      while(cursor_.moveNext()) {
         ABTValue user = addObject(users);
         try {
            initializeUserResourceRights((ABTObject)user);
         } catch (ClassCastException e) {
            // Eat this exception
         }
         updateStatus((ABTObject)user);
      }

      closePopulatorCursor();

      return users;
   }

   protected ABTValue addObject(ABTObjectSet users)
   {
      ABTObject user = (ABTObject)users.addNew(session_);
      user.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
      user.setValue(session_,FLD_TW_NAME,cursor_.getField(FLD_NAME));
      user.setValue(session_,FLD_TW_PASSWORD,cursor_.getField(FLD_PASSWORD));
      RemoteID.setRemoteID(user,session_);

      return user;
   }

   protected void initializeUserResourceRights(ABTObject user)
   {
      ABTException exception     = null;
      ABTCursor    readCursor    = null;
      ABTCursor    writeCursor   = null;
      ABTValue     userName      = user.getValue(session_, FLD_TW_NAME);
      int          rightsLevel;
      int          sessionID     = getDriver().getSession().getID();

      String readSQL  = "SELECT * FROM PRResource" +
                        " WHERE prIsOpen <> 0" +
                        " AND prIsRole = 0" +
                        " AND prTrackMode = 2";
      String writeSQL = "SELECT * FROM PRTemporary WHERE prID = -1";
      try {

         readCursor = getDriver().getRepository().select(readSQL);
         writeCursor = getDriver().getRepository().select(writeSQL);
         while (readCursor.moveNext()) {
            rightsLevel = 0;
            if (checkRight(readCursor,CAN_ENTERTIME)) rightsLevel = rightsLevel + ENTER_TIME_RIGHT;
            if (checkRight(readCursor,CAN_APPROVEACTUALS)) rightsLevel = rightsLevel + APPROVE_RIGHT;
            if (readCursor.getFieldString(FLD_NAME).equals(userName.stringValue())) rightsLevel = rightsLevel + USER_RIGHT;

            if (rightsLevel > 0) {
               writeCursor.addNew();
               writeCursor.setFieldString(FLD_NAME, "ResourceRights");
               writeCursor.setFieldInt(FLD_SESSIONID, sessionID);
               writeCursor.setFieldInt(FLD_RECORDID1, readCursor.getFieldInt(FLD_ID));
               writeCursor.setFieldInt(FLD_RECORDID2, user.getValue(session_, FLD_TW_ID).intValue());
               writeCursor.setFieldInt(FLD_FLAGS, rightsLevel);
               writeCursor.update();
            }
         }

      } catch (Exception e) {
         if (e instanceof ABTException) exception = (ABTException)e;
         else e.printStackTrace();
      }

   }
}