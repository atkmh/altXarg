
package com.abtcorp.hub;

/*
 * ABTExtendedPropertyList.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.*;
import com.abtcorp.parser.*;
import java.util.Enumeration;
import java.lang.Math;

/**
 * ABTExtendedPropertyList contains the
 * list of name/value pairs needed to manage extended properties
 * <p>
 * @see com.abtcorp.hub.ABTProperty
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTExtendedPropertyList extends ABTValue
{
   private ABTSortedArray data;
   private static final int ENUM_VALUES = 0;
   private static final int ENUM_KEYS   = 1;

//=============================================================================
// Constructor/Deconstructor
//=============================================================================

  /**
   * Default constructor
   * @exception java.lang.IllegalArgumentException If size is negative.
   */
   public ABTExtendedPropertyList() {  data = null; }

   /**
   * remove all pending references
   */
	protected final void destroy()
	{
	   if (data != null)data.clear();
	   data = null;
	}

   /**
   * remove all pending references
   */
   public void finalize() { destroy();  }

   /*
   * return this
   * @see cvom.abtcorp.core.ABTValue
   * @return
   */
   public ABTValue eval() { return this; }

  /**
   * Return a string that describes me.
   */
   public synchronized String toString() { return data.toString();  }

//================================================================================
// adding / removeing elements
//================================================================================
   /**
   * Remove all of my elements.
   */
   public synchronized void clear()
   {
	   if (data != null)data.clear();
	   data = null;
   }


  /**
   * Remove the element at a particular index.
   * @param index The index of the element to remove.
   * @return The object removed.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
   public synchronized ABTValue remove( ABTValue key )
   {
    ABTExtendedProperty fkey = findKey(key.intValue());
    if (fkey == null) return null;
    data.remove(fkey);
    return null;
   }


  /**
   * Add an object with provided key
   * @param key the key of the object
   * @param element the object to add
   * @return added object or ABTError
   */
   public synchronized ABTValue add( ABTValue key, ABTValue element )
   {
    if (key instanceof ABTInteger)
        return add(key.intValue(),element);
    return null;
   }

  /**
   * Add an object with provided key
   * @param key the key of the object
   * @param element the object to add
   * @return added object or ABTError
   */
   public synchronized ABTValue add( int key, ABTValue element )
   {
    try{
        if (data == null){
        data = new ABTSortedArray();
        }
        ABTExtendedProperty fkey = findKey(key);
        if (fkey != null){
            // replacing a property
            fkey.value_ = element;
            }
        else{
            // adding a property
            data.add(new ABTExtendedProperty(key,element));
            }
        return null;
        }
    catch(Exception e){
        return null;
        }
   }

  /**
   * Add an object with provided key
   * @param key the key of the object
   * @param element the object to add
   * @return added object or ABTError
   */
   public synchronized ABTValue add( String key, ABTValue element )
   {
    // this is broken, need a lookup mechanism for strings
    return new ABTError(getClass(), "add(String,ABTValue)",
                        errorMessages.ERR_METHOD_NOT_SUPPORTED, null);
   }



  /**
   * Return true if I contain the provided value
   */
   public boolean containsValue(ABTValue value)
   {
      if (isEmpty()) return false;
      for (int I = 0; I < size(); ++I){
        // look through the values for a match
        if (((ABTExtendedProperty)data.at(I)).compareTo(value) == 0)
            return true;
        }
      return false;
   }


  /**
   * Return true if I contain the provided key
   */
   public boolean containsKey(ABTValue key)
   {  return (containsKey(key.intValue())); }
   
  /**
   * Return true if I contain the provided key
   */
   public boolean containsKey(int key)
   {  return (findKey(key) != null); }

  /**
   * Return true if I contain no entries.
   */
   public boolean isEmpty()
   { return ((data == null) || (data.isEmpty())); }

  /**
   * Return the number of entries that I contain.
   */
    public int size() {
        if (data == null) return 0;
        return data.size();
    }


  /**
   * Return an Enumeration of my unsorted components.
   */
   public synchronized Enumeration elements()
   {
      if (isEmpty()) return null;
      return new EPEnumerator(ENUM_VALUES);
   }

  /**
   * Return an Enumeration of my unsorted components.
   */
   public synchronized Enumeration keys()
   {
      if (isEmpty()) return null;
      return new EPEnumerator(ENUM_KEYS);
   }

//================================================================================
// Getters
//================================================================================
  /**
   * Return  item with provided key.
   */
   public synchronized ABTValue get(ABTValue key)
   {
      if ((key instanceof ABTInteger))
        return get(key.intValue());
      return null;
   }

  /**
   * Return  item with provided key.
   */
   public synchronized ABTValue get(int key)
   {
    ABTExtendedProperty fkey = findKey(key); 
    if (fkey == null) return null;
    return fkey.value_;
   }

  /**
   * Return  item with provided key.
   */
   public synchronized ABTValue get(String key)
   {
      // string keys don't work right now
      return null;
   }

    private ABTExtendedProperty findKey(int key){
        if (isEmpty()) return null;// the list is empty, so it can't be in there

        // do a binary search in the already sorted array
        // for the ABTExtendedProperty with the matching key
        int lo = 0;
        int hi = size()-1;
        ABTExtendedProperty loProp = (ABTExtendedProperty)data.at(lo);
        ABTExtendedProperty hiProp = (ABTExtendedProperty)data.at(hi);
        if (loProp.index_ == key) return loProp;
        if (hiProp.index_ == key) return hiProp;
        // it's not the first or the last, look in the middle
        while (lo < hi){
            int mid = lo + ((hi - lo) >> 1);            
            ABTExtendedProperty midProp = (ABTExtendedProperty)data.at(mid);
            if (midProp.index_ == key)    return midProp;
            // didn't find it yet
            if (midProp.index_ > key) {
                hi = mid - 1;
                if (lo >= hi) break;
                hiProp = (ABTExtendedProperty)data.at(hi);
                if (hiProp.index_ == key) return hiProp;
                }
            else {
                lo = mid + 1;
                if (lo >= hi) break;
                loProp = (ABTExtendedProperty)data.at(lo);
                if (loProp.index_ == key) return loProp;
                }
            }
       // didn't find it anywhere 
       return null;
       }
        
    private class ABTExtendedProperty implements ABTComparable
        {
        public int index_;
        public ABTValue abtIndex_;
        public ABTValue value_;
        public ABTExtendedProperty (int index, ABTValue value){
            index_ = index;
            value_ = value;
            abtIndex_ = null;
            }
            
        public String toString(){
            return new String(String.valueOf(index_)+ "="+value_.toString());
            }
            
        public int compareTo(Object other){
            // this will throw if other isn't an ABTExtendedProperty
            ABTExtendedProperty p2 = (ABTExtendedProperty)other;
            if (index_ > p2.index_)
                return 1;
            if (index_ < p2.index_)
                return -1;
            return 0;
            }
            
        public boolean equals(Object other){
            if (other instanceof ABTExtendedProperty)
                return index_ == ((ABTExtendedProperty)other).index_;
            return false;
            }
        }

    private class EPEnumerator implements Enumeration
    {
        private Enumeration enumer;
        private int which;
        public EPEnumerator(int KeysOrValues){
            enumer = data.elements();
            which = KeysOrValues;
        }
        
        public boolean hasMoreElements(){
            return enumer.hasMoreElements();
            }
        public Object nextElement(){
            ABTExtendedProperty prop = (ABTExtendedProperty)enumer.nextElement();
            if (which == ENUM_VALUES)
                return prop.value_;
            // return an ABTInteger for the index, but only create it once                
            if (prop.abtIndex_ == null)
                prop.abtIndex_ = new ABTInteger(prop.index_);
            return prop.abtIndex_;
            }
    }
}



