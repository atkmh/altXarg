package com.abtcorp.io.siterepo;

/*
 * Calendar.java 08/11/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-11-98    LZX         Initial Implementation
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  Calendar is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTSiteRepoDriver object.
 *
 *  <pre>
 *       Calendar rt = new Calendar(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTSiteRepoDriver
 */

public class Calendar extends ABTSiteRepoHelper
{
   private Hashtable calHash_ = null;

/**
 *    Calendar constructor.
 *    @param   driver: the reference to the driver.
 */
   Calendar(ABTRepositoryDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_CALENDAR, OBJ_CALENDAR);
      site_ = parent;
      reqParams_.putItemByString(OFD_SITE, site_);
      matchField_ = OFD_NAME;
     	calHash_ = new Hashtable();
   }

/**
 * Set base calendar references after the calendar objects have been populated.
 * @param cur  the cursor used to populate.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   protected void populateOthers(ABTCursor cur) throws ABTException
   {
	   Long prID = null;
	   Long baseID = null;

      int count = cur.getRecordCount();
      if (count == 0)
         return;   // get out if the cursor is empty

      // go back to the top of the calendar cursor. iterate thru
      // each row in the result set and set the base calendar reference.
      cur.moveFirst();
      do
      {
         // retrieve the base calendar ID from the cursor.
         baseID = new Long (cur.getFieldInt(FLD_BASECALENDARID));

         if ( baseID.intValue() > 0)
         {
            // if baseID is not null, retrieve both the calendar object
            // and the base calendar object from the hash table.
            prID = new Long (cur.getFieldInt(FLD_ID));
            ABTObject cal = (ABTObject) calHash_.get(prID);
            if (cal == null)
               processError("populateOthers",
                           errorMessages.ERR_OBJECT_NOT_FOUND,
                           "Calendar not found in hash table. prID = " + prID.toString());

            ABTObject base = (ABTObject) calHash_.get(baseID);
            if (base == null)
               processError("populateOthers",
                           errorMessages.ERR_OBJECT_NOT_FOUND,
                           "Base calendar not found in hash table. prBaseCalendarID = " + baseID.toString());

            // set the base calendar object reference
            setValue(cal, OFD_BASECALENDAR, base);
         }

      }  while (cur.moveNext()); // end do-while()
   }

/**
 * Update an existing object in the object space.
 *	@param object: the object to be updated.
 *	@return ABTValue: a reference to the object updated or an ABTError.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue update(ABTCursor cur, ABTObject object, ABTRemoteIDRepository id, boolean updateSpace) throws ABTException
   {
      super.update(cur, object, id, updateSpace);
      
      // add calendar object to hashtable
      long prID = cur.getFieldInt(FLD_ID);
		calHash_.put(new Long(prID), object); // save for quickly locating calendar object
      
      return object;
   }
   

/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(ABTCursor cur, String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
      ABTObject object = (ABTObject) super.create(cur, type, id, params);

      // add calendar object to hashtable
      long prID = cur.getFieldInt(FLD_ID);
		calHash_.put(new Long(prID), object); // save for quickly locating base calendar object
      
      return object;
   }

/**
 *  Retrieves the calendar hash table.
 *  @return the hash table
 *  @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public Hashtable getHash() throws ABTException
   {
      return calHash_;
   }
   
   
}