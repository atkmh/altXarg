/*
 * $Header: d:\sanani\src\com\abtcorp\blob\ABTCurve.java, 24, 12/16/98 5:33:46 PM, Benoit Menendez$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.blob;

import com.abtcorp.core.*;

/**
 * The ABTCurve class represents time phased values in the ABT repository, such as actuals,
 * estimates and availability as a function of time.
 *
 * The methods for this class closely match the curve API as documented in the API documentation for
 * ABT RMS 3.0.
 *
 * @author  $Author: Benoit Menendez$
 * @version $Revision: 24$
 */

public final class ABTCurve extends ABTValue
{
   private static final long serialVersionUID = -7427825131539639085L;
/**
 * This constant specifies a rate curve.
 */

   public static final int RATECURVE  = 1;

/**
 * This constant specifies a value curve.
 */

   public static final int VALUECURVE = 2;

   private int            type_;
   private ABTSegmentList segments_;

/**
 * Class constructor specifying the type of curve and the default value.
 * @param type the type of curve (either <code>RATECURVE</code> or <code>VALUECURVE</code>)
 * @param rate the default rate
 * @see  #RATECURVE
 * @see  #VALUECURVE
 */

   public ABTCurve(int type, double rate) {type_ = type; segments_ = new ABTSegmentList(rate);}

/**
 * Class constructor specifying the type of curve.
 * @param type the type of curve (either <code>RATECURVE</code> or <code>VALUECURVE</code>)
 * @see  #RATECURVE
 * @see  #VALUECURVE
 */

   public ABTCurve(int type) {this(type, 0);}

/**
 * Class constructor.
 */

   public ABTCurve() {this(VALUECURVE);}

/**
 * Returns the type of this curve.
 *
 * @return  <code>RATECURVE</code> or <code>VALUECURVE</code>
 * @see  #RATECURVE
 * @see  #VALUECURVE
*/

	public final int getType() {return type_;}

/**
 * Returns the segments of this curve.
 *
 * @return  a list of segments
*/

   public final ABTSegmentList getSegments() {return segments_;}

/**
 * Returns the default rate of this curve.
 *
 * @return  the default rate
*/

	public final double getDefault() {return segments_.getDefault();}

/**
 * Sets the default rate of this curve.
 *
 * @param  rate   the rate
*/

	public final void setDefault(double rate) {segments_.setDefault(rate);}

   public final ABTTime	getStart()  {return segments_.getFirst();}
	public final ABTTime getFinish() {return segments_.getLast();}

	public final boolean isDefined(ABTTime time)                   {return segments_.isDefined(time);}
	public final boolean isDefined(ABTTime start, ABTTime finish)  {return segments_.isDefined(start, finish);}
	public final double	getRate(ABTTime time)                     {return segments_.getRate(time);}
	public final double	getSum(ABTTime start, ABTTime finish)     {return segments_.getSum(start, finish);}
	public final double	getSum()                                  {return getSum(null, null);}
	public final boolean isZero()                                  {return segments_.isZero();}

   public final void clipSegment(ABTTime start, ABTTime finish)   {segments_.clipSegment(start, finish);}
   public final void resetSegment(ABTTime start, ABTTime finish)  {segments_.resetSegment(start, finish);}

	public final void	addRate(double rate)    {if (rate != 0) segments_.addRate(rate);}
	public final void	subRate(double rate)    {if (rate != 0) segments_.subRate(rate);}
	public final void	scaleRate(double rate)  {if (rate != 1) segments_.scaleRate(rate);}
	public final void	divideRate(double rate) {if (rate != 1) segments_.divideRate(rate);}

   private final ABTSegment segment(ABTTime start, ABTTime finish, double value, ABTCalendar calendar)
   {
	   ABTDate startDate  = new ABTDate(start, false);
	   ABTDate finishDate = new ABTDate(finish, true);

   	if (calendar != null) calendar = calendar.flat(startDate, finishDate);

	   if (type_ == RATECURVE || value == 0) return new ABTSegment(start, finish, value, calendar);

   	if (calendar == null) return new ABTSegment(start, finish, value / ABTTime.diff(start, finish), null);

  	   int duration = calendar.diffWorktime(start, finish);

	   if (duration == 0) {
	      calendar.setShifts(startDate, finishDate, ABTShiftList.WORK);
	   	
         duration = calendar.diffWorktime(start, finish);
      }

      if (duration != 0) return new ABTSegment(start, finish, value / duration, calendar);

      return new ABTSegment(start, finish, value / ABTTime.diff(start, finish), null);
   }

	public final void addSegment(ABTTime start, ABTTime finish, double value, ABTCalendar calendar)
	{
	   ABTSegmentList segments = new ABTSegmentList(0);

	   segments.setSegment(segment(start, finish, value, calendar));

	   segments_.addSegments(segments);
	}

	public final void subSegment(ABTTime start, ABTTime finish, double value, ABTCalendar calendar)
	{
	   ABTSegmentList segments = new ABTSegmentList(0);

	   segments.setSegment(segment(start, finish, value, calendar));

	   segments_.subSegments(segments);
	}

	public final void setSegment(ABTTime start, ABTTime finish, double value, ABTCalendar calendar)
	{
	   segments_.setSegment(segment(start, finish, value, calendar));
	}

	public final void scaleSegment(ABTTime start, ABTTime finish, double value, ABTCalendar calendar)
	{
	   ABTSegmentList segments = new ABTSegmentList(1);

	   segments.setSegment(segment(start, finish, value, calendar));

	   segments_.scaleSegments(segments);
	}

	public final void divideSegment(ABTTime start, ABTTime finish, double value, ABTCalendar calendar)
	{
	   ABTSegmentList segments = new ABTSegmentList(1);

	   segments.setSegment(segment(start, finish, value, calendar));

	   segments_.divideSegments(segments);
	}

	public final void	addCurve(ABTCurve curve)
	{
	   if (curve == null) return;

	   segments_.addSegments((ABTSegmentList)curve.segments_.clone());
	}

	public final void	subCurve(ABTCurve curve)
	{
	   if (curve == null) return;

	   segments_.subSegments((ABTSegmentList)curve.segments_.clone());
	}

	public final void	setCurve(ABTCurve curve)
	{
	   if (curve == null) return;

	   segments_.setSegments((ABTSegmentList)curve.segments_.clone());
   }
	
	public final void	scaleCurve(ABTCurve curve)
	{
	   if (curve == null) return;

	   segments_.scaleSegments((ABTSegmentList)curve.segments_.clone());
	}
	
	public final void	divideCurve(ABTCurve curve)
	{
	   if (curve == null) return;

	   segments_.divideSegments((ABTSegmentList)curve.segments_.clone());
	}
	
	public final ABTTime addWorktime(ABTTime time, double value)	{return segments_.addWorktime(time, value);}
	public final ABTTime subWorktime(ABTTime time, double value)	{return segments_.subWorktime(time, value);}
	
	public final void shift(ABTCalendar calendar, int offset)
	{
	   ABTSegmentList segments = new ABTSegmentList(segments_.getDefault());
		
		ABTTime finish = null;
		
		for (int index = 0; index < segments_.size(); index++) {
   	   ABTSegment segment = segments_.getSegment(index);
			
			ABTTime start = segment.getStart();
			
			if (calendar == null) start = offset >= 0 ? start.add(offset) : start.sub(-offset);
			else {
				start = offset >= 0 ? calendar.addWorktime(start, offset) : calendar.subWorktime(start, -offset);
				
				start = calendar.nextWorktime(start);
			}
			
			if (finish != null && start.compareTo(finish) < 0) start = finish;	// bump
			
			double value = segment.getRate();
			
			ABTCalendar tmp = segment.getCalendar();
			
			if (tmp != null) {	// preserve duration
				int duration = tmp.diffWorktime(segment.getStart(), segment.getFinish());
				
				if (calendar != null) tmp = calendar;	// replace calendar
			
				finish = tmp.addWorktime(start, duration);

				if (type_ == VALUECURVE) value *= duration;
			} else {					// preserve elapsed duration
				int duration = ABTTime.diff(segment.getStart(), segment.getFinish());
				
				finish = start.add(duration);

				if (type_ == VALUECURVE) value *= duration;
			}

		   segments.setSegment(segment(start, finish, value, tmp));
		}

		segments_ = segments;
	}

	public final int 		diffWorktime(ABTTime start, ABTTime finish)					{return segments_.diffWorktime(start, finish);}
	public final void 	floor(ABTTime start, ABTTime finish, double rate)			{segments_.floor(start, finish, rate);}
	public final void 	ceil(ABTTime start, ABTTime finish, double rate)			{segments_.ceil(start, finish, rate);}
	public final boolean lessThan(ABTTime start, ABTTime finish, double rate)		{return segments_.lessThan(start, finish, rate);}
	public final boolean greaterThan(ABTTime start, ABTTime finish, double rate)	{return segments_.greaterThan(start, finish, rate);}
	
	public final int 		diffWorktime()             {return diffWorktime(null, null);}
	public final void 	floor(double rate)			{floor(null, null, rate);}
	public final void 	ceil(double rate)				{ceil(null, null, rate);}
	public final boolean lessThan(double rate)		{return lessThan(null, null, rate);}
	public final boolean greaterThan(double rate)	{return greaterThan(null, null, rate);}

   public String toString() {return "ABTCurve{\n" + segments_ + "\n}";}

	public synchronized Object clone()
	{
      ABTCurve result = (ABTCurve)super.clone();

      result.segments_ = (ABTSegmentList)segments_.clone();

	   return result;
	}

   public ABTValue eval() {return (ABTValue)clone();}


}