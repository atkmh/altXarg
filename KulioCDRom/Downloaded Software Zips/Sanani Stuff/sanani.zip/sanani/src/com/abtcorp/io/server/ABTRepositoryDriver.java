package com.abtcorp.io.server;
/*
 * ABTRepositoryDriver.java 03/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98      SA          Initial Implementation
  * 03-26-98		SOB			Initial Documentor
  * 03-31-98      SOB         Add a default constructor
  * 04-15-98      SOB         Add getProjectNameList() method
  * 04-21-98      SOB         Add QRY strings for reading a project
  * 05-13-98      SOB         Relocate QRY strings to ABTDriverConstants
  * 05-22-98      SOB         Relocate 2 useful methods from ProjectPopulator class
  * 06-09-98      SDP         Changed getDataRepositoryList method to return an ABTArray
  * 06-19-98      LZX         change setPropertyValues() from package default to public.
  * 06-23-98      TOMO        Added the repository loginAs call.
  * 07-09-98      SOB         Transaction support
  * 07-10-98      SOB         Reinstate code that was dropped when transaction support went in
  * 07-13-98      SOB         Added getUser() and getPassword()
  * 07-14-98      SOB         Removed setPropertyValues() method and its associated support methods and data items
  * 07-23-98      LZX         added login params to open(), added checkInitStatus().
  * 08-03-98      SOB         changed to com.abtcorp.io.server package
  * 08-12-98      LZX         changed open() to retrieve login arguments from hashtable.
  * 12-15-98      SOB         #684
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */


import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.io.*;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

/**
 *  ABTRepositoryDriver is the base class for all drivers which will access the ABT Repository.
 *
 *			This class is not meant to be instantiated directly, but to be extended by Repository
 *			drivers which access the ABT Repository in an application-specific way, e.g.,
 *
 *  <pre>
 *       public class PMWRepositoryDriver extends ABTRepositoryDriver
 *       {
 *         ... override populate() and save() methods for PMW-specific requirements ...
 *       }
 *
 *  </pre>
 *
 * @version     $Revision: 34$
 * @author      S. Asire
 * @author		 S. Bursch
 * @see         ABTServerDriver
 */

public class ABTRepositoryDriver extends ABTServerDriver implements ABTNames, ABTEnum
{
   private ABTSession      session_;
   private ABTRepository   repository_;
   private ABTLicense      license_;

   private String          server_;
   private String          repositoryName_;
   private String          user_;
   private String          password_;
   private String          product_;

   private static final int CMD_LISTREPO = 0;
   private static final int CMD_UNKNOWN = 1;
   
   public static final String USER_SELECT = "select prID, prName from PRUser where prID = ";

/**
 *		Creates an ABTRepositoryDriver that is not associated with an ABTObjectSpace.
 *    Associating an object space with this driver will be deferred until later.
 */

   public ABTRepositoryDriver() {/*implicit call to super() here*/}

/**
 *		Creates an ABTRepositoryDriver that is associated with an ABTObjectSpace.
 *		@param space  The ABTObjectSpace object with which this ABTRepositoryDriver is
 *		associated.
 */

   public ABTRepositoryDriver(ABTObjectSpace space,ABTUserSession session)
   {
    super(space,session);
   }

/**
 *		Creates an ABTRepositoryDriver that is associated with an ABTObjectSpace. Use
 *		additional parameters to effect an ABT Repository login:
 *		@param space  The ABTObjectSpace object with which this ABTRepositoryDriver is
 *		associated.
 *		@param server The name of the server machine on which the ABT Repository is located.
 *		@param repository  The name of the repository.
 *		@param user	The username to be used for logging on to the ABT Repository.
 *		@param password  The password associated with user.
 *		@param product  The product name against which licensing constraints will be applied.
 *		@exception ABTException Thrown if an unrecoverable error occurs.
 *		@exception ABTInvalidLoginException Thrown if cannot login to the repository.
 *		@exception ABTInvalidLicenseException Thrown if an unrecoverable error occurs.
 *		@exception ABTInvalidRepositoryException Thrown if an unrecoverable error occurs.
 */

   public ABTRepositoryDriver(ABTObjectSpace space, ABTUserSession userSession, String server, String repository, String user, String password, String product) throws ABTException, ABTInvalidLoginException, ABTInvalidLicenseException, ABTInvalidRepositoryException
   {
      super(space,userSession);
      user_ = user;
      repositoryName_ = repository;
      server_ = server;
      password_ = password;
      product_ = product;

      if (session_ == null) {
         if (user_ == null && password_ == null) session_ = ABTSession.login();
			else												 session_ = ABTSession.loginAs(user_, password_);
      }

      if (session_ == null) throw new ABTInvalidLoginException();
   }

/**
 *		Sets user name for Repository login.
 *		@param user  The username which will be used to login to the ABT
 *		Repository.
 */

   protected void setUser(String user)             {user_ = user;}

/**
 *		Sets password for Repository login.
 *		@param password  The password which will be used to login to the ABT
 *		Repository.
 */

   protected void setPassword(String password)     {password_ = password;}

/**
 *		Sets ABT Repository name for Repository login.
 *		@param  repository  The name of the ABT Repository to which a connection will be
 *		established.
 */

   protected void setRepositoryName(String repository) {repositoryName_ = repository;}

/**
 *		Sets product name for verifying licensing constraints.
 *		@param  product The name of the ABT product against which licensing constraints will
 *		be verified.
 */

   protected void setProduct(String product)       {product_ = product;}

/**
 *		Sets repository session.
 *		@param  session ABTSession handle.
 */

   protected void setSession(ABTSession session)       {session_ = session;}

/**
 *		Sets repository.
 *		@param  repo ABTRepository handle.
 */

   protected void setRepository(ABTRepository repo)       {repository_ = repo;}

/**
 *		Opens a connection to a specific ABT Repository.  Verifies license constraints.  The
 *		server, repository name, user, password, etc., must have been previously set before
 *		this method can be called.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return ABTValue an ABTError if unsuccessful; null if successful
 */

   public ABTValue open(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue ret = null;    // assume successful open
      String repoName = null;
      String userName = null;
      String password = null;
      String product = null;

      // first see if there is any login arguments in the hashtable
      if (args != null && args.size() > 0)
      {
         repoName = getStringValue(args, KEY_REPONAME);
         userName = getStringValue(args, KEY_USERNAME);
         password = getStringValue(args, KEY_PASSWORD);
         product  = getStringValue(args, KEY_PRODUCT);
      }

      // NOTE: We are not checking if any of the login arguments is null because
      // the PVISION allowes user to input the login information if they are
      // insufficient. However, if the driver runs on a different machine from
      // the app, this will not work. We may need to support "loginAs" only at
      // that time!!!

      if (repository_ != null)
      {
	      // If there is already a repository connected, check to see if the existing
	      // repository name matches the new repo name. If they match, return to the
	      // user without changing anything. Otherwise release the current repoistory
	      // and reconnect.
	      String curName = repository_.getName();
      	if (curName.equals(repoName))
      	{
      	   // reset repositoryName_ in case it wasn't set before
      	   // (the PVision used the default repository to connect)
            repositoryName_ = repoName;
            return null;
      	}

         repository_.release();
         repository_ = null;
      }

		// reset the repository login and product information, but only if they are present in
		// the input args
		//
      if (repoName != null) repositoryName_ = repoName;
      if (userName != null) user_ = userName;
      if (password != null) password_ = password;
      if (product  != null) product_ = product;

      // login to the repository server
		if (session_ == null)
		{
			if (user_ == null && password_ == null) session_ = ABTSession.login();
			else												 session_ = ABTSession.loginAs(user_, password_);
         if (session_ == null) return ret = createErrorObject(MOD_OPEN,
                                                              EXC_INVALID_USERID_OR_PASSWORD + " '" + repositoryName_ + "'");
	   }

      // Verify license.  The product name must NOT be null.
      if (product_ == null) 
      {
         session_.release();
         return ret = createErrorObject(MOD_OPEN, EXC_INVALID_PRODUCT);
      }
      
      license_ = session_.openLicense(product_);

      if (license_ == null)
      {
         session_.release();
         return ret = createErrorObject(MOD_OPEN, EXC_INVALID_LICENSE);
      }

      if (repository_ == null) repository_ = session_.connect(repositoryName_);

      if (repository_ == null)
      {
         session_.release();
         session_ = null;
         return ret = createErrorObject(MOD_OPEN, EXC_UNABLE_TO_CONNECT + " '" + repositoryName_ + "'");
      }

	   // reset repositoryName_ in case it wasn't set by the user and
	   // the PVision used the default repository to connect
	   if (repositoryName_ == null)
         repositoryName_ = repository_.getName();

      // Successful open; return null
      return ret;
   }


/**
 *		Populates the ABTObjectSpace with objects from the ABT Repository. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.  If an error occurs, an ABTError is returned.
 */
   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      return createErrorObject(MOD_POPULATE, EXC_NOTIMPLEMENTED);
   }

/**
 *		Saves the ABTObjects identified in the ABTObjectSet object back to the associated
 *		ABT Repository. This method MUST be overridden by the application-specific class
 *		that extends this class.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *    @return ABTValue ABTError if an error occurred; null, otherwise.
 */
   public ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      return createErrorObject(MOD_SAVE, EXC_NOTIMPLEMENTED);
   }

/**
 *		Closes a connection to a specific ABT Repository.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public ABTValue close(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      if (repository_ != null) {
         repository_.release();
         repository_ = null;
      }

      if (license_ != null) {
         license_.release();
         license_ = null;
      }

      if (session_ != null) {
         session_.release();
         session_ = null;
      }
      return (ABTValue) null;
   }


/**
 *    Get the product name used for verifying licensing constraints.
 *    @return String The product name that this driver is licensed for.
 */

   public String getProduct()                   {return product_;}

/**
 *		Get the ABT Repository name of the repository with which this reader is associated.
 *		@return  The String value of the Repository name.
 */

   public String			getRepositoryName()		{return repositoryName_;}

/**
 *		Get the ABT Repository object.
 *		@return  The ABTRepository object.
 */

   public ABTRepository getRepository()         {return repository_;}

/**
 *		Get the ABTSession object.
 *		@return  The ABTSession object.
 */

   public ABTSession    getSession()            {return session_;}

/**
 *		Get the user ID.
 *		@return  The user ID.
 */

   public String    getUser()            {return user_;}

/**
 *		Get the user's password.
 *		@return  The user's password string.
 */

   public String    getPassword()            {return password_;}


/**
 *		Get a list of ABT Repository names.
 *		@return  An array of names of ABT Repositories to which connections can be
 *		established.
 *		@exception ABTException Thrown if an unrecoverable error occurs.
 */

   private ABTHashtable getDataRepositoryList()
   {
      ABTRepository system = session_.getSystem();
      ABTCursor cursor = system.select("select prName from PRRepository");
      ABTHashtable names = new ABTHashtable();
      while(cursor.moveNext( )) {
         ABTString reponame = new ABTString(cursor.getFieldString("prName"));
         names.put( reponame,reponame);
      }

      cursor.release();								// release the ABTCursor
      system.release();								// release the ABTRepository

      return names;
   }

/**
 *	Makes sure that the object space is set and the user is connected to a repository.
 * @return true if success.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean checkInitStatus() throws ABTException
   {
      // make sure that the object space is set.
      if (getSpace() == null)
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->checkInitStatus", 
                          errorMessages.SERVER_ERR_NO_OBJECT_SPACE,
                          "Object space needs to be specified."));

      // make sure that the user session is set.
      if (getUserSession() == null)
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->checkInitStatus", 
                          errorMessages.SERVER_ERR_NO_USER_SESSION,
                          "User session needs to be specified."));

		// make sure that the user is connected to a repository
  		if (getRepository() == null)
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->checkInitStatus", 
                          errorMessages.SERVER_ERR_NO_REPO,
                          "An ABT Repository needs to be connected"));

      return true;
   }

   protected ABTError createErrorObject(String method, String errMsg)
   {
      return new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + ":" + method, 
                          errorMessages.SERVER_ERR_ERROR,
                          errMsg);
   }

   public ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue ret = null;

      try
      {
         switch (getExecuteCmd(args))
         {
            case CMD_LISTREPO:
               ret = (session_ != null) ? (ABTValue) getDataRepositoryList() :
                                          createErrorObject(MOD_EXECUTE, EXC_REPOSESSION_NOT_SET);
               break;

            case CMD_UNKNOWN:
            default:
               ret = createErrorObject(MOD_EXECUTE, EXC_INVALID_COMMAND);
               break;
         }
      }
      catch (ABTException e)
      {
         ret = createErrorObject(MOD_EXECUTE, e.getMessage());
      }
      finally
      {
         return ret;
      }
   }

   private int getExecuteCmd(ABTHashtable args) throws ABTException
   {
      int ret = CMD_UNKNOWN;

      //
      // For the Repository Driver, only one execute command is supported:
      // get a list of repositories
      //
      String valCmd = getStringValue(args, KEY_COMMAND);
      if (valCmd == null)
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->getExecuteCmd", 
                          errorMessages.SERVER_ERR_MISSING_CMD_KEYWORD,
                          null));
      if (!valCmd.equalsIgnoreCase(CMD_LIST))
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->getExecuteCmd", 
                          errorMessages.SERVER_ERR_INVALID_CMD,
                          null));
      String valType = getStringValue(args, KEY_TYPE);
      if (valType == null)
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->getExecuteCmd", 
                          errorMessages.SERVER_ERR_MISSING_TYPE_KEYWORD,
                          null));
      if (!valType.equalsIgnoreCase(TYPE_REPOSITORY))
         throw new ABTException( new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + "->getExecuteCmd", 
                          errorMessages.SERVER_ERR_INVALID_TYPE,
                          null));
      ret = CMD_LISTREPO;

      return ret;
   }


/**
 * Make sure the input parameters are set.
 * @param space: the object space.
 * @param session: the user session.
 * @param args: the hashtable for additional params.
 * @param caller: the module that calls this method.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTValue checkParms(ABTObjectSpace space, ABTUserSession session, ABTHashtable args, String caller)
   {
      String repoName = null;
      ABTValue val = null;

      // make sure the space is set.
      if (space == null)
         return new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + ":" + caller, 
                          errorMessages.SERVER_ERR_NO_OBJECT_SPACE,
                          "Object space needs to be specified.");
      else
         setSpace(space);

      // make sure the user session is set.
      if (session == null)
         return new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + ":" + caller, 
                          errorMessages.SERVER_ERR_NO_USER_SESSION,
                          "User session needs to be specified.");
      else
         setUserSession(session);

      // make sure the hashtable is not null
      if ((args == null) || args.isEmpty())
         return new ABTError(COMP_SERVERDRIVER, 
                          COMP_SERVERREPODRIVER + ":" + caller, 
                          errorMessages.SERVER_ERR_INVALID_HASH,
                          "Hashtable must be populated.");

      // get repo name from hash table
      if (caller.equals(MOD_POPULATE))
         repoName = getStringValue(args, KEY_SOURCENAME);
      else if (caller.equals(MOD_SAVE))
         repoName = getStringValue(args, KEY_DESTINATIONNAME);
      else if (caller.equals(MOD_EXECUTE))
         repoName = getStringValue(args, KEY_REPONAME);

      // if repo name is not null, reconnect to the repository
      if (repoName != null)
      {
         // open() uses KEY_REPONAME so we need to reset it.
         args.putItemByString(KEY_REPONAME, new ABTString(repoName));
         val = open(getSpace(), getUserSession(), args);
      }

      return val;
   }


/**
 *    Processes an error situation raised by the caller. Currently, disconnects from the 
 *    repository and throws an ABTException for all types of errors.
 *    @param component: the component in which error occurrred. 
 *    @param method: the method in which error occured. 
 *    @param code: the error code
 *    @param info: further information describing the error condition
 *    @return the severity level (only 1 for now)
 *    @exception ABTException thrown for all error conditions currently
 */
 public int processError(String component, String method, ABTErrorCode code, Object info) throws ABTException
 {    
   int severity = 1; 
   
   // Construct an ABTError
   ABTError err = new ABTError(component, method, code, info);
   
   // all errors are severity 1 for now
   if (severity == 1)
   {
      // throw an ABTException
      throw new ABTException(err);
   }
   
   return severity;
 }

/**
 *    Gets the user name (given the user ID) from an ABT Repository.
 *    @param userID is the ID of the user whose user name will be returned 
 *    @return the ABTString containing the user name; null if input user ID is invalid
 */
   public ABTString getUserName(int userID)
   {
      ABTString ret = null;
      
      //
      // If the input userID is greater than zero, then it should represent a valid user in the
      // PRUser table in an ABTRepository.   If the input userID is zero or less, it cannot represent
      // a valid user and so return null to the caller.  If an error occurs in positioning on the
      // PRUser tuple, return "UNKNOWN" to the caller.
      //
      if ( userID > 0 )
      {
         ABTRepository system = getSession().getSystem();
         ABTCursor cur = system.select(USER_SELECT + userID);

         ret  = (cur.moveFirst() ? (ABTString) cur.getField(FLD_NAME) : new ABTString(UNKNOWN));
         
         cur.release();
         system.release();
      }
      
      return ret;
      
   }

}