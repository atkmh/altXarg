package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTSortedArray;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class PeriodPopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   public PeriodPopulator() {}
   public PeriodPopulator(ABTRepositoryDriver driver) {super(driver);}

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet periods = getObjectSet(OBJ_TW_TIMEPERIOD);

      if (periods == null || cursor_ == null) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      timePeriods_ = new ObjectIDSortedArray(new TWObjectComparator(session_));
   	timePeriods_.setSize(cursor_.getRecordCount());
   	
   	while(cursor_.moveNext()) {
         ABTObject period = (ABTObject)addObject(periods);
         timePeriods_.add(period);
   		updateStatus(period);
      }

      closePopulatorCursor();

      return periods;
   }

   protected ABTValue addObject(ABTObjectSet periods)
   {
      ABTObject period = (ABTObject)periods.addNew(session_);
      period.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
      period.setValue(session_,FLD_TW_NAME,cursor_.getField(FLD_NAME));
      period.setValue(session_,FLD_TW_START,cursor_.getField(FLD_START));
      period.setValue(session_,FLD_TW_FINISH,cursor_.getField(FLD_FINISH));
      RemoteID.setRemoteID(period,session_);
      return period;
   }
}