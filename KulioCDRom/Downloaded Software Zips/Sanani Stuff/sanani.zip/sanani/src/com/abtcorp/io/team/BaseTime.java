package com.abtcorp.io.team;

import java.net.URL;
import java.net.URLConnection;
import java.io.DataInputStream;

public class BaseTime
{
   private static long startTime_ = -1;
   private static long baseTime_ = -1;

   public static void setStartTime(long millis)
   {
      startTime_ = millis;
   }

   public static void setStartTime()
   {
      if(startTime_ < 0) {
         setStartTime(System.currentTimeMillis());
      }
   }

   public static void setBaseTime(long millis)
   {
      if(baseTime_ < 0) {
         baseTime_ = millis;
      }
   }

   public static void setBaseTime(String protocol, String server, String servlet, int port)
   {
      if (baseTime_ < 0) {
         // Make sure the base time is set for the objects
         try {
            if(server != null && server.length() > 0) {
               DataInputStream stream = null;
               URLConnection connection = null;
               URL url = null;
               if (port > 0) url = new URL(protocol, server, port, "/servlet/" + servlet + "/basetime");
               else          url = new URL(protocol, server, "/servlet/" + servlet + "/basetime");
               
               if (url != null) {
                  connection = url.openConnection();
                  connection.setDoInput(true);
                  connection.setDoOutput(false);
                  connection.setUseCaches(false);
               }
               
               if (connection != null) {
                  stream = new DataInputStream(connection.getInputStream());
                  // Based on the servlet's time.
                  baseTime_ = stream.readLong();
                  stream.close();
               }
            }

         } catch (Exception e) {
            System.out.println("Servlet connection failed - using local clock time");
         }
      }
   }

   public static long getElapsedTime()
   {
      if(startTime_ > 0) {
         return System.currentTimeMillis() - startTime_;
      }
      return 0;
   }
   public static long getStartTime()             {return startTime_;}
   public static long getBaseTime()              {return (baseTime_ == -1) ? System.currentTimeMillis() : baseTime_;}
}