/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTValue.java, 20, 12/7/98 5:24:08 PM, Benoit Menendez$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import java.io.*;

public abstract class ABTValue implements ABTComparable, Serializable, Cloneable
{
   private static final long serialVersionUID = 7765451034136487774L;
   public boolean booleanValue()          {return false;}
   public short   shortValue()            {return 0;}
   public int     intValue()              {return 0;}
   public double  doubleValue()           {return 0;}
   public String  stringValue()           {return null;}
   public ABTDate dateValue(boolean pm)   {return null;}
   public ABTTime timeValue()             {return null;}

   public ABTValue eval() {return this;}

   public boolean equals(Object object)
   {
      if (this == object) return true;

      return object != null && object instanceof ABTValue && compareTo(object) == 0;
   }

   public int compareTo(Object object)
   {
      if (object == null) return 1;     
      int hash1 = hashCode();
      int hash2 = object.hashCode();

      if (hash1 == hash2) return 0;

      return hash1 < hash2 ? -1 : +1;
   }

   public Object clone()
   {
      try {
         return super.clone();
      } catch (CloneNotSupportedException exception) {
         return null;
      }
   }

   public String toString() {return stringValue();}

   public String dump(int indent, int level)
   {
      switch (level)
      {
         case 0:
            return ABTUtil.newLine(indent) + toString();
         default:
            return ABTUtil.newLine(indent) + this.getClass() + " : " + toString();
      }
   }

   public static boolean isNull(ABTValue val)
   {
      if ((val == null) || (val instanceof ABTEmpty))
         return true;
      return false;
   }
   public static boolean isEmpty(ABTValue val)
   {
      if ((val != null) && (val instanceof ABTEmpty))
         return true;
      return false;
   }
}