/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTTime.java, 22, 12/7/98 10:22:56 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.io.*;
import java.util.*;
import java.text.*;

public class ABTTime extends ABTImmutableValue
{
   private static final long serialVersionUID = 5938516854891918214L;

   public static final int SecondsPerDay = 86400;

   protected int julian_;
   protected int timeofday_;
   
   public void fromByte(byte[] input){};
   public byte[] fromByte(){ return null;};

   public ABTTime(double julian)                                  {initialize(julian);}
	public ABTTime(int julian, int timeofday)                      {julian_ = julian; timeofday_ = timeofday;}
	public ABTTime(ABTDate date, int timeofday)                    {this(date.getJulian(), timeofday);}
   public ABTTime(ABTDate date, int hour, int minute, int second) {this(date.getJulian(), hour * 3600 + minute * 60 + second);}
   public ABTTime(Calendar calendar)                              {initialize(calendar);}
   public ABTTime(Date date)                                      {initialize(date);}
   public ABTTime(ABTValue value)                                 {this(value.timeValue());}
   public ABTTime(ABTTime time)                                   {julian_ = time.julian_; timeofday_ = time.timeofday_;}

   public final double getJulian()           {return julian_ + (double)timeofday_ / SecondsPerDay;}
   public final int    getJulian(boolean pm) {return pm && timeofday_ == 0 ? julian_ - 1 : julian_;}

   public final int getTimeOfDay()           {return timeofday_;}

   public int hashCode() {return julian_ ^ timeofday_;}

   public int compareTo(Object object) 
   {
   	if (object == null) return 1;
    	
   	return compareTo(((ABTValue)object).timeValue());
   }

   public final int compareTo(ABTTime time)
   {
      if (time == null) return +1;
      
      if (julian_    < time.julian_)    return -1;
      if (julian_    > time.julian_)    return +1;
      if (timeofday_ < time.timeofday_) return -1;
      if (timeofday_ > time.timeofday_) return +1;
      
      return 0;
   }

   public static ABTTime min(ABTTime time1, ABTTime time2)
   {
      if (time1 == null) return time2;
      if (time2 == null) return time1;

      return time1.compareTo(time2) < 0 ? time1 : time2;
   }

   public static ABTTime max(ABTTime time1, ABTTime time2)
   {
      if (time1 == null) return time2;
      if (time2 == null) return time1;

      return time1.compareTo(time2) < 0 ? time2 : time1;
   }

   public static int diff(ABTTime time1, ABTTime time2) {return (time2.julian_     - time1.julian_)     * SecondsPerDay + (time2.timeofday_ - time1.timeofday_);}
   public static int diff(ABTDate date1, ABTTime time2) {return (time2.julian_     - date1.getJulian()) * SecondsPerDay + time2.timeofday_;}
   public static int diff(ABTTime time1, ABTDate date2) {return (date2.getJulian() - time1.julian_)     * SecondsPerDay - time1.timeofday_;}

   public static ABTTime now() {return new ABTTime(Calendar.getInstance());}
	
   public final ABTTime add(int seconds)
	{
		if (seconds == 0) return this;
		if (seconds <  0) return sub(-seconds);

		long tmp = (long)julian_ * SecondsPerDay + timeofday_ + seconds;
			
      int julian    = (int)(tmp / SecondsPerDay);
      int timeofday = (int)(tmp - (long)julian * SecondsPerDay);
		
		return new ABTTime(julian, timeofday);
	}

	public final ABTTime sub(int seconds)
	{
		if (seconds == 0) return this;
		if (seconds <  0) return add(-seconds);
		
		long tmp = (long)julian_ * SecondsPerDay + timeofday_ - seconds;
			
      int julian    = (int)(tmp / SecondsPerDay);
      int timeofday = (int)(tmp - (long)julian * SecondsPerDay);
		
		return new ABTTime(julian, timeofday);
	}

   public Calendar toCalendar() {return ABTDate.toCalendar(julian_, timeofday_);}
   public Date     toDate()     {return ABTDate.toDate(julian_, timeofday_);}

   public final void initialize(double julian)
   {
      long seconds = Math.round(julian * SecondsPerDay);

      julian_    = (int)(seconds / SecondsPerDay);
      timeofday_ = (int)(seconds - (long)julian_ * SecondsPerDay);
   }

   public final void initialize(Calendar calendar)
   {
      if (calendar == null) {julian_ = timeofday_ = 0; return;}

      int day    = calendar.get(Calendar.DATE);
      int month  = calendar.get(Calendar.MONTH) + 1;
      int year   = calendar.get(Calendar.YEAR);
      int hour   = calendar.get(Calendar.HOUR_OF_DAY);
      int minute = calendar.get(Calendar.MINUTE);
      int second = calendar.get(Calendar.SECOND);

      timeofday_ = hour * 3600 + minute * 60 + second;

      julian_ = ABTDate.julian(year, month, day);
   }

   public final void initialize(Date date)
   {
      if (date == null) {julian_ = timeofday_ = 0; return;}

      Calendar calendar = Calendar.getInstance();

      calendar.setTime(date);

      initialize(calendar);
   }

   public final void initialize(ABTTime time)
   {
      if (time == null) {julian_ = timeofday_ = 0; return;}
      
      julian_    = time.julian_;
      timeofday_ = time.timeofday_;
   }
   
   public String  stringValue()           {return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(toDate());}
   public ABTDate dateValue(boolean pm)   {return new ABTDate(this, pm);}
   public ABTTime timeValue()             {return this;}

   public static ABTTime valueOf(String string) {return new ABTTime(new ABTString(string));}

   public String toSQL()    {return "{ts '" + new java.sql.Timestamp(toDate().getTime()) + "'}";}

   // This optimizes the serialization

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeInt(julian_);
      stream.writeInt(timeofday_);
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      julian_    = stream.readInt();
      timeofday_ = stream.readInt();
   }
}