package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTDouble;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class TimeSheetPopulator extends TWPopulator implements TWRepoDriverConstants, IABTTWRuleConstants, ABTNames
{

   protected ABTCursor 	 sumCursor_ = null;
   protected String    	 searchKey_ = null;
   protected String    	 fieldName_ = null;
   protected ABTCursor 	 noteCursor_;
	protected NotePopulator notePopulator_;

   public TimeSheetPopulator(ABTRepositoryDriver driver) {super(driver);}

   public TimeSheetPopulator() {}
	
	public void setNotePopulator(NotePopulator populator) {notePopulator_ = populator;}

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet timesheets = getObjectSet(OBJ_TW_TIMESHEET);

      if (timesheets == null || cursor_ == null) return null;

   	ABTObject resource = null;

   	if (noteCursor_ != null) noteCursor_.moveFirst();
      if (notePopulator_ == null) notePopulator_ = new NotePopulator(getDriver(),OBJ_TW_TIMESHEET, getSpace(), getSession());

   	ABTValue id = null;
   	
   	while(cursor_.moveNext()) {
         try {
         	ABTValue temp = cursor_.getField(FLD_ID);
         	
         	if (id == null || id.intValue() != temp.intValue()) {
         		id = temp;
               // create the timesheet object
            	resource = getResource(cursor_, resource);
            	ABTObject timesheet = (ABTObject)addObject(timesheets, resource);
               addNotesForTimesheet(resource, timesheet);
         	   timesheets.add(session_,timesheet);

               updateStatus(timesheet);
         	}
         } catch (ClassCastException e) {
            // Eat these exceptions if the timesheet comes back as an ABTError.
         }
      }

      closePopulatorCursor();

      if (sumCursor_ != null) sumCursor_.release();
      sumCursor_ = null;

      if (noteCursor_ != null) noteCursor_.release();
      noteCursor_ = null;

      return timesheets;
   }

   protected ABTValue addObject(ABTObjectSet timesheets, ABTObject resource)
   {
      ABTObject timeperiod = null;

   	// find the time period in the cached time period array
   	int index = timePeriods_.indexOf(new Integer(cursor_.getFieldInt(FLD_TIMEPERIODID)));
   	if (index != -1) timeperiod = (ABTObject)timePeriods_.at(index);

      // create the object
   	ABTHashtable args = new ABTHashtable(2,(float)1.0);
      args.put(new ABTString(FLD_TW_TIMEPERIOD),timeperiod);
      args.put(new ABTString(FLD_TW_RESOURCE),resource);
      ABTObject timesheet = (ABTObject)getDriver().getSpace().createObject(session_,OBJ_TW_TIMESHEET,null,args);

      // set the timesheet's properties
   	if (timesheet instanceof ABTObject) {
         timesheet.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
         timesheet.setValue(session_,FLD_TW_STATUS,cursor_.getField(FLD_STATUS));
         timesheet.setValue(session_,FLD_TW_TIMEPERIOD,timeperiod);
         timesheet.setValue(session_,FLD_TW_RESOURCE,resource);

         // if this timesheet adjusts another timesheet, hook them up
   		ABTValue id = cursor_.getField(FLD_ADJUSTEDID);
         if (!ABTError.isError(id) && !ABTValue.isEmpty(id) && id != null) {
            String adjustTSSelection = FLD_TW_ID + " = ";
            if (id instanceof ABTInteger) adjustTSSelection = adjustTSSelection.concat("" + id.intValue());

            ABTValue value = (ABTValue)getDriver().getSpace().findObject(session_,OBJ_TW_TIMESHEET,adjustTSSelection);
            if (!ABTError.isError(value) && !ABTValue.isEmpty(value)) {
               ABTObjectSet adjustedTS = (ABTObjectSet)value;
               timesheet.setValue(session_,FLD_TW_ADJUSTED_TIMESHEETID,((ABTObject) adjustedTS.at(session_,0)).getValue(session_, FLD_TW_INTERNALID));
            }
         }

         RemoteID.setRemoteID(timesheet,session_);

         // set timesheet hours here
         if (sumCursor_ != null) {
            if (sumCursor_.bsearchFirstInt(searchKey_, timesheet.getValue(session_,FLD_TW_ID).intValue())) {

               ABTValue test = timesheet.getValue(session_,FLD_TW_RESOURCE,null);
               double multiplier = 1;
               if (test instanceof ABTObject) {
                  switch (((ABTObject)test).getValue(session_,FLD_TW_UNIT,null).intValue()) {
                     case RESOURCE_DAYS:   multiplier /= ((ABTObject)test).getValue(session_,FLD_TW_HOURS_PER_DAY,null).doubleValue();
                     case RESOURCE_HOURS:  multiplier /= 3600;
                  }
               }

               ABTValue temp = sumCursor_.getField(fieldName_);
               if (!ABTError.isError(temp) && !ABTValue.isEmpty(temp) && temp != null) {
                  timesheet.setValue(session_,FLD_TW_HOURS,new ABTDouble(temp.doubleValue()*multiplier));
               } else {
                  timesheet.setValue(session_,FLD_TW_HOURS,new ABTDouble(0));
               }
            }
         }
      }

      return timesheet;
   }

   public void setSumQuery(String query, String searchKey, String fieldName) {
      searchKey_ = searchKey;
      fieldName_ = fieldName;
      sumCursor_ = getDriver().getRepository().select(query);
   }
	
	private ABTObject getResource(ABTCursor cursor, ABTObject resource)
	{
		int id = cursor.getFieldInt(FLD_RESOURCEID);

		if (resource != null && resource.getValue(session_, FLD_TW_ID).intValue() == id) return resource;
		
      int idx = resources_.indexOf(new Integer(id));
		
		if (idx >= 0) return (ABTObject)resources_.at(idx);
		
      return null;
	}

	public void setNoteCursor(String query)
	{
		noteCursor_ = getDriver().getRepository().select(query);
	}
	
	protected void addNotesForTimesheet(ABTObject resource, ABTObject timesheet)
	{
		if (noteCursor_ != null) {

			int noteID = 0;
			while (noteCursor_.isValid() && (noteCursor_.getField(FLD_RESOURCEID).intValue() <= resource.getValue(session_, FLD_TW_ID).intValue())) {
				
				while (noteCursor_.isValid()
					    && (noteCursor_.getField(FLD_RESOURCEID).intValue() == resource.getValue(session_, FLD_TW_ID).intValue())
					    && (noteCursor_.getField(FLD_RECORDID).intValue() <= timesheet.getValue(session_, FLD_TW_ID).intValue())) {
			      if (timesheet.getValue(session_, FLD_TW_ID).intValue() == noteCursor_.getField(FLD_RECORDID).intValue()) {
			      	if (noteCursor_.getField(FLD_ID).intValue() != noteID) notePopulator_.addObject(timesheet, noteCursor_);
			      	noteID = noteCursor_.getField(FLD_ID).intValue();
			      }
					noteCursor_.moveNext();
				}
				
				noteCursor_.moveNext();
			}

		}
		return;
	}
	
}