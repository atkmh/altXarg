package com.abtcorp.repository;

import com.abtcorp.core.*;

public class ABTSession extends ABTNative
{
   ABTSession(int handle) {super(handle);}

   public static native ABTSession login();
   public static native ABTSession loginAs(String user, String password);

   public native int             getID();
   public native boolean         isLocal();
   public native boolean         getPrompt();
   public native String          getUserName();
   public native int             getUserID();
   public native String          getWorkstation();
   public native ABTRepository   getSystem();
   public native ABTTime         getCurrentTime();

   public native void            setPrompt(boolean prompt);
   
   public native void            changePassword();
   public native ABTRepository   connect(String name);
   public native ABTLicense 	   openLicense(String product);
}