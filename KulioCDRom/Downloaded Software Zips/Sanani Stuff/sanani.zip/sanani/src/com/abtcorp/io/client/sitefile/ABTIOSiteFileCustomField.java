package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileCustomField.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-1-98     MXA         Initial Implementation
 *
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;


/**
 *  ABTIOSiteFileCustomField is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOSiteFileDriver.
 *
 *  <pre>
 *       ABTIOSiteFileCustomField fr = new ABTIOSiteFileCustomField(driver,parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOSiteFileDriver
 */

public class ABTIOSiteFileCustomField extends ABTIOSiteFileHelper implements IABTRuleConstants
{
//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOSiteFileCustomField constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOSiteFileCustomField(ABTIOSiteFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_CUSTOMFIELD);
      site_ = parent;
   }


/**
 *  Saves the custom field objects back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving custom enums, aggregate fields, etc.)
 *	@param oSet   the custom field object set to be saved back to the loal file
 *  @return       the objects set that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObjectSet oSet) throws ABTException
   {
    try
    {
        super.save(oSet);
      // save the subordinate objects of all the custom fields in the object set.
      saveOtherObjects(oSet);
    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
       return (ABTValue)oSet;
    }


   }

   private void saveOtherObjects(IABTObjectSet oSet) throws ABTException
   {
   	// loop through all the objects in the object set
      for (int i = 0; i < size(oSet); i++)
      {
         IABTObject obj = (IABTObject)at(oSet, i);

      	// save the custom enums.
      	ABTIOSiteFileCustomEnum ceHelper = new ABTIOSiteFileCustomEnum(driver_, obj);
       	ceHelper.save(obj, OFD_CUSTOMENUMS);

      	// save the aggregate fields if there is any.
      	ABTIOSiteFileAggregateField afHelper = new ABTIOSiteFileAggregateField(driver_, obj);
       	afHelper.save(obj, OFD_AGGREGATEFIELDS);

      }
   }


/**
 * Populate site's custom fields.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
 protected ABTValue populate() throws ABTException
 {
        ABTValue     val       = null;
	    ABTValue     ret       = null;
        ABTRemoteID  remoteId  = null;
        IABTLocalID   id       = null;
        ABTObjectSetIDList custFieldIds = null;
        Object             obj          = null;
        
        id = driver_.getSiteId();
        val = getIDs(id,OBJ_SITE, OFD_CUSTOMFIELDS);

        if (val instanceof ABTObjectSetIDList)
            custFieldIds = (ABTObjectSetIDList)val;
        else 
            throw new ABTException("Wrong Cast");

        Enumeration itID = custFieldIds.getActiveIDs();
        while( itID.hasMoreElements() )
        {
           obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            id_ = (IABTLocalID)obj;           
           else
            throw new ABTException("Wrong Cast");
           ret = super.populate();   
           //then populate the custom enums 
           populateOtherObjects();
        }
        
        //Pass 2 for the Aggragate fields
        IABTLocalID customFieldId = null;
        itID = custFieldIds.getActiveIDs();
        while( itID.hasMoreElements() )
        {
           obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            customFieldId = (IABTLocalID)obj;           
           else
            throw new ABTException("Wrong Cast");
          
           //then populate aggregate fields
            populateAggragateObjects(customFieldId); 
        }
        
        return ret;
 }



/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
      reqParams_.putItemByString(OFD_SITE, (ABTValue)site_);
      return (super.create(type, id, reqParams_));
   }


   private void populateOtherObjects() throws ABTException
   {

   	IABTLocalID custFieldId  = id_;

   	// populate the custom enums.
   	ABTIOSiteFileCustomEnum ceHelper = new ABTIOSiteFileCustomEnum(driver_, site_);
    ceHelper.populate(custFieldId);
   }
   
   
   private void populateAggragateObjects(IABTLocalID customFieldId) throws ABTException
   {
   	// populate the aggregate fields if there is any.
   	ABTIOSiteFileAggregateField afHelper = new ABTIOSiteFileAggregateField(driver_, site_);
    afHelper.populate(customFieldId);
   }


}
