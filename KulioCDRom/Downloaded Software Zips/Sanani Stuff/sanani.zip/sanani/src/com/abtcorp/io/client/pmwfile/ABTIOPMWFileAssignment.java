package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileAssignment.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;
//DEBUG
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;
import com.abtcorp.io.client.ABTFileHelper;

import java.util.Hashtable;
/**
 *  ABTIOPMWFileAssignment is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileAssignment ft = new ABTIOPMWFileAssignment(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileAssignment extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       assignVector_ = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 *    ABTIOPMWFileAssignment constructor.
 *    @param   driver: the reference to the driver.
*/

   ABTIOPMWFileAssignment(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_          = OBJ_ASSIGNMENT;
      assignVector_  = new Vector();
   }

//====================================================================================
// Populate Assignment from the Intermediate Hash Table
//====================================================================================

/**
 * Populate assignment object from the Intermediate Hash Table to the space
 * @param Hashtable parms
 * @return an ABTValue the assignment object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(Hashtable parms) throws ABTException
   {
    ABTObjectSetIDList assignmentIDs   = null;
    IABTObject         project   = null;
    IABTObject         targetObj = null;
    Object             object    = null;

    try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        //Get the Target object which this note belongs to
        object = parms.get(TARGET_OBJ);
        if (object instanceof IABTObject)
            targetObj  = (IABTObject)object;

        //Get the Assignment IDs
        object = parms.get(ASSIGNMENT_ID);
        if (object instanceof ABTObjectSetIDList)
            assignmentIDs  = (ABTObjectSetIDList)object;

        Enumeration itID = assignmentIDs.getActiveIDs();
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);
            reqparms.put(TARGET_OBJ, targetObj);
            reqparms.put(ASSIGNMENT_ID,(IABTLocalID)itID.nextElement());

            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }
   }

 /**
 * Create a new Assignment object in the object space and initialize it with appropriate values
 * @param Hashtable parms
 * @return ABTValue the newly created note
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {     
      IABTLocalID  assignmentID    = null;
      IABTObject  project         = null;
      IABTObject  targetObj       = null;
      Object      object          = null;
      IABTObject  assignmentObj   = null;
      ABTValue    val             = null;
  try{
      //Get the Assignment ID
      object = null;
      object = parms.get(ASSIGNMENT_ID);
      if (object instanceof IABTLocalID)
         assignmentID  = (IABTLocalID)object;

      //Check if Assignment has already been created
        object = null;
        object = driver_.lookupTableGet(assignmentID);
        if ( object!= null && object instanceof IABTObject)
        {
         // TO DO UPDATE
           ;
        }
        else
        {
          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object;


          //Get the Target object which this note belongs to
          object = null;
          object = parms.get(TARGET_OBJ);
          if (object instanceof IABTObject)
             targetObj  = (IABTObject)object;


          // Get the array of value associated with Assignment
          IABTArray   assignmentArr  = null;
          object = null;

          object = driver_.intermediateTableGet(assignmentID);
          if (object instanceof IABTArray)
            assignmentArr = (IABTArray) object;

          //Get the property set associated with the team
          IABTPropertySet propSet = null;
          propSet = getProperties(type_);

         //Get associated team
          val = null;
          IABTLocalID teamID  = null;
          IABTObject  teamObj = null;
          object = null;

          val = getHashValue(assignmentArr, propSet, OFD_TEAM);
          if (val instanceof IABTLocalID)
             teamID  = (IABTLocalID)val;
          else
            throw new ABTException("Assignment Team ID is not valid");
          object = driver_.lookupTableGet(teamID);
          if ( object != null && object instanceof IABTObject )
            teamObj = (IABTObject)object;
          else
            throw new ABTException("ASSIGNMENT CREATE: Resource Object is not valid");


          //Get associated Resource
          val = null;
          IABTObject  resourceObj = null;

          val = getValue(teamObj, OFD_RESOURCE);
          if ( val instanceof IABTObject)
            resourceObj = (IABTObject) val;
         else
            throw new ABTException("Assignment Team Resource Obj is not valid");


          //Get Assignment's Remote ID
          val = null;
          ABTRemoteID id  = null;
          val = getHashValue(assignmentArr, propSet, PROP_REMOTEID);
          if (ABTValue.isNull(val))
            id = (ABTRemoteID)null;
          else if (val instanceof ABTRemoteID )
            id = (ABTRemoteID)val;            
          else
            throw new ABTException("Assignment Team ID is not valid");

          //Create the Assignment
          IABTHashTable  reqparms = (getSpace()).newABTHashTable();
          reqparms.putItemByString(OFD_TASK,     (ABTValue)targetObj);
          reqparms.putItemByString(OFD_RESOURCE, (ABTValue)resourceObj);
          assignmentObj = createObject(type_,id, reqparms);

          //Set Assignment's scalar values.
          setScalarValues(propSet, assignmentArr, assignmentObj);

         //Get assignment's note IDs
         ABTValue  noteVal = null;
         noteVal = getHashValue(assignmentArr, propSet, OFD_NOTES);

         ABTIOPMWFileNote noteHelper = new ABTIOPMWFileNote(driver_);

         Hashtable reqNoteParms = new Hashtable();
         reqNoteParms.put(OFD_PROJECT,project);
         if (noteVal == null)
            reqNoteParms.put(OFD_NOTES,OFD_NOTES);
         else
            reqNoteParms.put(OFD_NOTES,noteVal);
         if (assignmentObj == null)
            reqNoteParms.put(TARGET_OBJ,TARGET_OBJ);
         else
            reqNoteParms.put(TARGET_OBJ, assignmentObj);

         noteHelper.populate(reqNoteParms);


        }
    driver_.lookupTablePut(assignmentID, assignmentObj);
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }

    return (ABTValue)assignmentObj;

   }

//====================================================================================
// Save Assignment to an Intermediate Hash Table
//====================================================================================

/**
 * Saves assign objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
      IABTObject project = null;

        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        if (project == null)
            throw new ABTException("The current project is null.");

        IABTObjectSet assignOs = getObjectSet(project, OFD_ALLASSIGNMENTS);

        for (int i =0; i < size(assignOs); i++)
        {
            IABTObject  assignObj     = (IABTObject)at(assignOs, i);

            // Make sure the object is of type assign
            if (!assignObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the assign in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(assignObj);
            if (arr==null)
                throw new ABTException("The arr of assign values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID assignId = assignObj.getID();
            if (assignId == null)
                throw new ABTException("assign ID is null.");

            driver_.intermediateTablePut(assignId, arr);
            //if (( driver_.intermediateTablePut(assignId, arr)) != null)
            //    throw new ABTException("The assign ID already exist.");

            //DEBUG
            assignVector_.addElement(assignId);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }

}