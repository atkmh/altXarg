package com.abtcorp.io.siterepo;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_ERROR_OCCURRED.getCode(),"Error occurred"},
{ERR_INVALID_ID.getCode(),"Invalid ID"},
{ERR_INSUFFICIENT_RIGHT.getCode(),"Insufficient right"},
{ERR_INVALID_KEY.getCode(),"Invalid key"},
{ERR_INVALID_COMMAND.getCode(),"Invalid command"},
{ERR_INVALID_SOURCE.getCode(),"Invalid source"},
{ERR_INVALID_PROPERTYSET.getCode(),"Invalid property set"},
{ERR_INVALID_HASH.getCode(),"Invalid hash table"},
{ERR_UNABLE_TO_CONNECT.getCode(),"Unable to connect to the repository"},
{ERR_CURSOR_ERROR.getCode(),"Cursor error"},
{ERR_RECORD_NOT_FOUND.getCode(),"Record not found"},
{ERR_INVALID_TABLE.getCode(),"Invalid table"},
{ERR_INVALID_TYPE.getCode(),"Invalid type"},
{ERR_OBJECT_NOT_FOUND.getCode(),"Object not found"},
{ERR_OBJECTSET_NOT_FOUND.getCode(),"Object set not found"},
{ERR_NOT_IMPLEMENTED.getCode(),"Not implemented"},
{ERR_DUPLICATE_DETECTED.getCode(),"Duplicate detected"},
{ERR_SELECT_ERROR.getCode(),"Select error"},

 };
}