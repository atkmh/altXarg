package com.abtcorp.io.PMWRepo;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_WBSSEQUENCE_NULL.getCode(),"Repository name is null"},
{ERR_PROJECT_NOT_FROM_REPO.getCode(),"New resources prevent project from being saved"},
{ERR_TEAM_NO_RESOURCE.getCode(),"An exception has occured"},
{ERR_IPD_PREDTASK_NOT_FOUND.getCode(),"Project's OFD_WBSSEQUENCE cannot be null"},
{ERR_IPD_SUCCTASK_NOT_FOUND.getCode(),"Project being saved did not originate from a Repository.  Use 'saveAs' instead."},
{ERR_NO_VIEW_RIGHT.getCode(),"Resource referenced by Team object not found in target Repository"},
{ERR_NO_VIEWABLE_PROJECTS.getCode(),"Interproject predecessor task not found"},
{ERR_PROJECT_LOCKED_BY_ANOTHER.getCode(),"Interproject successor task not found"},
{ERR_INVALID_LOCK_TYPE.getCode(),"User does not have rights to view the project"},
{ERR_UNABLE_TO_CONNECT.getCode(),"None of the selected projects are viewable by the user"},
{ERR_LOCK_STILL_HELD.getCode(),"Project is locked by another user. Project not populated"},
{ERR_LOCK_NOT_HELD.getCode(),"Invalid lock type"},
{ERR_EXTIDS_ARG.getCode(),"Unable to connect to the repository"},
{ERR_INPUT_OBJECT_MISSING.getCode(),"A lock was successfully released, but the user still holds a lock on the projec"},
{ERR_SAVEAS_NULL_EXTID.getCode(),"The lock is not held by the user"},
{ERR_PROJECT_EXTID_MISSING.getCode(),"ExtIDs argument missing or improper value"},
{ERR_PROJECT_READONLY.getCode(),"Input object to be saved is missing or is not an instance of ABTObject"},
{ERR_TARGET_EXISTS_SPACE.getCode(),"Saveas requires a non-null project external ID"},
{ERR_TARGET_EXISTS_REPO.getCode(),"Project external ID is missing"},
{ERR_NO_SAVEAS_RIGHTS.getCode(),"Project is marked 'readonly' and cannot be saved"},
{ERR_NOT_LOCKED.getCode(),"Target project for SaveAs exists in the object space and cannot be saved as a new project"},
{ERR_NO_REPO_SESSION.getCode(),"Target project for SaveAs exists in the Repository and cannot be saved as a new project"},
{ERR_BAD_VERSIONS.getCode(),"User does not have rights to save a project under a different name"},
{ERR_BAD_TYPE.getCode(),"User does not have a lock on the project"},
{ERR_NO_TASK_FOR_CONSTRAINT.getCode(),"A repository session has not been established"},
{ERR_NO_EST_MODEL.getCode(),"The project version in the object space is not greater than the project version in the Repository"},
{ERR_NO_TASK_FOR_TASK_EST.getCode(),"The save type is not of type 'project'"},
{ERR_NO_TASK_FOR_CUSTOM_FIELD.getCode(),"Cannot find associated task for constraint object"},
{ERR_NO_TASK_FOR_NOTE.getCode(),"Cannot find associated estimating model for task estimate objectCannot find associated estimating model for task estimate object"},
{ERR_NOT_IMPLEMENTED.getCode(),"Cannot find associated task for task estimate object"},
{ERR_COULD_NOT_GET_LOCK.getCode(),"Cannot find associated task for a task custom field"},
{ERR_PROJECT_NOT_FOUND.getCode(),"Cannot find associated task for a task note"},
{ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA.getCode(),"Not implemented"},
{ERR_MISSING_TASK_EXTID.getCode(),"Could not acquire lock for project"},
{ERR_MISSING_PROJECT_IDS.getCode(),"Project not found"},
{ERR_ASSIGNMENT_RESOURCE_NOT_FOUND.getCode(),"No projects meet the selection criteria"},
{ERR_INVALID_POPULATE_TYPE.getCode(),"Missing task external ID"},
{ERR_ORIG_REPONAME_NULL.getCode(),"Missing project IDs array"},
{ERR_OBJECT_SPACE_MISSING.getCode(),"The resource for an assignment was not found"},
{ERR_USER_SESSION_MISSING.getCode(),"Invalid populate type"},
{ERR_ARGS_MISSING.getCode(),"The project did not originate from a repository.  Save disallowed.  Use saveAs instead."},
{ERR_TYPE_MISSING.getCode(),"Missing input object space parameter"},
{ERR_SUBPROJECT_LOCK.getCode(),"Missing input user session parameter"},
{ERR_EXCEPTION_OCCURRED.getCode(),"An exception occurred"},
{ERR_REPO_NAME_NULL.getCode(),"The ABT Repository name is null"},
{ERR_NEW_RESOURCES.getCode(),"The project could not be saved because it references resources which are not present in the target Repository"},

 };
}