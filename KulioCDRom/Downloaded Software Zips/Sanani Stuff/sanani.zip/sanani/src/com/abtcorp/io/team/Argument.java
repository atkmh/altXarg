package com.abtcorp.io.team;

import java.util.*;

public class Argument extends Hashtable {
   
   /***
    * Indicator that the argument has been set but has no value. This string
    * is returned when an option is passed to Argument but there is corresponding
    * value associated with it. Ex.) -f -o=foo. The -f is an example where the
    * SET string would be placed into the hashtable during parse.
    */
   public final static String SET = "xxx".intern();
   
   /***
    * Constructs an ABTArgument object.
    * This method accepts a string that lists the valid arguments.
    * The argument list is a comma separated list, e.g., a,b,cd,efg,h,i.
    * @param args The comma-separated list of arguments this object accepts.
    */
   public Argument(String args) {
      super();

      StringTokenizer st = new StringTokenizer(args,",");
      while(st.hasMoreTokens()) {
         put((String)st.nextToken(),""); // Initialize the dictionary with the arguments.
      }
   }


   /***
    * Parses the string array looking for valid arguments and saving them in the hashtable.
    * @param args An array of strings representing the arguments passed to the object.
    * Arguments passed to this method must be of one of the following the forms:
    * "-arg1 -arg2 -arg3=value3"
    * "-arg1arg2arg3 -arg4 -arg5=value3"
    * ex.) -sfx -g=value -t
    *
    * Only valid arguments are saved in the hashtable. Invalid arguments are skipped. The valid
    * arguments must have been set in the table when this object was constructed.
    */
   public void parse(String[] args) {

      for(int i = 0;i < args.length;i++) {

         String arg = args[i];

         if(arg.charAt(0) == '-' || arg.charAt(0) == '/') {

            int pos = 1;

            for(int end = arg.length();end >= pos;end--) {
               String candidate = arg.substring(pos,end);

               if(containsKey(candidate)) {
                  String value = null;

                  pos = end;

                  if(end == arg.length()) {
                     value = arg.substring(end,arg.length());

                     // Check next argument for value. The args might be of the form -option value
                     if(i < args.length - 1) {
                        String nextArg = args[i+1];
                        if(nextArg.length() > 0 && nextArg.charAt(0) != '-' && arg.charAt(0) != '/') {
                           value = nextArg;
                        }
                     }

                     if(value.length() == 0) {
                        value = SET;
                     }

                  } else if(arg.charAt(end) == '=' || arg.charAt(end) == ' ') {
                     value = arg.substring(end+1,arg.length());
                  } else {
                     value = SET;      // Save a "dummy" value;
                     end = arg.length(); // Look for next argument;
                  }
                  put(candidate,value);
               }
            }
         }
      }
   }

   public Object get(Object key) {
      return super.get(key);
   }

   public boolean containsKey(Object key) {
      return super.containsKey(key);
   }
}