package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class TimeEntryPopulator extends TWPopulator implements TWRepoDriverConstants, IABTTWRuleConstants, ABTNames
{
	private ABTObject timesheet_ = null;
	
	public TimeEntryPopulator(ABTRepositoryDriver driver) {super(driver);}
   public TimeEntryPopulator() {}

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet timeEntries = getObjectSet(OBJ_TW_TIMEENTRY);

      if (timeEntries == null || cursor_ == null) return null;

      while(cursor_.moveNext()) {
         try {
            ABTObject timeEntry = (ABTObject)addObject(timeEntries);
            timeEntries.add(session_,timeEntry);
            updateStatus(timeEntry);
         } catch (ClassCastException e) {
            // Eat these exceptions if the time entry comes back as an ABTError.
         }
      }

      closePopulatorCursor();
   	timesheet_ = null;

      return timeEntries;
   }

	/* Adds the time entry to the object space. There is no need to set FLD_TW_ASSIGNMENT */
	/*  here because it is set during object initialization.                              */
	protected ABTValue addObject(ABTObjectSet timeEntries)
   {
      double multiplier = 1;
      ABTObject resource = null;

      ABTHashtable args = new ABTHashtable(1,(float)1.0);
      ABTValue assignID = cursor_.getField(FLD_ASSIGNMENTID);
      if (!ABTError.isError(assignID) && !ABTValue.isEmpty(assignID) && assignID != null)
         args.put(new ABTString(REPO_ASSIGNMENTID),assignID);
      ABTObject timeEntry = (ABTObject)getDriver().getSpace().createObject(session_,OBJ_TW_TIMEENTRY,null,args);

      if (timeEntry instanceof ABTObject) {

         String chargeSelection     = FLD_TW_ID + " = ";
         String typeSelection       = FLD_TW_ID + " = ";

         ABTValue id = cursor_.getField(FLD_CHARGECODEID);
         if (id != null && id instanceof ABTInteger) chargeSelection = chargeSelection.concat("" + id.intValue());

         id = cursor_.getField(FLD_TYPECODEID);
         if (id != null && id instanceof ABTInteger) typeSelection = typeSelection.concat("" + id.intValue());

			ABTObject timesheet = null;
      	if (timesheet_ != null) timesheet = timesheet_;
      	else {
	      	id = cursor_.getField(FLD_TIMESHEETID);
	         if (id != null && id instanceof ABTInteger) {
		         String timesheetSelection  = FLD_TW_ID + " = ";
	         	timesheetSelection = timesheetSelection.concat("" + id.intValue());
	      		ABTValue set = getDriver().getSpace().findObject(session_,OBJ_TW_TIMESHEET,timesheetSelection);
		         if (set == null || ABTError.isError(set) || ABTEmpty.isEmpty(set) || ((ABTObjectSet)set).size(session_) == 0) return timeEntry;
		         timesheet = (ABTObject)((ABTObjectSet)set).at(session_,0);
	         }
      	}

         timeEntry.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));

         timeEntry.setValue(session_,FLD_TW_ACTUALS,cursor_.getField(FLD_ACTCURVE));

         timeEntry.setValue(session_,FLD_TW_TIMESHEET,timesheet);

         ABTValue test = timesheet.getValue(session_,FLD_TW_RESOURCE,null);
         if (test instanceof ABTObject) {
            resource = (ABTObject)test;
            switch (resource.getValue(session_,FLD_TW_UNIT,null).intValue()) {
               case RESOURCE_DAYS:   
                  multiplier /= (resource.getValue(session_,FLD_TW_HOURS_PER_DAY,null).doubleValue() * 3600);
            	   break;
               case RESOURCE_HOURS:  
                  multiplier /= 3600;
            	   break;
            }
         }

         ABTValue value = (ABTValue)getDriver().getSpace().findObject(session_,OBJ_TW_CHARGECODE,chargeSelection);
         if (!ABTError.isError(value) && !ABTValue.isEmpty(value)) {
               ABTObjectSet chargeCodes = (ABTObjectSet)value;
               timeEntry.setValue(session_,FLD_TW_CHARGECODE,chargeCodes.at(session_,0));
         }

         value = (ABTValue)getDriver().getSpace().findObject(session_,OBJ_TW_TYPECODE,typeSelection);
         if (!ABTError.isError(value) && !ABTValue.isEmpty(value)) {
            ABTObjectSet typeCodes = (ABTObjectSet)value;
            timeEntry.setValue(session_,FLD_TW_TYPECODE,typeCodes.at(session_,0));
         }
         scaleCurve(timeEntry,multiplier,FLD_TW_ACTUALS);

         RemoteID.setRemoteID(timeEntry,session_); // Tag the object with the remote id.
      }

      return timeEntry;
   }

   protected void scaleCurve(ABTObject assignment, double multiplier, String name)
   {
      ABTValue value = assignment.getValue(session_,name,null);
      if (!ABTValue.isEmpty(value) && !ABTError.isError(value) && value != null) {
         ABTCurve curve = (ABTCurve)value;
         curve.scaleRate(multiplier);
      	assignment.setValue(session_,name,curve,null);
      }
   }
	
	public void setTimesheet(ABTObject timesheet) { timesheet_ = timesheet; }

}