package com.abtcorp.io.team;

import java.util.Date;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTDouble;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTDate;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class AssignmentPopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   protected ABTCursor peUnsubmitted_;
   protected ABTCursor peSubmitted_;
   private int start_;
   private int finish_;

   public AssignmentPopulator() {}
   public AssignmentPopulator(ABTRepositoryDriver driver) {super(driver);}
   public AssignmentPopulator(ABTRepositoryDriver driver, ABTObjectSpace space, ABTUserSession session)
   {
      super();
   	setDriver(driver, space, session);
   }


   public void setAssignmentPeriod(int daysBefore, int daysAfter) throws ABTException
   {      
      boolean manual = (daysBefore >= 0 && daysAfter >= 0) ? true : false;

      ABTCursor cursor = getCurrentTimePeriod();

      if (manual) {
         start_ = getCurrentTimePeriodStart(cursor) - daysBefore;
         finish_ = getCurrentTimePeriodStart(cursor) + daysAfter;
      } else {
         int start = getCurrentTimePeriodStart(cursor);
         int finish = getCurrentTimePeriodFinish(cursor);
         ABTTime end = new ABTTime(ABTDate.toDate(finish+1,0));
         ABTTime begin = new ABTTime(ABTDate.toDate(start,0));

         // Find the active assignment pool start. We will look for the most recent closed time period
         // and use it's finish date as the start of the assignment pool. If we don't find any closed time periods
         // we will use the oldest open time period's start date as the start date for the assignment pool.
         ABTCursor temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen=0 and prFinish <= " + begin.toSQL() + " order by PRTimePeriod.prStart");

         if (temp.moveLast()) start_ = temp.getFieldDate(FLD_FINISH, false).getJulian();
         else {
            temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen <> 0 and prFinish <= " + begin.toSQL() + " order by prStart");
            if (temp.moveFirst()) start_ = temp.getFieldDate(FLD_START, false).getJulian();
         }

         // Find the active assignment pool finish. We will look for the closed time period in the future closest to the finish of
         // the current time period and use that as our finish date for the assignment pool. If there are no closed time periods closed
         // in the future we will use the open time period farthest in the future for our finish date.
         temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen=0 and prStart >= " + end.toSQL() + " order by PRTimePeriod.prStart");

         if (temp.moveFirst()) finish_ = temp.getFieldDate(FLD_START,false).getJulian();
         else {
            temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen <> 0 and prStart >= " + end.toSQL() + " order by PRTimePeriod.prStart");
            if (temp.moveLast()) finish_ = temp.getFieldDate(FLD_FINISH, false).getJulian();
         }
         temp.release();
      }

      cursor.release();
   }

   public int getAssignmentPeriodStart()      {return start_;}
   public int getAssignmentPeriodFinish()     {return finish_;}

   public ABTObject addObject(ABTObject task, ABTCursor assignCursor)
   {
   	ABTObject assignment = (ABTObject)getDriver().getSpace().createObject(session_,OBJ_TW_ASSIGNMENT,null,null);
      
   	try {
      	if (peUnsubmitted_ == null) peUnsubmitted_ = getPendingActualsForUnSubmittedTimeSheets();
         if (peSubmitted_ == null) peSubmitted_   = getPendingActualsForSubmittedTimeSheets();
   	} catch (Exception e) {
    		e.printStackTrace();
      }

      if (assignment instanceof ABTObject) {
         assignment.setValue(session_,FLD_TW_ID,assignCursor.getField(FLD_ID));
         assignment.setValue(session_,FLD_TW_RESOURCEID,assignCursor.getField(FLD_RESOURCEID));
         assignment.setValue(session_,FLD_TW_TASKID,assignCursor.getField(FLD_TASKID));
         assignment.setValue(session_,FLD_TW_START,assignCursor.getField(FLD_START));
         assignment.setValue(session_,FLD_TW_FINISH,assignCursor.getField(FLD_FINISH));
         assignment.setValue(session_,FLD_TW_ISUNPLANNED,assignCursor.getField(FLD_ISUNPLANNED));
         assignment.setValue(session_,FLD_TW_LOADPATTERN,assignCursor.getField(FLD_ESTPATTERN));
         assignment.setValue(session_,FLD_TW_ACTTHRU,assignCursor.getField(FLD_ACTTHRU));
         assignment.setValue(session_,FLD_TW_ACTUALS,assignCursor.getField(FLD_ACTCURVE));
         assignment.setValue(session_,FLD_TW_ESTIMATES,assignCursor.getField(FLD_ESTCURVE));
         assignment.setValue(session_,FLD_TW_TASK,task);

         // Set pending estimates for the assignment.
         setPendingEstimates(assignment,assignCursor);
         RemoteID.setRemoteID(assignment,session_);
      }

      return assignment;
   }

   public ABTValue populate() throws ABTException
   {
   	// This method is never called by the driver explicitly.
      return null;
   }

   protected void setPendingEstimates(ABTObject assignment, ABTCursor cursor)
   {
   	int id = cursor.getFieldInt(FLD_RESOURCEID);
   	int idx = resources_.indexOf(new Integer(id));
   	if (idx >= 0) {
   		ABTObject resource = (ABTObject)resources_.at(idx);
         double multiplier = 1;
         switch (resource.getValue(session_,FLD_TW_UNIT,null).intValue()) {
            case RESOURCE_DAYS:   multiplier /= resource.getValue(session_,FLD_TW_HOURS_PER_DAY,null).doubleValue();
            case RESOURCE_HOURS:  multiplier /= 3600;
         }

         if (cursor.getFieldInt(FLD_ESTPATTERN) == FIXED_LOADPATTERN) {
            if (! cursor.isFieldNull(FLD_PENDESTSUM)) assignment.setValue(session_,FLD_TW_PENDING,new ABTDouble(cursor.getFieldDouble(FLD_PENDESTSUM) * multiplier));
            else assignment.setValue(session_,FLD_TW_PENDING,new ABTDouble(-1.0));
         } else {
            if (! cursor.isFieldNull(FLD_PENDESTSUM)) calculatePendingEstimates(assignment,peUnsubmitted_,cursor.getFieldDouble(FLD_PENDESTSUM),resource, true, multiplier);
            else calculatePendingEstimates(assignment,peSubmitted_,cursor.getFieldDouble(FLD_ESTSUM),resource, false, multiplier);
         }

         scaleCurve(assignment,multiplier,FLD_TW_ACTUALS);
         scaleCurve(assignment,multiplier,FLD_TW_ESTIMATES);
      }
   }

   protected void calculatePendingEstimates(ABTObject assignment, ABTCursor cursor, double estimate, ABTObject resource, boolean add, double multiplier)
   {
      assignment.setValue(session_,FLD_TW_PENDING,new ABTDouble(estimate * multiplier));
   	   	
      try {
         if (cursor.bsearchFirstInt(FLD_ASSIGNMENTID,assignment.getValue(session_,FLD_TW_ID,null).intValue())) {
            if (cursor.getFieldInt(FLD_RESOURCEID) == resource.getValue(session_,FLD_TW_ID,null).intValue()) {
               if (add) assignment.setValue(session_,FLD_TW_PENDING, new ABTDouble((estimate + cursor.getFieldDouble(FLD_PENDACTSUM)) * multiplier));
               else assignment.setValue(session_,FLD_TW_PENDING, new ABTDouble((Math.max(0.0,estimate - cursor.getFieldDouble(FLD_PENDACTSUM))) * multiplier));
            }
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   protected void scaleCurve(ABTObject assignment, double multiplier, String name)
   {
      ABTValue value = assignment.getValue(session_,name,null);
      if (!ABTValue.isEmpty(value) && !ABTError.isError(value) && value != null) {
         ABTCurve curve = (ABTCurve)value;
         curve.scaleRate(multiplier);
      	assignment.setValue(session_,name,curve,null);
      }
   }

   protected final ABTCursor getPendingActualsForUnSubmittedTimeSheets() throws ABTException
   {
      return getDriver().getRepository().select("select PRTimeEntry.prAssignmentID, PRAssignment.prResourceID,  SUM(PRTimeEntry.prActSum) AS prPendActSum " +
	                                             "from PRTimeEntry, PRTimeSheet, PRAssignment, PRTask " +
	                                             "where PRTimeEntry.prTimeSheetID=PRTimeSheet.prID and " +
	                                             "PRTimeEntry.prAssignmentID=PRAssignment.prID and " +
	                                             "PRAssignment.prTaskID=PRTask.prID and " +
	                                             "PRTimeEntry.prCorrectID is NULL and " +
	                                             "(PRTimeSheet.prStatus = 0 or PRTimeSheet.prStatus = 2) " +
	                                             "GROUP BY PRTimeEntry.prAssignmentID, PRAssignment.prResourceID " +
	                                             "ORDER BY PRTimeEntry.prAssignmentID");
   }

   protected final ABTCursor getPendingActualsForSubmittedTimeSheets() throws ABTException
   {
      return getDriver().getRepository().select("select PRTimeEntry.prAssignmentID, PRAssignment.prResourceID,  SUM(PRTimeEntry.prActSum) AS prPendActSum " +
	                                             "from PRTimeEntry, PRTimeSheet, PRAssignment, PRTask " +
	                                             "where PRTimeEntry.prTimeSheetID=PRTimeSheet.prID and " +
	                                             "PRTimeEntry.prAssignmentID=PRAssignment.prID and " +
	                                             "PRAssignment.prTaskID=PRTask.prID and " +
	                                             "PRTimeEntry.prCorrectID is NULL and " +
	                                             "(PRTimeSheet.prStatus = 1 or PRTimeSheet.prStatus = 3) " +
	                                             "GROUP BY PRTimeEntry.prAssignmentID, PRAssignment.prResourceID " +
	                                             "ORDER BY PRTimeEntry.prAssignmentID");
   }

   private final ABTCursor getCurrentTimePeriod() throws ABTException
   {
      ABTTime today = new ABTTime(new Date());

      return getDriver().getRepository().select("select * from PRTimePeriod where prStart<=" + today.toSQL() + " and prFinish>" + today.toSQL());
   }

   private final int getCurrentTimePeriodStart(ABTCursor cursor)
   {
      try {
         if(cursor.moveFirst()) {
            return cursor.getFieldDate(FLD_START, false).getJulian();
         }
      } catch (Exception e) {
      }
      return ABTDate.today().getJulian();
   }

   private final int getCurrentTimePeriodFinish(ABTCursor cursor)
   {
      try {
         if(cursor.moveFirst()) {
            return cursor.getFieldDate(FLD_FINISH, true).getJulian();
         }
      } catch (Exception e) {
      }
      return ABTDate.today().getJulian();
   }

   public String getActiveAssignmentQuery(boolean strict, int start, int finish)
   {
      ABTTime end = new ABTTime(ABTDate.toDate(finish+1,0));
      ABTTime begin = new ABTTime(ABTDate.toDate(start,0));

      if (strict) {
         return new String("select PRAssignment.*, PRTask.prProjectID from PRAssignment, PRTask, PRProject, PRResource, PRTeam where " +
                           "PRAssignment.prTaskID=PRTask.prID and " +
                           "PRAssignment.prResourceID=PRResource.prID and " +
                           "PRTask.prProjectID=PRProject.prID and " +
                           "PRTeam.prProjectID=PRProject.prID and " +
                           "PRTeam.prResourceID=PRResource.prID and " +
                           "PRAssignment.prStart<" + end.toSQL() + " and " +
                           "PRAssignment.prFinish>" + begin.toSQL() + " and " +
                           "PRTask.prStatus<>2 and " +
                           "(PRProject.prIsOpen<>0 and PRProject.prTrackMode=2) and " +
                           "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0) and " +
                           "PRTeam.prIsOpen<>0 " +
                           "order by PRTask.prProjectID");
      } else
         return new String("select PRAssignment.*, PRTask.prProjectID from PRAssignment, PRTask, PRProject, PRResource, PRTeam where " +
                           "PRAssignment.prTaskID=PRTask.prID and " +
                           "PRAssignment.prResourceID=PRResource.prID and " +
                           "PRTask.prProjectID=PRProject.prID and " +
                           "PRTeam.prProjectID=PRProject.prID and " +
                           "PRTeam.prResourceID=PRResource.prID and " +
                           "PRTask.prStart<" + end.toSQL() + " and " +
                           "PRTask.prFinish>" + begin.toSQL() + " and " +
                           "PRTask.prStatus<>2 and " +
                           "(PRProject.prIsOpen<>0 and PRProject.prTrackMode=2) and " +
                           "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0) and " +
                           "PRTeam.prIsOpen<>0 " +
                           "order by PRTask.prProjectID");
   }
}