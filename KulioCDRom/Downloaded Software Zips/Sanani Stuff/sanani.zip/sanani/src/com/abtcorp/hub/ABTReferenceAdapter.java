

package com.abtcorp.hub;

/*
 * ABTReferenceAdapter.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 05-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import  java.util.Enumeration;
import  java.util.Hashtable;
import com.abtcorp.core.*;

/**
 * ABTReferenceAdapter implements the source for reference notification
 * an instance of this class contains the list of all ABTReferenceListeners
 * to this instance and upon event reception invokes the applicable
 * routines
 * Registration as a listener to a property is done via (field)rules.
 * The To register as a listener the the ABTObject or the ABTObjectSet as to
 * provide itself , the property within itself
 * @version	1.0
 * @author      Hajo Birthelmer
 */


public class ABTReferenceAdapter implements Serializable,Cloneable
{
    Hashtable propertyReferences;
    Hashtable allReferences;
    

    private IABTReferenceSource owner;


   /**
    * used to identify myself for QA-dump
    */
   public String dump(int indent,int level)
   {
      Hashtable ref;
      StringBuffer sb = new StringBuffer();


      if (level > 0)
         sb.append(com.abtcorp.core.ABTUtil.newLine(indent) + this.getClass() + ":");
      if (allReferences != null)
      {
         sb.append(com.abtcorp.core.ABTUtil.newLine(indent+1) + "General References: ");
         Enumeration e = allReferences.keys();
         while (e.hasMoreElements())
         {
            ABTValue o = (ABTValue)e.nextElement(); 
            sb.append(com.abtcorp.core.ABTUtil.newLine(indent+1) + " -" + ((IABTReferenceListener)o).dump(indent+1,0) + " - " + ((ABTProperty)allReferences.get(o)).dump(indent+1,0));
         }         
         
      }
      if (propertyReferences != null)
      {
         sb.append(com.abtcorp.core.ABTUtil.newLine(indent+1) + "Specific References: ");
         Enumeration e1 = propertyReferences.keys();
         while (e1.hasMoreElements())
         {
            ABTProperty prop = (ABTProperty)(e1.nextElement());
            sb.append(" Property : " + prop.dump(indent+1,0));
            ref = (Hashtable)(propertyReferences.get(prop));                        
            Enumeration e2 = ref.keys();
            ABTValue  o1 = (ABTValue)e2.nextElement(); 
            sb.append("\n -" + ((IABTReferenceListener)o1).dump(indent+1,0) + " - " + ((ABTProperty)allReferences.get(o1)).dump(indent+1,0));
         }         
         
      }
      return sb.toString();   
         
      
   }
   
   /**
   * class constructor, invoked by the explicitly by an ABTRow,
   * implicitly by an ABTObject/ABTObjectSet
   * Owner is either an ABTRow or an ABTObjectSet
   */

   ABTReferenceAdapter (IABTReferenceSource owner_)
   {
      owner = owner_;
   }
   
   protected int countListeners()
   {
      int size = 0;
      if (allReferences != null)
         size = allReferences.size();
      if (propertyReferences != null)
      {
         Enumeration e = propertyReferences.elements();
         while (e.hasMoreElements())
         {
            size = size + ((Hashtable)e.nextElement()).size();
         }
      }      
      return size;
   }

   protected void addReference(ABTUserSession session, IABTReferenceListener value,ABTProperty listenerProperty, ABTProperty property)
   {
      Hashtable ref;

      if (property == null)
      {
         if (allReferences == null)
            allReferences = new Hashtable();
         ref = allReferences;
         ref.put(value,listenerProperty);
         return;
      }
      if (propertyReferences == null)
      {
         propertyReferences = new Hashtable();
         ref = null;
      }   
      else   
         ref = (Hashtable)propertyReferences.get(property);
      if (ref == null)
      {
         ref = new Hashtable();
         ref.put(value,listenerProperty);
         propertyReferences.put(property,ref);
      }
      else
         ref.put(value,listenerProperty);
   }

   protected void removeReference(ABTUserSession session, IABTReferenceListener reference)
   {
      Hashtable ref;

      if (allReferences != null)
      {
         allReferences.remove(reference);
      }
      if (propertyReferences == null)
         return;

      Enumeration e = propertyReferences.elements();
      while (e.hasMoreElements())
      {
         ref = (Hashtable)e.nextElement();
         ref.remove(reference);
      }
      return;
   }


   protected void removeReference(ABTUserSession session, IABTReferenceListener reference,ABTProperty property)
   {
      Hashtable ref;

      if (property == null)
      {
         if (allReferences == null)
            return;
         ref = allReferences;
      }
      else
      {
         if (propertyReferences == null)
            return;
         ref = (Hashtable)propertyReferences.get(property);
      }


      if (ref == null)
         return;
      ref.remove(reference);
   }

   protected void removeReferences()
   {
      if (allReferences != null)
         allReferences.clear();
      allReferences = null;
      if (propertyReferences != null)
         propertyReferences.clear();
      propertyReferences = null;
   }

   public void finalize()
   {
      removeReferences();
      owner = null;
   }

   protected void destroy()
   {
      removeReferences();
      owner = null;
   }

   // get a reference
   Hashtable getTarget(ABTProperty property)
   {

      Hashtable ref;

      if (property == null)
      {
         return allReferences;

      }
      if (propertyReferences == null)
         return null;
      return (Hashtable)propertyReferences.get(property);

   }

// NOTIFICATIONS
  /**
  * notify the referenceListener of attempt to add an element
  */
  protected ABTError notifyReferenceAdd (ABTUserSession session,
                                         ABTValue newValue,
                                         boolean existing,
                                         boolean dirty)
  {
      Hashtable ar = getTarget(null);
      if (ar == null)
         return null;
      int i = 0;
      ABTError er = null;
      Enumeration e = ar.keys();
      while ((e.hasMoreElements()) && (er == null))
      {
         IABTReferenceListener target = (IABTReferenceListener)e.nextElement();
         er = target.notifyReferenceAdd(session,(ABTProperty)(ar.get(target)),owner,newValue,existing,dirty);
      }
      return er;
  };

  protected ABTError notifyReferenceRemove (ABTUserSession session,ABTValue removedValue, boolean dirty)
  {
      Hashtable ar = getTarget(null);
      if (ar == null)
         return null;
      int i = 0;
      ABTError er = null;
      Enumeration e = ar.keys();
      while ((e.hasMoreElements()) && (er == null))
      {
         IABTReferenceListener target = (IABTReferenceListener)e.nextElement();
         er = target.notifyReferenceRemove(session,(ABTProperty)(ar.get(target)),owner,removedValue,dirty);
      }
      return er;
  };
  protected ABTError notifyReferenceClear (ABTUserSession session, boolean dirty)
  {
      Hashtable ar = getTarget(null);
      if (ar == null)
         return null;
      int i = 0;
      ABTError er = null;
      Enumeration e = ar.keys();
      while ((e.hasMoreElements()) && (er == null))
      {
         IABTReferenceListener target = (IABTReferenceListener)e.nextElement();
         er = target.notifyReferenceClear(session,(ABTProperty)(ar.get(target)),owner,dirty);
      }
      return er;
  };
  protected ABTError notifyReferenceChildSet ( ABTUserSession session,
                                                ABTObject child,
                                              ABTProperty childProperty,
                                              ABTValue oldValue,
                                              ABTValue newValue,
                                              boolean dirty)
  {
      Hashtable ar = getTarget(childProperty);
      if (ar == null)
         return null;
      int i = 0;
      ABTError er = null;
      Enumeration e = ar.keys();
      while ((e.hasMoreElements()) && (er == null))
      {
         IABTReferenceListener target = (IABTReferenceListener)e.nextElement();
         er = target.notifyReferenceChildSet(session,(ABTProperty)(ar.get(target)),owner,child,childProperty,oldValue,newValue,dirty);
      }
      return er;
  };
  protected ABTError notifyReferenceSet (ABTUserSession session,
                                         ABTProperty childProperty,
                                         ABTValue oldValue,
                                         ABTValue newValue,
                                         boolean dirty)
  {
      Hashtable ar = getTarget(childProperty);
      if (ar == null)
         return null;
      int i = 0;
      ABTError er = null;
      Enumeration e = ar.keys();
      while ((e.hasMoreElements()) && (er == null))
      {
         IABTReferenceListener target = (IABTReferenceListener)e.nextElement();
         er = target.notifyReferenceSet(session,(ABTProperty)(ar.get(target)),owner,childProperty,oldValue,newValue,dirty);
      }
      return er;
  };
  protected ABTError notifyReferenceDelete (ABTUserSession session, ABTProperty childProperty,boolean dirty)
  {
      Hashtable ar = getTarget(childProperty);
      if (ar != null)
      {
          int i = 0;
          ABTError er = null;
          Enumeration e = ar.keys();
          while ((e.hasMoreElements()) && (er == null))
          {
             IABTReferenceListener target = (IABTReferenceListener)e.nextElement();
             er = target.notifyReferenceDelete(session,(ABTProperty)(ar.get(target)),owner, dirty);
          }
          if (er != null) return er;
      }
      Hashtable ar1 = getTarget(null);
      if (ar1 == null)
         return null;
      ABTError er1 = null;
      Enumeration e1 = ar1.keys();
      while ((e1.hasMoreElements()) && (er1 == null))
      {
         IABTReferenceListener target1 = (IABTReferenceListener)e1.nextElement();
         er1 = target1.notifyReferenceDelete(session,(ABTProperty)(ar1.get(target1)),owner, dirty);
      }
      return er1;

  };

}
