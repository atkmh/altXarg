package com.abtcorp.io.PMWRepo;

/*
 * ABTProjectSaver.java 05/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 07-17-98    SOB         Initial Implementation
 * 08-07-98    SOB         Mods to support Widgeon data model changes
 * 09-11-98    SOB         Mods to disable saving of new resources.
 * 12-09-98    SOB         #656
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTBoolean;

/**
 *  ABTProjectSaver is a helper class for the ABT Repository driver for the PMW application.
 *  It is instantiated by the driver application and by itself when a helper class object
 *  (e.g., ABTIOPMWRepoSubProject)
 *  determines that another subproject or related project needs to be populated.
 *
 *  <pre>
 *       ABTPProjectSaver ps = new ABTProjectSaver(ABTServerDriver driver,
 *                                                 ABTObject project,
 *                                                 boolean forceAddNew);
 *
 *  </pre>
 *
 * @version	    $Revision: 28$
 * @author		 S. Bursch
 * @see         ABTPMWRepoDriver
 */

public class ABTProjectSaver implements IABTPMWRepoConstants,
                                        IABTPMRuleConstants
{

   /**
    *    Driver associated with this object.
    */
   private  ABTRepositoryDriver driver_;

   /**
    *    Object space associated with this object.
    */
   private ABTObjectSpace space_;

   /**
    *    Project object reference to project being saved.
    */
   private ABTObject project_;

   /**
    *    Repository associated with the project being saved.
    */
   private ABTRepository repo_;

   /**
    *    A boolean flag.   true:  a project must be added to the repository
    *                      false: objects associated with a project are added only if they are new
    */
   private boolean forceAddNew_;

   /**
    *    A listener object that can be used to provide progress feedback to a connected application.
    */
   private IABTInternalProgressListener progress_;

   /**
    *    Constructs a project saver object for a single project.
    */
   public ABTProjectSaver(ABTRepositoryDriver driver, 
                          ABTObject projectObj, 
                          boolean forceAddNew, 
                          IABTInternalProgressListener progress)
   {
      driver_ = driver;
      project_ = projectObj;
      forceAddNew_ = forceAddNew;
      repo_ = driver_.getRepository();
      space_ = driver_.getSpace();
      progress_ = progress;
   }

   /**
    *    Saves an entire project (not just the project object itself) to an ABT Repository.
    *    The project may be a master (main) project, or it may be a subproject.  The order of
    *    saving a project's objects to the Repository is important.  This method specifies that
    *    order.  Some of a project's objects require two passes to complete.
    *    @return a value indicating success/failure of the save process
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue save() throws ABTException
   {
      try
      {
         //
         // Build an ABTArray object indicating "pass 1"
         //
         ABTArray parms = new ABTArray();
         parms.add(new ABTInteger(PASS_ONE));

         //
         // Instantiate a helper object to save the project object.
         //
         ABTIOPMWRepoProject rp = new ABTIOPMWRepoProject(space_,
                                                          driver_,
                                                          project_,
                                                          forceAddNew_,
                                                          progress_);

         //
         // save the project object.
         //
         rp.save(parms);

         //
         // Per Zane S., projects cannot be saved if that would cause new resources
         // to be created.  Consequently, the following resource-related code has been
         // commented out.  I've commented it out (instead of removing it) just in case
         // it needs to be reactivated in the future.  SOB 09-11-98

         /*
         //
         // Instantiate a helper object to save new resources.
         //
         ABTIOPMWRepoResource rr = new ABTIOPMWRepoResource(space_,
                                                            driver_,
                                                            project_,
                                                            forceAddNew_);

         //
         // Save new resource objects to the repository.
         //
         rr.save(parms);
         */


         //
         // Instantiate a helper object to save team objects
         //
         ABTIOPMWRepoTeam rtm = new ABTIOPMWRepoTeam(space_,
                                                     driver_,
                                                     project_,
                                                     forceAddNew_,
                                                     progress_);

         //
         // Save team objects to the repository.
         //
         rtm.save(parms);

         //
         // Instantiate a helper object to save the task object(s).
         //
         ABTIOPMWRepoTask rt = new ABTIOPMWRepoTask(space_,
                                                    driver_,
                                                    project_,
                                                    forceAddNew_,
                                                    progress_);

         //
         // First pass of task objects.
         //
         rt.save(parms);

         //
         // Instantiate a helper object to save the assignment object(s).
         //
         ABTIOPMWRepoAssignment ra = new ABTIOPMWRepoAssignment(space_,
                                                                driver_,
                                                                project_,
                                                                forceAddNew_,
                                                                progress_);

         //
         // save assignment objects.
         //
         ra.save(parms);

         //
         // Now do pass #2 of task objects.
         //
         parms.put(0, new ABTInteger(PASS_TWO));

         rt.save(parms);

         //
         // Instantiate a helper object to save the dependency object(s).
         //
         ABTIOPMWRepoDependency rd = new ABTIOPMWRepoDependency(space_,
                                                                driver_,
                                                                project_,
                                                                forceAddNew_,
                                                                progress_);

         //
         // Save dependency objects.
         //
         rd.save(parms);

         //
         // Instantiate a helper object to save subproject link objects.
         //
         ABTIOPMWRepoSubProject rspl = new ABTIOPMWRepoSubProject(space_,
                                                                  driver_,
                                                                  project_,
                                                                  forceAddNew_,
                                                                  progress_);

         //
         //Save subproject link objects.
         //
         rspl.save(parms);

         //
         // Instantiate a helper object to save estimating model objects.
         //
         ABTIOPMWRepoEstimatingModel rem = new ABTIOPMWRepoEstimatingModel(space_,
                                                                           driver_,
                                                                           project_,
                                                                           forceAddNew_,
                                                                           progress_);

         //
         //Save estimating model objects.
         //
         rem.save(parms);

         //
         // Instantiate a helper object to save task estimates objects.
         //
         ABTIOPMWRepoTaskEstimate rte = new ABTIOPMWRepoTaskEstimate(space_,
                                                                     driver_,
                                                                     project_,
                                                                     forceAddNew_,
                                                                     progress_);

         //
         //Save task estimate objects.
         //
         rte.save(parms);

         //
         // Instantiate a helper object to save custom field value objects.  Currently,
         // only the project object and task objects will have custom field values.
         //
         ABTIOPMWRepoCustomFieldValue rcfv = new ABTIOPMWRepoCustomFieldValue(space_,
                                                                           driver_,
                                                                           project_,
                                                                           forceAddNew_,
                                                                           progress_);

         //
         //Save custom field value objects.
         //
         rcfv.save(parms);

         //
         // Instantiate a helper object ot save deliverable objects and (perhaps) task
         // deliverable link tuples (into the PRTaskDelivLink table).
         //
         ABTIOPMWRepoDeliverable rdlv = new ABTIOPMWRepoDeliverable(space_,
                                                                    driver_,
                                                                    project_,
                                                                    forceAddNew_,
                                                                    progress_);

         //
         // Save deliverable objects.
         //
         rdlv.save(parms);

         //
         // Instantiate a helper object to save constraint objects for tasks.
         //
         ABTIOPMWRepoConstraint rc = new ABTIOPMWRepoConstraint(space_,
                                                    driver_,
                                                    project_,
                                                    forceAddNew_,
                                                    progress_);

         //
         // Save constraint objects.
         //
         rc.save(parms);

         //
         // Instantiate a helper object to save note objects for projects, tasks,
         // assignments, and resources.
         //
         ABTIOPMWRepoNote rn = new ABTIOPMWRepoNote(space_,
                                                    driver_,
                                                    project_,
                                                    forceAddNew_,
                                                    progress_);

         //
         // Save note objects.
         //
         rn.save(parms);
         
         //
         // Now increment the project's version number by 1.  Only increment the
         // the object space's project object, not the Repository's version of the project.
         // Incrementing the project's version number after a successful save mimics the
         // behavior after a successful populate (see ABTProjectPopulator.populate()).
         //
         ABTValue version = rp.getValue(project_, OFD_VERSION);
         short ver = version.shortValue();
         rp.setValue(project_, OFD_VERSION, new ABTShort((short)(ver + 1)));
         
         //
         // We've just completed writing the project to a repository.  Make sure the copy of the project
         // in the space is marked as READ/WRITE and fully populated. The project could have been a brand 
         // new project and would be marked READONLY.  It's cheaper just to set the property to READ/WRITE 
         // than to ask and then conditionally
         // set the property.
         //
         rp.setValue(project_, OFD_READONLY,         new ABTBoolean(false) );
         rp.setValue(project_, OFD_ISFULLYPOPULATED, new ABTBoolean(true) );
         
         //
         // Set the source repository name and nullify any fromFile name.  These particular setValue()
         // invocations are not so important when merely doing a save/saveAs back to the same repository
         // from which the original project was populated.  However, it becomes very important if the operation
         // is saveAs to a different repository.  In that case, subsequent saves of the project could possibly
         // fail, or worse, cause an existing project in the wrong repository to be overwritten.
         //
         rp.setValue(project_, OFD_REPONAME,         new ABTString(repo_.getName()) ); /* #656 */
         rp.setValue(project_, OFD_FROMFILE,         null );                           /* #656 */

         return (ABTValue) null;
      }
      finally
      {
      }
   }

   /**
    *
    */

}