package com.abtcorp.io.team.connect.data;

public interface ManagerKey
{
   public Object getManagerKey();
}