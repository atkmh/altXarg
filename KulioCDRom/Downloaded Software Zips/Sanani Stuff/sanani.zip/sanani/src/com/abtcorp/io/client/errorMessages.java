package com.abtcorp.io.client;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.io.client".intern();
public static final ABTErrorCode ERR_0 = new ABTErrorCode(Package, "ERR_0", UNRECOVERABLE_ERROR );

}