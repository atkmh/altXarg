package com.abtcorp.io.team.connect;

import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.team.NotePopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTBoolean;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.idl.IABTPropertyType;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ConnectNotePopulator extends NotePopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants, IABTPropertyType
{
   public ConnectNotePopulator() {}

   public ConnectNotePopulator(ABTRepositoryDriver driver, String objectType, ABTObjectSpace space, ABTUserSession session)
   {
      super(driver,objectType,space,session);
      checkProperties(OBJ_TW_NOTE,FLD_TW_DELETED,PROP_BOOLEAN);
   }

   public void addProperties()
   {
      checkProperties(OBJ_TW_NOTE,FLD_TW_DELETED,PROP_BOOLEAN);
   }
}