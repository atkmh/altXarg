package com.abtcorp.hub;

/*
 * ABTRule.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;
import java.util.Enumeration;
/**
 * ABTRule is the base class allowing common handling of all business rules
 * See "public getter/setters/validation routines to be overwritten by derived rule implementations"
 * for functions to be overwritten by rule implementations
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */

public abstract class ABTRule extends ABTRuleUtility
{

   private ABTProperty deletedProperty = null;
   private ABTProperty remoteProperty = null;
   private ABTProperty hasChangedProperty = null;
   private ABTArray indices = null;

   private ABTHashtable unloadedProperties = null;

   	/**
	 *	dictionary : reference to dictionary entry
	 */
   private ABTObjectSpace myObjectSpace;

   private  ABTPropertySet my_properties;

   private ABTRowSet my_rowset;



   private String my_name;

   private String objectPath;
   private String objectExtension;

   private Class objectClass;
   private Class objectClassSet;

   protected boolean notifySet = false;


   private ABTInteger _updateable = new ABTInteger(PROP_KUPDATABLE);
   private ABTInteger _enforceNotNull = new ABTInteger(PROP_KENFORCENOTNULL);
   private ABTInteger _enforceType = new ABTInteger(PROP_KENFORCETYPE);
   private ABTInteger _visible = new ABTInteger(PROP_KVISIBLE);
   private ABTInteger _useDefault = new ABTInteger(PROP_KUSEDEFAULT);
   private ABTInteger _defaultValue = new ABTInteger(PROP_KDEFAULTVALUE);


   public String dump(int indent ,int level)
   {
      StringBuffer sb;
      switch (level)
      {
         case 0:
            return (my_name );
         default:
            sb = new StringBuffer();
            sb.append(my_name +  com.abtcorp.core.ABTUtil.newLine(indent+1) + " - ");
      	   sb.append("objectPath : " + objectPath + com.abtcorp.core.ABTUtil.newLine(indent+1) + " - ");
      	   sb.append("objectExtension " + objectExtension + com.abtcorp.core.ABTUtil.newLine(indent+1) + " - ");
            if (objectClass == null)
               sb.append("objectClass = null " + com.abtcorp.core.ABTUtil.newLine(indent+1) +" - ");
            else
               sb.append("objectClass : " + objectClass.toString() + com.abtcorp.core.ABTUtil.newLine(indent+1) + " - ");
            if (objectClassSet == null)
               sb.append("objectClassSet = null " + com.abtcorp.core.ABTUtil.newLine(indent+1) + " - ");
            else
               sb.append("objectClassSet : " + objectClassSet.toString() + com.abtcorp.core.ABTUtil.newLine(indent+1) + " - ");
            return sb.toString();
      }

   }

//==========================================================================================
  /**
   * Default Constructor, creates the first (default) entry
   */

	protected  ABTRule()
	{
      my_properties = new ABTPropertySet(this);
      unloadedProperties = new ABTHashtable();

      addProperty(PROP_DELETED,
                  PROP_DELETED,
                  PROP_BOOLEAN,
                  false,
                  true,
                  true,
                  false,
                  null,
                  null,
                  null);
      ABTBoolean b = ABTBoolean.True();
      ABTProperty prop = (ABTProperty)getProperties().back();
      deletedProperty = prop;

      prop.setPropertyKey(PROP_KINTERNALUSE,b);
      prop.setPropertyKey(PROP_KEDITABLE,ABTBoolean.False());

      addProperty(PROP_REMOTEID,
                  PROP_REMOTEID,
                  PROP_ID,
                  false,
                  true,
                  true,
                  false,
                  null,
                  null,
                  null);
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KINTERNALUSE,b);
      prop.makeIndex();
      
      remoteProperty =prop;

      addProperty(PROP_HASCHANGED,
                  PROP_HASCHANGED,
                  PROP_BOOLEAN,
                  false,
                  true,
                  true,
                  false,
                  null,
                  null,
                  null);
    prop = (ABTProperty)getProperties().back();
    hasChangedProperty = prop;
    prop.setPropertyKey(PROP_KEDITABLE, ABTBoolean.False());
    prop.setPropertyKey(PROP_KINTERNALUSE,b);
	}

   protected final ABTArray getIndices()
   {

      return indices;
   }

   /**
   *  constructor - create a ABTClassDictionary of given classtype with given name
   * @param caller_ ObjectSpace building this dictionary
   * @param name_ name of dictionary entry
   * @param objectPath - path to runtime objects (i.e. ABTObject/ABTObjectSet)
   * @param objectExtension - i.e. "", "com", "rmi" etc.
    */
   protected final ABTError instantiate( ABTObjectSpace caller_,
                                 String name_,
                                 String objectPath_,
                                 String objectExtension_)

   {
      Class newClass;

      my_name = name_;

      // definitions objectspace-reference
      myObjectSpace = caller_;

      // definitions for dynamic class-overloading
      if (objectPath_ != null)
         objectPath = objectPath_;
      else
         objectPath = "com.abtcorp.hub";
      if (objectExtension_ != null)
         objectExtension = objectExtension_;
      else
         objectExtension = "";

// now deal with the ABTObjects....
      // attempt to load rule class
      try
      {
         objectClass = Class.forName (objectPath + ".ABTObject" + objectExtension );
      }
      catch (Exception e)
      {
         return
               new ABTErrorHub( this.getName() +  "->instantiate",
                             errorMessages.ERR_21,e);

      }
      if (objectClass == null) //whoops...
        return
               new ABTErrorHub( this.getName() +  "->instantiate",
                             errorMessages.ERR_21,new ABTString(objectPath + ".ABTObject" + objectExtension + "  not found "));

      try
      {
         objectClassSet = Class.forName (objectPath + ".ABTObjectSet" + objectExtension );
      }
      catch (Exception e)
      {
         return
               new ABTErrorHub( this.getName() +  "->instantiate",errorMessages.ERR_21,e);
      }
      if (objectClassSet == null) //whoops...
            return
               new ABTErrorHub( this.getName() +  "->instantiate",
                             errorMessages.ERR_21,new ABTString(objectPath + ".ABTObject" + objectExtension + "  forName not found "));

      return null;
   }

public ABTHashtable getUnloadedProperties()
{
   return  unloadedProperties;
}

public ABTBoolean anyUnloadedProperties()
{
   if (unloadedProperties.size() > 0)
      return ABTBoolean.True();
   return ABTBoolean.False();

}
/**
* return the path component of my class
* i.e. com.abtcorp.objectModel.pm.Task will return com.abtcorp.objectModel.pm
* @return String
*/
public String getPath()
{
   String s = getClass().getName();
   int i = s.lastIndexOf('.');
   String result = s.substring(0,i);
   return result;

}
//=====================================
// properties
//=====================================

   protected abstract void setDefaultProperties();


   protected  void setDefaultIndex()
   {
      indices = new ABTArray();
      int i = 0;
      Enumeration e = my_properties.elements();
      while (e.hasMoreElements())
      {
         ABTProperty prop = (ABTProperty)e.nextElement();
         if (prop.isIndex())
         {
            prop.setLookupIndex(i);
            i++;
            indices.add(prop);
         }
      }
      my_rowset = new ABTRowSet(this);
   }

   /**
   * add a property to my list
   */
   protected ABTError addProperty(
                                 String name_,
                                 String caption_,
                                 int type_,
                                 boolean virtual_,
                                 boolean visible_,
                                 boolean updatable_,
                                 boolean transient_,
                                 String referenceType,
                                 String propertyRule,
                                 ABTValue defaultValue
                                 )
      {
         ABTRule referenceRule = null;
         ABTFieldRule fieldRule = null;
         ABTError err = null;

         if ((type_ == PROP_OBJECT) || (type_ == PROP_OBJECTSET))
         {
            if (referenceType == null)
            {
               err = new ABTErrorHub(this.getName() +  "->addProperty",
                            errorMessages.ERR_27,
                            "Missing Reference-type name for Object/ObjectSet");
               unloadedProperties.put(new ABTString(name_),err);
               return err;
            }

            try
            {
               referenceRule = (ABTRule) myObjectSpace.loadRule(referenceType);
            }
            catch (Exception e)
            {
               err =  new ABTErrorHub(this.getName() +  "->addProperty",
                               errorMessages.ERR_28,
                               e);
               unloadedProperties.put(new ABTString(name_),err);
               return err;
            }
         }
         // field validation
         if (propertyRule == null)
            fieldRule = new ABTDefaultFieldRule();
         else
         {
            try
            {
               fieldRule = (ABTFieldRule) ABTObjectSpace.loadObject(getPath() + ".fr",propertyRule);
            }
            catch (Exception e)
            {
               err =  new ABTErrorHub(this.getName() +  "->addProperty",
                               errorMessages.ERR_29,
                               e);
               unloadedProperties.put(new ABTString(name_),err);
               return err;
            }
         }
         if (fieldRule != null)
            fieldRule._space = myObjectSpace;
            
         // create the new property
         ABTProperty prop = new ABTProperty(name_,caption_,type_);
         // set the fields

         prop.setFieldRule(fieldRule);

         if (!(visible_))
            prop.setNotVisible();
         if (!(updatable_))
            prop.setNotUpdatable();
         if (virtual_)
            prop.setVirtual();

         if (transient_)
            prop.setTransient();


         prop.setReferenceType(referenceRule);

         prop.setDefaultValue(defaultValue);


         return my_properties.addProperty(prop);


      }





//==========================================================================================
// private/protected functions not to be modified in derived rule implementations
//==========================================================================================
   /**
   * return my name
   */
   public final String getName()
   {
      return my_name;
   }


   /**
   *  return an instance of the ABTObject class described by this dictionary
   *  entry
   * @param id_ - id of object
   * @requiredParameters list of required arguments
   * @return ABTObject
   */
    protected ABTValue getInstance(ABTUserSession session ,ABTID id_,ABTHashtable requiredParameters)
    {
        ABTObject obj= null;
        ABTRow row = null;
        // add it to my list...
        row = addRow(session,id_,requiredParameters);
        if (row == null)
            return new ABTErrorHub(getClass().getName() + "->getInstance()",errorMessages.ERR_30,"row returned null");
        // create a new ABTID
        try
        {
           obj = (ABTObject)objectClass.newInstance();
        }
        catch (Exception e)
        {
            return new ABTErrorHub(getClass().getName() + "->getInstance()",errorMessages.ERR_31,e);
        }
        if (obj != null)
        {
            obj.instantiate(this,id_,row);
    	    ABTValue v = initializeRow(session,obj,requiredParameters);
    	    if (ABTError.isError(v))
    	    {
        	    row.delete(session); // remove the newly created row....
        	    obj = null;
    	        return v;
    	    }
        }
        else
            return new ABTErrorHub(getClass().getName() + "->getInstance()",errorMessages.ERR_31,"Object returned null");

        return obj;

    }






   /**
   *  return an instance of the ABTObjectSet described by this dictionary
   *  entry
   * @return ABTObjectSet
   */
    protected ABTObjectSet getSet(ABTUserSession session)
    {
        ABTObjectSet abt;
        // add it to my list...
        try
        {
           abt = (ABTObjectSet)objectClassSet.newInstance();
        }
        catch (Exception e)
        {
            return null;
        }
        if (abt != null)
        {
            abt.instantiate(session,this,null);
//            users.add(abt);
        }
        return abt;

    }


   /**
   *  return an instance of the ABTObjectSet described by this dictionary
   *  entry
   * @return ABTObjectSet
   */
    public ABTObjectSet returnCurrentSet(ABTUserSession session)
    {
        ABTObjectSet abt;
        // add it to my list...
        try
        {
           abt = (ABTObjectSet)objectClassSet.newInstance();
        }
        catch (Exception e)
        {
            return null;
        }
        if (abt != null)
        {
            abt.instantiate(session,this,my_rowset);
//            users.add(abt);
        }
        return abt;

    }


    /**
    *  Return an existing ABTObject based on a given type with the new name with the subset of properties
    *  @param criteria - search expression
    *  @return ABTValue - existing ABTObject or ABTError for error
    * ToDo:
    *   1 - implement
    */
    public ABTValue findObject(  ABTUserSession session,String criteria)
    {
         ABTValue val = returnCurrentSet(session);
         if (!(val instanceof ABTObjectSet))
            return val; // most likely error
         return ((ABTObjectSet)val).select(session,criteria);
    }


	public synchronized final ABTValue findExistingObject(ABTUserSession session,String prop, ABTValue id)
	{
      return findExistingObject (session,getProperty(session,prop),id);
	}

	public synchronized final ABTValue findExistingObject(ABTUserSession session,ABTString prop, ABTValue id)
	{
      return findExistingObject (session,getProperty(session,prop),id);
	}

	public synchronized final ABTValue findExistingObject(ABTUserSession session,int prop, ABTValue id)
	{
      return findExistingObject (session,getProperty(session,prop),id);
	}

   /**
   *  Return an existing ABTObject based on a given type with the new name with the subset of properties
   *  @param id - remote id
   *  @return ABTValue - existing ABTObject or ABTError for error
   * ToDo:
   */
	public synchronized final ABTValue findExistingObject(ABTUserSession session,ABTProperty prop, ABTValue id)
	{
//      ABTID aid_ = myObjectSpace.createNewABTID();
//      if (id == null)
//        aid_.setRemote(id);
      ABTRow row = getExistingRow(session,prop,id);
      if (row != null)
         return row.getObject();
      else
         return new ABTErrorHub(this.getName() +  "->findExistingObject",errorMessages.ERR_13,id);
   }

	public synchronized final ABTValue findObject(ABTUserSession session,String prop, ABTValue id)
	{
      return findObject (session,getProperty(session,prop),id);
	}

	public synchronized final ABTValue findObject(ABTUserSession session,ABTString prop, ABTValue id)
	{
      return findObject (session,getProperty(session,prop),id);
	}

	public synchronized final ABTValue findObject(ABTUserSession session,int prop, ABTValue id)
	{
      return findObject (session,getProperty(session,prop),id);
	}

   /**
   *  Return an existing ABTObject based on a given type with the new name with the subset of properties
   *  @param id - remote id
   *  @return ABTValue - existing ABTObject or ABTError for error
   * ToDo:
   */
	public synchronized final ABTValue findObject(ABTUserSession session,ABTProperty prop, ABTValue id)
	{
//      ABTID aid_ = myObjectSpace.createNewABTID();
//      if (id == null)
//        aid_.setRemote(id);
      ABTRow row = getRow(session,prop,id);
      if (row != null)
         return row.getObject();
      else
         return new ABTErrorHub(this.getName() +  "->findObject",errorMessages.ERR_13,id);
   }


   /**
   *  Return an existing ABTObject based on a given type with the new name with the subset of properties
   *  @param localID - local id
   *  @return ABTValue - existing ABTObject or ABTError for error
   * ToDo:
   */
   public ABTValue findObject( ABTUserSession session,int localID)
   {
      ABTRow row = getRow(session,localID);
      if (row != null)
         return row.getObject();
      else
         return new ABTErrorHub(this.getName() +  "->findObject",errorMessages.ERR_13,new ABTDouble(localID));
   }

   /**
   * return the asscoiated objectspace
   * @return ABTObjectSpace owner of this dictionary
    */
   public ABTObjectSpace getObjectSpace()
      {
         return myObjectSpace;
      }


   /**
   *  return the set of properties for this class
   */
   protected final ABTPropertySet getProperties()
   {
	   return my_properties;
   }

   /**
   *  return a particular property
   *  @param session - user session/security manager
   *  @param index int index in property-list
   *  @return ABTProperty or null
   */
   public final ABTProperty getProperty(ABTUserSession session,int index)
   {
       try
       {
    	   return (ABTProperty)my_properties.at(index);
       }
       catch (Exception e)
       {
        return null;
       }
   }

   /**
   *  return a particular property
   *  @param index int index in property-list
   *  @return ABTProperty or null
   */
   public final ABTProperty getProperty(ABTUserSession session, ABTString name)
   {
      return getProperty(session,name.stringValue());
   }
   /**
   *  return a particular property
   *  @param index int index in property-list
   *  @return ABTProperty or null
   */
   public final ABTProperty getProperty(ABTUserSession session, String name)
   {
      int index =  my_properties.indexForName(name);
       try
       {
    	   return (ABTProperty)my_properties.at(index);
       }
       catch (Exception e)
       {
        return null;
       }
   }


 	/**
	*  return my rowset
	* @return ABTRowSet - current active rowset
	 */
	protected final ABTRowSet getRowSet()
	{
		return my_rowset;
	}

 	/**
	*  return a row with a specific ID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
	protected synchronized final ABTRow getRow(ABTUserSession session,ABTProperty prop, ABTValue id)
	{
      try
      {
   		return my_rowset.get(session,prop.getLookupIndex(),id);
      }
      catch (Exception e)
      {
         return null; // invalid property;
      }
	}
 	/**
	*  return a row with a specific ID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
	protected synchronized final ABTRow getRow(ABTUserSession session,ABTString prop, ABTValue id)
	{
      return getRow (session,getProperty(session,prop),id);
	}

 	/**
	*  return a row with a specific ID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
	protected synchronized final ABTRow getRow(ABTUserSession session,int prop, ABTValue id)
	{
      return getRow (session,getProperty(session,prop),id);
	}


	protected synchronized final ABTRow getExistingRow(ABTUserSession session,ABTProperty prop, ABTValue id)
	{
      try
      {
   		return my_rowset.getExisting(session,prop.getLookupIndex(),id);
      }
      catch (Exception e)
      {
         return null; // invalid property;
      }
	}

	protected synchronized final ABTRow getExistingRow(ABTUserSession session,String prop, ABTValue id)
	{
      return getExistingRow (session,getProperty(session,prop),id);
	}

	protected synchronized final ABTRow getExistingRow(ABTUserSession session,ABTString prop, ABTValue id)
	{
      return getExistingRow (session,getProperty(session,prop),id);
	}

	protected synchronized final ABTRow getExistingRow(ABTUserSession session,int prop, ABTValue id)
	{
      return getExistingRow (session,getProperty(session,prop),id);
	}


 	/**
	*  return a row with a specific localID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
	protected final ABTRow getRow(ABTUserSession session,int localID)
	{
		return my_rowset.get(session,localID);
	}

 	/**
	*  create a new row for this id
	*  @param id - ABTID to be adddd
	* @return ABTRow - new row with id
	 */
	protected final ABTRow addRow(ABTUserSession session,ABTID id, ABTHashtable requiredParameters)
	{
	   ABTRow row = my_rowset.add(session,id);
	   // initialize if necessary
	   return row;
	}

   /**
   * return number of non-virtual Properties
   * @return int
   */
   protected int countNonVirtualProperties()
   {
      return my_properties.countNonVirtualProperties();

   }


   protected int indexForName(String name)
   {
      return my_properties.indexForName(name);

   }

   protected String nameForIndex(int index)
   {
      return my_properties.nameForIndex(index);
   }





//==========================================================================================
// getter/setters/validation routines to be overwritten by derived rule implementations
//==========================================================================================
   /**
   * initializes a row to the default values
   * walk through the properties and if there is any value where the default value
   * is not null set it in the row
   * @param requiredParamters list of parameters for rule processing
   */

   protected ABTError initializeRow(ABTUserSession session, ABTObject object,ABTHashtable requiredParameters)
   {
      ABTValue val = onInitialize ( session, object, requiredParameters);
      if (ABTError.isError(val))
        return (ABTError)val;

 //   ... do that on 'any' first call to get for this thing
 //   ... invoked by abtobject but pointer set in row
      Enumeration e = my_properties.elements();
      while (e.hasMoreElements())
      {
         ABTProperty prop = (ABTProperty)e.nextElement();

         val = onInitialize(session,object,prop,prop.getDefaultValue(),requiredParameters);
         if (ABTError.isError(val))
           return (ABTError)val;
         val = prop.getFieldRule().onInitialize (session,
                                        object,
                                        prop,
                                        val,
                                        requiredParameters
                                      );
         if (ABTError.isError(val))
            return (ABTError)val;
         if (val != null)
            val = write(session,object,prop,ABTEmpty.getEmpty(),val,true);
            if (ABTError.isError(val))
               return (ABTError)val;
      }
      return null;
   }


//+++++++++++++++
// Getters
//+++++++++++++++


  /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param requestor ABTObject requesting
   * @param property - index of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session, ABTObject requestor,int property, int key)
   {
      ABTValue val = null;
      try
      {
          ABTProperty prop = getProperty(session, property);
          return getPropertyKey(session, requestor,prop,new ABTInteger(key));
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTRule.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }


  /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param requestor ABTObject requesting
   * @param property - index of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,ABTObject requestor,int property, ABTValue key)
   {
      ABTValue val = null;
      try
      {
          ABTProperty prop = getProperty(session,property);
          return getPropertyKey(session, requestor,prop,key);
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTRule.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }

  /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param requestor ABTObject requesting
   * @param property - index of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,ABTObject requestor,int property, String key)
   {
      ABTValue val = null;
      try
      {
          ABTProperty prop = getProperty(session,property);
          if (prop == null)
             return new ABTErrorHub( this.getName() +  "->getPropertyKey",
                       errorMessages.ERR_32,"Index : " + property );
          val = prop.getPropertyKey(key);
          return val;
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTRule.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }

  /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param requestor ABTObject requesting
   * @param property - property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,ABTObject requestor,ABTProperty property, ABTValue key)
   {
      try
      {
          ABTValue val = null;
          if (property == null)
             return new ABTErrorHub( this.getName() +  "->getPropertyKey",
                       errorMessages.ERR_32,"Index : " + property );

          val = property.getPropertyKey(key);
          if (key instanceof ABTInteger)
          {
             ABTValue v1 = onPropertyKey(session,requestor,property,key.intValue(),val);
             if (v1 != null)
                return v1;
             return property.getFieldRule().onPropertyKey(session,requestor,property,key.intValue(),val);
          }
          else
             return val;
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTRule.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }

  /**
   * Get the parameter with a given index
   * @param requestor ABTObject requesting the change
   * @param parameterIndex index of parameter to be returned
   * @param parameterName name of parameter to be returned in parameter list
   * @param paramters list of parameters for rule processing
   * @return ABTValue - check for ABTError....
   */
  protected final ABTValue getValue (
                  ABTUserSession session,
                  ABTObject requestor,
                   int parameterIndex,
                   boolean dirty,
                   ABTHashtable parameters)
  {
   ABTValue val = null;
   ABTProperty prop = getProperty(session,parameterIndex);
   if (prop == null)
      return new ABTErrorHub( this.getName() +  "->getValue",
                errorMessages.ERR_32,"Index : " + parameterIndex );

   ABTValue bool = getPropertyKey(session,requestor,prop,_visible);
   if (ABTError.isError(bool))
    return bool;
   if ((bool instanceof ABTBoolean) && (bool.booleanValue() == false))
          return new ABTErrorHub( this.getName() +  "->getValue",
                    errorMessages.ERR_41,prop);


   if (!(prop.isVirtual()))
      val = requestor.getRowValue (
                                    session,
                                    prop);
   if (dirty)
    return val;

   val = onGet(session,requestor,prop,val,parameters);
      if (ABTError.isError(val))
        return (ABTError)val;

   val =  prop.getFieldRule().onGet(session,
                            requestor,prop,
                            val,
                            parameters);
    if (ABTValue.isEmpty(val))
    {
         bool = getPropertyKey(session,requestor,prop,_useDefault);
        if (ABTError.isError(bool))
            return val;
        if ((bool instanceof ABTBoolean) && (bool.booleanValue() == true))
            return getPropertyKey(session,requestor,prop,_defaultValue);
        else
            return val;
    }
    else
        return val;


  }

  /**
   * Allows common handling of property keys. E.g. all properties
   * in an object can be set to read-only for specific circumstances
   * By default this returns null and the field-specific rule will be invoked
   *
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param myProperty - my ABTProperty
   * @param key - the key in the property (e.g. PROP_KVISIBLE)
   * @param defaultValue - the default for the property key
   * @return ABTValue - the default is null (no general modifications)
   * @see com.abtcorp.IABTPROPERTYYPES
   */
  protected ABTValue onPropertyKey (ABTUserSession session,ABTObject parent, ABTProperty myProperty, int key, ABTValue defaultValue)
  {
     return null;
  }

 /**
   * Get a particular position in the set
   * @param requestor ABTObjectSet requesting the change
   * @param index index of object in set
   * @param paramters list of parameters for rule processing
   * @return ABTValue - check for ABTError....
   */
  protected final ABTValue getValue (
                   ABTUserSession session,
  	               ABTObjectSet requestor,
	               int index,
                   boolean dirty,
                   ABTHashtable parameters)
  {
    //t.b.d.
        ABTValue v = requestor.get(session,index);
        // v can only be reference, error or null
        if ((ABTError.isError(v)) || (v == null)) return v;

        return v;
  }





//+++++++++++++++
// Setters / modifiers
//+++++++++++++++




  /**
   * Set the parameter with a given index to the provided value
   * @param requestor ABTObject requesting the change
   * @param parameterIndex index of parameter to be set in parameter list
   * @param newValue new object value
   * @param oldValue current value
   * @param paramters list of parameters for rule processing
   * @return ABTValue new Value or ABTError
   */
	protected final  ABTValue setValue(
	               ABTUserSession session,
	               ABTObject requestor,
	               int parameterIndex,
	               ABTValue newValue,
	               ABTValue oldValue,
	               ABTHashtable parameters)
	{

      ABTValue val = null;
      ABTProperty prop = getProperty(session,parameterIndex);
      if (prop == null)
          return new ABTErrorHub( this.getName() +  "->setValue",
                    errorMessages.ERR_32,"Index : " + parameterIndex);
      ABTValue bool = getPropertyKey(session,requestor,prop,_updateable);
      if (ABTError.isError(bool))
        return bool;
      if ((bool instanceof ABTBoolean) && (bool.booleanValue() == false))
          return new ABTErrorHub( this.getName() +  "->setValue",
                    errorMessages.ERR_42,prop);

      bool = getPropertyKey(session,requestor,prop,_enforceNotNull);
//#356      if (ABTError.isError(bool))
//#356        return bool;
      if ((!(ABTError.isError(bool))) && (!(ABTValue.isNull(bool))) && (bool instanceof ABTBoolean) && (bool.booleanValue() == true) && (newValue == null))
      {
            return new ABTErrorHub( this.getName() +  "->setValue",
                        errorMessages.ERR_43,prop);
      }


      bool = getPropertyKey(session,requestor,prop,_enforceType);
//#356      if (ABTError.isError(bool))
//#356        return bool;
      if ((!(ABTError.isError(bool))) && (!(ABTValue.isNull(bool))) && (bool instanceof ABTBoolean) && (bool.booleanValue() == true) && (newValue != null))
      {
       // do type checking
           newValue = prop.coerceType(newValue);
           if (ABTError.isError(newValue))
            return newValue;
      }



      val = onSet(session,requestor,prop,oldValue,newValue,parameters);
      if (ABTError.isError(val))
        return (ABTError)val;
      return prop.getFieldRule().onSet ( session,requestor,prop,oldValue,
                                        val,
                                        parameters
                                      );
	}


  /**
   * Remove this object from ALL lists and mark it as deleted
   * @param requestor ABTObject requesting the change
   */
	protected final  ABTValue delete(ABTUserSession session,
	               ABTObject requestor)
	{

      return onDelete ( session,requestor);
	}





// Actions for sets of objects (e.g. ChildTasks etc.)




   /**
   * Add an existing instance with default values to this set
   * @param requestor ABTObjectSet requesting the change
   * @param newValue - newly !empty! value to be added
   * @return ABTValue - return the newValue, modify it or return ABTError if update should not be performed
   */
   protected final ABTValue add( ABTUserSession session,
                            ABTObjectSet requestor,
                           ABTValue newValue,
                           boolean existing)
   {
        try
        {
            if (enforceType())
            {
                if (!(ABTProperty.isCloseEnoughType(PROP_OBJECTSET, this,newValue)))
                    return new ABTErrorHub(getName()+ "->add",errorMessages.ERR_20,newValue);
            }
            if (enforceUniqueness())
            {
                if  (requestor.contains( session, (ABTObject)newValue))
                    return new ABTErrorHub(getName()+ "->add",errorMessages.ERR_48,newValue);
            }
            return  onAdd (session, requestor,newValue, existing);
        }
        catch (Exception e)
        {
            return new ABTErrorHub(getName()+ "->add",errorMessages.ERR_49,e);
        }

   }




   /**
   * Remove an instance from this set
   * @param requestor ABTObjectSet requesting the change
   * @param removeValue - value of field after the change
   * @return ABTValue - return the value to be removed or ABTError if update should not be performed
   */
   protected final ABTValue remove( ABTUserSession session,
                            ABTObjectSet requestor,
                           ABTValue removeValue,
                           int index)
   {

      return onRemove (session, requestor,  removeValue,index);
   }





   /**
   * Clear the whole set
   * @param requestor ABTObjectSet requesting the change
   */
   protected final ABTValue clear(  ABTUserSession session,ABTObjectSet requestor)
   {
      return onClear (session, requestor);
   }

  /**
   * Delete the object from the rowset
   * @param requestor ABTObject to be deleted
   * @return ABTValue the value finally assign (check for ABTError)
   */
	protected final ABTValue deleteObject(ABTUserSession session,ABTObject requestor)
	{
      //notify
      if (requestor.refAdapter != null)
      {
         ABTError er = requestor.refAdapter.notifyReferenceDelete(session,(ABTProperty)my_properties.at(0),false);
         if (er != null)
            return er;
         requestor.refAdapter.removeReferences();
         requestor.refAdapter = null;
      }
	    return requestor.getRow().delete(session);
	}

protected ABTProperty getChangedProperty()
{
    return hasChangedProperty;
}
//=================================================
// rules
//=================================================

protected void  createDefaultObject(ABTUserSession session)
{
}
//+++++++++++++++
// Getters
//+++++++++++++++

  /**
   * Default onGet, which just returns the passed in value unmodified
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param property - the property accessed
   * @param myValue - the value currently available
   * @param paramters list of parameters for rule processing
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onGet (ABTUserSession session,ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters);
/*  {
     return myValue;
  }
*/
  /**
   * Default onGet for objectSets - which just returns the passed in value unmodified
   * @param parent - my ABTObjectSet container (e.g. Tasks, Projects etc.)
   * @param myValue - the value which is about to be retrieved
   * @param myIndex - the position of this value in the current ObjectSet
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onGet (ABTUserSession session,ABTObjectSet parent, ABTObject myValue, int myIndex, ABTHashtable parameters);
/*
  {
     return myValue;
  }
*/

//+++++++++++++++
// validators
//+++++++++++++++
  /**
   * Default 'would this be a valid value?' if added to the set?
   * @param parent - my ABTObject container (e.g. Tasks, Projects etc.)
   * @param myValue - the value to be added
   * @param paramters list of parameters for rule processing
   * @return ABTValue - (ABTBoolean or ABTError)
   */
  abstract protected ABTValue isValid (ABTUserSession session,ABTObjectSet parent, ABTValue myValue, ABTHashtable parameters);

/*  {
     return ABTBoolean.True();
  }
*/

//+++++++++++++++
// Setters / modifiers
//+++++++++++++++

  /**
   * Default onSet for modification of a position within an object
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param property - the property accessed
   * @param myValue - the value currently available i.e. the ABTObject at this position
   * @param newValue - the new value, i.e. the ABTObject to be placed instead
   * @param paramters list of parameters for rule processing
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onSet (ABTUserSession session,ABTObject parent, ABTProperty property,  ABTValue myValue, ABTValue newValue, ABTHashtable parameters);

/*  {
     return newValue;
  }
*/

  /**
   * Default onInitialize for setting /modifying additional values
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param property - the property accessed
   * @param myValue - the current default value
   * @param paramters list of parameters for rule processing
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onInitialize (ABTUserSession session, ABTObject parent, ABTProperty property,  ABTValue myValue, ABTHashtable parameters);
/*  {
     return myValue;
  }
*/


  /**
   * Default onAdd for adding an object to an ObjectSet
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param newValue - the new value, i.e. the ABTObject to be placed instead
   * @param existing - true if the passed in new Value is an existing ABTObject
   *  , false if it was initialized to default values
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onAdd (ABTUserSession session,ABTObjectSet parent, ABTValue newValue,boolean existing);
/*  {
     return parent.addToSet(session,newValue,existing);
  }
*/

  /**
   * Default remove of an object
   * @param parent - the object to be removed
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onDelete (ABTUserSession session,ABTObject parent);
/*  {
     return deleteObject(session,parent);
  }
*/

  /**
   * Default onRemoving for removing an element for the objectset
   * @param parent - my ABTObjectSet container (e.g. Task, Project etc.)
   * @param myValue - the value currently available i.e. the ABTObject at this position
   * @param myIndex - the position within this objectSet
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onRemove (ABTUserSession session,ABTObjectSet parent,  ABTValue myValue,int myIndex);
/*
  {
      return parent.removeFromSet(session,myValue,myIndex);
  }
*/


  /**
   * Default onClear for removing all elements from the set
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param property - the property accessed
   * @param myValue - the value currently available i.e. the ABTObject at this position
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onClear (ABTUserSession session,ABTObjectSet parent);
/*  {
      return parent.clearSet(session);
  }
*/

// NOTIFICATIONS
  /**
   * Notification of a set operation in an element of the objectset stored in this objectSet
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param child - the object in the childset which was modified
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
  abstract protected    ABTError notifyReferenceSet (ABTUserSession session,ABTObjectSet parent, IABTReferenceSource child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue , boolean dirty);
/*
  {
     return null;
  }
*/
  /**
   * Notification of a delete operation on an object referenced in this property
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param child - the object currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   abstract public ABTError notifyReferenceDelete (ABTUserSession session,ABTObjectSet parent, IABTReferenceSource child, boolean dirty);
/*
   {
      return null;
   }
*/
  /**
   * Default onInitialize for setting /modifying additional values
   * @param session - the current user session handle
   * @param parameters - list of required parameters
   * @return ABTValue - check for ABTError....
   */
  abstract protected ABTValue onInitialize ( ABTUserSession session,ABTObject object,ABTHashtable requiredParameters);



  /**
   * return true if strong type checking on >onADD< should be used
   * @return boolean - true if new ABTObject have to be of the same rule type
   */
  abstract protected boolean enforceType ();

  /**
   * return true if uniqueness >onADD< should be enforced
   * @return boolean - true if new ABTObject have to be unique
   */
  abstract protected boolean enforceUniqueness ();


}
