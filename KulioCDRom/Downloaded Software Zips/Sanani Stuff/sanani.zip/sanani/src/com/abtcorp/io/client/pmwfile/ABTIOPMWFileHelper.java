package com.abtcorp.io.client.pmwfile;

/*
 * ABTPMWFileHelper.java 07/14/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 07-14-98    MXA         Initial Implementation
 *
 *
 */

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTEnumerator;


import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTArray;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTFileDriver;
import com.abtcorp.io.client.pmwfile.ABTIOPMWFileDriver;
import com.abtcorp.io.client.ABTObjectSetIDList;


/**
 * ABTIOPMWFileHelper is an abstract class for the ABT PMW Local File driver.
 * It is to be instantiated by the other ABT PMW Local File helper objects.
 *
 *  <pre>
 *       ABTIOPMWFileHelper ra = new ABTIOPMWFileHelper(ABTIOPMWFileDriver driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 M. Abadian
 */

public abstract class ABTIOPMWFileHelper extends ABTFileHelper implements IABTPMRuleConstants,IABTPropertyType
{

   protected ABTIOPMWFileDriver driver_;        // the driver that uses this helper
   protected String type_;                      // the object type

   /**
   * ABTIOPMWFileHelper constructor.
   * @param driver: the reference to the driver.
   */
   ABTIOPMWFileHelper(ABTIOPMWFileDriver driver)
   {
      driver_           = driver;
      space_            = driver.getSpace();
   }

/**
 *    Processes an error situation raised by the caller.  If the severity level is 1, an
 *    exception is thrown.  For all other levels, a return to the caller is effected.
 *    @param severityLevel: the level of severity of the error; low numbers are more severe
 *    @param objType: the type of Sanani object in trouble
 *    @param exceptionName: an exception identifier string
 *    @param errorMessage: further text describing the error condition
 *    @return some kind of value (for now the severity level).
 *    @exception ABTException if the severity level is 1 (the highest severity)
 */
 public int processError(int severityLevel, String objType, String exceptionName, String errorMessage) throws ABTException
 {
   return driver_.processError(severityLevel, objType, exceptionName, errorMessage);
 }

   public void trace() throws ABTException
   {
      IABTArray arr = null;
      IABTPropertySet propset = null;

/*
      Vector taskVector = com.abtcorp.io.client.pmwfile.ABTIOPMWFileTask.taskVector_;
      IABTLocalID taskId= null;

      System.out.println("THERE ARE  " + taskVector.size()+ " TASKS");
      for (int i  = taskVector.size()-1; i >=0; i-- )
      {
         taskId  = (IABTLocalID)taskVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(taskId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_TASK);
         System.out.println("\nTASK " + ( taskVector.size() - i));
         printProperties(propset, arr);

      }

      Vector resourceVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileResource.resourceVector_;
      IABTLocalID resourceId = null;
      System.out.println("THERE ARE  " + resourceVector.size()+ " RESOURCES");
      for (int i  = resourceVector.size()-1; i >=0; i-- )
      {
         resourceId  = (IABTLocalID)resourceVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(resourceId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_RESOURCE);
         System.out.println("\nresource " + ( resourceVector.size() - i));
         printProperties(propset, arr);

      }


      Vector teamVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileTeam.teamVector_;
      IABTLocalID teamId = null;
      System.out.println("THERE ARE  " + teamVector.size()+ " TEAMS");
      for (int i  = teamVector.size()-1; i >=0; i-- )
      {
         teamId  = (IABTLocalID)teamVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(teamId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_TEAM);
         System.out.println("\nteam " + ( teamVector.size() - i));
         printProperties(propset, arr);

      }


      Vector assignmentVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileAssignment.assignVector_;
      System.out.println("THERE ARE  " + assignmentVector.size()+ " Assignments");
      IABTLocalID assignmentId = null;
      System.out.println("THERE ARE  " + assignmentVector.size()+ " ASSIGNMENTS");
      for (int i  = assignmentVector.size()-1; i >=0; i-- )
      {
         assignmentId  = (IABTLocalID)assignmentVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(assignmentId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_ASSIGNMENT);
         System.out.println("\n assignment " + ( assignmentVector.size() - i));
         printProperties(propset, arr);

      }

      Vector estModelVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileEstimatingModel.estModelVector_;
      IABTLocalID estModelId = null;
      System.out.print("\n\n" + estModelVector.size()+ " Estimating Models! ");
      if ( estModelVector.size() > 0 )
      {
        for (int i  = estModelVector.size()-1; i >=0; i-- )
        {
          estModelId  = (IABTLocalID)estModelVector.elementAt(i);
          arr         = (IABTArray)driver_.intermediateTableGet(estModelId);
          if (arr == null)
             throw new ABTException(" The element associated with the Key does not exist. ");
          propset = getProperties(OBJ_ESTIMATINGMODEL);
          System.out.println("\n EstimatingModel " + ( estModelVector.size() - i));
          printProperties(propset, arr);

        }
      }



      Vector dependencyVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileDependency.dependencyVector_;
      IABTLocalID dependencyId = null;
      System.out.println("THERE ARE  " + dependencyVector.size()+ " Depencies");
      for (int i  = dependencyVector.size()-1; i >=0; i-- )
      {
         dependencyId  = (IABTLocalID)dependencyVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(dependencyId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_DEPENDENCY);
         System.out.println("\ndependency " + ( dependencyVector.size() - i));
         printProperties(propset, arr);

      }


      Vector constraintVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileConstraint.constraintVector_;
      IABTLocalID constraintId = null;
      System.out.println("\n" + constraintVector.size()+ " Constraints");
      for (int i  = constraintVector.size()-1; i >=0; i-- )
      {
         constraintId  = (IABTLocalID)constraintVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(constraintId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_CONSTRAINT);
         System.out.println("constraint " + ( constraintVector.size() - i));
         printProperties(propset, arr);

      }


      {
        Vector CustomFieldValueVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileCustomFieldValue.prjCustFieldsVector_;
         IABTLocalID CustomFieldValueId = null;
        System.out.println("\n" + CustomFieldValueVector.size()+ "Project CustomFieldValues");
        for (int i  = CustomFieldValueVector.size()-1; i >=0; i-- )
        {
             CustomFieldValueId  = (IABTLocalID)CustomFieldValueVector.elementAt(i);
            arr     = (IABTArray)driver_.intermediateTableGet(CustomFieldValueId);
            if (arr == null)
                throw new ABTException(" The element associated with the Key does not exist. ");
            propset = getProperties(OBJ_CUSTFIELDVALUE);
            System.out.println("Prj CustomFieldValue " + ( CustomFieldValueVector.size() - i));
            printProperties(propset, arr);

         }
      }



        Vector CustomFieldValueVector = (Vector)com.abtcorp.io.client.pmwfile.ABTIOPMWFileCustomFieldValue.taskCustFieldsVector_;
        IABTLocalID CustomFieldValueId = null;
        System.out.print("\n" + CustomFieldValueVector.size()+ " Task CustomFieldValues");
        for (int i  = CustomFieldValueVector.size()-1; i >=0; i-- )
        {
            CustomFieldValueId  = (IABTLocalID)CustomFieldValueVector.elementAt(i);
            arr     = (IABTArray)driver_.intermediateTableGet(CustomFieldValueId);
            if (arr == null)
                throw new ABTException(" The element associated with the Key does not exist. ");
            propset = getProperties(OBJ_CUSTFIELDVALUE);
            System.out.println("Task CustomFieldValue " + ( CustomFieldValueVector.size() - i));
            printProperties(propset, arr);

        }

      Vector deliverableVector = com.abtcorp.io.client.pmwfile.ABTIOPMWFileDeliverable.deliverableVector_;
      IABTLocalID deliverableId= null;

      System.out.println("\n" + deliverableVector.size()+ " Deliverables");
      for (int i  = deliverableVector.size()-1; i >=0; i-- )
      {
         deliverableId  = (IABTLocalID)deliverableVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(deliverableId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_DELIVERABLE);
         System.out.println("deliverable " + ( deliverableVector.size() - i));
         printProperties(propset, arr);

      }


      Vector taskEstimateVector = com.abtcorp.io.client.pmwfile.ABTIOPMWFileTaskEstimate.taskEstimateVector_;
      IABTLocalID taskEstimateId= null;

      System.out.println("\n" +  " taskEstimates " + taskEstimateVector.size());
      for (int i  = taskEstimateVector.size()-1; i >=0; i-- )
      {
         if ( taskEstimateVector.elementAt(i) instanceof IABTLocalID)
            taskEstimateId  =(IABTLocalID) taskEstimateVector.elementAt(i);

         arr     = (IABTArray)driver_.intermediateTableGet(taskEstimateId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_TASKESTIMATE);
         System.out.println("taskEstimate " + ( taskEstimateVector.size() - i));
         printProperties(propset, arr);

      }


      Vector subProjectVector = com.abtcorp.io.client.pmwfile.ABTIOPMWFileSubProject.subProjectVector_;
      IABTLocalID subProjectId= null;

      System.out.println("\n" + subProjectVector.size()+ " subProjects");
      for (int i  = subProjectVector.size()-1; i >=0; i-- )
      {
         subProjectId  = (IABTLocalID)subProjectVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(subProjectId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_SUBPROJECTLINK);
         System.out.println("subProject " + ( subProjectVector.size() - i));
         printProperties(propset, arr);

      }



      Vector NoteVector = com.abtcorp.io.client.pmwfile.ABTIOPMWFileNote.noteVector_;
      IABTLocalID NoteId= null;

      System.out.println("\n" + NoteVector.size()+ " Notes");
      for (int i  = NoteVector.size()-1; i >=0; i-- )
      {
         NoteId  = (IABTLocalID)NoteVector.elementAt(i);
         arr     = (IABTArray)driver_.intermediateTableGet(NoteId);
         if (arr == null)
            throw new ABTException(" The element associated with the Key does not exist. ");
         propset = getProperties(OBJ_NOTE);
         System.out.println("\n Note " + ( NoteVector.size() - i));
         printProperties(propset, arr);

      }
      */
        //populateObjectSpaceFromHashTable();
   }


/**
 * printProperties -Utility to print the properties type and name from a propertySet
 * @param ABtpropertySet
 * @return void
 */
protected void printProperties(IABTPropertySet propset, IABTArray arr)
{
try{
   if ( (arr == null) ||(propset == null) )
      throw new Exception("printProperties()  arr is null");
   Enumeration    itp_  = propset.getElements();
   IABTEnumerator ita_  = arr.getElements();

   while(itp_.hasMoreElements())
   {
      IABTProperty prop = ((IABTProperty)(itp_.nextElement()));
      System.out.print(" " + prop.getName() );
      if (prop.isVirtual())
         System.out.print(" is Virtual!");
      else if (prop.isTransient())
         System.out.print(" is Transient!");
      else if (ita_.hasMoreElements())
      {
        ABTValue val = null;
        Object valObj = ita_.nextElement();
        if (valObj == null)
            System.out.print(" = THE VALUE IS null ");
        else
        {
            if (valObj instanceof ABTValue)
                val = (ABTValue)(valObj);
            else
                throw new ABTException(" Wrong casting ");

            switch(prop.getType())
            {
                case PROP_INT:
                       System.out.print(" Integer ");
                       System.out.print( " " + val.intValue() );
                       break;
                    case PROP_STRING:
                       System.out.print(" String");
                       System.out.print( " = " + val.stringValue() );
                       break;
                    case PROP_OBJECT:
                        System.out.print(" Object ");
                        if ( val instanceof IABTLocalID)
                        {
                           IABTLocalID id = (IABTLocalID) val;
                           ABTInteger abti= null;
                           abti = new ABTInteger(id.getLocal()) ;
                           System.out.print( " OBJECT " + " ID = " + abti.intValue() + " " );
                        }
                       else
                           System.out.print( " = OBJECT not instance of ID ");
                       break;
                    case PROP_OBJECTSET:
                       System.out.print( " =  OBJECTSET ");
                       if (val instanceof ABTObjectSetIDList)
                       {
                            ABTObjectSetIDList valid = (ABTObjectSetIDList)val;
                            Enumeration iti_ = valid.getActiveIDs();
                             int counter =0;
                            while(iti_.hasMoreElements())
                            {
                                counter++;
                                ABTValue value = (ABTValue) (iti_.nextElement());
                                if ( value instanceof IABTLocalID)
                                {
                                    IABTLocalID ids = (IABTLocalID) value;
                                    ABTInteger abtsi= null;
                                    abtsi = new ABTInteger(ids.getLocal()) ;
                                    System.out.print( " OBJECT " + " ID = " + abtsi.intValue() + " " );

                                }
                                else
                                    System.out.print( " = OBJECT not instance of ID in OBJECTSET ");

                            }

                            //System.out.print("THE COUNTER IS :" + counter);
                       }
                       break;
                    case PROP_LONG:
                       System.out.print(" Long ");
                       break;
                    case PROP_BOOLEAN:
                       System.out.print(" Boolean ");
                       System.out.print( " = " + val.booleanValue() );
                       break;
                    case PROP_DOUBLE:
                       System.out.print(" Double ");
                       System.out.print( " = " + val.doubleValue() );
                       break;
                    case PROP_DATE:
                       System.out.print(" Date ");
                       break;
                    case PROP_TIME:
                       System.out.print(" Time ");
                       System.out.print( " = " + val.timeValue() );
                       break;
                    case PROP_TIMESTAMP:
                       System.out.print(" TimeStamp ");
                       break;
                    case PROP_BLOB:
                       System.out.print(" Blob ");
                       break;
                    case PROP_SHORT:
                       System.out.print(" Short ");
                       System.out.print( " =  " + val.shortValue() );
                       break;
                    case PROP_ID:
                        System.out.print(" Remote ID ");
                        break;
                    case PROP_UNKNOWN:
                    default:
                       System.out.print(" Unknown ");
                       break;
               }
         }
      }


   }
} catch (Exception e)
{
  e.printStackTrace();
}
}




   public ABTValue populate(ABTArray parms) throws ABTException {
      return null;
   }

/**
 *    Populate an object space with an object (or objects) as appropriate to the
 *    particular helper
 *	   @param None.
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue populate() throws ABTException {
      return null;
   }

/**
 *    Save an object (or objects) from the object space as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return void
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public void save(ABTArray parms) throws ABTException {
   }


/**
 * Create a new object in the object space and initialize it with values appropriate to the
 * driver being used.
 *	@param ABTArray parms, the elements of which are meaningful as parameters to the particular
 * helper
 *	@return an ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue create(ABTArray parms) throws ABTException {
      return null;
   }

/**
 *    Update an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param ABTArray parms, the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object updated in the
 *    object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue update(ABTArray parms) throws ABTException
   {
      return null;
   }





 }