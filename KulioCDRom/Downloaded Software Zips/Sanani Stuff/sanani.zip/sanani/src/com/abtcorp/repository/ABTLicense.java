package com.abtcorp.repository;

public class ABTLicense extends ABTNative
{
   ABTSession session_;

   ABTLicense(int handle, ABTSession session) {super(handle); session_ = session; session_.addref();}

   public void addref()                  {super.addref(); session_.addref();}
   public void release(boolean finalize) {super.release(finalize); session_.release(false);}
   
   public ABTSession getSession() {return session_;}
}