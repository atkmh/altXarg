package com.abtcorp.io;

import com.abtcorp.core.ABTException;

public class ABTNotImplementedException extends ABTException
{
   public ABTNotImplementedException(String s) {super(s);}
   public ABTNotImplementedException() {super("");}
}