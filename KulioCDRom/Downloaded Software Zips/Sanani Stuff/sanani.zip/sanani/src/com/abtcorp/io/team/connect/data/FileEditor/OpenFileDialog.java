package com.abtcorp.io.team.connect.data.FileEditor;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class OpenFileDialog extends JDialog implements ItemListener{

    private GridBagLayout gridbag_;
    private JTextField dirField_;
    private JComboBox fileBox_;
    private String directory_;
    private String file_;

    OpenFileDialog(Frame theClass, String title, Object listener, String initialDir)
    {
        super(theClass, title);

        directory_ = initialDir;
  
        gridbag_ = new GridBagLayout();
        this.getContentPane().setLayout(gridbag_);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5,5,5,5);
      
        constraints.gridwidth = GridBagConstraints.RELATIVE;      
        JLabel dirLabel = new JLabel("Location: ");
        gridbag_.setConstraints(dirLabel, constraints);
        this.getContentPane().add(dirLabel);
      
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        dirField_ = new JTextField(directory_, 15);
        gridbag_.setConstraints(dirField_, constraints);
        this.getContentPane().add(dirField_);
      
        constraints.gridwidth = GridBagConstraints.RELATIVE;      
        JLabel fileLabel = new JLabel("Table: ");
        gridbag_.setConstraints(fileLabel, constraints);
        this.getContentPane().add(fileLabel);
      
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        fileBox_ = new JComboBox();
        file_ = "team.User";
        fileBox_.addItem("User");
        fileBox_.addItem("Unplanned");
        fileBox_.addItem("TypeCode"); 
        fileBox_.addItem("TimeSheet");
        fileBox_.addItem("TimePeriod");
        fileBox_.addItem("Task");
        fileBox_.addItem("Resource");        
        fileBox_.addItem("Project");
        fileBox_.addItem("Outgoing");
        fileBox_.addItem("ChargeCode");
        fileBox_.addItem("CategoryString");
        fileBox_.setMaximumRowCount(4);
      
        gridbag_.setConstraints(fileBox_, constraints);
        this.getContentPane().add(fileBox_);
        fileBox_.addItemListener(this);

        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.EAST;
        constraints.gridwidth = GridBagConstraints.RELATIVE;
        JButton okButton = new JButton("OK");
        gridbag_.setConstraints(okButton, constraints);
        this.getContentPane().add(okButton);
        okButton.setActionCommand("Open_Table_Now");
        okButton.addActionListener((ActionListener)listener);
      
        JButton closeButton = new JButton("Close");
        gridbag_.setConstraints(closeButton, constraints);
        this.getContentPane().add(closeButton);
        closeButton.setActionCommand("Hide_Open_Dialog");
        closeButton.addActionListener((ActionListener)listener);
    }
    
    public String updateDir()        { directory_ = dirField_.getText(); return directory_; }
    public void   setDir(String dir) { dirField_.setText(dir);                              }
    public String getDir()           { return directory_;                                   }
    public String getFile()          { return file_;                                        }
    public void   hideFileList()     { fileBox_.hidePopup();                                }

    //****ItemSelected Listener**** 
    public void itemStateChanged(ItemEvent e)
    {
        if(e.getStateChange() == ItemEvent.SELECTED){
            file_ = "team." + (String)e.getItem();
            //System.out.println("Ready to open: " + file_);
        }
    }

}