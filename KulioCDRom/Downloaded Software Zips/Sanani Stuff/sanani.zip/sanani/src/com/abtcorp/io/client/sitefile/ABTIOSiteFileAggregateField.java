package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileAggregateField.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-1-98     MXA         Initial Implementation
 *
 */

/**
 *  ABTIOSiteFileAggregateField is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOSiteFileDriver.
 *
 *  <pre>
 *       ABTIOSiteFileAggregateField fr = new ABTIOSiteFileAggregateField(driver,parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOSiteFileDriver
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;

public class ABTIOSiteFileAggregateField extends ABTIOSiteFileHelper implements IABTRuleConstants
{
     private IABTObject custFieldObj_ = null;
     
//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOSiteFileAggregateField constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOSiteFileAggregateField(ABTIOSiteFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_AGGREGATEFIELD);
      site_ = parent;
   }


/**
 * Populate site's Adjacent Rule.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
 protected ABTValue populate(IABTLocalID custFieldId) throws ABTException
 {
        ABTValue     val       = null;
	    ABTValue     ret       = null;
        ABTRemoteID  remoteId  = null;
        IABTLocalID  id        = null;
        ABTObjectSetIDList aggragateFieldIds = null;        
        Object        obj      = null;
                   
        val = getIDs(custFieldId, OBJ_CUSTOMFIELD, OFD_AGGREGATEFIELDS);        
	                                 
        if (val instanceof ABTObjectSetIDList) 
            aggragateFieldIds  = (ABTObjectSetIDList)val;
        else 
            throw new ABTException("Wrong Cast");   
        Enumeration itID = aggragateFieldIds.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
            obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            id_ = (IABTLocalID)obj;           
           else
            throw new ABTException("Wrong Cast");
            ret = super.populate();              
           
        }
        return ret; 
  }

/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {             
      IABTObject sourceObj = null;
      IABTObject targetObj = null;    
      
      
      //Get aggragate's source field ID
      ABTValue  val = null;
      IABTLocalID sourceID = null;
      
      val = getHashValue(objArr_, propSet_, OFD_SOURCEFIELD);
      if (val instanceof IABTLocalID)
        sourceID = (IABTLocalID)val;      
      else 
        throw new ABTException("Wrong Cast");
        
     //Get aggragate's target field ID
      val = null;
      IABTLocalID targetID = null;
    
      val = getHashValue(objArr_, propSet_, OFD_TARGETFIELD);
      if (val instanceof IABTLocalID)
        targetID = (IABTLocalID)val;    
       else 
        throw new ABTException("Wrong Cast");
       //Get aggragate's source field object
      Object obj = null;
      obj = driver_.lookupTableGet(sourceID);         
      if ( obj != null && obj instanceof IABTObject)
        sourceObj =  (IABTObject)obj;
      else
        throw new ABTException("The Aggregate source object is not valid");
        
      //Get aggragate's target field object
      obj = null;
      obj = driver_.lookupTableGet(targetID);         
      if ( (obj != null) && (obj instanceof IABTObject))
        targetObj =  (IABTObject)obj;
      else
        throw new ABTException("The Aggregate target object is not valid");
      
      
      reqParams_.putItemByString(OFD_SOURCEFIELD, (ABTValue)sourceObj);
      reqParams_.putItemByString(OFD_TARGETFIELD, (ABTValue)targetObj);
      reqParams_.putItemByString(OFD_SITE, (ABTValue)site_);
      
      return (super.create(type, id, reqParams_));
   }


}
