/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class ABTExceptionListCOM implements IABTExceptionListCOM
   {
   // Default constructor creates a new ABTExceptionList from scratch
   public ABTExceptionListCOM() { this(new ABTExceptionList()); }

   public ABTExceptionListCOM(ABTExceptionList list)
      {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base   = new ABTBaseJavaCOM(list);
      /**/
      }

   //aggregated ABTSortedArrayCOM access wrapper
   /**/
   protected ABTBaseJavaCOM _base;      // aggregated base array object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private ABTExceptionList _el;
   private ABTExceptionList el() {
      if (_el == null) _el = (ABTExceptionList)getObject(); 
      return _el;
      }


   public class ArrayEnumerator implements IEnumVariant,IABTEnumeratorCOM
     {
      protected java.util.Enumeration _en;
      public ArrayEnumerator() { _en = el().elements(); }
      public void Reset() { _en = el().elements(); }
      public IEnumVariant Clone(){ return new ArrayEnumerator();  }
      public void Skip(int n) {
         while (n-- > 0 && _en.hasMoreElements()) {  _en.nextElement();  }
         }
      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }

      public Variant nextElement() {
         com.abtcorp.blob.ABTException nextObj = (com.abtcorp.blob.ABTException)_en.nextElement();
         if (nextObj == null) return null;
         return new Variant(Variant.VariantDispatch,new ABTExceptionCOM(nextObj));
         }

      public void Next(int n, Variant[]v, int[]pfetched) {
         pfetched[0] = 0;
         while (n-- > 0 && _en.hasMoreElements())
            { v[(pfetched[0])++] = (Variant)nextElement().clone(); }
         }
     }

   public IUnknown get_NewEnum() { return new ArrayEnumerator(); }

   public IABTEnumeratorCOM getElements()
      { return new ArrayEnumerator(); }

   public int getCount()   { return size(); }
   public int size()   { return el().size(); }


   public IABTExceptionCOM getException(int n){
      return (IABTExceptionCOM)at(n).getObject();
      }

   public Variant getItem(int n){ return at(n); }
   public Variant at(int Index)  {
         return new Variant(Variant.VariantDispatch,new ABTExceptionCOM((com.abtcorp.blob.ABTException)el().at(Index)));
      }

   // Note: this is the method a COM client would use to add to the array
   // Java clients should add to the contained ABTArray
   public Variant add( Variant newObj )  {
      Object inner = ((IBaseJava)newObj.getObject()).getObject();
      el().add((ABTValue)inner);
      Variant retVal;
      retVal = (Variant)newObj.clone();
      return retVal;
      }


   }
