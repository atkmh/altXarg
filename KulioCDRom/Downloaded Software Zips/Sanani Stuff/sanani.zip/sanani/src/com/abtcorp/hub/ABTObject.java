
package com.abtcorp.hub;

//package com.abtcorp.abtooapi;
/*
 * ABTObject.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 04-09-98	HJB		getInstanceCount, getObjectType, addListener
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;
import java.util.Enumeration;
/**
 *  ABTObject is the base class allowing common handling of all business objects
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.core.ABTValue
 */

public class ABTObject  extends ABTValue implements IABTReferenceListener,IABTReferenceSource
{
    
	/**
	 * my_row - reference to element in ABTRowSet
	 */
	 private ABTRow my_row;

    /**
    * referenceAdapter
    */
    protected ABTReferenceAdapter refAdapter;

    
    private boolean deleted = false;
//==========================================================================================
  /**
   * Default constructor
   */
   protected ABTObject()
   {
	   my_row = null;
   }

   protected ABTUserSession getLockHolder()
   {
        return my_row.getLockHolder();
   }
  /**
   * Default constructor for sorting
   */
   protected ABTObject(ABTRule rule_)
   {
	   my_row = null;
   }

   /**
   * return the name of the rule (i.e. the type) of this object
   */
   public String getObjectType()
   {
      if (deleted) return new String("UNKNOWN");  
      return getRule().getName();
   }
   /**
   * return the storable portion of the ABTObject
   */

   public ABTValue eval()
   {
      if (deleted) return null;
    return this;
   }




   /**
   * instantiate the content with the correct rule, id and row references
   * @param rule_ new parent rule
   * @param id_ new abtid
   * @param row_ new row
   */
	protected final void instantiate(ABTRule rule_,ABTID id_, ABTRow row_)
	{
	   my_row = row_;
	   my_row.setObject(this);
	}


   /**
   * remove all pending references
   */
	protected synchronized final void destroy()
	{
      if (my_row != null)
      {
  	      my_row.setObject(null);
	      my_row = null;
      }
      if( refAdapter != null )
      {         
        refAdapter.destroy();
        refAdapter = null;
      }              
      deleted = true;

	}

   /**
   * remove all pending references
   */
   public void finalize()
   {
      destroy();
   }

/*   protected void setRemoteID(ABTRemoteID remoteID_)
   {
       remoteID = remoteID_;
   } 
*/   
   public ABTRemoteID getRemoteID (ABTUserSession session)
   {
      if  (my_row == null) return null;
      try
      {
        return (ABTRemoteID)(getRow().at(session,1));
      }
      catch (Exception e)
      {
        // most likely just null or ABTEmpty
        return null;
      }
   }

/**
   * get my row
   */
   protected final ABTRow getRow()
   {
      return my_row;
   }

   protected synchronized ABTUserSession getLock()
   {
    return my_row.getLockHolder();
   }

   /**
   * get my objectSpace
   */
   protected final ABTObjectSpace getObjectSpace()
   {
      return getRule().getObjectSpace();
   }


  /**
   * Set the parameter with a given index to the provided value
   * note that virtual fields will only call the notification and return the proposed new value (if notification succeeds) 
   * @param parameterIndex index of parameter to be set in parameter list
   * @param value new object value
   * @return ABTValue the value finally assign (check for ABTError)
   */
	protected final ABTValue setRowValue
	                        (   ABTUserSession session, 
	                            ABTProperty property, 
	                            ABTValue oldValue,
	                            ABTValue value_)
    {
        return setRowValue(session,property,oldValue,value_,false);
    }

  /**
   * Set the parameter with a given index to the provided value
   * note that virtual fields will only call the notification and return the proposed new value (if notification succeeds)
   * @param parameterIndex index of parameter to be set in parameter list
   * @param value new object value
   * @return ABTValue the value finally assign (check for ABTError)
   */
	protected final ABTValue setRowValue
	                        (   ABTUserSession session,
	                            ABTProperty property,
	                            ABTValue oldValue,
	                            ABTValue value_,
	                            boolean dirty_)
	{
      if (isDeleted(session)) return
            new ABTErrorHub("ABTObject->getRowValue",errorMessages.ERR_5,"Object already deleted");
      if (!(ABTValue.isEmpty(oldValue)))
      {
          if ((value_ == null) && (oldValue == null))
            return null; // don't bother
          if (value_ != null)
          {
            if ((value_ instanceof ABTString) && (!(ABTValue.isNull(oldValue))) &&  (oldValue instanceof ABTString))
            {
              if (((ABTString)value_).compareToReal(oldValue) == 0) return value_;
            }
            else
            {
              if (value_.equals(oldValue)) return value_;
            }
          }
      }
      if ((property.isVirtual()) || (property.getRowIndex() < 0))
         return value_;//new ABTErrorHub("ABTRule->dirtyWrite",
                    //                "Property is virtual",
                    //                 prop);

      //notify
      if (this.refAdapter != null)
      {
         ABTError er = this.refAdapter.notifyReferenceSet(session, property,oldValue,value_,dirty_);
         if (er != null)
            return er;
      }
      
      // remove existing notification
       //notify
      if ((oldValue != null) && ((oldValue instanceof ABTObject) || (oldValue instanceof ABTObjectSet)))
      {
         IABTReferenceSource source = (IABTReferenceSource)oldValue;
         source.removeReference( session, this );
      }


	    return this.getRow().setValue(session, property.getRowIndex(),property.getLookupIndex(),property,value_);
	}


   /**
   * Get the value for a the parameter with a given index
   * @param parameterIndex index of parameter to be accessed in parameter list
   * @return ABTValue
   */
   protected final ABTValue getRowValue (ABTUserSession session, ABTProperty property )
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getRowValue",errorMessages.ERR_5,"Object already deleted");
      ABTValue ar = my_row.getValue(session,property.getRowIndex());
      return ar;
   }

//================================================================================
//public access to ABTObjects
//================================================================================


    /**
   * return the Property object for the named property
   * @param property - name of property
   * @return ABTProperty - property object associated with key or null if error
   */
   public ABTProperty getProperty(ABTUserSession session, String property)
   {
      if (isDeleted(session)) return null;
	    return getRule().getProperty(session,property);
   }
    /**
   * return the Property object for the indexed property
   * @param property - index of property
   * @return ABTProperty - property object associated with key or null if error
   */
   public ABTProperty getProperty(ABTUserSession session,int property)
   {
      if (isDeleted(session)) return null;
	    return getRule().getProperty(session,property);
   }
   
    
    /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param property - name of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,String property, ABTValue key)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getPropertyKey(session,this,getRule().indexForName(property),key);
   }
    /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param property - index of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,int property, ABTValue key)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getPropertyKey(session,this,property,key);
   }

    /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param property - name of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,String property, String key)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getPropertyKey(session,this,getRule().indexForName(property),key);
   }
    /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param property - index of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,int property, String key)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getPropertyKey(session,this,property,key);
   }

    /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param property - name of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,String property, int key)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getPropertyKey(session,this,getRule().indexForName(property),key);
   }
    /**
   * return the objected dependant value for property-field by key
   * e.g. updatable - dependant on some other values...
   * @param property - index of property
   * @param key - key in property description
   * @return ABTValue - value associated with key or ABTError
   */
   public ABTValue getPropertyKey(ABTUserSession session,int property, int key)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
      return getRule().getPropertyKey(session,this,property,key);
   }



     /**
   * return whether the current value physically stored in the 
   * property is empty (i.e. has never been set
   * @param property - index of property
   * @return ABTValue - ABTBoolean true (if empty) or false
   */
   public ABTValue isEmpty(ABTUserSession session,ABTProperty property)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
      if (property == null)
        return new ABTErrorHub("ABTObject->isEmpty",errorMessages.ERR_7,new ABTInteger(property));
      ABTValue ar = my_row.getValue(session,property.getRowIndex());
      if (ABTError.isError(ar))
        return ar;
      if (ABTValue.isEmpty(ar))
        return ABTBoolean.True();
      else          
        return ABTBoolean.False();
        
   }

     /**
   * return whether the current value physically stored in the 
   * property is empty (i.e. has never been set
   * @param property - index of property
   * @return ABTValue - ABTBoolean true (if empty) or false
   */
   public ABTValue isEmpty(ABTUserSession session,String property)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
      ABTProperty prop = getRule().getProperty(session,property);
      if (prop == null)
        return new ABTErrorHub("ABTObject->isEmpty",errorMessages.ERR_7,new ABTString(property));
      ABTValue ar = my_row.getValue(session,prop.getRowIndex());
      if (ABTError.isError(ar))
        return ar;
      if (ABTValue.isEmpty(ar))
        return ABTBoolean.True();
      else          
        return ABTBoolean.False();
        
   }


     /**
   * return whether the current value physically stored in the 
   * property is empty (i.e. has never been set
   * @param property - index of property
   * @return ABTValue - ABTBoolean true (if empty) or false
   */
   public ABTValue isEmpty(ABTUserSession session,int property)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getPropertyKey",errorMessages.ERR_5,"Object already deleted");
      if (property < 0)
        return new ABTErrorHub("ABTObject->isEmpty",errorMessages.ERR_7,new ABTInteger(property));
      ABTValue ar = my_row.getValue(session,property);
      if (ABTError.isError(ar))
        return ar;
      if (ABTValue.isEmpty(ar))
        return ABTBoolean.True();
      else          
        return ABTBoolean.False();
        
   }

 
 
 /**
   * Return the deleted flag for the object at index
   * @return boolean true if deleted or element doesn't exist
   */
   public synchronized boolean isDeleted(ABTUserSession session )
   {
      return (( deleted) || (my_row.isDeleted(session)));
   }


  /**
   * Get all the properties in the given list 
   * if successfull the hashtable will contain the corresponding values
   * @param propertyValuePairs pairs of properties and values in hashtable
   * @return ABTError - error in one of them or null if successfull
   */
	public ABTValue getValues(ABTUserSession session,ABTArray properties)
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getValues",errorMessages.ERR_5,"Object already deleted");

	    ABTArray values     = new ABTArray();
        Enumeration e = properties.elements();
        while (e.hasMoreElements())
        {
            int p_index = -1;
            Object o = e.nextElement();
            if (o instanceof ABTString)
                p_index = getRule().indexForName(((ABTString)o).stringValue());
            else
                if (o instanceof String)
                    p_index = getRule().indexForName(((String)o));
                else
                    if (o instanceof ABTProperty)
                        p_index = ((ABTProperty)o).getIndex();
                    else
                        p_index = -1;
            if (p_index != -1)
            {
                try
                {
                    values.add(getValue(session,p_index,null));
                }
                catch (Exception e1)
                {
                    values.add(new ABTErrorHub("ABTObject->getValues",errorMessages.ERR_6,e1));
                }                
            }
            else
            {
                ABTError er2 = new ABTErrorHub("ABTObject->setValues",errorMessages.ERR_7,o);
                values.add(er2);
            }
        }
        return values;
            
    }

  /**
   * Get the value for a the parameter with a given index
   * @param parameterIndex index of parameter to be accessed in parameter list
   * @param paramters list of parameters for rule processing
   * @return ABTValue - Check for ABTError on return
   */
  public ABTValue getValue (ABTUserSession session,int parameterIndex_ , ABTHashtable parameters)
  {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getValue",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getValue(session,this,parameterIndex_,false, parameters);
  }
  /**
   * Get the value for a the parameter with a given name
   * @param parameterName name of parameter to be accessed in parameter list
   * @param paramters list of parameters for rule processing
   * @return ABTValue - Check for ABTError on return
   */
	public ABTValue getValue(ABTUserSession session,String parameterName_, ABTHashtable parameters)
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getValue",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getValue(session,this,getRule().indexForName(parameterName_),false,parameters);
   }



  /**
   * Get the value for a the parameter with a given index
   * @param parameterIndex index of parameter to be accessed in parameter list
   * @return ABTValue - Check for ABTError on return
   */
  public ABTValue getValue (ABTUserSession session,int parameterIndex_ )
  {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getValue",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getValue(session,this,parameterIndex_,false,null);
  }
  /**
   * Get the value for a the parameter with a given name
   * @param parameterName name of parameter to be accessed in parameter list
   * @return ABTValue - Check for ABTError on return
   */
	public ABTValue getValue(ABTUserSession session,String parameterName_)
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->getValue",errorMessages.ERR_5,"Object already deleted");
	    return getRule().getValue(session,this,getRule().indexForName(parameterName_),false,null);
   }


  /**
   * Remove this object from ALL lists and mark it as deleted
   * @return null if successfull or ABTError....
   */
	public ABTValue delete(ABTUserSession session)
	{
	    return getRule().delete(session,this);
	}



  /**
   * Set all the properties in the given list to their corresponding values
   * if successfull the passed in hashtable will reflect the set values....
   * @param propertyValuePairs pairs of properties and values in hashtable
   * @return ABTError - error in one of them or null if successfull
   */
	public ABTValue setValues(ABTUserSession session,ABTHashtable propertyValuePairs)
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->setValues",errorMessages.ERR_5,"Object already deleted");
	    int numberOfProperties = propertyValuePairs.size();
	    int[] properties = new int[numberOfProperties];

	    ABTArray values     = new ABTArray();
        
	    int i = 0;
	    int p_index = -1;
	    
        Enumeration e = propertyValuePairs.keys();
        while (e.hasMoreElements())
        {
            ABTValue o = (ABTValue)e.nextElement();
            if (o instanceof ABTString)
                p_index = getRule().indexForName(((ABTString)o).stringValue());
            else
                if (o instanceof ABTProperty)
                    p_index = ((ABTProperty)o).getIndex();
                else
                    p_index = -1;
            if (p_index != -1)
            {
                // try to get the value associated with this property
                try
                {
                    ABTValue value = (ABTValue)propertyValuePairs.get(o);
                    values.add(value);
                }
                catch (Exception e1)
                {
                    ABTError er1 = new ABTErrorHub("ABTObject->setValues",errorMessages.ERR_8,o);
                    values.add(er1);
                    p_index = -1;
                }
            }
            else
            {
                ABTError er2 = new ABTErrorHub("ABTObjectSet->setValues",errorMessages.ERR_7,o);
                values.add(er2);
            }
            properties[i] = p_index;
            i++;
        }

        // walk through items
        ABTArray result = new ABTArray();
        session.startTransaction();
        boolean ok = true;
        for (int index = 0; index < numberOfProperties;index++)
        {
            if (properties[index] != -1)
            {
                ABTValue val = (ABTValue)values.at(index);
                if (ABTValue.isEmpty(val))
                    val = null;
                ABTValue v1 = setValue(session,properties[index],val);
                if (ABTError.isError(v1))
                {
                    ABTArray tmp = new ABTArray();
                    tmp.add(v1);
                    tmp.add(new ABTInteger(index));
                    result.add(new ABTErrorHub("ABTObject->setValues",errorMessages.ERR_9,tmp));
                    ok = false;
                    index = 99999;
                }
            }                
        }
        if (ok)
        {
            result.add(this);
            session.commitTransaction();
        }
        else
            session.rollbackTransaction();

        return result;
            
    }
  /**
   * Set the parameter with a given index to the provided value
   * @param parameterIndex index of parameter to be set in parameter list
   * @param value new object value
   * @param paramters list of parameters for rule processing
   * @return ABTValue - value assigned to field (check for ABTError)
   */
	public ABTValue setValue(ABTUserSession session,int parameterIndex_, ABTValue value_ , ABTHashtable parameters	)
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->setValue",errorMessages.ERR_5,"Object already deleted");
        if (! my_row.lock(session))
            return new ABTErrorHub("ABTObject->setValue",errorMessages.ERR_10,this);
	    ABTValue result =  getRule().setValue( 
	                              session,
	                              this,
	                              parameterIndex_,
	                              value_, // new Value
	                              getRule().getValue(
	                                        session,
	                                        this,
	                                        parameterIndex_,
	                                        false,
	                                        parameters),
                                  parameters	                                        
	                              );
        if (ABTError.isError(result))
            my_row.removeOnelock(session);
        return result;            
	}
  /**
   * Set the parameter with a given name to the provided value
   * @param parameterName name of parameter to be set in parameter list
   * @param value new object value
   * @param paramters list of parameters for rule processing
   * @return ABTValue - newly assigned value or ABTError
   */
	public ABTValue setValue(ABTUserSession session,String parameterName_, ABTValue value_ ,ABTHashtable parameters	)
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->setvalue",errorMessages.ERR_5,"Object already deleted");
        if (! my_row.lock(session))
            return new ABTErrorHub("ABTObject->setValue",errorMessages.ERR_10,this);
	    int index = getRule().indexForName(parameterName_);
	    ABTValue result =  getRule().setValue( session,
	                                this,
	                                index,
	                                value_,
	                                getRule().getValue(session,this,index,false,parameters),
	                                parameters);
        if (ABTError.isError(result))
            my_row.removeOnelock(session);
        return result;            
	}


  /**
   * Set the parameter with a given index to the provided value
   * @param parameterIndex index of parameter to be set in parameter list
   * @param value new object value
   * @param paramters list of parameters for rule processing
   * @return ABTValue - value assigned to field (check for ABTError)
   */
	public ABTValue setValue(ABTUserSession session,int parameterIndex_, ABTValue value_ )
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->setValue",errorMessages.ERR_5,"Object already deleted");
        return setValue(session,parameterIndex_, value_ ,null);
	}
  /**
   * Set the parameter with a given name to the provided value
   * @param parameterName name of parameter to be set in parameter list
   * @param value new object value
   * @return ABTValue - newly assigned value or ABTError
   */
	public ABTValue setValue(ABTUserSession session,String parameterName_, ABTValue value_ )
	{
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->setValue",errorMessages.ERR_5,"Object already deleted");
        return setValue(session,parameterName_, value_ ,null);
	}


  /**
   * Add a specific listener to the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param propertyIndex index of property of -1 for all
   */
   public void addListener(ABTUserSession session, int action, IABTListener listener,int propertyIndex)
   {
     if (deleted) return;
       getRule().getObjectSpace().addListener(session,action, listener,this,propertyIndex);
   }

  /**
   * Add a specific listener to the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param property name of property or null all
   */
   public void addListener(ABTUserSession session, int action, IABTListener listener,String property)
   {
      if (deleted) return ;

        int index = -1;
        if (property != null)
            index = getRule().indexForName(property);
        addListener(session,action,listener,index);
   }

  /**
   * Remove a specific listener from the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param propertyIndex index of property of -1 for all
   */
   public void removeListener(ABTUserSession session,  IABTListener listener,int propertyIndex)
   {
      if (deleted)return ;
       getRule().getObjectSpace().removeListener(session,listener,this,propertyIndex);
   }


  /**
   * Remove a all listenedTo for the caller
   * @param listener caller who wants to be removed from the the listenerlist
   */
   public void removeListeners(ABTUserSession session, IABTListener listener)
   {
      if (deleted) return ;
       getRule().getObjectSpace().removeListener(session,listener,this,-1);
   }

   /**
   *  return the associated rule
   *  @return ABTRule
   */
   public ABTRule getRule()
   {
      if (deleted) return null;
      return my_row.getRule();
   }



   public boolean booleanValue()          {return my_row != null;}



   /**
   *  compare myself to another ABTObject or ABTID or returns 0 if object is not
   *  of one of those two types
   *  @param object - ABTObject or ABTID
   *  @return int 0 == equals, -1 smaller, 1 greater
   */
   public int compareTo(Object object)
   {
      if (object == null) return 1;     
      if (deleted) return -1;
      if (object instanceof ABTObject)
      {
         return getID().compareTo(((ABTObject)object).getID());
      }
      if (object instanceof ABTID)
      {
         return getID().compareTo((ABTID)object);
      }
      return super.compareTo(object);
   }


   /**
   *  return the hashcode - returns actually the hashcode of the associated ABTID
   *  of one of those two types
   *  @return int - hashCode for this object
   */
   public int hashCode()
   {
      if (deleted) return 0;
        return getID().hashCode();
   }
   public ABTID getID()
   {
      if (deleted) return null;
        return my_row.getID();
   }

   /**
   *  return the set of properties for this class
   *  @return ABTPropertySet
   */
   public ABTPropertySet getProperties()
   {
      if (deleted) return null;
       return getRule().getProperties();
   }

   /**
   * dumping
	* level 0 : just my_row;
	* level 1 : my class & my_row;
	* level 2 : level 1 + references
	* level 3 : level 2 + properties
	* level 4 : level 3 + rules

   */

   public String dump(int indent,int level)
   {
     if (deleted) return "DELETED";

      switch (level)
      {
         case 0:
            return my_row.dump(indent,level);
         case 1:
            return com.abtcorp.core.ABTUtil.newLine(indent) + 
                   this.getClass() + " : " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   my_row.dump(indent + 1,level);
         case 2:
            return com.abtcorp.core.ABTUtil.newLine(indent) + 
                   this.getClass() + " : " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   my_row.dump(indent+1,level) + " - " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   dumpAdapter(indent+1,level);
         case 3:
            return com.abtcorp.core.ABTUtil.newLine(indent) + 
                   this.getClass() + " : " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                     getProperties().dump(indent+1,level) +
                     com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   my_row.dump(indent+1,level) + " - " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   dumpAdapter(indent+1,level);
         default:
            return com.abtcorp.core.ABTUtil.newLine(indent) + 
                   this.getClass() + " : " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                     getRule().dump(indent+1,level) +
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                     getProperties().dump(indent+1,level) +
                     com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   my_row.dump(indent+1,level) + " - " + 
                   com.abtcorp.core.ABTUtil.newLine(indent) +                    
                   dumpAdapter(indent+1,level);

      }

   }


   private String dumpAdapter(int indent, int level)
   {
      if (refAdapter == null)
         return "no references";
      return refAdapter.dump(indent,level)         ;
   }
//================================================================================
//private/protected access to ABTObjects
//================================================================================
   /**
   *  set the row this object is pointing to....
   * @param row - ABTRow  from Rowset
   */
   protected final void setRow(ABTRow row)
   {
      my_row = row;
   }
   /**
   *
   */
   protected void undelete(ABTUserSession session)
   {
      if (isDeleted(session))
      {
         my_row.unDelete(session);
         deleted = false;
      }         
   }


  /**
   * Notification of an add operation to an objectset stored in this property
   * if used set notifyAdd in rule constructor  to true
   * @param property - my property on which I am listening
   * @param child - the objectset currently referenced in this property
   * @param newValue - the new value added to this property
   * @param existing - true if the passed in new Value is an existing ABTObject
   *  , false if it was initialized to default values
   * @return null if allowed  or ABTError if rejected
   */
   public ABTError notifyReferenceAdd (ABTUserSession session,ABTProperty property, IABTReferenceSource child,  ABTValue newValue,boolean existing, boolean dirty)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->notifyReferenceAdd",errorMessages.ERR_5,"Object already deleted");
      return property.getFieldRule().notifyReferenceAdd
      (  session,
         this, //ABTObjectSet parent,
         property,
         (ABTObjectSet)child,
         newValue,
         existing,
         dirty);
   }


  /**
   * Notification of a remove operation in an objectset stored in this property
   * if used set notifyRemove in rule constructor to true
   * @param property - my property on which I am listening
   * @param child - the objectset currently referenced in this property
   * @param removedValue - the new value added to this property
   * @return null if allowed  or ABTError if rejected
   */
   public    ABTError notifyReferenceRemove (ABTUserSession session,ABTProperty property, IABTReferenceSource child,  ABTValue removedValue, boolean dirty)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->notifyReferenceRemove",errorMessages.ERR_5,"Object already deleted");
      return property.getFieldRule().notifyReferenceRemove
      (  session,
         this, //ABTObjectSet parent,
         property,
         (ABTObjectSet)child,
         removedValue,
         dirty);
   }


  /**
   * Notification of a delete operation on an object referenced in this property
   * @param property - my property on which I am listening
   * @param child - the object currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   public ABTError notifyReferenceDelete (ABTUserSession session,ABTProperty property, IABTReferenceSource child, boolean dirty)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->notifyReferenceDelete",errorMessages.ERR_5,"Object already deleted");
      return property.getFieldRule().notifyReferenceDelete
      (  session,
         this, //ABTObject parent,
         property,
         (ABTObject)child,
         dirty);
   }

  /**
   * Notification of a remove operation in an objectset stored in this property
   * if used set notifyClear in rule constructor to true
   * @param property - my property on which I am listening
   * @param child - the objectset currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   public    ABTError  notifyReferenceClear (ABTUserSession session,ABTProperty property, IABTReferenceSource child, boolean dirty)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->notifyReferenceClear",errorMessages.ERR_5,"Object already deleted");
      return property.getFieldRule().notifyReferenceClear
      (  
         session,
         this, //ABTObjectSet parent,
         property,
         (ABTObjectSet)child,
         dirty);
   }





  /**
   * Notification of a set operation in an element of the objectset stored in this property
   * if used set notifyChildSet in rule constructor to true
   * @param property - my property on which I am listening
   * @param childSet - the objectset currently referenced in this property
   * @param child - the object in the childset which was modified
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
   public    ABTError  notifyReferenceChildSet (ABTUserSession session,
                                                ABTProperty property,
                                                IABTReferenceSource childSet,
                                                ABTObject child,
                                                ABTProperty childProperty,
                                                ABTValue oldValue,
                                                ABTValue newValue,
                                                boolean dirty)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->notifyReferenceChildSet",errorMessages.ERR_5,"Object already deleted");
      return property.getFieldRule().notifyReferenceChildSet
      (  session,
         this, //ABTObjectSet parent,
         property,
         (ABTObjectSet)childSet,
         child,
         childProperty,
         oldValue,
         newValue,
         dirty);
   }


  /**
   * Notification of a set operation in an element of the objectset stored in this property
   * if used set  notifySet in rule constructor to true
   * @param child - the object currently referenced in this property
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
   public    ABTError  notifyReferenceSet (  ABTUserSession session,
                                             ABTProperty property,
                                             IABTReferenceSource child,
                                             ABTProperty childProperty,
                                             ABTValue oldValue, ABTValue newValue,
                                             boolean dirty)
   {
      if (isDeleted(session)) return 
            new ABTErrorHub("ABTObject->notifyReferenceSet",errorMessages.ERR_5,"Object already deleted");
      return property.getFieldRule().notifyReferenceSet
      (  session,
         this, //ABTObjectSet parent,
         property,
         (ABTObject)child,
         childProperty,
         oldValue,
         newValue,
         dirty);
   }


   public void addReference(ABTUserSession session, IABTReferenceListener listener,ABTProperty listenerProperty,ABTProperty myProperty)
   {
      if (deleted) return ;
      if (refAdapter == null)
         refAdapter = new ABTReferenceAdapter(this);
      refAdapter.addReference(session, listener, listenerProperty,myProperty);
   }

   public void removeReference(ABTUserSession session, IABTReferenceListener listener,ABTProperty myProperty)
   {
      if (deleted) return ;
      if (refAdapter == null) return;
      refAdapter.removeReference(session, listener,myProperty);
      if (refAdapter.countListeners() == 0)
      {         
         refAdapter.destroy();
         refAdapter = null;
      }              
   }
   public void removeReference(ABTUserSession session, IABTReferenceListener listener)
   {
      if (deleted) return ;
      // JSE 6-16-98
      if( refAdapter == null )
         return;
         
      refAdapter.removeReference( session, listener );
      
      if (refAdapter.countListeners() == 0)
      {         
         refAdapter.destroy();
         refAdapter = null;
      }              
   }




   }