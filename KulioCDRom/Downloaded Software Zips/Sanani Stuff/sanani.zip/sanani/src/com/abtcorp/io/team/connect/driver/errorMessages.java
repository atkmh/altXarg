package com.abtcorp.io.team.connect.driver;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.io.team.connect.driver".intern();
public static final ABTErrorCode ERR_0 = new ABTErrorCode(Package, "ERR_0", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_1 = new ABTErrorCode(Package, "ERR_1", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_2 = new ABTErrorCode(Package, "ERR_2", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_3 = new ABTErrorCode(Package, "ERR_3", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_4 = new ABTErrorCode(Package, "ERR_4", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_5 = new ABTErrorCode(Package, "ERR_5", UNRECOVERABLE_ERROR );

}