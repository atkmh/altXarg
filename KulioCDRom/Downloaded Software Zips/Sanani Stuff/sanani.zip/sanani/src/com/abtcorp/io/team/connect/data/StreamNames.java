package com.abtcorp.io.team.connect.data;

public interface StreamNames
{
   public static final String SKIP_RESOURCE_DETAIL = "SkipResourceDetail";
   public static final String SKIP_PROJECT_DETAIL  = "SkipProjectDetail";
   public static final String SKIP_TIMESHEET_DETAIL = "SkipTimeSheetDetail";
   public static final String INCLUDE_USER_RESOURCES = "IncludeUserResources";
   public static final String INCLUDE_RESOURCE_PROJECTS = "IncludeResourceProjects";
   public static final String INCLUDE_ASSIGNMENT_DETAILS = "IncludeAssignmentDetails";
   public static final String LINK_NOT_REQUIRED = "LinkNotRequired";
   public static final String MATCH_NOT_REQUIRED = "MatchNotRequired";
   public static final String SKIP_RESOURCE_TIMESHEET = "SkipResourceTimeSheet";
   public static final String MANAGER_KEY = "ManagerKey";
}