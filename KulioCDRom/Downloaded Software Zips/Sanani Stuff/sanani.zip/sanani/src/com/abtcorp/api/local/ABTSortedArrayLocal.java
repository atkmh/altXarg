/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSpace;

public class ABTSortedArrayLocal extends ABTSessionObject implements IABTSortedArray
{
   // Constructs a new sorted array given an object space
   protected ABTSortedArrayLocal(ABTSessionObject s) {
      this(s, new ABTSortedArray());
      }

   // Constructs a new sorted array given an object space
   protected ABTSortedArrayLocal(ABTSessionObject s, ABTComparator comp) {
      this(s, new ABTSortedArray(comp));
      }

   // Wrap an internal com.abtcorp.core.ABTArray for presentation to clients
   protected ABTSortedArrayLocal(ABTSessionObject s, com.abtcorp.core.ABTSortedArray array) {
      super(s,array);
      _ar = array;
      }


   private com.abtcorp.core.ABTSortedArray _ar;
   private com.abtcorp.core.ABTSortedArray ar() {
      return _ar;
      }

   public IABTObjectSpace getObjectSpace(){
      return new ABTObjectSpaceLocal(this); 
      }

   public IABTEnumerator getElements(){
      return new enumer(ar().elements());
      }

   public ABTValue get(int index){
      try {
         ABTValue V1 = (ABTValue)ar().at(index);
         return ValueMunger.MarshalOut(this,V1);
         }
      catch (Exception e){
         return new ABTError(getClass(), "get", errorMessages.ERR_EXCEPTION, e);
         }
      }

   public void clear(){
      ar().clear();
      }

   public ABTValue add(ABTValue value){
      try {
         if (!hasSession())  TrySessionValue(value);
         ABTValue _val = (ABTValue)ValueMunger.MarshalIn(this, value);
         ABTValue V1 = (ABTValue)ar().add(_val);
         return ValueMunger.MarshalOut(this,V1);
         }
      catch (Exception e){
         return new ABTError(getClass(), "add", errorMessages.ERR_EXCEPTION, e);
         }
      }

   public ABTValue removeAt( int index ){
      return ValueMunger.MarshalOut( this, ar().remove(index));
      }

   public int remove( ABTValue value ){
      ABTValue _val = (ABTValue)ValueMunger.MarshalIn(this, value);
      return ar().remove(_val);
      }

   public int size(){
      return ar().size();
      }

   public boolean isEmpty(){
      return ar().isEmpty();
      }

   public boolean contains( ABTValue value ){
      ABTValue _val = (ABTValue)ValueMunger.MarshalIn(this, value);
      return ar().contains(_val);
      }

   // This will try to 'steal' the session context from an ABTValue
   // It is useful when a client creates a new hashtable without a session,
   // and then adds a session-wrapped object to it.
   private boolean TrySessionValue(ABTValue val){
      if (val instanceof ABTSessionObject){
         ABTSessionObject Sval = (ABTSessionObject)val;
         setUserSession(Sval);
         return true;
         }
      return false;
      }

   private class enumer implements com.abtcorp.idl.IABTEnumerator
      {
      java.util.Enumeration _enumer;
      public enumer(java.util.Enumeration en) { _enumer = en; }
      public boolean hasMoreElements() { return _enumer.hasMoreElements(); }
      public ABTValue nextValue() {return (ABTValue)nextElement(); }
      public Object nextElement() {return _enumer.nextElement(); }
      }

}
