package com.abtcorp.io.client.methfile;

/*
 * ABTIOMethFileMethod.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-21-98    MXA         Initial Implementation
 *
 */

/**
 *  ABTIOMethFileMethod is a helper class for the ABT Methodology File driver .
 *  It is instantiated by the ABTIOMethFileDriver.
 *
 *  <pre>
 *       ABTIOMethFileMethod sr = new ABTIOMethFileMethod(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOMethFileDriver
 */

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTMMRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;


public class ABTIOMethFileMethod extends ABTIOMethFileHelper implements IABTRuleConstants, IABTMMRuleConstants
{

//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOMethFileMethod constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOMethFileMethod(ABTIOMethFileDriver driver)
   {
      super(driver, null, OBJ_MM_METHOD);
   }

/**
 *  Saves the site object back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving typecode and chargecode etc.)
 *	@param site   the object set to be saved back to the loal file
 *  @return       the object that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObject MethObj) throws ABTException
   {
    IABTObjectSet MethOs = null;
    try
    {
      MethOs = createObjectSet(OBJ_MM_METHOD);
      addListMember(MethOs, MethObj);

      IABTLocalID methId = MethObj.getID();
       if (methId == null)
            throw new ABTException("The ID is null.");

       if ( driver_.isIntermediateTableNull() )
        throw new ABTException("The intermediate Hash table is null");

       
       driver_.setMethodId(methId);


      super.save(MethOs);
    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
    }
    return (ABTValue)MethOs;

   }

/**
 * Populate the method object.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
        id_ = driver_.getMethodId();
	    return (super.populate());
	}



}
