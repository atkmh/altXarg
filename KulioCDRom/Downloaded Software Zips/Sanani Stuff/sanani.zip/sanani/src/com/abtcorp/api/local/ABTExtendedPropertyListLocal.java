/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTExtendedPropertyList;

class ABTExtendedPropertyListLocal extends ABTSessionObject implements IABTHashTable
{
   // private, internal enumerator class
   private class enumer implements com.abtcorp.idl.IABTEnumerator
      {
      java.util.Enumeration _enumer;
      public enumer(java.util.Enumeration en) { _enumer = en; }
      public boolean hasMoreElements() { return _enumer.hasMoreElements(); }
      public ABTValue nextValue() {return (ABTValue)nextElement(); }
      public Object nextElement() {return _enumer.nextElement(); }
      }

   protected ABTExtendedPropertyListLocal(ABTSessionObject s, ABTExtendedPropertyList epl) {
      super(s,epl);
      _epl = epl;
      }

   private ABTExtendedPropertyList _epl;
   private ABTExtendedPropertyList epl() {
      if (_epl == null) _epl = (ABTExtendedPropertyList)getObject(); 
      return _epl;
      }


   public IABTObjectSpace getObjectSpace(){
      return new ABTObjectSpaceLocal(this);
      }

   public boolean containsKey(ABTValue key)  {
      return epl().containsKey(key);
      }

   public boolean containsValue(ABTValue key)  {
      return epl().containsKey(key);
      }

   public boolean isEmpty() {
      return epl().isEmpty();
      }

   public int size() {
      return epl().size();
      }

   public IABTEnumerator getElements()  {
      return new enumer(epl().elements());
      }

   public IABTEnumerator getKeys() {
      return new enumer(epl().keys());
      }

   public ABTValue getItemByKey(ABTValue key)  {
      ABTValue V1 = (ABTValue)epl().get(key);
      return ValueMunger.MarshalOut(this,V1);
      }

   public ABTValue getItemByInt(int key)  {
      return ValueMunger.MarshalOut(this, (ABTValue)epl().get(key));
      }

   public ABTValue getItemByString(String key) {
     return ValueMunger.MarshalOut(this, (ABTValue)epl().get(key));
     }



//**********************************************
// The rest of the IABTHashTable methods are stubbed-out
// because ABTExtendedPropertyList is read-only
// from the client perspective
//**********************************************
   public void clear() { }

   public ABTValue remove(ABTValue obj) {
      return new ABTError(getClass(), "remove", errorMessages.ERR_READ_ONLY, null);
      }

   public ABTValue putItemByKey(ABTValue key, ABTValue value)  {
      return new ABTError(getClass(), "putItemByKey", errorMessages.ERR_READ_ONLY, null);
      }

   public ABTValue putItemByInt(int key, ABTValue value)  {
      return new ABTError(getClass(), "putItemByInt", errorMessages.ERR_READ_ONLY, null);
      }

   public ABTValue putItemByString(String key, ABTValue value) {
      return new ABTError(getClass(), "putItemByString", errorMessages.ERR_READ_ONLY, null);
     }
}