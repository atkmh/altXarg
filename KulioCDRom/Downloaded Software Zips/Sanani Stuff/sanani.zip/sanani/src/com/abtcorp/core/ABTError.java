/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTError.java, 31, 12/16/98 2:01:02 PM, Hans-Joachim Birthelmer$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;
/*
 * ABTError.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import java.util.Date;
import java.util.ResourceBundle;
import java.util.ListResourceBundle;
import java.util.MissingResourceException;
import java.util.Locale;
import java.util.Hashtable;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-05-98	   HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



/**
 * Basic ABTError class - provides basic functionality for Error Handling
 * prepared for localization
 * <p>
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */

public class ABTError extends ABTImmutableValue
{

   private static final long serialVersionUID = -8431382958272174725L;
   ABTErrorCode errCode;

   String component;
   String method;

   String message;
   Date date;
   Object info;

   public void fromByte(byte[] input){};
   public byte[] fromByte(){ return null;};
   
   protected static Hashtable bundles_ = new Hashtable(10,(float)1.0);

   /**
   *  constructor
   *  @param component_ creator class
   *  @param method_ name of routine creating it
   *  @param code_ ABTErrorCode (probably a constant) to specify the package and resource
   */
   public ABTError(
               Class component_,
               String method_,
               ABTErrorCode code_,
               Object info_)
   {
      date = new Date();
      component = component_.getName();
      method = method_;
      errCode = code_;
      info = info_;
      message = null;
   }

   /**
   *  constructor
   *  @param component_ creator class
   *  @param method_ name of routine creating it
   *  @param code_ ABTErrorCode (probably a constant) to specify the package and resource
   */
   public ABTError(
               String component_,
               String method_,
               ABTErrorCode code_,
               Object info_)
   {
      date = new Date();
      component = component_;
      method = method_;
      errCode = code_;
      info = info_;
      message = null;
   }


   /**
   *  lookup the errorcode for this message
   *  @param component_ name of creator
   *  @param count_ error code
   *  @param locale_ locale for message
   */
    String lookupMessage(Locale locale_) {
      Locale myLocale;
      try {
        if (locale_ != null && locale_ instanceof Locale)
            myLocale = locale_;
        else
            myLocale = Locale.US;
        String packagename = errCode.getPackage();
        ListResourceBundle messages = getBundle(packagename,myLocale);
        // if there isn't a resource bundle for that locale, get the US english one
        if (messages == null) { messages = getBundle(packagename, Locale.US); }
        // if there isn't a US english one, give up
        if (messages == null) return errCode.toString();
          
        String themessage = null;
        themessage = messages.getString(errCode.getCode());
        return themessage;
      }
      catch (Throwable e) {  return errCode.toString();}
   }

   /**
   *  return the errorcode
   *  @return ABTErrorCode - Errorcode
   */
   public ABTErrorCode getErrorCode() { return errCode; }

   /**
   *  return extended information
   *  @return Object - info associated with this error message
   */
   public Object getInfo(){ return info;  }

   /**
   *  return the package of this error code
   *  @return String  name of package
   */
   public String getPackage() { return errCode.getPackage();  }

   /**
   *  return the component who created this thing
   *  @return String  name of creator
   */
   public String getComponent() { return component; }
   /**
   *  return the method (if any) which generated this error
   *  @return String  name of module
   */
   public String getMethod(){ return method; }
   /**
   *  return the date and time this error message was created
   *  @return Date
   */
   public Date getDate() { return date;  }

   /**
   *  return the message
   *  @return String textual representation of error
   */
   public String getMessage()
   {
      if (message == null)
         message = getLocalizedMessage(Locale.US);
      return message;
   }
   
   /**
   *  return the message
   *  @return localized String textual representation of error
   */
   public String getLocalizedMessage(Locale locale_)
   {
      return lookupMessage(locale_);
   }
   
   public ABTDate dateValue(boolean pm){ return new ABTDate(date,true); }
   public ABTTime timeValue()  { return new ABTTime(date); }
   public String stringValue() { return getMessage();}

   public boolean equalTo(ABTErrorCode errCode_){
      return errCode.equalTo(errCode_);
      }
   public boolean equalTo(ABTError err_){
      return errCode.equalTo(err_.errCode);
      }

   /**
   *  check whether the object passed in is an ABTError
   *  @param object - object to check
   *  @return boolean - true if this is an error
   */
   public static boolean isError(Object object)
   {
      if (object == null) return false;
      else return object instanceof ABTError;
   }
   
   // To work around a bug in the Java 1.2 Plugin, we have to explicitly load the bundles here.
   // Java 1.2 Plugin will throw ClassFormatError (not an Exception but a Throwable) which causes the ResourceBundle.getBundle()
   // call to fail without completing its search.
   static ListResourceBundle getBundle(String packagename, Locale myLocale)
   {
      String name = packagename + ".errorResources_" + myLocale.getLanguage() + "_" + myLocale.getCountry();
      Object bundle = bundles_.get(name);
      if (bundle == null) {
         bundle = bundles_.get(new String(packagename + ".errorResources_" + myLocale.getLanguage()));
         if (bundle == null) {
            bundle = bundles_.get(new String(packagename + ".errorResources"));
         }
      }
         
      if (bundle == null) {
         Class c = null;
         try {
            name = packagename + ".errorResources_" + myLocale.getLanguage() + "_" + myLocale.getCountry();
            c = Class.forName(name);
         } catch (Throwable e) {
            try {
               name = packagename + ".errorResources_" + myLocale.getLanguage();
               c = Class.forName(name);
            } catch (Throwable inner_e1) {
               try {
                  name = packagename + ".errorResources";
                  c = Class.forName(name);
               } catch (Throwable inner_e2) {
               }
            }
         }
         
         if (c != null) {
            try {
               bundle = c.newInstance();
               if (bundle != null) bundles_.put(name,bundle);
            } catch (Throwable exception) {
            }
         }
      }     
      return (ListResourceBundle)bundle;
   }
   
   
//***************************************************************************
//             !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//***************************************************************************
//*** Everything from here down is obsolete code and will get deleted soon
//***************************************************************************
//             !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//***************************************************************************
   
   /**
   *  constructor
   *  @param package_ package of creator class
   *  @param component_ creator class
   *  @param method_ name of routine creating it
   *  @param message_ textual representation of error
   *  @deprecated  will go away very soon!
   */
   public ABTError(
               String component_,
               String method_,
               String code_,
               Object info_)
   {
      this(component_,method_,new ABTErrorCode("obsolete ABTError",code_),info_);
   }

   /**
   *  constructor
   *  @param package_ package of creator class
   *  @param component_ creator class
   *  @param method_ name of routine creating it
   *  @param message_ textual representation of error
   *  @deprecated  will go away very soon!
   */
   public ABTError(
               String component_,
               String method_,
               int code_,
               Object info_)
   {
      this(component_,method_,new ABTErrorCode("obsolete ABTError",String.valueOf(code_)),info_);
   }


   /**
   *  constructor
   *  @param package_ package of creator class
   *  @param component_ creator class
   *  @param method_ name of routine creating it
   *  @param code_ code used for lookup
   *  @param info_ extra object
   *  @deprecated  will go away very soon!
   */
   public ABTError(
               String package_,
               String component_,
               String method_,
               String code_,
               Object info_)
   {
      this(component_,method_,new ABTErrorCode(package_,code_),info_);
   }

   /**
   *  constructor
   *  @param package_ package of creator class
   *  @param component_ creator class
   *  @param method_ name of routine creating it
   *  @param code_ code used for lookup
   *  @param info_ extra object
   *  @deprecated  will go away very soon!
   */
   public ABTError(
               String package_,
               String component_,
               String method_,
               int code_,
               Object info_)
   {
      this(component_,method_,new ABTErrorCode(package_,String.valueOf(code_)),info_);
   }

   /**
   *  default constructor
   *  @param component_ class of creator
   *  @param module_ name of routine creating it
   *  @param code_ ErrorCode, used for lookup
   *  @param info_ extra object
   *  @deprecated  will go away very soon!
   */
   public ABTError(
            Class component_,
            String method_,
            String code_,
            Object info_)
   {
      String packg;
      String comp;

      String cName = component_.getName();
      int lastDot = cName.lastIndexOf('.');
      if (lastDot > 0){
         packg = cName.substring(0,lastDot);
         comp = cName.substring(lastDot+1,cName.length());
         }
      else{
         packg = "";
         comp = cName;
         }

      date      = new Date();
      component = comp;
      method    = method_;
      errCode   = new ABTErrorCode(packg,code_);
      info      = info_;
   }

   /**
   *  constructor
   *  @param component_ class of creator
   *  @param module_ name of routine creating it
   *  @param code_ ErrorCode, used for lookup
   *  @param info_ extra object
   *  @deprecated  will go away very soon!
   */
   public ABTError(
            Class component_,
            String method_,
            int code_,
            Object info_)
   {
      this(component_,method_,new Integer(code_).toString(),info_);
   }
   
   /**
   *  return the errorcode
   *  @return int - Errorcode
   *  @deprecated  will go away very soon!
   */
   public int getCode() { 
        // this only works if the ErrorCode.code is a numeric string
        // which is no longer guaranteed
        try { return Integer.parseInt(errCode.getCode()); }
        catch (Exception e){}
        return -1; 
    }
   
}