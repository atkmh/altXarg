/*
 * $Header: d:\sanani\src\com\abtcorp\core\COM\ABTDispatch.java, 5, 11/3/98 5:21:54 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core.COM;

import com.abtcorp.core.*;

public class ABTDispatch extends ABTValue
{
   static {System.loadLibrary("jdisp");}

   protected int  handle_;

   ABTDispatch(int handle) {handle_ = handle;}
   
   public ABTDispatch(ABTDispatch dispatch) {handle_ = dispatch.handle_; addref();}
   
   // helper functions
   
   public static ABTValue[] params(ABTValue value)                   {ABTValue result[] = new ABTValue[1]; result[0] = value; return result;}
   public static ABTValue[] params(ABTValue value1, ABTValue value2) {ABTValue result[] = new ABTValue[2]; result[0] = value1; result[1] = value2; return result;}
   public static ABTValue[] params(int value)                        {return params(new ABTInteger(value));}
   public static ABTValue[] params(int value1, int value2)           {return params(new ABTInteger(value1), new ABTInteger(value2));}
   public static ABTValue[] params(String value)                     {return params(new ABTString(value));}
   public static ABTValue[] params(String value1, String value2)     {return params(new ABTString(value1), new ABTString(value2));}

   // native IUnknown interface
   
   public native int  addref();
   public native int  release();
   public native int  refcnt();
   
   // native IDispatch interface
   
   public native int       getID(String field);
   public native ABTValue  getField(int dispID, ABTValue[] params);
   public native void      setField(int dispID, ABTValue[] params, ABTValue value);
   public native ABTValue  invoke(int dispID, ABTValue[] params);

   public native static ABTDispatch create(String string);

   // default property
   
   public final ABTValue  getDefault()                                  {return getField(0, null);}
   public final ABTValue  getDefault(ABTValue[] params)                 {return getField(0, params);}
   public final ABTValue  getDefault(ABTValue param)                    {return getDefault(params(param));}
   public final ABTValue  getDefault(ABTValue param1, ABTValue param2)  {return getDefault(params(param1, param2));}
   public final ABTValue  getDefault(int index)                         {return getDefault(params(index));}
   public final ABTValue  getDefault(int index1, int index2)            {return getDefault(params(index1, index2));}
   public final ABTValue  getDefault(String index)                      {return getDefault(params(index));}
   public final ABTValue  getDefault(String index1, String index2)      {return getDefault(params(index1, index2));}

   public final void setDefault(ABTValue value)                                   {setField(0, null, value);}
   public final void setDefault(ABTValue[] params, ABTValue value)                {setField(0, params, value);}
   public final void setDefault(ABTValue param, ABTValue value)                   {setDefault(params(param), value);}
   public final void setDefault(ABTValue param1, ABTValue param2, ABTValue value) {setDefault(params(param1, param2), value);}
   public final void setDefault(int index, ABTValue value)                        {setDefault(params(index), value);}
   public final void setDefault(int index1, int index2, ABTValue value)           {setDefault(params(index1, index2), value);}
   public final void setDefault(String index, ABTValue value)                     {setDefault(params(index), value);}
   public final void setDefault(String index1, String index2, ABTValue value)     {setDefault(params(index1, index2), value);}

   // named property

   public final ABTValue  getField(String field)                                    {return getField(getID(field), null);}
   public final ABTValue  getField(String field, ABTValue[] params)                 {return getField(getID(field), params);}
   public final ABTValue  getField(String field, ABTValue param)                    {return getField(field, params(param));}
   public final ABTValue  getField(String field, ABTValue param1, ABTValue param2)  {return getField(field, params(param1, param2));}
   public final ABTValue  getField(String field, int index)                         {return getField(field, params(index));}
   public final ABTValue  getField(String field, int index1, int index2)            {return getField(field, params(index1, index2));}
   public final ABTValue  getField(String field, String index)                      {return getField(field, params(index));}
   public final ABTValue  getField(String field, String index1, String index2)      {return getField(field, params(index1, index2));}
   
   public final void      setField(String field, ABTValue value)                                    {setField(getID(field), null, value);}
   public final void      setField(String field, ABTValue[] params, ABTValue value)                 {setField(getID(field), params, value);}
   public final void      setField(String field, ABTValue param, ABTValue value)                    {setField(field, params(param), value);}
   public final void      setField(String field, ABTValue param1, ABTValue param2, ABTValue value)  {setField(field, params(param1, param2), value);}
   public final void      setField(String field, int index, ABTValue value)                         {setField(field, params(index), value);}
   public final void      setField(String field, int index1, int index2, ABTValue value)            {setField(field, params(index1, index2), value);}
   public final void      setField(String field, String index, ABTValue value)                      {setField(field, params(index), value);}
   public final void      setField(String field, String index1, String index2, ABTValue value)      {setField(field, params(index1, index2), value);}
   
   // named method

   public final ABTValue  invoke(String method)                      {return invoke(getID(method), null);}
   public final ABTValue  invoke(String method, ABTValue[] params)   {return invoke(getID(method), params);}
   public final ABTValue  invoke(String method, ABTValue param)      {return invoke(method, params(param));}
   public final ABTValue  invoke(String method, int param)           {return invoke(method, params(param));}
   public final ABTValue  invoke(String method, String param)        {return invoke(method, params(param));}
}