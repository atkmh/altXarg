package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;

import java.lang.Character;
import java.lang.Double;

import com.abtcorp.core.*;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.blob.ABTCalendar;

public class MppFormat extends ObjectSpaceUtilityFunctions implements MppFormatConstants, IABTPMRuleConstants
{

   public	String	  symbol_;
   public	int		  position_;
   public	int		  digits_;
   public	double	  hpd_                  = 8;
   public	double	  hpw_                  = 40;
   public	char		  listSeparator_        = ',';
   public	char		  thousandsSeparator_   = ',';
   public	char		  decimalSeparator_     = '.';
   public	char		  elapsedCharacter_     = 'e';
   public	char		  minuteCharacter_      = 'm';
   public	char		  hourCharacter_        = 'h';
   public	char		  dayCharacter_         = 'd';
   public	double	  defaultHoursPerDay_   = 8;
   public	char		  weekCharacter_        = 'w';
   public	double	  defaultHoursPerWeek_  = 40;
   public	String	  currencySymbol_       = "$";

   private  String     currSymbol_;
   private  int        currSymPos_;
   private  short      currDigits_;
   private  int        dateOrder_;
   private  int        dateFormat_;
   private  String     hrLabel_;
   private  String     amText_;
   private  String     pmText_;
   private  String     thouSeparator_;
   private  String     dateSeparator_;
   private  String     decSeparator_;
   private  String     timeSeparator_;

//public	double  defaultSecondsPerDay_ = ;
//public	double	defaultSecondsPerWeek_ = ;

   private  String     minuteDisplayString_;
   private  short      minuteDisplayIndex_;

   short minuteLabelDisplay_;
   short hourLabelDisplay_;
   short dayLabelDisplay_;
   short weekLabelDisplay_;
   short yearLabelDisplay_;
   Tasks tasks_;

   MppOsMap map_;

   public MppFormat(_MSProject mspApp)
   {

      Project mppProject = mspApp.getActiveProject();
      tasks_ = mppProject.getTasks();

      currSymbol_ = mppProject.getCurrencySymbol();
      currSymPos_ = mppProject.getCurrencySymbolPosition();
      currDigits_ = mppProject.getCurrencyDigits();

      dateOrder_  = mspApp.getDateOrder();
      dateFormat_ = mspApp.getDefaultDateFormat();
      amText_     = mspApp.getAMText();
      pmText_     = mspApp.getPMText();

      thouSeparator_ = mspApp.getThousandSeparator();
      dateSeparator_ = mspApp.getDateSeparator();
      decSeparator_  = mspApp.getDecimalSeparator();
      timeSeparator_ = mspApp.getTimeSeparator();

      minuteLabelDisplay_  =  mppProject.getMinuteLabelDisplay();
      hourLabelDisplay_    =  mppProject.getHourLabelDisplay();
      dayLabelDisplay_     =  mppProject.getDayLabelDisplay();
      weekLabelDisplay_    =  mppProject.getWeekLabelDisplay();
      yearLabelDisplay_    =  mppProject.getYearLabelDisplay();

      map_ = new MppOsMap(mppProject);

//      setLabelDisplayDefaults(mppProject);

   }

   public void setLabelDisplayDefaults (Project mppProject)
   {

      mppProject.setMinuteLabelDisplay ((short)(0));
      mppProject.setHourLabelDisplay   ((short)(0));
      mppProject.setDayLabelDisplay    ((short)(0));
      mppProject.setWeekLabelDisplay   ((short)(0));
      mppProject.setYearLabelDisplay   ((short)(0));

   }

   public void setLabelDisplayDefaultsToOriginal(Project mppProject)
   {

      mppProject.setMinuteLabelDisplay (minuteLabelDisplay_);
      mppProject.setHourLabelDisplay   (hourLabelDisplay_);
      mppProject.setDayLabelDisplay    (dayLabelDisplay_);
      mppProject.setWeekLabelDisplay   (weekLabelDisplay_);
      mppProject.setYearLabelDisplay   (yearLabelDisplay_);

   }

   public ABTTime getMppTime(ABTValue timeAbtValue)
   {

      if ( timeAbtValue != null) {
         String asString = timeAbtValue.stringValue();
         if (!asString.equals("NA"))
   			return new ABTTime(timeAbtValue);
      }

      return null;
   }

  double returnNumber(String p)
  {

  	StringBuffer  q       = new StringBuffer();
    int           qIndex  = 0;

  	for (int i = 0; i < p.length(); i++) {
	  	if (Character.isDigit(p.charAt(i))) {	//*q++ = *p;
        q.append(p.charAt(i));
        ++qIndex;
      }	else {
        if (p.charAt(i) == decimalSeparator_)
          if ( Character.isDigit(p.charAt(i-1)) || Character.isDigit(p.charAt(i+1)) ){
            q.append('.');
            ++qIndex;
          }
      }
	  }

    return Double.valueOf(q.toString()).doubleValue();

  }

  double parseRate(String value)
  {
	  return returnNumber(value)/3600;
  }


  double alphaToFloat(String  alpha)
  {

  	int pos = alpha.indexOf(thousandsSeparator_);
	  while (pos != -1) {
  		stringRemove(alpha, pos, 1);
	  	if (pos < alpha.length())
		  	pos++;
  		pos = alpha.indexOf(thousandsSeparator_);
  	}

    pos = -1;
	  pos = alpha.indexOf(decimalSeparator_);
  	if (pos != -1) alpha = alpha.replace(decimalSeparator_, '.');
    ABTString atofString =  new ABTString(alpha);
  	return atofString.doubleValue();
  }

  double          convertPercentStringToDouble(String pct)
  {
  	stringRemove(pct, (pct.length() - 1), 1);
  	return alphaToFloat(pct) / 100;
  }

    /**
    *  @param str
    *  @param start  remove from this index on to start+homany
    *  @param howMany how many from start is to be removed
    */


  public String stringRemove(String str, int start, int howMany)
  {

    String  rightPartOfString = null;
    String  leftPartOfString  = null;

    if (start == 0)
      return str.substring(howMany + start, str.length());

    leftPartOfString  = str.substring(0, start);

    if (start + howMany >= str.length()) {
      return leftPartOfString;
    } else {
      rightPartOfString = str.substring(start + howMany, str.length());
    }

    return  leftPartOfString.concat(rightPartOfString);

  }

  short           convertStringToDependencyTypeShort(String theDependencyType)
  {
  	if ((theDependencyType.trim()).length() == 0)
	  	return 0;
  	if (theDependencyType.equals("FS"))
	  	return PR_FIN_START_DEP;
  	if (theDependencyType.equals("SS"))
  		return PR_START_START_DEP;
  	if (theDependencyType.equals("FF"))
  		return PR_FIN_FIN_DEP;
	  if (theDependencyType.equals("SF"))
  		return PR_START_FIN_DEP;
  	return (short) 0;
  }

  MppTimeQuantity convertStringToTimeQuantity(String fv)
  {										  // in returned hours_
    MppTimeQuantity tq = new MppTimeQuantity();
	  double amount_of_time = 0;

  	if (fv.trim().length() == 0)
	  	return tq;
  //   if (fv.length() > 2)
  //      if (fv[fv.length() - 1] == elapsedCharacter_) { //french kluge   switch location of elapsed character
  //         fv[fv.length() - 1] = fv[fv.length() - 2];
  //         fv[fv.length() - 2] = elapsedCharacter_;

  //    }
    if (fv.charAt(fv.length() - 1) == minuteCharacter_)	// last letter is 'm' for	minutes
  		if (fv.charAt(fv.length() - 2) == elapsedCharacter_) {	// elapsed

  			stringRemove(fv, fv.length() - 2, fv.length()); //remove to end
	  		amount_of_time = alphaToFloat(fv);
		  	tq.setType(MINUTES);
			  tq.setAmount(amount_of_time / 60);
        return tq;
	  	} else {						  /* not elapsed */
  			stringRemove(fv, fv.length() - 1, fv.length());
	  		amount_of_time = alphaToFloat(fv);
		  	tq.setType(MINUTES);
			  tq.setAmount(amount_of_time / 60);
        return tq;
	  	}
  	if (fv.charAt(fv.length() - 1) == hourCharacter_)	// last letter is 'h' for
	  	// hours_
		  if (fv.charAt(fv.length() - 2) == elapsedCharacter_) {	// elapsed

  			stringRemove(fv, fv.length() - 2, fv.length());
	  		amount_of_time = alphaToFloat(fv);
		  	tq.setType(HOURS);
			  tq.setAmount(amount_of_time);
        return tq;
	  	} else {						  /* not elapsed */
		  	stringRemove(fv, fv.length()-1, 1);
			  amount_of_time = alphaToFloat(fv);
  			tq.setType(HOURS);
	  		tq.setAmount(amount_of_time);
        return tq;
  		}

  	if (fv.charAt(fv.length() - 1) == dayCharacter_)	// last letter is 'd' for
	  	// days
  		if (fv.charAt(fv.length() - 2) == elapsedCharacter_) {	// elapsed
	  		stringRemove(fv , fv.length() - 2, fv.length());
		  	amount_of_time = alphaToFloat(fv);
			  tq.setType(DAYS);
  			tq.setAmount(amount_of_time * defaultHoursPerDay_);
        return tq;
  		} else {						  /* not elapsed */
	  		stringRemove(fv, fv.length() - 1, fv.length());
		  	amount_of_time = alphaToFloat(fv);
			  tq.setType(DAYS);
  			tq.setAmount(amount_of_time * defaultHoursPerDay_);
        return tq;
		  }

  	if (fv.charAt(fv.length() - 1) == weekCharacter_)	// last letter is 'w' for
	  	// weeks
		  if (fv.charAt(fv.length() - 2) == elapsedCharacter_) {	// elapsed
  			stringRemove(fv, fv.length() - 2, fv.length());
	  		amount_of_time = alphaToFloat(fv);
		  	tq.setType(WEEKS);
  			tq.setAmount(amount_of_time * defaultHoursPerWeek_);
        return tq;
		  } else {						  /* not elapsed */
  			stringRemove(fv, fv.length() - 1, fv.length());
	  		amount_of_time = alphaToFloat(fv);
		  	tq.setType(WEEKS);
			   tq.setAmount(amount_of_time * defaultHoursPerWeek_);
         return tq;
	  	}

  	   return tq;
   }

   MppPredecessor convertStringToMppPredecessor(String dependencyString)
   {
      if ((dependencyString.trim()).length() == 0)
	      return null;

      MppPredecessor dp = new MppPredecessor();

      int           StringIndex = 0;
	   int           lengthOfString = 0;
  	   StringBuffer  idBuffer = new StringBuffer();

  	   dp.percentOrAmount_ = -1;
	   dp.type_ = 0;

  	   lengthOfString = dependencyString.length();
  	   // get ID out
	   if (dependencyString.charAt(StringIndex) >= '0' && dependencyString.charAt(StringIndex) <= '9') {
  		   do {
	  		   idBuffer.append(dependencyString.charAt(StringIndex));
		  	   StringIndex++;

  			   if (lengthOfString == StringIndex) {
	  			   break;
            }
  		   } while (dependencyString.charAt(StringIndex) >= '0' && dependencyString.charAt(StringIndex) <= '9');
      }

  	   if (idBuffer.length() > 0) {
         dp.predecessorUniqueId_ = Integer.decode(idBuffer.toString()).intValue();
     	}
      dependencyString = stringRemove(dependencyString, 0, StringIndex);
  	   // get Type out
	   if (dependencyString.length() > 0) {
  		   String        type = dependencyString.substring(0, 2);
	  	   dp.type_ = convertStringToDependencyTypeShort(type);
  	   } else dp.type_ = 0;

	   // get + or - out
  	   if (dependencyString.length() > 0) {
	  	   dependencyString = stringRemove(dependencyString, 0, 2);
		   if (dependencyString.length() > 0)
  			   dp.operator_ = dependencyString.charAt(0);
	  	   else
		  	   dp.operator_ = 0;

     	   if (dependencyString.length() > 0)
            stringRemove(dependencyString, 0, 1);

	      }

     	   if (dependencyString.length() > 0) {
	     	   // determine if it is a percentage or time quantity
		      int          pos = dependencyString.indexOf('%');
  		      if (pos != -1) {
	  		      // get percentage out
   		  	   dp.percentOrAmount_ = PR_PERCENT_DEPENDENCY;
	   		   if (dp.operator_ == '+')
  		   		dp.lagOrLead_ = convertPercentStringToDouble(dependencyString);
	  		   else
		  		   dp.lagOrLead_ = -1 * convertPercentStringToDouble(dependencyString);
     		} else {
	     		// get time quanity out
		     	dp.percentOrAmount_ = PR_DAILY_DEPENDENCY;
  			   if (dp.operator_ == '+') {
               MppTimeQuantity tmp = convertStringToTimeQuantity(dependencyString);
	   	  		dp.lagOrLead_ = tmp.getAmount();
  		   	} else {
               MppTimeQuantity tmp = convertStringToTimeQuantity(dependencyString);
		  		   dp.lagOrLead_ = -1 * tmp.getAmount();
           }
	     	}
  	   } else {
	  	   dp.lagOrLead_ = 0;
  	   }

	   return dp;

   }

  Vector  fillUniqueIDPredecessorsListFromString(String x)
  {
  	int          commaPosition;
    Vector uniqueIdPredecessorList = new Vector();

  	String       mspString = new String(x);

  	while (mspString.length() > 0) {

  		// read up to comma
	  	commaPosition = mspString.indexOf(listSeparator_);
		  if (commaPosition != -1) {
  			String aToken = mspString.substring(0, commaPosition);
	  		uniqueIdPredecessorList.addElement(aToken);
		  	mspString = stringRemove(mspString, 0, commaPosition + 1);
  		} else {
	  		uniqueIdPredecessorList.addElement(new String(mspString));
        return uniqueIdPredecessorList;
  		}
	  }
    return uniqueIdPredecessorList;
  }
     
    /**
    *  Strip extraneous information from the string returned from getting
    *  the standard rate field of a Microsoft Project resource.  This method
    *  removes the currency symbol wherever it is in the string, embedded blanks,
    *  and the "/hours" at the end of the string. It also saves the string
    *  "hours" since there seems to be no easy way to get this directly from
    *  an MPP file.
    *  @param inString the String object returned from the getStandardRate call
    *  @return a String object containing the amount with decimal places preserved
    */

    public String importMoney( String inString )
    {
        int separatorIdx = -1;
        double tempInt = 0;
        String retStr = null;

        if ( inString != null && inString.length() > 0 )
        {
            separatorIdx = inString.indexOf( "/" );

            // Save whatever string we're using in this file to specify "hours"
            if ( hrLabel_ == null )
                hrLabel_ = new String( inString.substring( separatorIdx+1 ) );

            // If currency symbol is at the beginning of the string, the
            // amount follows and the string up to the "/" is it.  If the
            // currency symbol follows the amount, the portion of the string
            // before it must be the amount. (currSymPos_ is a value from
            // an enum, not the actual position.)
            if ( currSymPos_ == 0 || currSymPos_ == 2 )
            {
                retStr = new String( inString.substring( 1, separatorIdx ) );
            }
            else  // Symbol follows the amount.
            {
                int tempIdx = inString.indexOf( currSymbol_ );
                retStr = new String( inString.substring( 0, tempIdx ) );
            }

            // Remove leading/trailing spaces.
            retStr.trim();
        }

        return retStr;
    }

    /**
    *  Build a string representing the MPP resource's standard rate for passing to
    *  the setStandardRate method of a Microsoft Project resource.  This method
    *  adds the currency symbol wherever and any embedded blanks based on the
    *  trailing data.  It also saves the string representation of "hours"
    *  since there seems to be no easy way to get this directly from an MPP file.
    *  @param money a double representing the Resource's standard rate in
    *  dollars (or whatever the currency really is) per second
    *  @return a String object formatted for the MSP file. An example would be
    *  "$150.00/hr"
    */
    public String exportMoney( double money )
    {
        String retStr = null;

        Double moneyDbl = new Double( money * 3600 ); //Per second -> per hour

        // Convert the amount to a string and add the currency specifier
        // and other characters to make a well-formed string for MSP.

        switch ( currSymPos_ )
        {
            case 0:
                retStr = currSymbol_ + moneyDbl.toString() + "/" + hrLabel_;
                break;

            case 1:
                retStr = moneyDbl.toString() + currSymbol_ + "/" + hrLabel_;
                break;

            case 2:
                retStr = currSymbol_ + " " + moneyDbl.toString() + "/" + hrLabel_;
                break;

            case 3:
                retStr = moneyDbl.toString() + " " + currSymbol_ + "/" + hrLabel_;
                break;
        }

        return retStr;
    }



   //MSP CONSTRAINT TYPE TO SANANI

   public int msToSnConstraintType(int type) {

      switch ( type ) {

         case pjALAP:      return 2;   // As late as possible (no date given)
         case pjMSO:       return 6;   // Must start on (date)
         case pjMFO:       return 5;   // Must finish on (date)
         case pjSNET:      return 7;   // Start no earlier than (date)
         case pjSNLT:      return 8;   // Start no later than (date)
         case pjFNET:      return 3;   // Finish no earlier than (date)
         case pjFNLT:      return 4;   // Finish no later than (date)

      }

      return 1;   // by default As soon as possible (no date given)
   }

   //SANANI CONSTRAINT TYPE TO MSP

   public int snToMsConstraintType(int type) {

      switch ( type ) {

         case 1:  return pjASAP;       // As late as possible (no date given)
         case 2:  return pjALAP;       // As late as possible (no date given)
         case 3:  return pjFNET;       // Finish no earlier than (date)
         case 4:  return pjFNLT;       // Finish no later than (date)
         case 5:  return pjMFO;        // Must finish on (date)
         case 6:  return pjMSO;        // Must start on (date)
         case 7:  return pjSNET;       // Start no earlier than (date)
         case 8:  return pjSNLT;       // Start no later than (date)
      }

      return 0;            // by default As soon as possible (no date given)
   }

   public Tasks getMppTasks(Project mppProject) //should throw if null??
   {
      if (mppProject instanceof Project){

         return mppProject.getTasks();
      }

      return null;
   }

   public  Task createMppTask(ABTValue Name, ABTValue Before)
   {
      return tasks_.Add(Name, Before);
   }


   public  Task createMppTask()
   {
      return tasks_.Add(null, null);
   }

   public  Tasks getTasks()
   {
      return tasks_;
   }

    public void deleteAllDependencies(Project mppProject_, boolean reload)
    {

      Enumeration mppTasksEnumerator = map_.getMppTasksEnumeration(mppProject_, reload);

      ABTValue taskAbtValue;

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch match = (MppOsMatch) mppTasksEnumerator.nextElement();

         Task mppTask = (Task) match.getMppObject();

         mppTask.setUniqueIDPredecessors("");

		}

    }

    boolean eq(String a, String b)
    {
      return a.equals(b);
    }

    public void mppSetTaskField(String ofd, IABTObject taskObject, Task mppTask)
    {

      ABTValue val  = taskObject.getValue(ofd);

      if (eq(ofd, OFD_NAME))        {mppTask.setName                 (val.stringValue());   return;}
//    if (eq(ofd, OFD_EARLYSTART))  {mppTask.setEarlyStart           (val.timeValue());     return;}
//    if (eq(ofd, OFD_EARLYFINISH)) {mppTask.setEarlyFinish          (val.timeValue());     return;}

//    if (eq(ofd, OFD_LATESTART))   {mppTask.setLateStart            (val.timeValue());     return;}
//    if (eq(ofd, OFD_LATEFINISH))  {mppTask.setLateFinish           (val.timeValue());     return;}
      if (eq(ofd, OFD_BASESTART))   {mppTask.setBaselineStart        (val.timeValue());     return;}
//    if (eq(ofd, OFD_BASEFINISH))  {mppTask.BaselineFinish          (val.timeValue());     return;}
      if (eq(ofd, OFD_PCTCOMPLETE)) {mppTask.setPercentComplete      (val); return;}
      if (eq(ofd, OFD_PCTEXPENDED)) {mppTask.setPercentWorkComplete  (val); return;}
      if (eq(ofd, OFD_DURATION))    {mppTask.setDuration             (new ABTDouble(val.doubleValue()*60*8)); return;}
      if (eq(ofd, OFD_BASEDURATION)){mppTask.setBaselineDuration     (val); return;}
      if (eq(ofd, OFD_DELAY))       {mppTask.setLevelingDelay        (val); return;}
//    if (eq(ofd, OFD_ISCRITICAL))  {mppTask.setCritical             (val);    return;}
      if (eq(ofd, OFD_ISMILESTONE)) {mppTask.setMilestone            (val); return;}
//    if (eq(ofd, OFD_ISTASK))      {mppTask.setSummary              (val); return;}

      //      if (eq(ofd, OFD_PRIORITY))
      //      if (eq(ofd, OFD_TOTALFLOAT))
      //      if (eq(ofd, OFD_WBSSEQUENCE))

   }


   public String timeQuantityToString(double amountOfTime, int timeQuantityType)
   {

	   String timeQuantityString = new String();

   	switch (timeQuantityType) {

	   	case MINUTES:
		   	timeQuantityString = (new String())     + amountOfTime;
			   timeQuantityString = timeQuantityString + minuteLabelDisplay_;
   			break;
	   	case HOURS:
		   	timeQuantityString = (new String())     + amountOfTime;
			   timeQuantityString = timeQuantityString + hourLabelDisplay_;
   			break;
	   	case DAYS:
		   	timeQuantityString = (new String())     + amountOfTime;
			   timeQuantityString = timeQuantityString + dayLabelDisplay_;
   			break;
	   	case WEEKS:
		   	timeQuantityString = (new String())     + amountOfTime;
			   timeQuantityString = timeQuantityString + weekLabelDisplay_;
   			break;
	   	case YEARS:
		   	timeQuantityString = (new String())     + amountOfTime;
			   timeQuantityString = timeQuantityString + yearLabelDisplay_;
   			break;
	   	default:
		   	timeQuantityString = (new String())     + amountOfTime;
			   timeQuantityString = timeQuantityString + hourLabelDisplay_;
   	}

	   return timeQuantityString;
   }

   public String getdailyDependencyString(MppPredecessor dp, String compositeString)
   {

      if (dp.percentOrAmount_ == PR_DAILY_DEPENDENCY) {
         if (dp.lagOrLead_ > 0)
		      compositeString = compositeString+ "+" +
               timeQuantityToString(dp.lagOrLead_ / defaultHoursPerDay_,DAYS);
  		   else
   		   compositeString = compositeString+
               timeQuantityToString(dp.lagOrLead_ / defaultHoursPerDay_, DAYS);
      	}

      return compositeString;

   }

   public String getPercentDependencyString(MppPredecessor dp, String compositeString)
   {

      if (dp.percentOrAmount_ == PR_PERCENT_DEPENDENCY) {
         if (dp.lagOrLead_ > 0)
		      compositeString = compositeString+ "+" + dp.lagOrLead_ +'%';
	      else compositeString = compositeString + dp.lagOrLead_;
     	}
      return compositeString;
   }


   public String mppPredecessorToString(MppPredecessor dp)
   {

	   String compositeString = new String();

   	compositeString = compositeString + dp.predecessorUniqueId_;
	   compositeString = compositeString + dp.type_;

      if (dp.lagOrLead_ != 0) {

      	if (dp.percentOrAmount_ == PR_DAILY_DEPENDENCY) {

            compositeString = getdailyDependencyString(dp, compositeString);

      	} else

            getPercentDependencyString(dp, compositeString);

      }

	   return compositeString;

   }

   String        dependencyTypeToString(short dependencyType)
   {
      switch (dependencyType) {

         case PR_FIN_START_DEP:     return new String("FS");
   	   case PR_START_START_DEP:   return new String("SS");
   	   case PR_FIN_FIN_DEP:       return new String("FF");
   	   case PR_START_FIN_DEP:   	return new String("SF");

      }

  	return new String("FS");

   }
}
