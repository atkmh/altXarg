package com.abtcorp.io.client;
/*
 * ABTFileDriver.java 03/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98      SA          Initial Implementation
  * 07-14-98      MXA         Add the default Constructor
  * 08-11-98      MXA         Add checkInitStatus().
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;

import com.abtcorp.io.ABTNotImplementedException;

/***
 * Base class for an ABTDriver for files. Drivers of this type will populate ABTObjectSpaces
 * from a file and save the ABTObjectSpace to a file.
 *
 */
public class ABTFileDriver extends ABTClientDriver
{
   /***
    * The file object that this driver reads and writes data from.
    */
   private File file_;
   /***
    * The name of the file that this driver reads and writes data from.
    */
   private String fileName_;

   /**
    *	Create an ABTFileDriver that is not associated with an ABTObjectSpace.
    * Associating an object space with this driver will be deferred until later.
    */

   public ABTFileDriver() {/*implicit call to super() here*/}

   /***
    * Constructs an ABTFileDriver. The driver constructed with this constructor
    * is not associated to any particular file yet.
    * @param space The ABTObjectSpace that this driver is associated with.
    */
   public ABTFileDriver(IABTObjectSpace space) {
      super();}

   /***
    * Constructs an ABTFileDriver. The driver constructed with this constructor
    * is associated with the file specified by the file name passed in.
    * @param space The ABTObjectSpace that this driver is associated with.
    * @param filename The name of the file that this driver is associated with.
    */
   public ABTFileDriver(IABTObjectSpace space, String filename)
   {
      super();

      fileName_ = filename;
      open(space, null);
   }

   /***
    * Opens the driver by creating the file object associated with the file name.
    * @param space reference to an IABTObjectSpace object
    * @param args a hash table of parameters and arguments for this method
    * @return boolean Indicator whether the open succeeded or failed. True = successful open; false = unsuccessful open.
    *
    */
   public ABTValue open(IABTObjectSpace space, IABTHashTable args)
   {
      ABTValue  ret = null;
      return ret;
   }
   
   /***
    * Populates the ABTObjectSpace based on the specifics of the selector passed and the
    * semantics of this driver.
    * @param space reference to an IABTObjectSpace object
    * @param args a hash table of parameters and arguments for this method
    * @return ABTValue A variant object that contains the objects that this driver populated based on the selector.
    * @exception ABTNotImplementedException
    *    If the populate method hasn't been implemented by this driver.
    */
   public ABTValue populate(IABTObjectSpace space, IABTHashTable args)
   {
      return new ABTError("com.abtcorp.io.client","ABTFileDriver", "populate", "100", null);
   }

   /***
    * Saves the objects passed to a file based on the criteria specified and the semantics of this driver.
    * @param space reference to an IABTObjectSpace object
    * @param args a hash table of parameters and arguments for this method
    * @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue save(IABTObjectSpace space, IABTHashTable args)
   {
      return new ABTError("com.abtcorp.io.client","ABTFileDriver", "save", "100", null);
   }

   /***
    * Closes this driver.
    * @param space reference to an IABTObjectSpace object
    * @param args a hash table of parameters and arguments for this method
    * @exception ABTException
    *    If the file cannot be closed.
    */
   public ABTValue close(IABTObjectSpace space, IABTHashTable args) {return (ABTValue) null;}

   /***
    * Sets the file name for this driver.
    * @param filename The file name that will be associated with this driver.
    *
    */
   public void setFileName(String filename) 
   {
        fileName_ = filename;
   }

   /***
    * Gets the file name for this driver.
    * @return file name  associated with this driver
    *
    */
   public String getFileName() {return fileName_;}

   /***
    * Returns the file object associated with this driver.
    * @return File The file object that this driver will read from or write to.
    */
   public File getFile() {return file_;}
 
   /***
    * Sets the file name for this driver.
    * @param filename The file name that will be associated with this driver.
    * @return boolean Indicator whether the open succeeded or failed. 
    *                 True = successful open; false = unsuccessful open.
    *
    *
    */
   protected ABTValue setFile(String filename) 
   {
      ABTValue  ret =  new ABTBoolean(true);
      
      setFileName(filename) ;        
      try {
         if (fileName_ != null) {
            file_ = new File(fileName_);
         }
      } catch (Exception e) {
         e.printStackTrace();
         ret = new ABTError("com.abtcorp.io.client","ABTFileDriver", "open", "101" + fileName_ + "'", null);
      }
      return ret;
   }
   
   /***
    * cleanupFile
    * Sets the file name and File for this driver to null
    * @return null   
    */
   protected ABTValue cleanupFile() 
   {
      fileName_ = null;
      file_     = null;
      return (ABTValue) null;
   }
   
  /***
   *Make sure that the object space is set and so is the file
   *@return true if success
   *@exception ABTException if an unrecoverable error occurs
   */
   public boolean checkInitStatus() throws ABTException 
   {
        //Make sure the Object Space is set.
        if (getSpace() == null)
            throw new ABTException("Object space not set");
        if (getSpace().getRulebase() == null)
            throw new ABTException("Rule base not set");
       if (getFile() == null)
            throw new ABTException("File not set");
            
       return true;
   }
   

}
