
package com.abtcorp.hub;

/*
 * ABTFunctionParameter.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



class ABTFunctionParameter
{
    public Object object;
    public ABTUserSession session;
    public ABTObjectSpace space;

    public ABTFunctionParameter(
        Object object_,ABTUserSession session_,ABTObjectSpace space_)
    {
         object = object_;
         session = session_;
         space = space_;
    }

    
}

