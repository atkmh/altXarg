package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoHelper.java 06/24/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-24-98    LZX         Initial Implementation
 * 07-10-98    LZX         Added methods to wrap around the "hub" methods (object,
 *                         objectset, etc.) and to support transactions.
 * 07-14-98    LZX			Move some methods to the ABTIOHelper and ABTIORepoHelper
 *                         and extend from ABTIORepoHelper.
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.idl.*;
import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 * ABTIOMethRepoHelper is an abstract class for the ABT methodology driver.
 * It is extended by the other ABT methodology helper classes.
 *
 *  <pre>
 *       ABTIOMethRepoHelper ra = new ABTIOMethRepoHelper(ABTMMRepoDriver driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 */

public abstract class ABTIOMethRepoHelper extends ABTIORepoHelper implements IABTIOMethRepoConstants, IABTMMRuleConstants
{

   protected ABTRepository repo_;             // the repository connected to
   protected ABTMMRepoDriver driver_;     // the driver that uses this helper
   protected ABTCursor cursor_;               // the cursor selected from the repository
   protected ABTValue parent_;                // the parent that owns the objects to be populated/saved
   protected ABTHashtable reqParams_;         // the required parameters when creating the object
   protected String component_;               // the name of the helper class

/**
 * ABTIOMethRepoHelper constructor.
 * @param driver: the reference to the driver.
 * @param parent: the parent object.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   ABTIOMethRepoHelper(ABTMMRepoDriver driver,  ABTValue parent, String table, String type)
   {
      super(driver, table, type);
      driver_ = driver;
      userSession_ = driver.getUserSession();
      space_ = driver.getSpace();
	   repo_ = driver_.getRepository();
	   parent_ = parent;
      reqParams_ = new ABTHashtable();
	   cursor_ = null;
   }


/**
 * Populate the object sets.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
	   ABTValue object = null;             // local ABTObject
   	ABTObjectSet oSet = null;

      try
      {
         // create an object set for the "global" objects.
         if (parent_ == null)
      	   oSet = createObjectSet(type_);

         cursor_ = getCursorForPopulate();
         if (cursor_ == null)
            processError(MOD_POPULATE,
                        errorMessages.ERR_SELECT_ERROR,
                        "table name = " + table_);

      	while (cursor_.moveNext())		// for every row in the result set...
      	{
            long prID = cursor_.getFieldInt(FLD_ID);
            ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID);

            // See if the object already exists in the object space.
            object = find(type_, id);

            if (object instanceof ABTObject)
            {
               // if found, update/merge this assignment
               object = update((ABTObject)object);
            }
            else
            {
               // if not found, create an object for this assignment in the
               // object space and set its property values.
               object = create(type_, id, reqParams_);
            }

            // add this object to the object set if it's a "global" object.
            if (parent_ == null)
               add(oSet, (ABTObject) object);

      	}  // end while()
      }
      finally
      {
         closeCursor(cursor_);
      }

      return oSet;
	}


/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
		ABTObject object = createObject(type, id, params);
		setValues(ps_, cursor_, object);

      return object;
   }

/**
 * Update an existing object in the object space with properties from the repository.
 *	@param object: the object to be updated.
 *	@return ABTValue: a reference to the object updated or an ABTError.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue update(ABTObject object) throws ABTException
   {
      // override everything for now.
		setValues(ps_, cursor_, object);

      return object;
   }

/**
 * Set assignment values.
 * @param ps: the assignment property list.
 * @param cur: the assignment cursor.
 * @param obj: the assignment object.
 * @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector aps, ABTCursor cur, ABTObject obj) throws ABTException
   {
      setPropertyValues(aps, cur, obj);
   }


/**
 * Save objects from the object space back to the repository
 * @param parent  the parent object that contains the object set to be saved
 * @param list    the name of the object set to save
 * @return ABTValue of the object set that's saved
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue save(ABTObject parent, String list, boolean saveAs) throws ABTException
   {
      // get object set from the parent object
   	ABTValue val = getValue(parent, list);
   	if (!(val instanceof ABTObjectSet))
   	{
         processError(MOD_SAVE,
                     errorMessages.ERR_OBJECTSET_NOT_FOUND,
                     list + " object set is not found in " + ((ABTObject)parent_).getObjectType() + ". id = " + getValue((ABTObject)parent_, OFD_ID));
         return null;
      }

      // make sure the object set is not null or empty
   	if (ABTValue.isNull(val))
   	{
         processError(MOD_SAVE,
                     errorMessages.ERR_OBJECTSET_NOT_FOUND,
                     list + " object set is null or empty in " + ((ABTObject)parent_).getObjectType() + ". id = " + getValue((ABTObject)parent_, OFD_ID));
         return null;
      }

      return save((ABTObjectSet) val, saveAs);
   }


/**
 * Save objects from the object space back to the repository
 * @param oSet the object set to be saved
 * @return ABTValue of the object set that's saved
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue save(ABTObjectSet oSet, boolean saveAs) throws ABTException
   {
      boolean isNew = false;

   	// get property set from the dictionary
	   ps_ = dataDictionary_.getPropertiesFromDataModel(table_);

      // make sure the property set is not null
      if ((ps_ == null) || ps_.isEmpty())
      {
         processError(MOD_SAVE,
                     errorMessages.ERR_INVALID_PROPERTYSET,
                     "Null property set for table " + table_);
         return null;
      }

      // a cursor is selected for the entire object set to be saved (all the
      // records that belong to the parent) sorted by prID.
      cursor_ = getCursorForSave();
      cursor_.setSort(table_ + "." + FLD_ID);

      try
      {
         // iterate through all the objects in the object set
         for (int i = 0; i < size(oSet); i++)
         {
            ABTObject obj = (ABTObject)at(oSet, i);

            // make sure the object is of the right type
            if (!obj.getObjectType().equals(type_))
            {
               processError(MOD_SAVE,
                           errorMessages.ERR_INVALID_TYPE,
                           "expected object type = " + type_ + ", bad type = " + obj.getObjectType());
               return null;
            }

            // check if this is a new object. force add new if save-as.
            if (saveAs)
               isNew = true;
            else
               isNew = isNewObject(obj, cursor_);

            // add or edit cursor depending on whether this is a new object
				if (isNew)
            {
            	// add a new row to the end of the cursor so that the order of the cursor won't
            	// get messed up (the cursor is ordered by prID for faster acess and the prID of
            	// the new row will be guranteed greater than the prID of the last row in the cursor).
            	cursor_.moveEOF();
               cursorAddNew(cursor_);
		      }
            else
				{
           		// edit the cursor for pre-existing record
              	cursorEdit(cursor_);
            }

            // set fields and update the cursor
				setCursorValues(ps_, cursor_, obj, this, isNew);
            cursorUpdate(cursor_);

            // Set the prID and remote ID for new object after successful update
            if (isNew)
            {
               ABTValue prID = cursor_.getField(FLD_ID);
               setValue(obj, OFD_ID, prID);
               ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID.intValue() );
               obj.getID().setRemote(userSession_, id);
            }

            //
            // Drop the current row from the cursor's result set.  Doing this
            // will facilitate deleting remaining rows in the result set after all
            // add/update/delete processing has taken place.  However, this method
            // will not delete remaining rows in the result set.  That operation is
            // up to the caller.
            //
   			cursor_.drop();

         }	// end for

         //
         // Now process the deleted objects associated with the input object set.  The
         // remote ID's of these deleted objects are presented in an ABTArray.
         //
         ABTArray da = oSet.getDeletedData(userSession_);
         Enumeration rmtIDEnum = da.elements();

         //
         // For each deleted object in the object set, see if a corresponding tuple exists in the cursor's
         // result set.  If it exists, delete it.  If it doesn't exist, skip the object and get the next
         // one; the tuple has already been deleted.  If the ABTArray contains an object which is not of type
         // ABTRemoteIDRepository, skip it and get the next object.
         //
         while ( rmtIDEnum.hasMoreElements() )
         {
            Object rmtID = rmtIDEnum.nextElement();
            if ( !(rmtID instanceof ABTRemoteIDRepository) )
               continue;
            int id = (int) ((ABTRemoteIDRepository)rmtID).getPrID();
            if ( cursor_.bsearchFirst(FLD_ID, new ABTInteger(id)) )
               cursor_.delete();
         }

      }
      finally
      {
         closeCursor(cursor_);
      }

      return oSet;
   }

/**
 *    Populate an object space with an object (or objects) as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      processError("populate(ABTArray)",
                  errorMessages.ERR_NOT_IMPLEMENTED,
                  "");
   	return null;
   }

/**
 * Create a new object in the object space and initialize it with values appropriate to the
 * driver being used.
 *	@param ABTArray parms, the elements of which are meaningful as parameters to the particular
 * helper
 *	@return an ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue create(ABTArray parms) throws ABTException
   {
      processError("create(ABTArray)",
                  errorMessages.ERR_NOT_IMPLEMENTED,
                  "");
   	return null;
   }

/**
 *    Update an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param ABTArray parms, the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object updated in the
 *    object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue update(ABTArray parms) throws ABTException
   {
      processError("update(ABTArray)",
                  errorMessages.ERR_NOT_IMPLEMENTED,
                  "");
   	return null;
   }


/**
 *    Save an object (or objects) from the object space as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return void
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public void save(ABTArray parms) throws ABTException
   {
      processError("save(ABTArray)",
                  errorMessages.ERR_NOT_IMPLEMENTED,
                  "");
   }


/**
 * Release the cursor.
 *	@param cursor: the cursor to be released.
 */
   protected void closeCursor(ABTCursor cursor)
   {
      if (cursor != null)
      {
         cursor.release();
         cursor = null;
      }
   }


/**
 *    Processes an error situation raised by the caller by calling ABTMMRepoDriver's processError().
 *    @param method: the method in which error occured.
 *    @param code: the error code
 *    @param info: further information describing the error condition
 *    @return some kind of value (for now the severity level).
 *    @exception ABTException if the severity level is 1 (the highest severity)
 */
 public int processError(String method, ABTErrorCode code, Object info) throws ABTException
 {
   return driver_.processError(component_, method, code, info);
 }


/**
 *    Get id from cursor and retrieve the object associated with the id from a hash table.
 *    @param cur:          the cursor that contains the id
 *    @param idFieldName:  the column name of the id (e.g., prTaskID)
 *    @param hash:         the hash table that contains the id-object pairs
 *    @param objType:      the type of the requested object
 *    @return the requested object.
 *    @exception ABTException if error occurred
 */
 public ABTObject getObjectFromHash(ABTCursor cur, String idFieldName, Hashtable hash, String objType) throws ABTException
 {
   ABTObject obj = null;

   // get id from cursor
   Long id = new Long(cur.getFieldInt(idFieldName));

   // make sure the id is not null
   if (id == null)
      processError("getObjectFromHash",
                  errorMessages.ERR_INVALID_ID,
                  idFieldName + " = " + id);

   // make sure the hash table is not null
   if ((hash == null) || hash.isEmpty())
      processError("getObjectFromHash",
                  errorMessages.ERR_INVALID_HASH,
                  "Empty hash table for object " + objType);

   // get object associated with the id from hash table
   obj = (ABTObject) hash.get(id);

   // make sure the object is not null and of correct type
   if (obj == null)
      processError("getObjectFromHash",
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  "object type = " + objType + ", " + idFieldName + " = " + id);

   else if (obj.getObjectType() != objType)
   {
      processError("getObjectFromHash",
                  errorMessages.ERR_INVALID_TYPE,
                  "expected object type = " + objType + ", bad type = " + obj.getObjectType());
      obj = null;
   }

   // finally, return the object itself.
   return obj;
}

/**
 *    Get id from cursor and retrieve the object associated with the id from the object space.
 *    @param cur:          the cursor that contains the id
 *    @param idFieldName:  the column name of the id (e.g., prTaskID)
 *    @param objType:      the type of the requested object
 *    @return the requested object.
 *    @exception ABTException if error occurred
 */
 public ABTObject getObjectFromSpace(ABTCursor cur, String idFieldName, String objType) throws ABTException
 {
   ABTValue val = null;

   // get referenced field id from cursor
   long id = cur.getFieldInt(idFieldName);

   // construct a remote id
   // NOTE: for global objects, may need to match external id or name in order
   // to support mix objects from multiple repositories.
   ABTRemoteIDRepository rmtID = new ABTRemoteIDRepository(repo_.getID(), id);

   // See if the object already exists in the object space.
   val = find(objType, rmtID);

   // make sure the object is not null
   if ((val instanceof ABTObject) && !ABTValue.isNull(val))
      // return the object.
      return (ABTObject)val;
   else
   {
      String table = cur.getTableName();
      long prID = cur.getFieldInt(FLD_ID);
      processError("getObjectFromSpace",
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  "table name = " + table + ", prID = " + prID + ", " +
                  idFieldName + " = " + id + ", object " + objType + " not found.");
   }
   return null;
}


/**
 *    determines if a new record should be added to the repository for an object.
 *    @param obj  the object in question
 *    @param cur  the cursor in which the id of the object is searched
 *    @return     true if new, false if not.
 *    @exception  ABTException if error occurred
 */
protected boolean isNewObject (ABTObject obj, ABTCursor cur) throws ABTException
{
   // get remote id of the object
   ABTValue rmtID = getRemoteID(obj);

   // if the remote id is not null, and matches the current reposiotry, and
   // the id value can be found in the cursor, then this is a pre-existing
   // record.
   if (rmtID != null &&
       rmtID instanceof ABTRemoteIDRepository &&
       ((ABTRemoteIDRepository)rmtID).getRepositoryID() == repo_.getID() )
   {
	   ABTValue id = getValue(obj, OFD_ID);
   	if ( cur.bsearchFirst(FLD_ID, id) )
   	   return false;
      else
      {
      	// The object has a remote id but can not be found in the repoitory!!!
      	// currently return to the user. should we keep going instead???
         processError("isNewObject",
                     errorMessages.ERR_RECORD_NOT_FOUND,
                     "The object has a remote id in the object space but can not be found in the repository. table name = " + table_ + ", prID = " + id);
         return true;
      }
  }

   // otherwise treat it as new record.
   return true;

}


   /**
    *    Determines if a global object exists in the repository
    *    @param obj the object to check
    *    @param cur the cursor used to search the object from
    *    @return true if the object is new to the Repository, false if exists in the
    *          repository
    *    @exception  ABTException if error occurred
    */
   public boolean isNewGlobal(ABTObject obj, ABTCursor cur, String altSearchField) throws ABTException
   {
      boolean ret = true;

      // Get the resource's remote ID, if any.
      ABTValue rmtID = getRemoteID(obj);

      // If the object has a repository id that is the same as that of the
      // currently connected repository, search the cursor for a match on
      // the prID field.
      //
      if ( getRepoID(obj) == repo_.getID() )
      {
         ABTValue id = getValue(obj, OFD_ID);

         // The following code assumes the cursor is ordered by prID.
         if ( cur.bsearchFirst(FLD_ID, id) )
            ret = false;                     // it exists
      }

      //
      // If the we still haven't positively identified the object as being present in the
      // currently connected repository, i.e., ret is still true, then perform a linear
      // search on the alternate search field (ext id or name).
      //
      if ( ret )
      {
         ABTValue searchStr = getValue(obj, altSearchField);
         if ( cur.lsearchFirst("pr" + altSearchField, searchStr))
            ret = false;            // it exists
      }

      return ret;
   }


/**
 * retrieves the ID field from an object and sets it to the correspondent field in
 * a cursor. The reason to do this is that when a new object is saved back to
 * the repository, the prID is assigned by PVision. Therefore we need to set this
 * prID back to the object and whenver it is referenced by other objects, we need
 * to retried the ID from the object itself.
 *
 * @param cur        the cursor to set ID to
 * @param obj        the object being saved
 * @param refObjName the name of the referenced object to retrieve ID from
 * @param idField    the ID field name in cursor
 * @return     true if new, false if not.
 * @exception  ABTException if error occurred
 */

protected void setIDFromObject (ABTCursor cur, ABTObject obj, String refObjName, String idField) throws ABTException
{
   // retrieve the object that contains the ID
	ABTValue val = getValue(obj, refObjName);
   if ((val instanceof ABTObject) && !ABTValue.isNull(val))
      // set the correspondent ID field in cursor using the ID value from the object
      cursorSetField(cur, idField, getValue((ABTObject)val, OFD_ID));
   else
      processError("setIDFromObject",
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  refObjName + " not found in " + obj.getObjectType());
}


/**
 */
protected void setGlobalID(ABTCursor cur, ABTCursor refCur, ABTObject obj, String refObjName, String idField, String matchField) throws ABTException
{
   // retrieve the referenced object
	ABTValue val = getValue(obj, refObjName);

   if ((val instanceof ABTObject) && !ABTValue.isNull(val))
   {
      ABTObject refObj = (ABTObject)val;

      // check if the ref object came from the same repository
      if (getRepoID(refObj) == repo_.getID())
      {
         // if it came from the same repository, check if the prID still exists.
         ABTValue id = getValue(refObj, OFD_ID);

         if (refCur.bsearchFirst(FLD_ID, id))
         {
            // prID is found in the ref cursor, so set the id and get out of here.
            cursorSetField(cur, idField, id);
            return;
         }
      }

      // if it came from another repository, or if it came from the same repository
      // but the prID does not exit anymore, look up the external id or name in
      // the ref cursor and retrieve the id from there.
      String searchStr = getValue(refObj, matchField.substring(2)).stringValue();

      if ((searchStr != null) && refCur.lsearchFirstString(matchField, searchStr))
      {
         ABTValue id = refCur.getField(FLD_ID);
         cursorSetField(cur, idField, id);
      }
      else
         processError("setGlobalID",
                errorMessages.ERR_RECORD_NOT_FOUND,
                matchField + " '" + searchStr + "' is not found in " + refCur.getTableName());

   }
   else
      processError("setGlobalID",
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  refObjName + " not found in " + obj.getObjectType());

}


/**
 * checks if an external id exists in the cursor.
 * @param cur     the cursor.
 * @param extID   the external id to check.
 * @return true if it does, false if it doesn't.
 */
   protected boolean extIDExistsInCursor(ABTCursor cur, String extID)
   {
      cur.setSort(table_ + "." + FLD_EXTERNALID);
   	if ( cur.bsearchFirst(FLD_EXTERNALID, new ABTString(extID)) )
   	   return true;
      else
         return false;
   }


/**
 *    finds object in the object space. first match by remote id. if not found,
 *    match by external id or name.
 *    @param type       the type of object to find
 *    @param matchField the name of the field to match on (i.e., prExternaID or prName)
 *                      if remote id is not found.
 *    @param id         the prID value of the object
 *    @param cur        the cursor used to get external id (or name) based on prID
 *    @return     the object found or null if not found.
 *    @exception  ABTException if error occurred.
 */
protected ABTValue findObject(String type, String matchField, int id, ABTCursor cur) throws ABTException
{
   // find object in the object space. first match by remote id.
   int repoID = repo_.getID();
   ABTRemoteIDRepository rmtID = new ABTRemoteIDRepository(repoID, id);
   ABTValue val = find(type, rmtID);

   if (val instanceof ABTObject)
      // return the object found
      return val;
   else
   {
      // if not found, match by external id
      // get external id from the cursor
      if (cur.bsearchFirstInt(FLD_ID, id))
      {
         ABTString searchStr = (ABTString) cur.getField(matchField);

         // NOTE: this findObject() method uses indexes to look up the space 
         // (for faster access) therefore it works only for those that are unique 
         // in the space and the property to be searched against has an index 
         // created during object creation.
         val = getSpace().findObject( getUserSession(), type,
                                      matchField.substring(2), searchStr );

         // If findObject() did not return an error and did not return null and
         // is an ABTObject, the desired object was found in the space
         if (!ABTError.isError(val) && !ABTValue.isNull(val) && (val instanceof ABTObject))
            return (ABTObject)val;
         else
            processError("findObject",
                errorMessages.ERR_OBJECT_NOT_FOUND,
                type + " object not found in object space. " + matchField + " = " + searchStr );
      }
      else
         processError("findObject",
                errorMessages.ERR_RECORD_NOT_FOUND,
                "prID '" + id + "' is not found in " + cur.getTableName());
   }
   return null;
}


//====================================================================================
// The following abstract methods must be implemented in the classes that extend this
// abstract class.
//====================================================================================

/**
 * Select a cursor from the repository for "populate".
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected abstract ABTCursor getCursorForPopulate() throws ABTException;

/**
 * Select a cursor from the repository for "save".
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected abstract ABTCursor getCursorForSave() throws ABTException;

}