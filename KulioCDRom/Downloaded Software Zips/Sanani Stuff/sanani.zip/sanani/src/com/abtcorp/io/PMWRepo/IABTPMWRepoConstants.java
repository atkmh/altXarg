package com.abtcorp.io.PMWRepo;

/*
 * IABTPMWRepoConstants.java 04/29/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 07-17-98    SOB             Initial Implementation
  * 08-11-98    SOB             Mods to support new public driver API
  * 10-30-98    SOB             Mods to QRY_PROJECTDEPENDENCIES for interproject dependencies
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

/**
 *  IABTPMWRepoConstants is a Java interface for specifying constants for the PMWRepo components.
 *
 *
 * @version	    $Revision: 25$
 * @author		 S. Bursch
 * @see         ABTPMWRepoDriver
 */


public interface IABTPMWRepoConstants
{
 	//
 	// Project locking-related strings
 	//
 	public static final String PM_NOTLOCKED = "NOT LOCKED".intern();
 	public static final String PM_UNKNOWNLOCKER = "UNKNOWN".intern();
 	
 	//
 	// Strings used by the public driver API when interrogating ABTHashtable input
 	// parameters and arguments.
 	//
 	// possible populate() method ABTHashtable parms
 	//
 	public static final String PM_PROJECTEXTID = "ProjectExtID".intern();            // this parm is required
 	public static final String PM_ACQUIREEXPORTLOCK = "AcquireExportLock".intern();

 	//
 	// possible save() method ABTHashtable parms
 	//
 	public static final String PM_PROJECTOBJ = "ProjectObject".intern();
 	public static final String PM_PROJECTSET = "ProjectSet".intern();
 	public static final String PM_SAVEAS = "SaveAs".intern();

   //
   // possible parms that can be input both to populate() and save()
   //
 	public static final String PM_REPONAME = "RepositoryName".intern();

   //
   // possible lock conditions for projects
   //
   public static final int LOCK_ACQUIRED = 1;
   public static final int LOCK_ALREADY_HELD = 2;

 	//
 	// populate() input ABTHashtable arg constant equivalents
 	//
 	public static final int PM_UNKNOWN = 0;         // this is also used by execute()
 	public static final int PM_GETPROJECTFULL = 1;
 	public static final int PM_PROJECTONLY = 3;
 	public static final int PM_PROJECTANDTASKSONLY = 4;
 	public static final int PM_PROJECTANDCUSTFIELDSONLY = 5; /* #613 */

 	//
 	// execute() input ABTHashtable arg constant equivalents
 	//
 	public static final int PM_LISTPROJECTS =                   1;
 	public static final int PM_UNLOCK =                         2;
 	public static final int PM_FILTER_PROJECTS_BY_TASK =        3; /* #613 */
 	public static final int PM_FILTER_PROJECTS_BY_CRITERIA =    4; /* #613 */
 	public static final int PM_GET_TASK_ESTIMATES =             5; /* #613 */
 	public static final int PM_GET_USER_NAME =                  6; /* #657 */
 	public static final int PM_GET_PROJECT_ESTIMATES =          7; /* #613 */
 	
 	//
 	// Define pass constants for the save process.
 	//
 	public static final int PASS_ONE = 1;
 	public static final int PASS_TWO = 2;

 	//
 	// Table names not found in ABTNames.
 	//

   public static final String TBL_PREDTASK = "PRPredTask".intern();
   public static final String TBL_SUCCTASK = "PRSuccTask".intern();
   //public static final String TBL_MRPREDTASK = "MRPredTask".intern();
   //public static final String TBL_MRSUCCTASK = "MRSuccTask".intern();

   //
   // SQL queries used to populate objects in the object space.  Some of these queries
   // are patterned after those in PRNAMES.H in the PVision code.
   //
   public static final String QRY_PROJECT = "select * from PRProject where prExternalID = ";
   public static final String QRY_PROJECTASSIGNMENTS = "SELECT PRAssignment.*, " +
                              "PRTask.prWBSSequence, " +
                              "PRTask.prID, " +
                              "PRTeam.prID " +
                              "FROM PRAssignment, PRTask, PRTeam " +
                              "WHERE PRTask.prID=PRAssignment.prTaskID AND " +
                              "PRTeam.prResourceID=PRAssignment.prResourceID";
   public static final String QRY_PROJECTDEPENDENCIES	= "SELECT PRDependency.*, " +
                              "PRPredTask.prWBSSequence, " +
                              "PRSuccTask.prWBSSequence " +
                              "FROM PRDependency, PRTask PRPredTask, PRTask PRSuccTask " +
                              "WHERE PRPredTask.prID=PRDependency.prPredTaskID AND " +
                              "PRSuccTask.prID=PRDependency.prSuccTaskID";
   public static final String QRY_PROJECTSUBPROJECTS = "SELECT PRSubproject.*, " +
                              "PRTask.prWBSSequence " +
                              "FROM PRSubproject, PRTask " +
                              "WHERE PRTask.prID=PRSubproject.prTaskID";
   public static final String QRY_PROJECTCONSTRAINTS = "SELECT PRConstraint.* " +
                              "FROM PRConstraint, PRTask " +
                              "WHERE PRTask.prID=PRConstraint.prTaskID ";
   public static final String QRY_PROJECTESTMODEL = "SELECT PREstModel.* " +
                              "FROM PREstModel ";
   public static final String QRY_TASKESTIMATES = "SELECT PRTaskEstimate.* " +
                              "FROM PRTaskEstimate, PRTask, PREstModel " +
                              "WHERE PRTaskEstimate.prTaskID = PRTask.prID AND " +
                              "PRTaskEstimate.prEstModelID = PREstModel.prID ";
   public static final String QRY_TASKCUSTFIELDVALUES = "SELECT PRCustFieldValue.* " +
                              "FROM PRCustFieldValue, PRTask, PRProject " +
                              "WHERE PRCustFieldValue.prTableName = 'PRTask' AND " +
                              "PRCustFieldValue.prRecordID = prTask.prID ";
   public static final String QRY_TASKDELIVLINK = "SELECT PRTaskDelivLink.* " +
                              "FROM PRTaskDelivLink, PRTask " +
                              "WHERE PRTaskDelivLink.prTaskID = PRTask.prID ";
   public static final String QRY_PROJECTRESOURCES = "SELECT PRResource.* " +
                              "FROM PRResource, PRTeam ";
   public static final String QRY_SUBPROJECTHACK = "SELECT prID " +
                              "FROM PRProject ";
   public static final String QRY_SUBPROJECTTASK = "SELECT prID " +
                              "FROM PRTask ";
   //
   //NOTE:  The following 4 notes-related queries are incomplete.  They all require
   //       that a project prID be appended to them.
   //

   public static final String QRY_PROJECTNOTES = "SELECT * FROM PRNote " +
                              "WHERE prTableName='PRProject' AND " +
                              "prRecordID=";
   public static final String QRY_TASKNOTES = "SELECT PRNote.* FROM PRNote, PRTask " +
                              "WHERE PRNote.prTableName='PRTask' AND " +
                              "PRNote.prRecordID=PRTask.prID AND " +
                              "PRTask.prProjectID=";
   public static final String QRY_ASSIGNMENTNOTES = "SELECT PRNote.* " +
                              "FROM PRNote, PRAssignment, PRTask " +
                              "WHERE PRNote.prTableName='PRAssignment' AND " +
                              "PRNote.prRecordID=PRAssignment.prID AND " +
                              "PRAssignment.prTaskID=PRTask.prID AND " +
                              "PRTask.prProjectID=";

   public static final String QRY_TASKSET = "select * from PRTask where prProjectID = ";
   public static final String ORDERBY_WBSSEQUENCE = " order by prWBSSequence";
   public static final String ORDERBY_ID = " order by prID";

   public static final String LOCK_SELECT = "select * from PRProject where prExternalID = ";
   public static final String RESOURCE_SELECT = "select prID, prExternalID from PRResource";
   public static final String USER_SELECT = "select prID, prName from PRUser where prID = ";
   
   public static final String PROJECTS_BY_TASK = "select PRProject.prExternalID " +  /* #613 */
                                                 "from PRProject, PRTask " +
                                                 "where PRTask.prProjectID = PRProject.prID ";
   
   public static final String GET_TASK_ESTIMATES_QRY0 = "select PRTask.prWBSSequence, PRTask.prWBSLevel " + /* #613 */
                                                        "from PRTask " ;
   //
   // The following SQL queries use "GROUP BY".  The code which uses the queries builds up the SQL statement
   // incrementally prior to execution.
   //
   public static final String MINSEQ = "MinSeq".intern();
   public static final String EXPR1  = "Expr1".intern();
   public static final String GET_TASKESTIMATES_QRY1A = "select PRTask.prProjectID, min(PRTask.prWBSSequence) as " + MINSEQ + " " + /* #613 */
                                                        "from PRTask " +
                                                        "where PRTask.prWBSSequence > ";  // append QRY0.prWBSSequence here
   public static final String GET_TASKESTIMATES_QRY1B = " and PRTask.prWBSLevel <= ";     // append QRY0.prWBSLevel here
   public static final String GET_TASKESTIMATES_QRY1C = " and PRTask.prProjectID = ";     // append QRY0.prProjectID here
   public static final String GET_TASKESTIMATES_QRY1D = " group by PRTask.prProjectID";
   
   public static final String GET_TASKESTIMATES_QRY2A = "select PRTask.prProjectID, sum(prActSum + prEstSum) as " + EXPR1 + " " + /* #613 */
                                                        "from PRTask, PRAssignment " +
                                                        "where PRTask.prID = PRAssignment.prTaskID";
   public static final String GET_TASKESTIMATES_QRY2B = " and PRTask.prWBSSequence >= ";  // append QRY0.prWBSSequence here
   public static final String GET_TASKESTIMATES_QRY2C = " and PRTask.prWBSSequence < ";   // append QRY1.MinSeq here
   public static final String GET_TASKESTIMATES_QRY2D = " and PRTask.prProjectID = ";     // append QRY0.prProjectID here
   public static final String GET_TASKESTIMATES_QRY2E = " group by PRTask.prProjectID";
   
   public static final String GET_PROJECTESTIMATES_QRY1A = "select PRTask.prProjectID, " +   /* #613 */ 
                                                           "sum(PRAssignment.prActSum + PRAssignment.prEstSum) as " + EXPR1 + " " +
                                                           "from PRTask, PRAssignment " +
                                                           "where PRTask.prID = PRAssignment.prTaskID " +
                                                           "and PRTask.prProjectID = ";
   public static final String GET_PROJECTESTIMATES_QRY1B = " group by PRTask.prProjectID";
   
   public static final String ACTUALS = "Actuals".intern();
   public static final String TOTAL   = "Total".intern();
   public static final String FILTER_BY_CRITERIA = "select PRProject.prExternalID, sum(PRAssignment.prActSum) as " + ACTUALS + ", " +
                                                   "sum(PRAssignment.prActSum + PRAssignment.prEstSum) as " + TOTAL + " " +
                                                   "from PRAssignment, PRTask, PRProject " +
                                                   "where PRTask.prID = PRAssignment.prTaskID and " +
                                                   "PRProject.prID = PRTask.prProjectID " +
                                                   "group by PRProject.prExternalID";

//--------------------------------------------------------------------------------------------
// Useful ABTError constants
//--------------------------------------------------------------------------------------------

   
}