/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;
import com.abtcorp.core.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

//
//
// ABTCursorCOM
//
//

public class ABTCursorCOM implements IABTCursorCOM
{
   public ABTCursorCOM(ABTCursor c)
     {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(c);
      /**/
     }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   
   private ABTCursor _curs;
   private ABTCursor curs() {
      if (_curs == null)
         _curs = (ABTCursor)getObject();
      return _curs;
      }

  public IABTRepositoryCOM getRepository()
     {return new ABTRepositoryCOM(curs().getRepository()); }

  public String getTableName()
     {return curs().getTableName();}

  public boolean isValid()
     {return curs().isValid();}

  public int getRecordCount()
     {return curs().getRecordCount();}

  public int getCurrentRecord()
     {return curs().getCurrentRecord();}

  public String getFilter()
     {return curs().getFilter();}

  public void setFilter(String pVal)
     {curs().setFilter(pVal) ;}

  public String getSort()
     {return curs().getSort();}

  public void setSort(String pVal)
     {curs().setSort(pVal) ;}

  public void addSort(String strSort)
     {curs().addSort(strSort) ;}

  public void SetAndFilter(String FilterString)
     {curs().andFilter(FilterString);}

  public void SetOrFilter(String FilterString)
     {curs().orFilter(FilterString);}

  public void SortBy(String Field)
     {curs().sort(Field,true);}

  public void Refresh()
     {curs().refresh();}

  public void addNew()
     {curs().addNew();}

  public void Edit()
     {curs().edit() ;}

  public void Update()
     {curs().update();}

  public void Cancel()
     {curs().cancel() ;}

  public boolean Delete()
     {return curs().delete();}

  public void DeleteAll()
     {curs().deleteAll();}

  public boolean Drop()
     {return curs().drop();}

  public int CheckLock(String Name, boolean bval)
     {return curs().checkLock(Name, bval);}

  public int LockRecord(String Name, boolean bval)
     {return curs().lock(Name, bval);}

  public int UnlockRecord(String Name)
     {return curs().unlock(Name);}

  public int Procedure(String str)
     {return curs().procedure(str);}

  public boolean Move(int MoveType, int Offset)
     {return curs().move(MoveType, Offset);}

  public boolean Search(String Field, Variant Value, int SearchType)
     {return false;}

  public boolean BinarySearch(String Field, Variant Value, int SearchType)
     {return false;}

  public void setField(String Field, Variant Value)
     {
     curs().setField(Field, VariantMunger.VariantToValue(Value));
     }

  public Variant getField(String Field)
     {
     ABTValue val = curs().getField(Field);
     Variant V = VariantMunger.ValueToVariant(val);
     return V;
     }

  public boolean IsFieldNull(String Field)
     {return curs().isFieldNull(Field);}

  public Variant getCursorTime()
     {return new Variant(curs().getCursorTime());}
}

