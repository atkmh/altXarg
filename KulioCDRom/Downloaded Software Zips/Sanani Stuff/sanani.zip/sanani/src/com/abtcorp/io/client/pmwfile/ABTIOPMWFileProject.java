package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileProject.java 07/14/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 07-17-98    MXA         Initial Implementation
 *
 *
 */
import java.io.File;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
//DEBUG
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.io.client.ABTObjectSetIDList;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;


import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.io.client.ABTFileHelper;
//import com.abtcorp.io.client.pmwfile.ABTPMWFileTask;

/**
 * ABTIOPMWFileProject is a helper class for the ABT PMW Local File driver.
 * It is instantiated by the ABT PMW Local File Driver.
 *
 *  <pre>
 *       ABTIOPMWFileProject fp = new ABTIOPMWFileProject(ABTIOPMWFileDriver driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 M. Abadian
 */

public class ABTIOPMWFileProject extends ABTIOPMWFileHelper implements IABTPMRuleConstants,IABTRuleConstants,IABTIOPMWFileConstants
{

//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTIOPMWFileHelper constructor.
 * @param driver: the reference to the driver.
 */
   ABTIOPMWFileProject(ABTIOPMWFileDriver driver)
   {
     super(driver);
     type_ = OBJ_PROJECT;
   }

//====================================================================================
// Populate Project from the Intermediate Hash Table
//====================================================================================

 /**
 * Populate the project
 * @param parms (currently not used)
 * @return an ABTValue the project which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(IABTLocalID projectId) throws ABTException
   {
      IABTArray projArr = null;
      IABTPropertySet propSet = null;

      System.out.println("PROJECT Populate:");

      //Get the array of value associated with project
      //IABTLocalID projectId = driver_.getProjectId();
      if ( projectId != null)
        projArr = (IABTArray)driver_.intermediateTableGet(projectId);
      else
        new ABTError(getClass(),
                     "populate",
                     errorMessages.ERR_PROJ_ID_NULL,
                     null);

      propSet = getProperties(type_);

      //Get the remote ID associated with the project
      ABTValue  val = null;
      val = getHashValue(projArr, propSet, PROP_REMOTEID);

      //Create the project Object
      IABTObject project = null;
      if (ABTValue.isNull(val))
        project = createObject(type_,(ABTRemoteID)null, null);
      else if (val instanceof ABTRemoteID)
        project = createObject(type_,(ABTRemoteID)val, null);
      else
        new ABTException(" WRONG TYPE CAST");

      //Check to see if it was not created earlier

      driver_.lookupTablePut(projectId, project);

      //Set Project's scalar values.
      setScalarValues(propSet, projArr, project);

      //Populate Project's Team.
      ABTValue teamVal = null;
      //TO DO Check to see if team is null
      teamVal = getHashValue(projArr, propSet, OFD_TEAMRESOURCES);

      Hashtable reqTeamParms = new Hashtable();
      reqTeamParms.put(OFD_PROJECT, project);
      if (teamVal == null)
        reqTeamParms.put(OFD_TEAMRESOURCES,OFD_TEAMRESOURCES);
      else
        reqTeamParms.put(OFD_TEAMRESOURCES,teamVal);

      ABTIOPMWFileTeam teamHelper = new ABTIOPMWFileTeam(driver_);
      teamHelper.populate(reqTeamParms);

      //Populate  Project's Estimating Model
      Hashtable reqEstModelParms      = new Hashtable();
      ABTValue estModelVal = null;
      estModelVal = getHashValue(projArr, propSet, OFD_ESTMODELS);
      reqEstModelParms.put(OFD_PROJECT,   project);
      if (estModelVal == null)
        reqEstModelParms.put(OFD_ESTMODELS, OFD_ESTMODELS);
      else
        reqEstModelParms.put(OFD_ESTMODELS, estModelVal);

      ABTIOPMWFileEstimatingModel estModelHelper = new ABTIOPMWFileEstimatingModel(driver_);
      estModelHelper.populate(reqEstModelParms);

      //Populate project's Custom Field Value
      ABTValue custfieldVal = null;
      custfieldVal = getHashValue(projArr, propSet, OFD_CUSTFIELDVALUES);
      if (custfieldVal != null)
      {
        ABTIOPMWFileCustomFieldValue custfieldHelper = new ABTIOPMWFileCustomFieldValue(driver_);
        Hashtable reqCustfieldParms = new Hashtable();
        reqCustfieldParms.put(OFD_PROJECT,     project     );
        reqCustfieldParms.put(CUSTOMFIELD_ID,  custfieldVal);
        reqCustfieldParms.put(TARGET_OBJ,      project     );
        custfieldHelper.populate(reqCustfieldParms);
      }

      //Populate Project's tasks
      Hashtable reqTaskParms         = new Hashtable();
      IABTLocalID firstChildTaskID   = null;
      IABTLocalID lastChildTaskID     = null;
      ABTObjectSetIDList allTaskIDs  = null;

      val = null;
      val = getHashValue(projArr, propSet, OFD_FIRSTCHILDTASK);
      if (val instanceof IABTLocalID)
        firstChildTaskID = (IABTLocalID) val;

      val = null;
      val = getHashValue(projArr, propSet, OFD_LASTCHILDTASK);
      if (val instanceof IABTLocalID)
        lastChildTaskID = (IABTLocalID) val;
      val = null;
      val = getHashValue(projArr, propSet, OFD_ALLTASKS);
      if (val instanceof ABTObjectSetIDList)
        allTaskIDs = (ABTObjectSetIDList) val;

      if(firstChildTaskID!=null &&   lastChildTaskID!=null && allTaskIDs != null)
      {
        reqTaskParms.put(TASK_ID,            firstChildTaskID );
        reqTaskParms.put(OFD_PROJECT,        project          );
        reqTaskParms.put(PARENT_OBJ,         PARENT_OBJ       ); //A trick to pass null as a parent
        reqTaskParms.put(PARENTLASTCHILD_ID, lastChildTaskID  );
        reqTaskParms.put(ALLTASK_ID,         allTaskIDs       );

        ABTIOPMWFileTask taskHelper = new ABTIOPMWFileTask(driver_);
        taskHelper.populate(reqTaskParms);
      }

      //Populate Project's notes
      ABTValue  noteVal = null;
      noteVal = getHashValue(projArr, propSet, OFD_NOTES);

      ABTIOPMWFileNote noteHelper = new ABTIOPMWFileNote(driver_);

      Hashtable reqNoteParms = new Hashtable();
      reqNoteParms.put(OFD_PROJECT,project);

      if (noteVal == null)
        reqNoteParms.put(OFD_NOTES,OFD_NOTES);
      else
        reqNoteParms.put(OFD_NOTES,noteVal);

      reqNoteParms.put(TARGET_OBJ, project);

      noteHelper.populate(reqNoteParms);

      //Populate  Project's SubProjectLink
      Hashtable reqSubProjectLinkParms = new Hashtable();
      ABTValue subProjectLinkVal = null;
      subProjectLinkVal = getHashValue(projArr, propSet, OFD_SUBPROJECTLINKS);
      reqSubProjectLinkParms.put(OFD_PROJECT,   project);
      if (subProjectLinkVal == null)
        reqSubProjectLinkParms.put(OFD_SUBPROJECTLINKS, OFD_SUBPROJECTLINKS);
      else
        reqSubProjectLinkParms.put(OFD_SUBPROJECTLINKS, subProjectLinkVal);

      ABTIOPMWFileSubProject subProjectHelper = new ABTIOPMWFileSubProject(driver_);
      subProjectHelper.populate(reqSubProjectLinkParms);

      return (ABTValue)project;
   }

//====================================================================================
// Save Project to an Intermediate Hash Table
//====================================================================================

/**
 * Saves the project in a file
 * @param Hashtable parms
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
        IABTObject  project   = null;
        IABTLocalID projectId = null;
        IABTArray   arr       = null;

        //Get the project object
        Object object = null;
        object = parms.get(PROJECT_OBJ);
        if (object == PROJECT_OBJ)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        //Get the project ID
        object = null;
        object = parms.get(PROJECT_ID);
        if (object == PROJECT_ID)
            projectId = null;
        if (object instanceof IABTLocalID)
            projectId = (IABTLocalID)object;

       // Make sure the curProject is a project
       if (!project.getObjectType().equals(type_))
            processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

       // Load the values of the properties associated with the project in an array
       arr = loadObjectPropertyValues(project);

      // IABTLocalID projectId = project.getID();
      // if (projectId == null)
      //      throw new ABTException("The ID is null.");

       if ( driver_.isIntermediateTableNull() )
        throw new ABTException("The intermediate Hash table is null");

       //driver_.setProjectId(projectId);

       Object Element = driver_.intermediateTablePut(projectId, arr);
    //   if ( Element != null)
    //        throw new ABTException("The ID already exist.");

       //First import the resources
       ABTIOPMWFileResource resHelper = new  ABTIOPMWFileResource(driver_);
       Hashtable         resparms       = new Hashtable();
       resparms.put(OFD_PROJECT,project);
       resHelper.save(resparms);



       //DEBUG
       /*
       System.out.println("PROJECT ");
       IABTPropertySet propset = null;
       propset = getProperties(type_);
       printProperties(propset, arr);
       */
       //DEBUG

        //Now import the tasks
        ABTIOPMWFileTask taskHelper = new ABTIOPMWFileTask(driver_);
        ABTValue tasks = getValue(project, OFD_ALLTASKS);
        Hashtable reqTaskParms = new Hashtable();
        reqTaskParms.put(OFD_PROJECT, project);
        if (tasks instanceof IABTObjectSet)
            reqTaskParms.put(ALLTASK_OBJ, (IABTObjectSet) tasks);
        else if (tasks == null)
            reqTaskParms.put(ALLTASK_OBJ, ALLTASK_OBJ);
        else
            processError(SEVERITY_ONE, "", "", EXC_TASK_OSET_NOT_FOUND);
        taskHelper.save(reqTaskParms);

        //Now import the team
        ABTIOPMWFileTeam teamHelper = new ABTIOPMWFileTeam(driver_);
        Hashtable reqTeamParms = new Hashtable();
        reqTeamParms.put(OFD_PROJECT, project);
        teamHelper.save(reqTeamParms);

        //Now import the assignments
        ABTIOPMWFileAssignment assignmentHelper = new ABTIOPMWFileAssignment(driver_);
        Hashtable reqAssgnParms = new Hashtable();
        reqAssgnParms.put(OFD_PROJECT, project);
        assignmentHelper.save(reqAssgnParms);

        //Now import the Estimating Models
        ABTIOPMWFileEstimatingModel estModelHelper = new ABTIOPMWFileEstimatingModel(driver_);
        Hashtable reqEstModelParms      = new Hashtable();
        reqEstModelParms.put(OFD_PROJECT,   project);

        estModelHelper.save(reqEstModelParms);

        //Now import the Dependencies
        ABTIOPMWFileDependency dependencyHelper = new ABTIOPMWFileDependency(driver_);
        Hashtable reqDepParms = new Hashtable();
        reqDepParms.put(OFD_PROJECT, project);
        dependencyHelper.save(reqDepParms);

        //Now import the Constraints
        ABTIOPMWFileConstraint constraintHelper = new ABTIOPMWFileConstraint(driver_);
        Hashtable reqConstraintParms = new Hashtable();
        reqConstraintParms.put(OFD_PROJECT, project);
        constraintHelper.save(reqConstraintParms);

        //Now import the Custom Fields
        ABTIOPMWFileCustomFieldValue CustFieldHelper = new ABTIOPMWFileCustomFieldValue(driver_);
        Hashtable reqCustfieldParms = new Hashtable();
        reqCustfieldParms.put(OFD_PROJECT, project);
        CustFieldHelper.save(reqCustfieldParms);

        //Now import the Deliverables
        ABTIOPMWFileDeliverable deliverableHelper = new ABTIOPMWFileDeliverable(driver_);
        Hashtable reqDeliverableParms = new Hashtable();
        reqDeliverableParms.put(OFD_PROJECT, project);
        deliverableHelper.save(reqDeliverableParms);

        //Now import the TaskEstimate
        ABTIOPMWFileTaskEstimate  taskEstimateHelper = new ABTIOPMWFileTaskEstimate(driver_);
        Hashtable reqTaskEstParms = new Hashtable();
        reqTaskEstParms.put(OFD_PROJECT, project);
        taskEstimateHelper.save(reqTaskEstParms);

         //Now import the SubProjects
        ABTIOPMWFileSubProject  subProjectHelper = new ABTIOPMWFileSubProject(driver_);
        Hashtable reqSubProjParms = new Hashtable();
        reqSubProjParms.put(OFD_PROJECT, project);
        subProjectHelper.save(reqSubProjParms);

        //Now import the Notes
        ABTIOPMWFileNote  NoteHelper = new ABTIOPMWFileNote(driver_);
        Hashtable reqNoteParms = new Hashtable();
        reqNoteParms.put(OFD_PROJECT,project);
        NoteHelper.save(reqNoteParms);
   }
   catch (ABTException e)
   {
       throw new ABTException(e.getMessage());
   }
   finally
   {
   }


 }


 }