package com.abtcorp.io.team.connect.data;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;

public class TypeCodeData extends SimpleData
{
   public TypeCodeData(ABTObject object, ABTUserSession session)
   {
      super(object, session);
   }

}
