package com.abtcorp.io.client.sitefile;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_WRONG_CAST.getCode(),"Wrong Cast"},
{ERR_EXPECTED_IABTHashTable.getCode(),"Expected IABTHashTable"},
{ERR_EXPECTED_IABTLocalID.getCode(),"Expected IABTLocallID"},
{ERR_INVALID_TYPE.getCode(),"The type is not supported "},
{ERR_EXCEPTION_OCCURED.getCode(),"An Exception has occured"},
{ERR_EXPECTED_IABTObject.getCode(),"Expected IABTObject"},

 };
}