package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoPackageMember.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-16-98    LZX         Initial Implementation
 * 07-10-98    LZX         Support transactions
 * 07-23-98    LZX         Add reference to the package object
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTIOMethRepoPackageMember is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTIOMethRepoPage object.
 *
 *  <pre>
 *       ABTIOMethRepoPackageMember rt = new ABTIOMethRepoPackageMember(
 *                                              driver,
 *                                              package,
 *                                              taskHash,
 *                                              delivHash);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTIOMethRepoPage
 */

public class ABTIOMethRepoPackageMember extends ABTIOMethRepoHelper 
{

   private Hashtable taskHash_ = null;
   private Hashtable delivHash_ = null;
   private Hashtable packHash_ = null;
   private ABTObject method_ = null;

/**
 *    ABTIOMethRepoPackageMember constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the package object that owns the package members.
 */
   ABTIOMethRepoPackageMember(ABTMMRepoDriver driver, ABTObject parent, Hashtable taskHash, Hashtable delivHash, Hashtable packHash)
   {
      super(driver, parent, TBL_MRPACKAGECONTENT, OBJ_MM_PACKAGEMEMBER);
      method_ = parent;
      taskHash_ = taskHash;
      delivHash_ = delivHash;
      packHash_ = packHash;
      component_ = "ABTIOMethRepoPackageMember";
   }


/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {      
      // reset the req parm hashtable everytime since to prevent "left-over" items
      if (reqParams_ != null)
         reqParams_.clear();

      // get package from the hash table.
      ABTObject obj = getObjectFromHash(cursor_, FLD_PACKAGEID, packHash_, OBJ_MM_PACKAGE);
      reqParams_.putItemByString(OFD_PACKAGE, obj);

      // Set a reference to the associated task, deliverable or child package object
      // depending on the table name. 
      String tblName = new String(cursor_.getFieldString(FLD_TABLENAME));
      if (tblName.equalsIgnoreCase(TBL_MRTASK))
      {
      	// find associated task from the hash table
         obj = getObjectFromHash(cursor_, FLD_RECORDID, taskHash_, OBJ_MM_TASK);
         reqParams_.putItemByString(OFD_TASK, obj);
      }
      else if (tblName.equalsIgnoreCase(TBL_MRDELIVERABLE))
      {
      	// find associated deliverable from the hash table
         obj = getObjectFromHash(cursor_, FLD_RECORDID, delivHash_, OBJ_MM_DELIVERABLE);
         reqParams_.putItemByString(OFD_DELIVERABLE, obj);
      }
      else if (tblName.equalsIgnoreCase(TBL_MRPACKAGE))
      {
      	// find associated package from the hash table
         obj = getObjectFromHash(cursor_, FLD_RECORDID, packHash_, OBJ_MM_PACKAGE);
         reqParams_.putItemByString(OFD_SUBPACKAGE, obj);
      }
      else 
         processError("create", 
                     errorMessages.ERR_INVALID_TABLE, 
                     "prID = " + id.getPrID() + ", table name = " + tblName);

      return (super.create(type, id, reqParams_));
   }

/**
 * Sets cursor values and updates the repository.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// first set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);
		
		if (isNew)
		{
	   	// for new records, get package id from the page object and set it in the cursor.
   		setIDFromObject(cur, obj, OFD_PACKAGE, FLD_PACKAGEID);
   		
         // retrieve the id from either task, deliverable or subpackage object
         // and set it in the record id field in the package member cursor
         
         // is task present?
      	ABTValue val = getValue(obj, OFD_TASK);
         if ((val instanceof ABTObject) && !ABTValue.isNull(val))
         {
            cursorSetField(cur, FLD_TABLENAME, new ABTString(TBL_MRTASK));
            cursorSetField(cur, FLD_RECORDID, getValue((ABTObject)val, OFD_ID));
            return;
         }
                  
         // task is not present, is deliverable present?
         val = getValue(obj, OFD_DELIVERABLE);
         if ((val instanceof ABTObject) && !ABTValue.isNull(val))
         {
            cursorSetField(cur, FLD_TABLENAME, new ABTString(TBL_MRDELIVERABLE));
            cursorSetField(cur, FLD_RECORDID, getValue((ABTObject)val, OFD_ID));
            return;
         }
         
         // deliverable is not present, is subpackage present?
         val = getValue(obj, OFD_SUBPACKAGE);
         if ((val instanceof ABTObject) && !ABTValue.isNull(val))
         {
            cursorSetField(cur, FLD_TABLENAME, new ABTString(TBL_MRPACKAGE));
            cursorSetField(cur, FLD_RECORDID, getValue((ABTObject)val, OFD_ID));
            return;
         }
   
   		// no task, deliverable or subpackage is present. throw an exception.
         processError("setCursorValues", 
                  errorMessages.ERR_OBJECT_NOT_FOUND, 
                  "No task, deliverable or subpackage object not found for package member.");
      }
   }
   

/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      // prPackageID, prTableName and prRecordID can not be modified after add-new
      if (!isNew &&
         (prapiName.equals(FLD_PACKAGEID) ||
          prapiName.equals(FLD_TABLENAME) ||
          prapiName.equals(FLD_RECORDID)))
         return true;
         
      return super.isSaveException(prapiName, obj, prapiFlags, isNew);            
   }


/**
 * Select cursor from the repository for populate.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForPopulate() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODPACKAGEMEMBERS + id ));
   }

/**
 * Select cursor from the repository for save.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForSave() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODPACKAGEMEMBERS + id));
   }
}