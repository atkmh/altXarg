package com.abtcorp.core;

import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.util.Locale;

public class ABTProgressReport extends ABTValue
{
    public final static int STATUS_STARTING    = 100;
    public final static int STATUS_WORKING     = 101;
    public final static int STATUS_FINISHED    = 102;
    public final static int STATUS_USER_ABORTED= 103;
    public final static int STATUS_ERROR       = 104;

    public final static int INFO_STRING        = 200;
    public final static int INFO_PERCENT       = 201;
    public final static int INFO_COUNT         = 202;
    public final static int INFO_NULL          = 203;

    protected boolean isSynchronous;
    protected String myPackage;
    protected String component;
    protected int code;
    protected int infoType;
    protected int status;
    protected ABTValue info;
    protected String message;

    public ABTProgressReport(String package_,
                             String component_,
                             int code_,
                             int status_,
                             int type_,
                             ABTValue info_){
        myPackage  = package_;
        component  = component_;        
        code       = code_;
        status     = status_;
        infoType   = type_;
        info       = info_;

        message    = null;
        }

    public ABTProgressReport(Class component_,
                             int code_,
                             int status_,
                             int type_,
                             ABTValue info_){
      String packg;
      String comp;

      String cName = component_.getName();
      int lastDot = cName.lastIndexOf('.');
      if (lastDot > 0){
         packg = cName.substring(0,lastDot);
         comp = cName.substring(lastDot+1,cName.length());
         }
      else{
         packg = "";
         comp = cName;
         }

      myPackage  = packg;
      component  = comp;
      code       = code_;
      status     = status_;
      info       = info_;
      message    = null;
     }

    public void setSynchronous( boolean b) {isSynchronous = b; }
    public int getStatus(){ return status; }
    public int getType(){ return infoType; }
    public boolean isSynchronous(){ return isSynchronous;}
    public ABTValue getInfo(){return info;}
    public void setInfo(ABTValue info_) { info = info_; }

    public String getMessage(){
      if (message == null)
         message = getLocalizedMessage(Locale.US);
      return message;
      }
      
    public String getLocalizedMessage(Locale locale_){
      String fullPath = myPackage+"."+component;
      return lookupMessage(fullPath, code, locale_);
      }
      
    protected String lookupMessage( String component_, int code_, Locale locale_){
      Locale myLocale;
      String codeString = new Integer(code_).toString();

      if (locale_ == null)
         myLocale = locale_;
      else
         myLocale = Locale.US;
      String packagename = component_;
      int lastDot = packagename.lastIndexOf('.');
      if (lastDot > 0)
         packagename = packagename.substring(0,lastDot);
      else
         // no resource, just return the code string
         return codeString;
      ResourceBundle messages = null;
      String themessage = null;
      try{
         messages = ResourceBundle.getBundle(packagename+".statusMessages",myLocale);
         return messages.getString(codeString);
         }

      catch(MissingResourceException e){
         // didn't find a resource bundle in the callers package
         // or didn't find the message in the resource bundle
         try {
            messages = ResourceBundle.getBundle("com.abtcorp.core.statusMessages",myLocale);
            return messages.getString(codeString);
            }
         catch(MissingResourceException e2){
            // There isn't a root resource bundle either.  I give up.
            return codeString;
            }
         }
      }
}