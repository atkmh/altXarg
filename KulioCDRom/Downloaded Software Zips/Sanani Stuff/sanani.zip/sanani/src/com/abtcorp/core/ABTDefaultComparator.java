/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTDefaultComparator.java, 9, 12/8/98 9:48:19 AM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

/**
 * ABTDefaultComparator is an implementation of the ABTComparator interface. It will order
 * elements of type ABTComparable using the natural order. This comparator should only be
 * used to compare objects of type ABTComparable such as ABTValue.
 *
 * @version    $Revision: 9$, $Date: 12/8/98 9:48:19 AM$
 * @author     $Author: Benoit Menendez$
 *
 * @see        com.abtcorp.core.ABTComparator
 * @see        com.abtcorp.core.ABTComparable
 * @see        com.abtcorp.core.ABTValue
 *
 */

import java.io.Serializable;

public class ABTDefaultComparator implements ABTComparator, Serializable
{
  private static final long serialVersionUID = -8091894394144841161L;   
/**
 * Default (empty) constructor
 */
 
   public ABTDefaultComparator() {}

/**
 * This method compares two ABTComparables.
 *
 * Like all ABTComparator implementations, this method will also ensure that null elements
 * are always before non null elements in the order.
 *
 * @return  a negative integer, zero, or a positive integer as the
 * 	      first argument is less than, equal to, or greater than the
 *	         second. 
 */
 
   public int compare(Object object1, Object object2)
   {
      if (object1 == null && object2 == null) return 0;
      if (object1 == null)                    return -1;
      if (object2 == null)                    return +1;
      
      return ((ABTComparable)object1).compareTo(object2);
   }
}