package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileDependency.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;

import java.util.Hashtable;

//DEBUG
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTObjectSetIDList;

/**
 *  ABTIOPMWFileDependency is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileDependency fd = new ABTIOPMWFileDependency(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileDependency extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       dependencyVector_ = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 *    ABTIOPMWFileDependency constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileDependency(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_              = OBJ_DEPENDENCY;
      dependencyVector_  = new Vector();
   }

//====================================================================================
// Populate  Dependency from the Intermediate Hash Table
//====================================================================================

/**
 * Populate  Dependency  object from the Intermediate Hash Table to the sapce
 * @param Hashtable parms,
 * @return an ABTValue the team object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue populate(Hashtable parms) throws ABTException
   {
    ABTObjectSetIDList DependencyIDs   = null;
    Object             object          = null;

    try
     {

        //Get the Dependency IDs
        object = parms.get(DEPENDENCIES_ID);
        if (object instanceof ABTObjectSetIDList)
            DependencyIDs  = (ABTObjectSetIDList)object;

        Enumeration itID = DependencyIDs.getActiveIDs();
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            Object obj = itID.nextElement();
            if (obj instanceof IABTLocalID)
                reqparms.put(DEPENDENCIES_ID,(IABTLocalID)obj);
            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }
   }

/**
 * Create a new object in the object space and initialize it with  appropriate values
 * @param Hashtable parms
 * @return ABTValue the newly created dependency
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {

      IABTLocalID dependencyID    = null;
      IABTObject project          = null;
      IABTObject targetObj        = null;
      Object     object           = null;
      IABTObject dependencyObj    = null;
      ABTValue   val              = null;
      //Get the Dependency ID
      object = null;
      object = parms.get(DEPENDENCIES_ID);
      if (object instanceof IABTLocalID)
         dependencyID  = (IABTLocalID)object;

      //Check if Dependency has already been created
      object = null;
      object = driver_.lookupTableGet(dependencyID);
      if ( object!= null && object instanceof IABTObject)
      {
         // TO DO UPDATE
           ;
      }
      else
      {

          // Get the array of value associated with Dependency
          IABTArray   dependencyArr  = null;
          object = null;

          object = driver_.intermediateTableGet(dependencyID);
          if (object instanceof IABTArray)
            dependencyArr = (IABTArray) object;

          //Get the property set associated with the Dependency
          IABTPropertySet propSet = null;
          propSet = getProperties(type_);

          //Get Associated Predecessor Task
          val = null;
          IABTLocalID predTaskID = null;
          IABTObject predTaskObj = null;
          object = null;

          val = getHashValue(dependencyArr, propSet, OFD_PREDTASK);
          if (val instanceof IABTLocalID)
             predTaskID  = (IABTLocalID)val;

          object = driver_.lookupTableGet(predTaskID);
          if ( object != null && object instanceof IABTObject )
            predTaskObj = (IABTObject)object;
          else
            throw new ABTException("Dependency CREATE: PREDECESSOR TASK is not valid");

          //Get Associated Successor Task
          val = null;
          IABTLocalID succTaskID = null;
          IABTObject succTaskObj = null;
          object = null;

          val = getHashValue(dependencyArr, propSet, OFD_SUCCTASK);
          if (val instanceof IABTLocalID)
             succTaskID  = (IABTLocalID)val;


          object = driver_.lookupTableGet(succTaskID);
          if ( object != null && object instanceof IABTObject )
            succTaskObj = (IABTObject)object;
          else
            throw new ABTException("Dependency CREATE: SUCCESSOR TASK is not valid");


          // Get the required parameter to create Dependency Object
          IABTHashTable  reqparms       = (getSpace()).newABTHashTable();
          reqparms.putItemByString(OFD_PREDTASK, (ABTValue)predTaskObj);
          reqparms.putItemByString(OFD_SUCCTASK, (ABTValue)succTaskObj);

          //Get Dependency's Remote ID
          val = null;

          val = getHashValue(dependencyArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            dependencyObj = createObject(type_,(ABTRemoteID)val, reqparms);                       
          else if (ABTValue.isNull(val)) 
            dependencyObj = createObject(type_,(ABTRemoteID)null, reqparms);
          else
            new ABTException(" WRONG TYPE CAST");


          //Set Dependency's scalar values.
          setScalarValues(propSet, dependencyArr, dependencyObj);
    }
    driver_.lookupTablePut(dependencyID, dependencyObj);
    return (ABTValue)dependencyObj;
   }

//====================================================================================
// Save Dependency to an Intermediate Hash Table
//====================================================================================

/**
 * Saves dependency objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
        IABTObject project = null;

        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        IABTObjectSet dependencyOs = getObjectSet(project, OFD_ALLDEPENDENCIES);
        int size = size(dependencyOs);
        for (int i =0; i < size; i++)
        {
            IABTObject  dependencyObj     = (IABTObject)at(dependencyOs, i);

            // Make sure the object is of type dependency
            if (!dependencyObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the dependency in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(dependencyObj);
            if (arr==null)
                throw new ABTException("The arr of dependency values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID dependencyId = dependencyObj.getID();
            if (dependencyId == null)
                throw new ABTException("dependency ID is null.");

            driver_.intermediateTablePut(dependencyId, arr);
            //if (( driver_.intermediateTablePut(dependencyId, arr)) != null)
            //    throw new ABTException("The dependency ID already exist.");

            //DEBUG
            dependencyVector_.addElement(dependencyId);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }

}