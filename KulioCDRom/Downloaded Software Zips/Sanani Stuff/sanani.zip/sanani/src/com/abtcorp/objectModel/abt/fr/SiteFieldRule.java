package  com.abtcorp.objectModel.abt.fr;


/*
 * PMFieldRule.java 07/31/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author         Description
 * 06-03-98       JSE         Initial Design
 * 09-17-98       SOB         Mods to use objectModel.pm.IABTPMRuleConstants
 *
 */

import   java.util.*;
import java.net.URL;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.*;

/**
 * This is a field rule that performs only default behavior
 *
 * @version	1.0
 * @author  Scott Ellis
 */

public class SiteFieldRule extends ABTFieldRule implements com.abtcorp.objectModel.abt.IABTRuleConstants
{

   /**
    * Return the site calendar object
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The current value of the property
    * @param parameters - list of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue getSite( ABTUserSession session, String property)
   {
      try
      {
          ABTObjectSet os = (ABTObjectSet) _space.getObjects( session, OBJ_SITE);
          ABTObject site = (ABTObject)(os.at(session,0));
          if (property != null)
             return site.getValue( session, property /*OFD_CALENDAR*/ );
          else
             return site;
      }
      catch (Exception e)
      {
          return new ABTError("SiteFieldRule",
            "GetSite",
            errorMessages.ERR_SITE_ACCESS,
            e);
      }

   }
   /**
    * Default Constructor, calls PMFieldRules' default constructor
    */
   public SiteFieldRule()
   {
      super();
   }

//+++++++++++++++
// Getters
//+++++++++++++++

   /**
    * Default onGet, which just returns the passed in value unmodified
    * VALID FOR ALL property types
    *
    * @param session    session object for transaction support
    * @param parent     the container object for this field property
    * @param property   the property object
    * @param myValue    the current value of the property
    * @param parameters list of parameters and (field/app specific)
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    */
   protected ABTValue onGet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters )
   {
      return myValue;
   }

//+++++++++++++++
// validators
//+++++++++++++++

   /**
    * Default 'would this be a valid value?'- returns true
    *
    * @param session    session object for transaction support
    * @param parent     the container object for this field property
    * @param property   the property object
    * @param myValue    the current value of the property
    * @param parameters list of parameters and (field/app specific)
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    */
   protected ABTValue isValid( ABTUserSession session, ABTObject parent, ABTValue myValue, ABTHashtable parameters )
   {
      return ABTBoolean.True();
   }

//+++++++++++++++
// validators
//+++++++++++++++

   /**
    * Modification/Verification of property keys
    *
    * @param session       session object for transaction support
    * @param parent        the container object for this field property
    * @param myProperty    the ABTProperty object
    * @param key           the key in the property (e.g. PROP_KVISIBLE)
    * @param defaultValue  the default for the property key
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    *
    * @see com.abtcorp.IABTPROPERTYTYPES
    */
   protected ABTValue onPropertyKey( ABTUserSession session, ABTObject parent, ABTProperty myProperty, int key, ABTValue defaultValue )
   {
      return defaultValue;
   }

//++++++++++++++++++++
// Setters / modifiers
//++++++++++++++++++++

   /**
    * Default onInitialize for setting /modifying additional values
    *
    * @param session    the current user session handle
    * @param object     ABTObject to be initialized
    * @param property   property to be set
    * @param myValue    the current default value
    * @param parameters list of required parameters
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTProperty property, ABTValue myValue, ABTHashtable requiredParameters )
   {
      return myValue;
   }

   /**
    * Default onSet for modification of a position within an object.
    *
    * @param session    session object for transaction support
    * @param parent     the container object for this field property
    * @param property   the property object
    * @param myValue    the value currently available i.e. the ABTObject at this position
    * @param newValue   the new value, i.e. the ABTObject to be placed instead
    * @param parameters list of parameters and (field/app specific)
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      return write( session, parent, property, myValue, newValue, false );
   }

// NOTIFICATIONS

   /**
    * Notification of an add operation to an objectset stored in this property.
    * If used set notifyAdd in rule constructor  to true.
    *
    * @param session    session object for transaction support
    * @param parent     the container object for this field property
    * @param property   the property object
    * @param child      the objectset currently referenced in this property
    * @param newValue   the new value
    * @param existing   true if the passed in new Value is an existing ABTObject
    *                   , false if it was initialized to default values
    *
    * @return Returns null if the operation is not allowed, ABTError if it is rejected.
    */
   protected ABTError notifyReferenceAdd( ABTUserSession session, ABTObject parent, ABTProperty property, ABTObjectSet child, ABTValue newValue, boolean existing, boolean dirty )
   {
      return null;
   }

   /**
    * Notification of a remove operation in an objectset stored in this property.
    * If used set notifyRemove in rule constructor to true.
    *
    * @param session       session object for transaction support
    * @param parent        the container object for this field property
    * @param property      the property object
    * @param child         the objectset currently referenced in this property
    * @param removedValue  the value being removed from the objectset
    *
    * @return Returns null if allowed, ABTError if it is rejected.
    */
   protected ABTError notifyReferenceRemove( ABTUserSession session, ABTObject parent, ABTProperty property, ABTObjectSet child, ABTValue removedValue , boolean dirty)
   {
      return null;
   }

   /**
    * Notification of a remove operation in an objectset stored in this property.
    * If used set notifyClear in rule constructor to true.
    *
    * @param session       session object for transaction support
    * @param parent        the container object for this field property
    * @param property      the property object
    * @param child         the objectset currently referenced in this property
    *
    * @return Returns null if allowed, ABTError if it is rejected.
    */
   protected ABTError notifyReferenceClear( ABTUserSession session, ABTObject parent, ABTProperty property, ABTObjectSet child , boolean dirty)
   {
      return null;
   }

   /**
    * Notification of a set operation in an element of the objectset stored in this property.
    * If used set notifyChildSet in rule constructor to true.
    *
    * @param session       session object for transaction support
    * @param parent        the container object for this field property
    * @param property      the property object
    * @param childSet      the objectset currently referenced in this property
    * @param child         the object in the childset which was modified
    * @param childProperty the property modified
    * @param oldValue      the old value in the child property
    * @param newValue      the new value in the child property
    *
    * @return Returns null if allowed, ABTError if it is rejected.
    */
   protected ABTError notifyReferenceChildSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTObjectSet childSet, ABTObject child, ABTProperty childProperty, ABTValue oldValue, ABTValue newValue , boolean dirty)
   {
      return null;
   }

   /**
    * Notification of a set operation in an element of the objectset stored in this property.
    * If used set  notifySet in rule constructor to true.
    *
    * @param session       session object for transaction support
    * @param parent        the container object for this field property
    * @param property      the property object
    * @param child         the object currently referenced in this property
    * @param childProperty the property modified
    * @param oldValue      the old value in the child property
    * @param newValue      the new value in the child property
    *
    * @return Returns null if allowed, ABTError if it is rejected.
    */
   protected ABTError notifyReferenceSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTObject child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue, boolean dirty )
   {
      return null;
   }

   /**
    * Notification of a delete operation on an object referenced in this property.
    *
    * @param session       session object for transaction support
    * @param parent        the container object for this field property
    * @param property      the property object
    * @param child         the object currently referenced in this property
    *
    * @return Returns null if allowed, ABTError if it is rejected.
    */
   protected ABTError notifyReferenceDelete( ABTUserSession session, ABTObject parent, ABTProperty property, ABTObject child , boolean dirty)
   {
      return null;
   }

      protected ABTValue getUnitOfMeasure( ABTUserSession session,
                                     ABTObject parent,
                                     ABTValue myValue,
                                     ABTHashtable parameters)
   {

      ABTObject resource = null;
      ABTHashtable parms = parameters;
      if (parms == null)
         parms = new ABTHashtable();

      // get the resource unit:
      ABTValue v = parent.getValue(session,OFD_RESOURCE, parms);
      if (ABTError.isError(v))
         return v;
      if (!(ABTValue.isNull(v)))
      {
         resource = (ABTObject)v;
      }
      return getUnitOfMeasure( session,
                               parent,
                               myValue,
                               resource,
                               parms);

    }

    /**
    * convert a given value into the appropriate unit of measure
    * <ul>
    *	<li> If unit of measure is hours and Resource.Unit is hours or days
    *	<li> 		Result.scaleRate(1/3600) // for curves
    *	<li> 		Result /= 3600 // for doubles
    *	<li> Else If unit of measure is days and Resource.Unit is hours or days
    *	<li> 		Result.scaleRate(1/(3600*Site.Calendar.HoursPerDay()) // for curves
    *	<li> 		Result /= (3600*Site.Calendar.HoursPerDay()) // for doubles
    *	<li> 	Else If unit of measure is quantity and Resource.Unit is quantity
    *	<li> 		// do nothing
    *	<li> 	Else If unit of measure is cost
    *	<li> 		Result.scaleRate(Resource.Rate) // for curves
    *	<li> 		Result *= Resource.Rate // for doubles
    *	<li> 	Else
    *	<li> 		Result = null
    * <ul>
    * <li> possible values:
    * <li>   "Days" - kDays  0
    * <li>   "Hours" - kHours 1
    * <li>   "Cost"; - kCost   2
    * <li>   "Quantity"; - kQuantity  3
    * </ul>
    * <ul>
    * <li> exceptions:
    * <li> unit = -1 : return myValue
    * <li> resource not found : convert the current value into the given unit
    *
    * </ul>
    *
    * @param session    session object for transaction support
    * @param parent     the container project object for this field property
    * @param value      the value to convert
    * @param parameters requried hashtable carrying unit, resource and site
    * @return ABTValue. Returns ABTValue if successful (probably an ABTCurve), ABTError if not.
    */
   protected ABTValue getUnitOfMeasure( ABTUserSession session,
                                     ABTObject parent,
                                     ABTValue myValue,
                                     ABTObject resource,
                                     ABTHashtable parameters)
   {
      ABTCalendar siteCalendar = null;

      double rate = 0;
      short unit;
      short mUnit = -1;
      short rUnit = -1;

      ABTHashtable parms = parameters;
      if (parms == null)
         parms = new ABTHashtable();

      ABTValue v = parms.get(new ABTString(OFD_UNIT));
      if (!(ABTValue.isNull(v)))
         mUnit = v.shortValue();

         if (!(ABTValue.isNull(resource)))
         {
            v = resource.getValue(session,OFD_RATE,parms);
            if ((!(ABTError.isError(v))) && (!(ABTValue.isNull(v))))
               rate = v.doubleValue();
            v = resource.getValue(session,OFD_UNIT,parms);
            if ((!(ABTError.isError(v))) && (!(ABTValue.isNull(v))))
            {
               rUnit = v.shortValue();
               if (mUnit < 0)
               {
      /*569*/      v = parms.get(new ABTString(OFD_RESOURCE));
      /*569*/      if  ((!(ABTValue.isNull(v))) && (v.booleanValue()))
      /*569*/      {
      /*569*/           mUnit = rUnit;
      /*569*/      }

               }
           }
         }
      if (mUnit < 0)
         return myValue;

      v = parms.get(new ABTString(OFD_CALENDAR));
      if (!(ABTValue.isNull(v)))
         siteCalendar = (ABTCalendar)v;
      else
      {
         v = getSite(session,OFD_CALENDAR);
         if (ABTError.isError(v))
            return v;
         siteCalendar = (ABTCalendar)v;
         parms.put(new ABTString(OFD_CALENDAR),siteCalendar);
      }


      if (myValue instanceof ABTDouble)
      {
         double d = myValue.doubleValue();

         switch (mUnit)
         {
            case kDays :
                  double hoursPerDay = siteCalendar.getHoursPerDay();
                  if (hoursPerDay == 0)
                     hoursPerDay = 24;
                  if (rUnit <= kHours)
                     return new ABTDouble(d/ (3600*hoursPerDay));
                  else
                     return null;
            case kHours:
                  if (rUnit <= kHours)
                     return new ABTDouble(d/3600);
                  else
                     return null;
            case kCost :
                     return new ABTDouble(d * rate);
            case kQuantity :
                  if (rUnit == kQuantity)
                     return myValue;
                  else
                     return null;
            default:
               return myValue;
         }
      }
      if (myValue instanceof ABTCurve)
      {
/*#582*/         ABTCurve c = (ABTCurve)((ABTCurve)myValue).clone();
         switch (mUnit)
         {
            case kDays :
                  double hoursPerDay = siteCalendar.getHoursPerDay();
                  if (hoursPerDay == 0)
                     hoursPerDay = 24;
                  if (rUnit <= kHours)
                  {
                     c.scaleRate(1.0 / (3600.0 * hoursPerDay));
                     return c;
                  }
                  else
                     return null;
            case kHours:
                  if (rUnit <= kHours)
                  {
                     c.scaleRate(1.0 / 3600.0);
                     return c;
                  }
                  else
                     return null;
            case kCost :
                  c.scaleRate(rate);
                  return c;
            case kQuantity :
                  if (rUnit == kQuantity)
                     return c;
                  else
                     return null;
            default:
               return c;
         }
      }
      return null;
   }

    /**
    * revert above operation #571
   */
   protected ABTValue setUnitOfMeasure( ABTUserSession session,
                                     ABTObject parent,
                                     ABTValue myValue,
                                     ABTHashtable parameters)
   {

      ABTHashtable parms = parameters;
      if (parms == null)
         parms = new ABTHashtable();

      ABTObject resource = null;
      // get the resource unit:
      ABTValue v = parent.getValue(session,OFD_RESOURCE,parms);
      if (ABTError.isError(v))
         return v;
      if (!(ABTValue.isNull(v)))
      {
         resource = (ABTObject)v;
      }
      return setUnitOfMeasure( session,
                               parent,
                               myValue,
                               resource,
                               parms);

    }

    /**
    * revert above operation #571
    * <ul>
    *	<li> If unit of measure is hours and Resource.Unit is hours or days
    *	<li> 		Result.scaleRate(3600) // for curves
    *	<li> 		Result *= 3600 // for doubles
    *	<li> Else If unit of measure is days and Resource.Unit is hours or days
    *	<li> 		Result.scaleRate(1/(3600*Site.Calendar.HoursPerDay()) // for curves
    *	<li> 		Result *= (3600*Site.Calendar.HoursPerDay()) // for doubles
    *	<li> 	Else If unit of measure is quantity and Resource.Unit is quantity
    *	<li> 		// do nothing
    *	<li> 	Else If unit of measure is cost
    *	<li> 		Result.scaleRate(Resource.Rate) // for curves
    *	<li> 		Result /= Resource.Rate // for doubles
    *	<li> 	Else
    *	<li> 		Result = null
    * <ul>
    * <li> possible values:
    * <li>   "Days" - kDays  0
    * <li>   "Hours" - kHours 1
    * <li>   "Cost"; - kCost   2
    * <li>   "Quantity"; - kQuantity  3
    * </ul>
    * <ul>
    * <li> exceptions:
    * <li> unit = -1 : return myValue
    * <li> resource not found : convert the current value into the given unit
    *
    * </ul>
    *
    * @param session    session object for transaction support
    * @param parent     the container project object for this field property
    * @param value      the value to convert
    * @param parameters requried hashtable carrying unit, resource and site
    * @return ABTValue. Returns ABTValue if successful (probably an ABTCurve), ABTError if not.
    */
   protected ABTValue setUnitOfMeasure( ABTUserSession session,
                                     ABTObject parent,
                                     ABTValue myValue,
                                     ABTObject resource,
                                     ABTHashtable parameters)
   {
      ABTCalendar siteCalendar = null;

      ABTHashtable parms = parameters;
      if (parms == null)
         parms = new ABTHashtable();

      double rate = 0;
      short unit;
      short mUnit = -1;
      short rUnit = -1;



      ABTValue v = parms.get(new ABTString(OFD_UNIT));
      if (!(ABTValue.isNull(v)))
         mUnit = v.shortValue();

         if (!(ABTValue.isNull(resource)))
         {
            v = resource.getValue(session,OFD_RATE,parms);
            if ((!(ABTError.isError(v))) && (!(ABTValue.isNull(v))))
               rate = v.doubleValue();
            v = resource.getValue(session,OFD_UNIT,parms);
            if ((!(ABTError.isError(v))) && (!(ABTValue.isNull(v))))
            {
               rUnit = v.shortValue();
               if (mUnit < 0)
               {
      /*569*/      v = parms.get(new ABTString(OFD_RESOURCE));
      /*569*/      if  ((!(ABTValue.isNull(v))) && (v.booleanValue()))
      /*569*/      {
      /*569*/           mUnit = rUnit;
      /*569*/      }

               }
           }
         }
      if (mUnit < 0)
         return myValue;

      v = parms.get(new ABTString(OFD_CALENDAR));
      if (!(ABTValue.isNull(v)))
         siteCalendar = (ABTCalendar)v;
      else
      {
         v = getSite(session,OFD_CALENDAR);
         if (ABTError.isError(v))
            return v;
         siteCalendar = (ABTCalendar)v;
         parms.put(new ABTString(OFD_CALENDAR),siteCalendar);
      }


      if (myValue instanceof ABTDouble)
      {
         double d = myValue.doubleValue();

         switch (mUnit)
         {
            case kDays :
                  double hoursPerDay = siteCalendar.getHoursPerDay();
                  if (hoursPerDay == 0)
                     hoursPerDay = 24;
                  if (rUnit <= kHours)
                     return new ABTDouble(d *  3600 * hoursPerDay);
                  else
                     return null;
            case kHours:
                  if (rUnit <= kHours)
                     return new ABTDouble(d * 3600);
                  else
                     return null;
            case kCost :
                     return new ABTDouble(d / rate);
            case kQuantity :
                  if (rUnit == kQuantity)
                     return myValue;
                  else
                     return null;
            default:
               return myValue;
         }
      }
      if (myValue instanceof ABTCurve)
      {
         ABTCurve c = (ABTCurve)myValue;
         switch (mUnit)
         {
            case kDays :
                  double hoursPerDay = siteCalendar.getHoursPerDay();
                  if (hoursPerDay == 0)
                     hoursPerDay = 24;
                  if (rUnit <= kHours)
                  {
                     c.scaleRate(1.0 * 3600.0 * hoursPerDay);
                     return c;
                  }
                  else
                     return null;
            case kHours:
                  if (rUnit <= kHours)
                  {
                     c.scaleRate(1.0 *  3600.0);
                     return c;
                  }
                  else
                     return null;
            case kCost :
                  c.scaleRate(1.0/rate);
                  return c;
            case kQuantity :
                  if (rUnit == kQuantity)
                     return myValue;
                  else
                     return null;
            default:
               return myValue;
         }
      }
      return null;
   }




}
