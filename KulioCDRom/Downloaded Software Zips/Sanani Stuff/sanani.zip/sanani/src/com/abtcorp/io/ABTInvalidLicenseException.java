package com.abtcorp.io;

import com.abtcorp.core.ABTException;

public class ABTInvalidLicenseException extends ABTException
{
   public ABTInvalidLicenseException(String s) {super(s);}
   // TODO: Localization issue with the exception message!
   public ABTInvalidLicenseException() {super("Invalid product license");}
}
