/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;

import com.abtcorp.blob.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;


public class ABTArrayCOM implements IABTArrayCOM
   {
//   public ABTArrayCOM() { this( new com.abtcorp.api.local.ABTArrayLocal()); }
   public ABTArrayCOM(IABTArray array) {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base   = new ABTBaseJavaCOM(array);
      /**/
      }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private IABTArray _ar;
   private IABTArray ar() {
      if (_ar == null) _ar = (IABTArray)getObject(); 
      return _ar;
      }

   public IABTObjectSpaceCOM getObjectSpace(){
      IABTHashTable ht = (IABTHashTable)getObject();
      IABTObjectSpace os = ar().getObjectSpace();
      return new ABTObjectSpaceCOM(os);
      }

   public class ArrayEnumerator implements IEnumVariant,IABTEnumeratorCOM
     {
      IABTEnumerator _en;
      IABTArray _os;

      public ArrayEnumerator(IABTArray os)
         {
         _os = os;
         _en = _os.getElements();
         }

      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }
      public Variant nextElement()
         { return VariantMunger.ValueToVariant(_en.nextValue());  }

      public void Skip(int n) {
         while (n-- > 0 && _en.hasMoreElements()) {
            _en.nextElement(); }
         }
      public void Reset() 
         { _en = _os.getElements();  }
      public IEnumVariant Clone()
         { return new ArrayEnumerator(_os); }

      public void Next(int n, Variant[]v, int[]pfetched) {
         pfetched[0] = 0;
         try {
            while (n-- > 0 && _en.hasMoreElements()){
               v[(pfetched[0])++] = nextElement();
               }
            }
         catch (Exception e){throw new com.ms.com.ComFailException(e.getMessage()); }
         }
     }


   public IUnknown get_NewEnum() { return new ArrayEnumerator(ar()); }

   public IABTEnumeratorCOM getElements()
      { return new ArrayEnumerator(ar()); }

   public int getCount()   { return ar().size(); }
   public int size()   { return ar().size(); }

   public Variant get(int Index)  {
      return VariantMunger.ValueToVariant((ABTValue)ar().get(Index));
      }

   // Note: this is the method a COM client would use to add to the array
   // Java clients should add to the contained ABTArray
   public Variant add( Variant newObj )  {
      ABTValue _val = VariantMunger.VariantToValue(newObj);
      ABTValue V1 = (ABTValue)ar().add(_val);
      return VariantMunger.ValueToVariant(V1);
      }
}