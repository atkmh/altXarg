/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.hub.ABTID;
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.api.*;
import java.io.InputStream;
import java.io.ObjectInputStream;

import java.awt.*;

public class ABTObjectSpaceLocal extends ABTSessionObject implements IABTObjectSpace
{
   //*********************************************/
   //* This private class starts a debug monitor */
   //* window on another thread                  */
   //*********************************************/
   class DebugMonitorThread extends Thread {
      private IABTAPIMonitor myMonitor;
      private ABTSessionObject host;
      public DebugMonitorThread(ABTSessionObject _host) {   host = _host;	}
      public synchronized void run() {
         try {
            host.setMonitor(null);  /* clear it out first */
            Class vf = Class.forName("com.abtcorp.tools.SpaceView.ViewerFrame");
            IABTAPIMonitor frame = (IABTAPIMonitor)vf.newInstance();
            /* if we got a healthy monitor frame, bind it to the host */
            host.setMonitor(frame); 
            }
         catch(Throwable e){
            host.setMonitor(null);  /* make sure the host doesn't have a sick monitor */
            }
         }
      }
   //*********************************************/
   //*********************************************/

   public ABTObjectSpaceLocal() {
      super(new com.abtcorp.hub.ABTObjectSpace());
      }

   protected ABTObjectSpaceLocal(ABTSessionObject s) {
      super(s,s.getHubObjectSpace());
      }

   private com.abtcorp.hub.ABTObjectSpace _space;
   private com.abtcorp.hub.ABTObjectSpace space() {
      if (_space == null) _space = (com.abtcorp.hub.ABTObjectSpace)getObject();
      return _space;
      }

   /**
   * add a listener
   * @param Listener - caller
   * @param target - listen to
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
    public synchronized void  addListener(int action,  IABTListener Listener, IABTObject target, int parameterindex_)
      {
//      ListenerProxy pxy = new ListenerProxy(this, Listener);
//      space().addListener(pxy,(ABTObject)target.getObject(),parameterindex_);
      }

   /**
   * remove a particular listener 
   * @param Listener - caller
   * @param target - listen to or null for all
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   public synchronized void removeListener(IABTListener Listener, IABTObject target, int parameterindex_)
      {
//      space().removeListener((ListenerProxy)Listener.getProxy(),(ABTObject)target.getObject(),parameterindex_);
      }

   /**
   * remove a particular target from the listener list
   * @param target - object to be removed
   */
   public synchronized void removeListenedTo(IABTObject target)
      {
      space().removeListenedTo((com.abtcorp.hub.ABTObject)target);
      }

 /**
 * Get the propertySet for a given ObjectType
 * @param type  - name of type
 * @return ABTPropertySet - properties for this object or null for error
 */
 public synchronized IABTPropertySet getProperties(String type)
 {
   ABTPropertySetLocal psl = new ABTPropertySetLocal(this,space().getProperties(type));
   return psl;
 }

 /**
 * Get the current classpath for rule objects (e.g. ABTTask)
  * @return String - current path to rule objects
  */
 public synchronized String getRulebase()
 {
   return space().getRulebase();
 }


/**
* get the extension for all abtobjects created (e.g. 
*  ABTObjectCOM, ABTObjectSetCOM
*  @return String ObjectExtension 
*/
public synchronized String getExtension()
{
   return space().getExtension();
}

/**
* get the class Path for all abtobjects created 
*  @return String - path to ABTObjects
*/
public synchronized String getObjectPath()
{
   return space().getObjectPath();
}

 /**
 *  loads a rule if necessary and attempts to add the property 
 *  to it
 *  @param rule name of rule to load (e.g. 'pm.Task')
 *  @param name_ - name of property
 *  @param caption_ - caption of property
 *  @param type_  valid type of property
 *  @param virtual_ true if property does not occupy physical storage
 *  @param visible_ true if this property can be retrieved
 *  @param updatable_ true if this property is updatable
 *  @param transient_ true if this property is transient
 *  @param referenceType_ name of Rule if this property is an objectSet/Object
 *  @param propertyRule_ name of property-rule file or null if no specific rules
 *  @return ABTError - or null if none
 * ToDo:  
 */
   public synchronized ABTError addProperty(  String rule_,
                                 String name_,
                                 String caption_,
                                 int type_,
                                 boolean virtual_,
                                 boolean visible_,
                                 boolean updatable_,
                                 boolean transient_,
                                 String referenceType,
                                 String propertyRule,
                                 ABTValue defaultValue
                                 )
   {

   String rType;
   String pRule;
   if (referenceType != null && referenceType.length() == 0)
      rType = null;
   else
      rType = referenceType;

   if (propertyRule != null && propertyRule.length() == 0)
      pRule = null;
   else
      pRule = propertyRule;

   return space().addProperty(rule_,
                            name_,
                            caption_,
                            type_,
                            virtual_,
                            visible_,
                            updatable_,
                            transient_,
                            rType,
                            pRule,
                            (ABTValue)ValueMunger.MarshalIn(this, defaultValue));
   }

 public synchronized ABTValue createObject(String type, ABTRemoteID id, IABTHashTable requiredParameters)
 {
   ABTHashtable Args = null;
   ABTHashTable hT = null;
   if (requiredParameters != null) {
      hT = (ABTHashTable)requiredParameters;
      Args = (ABTHashtable)hT.getObject();
      }

   ABTValue val = ValueMunger.MarshalOut(this,space().createObject(getUserSession(),type,id,Args));

   /* if there's a debug monitor, tell it that an object just got created */
   try{
      IABTAPIMonitor mon = getMonitor();
      if (mon != null && (val instanceof IABTObject))
            mon.OnClientCreateObject((IABTObject)val);
      }
   catch (Throwable e)// The debug monitor threw an exception.  Stop trusting it
      { setMonitor(null); }

   return val;  
 }

 public synchronized ABTValue createNewObject(String type, IABTHashTable requiredParameters)
 {
   ABTHashtable Args = null;
   ABTHashTable hT = null;
   if (requiredParameters != null) {
      hT = (ABTHashTable)requiredParameters;
      Args = (ABTHashtable)hT.getObject();
      }
   ABTValue val = ValueMunger.MarshalOut(this,space().createObject((ABTUserSession)getUserSession(),type,null,Args));

   /* if there's a debug monitor, tell it that an object just got created */
   try{
      IABTAPIMonitor mon = getMonitor();
      if (mon != null && (val instanceof IABTObject))
            mon.OnClientCreateObject((IABTObject)val);
      }
   catch (Throwable e)// The debug monitor threw an exception.  Stop trusting it
      { setMonitor(null); }

   return val;
 }
 
public synchronized ABTValue createNewObjectSet( String type)
   {
   return ValueMunger.MarshalOut(this,space().createObjectSet((ABTUserSession)getUserSession(),type));
   }

 public synchronized ABTValue getObjects(String subType)
 {
   return ValueMunger.MarshalOut(this,space().getObjects((ABTUserSession)getUserSession(),subType));
 }

 public synchronized ABTValue findObject(  String subType, String expression) {
   return ValueMunger.MarshalOut(this,space().findObject(getUserSession(),subType, expression));
   }

 public ABTValue findObjectByID(  String subType,IABTLocalID localID) {
   ABTLocalID lid = (ABTLocalID)localID;
   ABTID id = (ABTID)lid.getObject();
   return ValueMunger.MarshalOut(this,space().findObject((ABTUserSession)getUserSession(),subType, id));
   }

 public synchronized ABTValue findObjectByRemoteID( String subType, ABTRemoteID id){
   return ValueMunger.MarshalOut(this,space().findObject(getUserSession(),subType,id));
    }


 public synchronized ABTError startSession(IABTHashTable sessionIdentifiers) {
   ABTHashtable ht = null;
   if (sessionIdentifiers != null) {
      ABTHashTable hT = (ABTHashTable)sessionIdentifiers;
      ht = (ABTHashtable)hT.getObject();
      }
   ABTUserSession us = space().startSession(ht);
   setUserSession(us);

   
   if (sessionIdentifiers != null && sessionIdentifiers.containsKey(new ABTString("ShowMonitor")) == true )
      {
      ABTValue showit = sessionIdentifiers.getItemByString("ShowMonitor");
      if (showit.booleanValue() == true){
         showMonitor(true);
         }
      }

   return null;
   }

   public synchronized void showMonitor(boolean val){
      if (getMonitor() != null) return;
      //**************************************/
      //* try to start a debug monitor       */
      //**************************************/
      DebugMonitorThread monitor = new DebugMonitorThread(this);
      monitor.start();
      }


 public synchronized ABTError endSession() {
   IABTAPIMonitor mon = getMonitor();
   if (mon != null){
      // there is a debug monitor open, close it
      mon.close();
      setMonitor(null);
      }
   space().endSession(getUserSession());
   setUserSession((ABTUserSession)null);
   return null;
   }

   public synchronized ABTError startTransaction() { 
      return getUserSession().startTransaction();
      }

   public synchronized ABTError commitTransaction(){
      return getUserSession().commitTransaction();
      }

   public synchronized ABTError rollbackTransaction(){
      return getUserSession().rollbackTransaction();
      }


   // API layer helper methods
   public IABTArray       newABTArray(){
      return new ABTArrayLocal(this);
      }

   public IABTSortedArray newABTSortedArray(){
      return new ABTSortedArrayLocal(this);
      }

   public IABTSortedArray newABTSortedArray(ABTComparator comp){
      return new ABTSortedArrayLocal(this, comp);
      }

   public IABTHashTable   newABTHashTable(){
      return new ABTHashTable(this);
      }

   public IABTHashTable   newABTHashTable(int initialCapacity, float loadFactor){
      return new ABTHashTable(initialCapacity,loadFactor);
      }

   public IABTHashTable   newABTHashTable(java.io.ObjectInputStream in){
      try{
         ABTHashTable table = (ABTHashTable)in.readObject();
         table.setObjectSpace(this);
         return table;
         }
      catch (Exception e){
         return null;
         }
      }

   public IABTDriver      newABTDriver(){
      return new ABTDriverLocal(this);
      }

   public IABTDriver      newABTDriver(String className, IABTHashTable args){
      ABTDriverLocal dvr = new ABTDriverLocal(this);
      dvr.initialize(className, args);
      return dvr;
      }

}
