package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;

import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTProperty;

public class AssignmentData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public AssignmentData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_ASSIGNMENT) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         if (property.getName().equals(FLD_TW_CREATED)) continue;

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            // Task is saved as the id to the task.
            if (property.getName().equals(FLD_TW_TASK) || property.getName().equals(FLD_TW_TASKID)) {

               ABTValue object = object_.getValue(session_,FLD_TW_TASK);
               if (ABTError.isError(object) || ABTEmpty.isEmpty(object)) continue;
               
               try {
                  table.put(property.getName(),((ABTObject)object).getValue(session_,FLD_TW_INTERNALID,null));
               } catch (Exception exception) {
               }
            } else if (property.getName().equals(FLD_TW_RESOURCEID)) {
               ABTValue resourceid = object_.getValue(session_,FLD_TW_RESOURCEID,null);
               if (resourceid != null && !ABTEmpty.isEmpty(resourceid) && !ABTError.isError(resourceid)) {
                  String selection = FLD_TW_ID + " = " + resourceid.intValue();
                  ABTObjectSpace space = object_.getRule().getObjectSpace();
                  ABTValue temp = space.findObject(session_,OBJ_TW_RESOURCE,selection);
                  if (temp instanceof ABTObjectSet) {
                     try {
                        ABTObject resource = (ABTObject)((ABTObjectSet)temp).at(session_,0);
                        table.put(property.getName(),resource.getValue(session_,FLD_TW_INTERNALID,null));
                     } catch (Exception exception) {
                        exception.printStackTrace();
                     }
                  }
               }
            } else table.put(property.getName(),value);
         }
      }
      return table;
   }
}
