package com.abtcorp.io.team.connect;

import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.TimeSheetPopulator;
import com.abtcorp.io.team.RemoteID;
import com.abtcorp.io.team.ObjectIDSortedArray;
import com.abtcorp.io.team.TWObjectComparator;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.idl.IABTPropertyType;


import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ConnectTimeSheetPopulator extends TimeSheetPopulator implements TWRepoDriverConstants, IABTTWRuleConstants, ABTNames, IABTPropertyType
{

   public ConnectTimeSheetPopulator() {}

   public ConnectTimeSheetPopulator(ABTRepositoryDriver driver, ABTObjectSpace space, ABTUserSession session)
   {
      super(driver);
      setDriver(driver,space,session);
   	setNotePopulator(new ConnectNotePopulator(getDriver(),OBJ_TW_TIMESHEET, getSpace(), getSession()));
      checkProperties(OBJ_TW_TIMESHEET,FLD_TW_SAVED,PROP_BOOLEAN);
   }

   public ABTValue populate() throws ABTException
   {
   	ABTValue timesheets = super.populate();
   	
      if (timesheets == null) return null;
   	
   	if (timesheets instanceof ABTObjectSet) {
   		ABTObjectSet set = (ABTObjectSet)timesheets;
   		timeSheets_ = new ObjectIDSortedArray(new TWObjectComparator(getSession()));  		
   		for (int i = 0;i < set.size(getSession());i++) {
   	      timeSheets_.add(set.at(getSession(),i)); // Save off the timesheets for faster look up later.
   		}
   	}
            
      closePopulatorCursor();

      return timesheets;
   }

   public void addProperties()
   {
      checkProperties(OBJ_TW_TIMESHEET,FLD_TW_SAVED,PROP_BOOLEAN);
   }

}