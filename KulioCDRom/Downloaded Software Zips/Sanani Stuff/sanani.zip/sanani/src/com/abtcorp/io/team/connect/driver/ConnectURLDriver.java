package com.abtcorp.io.team.connect.driver;

import java.io.*;
import java.util.Hashtable;
import java.util.Enumeration;
import java.net.*;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTUtil;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.server.ABTServerDriver;

import com.abtcorp.io.team.connect.data.DataSet;
import com.abtcorp.io.team.connect.data.DataRow;
import com.abtcorp.io.team.connect.data.TWDataInputStream;
import com.abtcorp.io.team.connect.data.TWDataOutputStream;
import com.abtcorp.io.team.connect.data.TWOutputStream;
import com.abtcorp.io.team.connect.data.TWInputStream;
import com.abtcorp.io.team.connect.data.ObjectGenerator;
import com.abtcorp.io.team.connect.data.ObjectDataAdapter;
import com.abtcorp.io.team.connect.data.ObjectData;
import com.abtcorp.io.team.connect.data.FileManager;

import com.abtcorp.io.team.StatusMonitor;
import com.abtcorp.io.team.BaseTime;
import com.abtcorp.io.team.RemoteID;
import com.abtcorp.io.team.TWRepoDriverConstants;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

public class ConnectURLDriver extends ABTServerDriver implements IABTTWRuleConstants, TWRepoDriverConstants, errorMessages
{
   // Various strings used to aid the driver in opening, populating and saving.
   public static final ABTString USERDATA          = new ABTString("UserData".intern());
   public static final ABTString IMPORT_OBJECTS    = new ABTString("ImportObjects".intern());
   public static final ABTString TIMESHEETS        = new ABTString("TimeSheets".intern());
   public static final ABTString URL               = new ABTString("URL".intern());
   public static final ABTString OBJECTDATA        = new ABTString("ObjectData".intern());
   public static final ABTString NEWDATA           = new ABTString("NewData".intern());
   public static final ABTString SERVLET           = new ABTString("Servlet".intern());

   protected URL url_;

   protected Hashtable processedRows_ = new Hashtable();

   public ConnectURLDriver() {}
   /***
    * Opens the URL to read the data from. The hashtable passed contains arguments that
    * specify the URL to open. If there is no URL argument then the driver attempts to open
    * URL http://localhost/.
    *
    * @param space The object space that is to be populated by the driver.
    * @param session The user session started for this application.
    * @param args An ABTHashtable of arguments to aid the driver in performing the open.
    * The only argument that the driver looks for is ConnectURLDriver.URL. The value
    * associated with this key is the URL to connect to.
    *
    * @return ABTValue Null if the open succeeded. An ABTError if the open failed.
    *
    * @see ABTError
    * @see ABTValue
    */
   public ABTValue open(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue ret = null;

      if (args != null) {
         ABTValue temp = (ABTValue)args.get(URL);
         if (temp != null && temp instanceof ABTString) {
            try {
               url_ = new URL(temp.stringValue());
            } catch (MalformedURLException e) {
               return new ABTError(getClass(),"open",ERR_3,e.getMessage());
            }
         }
      }

      try {

         if (url_ == null) url_ = new URL("http", InetAddress.getLocalHost().getHostName(), "/");

      } catch (Exception e) {
         e.printStackTrace();
         ret = new ABTError(getClass(),"open",ERR_3,e.getMessage());
      }
      return ret;
   }

/**
 *		Populates the ABTObjectSpace with objects from the data source.
 *
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hashtable of optional, application-specific, parameters
 *
 *		@return An ABTValue object. The ABTValue consists of either an ABTObject or
 *		ABTObjectSet. All ABTObjects were added to the ABTObjectSpace by this
 *		method. If an error occurs the return ABTValue will be an ABTError.
 */
   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue value = null;
      TWDataInputStream input = null;

      if (url_ == null) return new ABTError(getClass(),"populate",ERR_2,null);

      if (args.get(USERDATA) != null) input = getUserInputStream(args);
      else if (args.get(IMPORT_OBJECTS) != null) input = getReceiveInputStream(args);

      if (input != null) value = populateSpaceFromStream(input,space,session,args);
      else return new ABTError(getClass(),"populate",ERR_1,null);

      return value;
   }

   /***
    * Saves objects from an object space to a URL via an HTTP Post request. This method accepts
    * a hashtable of arguments which determine the servlet path and request parameters (if any)
    * to concatenate to the URL.  All keys and values in the hashtable must be ABTValues.
    *
    * This method accepts the following hashtable keys: ConnectURLDriver.OBJECTDATA, ConnectURLDriver.TIMESHEETS
    * The OBJECTDATA key is used to save back modified timesheets, new tasks, or resources updated with new assignments.
    * This key is used by the applet when the user makes changes to their timesheets resulting in one of the above
    * mentioned objects being updated or created.
    * The TIMESHEETS key is used to save back rejected timesheets. This key is used by the ABT Connect
    * Agent after it has processed timesheets from the web server.
    *
    * @param space The space that contains the objects to save.
    * @param session The user session associated with the application.
    * @param args Hashtable of arguments used to aid in saving the objects.
    *
    * @return ABTValue Null if successful or an ABTError if it failed.
    */
   public ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      if (args == null) return null; // No args, nothing to do.

      ABTValue retval = null; // Errors returned from servlet.
      TWOutputStream stream = getOutputStreamForServlet(args);

      if (stream != null) {
         ABTValue value = isPostingObjectData(args); 
         if (value != null && !ABTEmpty.isEmpty(value) && !ABTError.isError(value)) {  
            try {
               if (value instanceof ABTArray) {
                  Object[] data = new Object[((ABTArray)value).size()]; // Data to be sent to the web server.
                  for (int i = 0;i < ((ABTArray)value).size();i++) {
                     ABTObjectSet set = (ABTObjectSet)((ABTArray)value).at(i);
                     DataSet dataset = DataSet.createDataSet(set.getObjectSetType(),set,session);
                     data[i] = dataset;
                  } // for
                  stream.writeInt(((ABTArray)value).size());
                  stream.writeObject(data); // Send the data to the web server.
                  stream.flush();
                  // Get the return ABTError values
                  TWInputStream input = stream.getInputStream();
                  retval = (ABTValue)input.readObject();
                  stream.close();
               } 
            } catch (Exception e) {
               e.printStackTrace();
               return new ABTError(getClass(),"save",ERR_3,e.getMessage());
            }
         } 

         value = (ABTValue)args.get(TIMESHEETS);
         if (value != null && !ABTEmpty.isEmpty(value) && !ABTError.isError(value)) {

            try {
               if (value instanceof ABTObjectSet) { // Processed timesheets from the agent.
                  ABTObjectSet set = (ABTObjectSet)value;
                  for (int i = 0;i < set.size(session);i++) {
                     DataRow row = new DataRow(ObjectDataAdapter.createObjectData((ABTObject)set.at(session,i),session),FileManager.mapType(((ABTObject)set.at(session,i)).getObjectType()));
                     stream.writeObject(row);
                  }
                  stream.writeObject(null); // Tell servlet no more data.
                  stream.flush();
                  stream.close();
               }
            } catch (Exception e) {
               return new ABTError(getClass(),"save",ERR_3,e.getMessage());
            }
         }

      } else return new ABTError(getClass(),"save",ERR_0,null);

      return retval;
   }

   public ABTValue close(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      return (ABTValue) null;
   }

   /***
    * Populates a Sanani object space using the input stream passed. The stream will be used to
    * read data rows from a data source, usually a URL. This routine will generate ABTObjects
    * from the data rows read in and populate the object space with them.
    *
    * @param input TWDataInputStream used to read the data rows from the data source.
    * @param space Sanani object space that will be populated.
    * @param session The user session the populate occurs within.
    *
    * @return ABTValue Either an ABTObject or ABTObjectSet of the populated objects, or an
    * ABTError indicating an error occurred.
    *
    * @see DataRow
    * @see ObjectGenerator
    */
   private ABTValue populateSpaceFromStream(TWDataInputStream input, ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue value = null;
      int total = 0;
      int count = 0;
      StatusMonitor monitor = null;
      try {
         monitor = (StatusMonitor)args.get(MONITOR);
      } catch (Exception e) {
      }

      try {
         if (args.get(IMPORT_OBJECTS) != null) total = input.readInt();
         else if (args.get(USERDATA) != null) {
            try {
               // The servlet will send back a number first. A positive number indicates the user
               // was verified and the number represents the base time for the servlet. A negative number represents 
               // an error condition and an ABTError object follows.
               long test = input.readLong(); 
               if (test > 0) {
                  BaseTime.setBaseTime(test);
                  ObjectInputStream is = new ObjectInputStream(input);
                  RemoteID.setHostAddress((InetAddress)is.readObject());
               } 
            } catch (ClassCastException e) {
               return new ABTError(getClass(),"populate",ERR_5,e.getMessage());         
            }
         }
         int length = input.readInt();
         Object row = null;
         ABTValue object = null;

         while(length != -100) {
            try {
               if (length > 0) row = input.readRow(length);

               if (row != null && row instanceof DataRow) object = ObjectGenerator.getGenerator().createObjectFromRow(space,session,(DataRow)row);
               else if (row instanceof ABTError) value = (ABTValue)row;

               if (args.get(USERDATA) != null) {
                  if (object instanceof ABTObject && ((ABTObject)object).getObjectType().equals(OBJ_TW_USER)) value = object;
               } //else if (args.get(TIMESHEETS) != null) {
                 // if (value == null) {
                     // Create the object to hold the timesheets.
                 //    value = space.createObjectSet(session,OBJ_TW_TIMESHEET);
                 //    if (value == null || ABTError.isError(value)) return value;
                 // }
                 // if (object instanceof ABTObject && ((ABTObject)object).getObjectType().equals(OBJ_TW_TIMESHEET)) ((ABTObjectSet)value).add(session,(ABTObject)object);
              // }

               if (row instanceof DataRow) {
                  if (args.get(IMPORT_OBJECTS) != null) {
                     if (((DataRow)row).getType() == FileManager.PROJECT || ((DataRow)row).getType() == FileManager.RESOURCE) total++;
                  }
                  if (monitor != null) monitor.updateStatus(this,FileManager.mapRowTypeToObjectType(((DataRow)row).getType()),total,count++);               
               }
               
               row = null;
               object = null;

            } catch (Exception e) {
               e.printStackTrace();
            }
            length = input.readInt();
         }

      } catch (Exception exception) {
         exception.printStackTrace();
         value = new ABTError(getClass(),"populateSpaceFromStream",ERR_3,exception.getMessage());
      }

      return value;
   }

   /***
    * Returns an input stream connected to the ABT Connect servlet for
    * the purposes of retrieving data rows associated with a particular
    * user.
    *
    * @param args Hashtable containing the user name and password. The user name
    * must be keyed by the ABTString FLD_TW_NAME and the password must be keyed by
    * the ABTString FLD_TW_PASSWORD.
    *
    * @return TWDataInputStream The stream that can be read for the data rows or null
    * if the connection could not be made based on the url set during construction of
    * this driver.
    *
    * @see TWDataInputStream
    */

   private TWDataInputStream getUserInputStream(ABTHashtable args)
   {
      if (url_.getProtocol().equals("http") || url_.getProtocol().equals("https")) {
         ABTValue servlet = (ABTValue)args.get(SERVLET);

         if (servlet instanceof ABTString) {
            ABTValue name = (ABTValue)args.get(new ABTString(FLD_TW_NAME));
            ABTValue password = (ABTValue)args.get(new ABTString(FLD_TW_PASSWORD));

            // Password may be 0 length string. If that's so, then there is no password.
            if (password != null && password.stringValue().length() == 0) password = null;

            String parm1 = name.stringValue();
            String parm2 = null;

            if (password != null && !ABTEmpty.isEmpty(name) && !ABTError.isError(name)) parm2 = ABTUtil.hash(password.stringValue());

            try {
               TWDataOutputStream output = new TWDataOutputStream(url_, "/servlet/" + servlet + "/user");
               if (parm1 != null) output.writeUTF(parm1);
               else output.writeUTF("");

               if (parm2 != null) output.writeUTF(parm2);
               else output.writeUTF("");

               return new TWDataInputStream(output.closeStream());
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      }
      return null;
   }

   /***
    * Returns an input stream connected to the ABT Connect servlet for
    * the purposes of retrieving data rows representing submitted/approved timesheets.
    *
    * @param args Hashtable containing the key TYPE with a value of SUBMITTED, APPROVED or ALL
    * indicating which timesheets to retrieve.
    *
    * @return TWDataInputStream The stream that can be read for the data rows or null
    * if the connection could not be made based on the url set during construction of
    * this driver.
    *
    * @see TWDataInputStream
    */

   private TWDataInputStream getReceiveInputStream(ABTHashtable args)
   {
      if (url_.getProtocol().equals("http") || url_.getProtocol().equals("https")) {

         ABTValue servlet = (ABTValue)args.get(SERVLET);
         if (servlet instanceof ABTString) {

            try {
               return new TWDataInputStream(url_, "/servlet/" + servlet.stringValue() + "/receive");
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      }
      return null;
   }

   /***
    * Returns an output stream that is used to save objects from the local object space to
    * a servlet.
    *
    * @param args A hashtable of arguments that determine which servlet path to open on the
    * URL associated with this driver.
    *
    * @return TWOutputStream The output stream to the servlet or null if the stream could not
    * be created.
    *
    * @see TWOutputStream
    *
    */
   private TWOutputStream getOutputStreamForServlet(ABTHashtable args)
   {
      TWOutputStream stream = null;

      try {
         ABTValue servlet = (ABTValue)args.get(SERVLET);
         if (servlet instanceof ABTString) {
            if (args.get(OBJECTDATA) != null) stream = new TWOutputStream(url_, "/servlet/" + servlet + "/data");
            else if (args.get(NEWDATA) != null) stream = new TWOutputStream(url_, "/servlet/" + servlet + "/newdata");
            else if (args.get(TIMESHEETS) != null) stream = new TWOutputStream(url_, "/servlet/" + servlet + "/rejecttimesheets");
         }
      } catch (Exception e) {
         e.printStackTrace();
      }

      return stream;
   }
   
   private ABTValue isPostingObjectData(ABTHashtable args)
   {
      ABTValue value = args.get(OBJECTDATA);
      if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) return value;
    
      value = args.get(NEWDATA);
      if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) return value;
      
      return null;

   }
   
   public ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable parameters) {return null;}
}