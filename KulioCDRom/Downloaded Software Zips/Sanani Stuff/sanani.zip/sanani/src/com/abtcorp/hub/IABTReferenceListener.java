
package com.abtcorp.hub;

/*
 * ABTReferenceListener.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 04-09-98	HJB		getInstanceCount, getObjectType
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;

/**
 *  IABTListener is the base class allowing common handling of notification of rowchanges
 *  By implementing this interface an object can 'listen' to
 *  any rowchanges
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */

public interface IABTReferenceListener
{

  /**
   * used to identify myself for QA-dump
   */
  public String dump(int indent,int level);
   
  /**
   * Notification of an add operation to an objectset stored in this property
   * if used set notifyAdd in rule constructor  to true
   * @param property - my property on which I am listening
   * @param child - the objectset currently referenced in this property
   * @param newValue - the new value added to this property
   * @param existing - true if the passed in new Value is an existing ABTObject
   *  , false if it was initialized to default values
   * @return null if allowed  or ABTError if rejected
   */
   ABTError notifyReferenceAdd (ABTUserSession session, ABTProperty property, IABTReferenceSource child,  ABTValue newValue,boolean existing, boolean dirty);


  /**
   * Notification of a remove operation in an objectset stored in this property
   * if used set notifyRemove in rule constructor to true
   * @param property - my property on which I am listening
   * @param child - the objectset currently referenced in this property
   * @param removedValue - the new value added to this property
   * @return null if allowed  or ABTError if rejected
   */
   ABTError notifyReferenceRemove (ABTUserSession session,ABTProperty property, IABTReferenceSource child,  ABTValue removedValue, boolean dirty);


  /**
   * Notification of a remove operation in an objectset stored in this property
   * if used set notifyClear in rule constructor to true
   * @param property - my property on which I am listening
   * @param child - the objectset currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   ABTError  notifyReferenceClear (ABTUserSession session,ABTProperty property, IABTReferenceSource child, boolean dirty);




  /**
   * Notification of a set operation in an element of the objectset stored in this property
   * if used set notifyChildSet in rule constructor to true
   * @param property - my property on which I am listening
   * @param childSet - the objectset currently referenced in this property
   * @param child - the object in the childset which was modified
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
   ABTError  notifyReferenceChildSet (ABTUserSession session,ABTProperty property, IABTReferenceSource childSet,  ABTObject child, ABTProperty childProperty, ABTValue oldValue, ABTValue newValue , boolean dirty);

  /**
   * Notification of a set operation in an element of the objectset stored in this property
   * if used set  notifySet in rule constructor to true
   * @param child - the object currently referenced in this property
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
   ABTError  notifyReferenceSet (ABTUserSession session,ABTProperty property, IABTReferenceSource child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue , boolean dirty);


  /**
   * Notification of a delete operation on an object referenced in this property
   * @param property - my property on which I am listening
   * @param child - the object currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   ABTError notifyReferenceDelete (ABTUserSession session,ABTProperty property, IABTReferenceSource child, boolean dirty);


}