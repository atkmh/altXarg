package com.abtcorp.io.client.pmwfile;
/*
 * IABTIOPMWFileConstants.java 08/04/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 08-04-98    MXA             Initial Implementation
  *
  */

/**
 *  IABTIOPMWFileConstants is a Java interface for specifying constants for the PMWFile components.
 *
 *
 * @version	1.0
 * @author		M. Abadian
 * @see        ABTDriver
 */


public interface IABTIOPMWFileConstants
{

    public static final String TARGET_OBJ           = "pmTargetObj".intern();
    public static final String PARENT_OBJ           = "pmParentObj".intern();
    public static final String PROJECT_OBJ          = "pmProjectObj".intern();
    public static final String PROJECT_ID           = "pmProjectID".intern();
    public static final String TEAM_ID              = "pmTeamID".intern();
    public static final String TASK_ID              = "pmTaskID".intern();
    public static final String ALLTASK_ID           = "pmAllTaskID".intern();
    public static final String ALLTASK_OBJ          = "pmAllTaskObj".intern();
    public static final String ASSIGNMENT_ID        = "pmAssignmentID".intern();
    public static final String DELIVERABLE_ID       = "pmDeliverableID".intern();
    public static final String CONSTRAINT_ID        = "pmConstraintID".intern();
    public static final String CUSTOMFIELD_ID       = "pmCustomfieldID".intern();
    public static final String DEPENDENCIES_ID      = "pmDependenciesID".intern();
    public static final String PREDDEPENDENCIES_ID  = "pmPredDependenciesID".intern();
    public static final String SUCCDEPENDENCIES_ID  = "pmSuccDependenciesID".intern();
    public static final String TASKESTIMATES_ID     = "pmTaskEstimatesID".intern();
    public static final String ESTMODELS_ID         = "pmEstimatingModelsID".intern();
    public static final String PARENTLASTCHILD_ID   = "pmParentLastChildID".intern();
    public static final String SUBPROJECTLINK_ID    = "pmSubProjectLinkID".intern();

 	// Rule base string when invoking createObject() or
 	// createObjectSet() in the object space.

 	public static final String RULE_BASE               = "com.abtcorp.objectModel".intern();
 	public static final String EXC_INVALID_OBJ_TYPE    = "Invalid object type".intern();
 	public static final String EXC_TASK_OSET_NOT_FOUND = "Task object set not found".intern();
 	public static final String EXC_RESOURCE_OSET_NOT_FOUND = "Resource object set not found".intern();
}
