package com.abtcorp.io.client.mppfile;

/**
 * ABTClientMppProject.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 08-27-98    ATW             Initial Implementation
  * 09-18-98    ATW             Commented.
  *
  */

/**
 *  ABTClientMppProject is a helper class which controls the transfer between 
 *  project data in a Microsoft Project project file (MPP) and data in a 
 *  Sanani project object.
 *
 *
 * @version		1.0
 * @author		A. Waller
 * @see			ABTClientMppHelper
 */


import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.Project;
import com.abtcorp.autowrap.msproject._MSProject;

import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTBoolean;

public class ABTClientMppProject extends ABTClientMppHelper implements IABTClientMppDriverConstants
{
    public   MppFormat   format_        = null;
    private _MSProject mppApp_ = null;

    private IABTObject projectObject_;
    private IABTObject tasksObject_;
    private IABTObject resourcesObject_;
    private IABTObject assignmentsObject_;
    private ABTClientMppRemoteID id_;

   /**
    *    Empty constructor.  Calls the parent classes' constructor.
    */
   public ABTClientMppProject() {/* implicit call to super() here */}

   /**
    *  Constructor used by the populate process.
    *  @param space the IABTObjectSpace that will contain this project
    *  @param driver the ABTClientMppDriver instance calling this helper
    *  @param mppApp an _MSProject object reference to the Microsoft Project application
    *  during the populate
    */
   public ABTClientMppProject( IABTObjectSpace space,
                               ABTClientMppDriver driver,
                               _MSProject mppApp )
    {
        super( space, driver );
        mppApp_ = mppApp;
    }

   /**
    *  Constructor used by the save process.
    *  @param space the IABTObjectSpace that contains the project to save from
    *  @param driver the ABTClientMppDriver instance calling this helper
    *  @param mppApp an _MSProject object reference to the Microsoft Project application
    *  @param project the IABTObject which is the project data will be saved to
    *  one already exists that could otherwise be updated
    */
    public ABTClientMppProject( IABTObjectSpace space,
                                ABTClientMppDriver driver,
                                _MSProject mppApp,
                                IABTObject project )
    {
        super( space, driver );
        projectObject_ = project;
        mppApp_ = mppApp;
    }


   /**
    *  Populates an object space with a project object.  This populate instantiates
    *  helpers for all the other objects that a project populated from an MPP file
    *  will contain and calls their populate methods.
    *  @return an ABTValue which is either the project object that was populated or an
    *  ABTError if one occurs
    *  @exception ABTException if an unrecoverable error occurs
    */
    public ABTValue populate() throws ABTException
    {
        ABTValue projSuccess              = null;
        ABTValue success                  = null;
        ABTValue returnValue              = null;
        Project mppActiveProject          = null;

        mppActiveProject = mppApp_.getActiveProject();

        format_ = new MppFormat( mppApp_ );

        // Create a remote ID for the project object from the filename and unique ID.
        id_ = new ABTClientMppRemoteID( mppActiveProject.getFullName(),
                                        mppActiveProject.getUniqueID());

        try
        {
            //    *****************        Populate Project       *******************

            if ( mppActiveProject instanceof Project )
            {
                projSuccess = create( null );

                if ( ABTError.isError( projSuccess ) )
                    throw new ABTException( ((ABTError)projSuccess).getMessage() );

                projectObject_ = (IABTObject) projSuccess;
                setValues( mppActiveProject, projectObject_ );
            }

            // The project has been created successfully.  Create its component objects.
            if ( projectObject_ instanceof IABTObject )
            {
                //
                // Get resources for the project.
                //
                ABTClientMppResources resPop = new ABTClientMppResources( getSpace(), driver_,
                                                    projectObject_, mppActiveProject, format_ );

                if ( resPop instanceof ABTClientMppResources )
                    success = resPop.populate();

                if ( ABTError.isError( success ) )
                    throw new ABTException( ((ABTError)success).getMessage() );

                //
                // Create the project's team set.  Since there is no team component in
                // an MPP file, this populator creates a team object for each
                // resource added to the project by the resource populator.
                //
                ABTClientMppTeam teamPop = new ABTClientMppTeam( getSpace(), driver_,
                                                projectObject_, resPop, mppActiveProject );

                if ( teamPop instanceof ABTClientMppTeam )
                    success = teamPop.populate();

                if ( ABTError.isError(success ) )
                    throw new ABTException( ((ABTError)success).getMessage() );

                ABTClientMppTasks tasksPopulator = new ABTClientMppTasks( getSpace(), driver_, projectObject_, mppActiveProject, true, format_ );

                if ( tasksPopulator instanceof ABTClientMppTasks )
                    success = tasksPopulator.populate();

                if ( ABTError.isError( success ) )
                    throw new ABTException( ((ABTError)success ).getMessage() );

  //    *****************        Populate Assignments      *****************

                ABTClientMppAssignments assignmentsPopulator = new ABTClientMppAssignments( space_, driver_,
                                                                    mppActiveProject, true , tasksPopulator, resPop, format_, projectObject_);

                if ( assignmentsPopulator instanceof ABTClientMppAssignments )
                    success = assignmentsPopulator.populate();

                if ( ABTError.isError(success ) )
                    throw new ABTException( ((ABTError)success).getMessage() );

                ABTClientMppDependencies dependenciesPopulator = new ABTClientMppDependencies( getSpace(), driver_, projectObject_, mppActiveProject, true, tasksPopulator, format_);

                if ( dependenciesPopulator instanceof ABTClientMppDependencies )
                    success = dependenciesPopulator.populate();

                if ( ABTError.isError( success ) )
                    throw new ABTException(((ABTError)success).getMessage());

                //
                // Get task constraints.  Only custom constraints (not "finish ASAP")
                // will be retrieved.
                //
                ABTClientMppConstraint conPop = new ABTClientMppConstraint( space_, driver_,
                                                projectObject_, mppActiveProject );

				if ( conPop instanceof ABTClientMppConstraint )
					success = conPop.populate();

				if ( ABTError.isError(success ) )
					throw new ABTException( ((ABTError)success).getMessage() );

                //
                // The notes populator gets the project, task, resource and
                // assignment notes.  All of these other populators should be
                // called before this one, obviously, but the absence of any of
                // their sets of objects won't cause a failure.
                //
                ABTClientMppNotes notesPop = new ABTClientMppNotes( space_, driver_,
                                             projectObject_, mppActiveProject );

                if ( notesPop instanceof ABTClientMppNotes )
                    success = notesPop.populate();

                if ( ABTError.isError( success ) )
                    throw new ABTException( ((ABTError)success).getMessage() );
            }

      // *** DONE ***

            returnValue =  projSuccess; //since everything went well with no exceptions
        }
        catch ( ABTException e )
        {
            returnValue = createErrorObject( this.getClass(), ERR_POP, e.getMessage() );
        }
        catch ( Exception e )
        {
			returnValue = new ABTError( this.getClass(), ERR_POP, ERR_JAVA_EXCEPTION, e );
        }
        finally
        {
            // Clean up and go.
            if ( mppActiveProject != null )
                mppActiveProject.release();
            System.gc();
            System.runFinalization();

            return returnValue;
        }
    }

   /**
    *  Creates a new project object
    *  @param parms an ABTArray of required parameters for creating this
    *  object.  This value can be null if this object type does not
    *  require any creation parameters
    *  @return an ABTValue which will either be the newly-created project object or
    *  null if none is created
    *  @exception ABTException if an unrecoverable error occurs
    */
    protected ABTValue create( ABTArray parms ) throws ABTException
    {
        ABTValue object = null;

        //
        // Ask the object space to create a new project object.  There are no required params
        // for project object creation.
        //
        object = (ABTValue)createObject( OBJ_PROJECT, id_, null );
        return object;
    }

   /**
    *  Updates an existing project object - currently just creates a new one
    *  @param parms an ABTArray containing the existing project object
    *  @return an ABTValue which is the updated project object (currently a brand-new one)
    *  @exception ABTException if an unrecoverable error occurs
    */
    protected ABTValue update( ABTArray parms ) throws ABTException
    {
        return create( parms );
    }

	/**
	*  Sets new values into the project object's properties from values
	*  in a Microsoft Project project's resource.
	*  @param mppProject a Project reference to the project object of the active project
    *  currently open in Microsoft Project.
	*  @param obj an ABTValue reference to the Sanani project object currently being modified
	*  @exception ABTException if an unrecoverable error occurs
	*/
    private void setValues( Project mppProject, IABTObject obj ) throws ABTException
    {
        ABTString tempStr = null;      // Used for field size validations before setting.
        ABTArray keyArray = new ABTArray(); 

        //
        // The Keywords field of the Project Summary property page may be
        // a string of up to four "words" each ending with the "@" character.   
        // The first three if present are the version number, external ID
        // and guidelines filename.
        //
        tempStr = new ABTString( mppProject.getField( "Keywords" ) );
        if ( (tempStr.toString()).length() > 0 )
        {
            getKeywords( keyArray, tempStr.toString() );
            if ( keyArray.at(0) != null )
                obj.setValue( OFD_VERSION, ((ABTShort)keyArray.at(0)) );
            if ( keyArray.at(1) != null )
                obj.setValue( OFD_EXTERNALID, ((ABTString)keyArray.at(1)) );
            if ( keyArray.at(2) != null )
                obj.setValue( OFD_GUIDELINES, ((ABTString)keyArray.at(2)) );
        }            

		obj.setValue( OFD_SITE, driver_.getSite( space_ ) );
		obj.setValue( OFD_ISFULLYPOPULATED, ABTBoolean.True() );
		obj.setValue( OFD_EXPLICITINTEREST, ABTBoolean.True() );
        obj.setValue( OFD_DESCRIPTION, new ABTString( mppProject.getField( "Subject" ) ) );
        obj.setValue( OFD_NAME, new ABTString( mppProject.getField( "Title" ) ) );
        obj.setValue( OFD_MANAGER, new ABTString( mppProject.getField( "Manager" ) ) );
        obj.setValue( OFD_DEPARTMENT, new ABTString( mppProject.getField( "Company" ) ) );

        obj.setValue( OFD_FORMAT, new ABTInteger(11) );  // Indicates source is MPP file.
        obj.setValue( OFD_CPMTYPE, new ABTInteger(0) );   // Current
        obj.setValue( OFD_ID, new ABTInteger( mppProject.getID() ) );
        obj.setValue( OFD_FILENAME, new ABTString( mppProject.getFullName() ) );
ABTTime tempDate = new ABTTime( mppProject.getProjectStart() );
        obj.setValue( OFD_START, tempDate );

		System.out.println( "Start date from file is " + tempDate.toString() );
        obj.setValue( OFD_AVAILSTART, new ABTTime( mppProject.getProjectStart() ) );
        obj.setValue( OFD_AVAILFINISH, new ABTTime( mppProject.getProjectFinish() ) );

        // Get the project's notes
        String projNote = mppProject.getProjectNotes();
        if ( projNote.length() > 0 )
        {
            IABTObjectSet noteOSet = getObjectSet( obj, OFD_NOTES );
            IABTObject noteObj = (IABTObject)createObject( OBJ_NOTE, null );
            noteObj.setValue( OFD_VALUE, new ABTString( projNote ) );
            addListMember( noteOSet, noteObj );
        }
    }


   // -------------------------------------------------------------------------------
   // save logic begins here.
   // -------------------------------------------------------------------------------

   /**
    *  Saves a Project object to an MPP file
    *  @return returns null if successful, an ABTError if not
    *  @exception ABTException if an unrecoverable error occurs
    */
    public ABTValue save() throws ABTException
    {
        ABTValue success                  = null;
        ABTValue returnValue              = null;
        Project mppActiveProject          = null;

        // Things not to save if gotten:  start date, committed actuals stuff, 

        mppActiveProject = mppApp_.getActiveProject();
        format_ = new MppFormat( mppApp_ );

        try
        {
            //
            // Match the active project in the MPP file with a project in 
            // the object space.  If it doesn't exist, that's a real problem!
            //
            if ( mppActiveProject instanceof Project )
            {
				ABTValue proj = null;
                
				// Create a remote ID for the project object from the filename and unique ID.
                id_ = new ABTClientMppRemoteID( mppActiveProject.getFullName(),
                                                mppActiveProject.getUniqueID());

				// No project object passed in, maybe we can find it in the space anyway,
				if ( projectObject_ == null )
				{
					proj = find( OBJ_PROJECT, id_ );

					if ( !(proj instanceof IABTObject) )
						returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_NO_PROJ );
						
					if ( success == null )
						projectObject_ = (IABTObject)proj;
				}

				if ( returnValue == null )
                {
                    getValues( mppActiveProject, projectObject_ );

                    // Save the project's resources.
                    ABTClientMppResources resSave = new ABTClientMppResources( getSpace(), driver_,
                                                        projectObject_, mppActiveProject, format_ );

                    if ( resSave instanceof ABTClientMppResources )
                        success = resSave.save();

                    if ( ABTError.isError( success ) )
                        returnValue = success;
                  //*****************  Task **************************

                  ABTClientMppTasks taskSave = new ABTClientMppTasks(
                                                            getSpace(),
                                                            driver_,
                                                            projectObject_,
                                                            mppActiveProject,
                                                            true,
                                                            format_
                                                            );

                  if (taskSave instanceof ABTClientMppTasks) success = taskSave.save();

                  if (ABTError.isError(success)) returnValue = success;

                  //*****************  Assignment **************************

                  ABTClientMppAssignments assignmentSave = new ABTClientMppAssignments(
                                                            getSpace(),
                                                            driver_,
                                                            projectObject_,
                                                            mppActiveProject,
                                                            format_
                                                            );

                  if (assignmentSave instanceof ABTClientMppAssignments) success = assignmentSave.save();

                  if (ABTError.isError(success)) returnValue = success;

                  //*****************  Dependency **************************

               	ABTClientMppDependencies dependencySave =  new ABTClientMppDependencies(
                                                            getSpace(),
                                                            driver_,
                                                            projectObject_,
                                                            mppActiveProject,
                                                            taskSave,
                                                            format_
                              );

                  if (dependencySave instanceof ABTClientMppDependencies) success = dependencySave.save();

                  if (ABTError.isError(success)) returnValue = success;

                }
                 //
				 // Error, probably "Object Not Found" from ABTRule's findObject().
                 // If so, throw an ABTException which will get converted to an ABTError
                 // and returned in the catch{} below.
                 //
                else
                {
                	if ( ABTError.isError( proj ) )
                    	throw new ABTException( (ABTError)proj );
                }
			}
            else
                returnValue = createErrorObject( this.getClass(), ERR_SAVE, ERR_BAD_MSPROJ );

        }
        catch ( ABTException e )
        {
            returnValue = createErrorObject( this.getClass(), ERR_SAVE, e.getMessage() );
        }
        catch ( Exception e )
        {
			returnValue = new ABTError( this.getClass(), ERR_SAVE, ERR_JAVA_EXCEPTION, e );
        }
        finally
        {
            // Clean up and go.
            if ( mppActiveProject != null )
                mppActiveProject.release();
            System.gc();
            System.runFinalization();

            return returnValue;
        }
    }

   /**
    *  Converts properties in the current Sanani project to values
    *  in the active project of the open MPP file.
    *  @param mppProject the Project currently open and active in Microsoft Project
    *  @param obj the IABTObject reference to the project object representing this MSP project
    *  @exception ABTException if an unrecoverable error occurs
    */
    private void getValues( Project mppProject, IABTObject obj ) throws ABTException
    {
        ABTString tempStr = null;      // Used for field size validations before setting.
        ABTTime   tempDate = null;

        tempStr = new ABTString( getValue( obj, OFD_NAME ) );
        if ( (tempStr.toString()).length() > 0  )
            mppProject.setField( "Title", tempStr );

        tempStr = new ABTString( getValue( obj, OFD_DESCRIPTION ) );
        if ( (tempStr.toString()).length() > 0  )
            mppProject.setField( "Subject", tempStr );

        tempStr = new ABTString( getValue( obj, OFD_MANAGER ) );
        if ( (tempStr.toString()).length() > 0  )
            mppProject.setField( "Manager", tempStr );

        tempStr = new ABTString( getValue( obj, OFD_DEPARTMENT ) );
        if ( (tempStr.toString()).length() > 0  )
            mppProject.setField( "Company", tempStr );

        mppProject.setProjectStart( getValue( obj, OFD_START ) );

        //
        // Concatenate all the notes in the project's note objectset.
        //
        IABTObjectSet noteSet = getObjectSet( obj, OFD_NOTES );
        ABTValue noteVal = null;
        IABTObject noteObj = null;

        if ( noteSet.size() > 0 )
        {
            StringBuffer noteBuf = new StringBuffer();

            for ( int k = 0; k < noteSet.size(); k++ )
            {
                noteObj = (IABTObject) noteSet.at( k );
                noteVal = noteObj.getValue( OFD_VALUE );
                tempStr = (ABTString)noteVal;
                if ( tempStr != null && (tempStr.stringValue()).length() > 0 )
                    noteBuf.append( tempStr.stringValue() + " " );
            }
            mppProject.setProjectNotes( noteBuf.toString() );
        }
        else  // Clear notes in the file if there are none in the project.
            mppProject.setProjectNotes("");

        //
        // Set the "Keywords" field in the Project Summary Information
        //
        mppProject.setField("Keywords", new ABTString( setKeywords( obj ) ) );
    }

//--------------------------------------------------------------------------
//      Utility functions
//--------------------------------------------------------------------------

   /**
    *  Extracts delimited keywords from the Keywords field of the Project
    *  Summary sheet of the currently active project in Microsoft Project
    *  into an ABTArray
    *  @param keyArr an ABTArray which will contain the separated strings
    *  from the Keywords field minus their delimiting character
    *  @param keyStr the String from the Project Summary Keywords field.
    */
    private void getKeywords( ABTArray keyArr, String keyStr )
    {
        int delim1 = -1, delim2 = -1;

        //
        // There are up to 4 "words" in the Keywords field separated by
        // the "@" character at the end of each. Get them into
        // the global array for later use.
        //
        delim1 = keyStr.indexOf( '@', 0 );
        if ( delim1 != -1 && delim1 > 0 )
        {
            // This one has to be numeric or else.
            ABTString strToShort = new ABTString( keyStr.substring( 0, delim1 ) );
			try
			{
                keyArr.add( new ABTShort( strToShort.shortValue() ) );
			}
			catch ( Exception e )
			{
				keyArr.add( new ABTString( "1" ) );
			}
        }
        else
            keyArr.add( null );

        delim2 = keyStr.indexOf( '@', delim1+1 );
        if ( delim2 != -1  && delim2 > 0 )
            keyArr.add( new ABTString( keyStr.substring( delim1+1, delim2 ) ) );
        else
            keyArr.add( new ABTString("") );

        delim1 = keyStr.indexOf( '@', delim2+1 );
        if ( delim1 != -1 && delim1 > 0 )
            keyArr.add( new ABTString( keyStr.substring( delim2+1, delim1 ) ) );
        else
            keyArr.add( new ABTString("") );
    }

   /**
    *  Builds the Keywords field for the Project Summary sheet of the 
    *  currently active project in Microsoft Project from an ABTArray 
    *  containing up to three strings.  Adds the "@" delimiter character
    *  after each string.
    *  @param object an IABTObject reference to the project object being created
    *  @return the formatted String for the Project Summary Keywords field
    */
    private String setKeywords( IABTObject object ) 
    {
        String retStr;
		short temp = 0;

        ABTShort version = new ABTShort( object.getValue( OFD_VERSION ) );
        ABTString extID = new ABTString( object.getValue( OFD_EXTERNALID ) );
        ABTString guide = new ABTString( object.getValue( OFD_GUIDELINES ) );

		try
		{
			// Increment version number.  (I saw this in the repo driver code.)
			temp = (short)(version.shortValue() + 1);
		}
		catch ( Exception e )
		{
			System.out.println( e.getMessage() );
		}

        retStr = new String( temp + "@" +
                             extID.toString() + "@" +
                             guide.toString() );
        if ( retStr.length() > 3 )
            return retStr;
        else
            return null;
    }
}






