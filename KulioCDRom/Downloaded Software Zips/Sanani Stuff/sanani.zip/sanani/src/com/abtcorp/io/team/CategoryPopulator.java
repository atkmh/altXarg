package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTInteger;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class CategoryPopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   public CategoryPopulator() {}
   public CategoryPopulator(ABTRepositoryDriver driver) {super(driver);}

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet categories = getObjectSet(OBJ_TW_NOTECATEGORIES);

      if (cursor_ == null || categories == null) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      ABTValue value = getDriver().getSpace().createObjectSet(session_,OBJ_TW_CATEGORYSTRING);
      if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) {

         ABTObjectSet strings = (ABTObjectSet)value;

         while (cursor_.moveNext()) {
            ABTObject str = (ABTObject)strings.addNew(session_);
            str.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
            str.setValue(session_,FLD_TW_BUFFER,cursor_.getField(FLD_CAPTION));
            RemoteID.setRemoteID(str,session_);
            updateStatus(str);
         }

         ABTObject list = (ABTObject)categories.addNew(session_);
         list.setValue(session_,FLD_TW_LIST,strings);

      }

      closePopulatorCursor();
      return categories;
   }
}