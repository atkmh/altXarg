package com.abtcorp.io;

import com.abtcorp.core.ABTException;

public class ABTInvalidRepositoryException extends ABTException
{
   public ABTInvalidRepositoryException(String s) {super(s);}
   // TODO: Localization issue with the exception message!
   public ABTInvalidRepositoryException() {super("Invalid data repository");}
}
