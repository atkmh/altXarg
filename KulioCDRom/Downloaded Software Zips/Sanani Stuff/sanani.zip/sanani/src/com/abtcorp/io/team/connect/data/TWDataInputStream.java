package com.abtcorp.io.team.connect.data;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.net.URL;
import java.net.URLConnection;

import com.abtcorp.core.ABTArray;

public class TWDataInputStream extends DataInputStream 
{
   private static URLConnection getURLConnection(URL url) throws IOException
   {
      URLConnection connection = url.openConnection();

      connection.setDoInput(true);
      connection.setDoOutput(false);
      connection.setUseCaches(false);

      return connection;
   }

   public TWDataInputStream(InputStream stream) throws IOException, StreamCorruptedException
   {
      super(stream);
   }

   public TWDataInputStream(String path) throws IOException
   {
      this(new FileInputStream(path));
   }

   public TWDataInputStream(URLConnection connection) throws IOException
   {
      this(connection.getInputStream());
   }

   public TWDataInputStream(URL url) throws IOException
   {
      this(getURLConnection(url));
   }

   public TWDataInputStream(URL url, String path) throws IOException
   {
      this(new URL(url, path));
   }

   private byte[] readStreamBytes(int length) throws IOException
   {
      byte[] array = new byte[length];
      readFully(array);
      return array;
   }

   public void readVector(ABTArray vector) throws IOException, ClassNotFoundException
   {
      int length = readInt();
      while (length != 0) {
         TWInputStream stream = getInputStream(length);
         if (stream != null) {
            vector.add(stream.readObject());
            stream.close();
         }
         length = readInt();
      }
   }
   
   public TWInputStream getInputStream(int length) throws IOException
   {
      if (length > 0) {
         byte[] array = readStreamBytes(length);
         TWInputStream stream = new TWInputStream(new ByteArrayInputStream(array));
         return stream;
      } 
      return null;
   }

   // Row can be an ABTError if something goes wrong. Caller must check.
   public Object readRow(int length) throws IOException, ClassNotFoundException
   {
      Object row = null;

      TWInputStream stream = getInputStream(length);
      if (stream != null) row = stream.readObject();

      return row;
   }
}