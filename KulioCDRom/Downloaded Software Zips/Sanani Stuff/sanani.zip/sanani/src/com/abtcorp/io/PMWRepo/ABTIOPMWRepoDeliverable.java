package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoDeliverable.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support new required parameters functionality
 * 07-24-98    SOB            Mods to support save() processing
 * 08-27-98    SOB            Mods to support exception-based populating.
 * 10-09-98    SOB            Beginnings of progress reporting
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoDeliverable is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTDeliverable object in the object space.
 *  <pre>
 *       ABTIOPMWRepoDeliverable rd = new ABTIOPMWRepoDeliverable(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 * @see         ABTProjectSaver
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTID;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoDeliverable extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private ABTObjectSet dos_;
   private Hashtable ht_;
   private Hashtable hr_;
   private ABTCursor dlcursor_ = null;

   public ABTIOPMWRepoDeliverable() {/*implicit call to super() here*/}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoDeliverable(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable ht,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_DELIVERABLE, OBJ_DELIVERABLE, progress);
      projObj_ = projObj;
      projectID_ = projID;
      ht_ = ht;
      
      //
      // Now obtain the propert index vector for deliverable objects.  We need to update
      // the property flags of each deliverable's External ID to bypass reading the External ID
      // if that ID is null (or zero length) in the repository.  Later, in the
      // isPopulateException() method, the flag will be tested.
      //
      Vector piv = getPropertyIndexVector(ps_);
      int size = piv.size();
      for (int i = 0; i < size; i++)
      {
         PropertyIndex pi = (PropertyIndex) piv.elementAt(i);
         if (pi.prapiName_.equals(FLD_EXTERNALID))
            pi.propertyFlags_ += FLAG_SKIP_READ_ON_NULL;
      }
   }

   /**
    *    Constructs an ABTIOPMWRepoDeliverable helper object to support the save process
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepositoryDriver reference
    *    @param project a Project object reference
    *    @param forceAddNew true, if addNew() operations are being forced; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoDeliverable(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_DELIVERABLE, OBJ_DELIVERABLE, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with Deliverable objects
    *    @param parms (currently not used)
    *    @return an ABTValue indicating the status of the populate process
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;

      try
      {
         getCursors();

   	   //
   	   // Set the sort order for the task deliverable link result set.
   	   //
   	   dlcursor_.setSort(TBL_TASKDELIVLINK + "." + FLD_DELIVERABLEID);

      	while (cursor_.moveNext())		// for every deliverable entry in the result set...
      	{
            //
            // Create a remote ID for this deliverable object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the deliverable object already exists in the object space.
            //
            object = find(OBJ_DELIVERABLE, id_);

            //
            // If the object found is an ABTObject, then the deliverable object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new deliverable object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray prms = new ABTArray();
               prms.add(object);      // identify the deliverable object for update()
               object = update(prms);
            }
            else
            {
               object = create(null);
            }
      	}           // end while (cursor_.moveNext())
      }              // end try
      finally
      {
         closeCursors();
      }

      return null;
   }

   /**
    *    Creates a new Deliverable object
    *    @param parms (currently not used)
    *    @return an ABTValue which is the newly-created deliverable object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Ask the object space to create a new deliverable object.  Set the remote ID.
      // A project reference is required to create a deliverable object.
      //
      ABTHashtable delivreqs = new ABTHashtable();
      delivreqs.putItemByString(OFD_PROJECT, projObj_);
      ABTObject deliv = createObject(OBJ_DELIVERABLE, id_, delivreqs);

      //
      // Initialize repository properties of the new deliverable object.
      //
      setValues(deliv);
      setReferences(deliv);

      return deliv;
   }

   /**
    *    Updates an existing Deliverable object
    *    @param parms the object to be updated
    *    @return an ABTValue which is the updated deliverable object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);
      setReferences(object);
      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
      //
      // Set the property values from the repository deliverable tuple into the deliverable
      // object.
      //
      setPropertyValues(ps_, cursor_, obj);

   }

      /**
    *    Checks for exceptions in reading some columns from the repository.  This method supports
    *    exception-based repository reading.  This method is entered for every PRAPI field that is
    *    a candidate for being read from the repository and set into an ABTObject property in the space.
    *    @param   obj the ABTObject which is about to have one of its properties set
    *    @param   val the ABTValue which contains the data to be set into obj
    *    @param   idx an object which contains useful information about the property which is about to
    *             be set, including the index of the property in the set of all properties for obj
    *    @return  true if there is an exception to the data being checked and it should NOT be set in obj;
    *             false if the the data should be set in obj.
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isPopulateException(ABTObject obj, ABTValue val, PropertyIndex idx) throws ABTException
   {
      if ( super.isPopulateException(obj, val, idx) ) return true;
      
      boolean ret = false;       // assume it's NOT an exception
      
      //
      // If we are to skip a field from the repository because it is null (or is a string of zero length),
      // then check for that now.  One such field the External ID of deliverable objects.
      
      if ((idx.propertyFlags_ & FLAG_SKIP_READ_ON_NULL) == FLAG_SKIP_READ_ON_NULL )
      {
         if (val == null)
            ret = true;          // it's null, therefore it's an exception
         else
         {
            if (val instanceof ABTString)
            {
               if ( ((ABTString)val).compareTo("") == 0 )
                  ret = true;    // the string is empty, therefore it's an exception
            }
         }
      }
      return ret;
   }
   
   private void setReferences(ABTObject obj) throws ABTException
   {
      // Position into the task deliverable link result set using the prDeliverableID.
      // Go to the first task deliverable link (if any) that matches on prDeliverableID.
      // There may be many such entries.  The positioning assumes that the result set is
      // ordered by prDeliverableID.
      //
      ABTValue delivID = cursor_.getField(FLD_ID);
      boolean found = dlcursor_.lsearchFirst(FLD_DELIVERABLEID, delivID);
      if (found)
      {
         do
         {
            //
            // Locate the task object identified by the task deliverable link's prDeliverableID
            // column.  If the task cannot be found, continue the loop.
            //
            Long associatedTaskID = new Long(dlcursor_.getFieldInt(FLD_TASKID));
            ABTObject associatedTask = (ABTObject) ht_.get(associatedTaskID);
            if (associatedTask == null) continue;

            //
            // Add this deliverable object to the associated task's collection of deliverables.
            // This will also add the task object to the deliverable object's set of associated
            // task objects.  Only add this deliverable object, however, if the associated task
            // does not already have it as a deliverable in its set of deliverables.
            //
            ABTObjectSet delivos = getObjectSet(associatedTask, OFD_DELIVERABLES);
            if (!contains(delivos, obj))
               addListMember(delivos, obj);
         }
         while (dlcursor_.lsearchNext(FLD_DELIVERABLEID, delivID));
      }           // end if (found)
   }

   private void getCursors()
   {
      //
      // Select the project-related deliverables for this project only.
      //
      cursor_ = repo_.select(TBL_DELIVERABLE);
      cursor_.andFilter(TBL_DELIVERABLE + "." + FLD_PROJECTID + " = " + projectID_);
  
      //
      // Select the task deliverable links for this project only.  These tuples identify
      // associated tasks (in the current project only) that have deliverables. Order the
      // result set by the prDeliverableID column; this will allow for ordered searches of
      // the result set later.
      //
      dlcursor_ = repo_.select(QRY_TASKDELIVLINK);
      dlcursor_.andFilter(TBL_TASK + "." + FLD_PROJECTID + " = " + projectID_);
   }

   private void closeCursors()
   {
      //
      // Close the deliverable cursor.
      //
      closeCursor();

      //
      // Close the task deliverable link cursor.
      //
      if (dlcursor_ != null)
      {
         dlcursor_.release();
         dlcursor_ = null;
      }
   }

   /**
    *    Saves deliverable objects back to the repository.  The saving also includes
    *    PRTaskDelivLink tuples, even though these are not represented in the object
    *    space as separate objects.
    *    @param parms (currently not used)
    *    @exception ABTException if an unrecoverable error occurs
    *
    */
   public void save(ABTArray parms) throws ABTException
   {
      getCursors();

      //
      // Set sort order for the result sets.
      //
      cursor_.setSort(TBL_DELIVERABLE + "." + FLD_ID);
      dlcursor_.setSort(TBL_TASKDELIVLINK + "." + FLD_TASKID);

      ABTObjectSet deliverables = getObjectSet(projObj_, OFD_ALLDELIVERABLES);

      //
      // Set some properties in the deliverable objects.
      //
      setSomeProperties(deliverables);

      //
      // Now save all of the deliverables
      //
      save(deliverables);

      //
      // Process task deliverable link entries in the repository.
      //
      // Since task deliverable link tuples do not have corresponding task
      // deliverable link objects in the space, we need to process these tuples
      // differently than other PM objects during save operations.
      //
      // 1. For each task in the project being saved, check for a non-empty collection of
      //    deliverable objects.
      // 2. If the collection is empty, get the next task.
      // 3. If the collection is not empty,
      //    a. If we are forcing new tuples (as in saveAs()), add a new tuple, drop the tuple, get next deliverable;
      //    b. Search the task deliverable link result set for a matching entry for the task object's ID
      //       and each deliverable object's ID.
      //    c. If a match is found in the result set, drop the tuple and get the next deliverable object in the
      //       task's collection.  There is nothing to update.
      //    d. If a match is not found in the result set, create a new task deliverable link entry and then
      //       drop it from the result set.
      // 6. At the conclusion of processing of all the tasks and their deliverables, delete any remaining
      //    tuples in the task deliverable link result set.  These tuples being dropped were either,
      //    a. Part of the project when the project was populated and were subsequently deleted by the application, or
      //    b. Not present when the project was populated and are therefore spurious or bogus, and should be deleted.
      //

      saveDeliverableLinks();
      dlcursor_.deleteAll();

      closeCursors();
   }

   private void setSomeProperties(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);

      //
      // For each deliverable object, make sure the project ID is set correctly.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject deliverable = at(oSet, i);
         setValue(deliverable, OFD_PROJECTID, getValue(projObj_, OFD_ID));
      }
   }

   /**
    *    Check for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: true, if the data being written is new to the repository, i.e., the
    *             operation is an add; false, if the operation is an update
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         if (super.isSaveException(prapiName, obj, prapiFlags, isNew))
            return true;

         boolean  ret = false;            // assume no exception

         //
         // We can't update the project ID field after it's been set initially when the tuple
         // was first added.  So if we are updating, and the field being set is the project ID,
         // then cause this field to be skipped.
         //
         if (prapiName.equals(FLD_PROJECTID) && !isNew)
            ret = true;

         return ret;
   }

   private ABTValue saveDeliverableLinks() throws ABTException
   {
      ABTObjectSet tasks = getObjectSet(projObj_, OFD_ALLTASKS);
      int size = size(tasks);

      for (int i = 0; i < size; i++)
      {
         ABTObject task = at(tasks, i);
         ABTObjectSet tasksDeliverables = getObjectSet(task, OFD_DELIVERABLES);
         int taskDelivCount = size(tasksDeliverables);
         for (int j = 0; j < taskDelivCount; j++)
         {
            ABTObject deliverable = at(tasksDeliverables, j);
            processDelivLink(task, deliverable);
         }
      }

      return (ABTValue) null;
   }

   private ABTValue processDelivLink(ABTObject task, ABTObject deliverable) throws ABTException
   {
      ABTValue taskID = getValue(task, OFD_ID);
      ABTValue delivID = getValue(deliverable, OFD_ID);

      boolean found = foundDelivLink(taskID, delivID);

      //
      // If we need to add a new task deliverable link tuple, do it now,
      // but drop the tuple from the result set after adding it.
      //
      if (forceAddNew_ || !found)
      {
      	dlcursor_.moveEOF();
         dlcursor_.addNew();
         dlcursor_.setField(FLD_TASKID, taskID);
         dlcursor_.setField(FLD_DELIVERABLEID, delivID);
         dlcursor_.update();
      }

      //
      // Drop the current tuple from the result set.
      //
      dlcursor_.drop();
      return (ABTValue) null;
   }

   private boolean foundDelivLink(ABTValue taskID, ABTValue delivID)
   {
      boolean found = false;        // assume not found
      boolean foundtuple = dlcursor_.lsearchFirst(FLD_TASKID, taskID);

      //
      // The following while() loop is dependent upon the repository task
      // deliverable link tuples being ordered by prTaskID.
      //
      // Search all those tuples that have a prTaskID equal to the input
      // task ID.  If a tuple can be found where the associated deliverable
      // ID matches the input deliverable ID, then return true to the caller.
      // Otherwise, return false to the caller.
      //
      while (foundtuple)
      {
         ABTValue tupleDelivID = dlcursor_.getField(FLD_DELIVERABLEID);

         //
         // Does the deliverable ID match the input deliverable ID?
         //
         if (delivID.equals(tupleDelivID))
         {
            found = true;
            break;
         }

         //
         // Get next tuple in result set, if any.  If none,
         // exit the loop.
         //
         if ( !(foundtuple = dlcursor_.moveNext()) )
            break;

         //
         // Got a tuple; does the task ID match the input task ID?
         // If not, then exit the loop.  Otherwise, continue at the
         // top of the loop.
         //
         ABTValue tupleTaskID = dlcursor_.getField(FLD_TASKID);
         if (!taskID.equals(tupleTaskID))
            break;
      }

      return found;
   }
}