

package com.abtcorp.hub;
import com.abtcorp.core.*;
import com.abtcorp.parser.*;
import java.util.Enumeration;

import java.lang.Math;


//=====================================
// internal classes
//=====================================
class ABTObjectSetSortedEnumerator implements Enumeration
{
//   protected ABTArray array_;
//   protected int count_;
   public ABTArray array_;
   public int count_;
   protected ABTSortOrderDefinition  mySortOrder;
   protected int contentType;
   protected ABTUserSession mySession;
   protected ABTObjectSet parent;

   public ABTObjectSetSortedEnumerator(ABTUserSession session, ABTObjectSet parent_, ABTSortOrderDefinition sortOrder)
   {
      if (sortOrder != null)
         mySortOrder = sortOrder;
//         mySortOrder = (ABTSortOrderDefinition)sortOrder.clone(session);
      contentType = ABTOSet.DATA_ACTIVE; // non-deleted elements only
      mySession = session;
      parent = parent_;
      refresh();
   }

   public ABTObjectSetSortedEnumerator(ABTUserSession session, ABTObjectSet parent_,ABTSortOrderDefinition sortOrder,int type)
   {
      if (sortOrder != null)
         mySortOrder = sortOrder;
//         mySortOrder = (ABTSortOrderDefinition)sortOrder.clone(session);
      contentType = type; // all elements
      mySession = session;
      parent = parent_;
      refresh();
   }

   private void destroy()
   {
    mySortOrder = null;
    array_.clear();
    array_ = null;
   }
   public void finalize()
   {
    destroy();
   }
   protected ABTObject get(int index)
   {
      if ((index < 0) || (index >= array_.size()))
         return null;
      return (ABTObject) array_.at(index);
   }




   private final void swap(int left, int right)
   {
      ABTObject ref = (ABTObject) array_.at(left);

      array_.put(left,array_.at(right));

      array_.put(right,ref);
   }

   private final int compare(int left, int right)
   {
      return mySortOrder.compare(get(left), get(right));
   }

   private final void sort(int lo, int hi)
   {
      if (hi < lo + 1) return;

      if (hi < lo + 8) {
         while (hi > lo) {
            int max = lo;

            for (int p = lo + 1; p <= hi; p++)
               if (compare(p, max) > 0) max = p;

            swap(max, hi--);
         }
      } else {
         int mid = (lo + hi) >> 1;

         swap(mid, lo);

         int loguy = lo, higuy = hi + 1;

         while (true) {
            do loguy++; while (loguy <= hi && compare(loguy, lo) <= 0);
            do higuy--; while (higuy >  lo && compare(higuy, lo) >= 0);

            if (higuy < loguy) break;

            swap(loguy, higuy);
         }

         swap(lo, higuy);

         if (higuy - lo > hi - loguy) {
            if (hi > loguy)      sort(loguy, hi);
            if (higuy > lo + 1)  sort(lo, higuy - 1);
         } else {
            if (higuy > lo + 1)  sort(lo, higuy - 1);
            if (hi > loguy)      sort(loguy, hi);
         }
      }
   }

   private final synchronized void sort()
   {
      if (array_.size() < 2) return;

      sort(0, array_.size() - 1);
   }

   private final void refresh()
   {
      array_ = parent.cloneData(mySession,contentType);
      if (mySortOrder != null)
          sort();
      count_ = 0;
   }



   public boolean hasMoreElements()
   {
      return count_ < array_.size();
   }

   public Object nextElement()
   {
      synchronized (array_)
      {
	      if (count_ < array_.size())
	      {
	         return (array_.at(count_++));
	      }
      }
      return new ABTErrorHub( "ABTObjectSet->ABTObjectSetSortedEnumerator->nextElement",
       errorMessages.ERR_17,"Cursor position in current sorted set on " + count_ + " beyond or on last element with index " + (array_.size()-1));
   }
}

