/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;

import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class VariantMunger
{
   static public ABTValue VariantToValue(Variant v)
      {
      ABTValue retVal = null;
      try {
      switch (v.getvt())
         {
         case Variant.VariantShort:
            retVal = new ABTShort(v.getShort());
            break;

         case Variant.VariantInt:
            retVal = new ABTInteger(v.getInt());
            break;

         case Variant.VariantDouble:
            retVal = new ABTDouble(v.getDouble());
            break;
         
         case Variant.VariantString:
            retVal = new ABTString(v.getString());
            break;

         case Variant.VariantBoolean:
            retVal = new ABTBoolean(v.getBoolean());
            break;

         case Variant.VariantDate:
            retVal = new ABTTime(v.getDate());
            break;

         case Variant.VariantDispatch:
         case Variant.VariantObject:
            {
            Object thing = v.toObject();
            if (thing instanceof IBaseJava)
               { retVal = ((ABTValue)((IBaseJava)thing).getObject()); }
            break;
            }
         }
      }catch (Exception e)
         { throw new com.ms.com.ComFailException(e.getMessage()); }

      v = null;   // release any strings or references
      return retVal;
      }

   static public Variant ValueToVariant(ABTValue val)
      {
      try {
         if (val == null)
            return new Variant(null);

         if (val instanceof ABTInteger)
            return new Variant(val.intValue());

         if (val instanceof ABTString)
            return new Variant(val.stringValue());

         if (val instanceof ABTBoolean)
            return new Variant(val.booleanValue());

         if (val instanceof ABTShort)
            return new Variant(val.shortValue());

         if (val instanceof ABTDouble)
            return new Variant(val.doubleValue());

         if (val instanceof ABTDate) {
            double ld = ((ABTDate)val).getJulian();
            return new Variant(Variant.VariantDate,ld);
            }

         if (val instanceof ABTTime) {
            double ld = ((ABTTime)val).getJulian();
            return new Variant(Variant.VariantDate,ld);
            }

         if (val instanceof ABTCalendar)
            return new Variant (Variant.VariantDispatch,new ABTCalendarCOM((ABTCalendar)val));

         if (val instanceof ABTCurve)
            return new Variant (Variant.VariantDispatch,new ABTCurveCOM((ABTCurve)val));

         if (val instanceof ABTError)
            return new Variant(Variant.VariantDispatch,new ABTErrorCOM((ABTError)val));

         if (val instanceof ABTEmpty)
            return new Variant(Variant.VariantDispatch,new ABTEmptyCOM((ABTEmpty)val));

         if (val instanceof ABTRemoteID)
            return new Variant(Variant.VariantDispatch,new ABTRemoteIDCOM((ABTRemoteID)val));

         if (val instanceof IABTSortedArray) {
            IABTSortedArray thing = (IABTSortedArray)val;
            ABTSortedArrayCOM cthing = new ABTSortedArrayCOM(thing);
            return new Variant(Variant.VariantDispatch,cthing);
            }

         if (val instanceof IABTArray) {
            IABTArray thing = (IABTArray)val;
            ABTArrayCOM cthing = new ABTArrayCOM(thing);
            return new Variant(Variant.VariantDispatch,cthing);
            }

         if (val instanceof IABTObjectSet){
            IABTObjectSet thing = (IABTObjectSet)val;
            ABTObjectSetCOM cthing = new ABTObjectSetCOM(thing);
            return new Variant(Variant.VariantDispatch,cthing);
            }

         if (val instanceof IABTObject) {
            IABTObject thing = (IABTObject)val;
            ABTObjectCOM cthing = new ABTObjectCOM(thing);
            return new Variant(Variant.VariantDispatch,cthing);
            }

         if (val instanceof IABTHashTable) {
            IABTHashTable thing = (IABTHashTable)val;
            ABTHashTableCOM cthing = new ABTHashTableCOM(thing);
            return new Variant(Variant.VariantDispatch,cthing);
            }


         // somebody got carried away with the high-level object stuff
         // I'll just mash it into a string and see how they like them apples
         return new Variant(val.toString());
      }catch (Exception e)
         { throw new com.ms.com.ComFailException(e.getMessage()); }
      }

}