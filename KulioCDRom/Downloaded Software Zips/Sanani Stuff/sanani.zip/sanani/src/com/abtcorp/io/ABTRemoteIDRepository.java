package com.abtcorp.io;

/*
 * ABTRemoteIDRepository.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-02-98      SOB           Initial Design
  * 08-10-98      MXA           Implement Serailizable.
  * 10-28-98      SOB           Implement toString()
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */
import java.io.Serializable;

import com.abtcorp.core.*;

/**
 *  ABTRemoteIDRepository class extends the the ABTRemoteID abstract class for repository drivers.
 *
 *  <pre>
 *			This class implements all methods of the ABTRemoteID abstract class.
 *       The purpose is to provide a way of uniquely identifying the remote source for
 *       an ABTObject.
 *
 *       Example:
 *			ABTRemoteIDRepository id = new ABTRemoteIDRepository();
 *
 *		   ...
 *
 *			id.setRepositoryID(1);
 *       id.setPrID(1024);
 *
 *       object = getSpace().createObject("ABTProject", id, "com.abtcorp.rulebase");
 *
 *       ...
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 */

public class ABTRemoteIDRepository extends ABTRemoteID implements Serializable
{
    private long repositoryID_;
    private long prID_;

   /**
    *		Create a default ABTRemoteIDRepository object.  If this
    *    constructor is used, the setRepositoryID() & setPrID() methods must be used
    *    subsequently to complete the construction of the object.
    */

    public ABTRemoteIDRepository()
    {
      repositoryID_ = 0;
      prID_ = 0;
    }

   /**
    *		Create a ABTRemoteIDRepository object using an input repository ID and prID.
    */

    public ABTRemoteIDRepository (long repositoryID, long prID)
    {
        repositoryID_ = repositoryID;
        prID_         = prID;
    }

   /**
    *		Get the repository ID component of this ABTRemoteIDRepository object.
    *
    */

    public long getRepositoryID() {return repositoryID_;}

   /**
    *		Set the repository ID component of this ABTRemoteIDRepository object.
    *    @param repositoryID The repository ID of with which this object is associated. This
    *    value, along with prID, uniquely identifies the source of the ABTObject.
    *
    */

    public void setRepositoryID(long repositoryID) {repositoryID_ = repositoryID;}

   /**
    *		Get the prID component of this ABTRemoteIDRepository object.
    *
    */

    public long getPrID() {return prID_;}

   /**
    *		Set the prID component of this ABTRemoteIDRepository object.
    *    @param prID The prID with which this object is associated.  This value,
    *    along with the repository ID, uniquely identifies the source of the
    *    ABTObject.
    *
    */

    public void setPrID(long prID) {prID_ = prID;}

    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return int 0 => equal, -1 => me < object2, 1 => me > object2
    */
    public int  compareTo  (Object object)
    {
      if (!(object instanceof ABTRemoteIDRepository))
         return -1;

      long repositoryID = ((ABTRemoteIDRepository)object).getRepositoryID();
      long prID = ((ABTRemoteIDRepository)object).getPrID();

      //
      // If both of the repository IDs are equal, and both of
      // the prIDs are equal, then the remote IDs are equal.
      //

      if (repositoryID_ == repositoryID &&
          prID_ == prID)
         return 0;

      //
      // IDs are not equal.  Is it the repository ID components that
      // are not the same?
      //

      if (repositoryID_ < repositoryID)
         return -1;
      else if (repositoryID_ > repositoryID)
         return +1;

      //
      // Repository IDs are equal; the prIDs are not equal.
      //

      return prID_ < prID ? -1 : +1;
    }


     /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    public boolean   equals (Object object)
    {
      return compareTo(object) == 0 ? true : false;
    }

	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */

   public int hashCode()
   {
      return toString().hashCode(); /*#553*/
   }

   /**
    *    Makes a String representation of an ABTRemoteIDRepository object.
    */
   public String toString()
   {
      return ( "(" + repositoryID_ + "," + prID_ + ")" );
   }
}