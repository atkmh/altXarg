package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ProjectPopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{

   protected	 ABTCursor 		teamCursor_;
   protected	 ABTCursor 		noteCursor_;
	protected    NotePopulator notePopulator_;
	
	protected String assignmentQuery_ = new String("SELECT PRAssignment.*, PRTask.prID, PRTask.prWBSSequence" +
				   			           					  " FROM PRAssignment, PRTask" +
      			   			 					        " WHERE PRAssignment.prTaskID = PRTask.prID" +
      				   		 					        " AND PRTask.prProjectID = %d" +
      					   	 					        " ORDER BY PRTask.prWBSSequence");

	public ProjectPopulator() {}
   public ProjectPopulator(ABTRepositoryDriver driver) {super(driver);}

   public ABTValue populate() throws ABTException
   {
      // get the object set of projects - we will add to this set
   	ABTObjectSet projects = getObjectSet(OBJ_TW_PROJECT);

      if (projects == null || cursor_ == null || cursor_.getRecordCount() == 0) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      // get the (one and only) user object in the object space
      ABTObject user = null;
      ABTValue value = getDriver().getSpace().getObjects(session_,OBJ_TW_USER);
      if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) {
         ABTObjectSet objects = (ABTObjectSet)value;
         if (objects.size(session_) > 0) user = (ABTObject)objects.at(session_,0);
      }

   	if (teamCursor_ != null) teamCursor_.moveFirst();
   	if (noteCursor_ != null) noteCursor_.moveFirst();
      if (notePopulator_ == null) notePopulator_ = new NotePopulator(getDriver(),OBJ_TW_PROJECT, getSpace(), getSession());

   	// move through the project cursor adding each project to the object space
   	while(cursor_.moveNext()) {

         // if the project is already in the object space, continue
         ABTValue temp = projects.select(session_, FLD_TW_ID + " = " + cursor_.getField(FLD_ID));
         if (!ABTError.isError(temp) && !ABTValue.isEmpty(temp)) {
            if (((ABTObjectSet)temp).size(session_) > 0) continue;
         }

         // add the project to the object space
   		ABTObject project = (ABTObject)addObject(projects);

         // add the tasks for this project to the object space
   		addTasksForProject(project);

			// link project to resources that are team members
   		createProjectTeams(project);

   		// check if user has edit project plan rights over this project
      	checkProjectRight(CAN_EDITPROJECTPLAN, project, user, FLD_TW_EPP_PROJECTS);

      	// check if user has project manager rights over this project
   		checkProjectRight(IS_PROJECTMANAGER, project, user, FLD_TW_MGR_PROJECTS);

         // add the notes for this project to the object space
   		addNotesForProject(project);

         updateStatus(project);
      }

      closePopulatorCursor();

   	if (noteCursor_ != null) noteCursor_.release();
      noteCursor_ = null;

   	if (teamCursor_ != null) teamCursor_.release();
      teamCursor_ = null;

      return projects;
   }

   protected final String getTaskNoteQuery(ABTObject project) throws ABTException
   {
      return new String("SELECT PRNote.*, PRTask.prID, PRTask.prProjectID, PRTask.prWBSSequence FROM PRNote, PRTask" +
      						 " WHERE PRNote.prTableName = 'PRTask'" +
      						 " AND PRNote.prRecordID = PRTask.prID" +
      						 " AND PRTask.prProjectID = " + project.getValue(session_,FLD_TW_ID,null).intValue() +
      						 " ORDER BY PRTask.prWBSSequence ASC, PRNote.prModTime DESC");
   }

   protected final String getTaskAssignmentQuery(ABTObject project) throws ABTException
   {
      int[] ids = new int[1];
      ids[0] = project.getValue(session_,FLD_TW_ID,null).intValue();
      return TWPopulator.substitute(ids, assignmentQuery_);
   }

   public final void setTaskAssignmentQuery(String query) { assignmentQuery_ = query; }

   public final void setTeamCursor(String query)
	{
		teamCursor_ = getDriver().getRepository().select(query);
	}

	public void setNoteCursor(String query)
	{
		noteCursor_ = getDriver().getRepository().select(query);
	}
	
   protected ABTValue addObject(ABTObjectSet projects)
   {
      ABTObject project = (ABTObject)projects.addNew(session_);

      project.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
      project.setValue(session_,FLD_TW_NAME,cursor_.getField(FLD_NAME));
      project.setValue(session_,FLD_TW_EXTERNALID,cursor_.getField(FLD_EXTERNALID));
      project.setValue(session_,FLD_TW_GUIDELINES,cursor_.getField(FLD_GUIDELINES));
      project.setValue(session_,FLD_TW_MANAGER,cursor_.getField(FLD_MANAGER));
      project.setValue(session_,FLD_TW_START,cursor_.getField(FLD_START));
      project.setValue(session_,FLD_TW_FINISH,cursor_.getField(FLD_FINISH));
      project.setValue(session_,FLD_TW_PCTCOMPLETE,cursor_.getField(FLD_PCTCOMPLETE));

   	// hook in the charge code object
   	int index = chargeCodes_.indexOf(new Integer(cursor_.getFieldInt(FLD_CHARGECODEID)));
   	if (index != -1) project.setValue(session_,FLD_TW_CHARGECODE,(ABTValue)chargeCodes_.at(index));

      RemoteID.setRemoteID(project,session_);
      return project;
   }

   
	protected void addTasksForProject(ABTObject project)
	{
		TaskPopulator taskPopulator = new TaskPopulator(getDriver(), project, getSpace(), getSession());
	
		try {
			taskPopulator.setNoteCursor(getTaskNoteQuery(project));
			taskPopulator.setAssignmentCursor(getTaskAssignmentQuery(project));
			taskPopulator.setPopulatorCursor("select * from PRTask where prProjectID=" + project.getValue(session_,FLD_TW_ID,null).intValue() + " order by prWBSSequence", false);
		   taskPopulator.populate();
      } catch (Exception e) {
      }
		
	}
	
	protected void checkProjectRight(String right, ABTObject project, ABTObject user, String fieldName)
	{
      if (checkRight(cursor_,right)) {
         ABTValue set = user.getValue(session_,fieldName,null);
         if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
            // Maintain uniqueness of the set.
            if (((ABTObjectSet)set).contains(session_,project)) return;
            ((ABTObjectSet)set).add(session_,project);
         }
      }
	}

	protected void createProjectTeams(ABTObject project)
	{
		if (teamCursor_ != null) {

			while (teamCursor_.isValid() && (teamCursor_.getField(FLD_PROJECTID).intValue() <= project.getValue(session_, FLD_TW_ID).intValue())) {

		      if (project.getValue(session_, FLD_TW_ID).intValue() == teamCursor_.getField(FLD_PROJECTID).intValue()) {

		      	int id = teamCursor_.getFieldInt(FLD_RESOURCEID);
		      	int idx = resources_.indexOf(new Integer(id));
		      	if (idx >= 0) {
		      		ABTObject resource = (ABTObject)resources_.at(idx);
               	ABTValue value = resource.getValue(session_, FLD_TW_PROJECTS);
               	ABTObjectSet projects = null;
		            if (ABTValue.isEmpty(value) || ABTError.isError(value) || value == null) {
                     // Resource doesn't have an object set of projects defined yet.
                     projects = (ABTObjectSet)getDriver().getSpace().createObjectSet(getSession(),OBJ_TW_PROJECT);
                     resource.setValue(getSession(),FLD_TW_PROJECTS,projects);
                  } else {
                     projects = (ABTObjectSet)value;
                  }

	         	   // Maintain uniqueness of the set.
  		            if (projects.contains(session_,project)) return;
   	            projects.add(session_,project);
	            }
		      }
				teamCursor_.moveNext();
			}
		}
		return;
	}

	protected void addNotesForProject(ABTObject project)
	{
		if (noteCursor_ != null) {

			int noteID = 0;
			while (noteCursor_.isValid() && (noteCursor_.getField(FLD_RECORDID).intValue() <= project.getValue(session_, FLD_TW_ID).intValue())) {

		      if (project.getValue(session_, FLD_TW_ID).intValue() == noteCursor_.getField(FLD_RECORDID).intValue()) {
		      	if (noteCursor_.getField(FLD_ID).intValue() != noteID) notePopulator_.addObject(project, noteCursor_);
		      	noteID = noteCursor_.getField(FLD_ID).intValue();
		      }
				noteCursor_.moveNext();
			}
		}
		return;
	}
}