
package com.abtcorp.hub;

/*
 * ABTID.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	 HJB		        Initial Design
  * 08-05-98    MXA             Add Serializable.
  * 10-09-98    SOB             Remove tilde character from unique ID generation
  * 10-26-98    MXA             Added transient to the "parent" member.
  * 11-12-98    SOB             Remove space character from unique ID generation
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;
import com.abtcorp.idl.IABTPropertyType;

/**
 *  ABTID  is allows common identification of ABT's real world objects
 *  (e.g. Task, Project ....) and carries local, remote and original identification
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */

public class ABTID extends ABTValue implements Serializable
{

	/**
	 *	my_localID : set/maintained by the objectspace to uniqule identify a "real world" object
	 */
	 private int my_localID = 0;

     /**
     * parent ABTObject
     */
     private transient ABTObject parent = null;


//==========================================================================================
  /**
   * default constructor
   */
    protected ABTID (int id)
       {
	      my_localID = id;
       }


  /**
   * internal function to set the ABTObject-parent
   */
    protected void setParent (ABTObject parent_)
       {
	      parent = parent_;
       }

   /**
    * set the remote ID - !immutable only valid ONCE
    * @param id - remote ID
    * @return ABTError if already set or null if successfull
    */
    public ABTError setRemote(ABTUserSession session,ABTRemoteID id)
    {
        if (parent == null)
            return
                new ABTErrorHub("ABTID->setRemote",errorMessages.ERR_4,"Parent ABTObject not set");
        ABTValue val = parent.setValue(session,IABTPropertyType.PROP_REMOTEID,id,null);
        if (ABTError.isError(val))
            return (ABTError)val;
        return null;
    }
   /**
    * set the original ID- !immutable only valid ONCE
    * @param id - original ID
    * @return ABTError if already set or null if successfull
    */
    public ABTError setOriginal(ABTUserSession session,ABTRemoteID id)
    {
        if (parent == null)
            return
                new ABTErrorHub("ABTID->setOriginal",errorMessages.ERR_4,"Parent ABTObject not set");
        ABTValue val = parent.setValue(session,IABTPropertyType.PROP_ORIGINALID,id,null);
        if (ABTError.isError(val))
            return (ABTError)val;
        return null;
    }

    /**
    *  get the combinedID
    * @return Object - local id or NULL if unknown
     */
    public int getLocal()
    {
       return my_localID;
    }

    /**
     * Returns a generated unique id.
     *
     * @return unique id as a String
     */
    public String getUniqueId()
    {
      //
      // Force the usage of the StringBuffer's constructor which takes a String argument.  Later,
      // the space character will be removed.
      //
      StringBuffer buf = new StringBuffer(" " + System.currentTimeMillis());
      //buf.append("." + my_localID + "~");     // tilde character causes PRAPI bsearchfirst() problems  SOB
      buf.append("." + my_localID);
      return buf.reverse().toString().trim();   // remove any leading/trailing whitespace
    }

    /**
    *  get the remote ID
    * @return Object - remote id or NULL if unknown
     */
    public ABTValue getRemote(ABTUserSession session)
       {
        if (parent == null)
            return
                new ABTErrorHub("ABTID->getRemote",errorMessages.ERR_4,"Parent ABTObject not set");
        return parent.getValue(session,IABTPropertyType.PROP_REMOTEID,null);
       }
     /**
    *  get the Original ID
    * @return Object - original id or NULL if unknown
    */
    public ABTValue getOriginal(ABTUserSession session)
    {
        if (parent == null)
            return
                new ABTErrorHub("ABTID->getOriginal",errorMessages.ERR_4,"Parent ABTObject not set");
        return parent.getValue(session,IABTPropertyType.PROP_ORIGINALID,null);
    }
     /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    public boolean equals   (Object object)
   {
      if (object instanceof ABTID)
      {
         return (getLocal() == ((ABTID)object).getLocal());
      }
      return false;

   }

  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compareTo  (Object  object)
   {
      if (object == null) return 1;
      if (object instanceof ABTID)
      {
            if (getLocal() == ((ABTID)object).getLocal())
               return 0;
            else
               return getLocal() < ((ABTID)object).getLocal() ? -1 : +1;
      }
      return 0;
   }

	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */
	public int hashCode()
	{
		return (int)getLocal();
	}





}