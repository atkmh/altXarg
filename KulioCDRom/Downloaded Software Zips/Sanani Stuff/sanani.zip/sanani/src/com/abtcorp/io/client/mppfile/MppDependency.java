package com.abtcorp.io.client.mppfile;

import com.abtcorp.autowrap.msproject.*;

public class MppDependency
{

   public   Task              successorMppTask_;
   private  int               successorUniqueId_;
   private  MppPredecessor    mppPredecessor_;

   public MppDependency(Task successorTask, MppPredecessor mppPredecessor)
   {
      successorMppTask_    =  successorTask;
      successorUniqueId_   =  successorTask.getUniqueID();
      mppPredecessor_      =  mppPredecessor;

   }

   public MppPredecessor getMppPredecessor()
   {
      return mppPredecessor_;
   }

   public   int getSuccessorUniqueId()
   {
      return successorUniqueId_;
   }

   public   int getPredecessorUniqueId()
   {
      return  mppPredecessor_.predecessorUniqueId_;
   }

   public   int getType()
   {
      return  mppPredecessor_.type_;
   }

   public   char getOperator()
   {
      return  mppPredecessor_.operator_;
   }

   public   double getLagOrLead()
   {
      return  mppPredecessor_.lagOrLead_;
   }

   public   int getPercentOrAmount()
   {
      return  mppPredecessor_.percentOrAmount_;
   }

}
