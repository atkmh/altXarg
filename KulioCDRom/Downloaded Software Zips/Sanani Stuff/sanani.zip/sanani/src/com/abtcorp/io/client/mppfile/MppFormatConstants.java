package com.abtcorp.io.client.mppfile;

public interface MppFormatConstants
{

   //Constraints
   public static final int pjASAP   =  0;
   public static final int pjALAP   =  1;
   public static final int pjFNET   =  6;
   public static final int pjFNLT   =  7;
   public static final int pjMFO    =  3;
   public static final int pjMSO    =  2;
   public static final int pjSNET   =  4;
   public static final int pjSNLT   =  5;

   // Types of dependencies (PRDepend.Type)
   public static final int PR_FIN_START_DEP 	  = 0;
   public static final int PR_START_START_DEP  = 1;
   public static final int PR_FIN_FIN_DEP 	  = 2;
   public static final int PR_START_FIN_DEP 	  = 3;

   // Types of dependency amount units (PRDepend.AmountType)
   public static final int PR_DAILY_DEPENDENCY   =	0;
   public static final int PR_PERCENT_DEPENDENCY =	1;

   public static final int MINUTES = 1;
   public static final int HOURS   = 2;
   public static final int DAYS    = 3;
   public static final int WEEKS   = 4;
   public static final int MONTHS  = 5;
   public static final int YEARS   = 6;
   public static final int NONE    = 7;


   public static final int pjDayMonthYear =  0;
   public static final int pjMonthDayYear =  1;
   public static final int pjYearMonthDay =  2;



}