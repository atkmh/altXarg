

package com.abtcorp.hub;

interface IABTTransactionData
{
      IABTTransactionData rollUp(IABTTransactionData target);

      IABTTransactionData copyData();
}
