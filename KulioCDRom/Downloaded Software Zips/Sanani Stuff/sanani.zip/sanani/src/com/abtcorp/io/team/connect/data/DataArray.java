package com.abtcorp.io.team.connect.data;

import com.abtcorp.core.ABTArray;
import java.io.Serializable;

public class DataArray extends ABTArray implements Serializable
{
   private static final long serialVersionUID = -8718961680604147447L;
   
   public DataArray() {super();}
   
   public synchronized Object match(Object object)
   {
      int index = indexOf(object);

      if (index < 0) add(object);
      else           object = at(index);

      return object;
   }
   
   public final synchronized Object find(Object object)
   {
      int index = indexOf(object);

      if (index < 0) return null;

      return at(index);
   }
}
