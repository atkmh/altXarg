package com.abtcorp.io.siterepo;

/*
 * AggregateField.java 06/22/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-22-98    LZX         Initial Implementation
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  AggregateField is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTSiteRepoDriver.
 *
 *  <pre>
 *       AggregateField rt = new AggregateField(driver, cfield);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         Method
 */

public class AggregateField extends ABTSiteRepoHelper
{
   Hashtable custHash_ = null;
   ABTCursor custCursor_;

/**
 * AggregateField constructor.
 * @param driver: the reference to the driver.
 * @param parent: the parent (site or custom field) object that owns the agg fields. 
 * @param custCursor: the custom field cursor.
 */
   AggregateField(ABTRepositoryDriver driver, ABTObject parent, ABTCursor custCursor)
   {
      super(driver, parent, TBL_MRAGGREGATEFIELD, OBJ_AGGREGATEFIELD);
      custCursor_ = custCursor;
      matchField_ = null;
   }

/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(ABTCursor cur, String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
      // find source custom field object in the space (first match by remote id, then by name)
      // if object is found, but it didn't come from the same repository, skip it.
      int fldID = cur.getFieldInt(FLD_SOURCEFIELDID);
      ABTObject obj = (ABTObject)findObject(OBJ_CUSTOMFIELD, FLD_NAME, fldID, custCursor_);
      
      if (obj == null)
         processError("create",
                   errorMessages.ERR_OBJECT_NOT_FOUND,
                   "Source custom field not found in object space. id = " + fldID  );
      
      if (getRepoID(obj) != repo_.getID())
         return null;
      // set the source custom field object references.
      reqParams_.putItemByString(OFD_SOURCEFIELD, obj);

      // find target custom field object in the space (first match by remote id, then by name)
      // if object is found, but it didn't come from the same repository, skip it.
      fldID = cur.getFieldInt(FLD_TARGETFIELDID);
      obj = (ABTObject) findObject(OBJ_CUSTOMFIELD, FLD_NAME, fldID, custCursor_);

      if (obj == null)
         processError("create",
                   errorMessages.ERR_OBJECT_NOT_FOUND,
                   "Target custom field not found in object space. id = " + fldID  );
            
      if (getRepoID(obj) != repo_.getID())
         return null;
      // set the target custom field object references.
      reqParams_.putItemByString(OFD_TARGETFIELD, obj);

      return (super.create(cur, type, id, reqParams_));
   }


/**
 * Sets cursor values.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// first set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);
		
		// for new records, get source and target custom field id and set them.
		if (isNew)
		{
		   ABTValue val = getValue(obj, OFD_SOURCEFIELD);
		   if (ABTValue.isNull(val) || !(val instanceof ABTObject))
            processError("setCursorValues", 
                        errorMessages.ERR_OBJECT_NOT_FOUND, 
                        "source field is null, empty, or is not an ABTObject.");	   	   
      	else
      	   cursorSetField(cur, FLD_SOURCEFIELDID, getValue((ABTObject)val, OFD_ID));
      
		   val = getValue(obj, OFD_TARGETFIELD);
		   if (ABTValue.isNull(val) || !(val instanceof ABTObject))
            processError("setCursorValues", 
                        errorMessages.ERR_OBJECT_NOT_FOUND, 
                        "target field is null, empty, or is not an ABTObject.");	   	   
      	else
      	   cursorSetField(cur, FLD_TARGETFIELDID, getValue((ABTObject)val, OFD_ID));
      
   	}
   }
   

/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      // NOTE: may not need this since agg fields are always saved as new???
      // prSourceFieldID and prTargetFieldID can not be modified after add-new
      if (!isNew && (prapiName.equals(FLD_SOURCEFIELDID) || prapiName.equals(FLD_TARGETFIELDID)))    
         return true;
         
      return super.isSaveException(prapiName, obj, prapiFlags, isNew);            
   }

}