package com.abtcorp.io.client.methfile;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.io.client.methfile".intern();
public static final ABTErrorCode ERR_WRONG_CAST = new ABTErrorCode(Package, "ERR_WRONG_CAST", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_EXPECTED_IABTHashTable = new ABTErrorCode(Package, "ERR_EXPECTED_IABTHashTable", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_EXPECTED_IABTLocalID = new ABTErrorCode(Package, "ERR_EXPECTED_IABTLocalID", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_TYPE = new ABTErrorCode(Package, "ERR_INVALID_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_EXCEPTION_OCCURED = new ABTErrorCode(Package, "ERR_EXCEPTION_OCCURED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_EXPECTED_IABTObject = new ABTErrorCode(Package, "ERR_EXPECTED_IABTObject", UNRECOVERABLE_ERROR );


}