package com.abtcorp.io.PMWRepo;

/*
 * ABTProjectPopulator.java 05/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 05-13-98    SOB         Initial Implementation
 * 05-14-98    SOB         Mods to support new project/task collection items from Widgeon
 * 05-20-98    SOB         Mods to support only reading FLD_CALENDAR for projects and resources
 * 05-20-98    SOB         Mods to support setValue() by index instead of by name
 * 05-21-98    SOB         Mods to support task constraints
 * 05-22-98    SOB         Relocate 3 useful methods to ABTDriver & ABTRepository driver classes
 * 05-26-98    SOB         Mods to support task estimates
 * 05-26-98    SOB         Some constants are now retrieved from IABTPMRuleConstants
 * 05-27-98    SOB         Mods to support custom field values for project and task objects
 * 05-27-98    SOB         Mods to support deliverables for a project and its tasks
 * 05-29-98    SOB         Mods to support subprojects
 * 06-24-98    SOB         Mods to support helper objects
 * 07-09-98    SOB         Mods to support transactions
 * 08-31-98    SOB         Mods to support thinly populated projects
 * 10-30-98    SOB         Mods to support interproject dependencies; populating subproject links happens before dependencies
 * 11-19-98    SOB         Mods to support using the Site Repo Driver's Resource populator
 * 12-14-98    SOB         #667
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTShort;

/**
 *  ABTProjectPopulator is a helper class for the ABT Repository driver for the PMW application.
 *  It is instantiated by the driver application and by itself when a helper class object 
 *  (e.g., ABTIOPMWRepoSubProject)
 *  determines that another subproject or related project needs to be populated.
 *
 *  <pre>
 *       ABTPProjectPopulator pp = new ABTProjectPopulator(ABTDriver driver,
 *                                                         ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTPMWRepoDriver
 */

public class ABTProjectPopulator implements ABTNames, 
                                            ABTEnum, 
                                            IABTDriverConstants,
                                            IABTPMWRepoConstants,
                                            IABTPMRuleConstants
{
   private ABTRepoDataDictionary dataDictionary_ = null;
   private Vector taskVector_ = null;
   private Hashtable taskHash_ = null;
   private Hashtable resourceHash_ = null;
   private Hashtable assignmentHash_ = null;
   private Hashtable estModelHash_ = null;
   private ABTObject curProject_ = null;
   private ABTRepositoryDriver driver_;
   private ABTValue selector_;
   private String extID_ = null;
   private long projectID_ = -1;
   private boolean masterProject_ = false;
   private int howToPopulate_ = PM_UNKNOWN;
   private boolean acquireLock_ = false;
   private boolean relaxSubprojectLocking_ = false;    /* #667 */
   private IABTInternalProgressListener progress_ = null;

   public ABTProjectPopulator(ABTRepositoryDriver driver,
                              ABTValue selector,
                              int howToPopulate,
                              boolean acquireLock,
                              boolean relaxSubprojectLocking,
                              IABTInternalProgressListener progress)
   {
      driver_ = driver;
      selector_ = selector;
      howToPopulate_ = howToPopulate;
      acquireLock_ = acquireLock;
      relaxSubprojectLocking_ = relaxSubprojectLocking;    /* #667 */
      progress_ = progress;

      //
      // Get the repository data dictionary
      //
      if (dataDictionary_ == null) dataDictionary_ = new ABTRepoDataDictionary();
     	if (!dataDictionary_.isValid()) dataDictionary_.createRepoDataDictionary(driver_.getSession());

      //
      // If the selector_ is an instance of ABTString, it contains the project's
      // external ID, the project is a master project, and it should be fully loaded 
      // into the object space.
      //
      // If the selector_ is an instance of ABTInteger, it contains the project's
      // prID, the project is a subproject, and the project may need to be only partially loaded.  
      // In this case, the project is read-only.
      //
      // TO DO: Devise a mechanism to partially load a project to support subproject
      //        loading.
      //
      if (selector_ instanceof ABTString)
      {
         extID_ = selector_.stringValue();
         masterProject_ = true;
         return;
      }
      else if (selector_ instanceof ABTInteger)
      {
         projectID_ = selector_.intValue();
         return;
      }

      //
      // TO DO:  selector_ is something else.  Figure out how to populate the
      //         project based on what the selector_ is, i.e., see Zane S.!
      //
   }

   public ABTValue populate() throws ABTException
   {
      ABTValue object = null;    // local handle for results
      boolean lockAcquired = false;
      boolean isFullyPopulated = false;
      boolean isReadOnly = false;
      
      ABTIOPMWRepoProject rp = new ABTIOPMWRepoProject(driver_.getSpace(),
                                                       driver_,
                                                       extID_,
                                                       projectID_,
                                                       masterProject_,
                                                       progress_);

      // populate object space and object set with fields from the project cursor...

      try
      {
         // Acquire a lock on the project if the caller specified to do so.  
         //
         // Note that the semantics for the acquireLock_ and lockAcquired variables are slightly different.
         // acquireLock_ is true if the caller specified that the project needs to be checked out of the
         // repository with a lock.  The logged on user may have the lock already from a previous check out,
         // in which case, the lock will NOT be acquired again.  The lockAcquired variable is true if the lock 
         // was newly-acquired with this populate process.  It is checked if an ABTException is thrown so that 
         // the lock may be released.
         //
         // If a lock must be acquired, but it cannot be obtained (and is not already held by the user), make
         // further checks.  If the project is being populated by its external ID (i.e., it's a "master," or
         // initial, project), we must throw an error indicating the lock cannot be acquired.  If it's not a
         // "master," and the caller indicated to relax subproject locking requirements, bypass throwing an
         // error, and indicate that the project should be loaded as READONLY.
         //
         if (acquireLock_)
         {
            int lockStatus = rp.acquireLock(extID_, projectID_);
            if ( lockStatus == LOCK_ACQUIRED )
               lockAcquired =  true;
            else if ( lockStatus != LOCK_ALREADY_HELD )
            {
               if ( !masterProject_ && relaxSubprojectLocking_ )  /* #667 */
                  isReadOnly = true;  /* #667 */
               else if ( masterProject_ ) /* #667 */  
                  throw new ABTException( new ABTError(COMP_PMREPODRIVER, 
                                                    "ProjectPopulator->populate", 
                                                    errorMessages.ERR_PROJECT_LOCKED_BY_ANOTHER, 
                                                    null) );
               else                                      
                  throw new ABTException( new ABTError(COMP_PMREPODRIVER, /* #667 */
                                                    "ProjectPopulator->populate", 
                                                    errorMessages.ERR_SUBPROJECT_LOCK, 
                                                    null) );
            }
         }
         
         object = rp.populate(null);
         
         //
         // If the populate operation failed because the user did not have rights to read the project,
         // return that as an error to the caller.
         if ( ABTError.isError( object ) )
         {
            ABTError err = (ABTError) object;
            ABTErrorCode errCode = err.getErrorCode();
            if ( errCode.equalTo( errorMessages.ERR_NO_VIEW_RIGHT ) )
               return err;
            else
               throw new ABTException( err );
         }
         
         //
         // If we didn't populate a project in this invocation, throw an exception.
         // This may be too harsh.
         //
         if (object == null) throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                                  "ProjectPopulator->populate",
                                                                  errorMessages.ERR_PROJECT_NOT_FOUND,
                                                                  null) );

         //
         // If the project has already been fully populated and it's a subproject, i.e.,
         // it's not a master project, merely return it to the caller.  This only works because
         // currently, all subprojects are fully loaded the first time they are encountered.
         // In the future, for performance reasons, subprojects will need to be thinly loaded.
         //
         // TO DO: Resolve project refresh issues, i.e., when should an existing object be
         //        refreshed from the repository vs. when should we merely return the
         //        existing project to the caller?  
         //
         
         ABTValue v = rp.getValue((ABTObject)object, OFD_ISFULLYPOPULATED);
         if (!ABTValue.isNull( v ) && v.booleanValue() )
            isFullyPopulated = true;
         
         if ( isFullyPopulated )
         {
            rp.setValue((ABTObject) object, OFD_READONLY, new ABTBoolean(isReadOnly));  /* #667 */
            return object;
         }
            
         /*
         if (object instanceof ABTObject && 
             !masterProject_ )
         {    
               if ( isFullyPopulated )
                  return object;
         }
         */
         
         ABTObject projObject = (ABTObject) object; // explicit cast

         curProject_ = projObject;                 // save current project reference
         	
         //
         // If we are only populating a thin project, return the project object now.
         //
         if (howToPopulate_ == PM_PROJECTONLY) return curProject_;
      	
      	long projID = projObject.getValue(driver_.getUserSession(),OFD_ID).intValue();

      	// #613
      	// If we are only populating projects thinly with project-related custom field value
      	// objects, do that now.  Note that the absence of a task object hash table will
      	// force the custom field value helper class to skip loading custom field values
      	// for the project's tasks.
      	// #613
      	if (howToPopulate_ == PM_PROJECTANDCUSTFIELDSONLY) /* #613 */
      	{
         	ABTIOPMWRepoCustomFieldValue cfv = new ABTIOPMWRepoCustomFieldValue(driver_.getSpace(),
         	                                                                    driver_,
         	                                                                    projObject,
         	                                                                    projID,
         	                                                                    null,  // no task hash table
         	                                                                    progress_);
            cfv.populate(null);
            cfv = null;       // for garbage collection
        	   return curProject_;
      	}
      	
      	//
      	// Retrieve the tasks associated with this project and populate the space with them.
      	//

         ABTIOPMWRepoTask rt = new ABTIOPMWRepoTask(driver_.getSpace(),
                                                    driver_,
                                                    projObject,
                                                    projID,
                                                    progress_);

      	//System.out.println("Populating tasks at " + new Date() );
      	
      	object = rt.populate(null);
      	if (ABTError.isError(object)) throw new ABTException( (ABTError)object );
         
         //
         // If we are only populating thin projects with their tasks only, then return the project object now.
         //
         if (howToPopulate_ == PM_PROJECTANDTASKSONLY) return curProject_;
         
         taskHash_ = rt.getTaskHashtable();
         
      	//
      	// Retrieve the subprojects associated with this project.
      	//
      	boolean parentLock = (acquireLock_ && !isReadOnly);
      	ABTIOPMWRepoSubProject rspl = new ABTIOPMWRepoSubProject(driver_.getSpace(),
      	                                                         driver_,
      	                                                         projObject,
      	                                                         projID,
      	                                                         taskHash_,
      	                                                         parentLock,                /* #667 */
      	                                                         relaxSubprojectLocking_,   /* #667 */
      	                                                         progress_);
      	//System.out.println("Populating subprojects at " + new Date() );
      	
         object = rspl.populate(null);      	                                                         
         if (ABTError.isError(object)) throw new ABTException( (ABTError)object );
         
      	//
      	// Retrieve the dependencies associated with this project.
      	//

      	ABTIOPMWRepoDependency rd = new ABTIOPMWRepoDependency(driver_.getSpace(),
      	                                                       driver_,
      	                                                       projObject,
      	                                                       projID,
      	                                                       taskHash_,
      	                                                       parentLock,               /* #667 #683 */
      	                                                       relaxSubprojectLocking_,  /* #667 #683 */
      	                                                       progress_);
      	//System.out.println("Populating dependencies at " + new Date() );
      	
         object = rd.populate(null);
         if (ABTError.isError(object)) throw new ABTException( (ABTError)object );
         
      	//
      	// Retrieve the team members and resources associated with this project.  This
      	// is accomplished by instantiating a team populating helper object, which, in turn,
      	// will cause a Site Repo Driver Resource helper object to be instantiated.
      	//

      	ABTIOPMWRepoTeam rtm = new ABTIOPMWRepoTeam(driver_.getSpace(),
      	                                           driver_,
      	                                           projObject,
      	                                           projID,
      	                                           progress_);
      	
      	//System.out.println("Populating teams and resources at " + new Date() );
      	
      	object = rtm.populate(null);
      	if (ABTError.isError(object)) throw new ABTException( (ABTError)object );
         resourceHash_ = getResourceHashtable();

      	//
      	// Retrieve the assignments associated with this project.
      	//
      	ABTIOPMWRepoAssignment ra = new ABTIOPMWRepoAssignment(driver_.getSpace(),
      	                                           driver_,
      	                                           projObject,
      	                                           projID,
      	                                           taskHash_,
      	                                           resourceHash_,
      	                                           progress_);
      	
      	//System.out.println("Populating assignments at " + new Date() );
      	
      	object = ra.populate(null);
      	if (ABTError.isError(object)) throw new ABTException( (ABTError)object );
         assignmentHash_ = ra.getAssignmentHashtable();

      	//
      	// Retrieve the constraints associated with the tasks of this project.
      	//
      	ABTIOPMWRepoConstraint rc = new ABTIOPMWRepoConstraint(driver_.getSpace(),
      	                                                       driver_,
      	                                                       projObject,
      	                                                       projID,
      	                                                       taskHash_,
      	                                                       progress_);
      	//System.out.println("Populating constraints at " + new Date() );
      	
         rc.populate(null);      	                                                       

      	//
      	// Retrieve and populate the project's estimating model.
      	//
      	ABTIOPMWRepoEstimatingModel rem = new ABTIOPMWRepoEstimatingModel(driver_.getSpace(),
      	                                                                  driver_,
      	                                                                  projObject,
      	                                                                  projID,
      	                                                                  progress_);
      	//System.out.println("Populating estimating models at " + new Date() );
      	
         object = rem.populate(null);      	                                                                  
      	if (ABTError.isError(object)) throw new ABTException( (ABTError)object );

      	estModelHash_ = rem.getEstModelHashtable();
      	
      	//
      	// Retrieve and populate task estimates.  This will establish links between task
      	// objects and estimating model objects.
      	//
      	ABTIOPMWRepoTaskEstimate te = new ABTIOPMWRepoTaskEstimate(driver_.getSpace(),
      	                                                           driver_,
      	                                                           projObject,
      	                                                           projID,
      	                                                           estModelHash_,
      	                                                           taskHash_,
      	                                                           progress_);
      	
      	//System.out.println("Populating task estimates at " + new Date() );
      	
      	te.populate(null);
      	
      	//
      	// Retrieve the custom field values for the project. In general, any repository
      	// table can have custom field values for its tuples.  However, for purposes of
      	// this driver, only project and task objects will have custom field values.
      	//
      	ABTIOPMWRepoCustomFieldValue cfv = new ABTIOPMWRepoCustomFieldValue(driver_.getSpace(),
      	                                                                    driver_,
      	                                                                    projObject,
      	                                                                    projID,
      	                                                                    taskHash_,
      	                                                                    progress_);
      	//System.out.println("Populating custom field values at " + new Date() );
      	
         cfv.populate(null);
     	
      	//
      	// Retrieve and populate deliverable objects.
      	//
         ABTIOPMWRepoDeliverable rdlv = new ABTIOPMWRepoDeliverable(driver_.getSpace(),
                                                                         driver_,
                                                                         projObject,
                                                                         projID,
                                                                         taskHash_,
                                                                         progress_);
      	//System.out.println("Populating deliverables at " + new Date() );
      	
         object = rdlv.populate(null);                                                                         
      	if (ABTError.isError(object)) throw new ABTException( (ABTError)object );

      	//
      	// Retrieve the notes associated with this project.
      	//
         ABTIOPMWRepoNote rnote = new ABTIOPMWRepoNote(driver_.getSpace(),
                                                       driver_,
                                                       projObject,
                                                       projID,
                                                       taskHash_,
                                                       resourceHash_,
                                                       assignmentHash_,
                                                       progress_);
      	//System.out.println("Populating notes at " + new Date() );
      	
         rnote.populate(null);
      
         //
         // Likewise, tag the project as FULLYPOPULATED.
         //
         rp.setValue(projObject, OFD_ISFULLYPOPULATED, new ABTBoolean(true));
         isFullyPopulated = true;
         
         //
         // If we are checking out the project with a lock, increment the project's version # by 1.
         // If the project's version was never set, set it to one.
         //
         if ( acquireLock_ && !isReadOnly ) /* #667 */
         {
            ABTValue version = rp.getValue(projObject, OFD_VERSION);
            short ver = (version == null || version instanceof ABTEmpty) ? 0 : version.shortValue();
            rp.setValue(projObject, OFD_VERSION, new ABTShort((short)(ver + 1)));
            //
            // Tag the project as READ/WRITE.
            //
            rp.setValue(projObject, OFD_READONLY, new ABTBoolean(false)); /* #667 */
         }
            
         return curProject_;
      }                    // end try block
      catch (ABTException e)
      {
         //
         // Since we are in an error situation, if we acquired a lock on the
         // project, we must release it now.
         //
         if (lockAcquired)
            rp.releaseLock(extID_);
         
         throw e;
      }
      catch (Throwable t)
      {
         /*#643*/
         if (lockAcquired)
            rp.releaseLock(extID_);
         
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "ABTProjectPopulator",
                                              errorMessages.ERR_EXCEPTION_OCCURRED,
                                              t) );
      }
      finally
      {
         //
         // Drop references to temporary Vector and Hashtable objects.
         //

         taskVector_ = null;
         taskHash_ = null;
         resourceHash_ = null;
         assignmentHash_ = null;
         estModelHash_ = null;

         //
         // If the project was fully populated, then many populate-related resources need to
         // be cleaned up.  Give the Java garbage collector a chance to do its job before
         // returning to the caller.
         //
         if ( masterProject_ && isFullyPopulated )
         {
            System.gc();               // indicate garbage collection should run
            System.runFinalization();  // run finalize() method(s)
         }
      }

   }

   /**
    *    Creates and returns a Hashtable of Resource objects
    *    @return Hashtable of Resource objects 
    *    @exception ABTException if an unrecoverable error occurs
    */
   private Hashtable getResourceHashtable() throws ABTException
   {
      ABTUserSession us = driver_.getUserSession();
      ABTValue val = curProject_.getValue(us, OFD_TEAMRESOURCES);
      if ( ABTError.isError( val ) ) throw new ABTException( (ABTError) val );
      ABTObjectSet ros = (ABTObjectSet) val;
      Hashtable ht = new Hashtable();
      
      int   size = ros.size(us);
      int   fakeID = 0;
      int   repoID = driver_.getRepository().getID();

      //
      // For each resource object in the set of all resource objects for the current project,
      // create a Hashtable entry.  The hash table can be used for quick look-up of
      // resources later in the populate process.
      
      // The project object has a collection property which contains all of the team members
      // assigned to the project.  Each team member object contains a resource object reference
      // property.
      //
      for (int i = 0; i < size; i++)
      {
         //
         // Get first/next team object.
         //
         ABTObject teamObj = (ABTObject) ros.at(us, i);
         
         //
         // Get the associated resource object and then get its ID.
         //
         val = teamObj.getValue(us, OFD_RESOURCE);
         if ( ABTError.isError( val ) ) throw new ABTException( (ABTError)val );
         ABTObject resObj = (ABTObject) val;     // explicit cast to a Resource object
         /*#553*/
         val = resObj.getRemoteID(us);
         if ( ABTError.isError( val ) ) throw new ABTException( (ABTError)val );
         if ( val == null )
         {
            fakeID--;
            val = new ABTRemoteIDRepository(repoID, fakeID);
         }

   	   //
   	   // Put the resource object into the hash table.  It will be keyed by its remote ID (or by a
   	   // fake repo remote ID, if the resource doesn't have a remote ID yet).  If the remote ID is
   	   // not of type ABTRemoteIDRepository, that's okay.
   	   //
   	   ht.put(val, resObj);
      }
      return ht;
   }
   
}