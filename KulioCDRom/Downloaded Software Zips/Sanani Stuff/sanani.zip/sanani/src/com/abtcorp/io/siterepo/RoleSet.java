package com.abtcorp.io.siterepo;

/*
 * RoleSet.java 12/15/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 12-15-98    LZX         Initial Implementation
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  RoleSet is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTSiteRepoDriver.
 *
 *  <pre>
 *       RoleSet rt = new RoleSet(driver, cfield);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         Method
 */

public class RoleSet extends ABTSiteRepoHelper
{
   ABTCursor resCursor_;

/**
 * RoleSet constructor.
 * @param driver: the reference to the driver.
 * @param parent: the resource object that owns the rolesets.
 * @param resCursor: the resource cursor.
 */
   RoleSet(ABTRepositoryDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_ROLESET, OBJ_ROLESET);
      matchField_ = null;
   }

/**
 * Populate the object space with data selected from the repository.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	public ABTValue populate(String list, String query) throws ABTException
   {
      // select a resource cursor from the repository in case we need 
      // to look up the external id later (need to select all resources
      // because a roleset may point to any resources and roles in the
      // resource table.
      resCursor_ = getCursor(QRY_RESOURCES, TBL_RESOURCE + "." + FLD_ID);

      // populate the roleset
	   ABTValue val = super.populate(list, query);

	   // close the resource cursor when resource populate is done.
	   closeCursor(resCursor_);

	   return val;
   }


/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(ABTCursor cur, String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
      // find source resource object in the space (first match by remote id, then by ext id)
      int resID = cur.getFieldInt(FLD_RESOURCEID);
      ABTObject obj = (ABTObject)findObject(OBJ_RESOURCE, FLD_EXTERNALID, resID, resCursor_);

      if (obj == null)
         processError("create",
                   errorMessages.ERR_OBJECT_NOT_FOUND,
                   "Resource not found in object space. res id = " + resID );
      
      // set the resource object references.
      reqParams_.putItemByString(OFD_RESOURCE, obj);

      // find the (resource) role object in the space (first match by remote id, then by ext id)
      resID = cur.getFieldInt(FLD_ROLEID);
      obj = (ABTObject) findObject(OBJ_RESOURCE, FLD_EXTERNALID, resID, resCursor_);

      if (obj == null)
      {
         // if the role not found in the space (it could happen if the 
         // global objects were previously loaded from a different repository),
         // instantiate a resource helper and load the positioned resource role
         // into the space
         Resource resHelper = new Resource(driver_, (ABTObject)driver_.getSite());
         ABTValue val = resHelper.populate(resCursor_, false);
         if (val instanceof ABTObject)
            obj = (ABTObject) val;
         else
            processError("create",
                   errorMessages.ERR_OBJECT_NOT_FOUND,
                   "Role not found in object space. role id = " + resID  );
      }
      // set the role object references.
      reqParams_.putItemByString(OFD_ROLE, obj);

      return (super.create(cur, type, id, reqParams_));
   }


}