package com.abtcorp.io.siterepo;

/*
 * IABTSiteRepoConstants.java 06/11/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date          Author      Description
  * 07-16-98      LZX         Initial Implementation
  *
  */

/**
 *  IABTIOSiteRepoConstants is a Java interface for specifying constants for the Sanani 
 *  site (global) drivers.
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTDriver
 */


public interface IABTSiteRepoConstants
{
   //
   // SOL queries used to populate/save global objects.
   //
   public static final String QRY_SITE = "SELECT * FROM PRSITE ";
   
   public static final String QRY_RESOURCEROLES = "SELECT * FROM PRResource where prIsRole <> 0 ";

   // this query is for saving resource roles. all the resources are selected
   // because we don't want to add any roles that have duplicate names as real resources.
   public static final String QRY_RESOURCES = "SELECT * FROM PRResource";

   public static final String QRY_ESTMODELS = "SELECT * FROM MREstModel ";

   public static final String QRY_CUSTOMFIELDS = "SELECT * FROM MRCustomField ";

   public static final String QRY_CUSTOMENUMS = "SELECT * FROM MRCustomEnum ";

   // query for saving custom enums
   public static final String QRY_CUSTOMENUMS2 = "SELECT * FROM MRCustomEnum where prFieldID = ";

   public static final String QRY_AGGREGATEFIELDS = "SELECT * FROM MRAggregateField ";

   public static final String QRY_ADJRULES = "select * from MRAdjRule ";

   public static final String QRY_TYPECODES = "select * from PRTypeCode ";

   public static final String QRY_CHARGECODES = "select * from PRChargeCode ";

   public static final String QRY_TIMEPERIODS = "select * from PRTimePeriod ";

   public static final String QRY_RESOURCENOTES = "select * from PRNote where prTableName = 'PRResource' and prRecordID = ";

   public static final String QRY_CALENDARS = "select * from PRCalendar ";

   public static final String QRY_BASECALENDARS = "select * from PRCalendar where prResourceID is null ";

   public static final String QRY_SITECALENDAR = "select * from PRCalendar where prID = ";
   
   // queries for selecting resource categories (including roles and non-roles)
   public static final String QRY_RESCAT = "select distinct(prCategory) from PRResource ";

   public static final String QRY_RESOURCEBYCAT = "select * from prresource where prCategory = ";

   public static final String QRY_RESOURCEBYNULLCAT = "select * from prresource  where prCategory is null";

   public static final String QRY_ROLESETS = "select * from PRRoleSet where prResourceID = ";
}
