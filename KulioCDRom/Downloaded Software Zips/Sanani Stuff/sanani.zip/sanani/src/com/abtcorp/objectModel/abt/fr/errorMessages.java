package com.abtcorp.objectModel.abt.fr;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.objectModel.abt.fr".intern();
public static final ABTErrorCode ERR_INVALID_VALUE = new ABTErrorCode(Package, "ERR_INVALID_VALUE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_OPERATION_DENIED = new ABTErrorCode(Package, "ERR_OPERATION_DENIED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_TYPE = new ABTErrorCode(Package, "ERR_INVALID_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_BASE_CALENDAR = new ABTErrorCode(Package, "ERR_BASE_CALENDAR", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_DUPLICATE_DETECTED = new ABTErrorCode(Package, "ERR_DUPLICATE_DETECTED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_DOH_DOT = new ABTErrorCode(Package, "ERR_DOH_DOT", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_GUIDELINE = new ABTErrorCode(Package, "ERR_GUIDELINE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_CIRCULAR_REFERENCE = new ABTErrorCode(Package, "ERR_CIRCULAR_REFERENCE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_DATA_CONVERSION = new ABTErrorCode(Package, "ERR_DATA_CONVERSION", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_SITE_ACCESS = new ABTErrorCode(Package, "ERR_SITE_ACCESS", UNRECOVERABLE_ERROR );

}