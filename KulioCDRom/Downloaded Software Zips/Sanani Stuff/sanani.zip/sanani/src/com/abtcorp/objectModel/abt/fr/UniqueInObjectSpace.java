package  com.abtcorp.objectModel.abt.fr;

/*
 * UniqueInObjectSpace.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author          Description
 * 08-27-98       LZX             Initial Design
 *
 */

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule enforces the uniqueness of this field for all objects of the
 * specified type in the object space.
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class UniqueInObjectSpace extends SiteFieldRule
{
   /**
    * The new value must be unique for the object type
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      String objectType = parent.getObjectType();
      String propName = property.getName();

      // value can't be null
      if( ABTValue.isNull( newValue ) )
         return new ABTError( "UniqueInObjectSpace",
                     "onSet",
                     errorMessages.ERR_INVALID_VALUE,
                     "Attempting to set " + objectType + "->" + propName + " to null or empty" );

      // return if new value is the same as old
      if( !ABTValue.isNull( myValue ) && newValue.equals( myValue ) )
         return myValue;

      // search in the object space for duplicates
      ABTRule rule = parent.getRule();
      ABTObjectSpace objectspace = rule.getObjectSpace();

      ABTValue v = objectspace.findObject ( session,
                                            objectType,
                                            propName,
                                            newValue);
      if (ABTError.isError( v ) )
         // couldn't find the object (no duplicate), go ahead write it
         return write( session, parent, property, myValue, newValue, false );
      else
         // duplicate found, return error
         return new ABTError( "UniqueInObjectSpace",
                  "onSet",
                  errorMessages.ERR_DUPLICATE_DETECTED,
                  objectType + "->" + propName + " must be unique in the object space. Value '" +
                  newValue.stringValue() + "' already existed.");
   }
}
