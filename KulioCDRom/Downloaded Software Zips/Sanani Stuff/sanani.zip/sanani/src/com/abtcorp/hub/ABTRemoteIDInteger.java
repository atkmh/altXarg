package com.abtcorp.hub;

/*
 * ABTRemoteIDInteger.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;

 /*
   * abtract class to be implemented by drivers....
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */


public class ABTRemoteIDInteger extends ABTRemoteID
{

    int my_i;

    public ABTRemoteIDInteger (int i)
    {
        my_i = i;
    }
    public ABTRemoteIDInteger()
    {
        my_i = 0;
    }

    public int getInt()
    {
        return my_i;
    }

    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return int 0 => equal, -1 => me < object2, 1 => me > object2
    */
    public int  compareTo  (Object object)
    {
        if (!(object instanceof ABTRemoteIDInteger))
            return -1;
        int i = ((ABTRemoteIDInteger)object).getInt();
        if (i == my_i) return 0;
        return my_i < i ? -1 : +1;


    }
     
     
     /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    public boolean   equals (Object object)
    {
        if (!(object instanceof ABTRemoteIDInteger))
            return false;
        return  my_i == ((ABTRemoteIDInteger)object).getInt();

    }

	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */
	public int hashCode()
    {
        return my_i;
    }


   }