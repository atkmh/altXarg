package com.abtcorp.io.client.mppfile;

/**
 * ABTClientMppTeam.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 09-02-98    ATW             Initial Implementation
  *
  */

/**
 *  ABTClientMppTeam is a helper class which populates to the team object set
 *  in a Sanani project object created from a Microsoft Project project.
 *
 *
 * @version		1.0
 * @author		A. Waller
 * @see			ABTClientMppHelper
 */


import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTTime;

import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.Project;
import com.abtcorp.autowrap.msproject.Resource;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;

public class ABTClientMppTeam extends ABTClientMppHelper implements IABTPMRuleConstants,
																	IABTPropertyType,
																	IABTClientMppDriverConstants
{
	private ABTClientMppResources resPop_;
	private IABTObject			projObj_;
	private long				projID_;
	private ABTRemoteID			id_;
	private Project 			msProject_;

	/**
	*  Empty constructor which calls the constructor of the parent class.
	*/
	public ABTClientMppTeam() {/* implicit call to super() here */}

	/**
	*  Construct a team populator helper.
	*  @param space an IABTObjectSpace reference to an existing object space in
	*  which the project object has been constructed
	*  @param space an IABTObjectSpace reference to the space the team's project is in
	*  @param driver an ABTClientMppDriver reference to the driver calling this helper
	*  @param projectObject the IABTObject project object the team resources belong to
	*  @param resPopulator an ABTClientMppResources reference used to get the hashtable
	*  of resource references created by the resource populator
	*  @exception ABTException if an unrecoverable error occurs.
	*/
	public ABTClientMppTeam(IABTObjectSpace space,
							ABTClientMppDriver driver,
							IABTObject projectObject,
							ABTClientMppResources resPopulator,
							Project msProject ) throws ABTException
	{
		super( space, driver );

		if ( msProject instanceof Project )
			msProject_ = msProject;
			
		if ( projectObject != null && projectObject instanceof IABTObject )
		{
			projObj_ = projectObject;
			projID_ = getValue( projObj_, OFD_ID ).intValue();
		}

		if ( resPopulator != null && resPopulator instanceof ABTClientMppResources )
			resPop_ = resPopulator;
	}

	/**
	*  Populate an object space with the resources for this project
	*  @return an ABTError or null if successful
	*  @exception ABTException if an unrecoverable error occurs.
	*/
	public ABTValue populate() throws ABTException
	{
		ABTValue		teamObj = null;
		ABTValue		retVal = null;
		Hashtable		resHash = null;

		try
		{
			//
			//	Make sure these necessary objects were passed in.  If not, create an error.
			//
			if ( projObj_ == null || resPop_ == null )
				retVal = createErrorObject( this.getClass(), ERR_TEAM + ERR_POP, ERR_MISSING_PARAM );

			if ( retVal == null )
				resHash = resPop_.getResourceHashTable();

			//
			// Iterate through the resources in the hashtable and create a
			// team resource object for each.
			// 
			if ( (retVal == null) && (resHash != null) ) 
			{
				Enumeration e = resHash.elements();
				IABTObject resObj;
				
				while( e.hasMoreElements() )
				{
					resObj = (IABTObject)e.nextElement();
					id_ = null;
					
					if ( (resObj != null) && (resObj instanceof IABTObject) &&
						 (resObj.getObjectType() == OBJ_RESOURCE) )
					{
						//
						// Assign the resource's remote ID to the team object.
						//
						ABTValue id = resObj.getValue( PROP_REMOTEID );
						if ( (id instanceof ABTRemoteID ) )
							id_ = (ABTRemoteID)id;

						//
						// Create a new team object and set its properties
						// from this project and the resource this object represents.
						//
						teamObj = create( resObj );
						if ( ABTError.isError( teamObj ) )
							throw new ABTException( ((ABTError)teamObj).getMessage() );
						else
						{
							if ( teamObj != null )
							{
								IABTObject abtobject = (IABTObject) teamObj;
								setValues( resObj, abtobject );
							}
						}
					}
				}
			}
			else
				retVal = createErrorObject( this.getClass(), ERR_TEAM + ERR_POP, ERR_BAD_PARAM );
		}
		catch ( ABTException e )
		{
			// Catchall which reformats error message to indicate it came from here.
			createErrorObject( this.getClass(), ERR_TEAM + ERR_POP, e.getMessage() );
		}

		return retVal;
	}

	/**
	*  Creates a new team object
	*  @param params an ABTArray of optional construction parameters - currently unused
	*  @return an ABTValue which should be the newly-created team resource object
	*  @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue create( ABTArray params ) throws ABTException
	{
		ABTValue object = null;
		return object;
	}

	/**
	*  Creates a new team object
	*  @param res an IABTObject reference to the resource object this team
	   object represents.  This is a required parameter for a team object.
	*  @return an ABTValue which should be the newly-created team object
	*  @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue create( IABTObject res ) throws ABTException
	{
		ABTValue object = null;
		IABTHashTable  reqparms = space_.newABTHashTable(); 
		reqparms.putItemByString( OFD_PROJECT, (ABTValue)projObj_ );	  
		reqparms.putItemByString( OFD_RESOURCE, (ABTValue)res );

		object = (ABTValue)createObject( OBJ_TEAM, id_, reqparms );
		return object;
	}

	/**
	*  Updates an existing team resource object
	*  @param params an ABTArray required by the team resource object
	*  @return an ABTValue which is the updated team resource object
	*  @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue update( ABTArray params ) throws ABTException
	{
		ABTValue object = create( params );
		return object;
	}

	/**
	*  Sets new values into the team resource object's properties from 
	*  properties found in the resource and project objects this team object
	*  is related to.
	*  @param resObj an IABTObject reference to the resource this team resource represents
	*  @param obj an IABTObject reference to the team resource object currently being modified
	*  @exception ABTException if an unrecoverable error occurs
	*/
	private void setValues( IABTObject resObj, IABTObject obj ) throws ABTException
	{
		// Reuse these IDs until and unless someone has a better idea.
		obj.setValue( OFD_ID, resObj.getValue( OFD_ID ) );
		obj.setValue( OFD_RESOURCEID, resObj.getValue( OFD_ID ) );
		obj.setValue( OFD_PROJECTID, projObj_.getValue( OFD_ID ) );

		// Set some other properties.
		obj.setValue( OFD_ISOPEN, ABTBoolean.True() );

		// If this team object was built from an MPP resource, we can try to get the 
		// availability from and to dates from the resource it was built from.  If there
        // are no explicit dates, use the project start and end dates.

		ABTRemoteID tempID = (ABTRemoteID)resObj.getValue( PROP_REMOTEID );
		if ( tempID instanceof ABTClientMppRemoteID )
		{
			Resource res = null;

			if ( ((ABTClientMppRemoteID)tempID).getFileName().equalsIgnoreCase( msProject_.getFullName() ) )
				res = (msProject_.getResources()).getUniqueID( ((ABTClientMppRemoteID)tempID).getUniqueID() );
			if ( res instanceof Resource )
			{
				ABTValue from = res.getAvailableFrom();
                if ( from instanceof ABTTime )
                    obj.setValue( OFD_AVAILSTART, (ABTTime)from );
                else
                	obj.setValue( OFD_AVAILSTART, (ABTTime)msProject_.getProjectStart() );
                ABTValue to = res.getAvailableTo();
                if ( to instanceof ABTTime )
                    obj.setValue( OFD_AVAILFINISH, (ABTTime)to );
                else
                	obj.setValue( OFD_AVAILFINISH, (ABTTime)msProject_.getProjectFinish() );
			}
		}
	}
}
