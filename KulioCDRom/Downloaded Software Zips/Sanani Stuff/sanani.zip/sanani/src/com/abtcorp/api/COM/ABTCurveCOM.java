/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

/** @com.register(clsid=71D14CB1-F986-11d1-ADFA-00E029143BC6,
                typelib=A2FAB780-BDD1-11D1-ADE6-00E029143BC6,
                progid="com.abtcorp.api.com.ABTCurveCOM.1",
                version="1.0")*/

public class ABTCurveCOM implements IABTCurveCOM
   {
   public ABTCurveCOM() {
      this(null);
      }

   public ABTCurveCOM(ABTCurve obj)  {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(obj);
      /**/
      }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj);}
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   
   private ABTCurve _curv;
   private ABTCurve curv() {
      if (_curv == null) _curv = (ABTCurve)getObject();
      return _curv;
      }

   public void Init(int type, double rate) {
      setObject(new ABTCurve(type,rate));
      }

	public int  getType() {
      return curv().getType();}

   public IABTSegmentListCOM getSegments() {
      return new ABTSegmentListCOM(curv().getSegments());}

	public double	getDefault() {
      return curv().getDefault();}
	public void		setDefault(double rate) {
      curv().setDefault(rate);}
   public Variant /*ABTTime*/	getStart()  {
      return VariantMunger.ValueToVariant(curv().getStart());}
   public Variant /*ABTTime*/ getFinish() {
      return VariantMunger.ValueToVariant(curv().getFinish());}

   public boolean isTimeDefined(Variant /*ABTTime*/ time) {
      return curv().isDefined((ABTTime)VariantMunger.VariantToValue(time));}
   public boolean isRangeDefined(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish) {
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      return curv().isDefined(s,f);
      }
   public double	getRate(Variant /*ABTTime*/ time) {
      return curv().getRate((ABTTime)VariantMunger.VariantToValue(time));}
   public double	getRangeSum(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish) {
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      return curv().getSum(s,f);
      }
   public double	getSum() {
      return curv().getSum();}
   public boolean isZero() {
      return curv().isZero();}
   public void clipSegment (Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish) {
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      curv().clipSegment (s,f);
      }
   public void resetSegment(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish) {
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      curv().resetSegment(s,f);
      }
   public void	addRate  (double rate) {
      curv().addRate(rate);}
   public void	subRate  (double rate) {
      curv().subRate(rate);}
   public void	scaleRate(double rate) {
      curv().scaleRate(rate);}
	public void addSegment(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish, double value, IABTCalendarCOM calendar) {
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      ABTCalendar c = null;
      if (calendar != null)  c = (ABTCalendar)calendar.getObject();
	   curv().addSegment(s,f,value,c);
      }
	public void subSegment(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish, double value, IABTCalendarCOM calendar)	{
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      ABTCalendar c = null;
      if (calendar != null)  c = (ABTCalendar)calendar.getObject();
	   curv().subSegment(s,f,value,c);
      }
	public void setSegment(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish, double value, IABTCalendarCOM calendar)	{
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      ABTCalendar c = null;
      if (calendar != null)  c = (ABTCalendar)calendar.getObject();
	   curv().setSegment(s,f,value,c);
      }
	public void scaleSegment(Variant /*ABTTime*/ start, Variant /*ABTTime*/ finish, double value, IABTCalendarCOM calendar){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      ABTCalendar c = null;
      if (calendar != null)  c = (ABTCalendar)calendar.getObject();
	   curv().scaleSegment(s,f,value,c);
      }
   public void	addCurve (IABTCurveCOM curve)  {
      curv().addCurve((ABTCurve)curve.getObject());}
   public void	subCurve (IABTCurveCOM curve)  {
      curv().subCurve((ABTCurve)curve.getObject());}
   public void	setCurve (IABTCurveCOM curve)  {
      curv().setCurve((ABTCurve)curve.getObject());}
   public void	scaleCurve(IABTCurveCOM curve) {
      curv().scaleCurve((ABTCurve)curve.getObject());}

   public IABTCurveCOM Clone(){
      return new ABTCurveCOM((ABTCurve)curv().clone());
      }


   public Variant addWorktime(Variant time, double value){
      ABTTime t = (ABTTime)VariantMunger.VariantToValue(time);
	   return VariantMunger.ValueToVariant(curv().addWorktime(t,value));
      }

   public void divideRate(double rate){
      curv().divideRate(rate);
      }

   public Variant subWorktime(Variant time, double value){
      ABTTime t = (ABTTime)VariantMunger.VariantToValue(time);
	   return VariantMunger.ValueToVariant(curv().subWorktime(t,value));
      }

   public void floor(Variant start, Variant finish, double rate){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
	   curv().floor(s,f,rate);
      }

   public void divideCurve(IABTCurveCOM curve){
      ABTCurve c = null;
      if (curve != null)  c = (ABTCurve)curve.getObject();
	   curv().divideCurve(c);
      }

   public void ceil(Variant start, Variant finish, double rate){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
	   curv().ceil(s,f,rate);
      }

   public void divideSegment(Variant start, Variant finish, double value, IABTCalendarCOM calendar){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
      ABTCalendar c = null;
      if (calendar != null)  c = (ABTCalendar)calendar.getObject();
	   curv().divideSegment(s,f,value,c);
      }

   public boolean lessThan(Variant start, Variant finish, double rate){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
	   return curv().lessThan(s,f,rate);
      }

   public boolean greaterThan(Variant start, Variant finish, double rate){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
	   return curv().greaterThan(s,f,rate);
      }

   public void shift(IABTCalendarCOM calendar, int offset){
      ABTCalendar c = null;
      if (calendar != null)  c = (ABTCalendar)calendar.getObject();
	   curv().shift(c,offset);
      }

   public int diffWorktime(Variant start, Variant finish){
      ABTTime s = (ABTTime)VariantMunger.VariantToValue(start);
      ABTTime f = (ABTTime)VariantMunger.VariantToValue(finish);
	   return curv().diffWorktime(s,f);
      }

   }
 