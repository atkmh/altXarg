package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileSite.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-1-98     MXA         Initial Implementation
 *
 */

/**
 *  ABTIOSiteFileSite is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOSiteFileDriver.
 *
 *  <pre>
 *       ABTIOSiteFileSite sr = new ABTIOSiteFileSite(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOSiteFileDriver
 */

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;


public class ABTIOSiteFileSite extends ABTIOSiteFileHelper implements IABTRuleConstants
{

//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOSiteFileSite constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOSiteFileSite(ABTIOSiteFileDriver driver)
   {
      super(driver, null, OBJ_SITE);
   }

/**
 *  Saves the site object back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving typecode and chargecode etc.)
 *	@param site   the object set to be saved back to the loal file
 *  @return       the object that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObject siteObj) throws ABTException
   {
    IABTObjectSet siteOs = null;
    try
    {
      siteOs = createObjectSet(OBJ_SITE);
      addListMember(siteOs, siteObj);

      IABTLocalID siteId = siteObj.getID();
      if (siteId == null)
        throw new ABTException("The ID is null.");

      if ( driver_.isIntermediateTableNull() )
        throw new ABTException("The intermediate Hash table is null");
      
      driver_.setSiteId(siteId);

      super.save(siteOs);
      // save the subordinate objects of all the Site
      saveOtherObjects(siteOs);
    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
    }
    return (ABTValue)siteOs;

   }

   private void saveOtherObjects(IABTObjectSet oSet) throws ABTException
   {
   	// loop through all the objects in the object set
      for (int i = 0; i < size(oSet); i++)
      {
         IABTObject obj = (IABTObject)at(oSet, i);
         
        ABTIOSiteFileCalendar calhelper = new ABTIOSiteFileCalendar(driver_, obj);
        calhelper.save(obj, OFD_CALENDARS);
      }
   }

/**
 * Populate the site object.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
        id_ = driver_.getSiteId();
	    return (super.populate());
	}


/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 *  @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {    
        IABTObject site = null;
         ABTValue ret  = null;
        ABTValue value  = (driver_.getSpace()).getObjects(type_);
        // Get the site out of the set 
	    if (value instanceof IABTObjectSet) 
        { 
            IABTObjectSet  siteSet = (IABTObjectSet)value;                   
            int size = siteSet.size();
            System.out.println("There are " + size + " sites in ABTIOSiteFileSite");
            value = siteSet.at(0);         
            if (value instanceof IABTObject)
                site = (IABTObject)value;
                
            super.setScalarValues(propSet_, objArr_ , site);
            setValues((IABTObject)site);
            ret = (ABTValue)site;
       }    
       else 
       {
            ret = super.create(type, id, params);
      
            if (ret instanceof IABTObject)
                setValues((IABTObject)ret);
            else 
                throw new ABTException("Wrong Cast");
           
       }
     return ret;
   }


/**
 *  Set site property values.
 *  @param       IABTObject site
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
  protected void setValues(IABTObject site) throws ABTException
  {
      IABTLocalID stdCalID         = null;
      IABTLocalID curTimePeriodID  = null;

      IABTObject stdCalObj        = null;
      IABTObject curTimePeriodObj = null;

      Object     obj              = null;
      ABTValue   val              = null;


      val = getHashValue(objArr_, propSet_, OFD_STDCALENDAR);
      if (val instanceof IABTLocalID)
        stdCalID = (IABTLocalID)val;
      else
        throw new ABTException("Wrong type cast");

      obj = driver_.lookupTableGet(stdCalID);
      if ( obj != null && obj instanceof IABTObject)
        stdCalObj =  (IABTObject)obj;
      else
      {
         ABTIOSiteFileCalendar calHelper = new ABTIOSiteFileCalendar(driver_, site);
         val = calHelper.populate(stdCalID);
         if (val instanceof IABTObject)
            stdCalObj = (IABTObject)val;
         else 
            throw new ABTException("Wrong Cast");
        
      }

/*
      val = getHashValue(objArr_, propSet_, OFD_CURTIMEPERIOD);
      if (val instanceof IABTLocalID)
        curTimePeriodID = (IABTLocalID)val;
      else
        throw new ABTException("Wrong type cast");

      obj = driver_.lookupTableGet(curTimePeriodID);
      if ( obj != null && obj instanceof IABTObject)
        curTimePeriodObj =  (IABTObject)obj;
      else
      {
        ABTIOSiteFileTimePeriod tpHelper = new ABTIOSiteFileTimePeriod(driver_, site);        
        val = tpHelper.populate(curTimePeriodID);        
        if (val instanceof IABTObject)
            curTimePeriodObj = (IABTObject)curTimePeriodObj;
      }

*/
      // there should be only one site calendar object found
      // set the site calendar object reference.
      setValue(site, OFD_STDCALENDAR, (ABTValue)stdCalObj);
//      setValue(site, OFD_CURTIMEPERIOD, (ABTValue)curTimePeriodObj);

   }



}
