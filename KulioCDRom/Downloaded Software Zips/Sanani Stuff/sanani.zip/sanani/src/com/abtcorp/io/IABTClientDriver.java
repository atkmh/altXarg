package com.abtcorp.io;
/*
 * IABTClientDriver.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 08-11-98      SOB         Initial Implementation
  * 08-18-98      SOB         Added execute() signature
  * 10-02-98      SOB         Remove javadoc warnings and errors
  *
  *
  */


import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTError;

import com.abtcorp.idl.IABTDriverConstants;

public interface IABTClientDriver
{
/**
 *		Opens a connection to a specific data source.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public ABTValue open(IABTObjectSpace space, IABTHashTable args);

/**
 *		Populates the ABTObjectSpace with objects from the data source. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public ABTValue populate(IABTObjectSpace space, IABTHashTable args);

/**
 *		Saves the ABTObjects identified in the ABTObjectSet object back to the data source.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public ABTValue save(IABTObjectSpace space, IABTHashTable args);

/**
 *		Closes a connection to a specific data source.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public ABTValue close(IABTObjectSpace space, IABTHashTable args);

/**
 *		Executes a driver-specific command.  All command arguments arrive via the args
 *    hash table.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public ABTValue execute(IABTObjectSpace space, IABTHashTable args);

}