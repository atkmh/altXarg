package com.abtcorp.blob;

import java.io.Serializable;

import com.abtcorp.core.*;

public final class ABTShiftList extends ABTSortedArray implements Serializable
{
   private static final long serialVersionUID = 4042397378224663590L;
	public static final ABTShiftList HOLIDAY = new ABTShiftList();
   public static final ABTShiftList WORK    = new ABTShiftList();

   // TODO: We should read this from a properties file

   static {
      WORK.setShift(8*3600,  12*3600);
      WORK.setShift(13*3600, 17*3600);
   }

   public ABTShiftList() {}

   public final ABTShift getShift(int index) {return (ABTShift)at(index);}

   public final void resetShift(int start, int finish)
   {
   	if (finish <= start) return;

   	for (int index = 0; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   	   if (shift.getFinish() <= start)  continue;
   	   if (shift.getStart()  >= finish) break;
   		if (shift.getFinish() >  finish) insert(index+1, new ABTShift(finish, shift.getFinish()));
   		if (shift.getStart()  <  start)  put(index, new ABTShift(shift.getStart(), start));
   		else                     		   remove(index--);
   	}
   }

   public final void setShift(int start, int finish)
   {
   	if (finish <= start) return;

   	setShift(new ABTShift(start, finish));
   }

   public final void setShift(ABTShift shift)
   {
      resetShift(shift.getStart(), shift.getFinish());

   	add(shift);
   }

   public final void optimize()
   {
      if (size() < 2) return;

  	   ABTShift prev = getShift(0);

     	for (int index = 1; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   		if (prev.getFinish() == shift.getStart()) {
   		   put(index-1, shift = new ABTShift(prev.getStart(), shift.getFinish()));
   			remove(index--);
   		}

   		prev = shift;
   	}
   }

	public final boolean isWorkday() {return size() > 0;}

	public final boolean isWorktime(int timeofday)
	{
   	for (int index = 0; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   	   if (shift.getFinish() <= timeofday) continue;
   	   if (shift.getStart()  >  timeofday) break;

   	   return true;
   	}

      return false;
	}

   public final int getDuration()
   {
      int result = 0;

	   for (int index = 0; index < size(); index++)
   	   result += getShift(index).getDuration();

      return result;
   }

   public final int diffWorktime(int start, int finish)
   {
   	if (finish <= start) return 0;

      int result = 0;

   	for (int index = 0; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   	   if (shift.getFinish() <= start)  continue;
   	   if (shift.getStart()  >= finish) break;

   	   result += Math.min(finish, shift.getFinish()) - Math.max(start, shift.getStart());
   	}

      return result;
   }

   final int nextWorktime(int timeofday)
   {
   	for (int index = 0; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   	   if (shift.getFinish() <= timeofday) continue;
   	   if (shift.getStart()  >  timeofday) return shift.getStart();

   	   return timeofday;
   	}

      return ABTTime.SecondsPerDay;
   }

   final int prevWorktime(int timeofday)
   {
   	for (int index = size(); index > 0; index--) {
   	   ABTShift shift = getShift(index-1);

   	   if (shift.getStart()  >= timeofday) continue;
   	   if (shift.getFinish() <  timeofday) return shift.getFinish();

   	   return timeofday;
   	}

      return 0;
   }

   final int nextHolitime(int timeofday)
   {
   	for (int index = 0; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   	   if (shift.getFinish() <= timeofday) continue;
   	   if (shift.getStart()  >  timeofday) return timeofday;

   	   return shift.getFinish();
   	}

      return ABTTime.SecondsPerDay;
   }

   final int prevHolitime(int timeofday)
   {
   	for (int index = size(); index > 0; index--) {
   	   ABTShift shift = getShift(index-1);

   	   if (shift.getStart()  >= timeofday) continue;
   	   if (shift.getFinish() <  timeofday) return timeofday;

   	   return shift.getStart();
   	}

      return 0;
   }

   final int addWorktime(int timeofday, int seconds[])
   {
   	for (int index = 0; index < size(); index++) {
   	   ABTShift shift = getShift(index);

   	   if (shift.getFinish() <= timeofday) continue;

         int start  = Math.max(shift.getStart(), timeofday);
         int finish = shift.getFinish();

   		if (seconds[0] <= finish - start) {start += seconds[0]; seconds[0] = 0; return start;}

   		seconds[0] -= finish - start;
   	}

      return ABTTime.SecondsPerDay;
   }

   final int subWorktime(int timeofday, int seconds[])
   {
   	for (int index = size(); index > 0; index--) {
   	   ABTShift shift = getShift(index-1);

   	   if (shift.getStart()  >= timeofday) continue;

         int start  = shift.getStart();
         int finish = Math.min(shift.getFinish(), timeofday);

   		if (seconds[0] <= finish - start) {finish -= seconds[0]; seconds[0] = 0; return finish;}

   		seconds[0] -= finish - start;
   	}

      return 0;
   }

   public String toString()
   {
	   if (equals(WORK))    return "work";
	   if (equals(HOLIDAY)) return "holiday";

	   StringBuffer buffer = new StringBuffer();

   	for (int index = 0; index < size(); index++) {
   		if (index > 0) buffer.append(", ");

         buffer.append(getShift(index));
   	}

   	return buffer.toString();
	}
}