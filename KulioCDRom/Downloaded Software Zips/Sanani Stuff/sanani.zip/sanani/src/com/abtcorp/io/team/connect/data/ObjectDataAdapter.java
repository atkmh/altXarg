package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;

import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTValue;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTUserSession;

public class ObjectDataAdapter implements ObjectData, IABTTWRuleConstants
{
   
   ABTObject object_;
   ABTRemoteID remoteID_;
   transient ABTUserSession session_;

   public ObjectDataAdapter(ABTObject object, ABTUserSession session)
   {
      object_ = object;
      remoteID_ = (ABTRemoteID)object_.getID().getRemote(session);
      session_ = session;
   }

   public Hashtable getValues()
   {
      return new Hashtable(20,(float).85); // Optimize for memory efficiency
   }

   public ABTValue getID()
   {
      if (object_ != null) {
         ABTValue id = object_.getValue(session_,FLD_TW_INTERNALID);

         if (id == null || ABTError.isError(id) || ABTEmpty.isEmpty(id)) return null;
         return id;
      }
      return null;
   }

   public static ObjectData createObjectData(ABTObject object, ABTUserSession session)
   {
      try {
         if (object.getObjectType().equals(OBJ_TW_CHARGECODE)) return new ChargeCodeData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_TYPECODE)) return new TypeCodeData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_PROJECT)) return new ProjectData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_RESOURCE)) return new ResourceData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_CATEGORYSTRING)) return new NoteData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_TIMESHEET)) return new TimeSheetData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_TASK)) return new TaskData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_TIMEPERIOD)) return new TimePeriodData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_USER)) return new UserData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_NOTE)) return new NoteData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_DELETEDOBJECT)) return new DeletedData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_DELETEDNOTE)) return new DeletedData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_DELETEDTASK)) return new DeletedData(object, session);
         else if (object.getObjectType().equals(OBJ_TW_DELETEDTIMESHEET)) return new DeletedData(object, session);
      } catch (Exception e) {
      }

      return null;
   }

   public DataArray getNotes(ABTObjectSet notes)
   {
      DataArray array = new DataArray();

      for (int i = 0;i < notes.size(session_);i++) {
         NoteData note = (NoteData)ObjectDataAdapter.createObjectData((ABTObject)notes.at(session_,i),session_);
         array.add(new DataRow(note,FileManager.NOTE)); // Save a datarow for the note.
      }

      return array;
   }

   public ABTRemoteID getRemoteID()         {return remoteID_;}
   public void setRemoteID(ABTRemoteID id)  {remoteID_ = id;}
}