package com.abtcorp.hub;
/*
 * ABTLogicalExpression.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-05-98	   HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  like-operation
  * 2-
  */



/**
 * Basic ABTLogicalExpression class - base class for handling complex expressions
 * An ABTLogicalExpression has either three elements -
 * a left-operand (ABTValue), a right-operand (ABTValue) and
 * an operation
 * <p>
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.core.ABTValue
 */


import com.abtcorp.core.*;
import com.abtcorp.parser.*;

import java.util.*;
import java.lang.Math.*;

public class ABTLogicalExpression extends ABTValue implements com.abtcorp.parser.IABTLogicalOperation
{

   ABTValue leftOperand;
   ABTValue rightOperand;
   int operation;
   ABTUserSession mySession = null;

   public String toString()
   {
      return leftOperand.toString() + " " +
		  operation + " " + rightOperand.toString();
   }

   /**
   * class constructor for default expressions
   * @param left - left operand
   * @param right - right operand
   * @param oper - operation to be performed
   */
   public ABTLogicalExpression(ABTUserSession session, ABTValue left, int oper, ABTValue right)
   {
      this(session);
      leftOperand = left;
      rightOperand = right;
      if (rightOperand == null)
         operation = ABT_EXPR_UNKNOWN;
      else
         operation = oper;
   }

   /**
   * class constructor for default expressions
   * @param oper - operation to be performed
   */
   public ABTLogicalExpression(ABTUserSession session, int oper)
   {
      this(session);
      operation = oper;
      leftOperand = null;
      rightOperand = null;
   }

   /**
   * class constructor with no arguments
   */
   public ABTLogicalExpression(ABTUserSession session)
   {
      leftOperand = null;
      rightOperand = null;
      operation = ABT_EXPR_UNKNOWN;
      mySession = session;
   }

   /**
   * set the left hand value
   * @param left - left operand
   */
   public void setLeftOperand( ABTValue left )
   {
      leftOperand = left;
   }

   /**
   * set the right hand value
   * @param right - right operand
   */
   public void setRightOperand( ABTValue right )
   {
      rightOperand = right;
   }

   /**
   * set the operation
   * @param oper - the operation
   */
   public void setOperation( int oper )
   {
      operation = oper;
   }

   /**
   *  evaluate the expression
   *  @return boolean
   */
   public boolean booleanValue()
   {
//      switch (java.lang.Math.abs(operation))
      switch (operation) // Took abs(operation) out JSE 8/3/98
      {
         case ABT_EXPR_AND:
            return (leftOperand.booleanValue() && rightOperand.booleanValue());
         case ABT_EXPR_OR:
            return (leftOperand.booleanValue() || rightOperand.booleanValue());
         case ABT_EXPR_GREATER:
            return (leftOperand.compareTo(rightOperand) > 0);
         case ABT_EXPR_GREATEREQUAL:
            return (leftOperand.compareTo(rightOperand) >= 0);
         case ABT_EXPR_SMALLER :// 5;
            return (leftOperand.compareTo(rightOperand) < 0);
         case ABT_EXPR_SMALLEREQUAL:// = 6;
            return (leftOperand.compareTo(rightOperand) <= 0);
         case ABT_EXPR_LIKE:// 7;
            return elementLike();
         case ABT_EXPR_NOTLIKE:// -7;
            return !elementLike();

         case ABT_EXPR_EQUAL:// = 8;
            return (leftOperand.compareTo(rightOperand) == 0);
         case ABT_EXPR_NOTEQUAL:// = -8;
            return (leftOperand.compareTo(rightOperand) != 0);

         case ABT_EXPR_IN:
            return elementIn();
         case ABT_EXPR_NOTIN:
            return !elementIn();

         case ABT_EXPR_BETWEEN:
            return elementBetween();
         case ABT_EXPR_NOTBETWEEN:
            return !elementBetween();

         case ABT_EXPR_IS:
            return elementIs();

         default:
            return leftOperand.booleanValue();
      }
   }

   //
   // This is a helper storage class to store the parts of the like string.
   // The hasPreceedingWildChars member is a boolean indicating whether or
   // not 0 to many characters can preceed the character sequence.
   //
   class SearchStringPart
   {
      public boolean     hasPreceedingWildChars_;
      public String      charSequence_;
      
      public SearchStringPart( boolean b, String s )
      {
         hasPreceedingWildChars_ = b;
         charSequence_ = s;
      }
   }

   /**
    * Determine if the left operand is LIKE the right operand.
    * The right operand can have any number of % characters to represent
    * 0-many wild card characters
    *
    * @return true if the left element is like the right, false if not
    */
   public boolean elementLike()
   {
      String left  = leftOperand.stringValue();
      String right = rightOperand.stringValue();

      if( left == null )
         return false;

      int      curpos   = 0, wildPos;
      boolean  done     = false;
      Vector   parts    = new Vector();

      //
      // Strip all double percent signs
      //
      int index;
      while( ( index = right.indexOf( "%%" ) ) != -1 )
         right = right.substring( 0, index ) + right.substring( index+1 );

      //
      // Parse apart the like string and store each character sequence that
      // exists between percent signs in the parts vector
      //
      while( !done )
      {
         SearchStringPart  part;
         String            s;

         wildPos = right.indexOf( '%' );
         switch( wildPos )
         {
            case -1:
               //
               // If no percent was found, then this is all there is.
               //
               part = new SearchStringPart( false, right );
               done = true;
               break;
            case 0:
               //
               // The first character is wild, so find the second percent
               //
               s = right.substring( 1 );
               wildPos = s.indexOf( '%' );
               if( wildPos == -1 )
                  done = true;
               else
               {
                  s = s.substring( 0, wildPos );
                  right = right.substring( wildPos + 1 );
               }
               part = new SearchStringPart( true, s );
               break;
            default:
               //
               // There is no preceeding wild character
               //
               s = right.substring( 0, wildPos );
               right = right.substring( wildPos );
               part = new SearchStringPart( false, s );
               break;
         }

         parts.addElement( part );
      }

      int         curPos   = 0;
      Enumeration e        = parts.elements();
      String      likeStr  = left;

      //
      // Iterate the stored string parts
      //
      while( e.hasMoreElements() )
      {
         SearchStringPart  part  = (SearchStringPart)e.nextElement();
         String            chars = part.charSequence_;

         int likeLength = likeStr.length(),
             curLength  = chars.length();

         //
         // If the length of the current string part is 0, then we are done,
         // but first...
         //
         if( curLength == 0 )
         {
            //
            // If the string we are comparing against has more characters left
            // in it, but the like clause says no freaking way buddy(!), then return
            // with a big fat I don't think so.
            //
            if( likeLength > 0 && !part.hasPreceedingWildChars_ )
               return false;

            return true;
         }

         //
         // If the character sequence is not found, or it is found somewhere in
         // the string beyond the first position ( and no wild character preceeds
         // it ) then return false
         //
         index = likeStr.indexOf( chars );
         if( index == -1 || ( index > 0 && !part.hasPreceedingWildChars_ ) )
            return false;

         //
         // Advance the likeStr to the first character beyond the last
         // found character sequence.
         //
         likeStr = likeStr.substring( index + curLength );
      }


      return likeStr.length() > 0 ? false : true;
   }

   public boolean elementIn()
   {
      ABTObjectSet array = ((ABTObjectSet)rightOperand);
      Enumeration i = (Enumeration)array.elements(mySession);
      while( i.hasMoreElements() )
      {
         ABTValue v = (ABTValue)i.nextElement();
         if( leftOperand.compareTo( v ) == 0 )
            return true;
      }

      return false;
   }

   public boolean elementBetween()
   {
      ABTObjectSet array = ((ABTObjectSet)rightOperand);
      ABTValue low   = (ABTValue)array.at(mySession, 0 );
      ABTValue high  = (ABTValue)array.at(mySession, 1 );

      if( leftOperand.compareTo( low ) > 0 && leftOperand.compareTo( high ) < 0 )
         return true;

      return false;
   }

   public boolean elementIs()
   {
      return ((IABTQueryValue)rightOperand).booleanValue( leftOperand );
   }

   /**
   *  by default return the error code
   *  @return short
   */
   public short shortValue()
   {
      if (booleanValue())
         return 1;
      return 0;
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int intValue()
   {
      return (int)shortValue();
   }

   /**
   *  by default return the error code
   *  @return double
   */
   public double doubleValue()
   {
      return (double)shortValue();
   }

   /**
   *  by default return null
   *  @return Date
   */
   public ABTDate dateValue(boolean pm)
   {
      return null;
   }

   /**
   *  by default return the true/false
   *  @return String
   */
   public String stringValue()
   {
      {return booleanValue() ? "true" : "false";}
   }

   /**
   *  by default return the time this thing was created
   *  @return ABTTime
   */
   public ABTTime timeValue()
   {
      return null;
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int hashCode()
   {
      return leftOperand.hashCode();
   }


   /**
   *  compare to ABTLogicalExpressions: first use the errorcode and (if not available)
   *  use the error message
   *  @param object - to compare me to
   *  @return int (0=equal, -1/+1 as usual)
   */
   public int compareTo(Object object)
   {
      if (object == null) return 1;     
      if ( (object != null) && (object instanceof ABTValue))
      {
         int a = intValue();
         int b = ((ABTValue)object).intValue();
         if (a ==b) return 0;
         return a < b ? -1 : +1;
      }
      return 1;
   }

}

