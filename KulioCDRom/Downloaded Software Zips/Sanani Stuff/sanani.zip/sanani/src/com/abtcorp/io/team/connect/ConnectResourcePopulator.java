package com.abtcorp.io.team.connect;

import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.team.ProjectPopulator;
import com.abtcorp.io.team.TWPopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.UserRight;
import com.abtcorp.io.team.ObjectIDSortedArray;
import com.abtcorp.io.team.TWObjectComparator;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.idl.IABTPropertyType;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

import com.abtcorp.io.team.ResourcePopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.TWPopulator;

public class ConnectResourcePopulator extends ResourcePopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants, IABTPropertyType
{
   private String server_;

   public ConnectResourcePopulator() {}

   public ConnectResourcePopulator(ABTRepositoryDriver driver)
   {
      super(driver);
   }
   
	public ABTValue populate() throws ABTException
   {
	      // get a calendar cursor to optimize calendar retrieval for resources
      ABTCursor calendars = getDriver().getRepository().select(CALENDAR_QUERY);
      
      // get set of all resources in the object space so that we can add to it
      ABTObjectSet resources = getObjectSet(OBJ_TW_RESOURCE);

      if (resources == null || cursor_ == null) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      int id = 0;
      
      total_ += 3; // For the user right processing.
      
      ABTObject resource = null;

   	if (resources_ == null) resources_ = new ObjectIDSortedArray(new TWObjectComparator(getSession()));
      // move through the resource cursor adding the resources
      while(cursor_.moveNext()) {
         resource = null;
         if (cursor_.getFieldInt(FLD_ID) != id) {                      // make sure we don't add the same resource twice
            resource = (ABTObject)addObject(resources,calendars);      // add the resource
            linkToUsers(resource);                                     // link the resource to the appropriate user properties
            resources_.add(resource);
         	updateStatus(resource);
         }
         id = cursor_.getFieldInt(FLD_ID);
      }

      closePopulatorCursor();
      calendars.release();


      if (resources != null && resources.size(getSession()) > 0) updateStatus((ABTObject)resources.at(getSession(),0));

      return resources;

   }
   
   public void setServerName(String server) {server_ = server;}
   public String getServerName() {return server_;}

   protected void linkToUsers(ABTObject resource)
   {
   	ABTCursor tempCursor = getDriver().getRepository().select(getTempResourceCursor(resource));
   	
   	if (userRights_ != null) {
   		int size = userRights_.size();
      	for (int i = 0;i < size;i++) {
      		
            ABTObject currentUser = ((UserRight)userRights_.at(i)).getUser();
      		if (currentUser != null) {
      		   if (tempCursor.bsearchFirst(FLD_RECORDID2,currentUser.getValue(getSession(),FLD_TW_ID))) {
               

                  if (tempCursor.getFieldInt(FLD_FLAGS) >= APPROVE_RIGHT) {

                     ABTValue set = currentUser.getValue(getSession(),FLD_TW_RESOURCE_APPROVAL,null);
                     if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
                        // Maintain uniqueness of the set.
                        ABTObjectSet resources = (ABTObjectSet)set;
                        if (!resources.contains(getSession(), resource)) resources.add(getSession(),resource);
                     }
                  }
         
                  if (tempCursor.getFieldInt(FLD_FLAGS) != APPROVE_RIGHT) {

                     ABTValue set = currentUser.getValue(getSession(),FLD_TW_RESOURCES,null);
                     if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
                        // Maintain uniqueness of the set.
                        ABTObjectSet resources = (ABTObjectSet)set;
                        if (!resources.contains(getSession(), resource)) resources.add(getSession(),resource);
                     }   
                  }
      		   }
      		}
      	}
      } 
   	
   	tempCursor.release();
   }
	
	private final String getTempResourceCursor(ABTObject resource)
   {
   	if (resource == null) return null;
   	
   	int resourceid = resource.getValue(getSession(),FLD_TW_ID).intValue();
   	
   	return new String("select * from PRTemporary where PRTemporary.prRecordID1 = " + resourceid + 
   		               " and PRTemporary.prSessionID = " + getDriver().getRepository().getSession().getID() +
   		               " and PRTemporary.prName = 'ResourceRights' order by PRTemporary.prRecordID2");
   }
}