package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileResource.java 08/11/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-11-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;

//DEBUG
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.io.client.ABTFileHelper;

/**
 *  ABTIOPMWFileResource is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileResource fr = new ABTIOPMWFileResource(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileResource extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       resourceVector_ = null;
//====================================================================================
// Constructors
//====================================================================================     
/**
 *    ABTIOPMWFileResource constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileResource(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_        = OBJ_RESOURCE;
      resourceVector_  = new Vector();
   }
//====================================================================================
// Populate Resource from the Intermediate Hash Table
//====================================================================================
/**
 * Populate resource objects from the Intermediate Hash Table to the space
 * @param Hashtable parms,
 * @return an ABTValue the resource object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
 
   public ABTValue populate(Hashtable parms) throws ABTException 
   {    
    IABTObject  project      = null;
    IABTLocalID resourceID   = null;      
    Object      object       = null;
    ABTValue    resource     = null;
    
    System.out.print(" Populate Resource: ");
     try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object;
            
        //Get the resource ID 
        object = parms.get(OFD_RESOURCE);
        if (object instanceof IABTLocalID) 
            resourceID  = (IABTLocalID)object;
    
        //Check if resource has already been created
        object = null;
        object = driver_.lookupTableGet(resourceID);
        if ( object!= null && object instanceof IABTObject)
            resource = (ABTValue) object;
        else
        {
            //Call to create
            Hashtable reqparms = new Hashtable();
            
            if (project == null)
                reqparms.put(OFD_PROJECT, OFD_PROJECT);    
            else
                reqparms.put(OFD_PROJECT, project);
                
            if (resourceID == null)
                 reqparms.put(OFD_RESOURCE, OFD_RESOURCE);
            else
                reqparms.put(OFD_RESOURCE, resourceID);
                
            resource = create(reqparms); 
        }
      
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return resource;
     }
      
   }

/**
 * Create a new object in the object space and initialize it witha ppropriate values 
 * @param Hashtable parms, associated resource id in the intermediate hash table,the project object
 * @return ABTValue the newly created team
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(Hashtable parms) throws ABTException 
   {
   
      IABTLocalID resourceID = null;      
      IABTObject  project    = null;
      Object      object     = null;
      
      //Get the resource ID 
      object = parms.get(OFD_RESOURCE);
      if (object == OFD_RESOURCE)
        throw new ABTException("Resource ID is null.");     
        
      if (object instanceof IABTLocalID) 
             resourceID  = (IABTLocalID)object;
       object = null;
       object = driver_.lookupTableGet((ABTValue)resourceID);
       if ( (object != null )&& (object instanceof IABTObject) )
       {
            // TO DO UPDATE
           return (ABTValue)object;
       }

      else
      {
         
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
      
        // Get the array of value associated with resource
        IABTArray   resourceArr  = null;
        object = null;
      
         object = driver_.intermediateTableGet(resourceID);
        if (object instanceof IABTArray)
            resourceArr = (IABTArray) object;
      
        //Get the property set associated with the resource
        IABTPropertySet propSet = null;
        propSet = getProperties(type_); 
      
        //Get the Resource's RemoteID
        ABTValue  id = null;      
        IABTObject resourceObj = null;
        IABTHashTable  resparms = (getSpace()).newABTHashTable();
      
        resparms.putItemByString(OFD_SITE,  driver_.getSite());
      
        id = getHashValue(resourceArr, propSet, PROP_REMOTEID);
        if(ABTValue.isNull(id))
            resourceObj = createObject(type_,(ABTRemoteID)null, resparms);
        else if (id instanceof ABTRemoteID)
            resourceObj = createObject(type_,(ABTRemoteID)id, resparms);         
        else
            new ABTException(" WRONG TYPE CAST");
      
        //Set Resource's scalar values.  
        setScalarValues(propSet, resourceArr, resourceObj);
      
        //Get resource's note IDs
        ABTValue  noteVal = null;    
        noteVal = getHashValue(resourceArr, propSet, OFD_NOTES);
      
        ABTIOPMWFileNote noteHelper = new ABTIOPMWFileNote(driver_);
     
        Hashtable reqparms = new Hashtable();
        if (project == null)
            reqparms.put(OFD_PROJECT,OFD_PROJECT);
        else
            reqparms.put(OFD_PROJECT,project);
        
        if (noteVal == null)
            reqparms.put(OFD_NOTES,OFD_NOTES);   
        else
            reqparms.put(OFD_NOTES,noteVal); 
        
        if (resourceObj == null)
            reqparms.put(TARGET_OBJ,TARGET_OBJ);
        else
            reqparms.put(TARGET_OBJ, resourceObj);
        
        noteHelper.populate(reqparms);

        if ( (driver_.lookupTablePut(resourceID,resourceObj)) != null)
		    throw new ABTException(" The object already exists in the lookup table");
		return (ABTValue)resourceObj;    
    }   
    
   }
   





//====================================================================================
// Save Resource to an Intermediate Hash Table
//====================================================================================
/**
 * Saves resource objects from the object space back to the Intermediate Hash Table
  * @param Hashtable parms 
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
        IABTObject project = null;
        
        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 

         
        IABTObjectSet teamOs = getObjectSet(project, OFD_TEAMRESOURCES);
                    
        for (int i =0; i < size(teamOs); i++)
        {
            IABTObject  teamObj     = (IABTObject)at(teamOs, i);
            IABTObject  resourceObj = getObject(teamObj, OFD_RESOURCE);
            
            // Make sure the object is of type resource
            if (!resourceObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the resource in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(resourceObj);
            if (arr==null)
                throw new ABTException("The arr of Resource values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID resourceId = resourceObj.getID();
            if (resourceId == null)
                throw new ABTException("RESOURCE ID is null.");
        
            if ( (driver_.intermediateTableGet(resourceId))!= null)
                if (( driver_.intermediateTablePut(resourceId, arr)) != null)
                    throw new ABTException("The RESOURCE ID already exist.");
                else
                    //DEBUG
                    resourceVector_.addElement(resourceId);
        }
     
   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


}