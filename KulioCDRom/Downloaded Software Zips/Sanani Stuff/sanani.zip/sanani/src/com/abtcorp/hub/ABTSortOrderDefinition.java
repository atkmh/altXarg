
package com.abtcorp.hub;

/*
 * ABTRowComparator.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
import java.util.Enumeration;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

public class ABTSortOrderDefinition extends ABTArray implements ABTComparator
{
   private ABTPropertySet my_set;
   ABTUserSession mySession = null;
  /**
   * Class construcotr for initial setting
   * @param new_set property set this sort order is based on.
   */
   protected  ABTSortOrderDefinition(ABTUserSession session,ABTRule rule_)
   {
      super();
      mySession = session;
      my_set = rule_.getProperties();
   }

   private  ABTSortOrderDefinition(ABTSortOrderDefinition old_)
   {
      super();
      mySession = old_.mySession;
      my_set = old_.my_set;
   }

   /**
   * make a copy of my definition
   */

   public ABTSortOrderDefinition clone(ABTUserSession session_)
   {
        ABTSortOrderDefinition so =  new ABTSortOrderDefinition(this);
        so.mySession = session_;
        return so;
   }

   /**
   * make a copy of my definition
   */

//   public Object clone()
//   {
//        return new ABTSortOrderDefinition(this);
//   }


   public synchronized Object add(Object object)
   {
      if (object instanceof ABTSortOrderPosition)
         return super.add(object);
      else
         return null;
   }

   public synchronized Object add(String property_, boolean asc_)
   {
      return add(new ABTSortOrderPosition(my_set,property_,asc_));
   }




   public int compare(Object object1, Object object2)
   {
      if ((object1 == null) && (object2 == null))
         return 0;
      if ((object2 == null) || (!(object2 instanceof ABTObject)))
         return 1;
      if ((object1 == null) || (!(object1 instanceof ABTObject)))
         return -1;

    int comp = 0;

    if (size() <= 0)
      return ((ABTObject)object1).compareTo((ABTObject)object2); // compare by ABTID

    Enumeration iterator = elements();
    while ( ( iterator.hasMoreElements() ))
    {
       ABTSortOrderPosition asp = ((ABTSortOrderPosition)(iterator.nextElement()));

       int index = asp.getIndex();
       ABTValue val2 = ((ABTObject)object2).getValue(mySession,index,null);
       ABTValue val1 = ((ABTObject)object1).getValue(mySession,index,null);
       if ((val1 == null) && (val2 == null)) return 0;
       if (val2 == null)
         return 1;
       if (val1 == null)
            return -1;
      comp = val1.compareTo(val2);
//System.out.println("compar : val1: " + val1 + " val2 : " + val2 + " compare at " + comp);
       if (comp != 0)
          if (asp.ascending())
             return (comp);
          else
             return -(comp);
    }
      return 0;
   }



}

