package  com.abtcorp.objectModel.abt.fr;

/*
 * UniqueExternalidInObjectSpace.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 08-27-98       JSE          Initial Design
 * 10-02-98       SOB          Mods to support normalization of single quotes within search strings
 *
 */

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule enforces the uniqueness of this field for all objects of the
 * specified type in the object space.
 *
 * @version	1.0
 * @author  Scott Ellis
 */

public class UniqueExternalIdInObjectSpace extends SiteFieldRule
{
   /**
    * The new value for the external id must be unique for the object type
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      if( ABTValue.isNull( newValue ) )
         return new ABTErrorRules( "UniqueExternalidInObjectSpace->onSet", "Illegal Value",
            "Attempting to set the externalid to null or empty" );

      if( !ABTValue.isNull( myValue ) && newValue.equals( myValue ) )
         return myValue;

      String objectType = parent.getObjectType();

      ABTRule rule = parent.getRule();
      ABTObjectSpace objectspace = rule.getObjectSpace();


//      ABTValue v = (ABTObjectSet)objectspace.findObject( session, objectType,
//         OFD_EXTERNALID + " = " +
//         ABTString.normalizeQuotes( newValue.toString() ));
      ABTValue v = objectspace.findObject ( session,
                                            objectType,
                                            OFD_EXTERNALID,
                                            newValue);
      if (ABTError.isError( v ) )
      {
         // couldn't find the object - everything is ok
         return write( session, parent, property, myValue, newValue, false );
      }
         else
            return new ABTErrorRules( "UniqueExternalidInObjectSpace->onSet", "Duplicate Detected",
               "Attempting to set the externalid to an existing value" );

   }
}
