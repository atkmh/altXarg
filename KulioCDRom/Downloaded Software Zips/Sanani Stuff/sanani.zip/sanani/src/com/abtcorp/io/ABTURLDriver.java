package com.abtcorp.io;

import java.net.URL;
import java.net.URLConnection;
import java.io.InputStream;
import java.io.OutputStream;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTError;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

/***
 * Base class for an ABTDriver for URLs. Drivers of this type will populate ABTObjectSpaces
 * from a URL and save the ABTObjectSpace to a URL. 
 *
 */
public class ABTURLDriver extends ABTDriver
{
   /***
    * The URLConnection associated with the URL for this driver. The URLConnection's input stream and output stream are used for
    * the underlying reading and writing.
    */
   private URLConnection connection_;
   /***
    * The URL associated with this driver.
    */
   private URL url_;
   /***
    * The input stream from the URLConnection. This stream is used to read the data for the populate method.
    */
   private InputStream input_;
   /*** 
    * The output stream from the URLConnection. This string is used to write the data for the save method.
    */
   private OutputStream output_;

   /***
    * Constructs a URL driver.
    * @param space The ABTObjectSpace associated with this driver.
    * @param URL The URL this driver is supposed to connect with to read and write data.
    */
   public ABTURLDriver(URL url)
   {
      super();
      
      url_ = url;
      open(new ABTHashtable());
   }
   
   /***
    * Establishes a connection the URL associated with this driver.
    * This method opens establishes the URLConnection based on the URL passed to the
    * constructor of this object and opens the input and output streams for reading and writing.
    * @return ABTValue ABTError if an error occurs; otherwise, null.
    */
   public ABTValue open(ABTHashtable args) 
   {
      ABTValue ret = null;
      try 
      {
         if (url_ != null) {
            connection_ = url_.openConnection();
            input_ = connection_.getInputStream();
            output_ = connection_.getOutputStream();
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return ret;
   }
   
   /***
    * Populates the ABTObjectSpace based on the specifics of the selector passed and the
    * semantics of this driver. 
    * @param args ABTHashtable of parameters
    * @return ABTValue A variant object that contains the objects that this driver populated based on the selector.
    * @exception ABTNotImplementedException
    *    If the populate method hasn't been implemented by this driver.
    */
   public ABTValue populate(ABTHashtable args) throws ABTNotImplementedException
   {
      throw new ABTNotImplementedException();
   }

   /***
    * Saves the objects passed to the URL based on the criteria specified and the semantics of this driver.
    * @param args ABTHashtable of parameters
    * @return ABTValue ABTError if an error occurs; otherwise, null
    * @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue save(ABTHashtable args) throws ABTException
   {
      throw new ABTNotImplementedException();
   }

   /***
    * Closes the URLConnection and its associated input and output streams.
    * @param args ABTHashtable of parameters
    * @return ABTValue ABTError if an error occurs; otherwise, null
    * @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue close(ABTHashtable args) throws ABTException
   {
      try {
         if (input_ != null) {
            input_.close();
         }

         if (output_ != null) {
            output_.flush();
            output_.close();
         }
      } catch (Exception e) {
         throw new ABTException(e.getMessage());
      }
      return (ABTValue) null;
   }

   /***
    * Sets this driver to output mode.
    */
   public void setOutput()
   {
      connection_.setDoInput(false);
      connection_.setDoOutput(true);
   }

   /***
    * Sets this driver to input mode.
    */
   public void setInput()
   {
      connection_.setDoInput(true);
      connection_.setDoOutput(false);
   }
   
   /***
    * Tests what mode this driver is currently set.
    * @return boolean True - the driver is in input mode; False - the driver is in output mode.
    */
   public boolean isInput() {return connection_.getDoInput();}

   /***
    * Gets the underlying input stream for this driver.
    * @return InputStream The input stream associated with the URL for this driver.
    */
   public InputStream   getInput()     {return input_;}
   /*** 
    * Gets the underlying output stream for this driver.
    * @return OutputStream The output stream associated with the URL for this driver.
    */
   public OutputStream  getOutput()    {return output_;}
}