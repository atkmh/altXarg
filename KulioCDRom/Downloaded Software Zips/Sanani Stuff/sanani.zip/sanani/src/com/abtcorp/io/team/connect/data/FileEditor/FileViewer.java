package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.io.team.Argument;
import com.abtcorp.component.util.ABTIconFactory;

import java.awt.Color;
import java.awt.Point;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.util.Vector;
import java.util.Hashtable;

import javax.swing.*;
import javax.swing.event.InternalFrameListener;
import javax.swing.event.InternalFrameEvent;
import javax.swing.JOptionPane; 

/*
 * //imports Needed to make this an applet
 *
 * import java.util.Enumeration;
 * import java.net.URL;
 * import java.awt.Image;
 * import java.applet.AudioClip;
 * import java.applet.AppletContext;
 * import java.applet.AppletStub;
 */
 
public class FileViewer 
    extends JFrame 
    implements ActionListener, MouseListener, WindowListener, InternalFrameListener //ItemListener
               //,AppletStub, AppletContext
{
   //Applet Stuff
   /*private final Applet thisApplet;
   private final String name;
   private final Properties parameters;
   private String path;
   */
   
   private static String ICON_DIR = "/com/abtcorp/io/team/connect/data/FileEditor/icons/";
   private String directory_;
   private String file_;
   private JTable mainTable;
   private JPanel tablePanel;
   private JDesktopPane layeredDesktop;
   private JTable currentTable;
   private JInternalFrame currentWin;
   private OpenFileDialog openDialog_;
   private EditorToolBar toolBar_;
  
   public FileViewer()//Applet thisApplet, int width, int height, String name, Properties parameters) 
   {
      //Applet stub stuff...
      /*this.thisApplet = thisApplet;
      this.name = name;
      this.parameters = parameters;
      */
      
      /*UIManager.LookAndFeelInfo laf[] = UIManager.getInstalledLookAndFeels();
      for(int i = 0; i < laf.length; i++)
      {
            System.out.println(laf[i].getName() + ":  " + laf[i].getClassName());
      }*/
      
     
      try
      {
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
      }catch(ClassNotFoundException ex){
            System.err.println("UIManager threw ClassNotFoundException");
      }catch(InstantiationException ex){
            System.err.println("UIManager threw InstantiationException");
      }catch(IllegalAccessException ex){
        System.err.println("UIManager threw IllegalAccessException");
      }catch(UnsupportedLookAndFeelException ex){
        System.err.println("UIManager threw UnsupportedLookAndFeelException");
      }
    
      
      this.addWindowListener(this);
      
      setTitle( "File Viewer" );
      setSize( 800, 600 );
      setBackground( Color.gray );

      layeredDesktop = new JDesktopPane();
      layeredDesktop.setBackground(getContentPane().getBackground());
      getContentPane().add("Center", layeredDesktop);
	  	  
	  toolBar_ = new EditorToolBar(this);
	  getContentPane().add("North", toolBar_);
	  
      directory_ = "C:/InetPub/scripts/servlets";   //Default directory
	  
      openDialog_ = new OpenFileDialog(this, "Open:", this, directory_);
      openDialog_.setBounds(100,100,300,240);
      
      file_ = openDialog_.getFile();  //Default file
   }
   
   public void run(String[] args)
   {
      Argument parser = new Argument("d,f,?,h");
      
      parser.parse(args);
      
      String help = (String)parser.get("?");
      if (help != null && help.length() > 0) {
         usage();
         return;
      }
      
      help = (String)parser.get("h");
      if (help != null && help.length() > 0) {
         usage();
         return;
      }
      
      String directory = (String)parser.get("d");
      if (directory != null && directory.length() > 0) {
         directory_ = directory;
         openDialog_.setDir(directory_);
      }
      
      String file = (String)parser.get("f");
      if (file != null && file.length() > 0) {
         file_ = file;
         openTable(file_, directory_);
         repaint();
         validate();
      }
      
    }
   
   private void openTable(String tableFile, String tableDir)
   {
        FVFileReader file = new FVFileReader(tableFile, tableDir);       
        Hashtable data = file.expand();
        
        if((data == null) || (data.size() < 1)){
            String[] mesg = {"Sorry:", "Unable to open File."};
            JOptionPane.showMessageDialog(this, mesg);
            return;
        }
        
        ViewerTableDataModel dataModel =  new ViewerTableDataModel(data);
        
        if(dataModel.isEmpty()){
            String[] mesg = {"Sorry:", "File for '" + tableFile + "' contains no data"};
            JOptionPane.showMessageDialog(this, mesg);
            return;   
        }
        
        buildTable(dataModel, tableFile);
    }
 
   private void expandCell()
   {        
        ViewerTableDataModel oldModel =  (ViewerTableDataModel) currentTable.getModel();
        int row = currentTable.getSelectedRow();
        int col = currentTable.getSelectedColumn();
        Object element = oldModel.getObjectAt(row, col);
        
        if(element instanceof Expandable)
        {   
            Hashtable data = ((Expandable)element).expand();

            ViewerTableDataModel newModel =  new ViewerTableDataModel( data);

            if(newModel.isEmpty()){
                String[] mesg = {"Sorry:", "This " + element + " contains no data"};
                JOptionPane.showMessageDialog(this, mesg);
                return;             
            }
            
            String title = currentWin.getTitle() + "/" + oldModel.getColumnName(col) + " for " 
                               + oldModel.getColumnName(0) + " '" + oldModel.getValueAt(row,0) + "'";
            buildTable(newModel, title);
        }
   }
   
   private JTable buildTable(ViewerTableDataModel dataModel, String title)
   {
        JTable newTable = new JTable(dataModel);
        newTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        newTable.getTableHeader().setResizingAllowed(true);
        newTable.getTableHeader().setReorderingAllowed(false);
        newTable.getTableHeader().resizeAndRepaint();
        newTable.setShowHorizontalLines( true );
        newTable.setRowSelectionAllowed( true );
        newTable.setCellSelectionEnabled( true );
        newTable.setColumnSelectionAllowed( false );
        newTable.setSelectionForeground( Color.white );
        newTable.addMouseListener(this);
	    
        //if(currentWin != null)
	    //    title = currentWin.getTitle() + title;

	    JInternalFrame tableWin = new JInternalFrame(title, true,true,true,true);
	    
	    tableWin.setBounds(50,50,480,360);
	    layeredDesktop.add("Center", tableWin);
		
        JScrollPane scrollPane = JTable.createScrollPaneForTable(newTable);
        tableWin.getContentPane().setLayout(new BorderLayout());
        tableWin.getContentPane().add("Center", scrollPane);
        tableWin.show();
        
        tableWin.addInternalFrameListener(this);
        
        currentTable = newTable;
        currentWin = tableWin;
        return newTable;
   }   
   
   //Event Listeners  
   //================================================================

   //****Action Listeners****
   public void actionPerformed(ActionEvent event)
   {
        if(event.getActionCommand().equals("Exit"))
        {
            System.exit(0);   
        }
        else if(event.getActionCommand().equals("Open"))
        {
            openDialog_.setBounds(getLocation().x + 20, getLocation().y + 60, 300,200);
            openDialog_.setVisible(true);
        }
        else if(event.getActionCommand().equals("Expand"))
        {
            expandCell();
            toolBar_.setExpandButton(false);
        }
        else if(event.getActionCommand().equals("Open_Table_Now"))
        { 
            directory_ = openDialog_.updateDir();
            file_ = openDialog_.getFile();
            openDialog_.setVisible(false);
            openTable(file_, directory_);
        }
        else if(event.getActionCommand().equals("Hide_Open_Dialog"))
        {
            openDialog_.setVisible(false);   
        }
        else if(event.getActionCommand().equals("Find"))
        {
            String searchFor = JOptionPane.showInputDialog(currentWin, "Enter 'Key' to find:");
            if(searchFor != null){
                Point p = ((ViewerTableDataModel)currentTable.getModel()).findKey(searchFor);
                if(p != null){
                    currentTable.setColumnSelectionInterval((int)p.getX(), (int)p.getX());
                    currentTable.setRowSelectionInterval((int)p.getY(), (int)p.getY());
                    ((JScrollPane)currentWin.getContentPane().getComponent(0)).getViewport().setViewPosition(new Point(0, (int)p.getY() * currentTable.getRowHeight() ));
                }
                else{
                    System.out.println("Key not found");
                }
            }
        }
        else if(event.getActionCommand().equals("Usage"))
        {
            usage();
        }
        repaint();
        validate();
   }

   //****Mouse Listeners****
   public void mouseClicked(MouseEvent e)
   {
        currentTable = (JTable)e.getSource();
        int row = currentTable.getSelectedRow();
        int col = currentTable.getSelectedColumn();
        ViewerTableDataModel dataModel = (ViewerTableDataModel)currentTable.getModel();
        if((row > dataModel.getRowCount() || row < 0) ||
            (col > dataModel.getColumnCount() || col < 0)){
            return;
        }
        else{
            if(dataModel.getObjectAt(row,col) instanceof Expandable)
                toolBar_.setExpandButton(true);      
            else
                toolBar_.setExpandButton(false);
        } 
   }
   public void mousePressed(MouseEvent e) 
   {
        currentTable = (JTable)e.getSource();
        int row = currentTable.getSelectedRow();
        int col = currentTable.getSelectedColumn();
        ViewerTableDataModel dataModel = (ViewerTableDataModel)currentTable.getModel();
        if((row > dataModel.getRowCount() || row < 0) ||
           (col > dataModel.getColumnCount() || col < 0)){
            return;
        }
        else{
            if(dataModel.getObjectAt(row,col) instanceof Expandable)
               toolBar_.setExpandButton(true);      
            else
               toolBar_.setExpandButton(false);
        }
   }
   public void mouseReleased(MouseEvent e)
   {
        currentTable = (JTable)e.getSource();
        int row = currentTable.getSelectedRow();
        int col = currentTable.getSelectedColumn();
        ViewerTableDataModel dataModel = (ViewerTableDataModel)currentTable.getModel();
        if((row > dataModel.getRowCount() || row < 0) ||
           (col > dataModel.getColumnCount() || col < 0)){
            return;
        }
        else{
            if(dataModel.getObjectAt(row,col) instanceof Expandable)
               toolBar_.setExpandButton(true);      
            else    
               toolBar_.setExpandButton(false);
       }
   }
   public void mouseEntered(MouseEvent e){}
   public void mouseExited(MouseEvent e){}
   
   //****Internal Frame Listeners****
   public void internalFrameActivated(InternalFrameEvent e){
        currentWin = (JInternalFrame)e.getSource();
   }
   public void internalFrameClosed(InternalFrameEvent e){
        ((JInternalFrame)e.getSource()).dispose();
        toolBar_.setExpandButton(false);//).setEnabled(false);
        repaint();
        validate();
   }
   public void internalFrameClosing(InternalFrameEvent e){}
   public void internalFrameDeactivated(InternalFrameEvent e){}
   public void internalFrameDeiconified(InternalFrameEvent e){
        repaint();
        validate();
   }
   public void internalFrameIconified(InternalFrameEvent e){
        repaint();
        validate();
   }
   public void internalFrameOpened(InternalFrameEvent e){
        repaint();
        validate();
   }

   //****Window Listeners**** 
   public void windowActivated(WindowEvent e) {}
   public void windowClosed(WindowEvent e) {}
   public void windowClosing(WindowEvent e) {System.exit(0);}
   public void windowDeactivated(WindowEvent e) {}
   public void windowDeiconified(WindowEvent e) {}
   public void windowIconified(WindowEvent e) {}
   public void windowOpened(WindowEvent e) {}


   //Application Methods
   //===============================================================

   public static void main(String[] args)
   {
      FileViewer app = new FileViewer();
      app.setVisible(true);
      app.run(args);
   }
   
   private void usage()
   {
      String[] msg = new String[18];
    
      msg[0]  = "usage: java FileViewer [-options]";
      msg[1]  = " ";
      msg[2]  = "options include:";
      msg[3]  = "  -d=directory     directory where the dat files reside. Default = d:/java/html";
      msg[4]  = "  -f=file                File to view. Possible file names are:";
      msg[5]  = "     team.Project";
      msg[6]  = "     team.Task";
      msg[7]  = "     team.ChargeCode";
      msg[8]  = "     team.TypeCode";
      msg[9]  = "     team.TimePeriod";
      msg[10] = "     team.TimeSheet";
      msg[11] = "     team.CategoryString";
      msg[12] = "     team.Resource";
      msg[13] = "     team.User";
      msg[14] = "     team.Outgoing";
      msg[15] = "     team.Submitted";
      msg[16] = " ";
      msg[17] = "Example: FileEditor -d=d:/java/data -f=team.Project";
     
      JOptionPane.showMessageDialog(this, msg);
     
     /*
      System.out.println("usage: java FileViewer [-options]");
      System.out.println(" ");
      System.out.println("options include:");
      System.out.println("  -d=directory     directory where the dat files reside. Default = d:/java/html");
      System.out.println("  -f=file          File to view. Possible file names are:");
      System.out.println("     team.Project");
      System.out.println("     team.Task");
      System.out.println("     team.ChargeCode");
      System.out.println("     team.TypeCode");
      System.out.println("     team.TimePeriod");
      System.out.println("     team.TimeSheet");
      System.out.println("     team.CategoryString");
      System.out.println("     team.Resource");
      System.out.println("     team.User");
      System.out.println("     team.Submitted");
      System.out.println("     team.Unplanned");
      System.out.println(" ");
      System.out.println("Example: java FileViewer -d=d:/java/data -f=team.Project");  
    */
   }
 
 
 /* 
   //AppletStub Overrides
   //=================================================================
   
   public boolean isActive() {return true;}
   public AppletContext getAppletContext() {return this;}
   public URL getDocumentBase() { return getURL(true);}
   public URL getCodeBase() { return getURL(false);}
   public String getParameter(String requested_property){ return parameters.getProperty(requested_property);}
   public void resizeApplet(int width, int height){ setSize(width, height);}
   //================================================================
   
   //AppletContext Overrides
   //================================================================
   public AudioClip getAudioClip(URL url){ return null;}
   public void showDocument(URL url){}
   public void showDocument(URL url, String target){}
   public Applet getApplet(String name){ return name.equals(thisApplet.getParameter(name)) ? thisApplet : null;}
   public void showStatus(String status){System.out.println(status);}
   public Image getImage(URL url){return Toolkit.getDafaultToolkit().getImage(url);}
   public Enumeration getApplets(){ return null; }
   //=================================================================
   */
}