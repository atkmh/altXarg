package com.abtcorp.io.client.methfile;

/*
 * ABTIOMethFileDeliverable.java 10/21/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-21-98    MXA         Initial Implementation
 *
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTMMRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.idl.IABTEnumerator;
import com.abtcorp.idl.IABTProperty;


import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTError;



import com.abtcorp.io.client.ABTObjectSetIDList;



/**
 *  ABTIOMethFileDeliverable is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOMethFileDriver.
 *
 *  <pre>
 *       ABTIOMethFileDeliverable fr = new ABTIOMethFileDeliverable(driver, parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOMethFileDriver
 */

public class ABTIOMethFileDeliverable extends ABTIOMethFileHelper implements IABTRuleConstants, IABTMMRuleConstants
{

//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOMethFileDeliverable constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOMethFileDeliverable(ABTIOMethFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_MM_DELIVERABLE);
      method_ = parent;
   }

/**
 *  Saves the deliverable objects back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving notes)
 *	@param oSet   the resource object set to be saved back to the loal file
 *  @return       the objects set that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObjectSet oSet) throws ABTException
   {
    try
    {
        super.save(oSet);
    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
        return (ABTValue)oSet;
    }
   }

/**
 * Populate the Deliverable object.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
        ABTValue     val       = null;
	    ABTValue     ret       = null;
        IABTLocalID  id        = null;
        Object       obj       = null;
        ABTObjectSetIDList delivIds = null;


        id = driver_.getMethodId();
        val = getIDs(id,OBJ_MM_METHOD, OFD_ALLDELIVERABLES);

        if (val instanceof ABTObjectSetIDList)
            delivIds  = (ABTObjectSetIDList)val;
         else
            throw new ABTException("Wrong Cast");

        Enumeration itID = delivIds.getActiveIDs();
        while( itID.hasMoreElements() )
        {
           obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            id_ = (IABTLocalID)obj;
           else
            throw new ABTException("Wrong Cast");
            ret = super.populate();

        }
        return ret;
	}

/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
      ABTValue ret = null;
      reqParams_.putItemByString(OFD_METHOD,   (ABTValue)method_);
      ret = super.create(type, id, reqParams_);
      return ret;
   }


 protected void setScalarValues(IABTPropertySet propSet, IABTArray valueArr, IABTObject delivObject) throws ABTException
 {
    super.setScalarValues(propSet, valueArr, delivObject);
    //setReference();

    IABTObjectSet taskos = createObjectSet(OBJ_MM_TASK);

    if (valueArr == null)
        throw new ABTException("setScalarValues()  valueArray is null");
    if (propSet== null)
        throw new ABTException("setScalarValues()  property set is null");

    Enumeration        itp_  = propSet.getElements();
    IABTEnumerator     ita_  = valueArr.getElements();
    ABTValue           val   = null;
    Object             obj   = null;
    ABTObjectSetIDList delivIds = null;

    while(itp_.hasMoreElements())
    {
        IABTProperty prop = ((IABTProperty)(itp_.nextElement()));
        String propName = prop.getName();

        if (!(prop.isVirtual()) && (ita_.hasMoreElements())&& (prop.isVisible()) )
        {
           
            val = null;
            Object valObj = ita_.nextElement();
            if (propName.equals(OFD_TASKS))
            {
                val = (ABTValue)(valObj);
    
                if (val instanceof ABTObjectSetIDList)
                    delivIds  = (ABTObjectSetIDList)val;
                else
                    throw new ABTException("Wrong Cast");

                Enumeration itID = delivIds.getActiveIDs();
                while( itID.hasMoreElements() )
                {
                    obj = null;
                    obj = itID.nextElement();
                    IABTLocalID taskID = null;
                    if ( (obj instanceof IABTLocalID) ||(obj == null) )
                        taskID = (IABTLocalID)obj;
                    else
                        throw new ABTException("Wrong Cast");

                    obj = driver_.lookupTableGet(taskID);
                    if ( obj != null && obj instanceof IABTObject )
                    {
                        IABTObject associatedTask = (IABTObject)obj;
                        add(taskos, associatedTask);
                        IABTObjectSet delivos = (IABTObjectSet)getValue(associatedTask, OFD_DELIVERABLES);
                        add(delivos, delivObject);
                    }
                    else
                        throw new ABTException("Wrong Cast");
                }
            }
        }
    }
    setValue(delivObject, OFD_TASKS, (ABTValue)taskos);
    return;
   }



}