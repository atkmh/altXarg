package com.abtcorp.hub;

/*
 * ABTAllClause.java 05/07/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author        Description
  * 05-07-98	 JSE           Initial Design
  *
  *
  * TO DO:
  *
  * 1-  optimize with field-index access
  * 2-
  */


/**
 * Basic ABTAllClause class - base class for handling
 * an all call
 *
 * @version	1.0
 * @author      Scott Ellis
 */

import java.util.*;
import com.abtcorp.core.*;

public class ABTAllClause extends ABTParserFunction
{
   /**
   * class constructor for an all clause
   * e.g. : ALL( Childtasks.PRNAME like 'SANANI' )
   */
   public ABTAllClause( ABTUserSession session,ABTArray instances_, String field_ , String subfield_, int operation_, ABTValue value_ )
   {
      super( session,instances_, field_, subfield_, operation_, value_ );
   }

   /**
   *  evaluate the expression
   *  @return boolean
   */
   public boolean booleanValue()
   {

      ABTValue val = lookup();
      if (val == null)
         return false; //?whoops

      if (!(val instanceof ABTObjectSet))
         return false; //?whoops

      Enumeration e = ((ABTObjectSet)val).elements(mySession);
      while( e.hasMoreElements() )
      {
         // abolute index-access better be in correct bounds - otherwise
         // there will be an array-out-of-bounds exception
         ABTValue v1 = (ABTValue) e.nextElement();
         if( !ABTError.isError( v1 ) )
         {
             ABTObject o = (ABTObject)v1;
             if( !evaluatePos( o.getValue( mySession,subfield,null ), value ) )
                return false;
         }
         
      }

      return true;
   }
}

