package com.abtcorp.io.team;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{

public static final String Package = "com.abtcorp.io.team".intern();
public static final ABTErrorCode ERR_0 = new ABTErrorCode(Package, "ERR_0", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_1 = new ABTErrorCode(Package, "ERR_1", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_2 = new ABTErrorCode(Package, "ERR_2", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_3 = new ABTErrorCode(Package, "ERR_3", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_4 = new ABTErrorCode(Package, "ERR_4", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_5 = new ABTErrorCode(Package, "ERR_5", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_6 = new ABTErrorCode(Package, "ERR_6", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_7 = new ABTErrorCode(Package, "ERR_7", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_8 = new ABTErrorCode(Package, "ERR_8", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_9 = new ABTErrorCode(Package, "ERR_9", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_10 = new ABTErrorCode(Package, "ERR_10", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_11 = new ABTErrorCode(Package, "ERR_11", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_12 = new ABTErrorCode(Package, "ERR_12", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_13 = new ABTErrorCode(Package, "ERR_13", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_14 = new ABTErrorCode(Package, "ERR_14", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_15 = new ABTErrorCode(Package, "ERR_15", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_16 = new ABTErrorCode(Package, "ERR_16", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_17 = new ABTErrorCode(Package, "ERR_17", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_18 = new ABTErrorCode(Package, "ERR_18", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_19 = new ABTErrorCode(Package, "ERR_19", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_20 = new ABTErrorCode(Package, "ERR_20", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_21 = new ABTErrorCode(Package, "ERR_21", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_22 = new ABTErrorCode(Package, "ERR_22", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_23 = new ABTErrorCode(Package, "ERR_23", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_24 = new ABTErrorCode(Package, "ERR_24", UNRECOVERABLE_ERROR );

}