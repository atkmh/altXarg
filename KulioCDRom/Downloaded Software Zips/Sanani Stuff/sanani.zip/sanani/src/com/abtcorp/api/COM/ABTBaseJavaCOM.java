/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;
import com.ms.com.*;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTValue;

public class ABTBaseJavaCOM implements IBaseJava
   {
   private Object _obj;
   public ABTBaseJavaCOM(Object obj) {
      _obj = obj;
      }
   public void setObject(Object obj) { _obj = obj; }
   public Object getObject( )        {return _obj; }

   public String toString()    { 
      try{ return _obj.toString(); }
      catch (Exception e){throw new com.ms.com.ComFailException(e.getMessage()); }
      }
   public String ToString()    { 
      try{ return _obj.toString(); }
      catch (Exception e){throw new com.ms.com.ComFailException(e.getMessage()); }
      }
   public int  getHashCode()   { return _obj.hashCode(); }
   public int  hashCode()      { return _obj.hashCode(); }

   public boolean EqualTo(Object Parameter0)
                              { return _obj.equals(((IBaseJava)(Parameter0)).getObject()); }
   public Object getClassInfo(){ return _obj.getClass(); }

   public boolean isABTError() { return (_obj instanceof ABTError); }
   public boolean isABTEmpty() { return (_obj instanceof ABTEmpty); }
   }
