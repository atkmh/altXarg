/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTShort.java, 17, 10/13/98 9:43:04 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.io.*;
import java.text.*;

public class ABTShort extends ABTImmutableValue
{
   // We cannot extend from Short since it is final

   /**
   * nice helper for WBS etc.
   */
   private static ABTShort minus1_ = null;
   private static final long serialVersionUID = 7515723908773894738L;

   protected short value_;

    public void fromByte(byte[] input){};
    public byte[] fromByte(){ return null;};
   public ABTShort(short    value) {value_ = value;}
   public ABTShort(ABTValue value) {value_ = value.shortValue();}

   public boolean booleanValue() {return value_ != 0;}
   public short   shortValue()   {return value_;}
   public int     intValue()     {return value_;}
   public double  doubleValue()  {return value_;}
   public String  stringValue()  {return NumberFormat.getInstance().format(value_);}

   public static ABTShort valueOf(String string) {return new ABTShort(new ABTString(string));}
   
   public int hashCode() {return value_;}

   // Warning: This is a loose compare since we will convert the argument
   //          using rounding, truncation or parsing

   public int compareTo(Object object) 
   {
    if (object == null) return 1;     
    return compareTo(((ABTValue)object).shortValue());
   }

   public final int compareTo(short value)
   {
      if (value_ == value) return 0;
      
      return value_ < value ? -1 : +1;
   }

   // This optimizes the serialization

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeShort(value_);
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      value_ = stream.readShort();
   }
   
   public static ABTShort  Minus1()
   {
        if (minus1_ == null)
            minus1_ = new ABTShort((short)-1);
        return minus1_;
   }
}