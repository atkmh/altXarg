package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

public class ResourceData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public ResourceData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_RESOURCE) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         if (property.getName().equals(FLD_TW_MODIFIED)) continue;

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            // Typecodes and resource projects are saved as ids.
            // Assignments are saved as elements in a hashtable.
            if (property.getName().equals(FLD_TW_TYPECODE)) {

               ABTValue object = object_.getValue(session_,property.getName());
               if (ABTError.isError(object) || ABTEmpty.isEmpty(object)) continue;

               ABTValue id = ((ABTObject)object).getValue(session_,FLD_TW_INTERNALID);
               table.put(property.getName(),id);

            } else if (property.getName().equals(FLD_TW_PROJECTS)) storeIDs(property,table);
            else if (property.getName().equals(FLD_TW_TIMESHEETS)) storeIDs(property,table);   
            else if (property.getName().equals(FLD_TW_ASSIGNMENTS)) {
               // Save an Hashtable of assignments. The keys are the FLD_TW_INTERNALID of the assignment.
               Hashtable assignments = new Hashtable(50,(float).85);

               ABTValue test = object_.getValue(session_,FLD_TW_ASSIGNMENTS);
               if (ABTError.isError(test) || ABTEmpty.isEmpty(test)) continue;

               ABTObjectSet set = (ABTObjectSet)test;
               for (int i = 0;i < set.size(session_);i++) {
                  ABTObject assignment = (ABTObject)set.at(session_,i);
                  try {
                     AssignmentData data = new AssignmentData(assignment,session_);
                     assignments.put(assignment.getValue(session_,FLD_TW_INTERNALID),data.getValues());
                  } catch (Exception exception) {
                  }
               }

               table.put(property.getName(),assignments);
            } else table.put(property.getName(),value);
         }
      }
      return table;
   }
   
   private void storeIDs(ABTProperty property, Hashtable table)
   {
      // Save an array of timesheet ids that can be retrieved later.
      DataArray array = new DataArray();

      ABTValue check = object_.getValue(session_,property.getName());
      if (ABTError.isError(check) || ABTEmpty.isEmpty(check)) return;

      ABTObjectSet set = (ABTObjectSet)check;
      for (int i = 0;i < set.size(session_);i++) {
         ABTObject object = (ABTObject)set.at(session_,i);

         ABTValue id = object.getValue(session_,FLD_TW_INTERNALID);
         if (ABTError.isError(id) || ABTEmpty.isEmpty(id)) continue;
         array.add(id);
      }

      table.put(property.getName(),array);
   }
}
