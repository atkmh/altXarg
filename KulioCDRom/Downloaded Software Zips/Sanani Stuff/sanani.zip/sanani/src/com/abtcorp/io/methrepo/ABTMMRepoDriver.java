package com.abtcorp.io.methrepo;

/*
 * ABTMMRepoDriver.java 05/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
* 05-26-98    LZX         Initial Implementation
* 06-30-98    LZX         Removed the "open" method. Use the one from super class.
* 07-10-98    LZX         Support transactions
* 07-14-98    LZX         Clean up code, comments, etc.
* 07-20-98    LZX         Separated site driver.
* 07-23-98    LZX         Modified "populate" and "save" methods so that no repo name is needed.
* 08-05-98    LZX         Use new business rules, io.server package, etc.
*
*/

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTExtendedPropertyList;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;
import com.abtcorp.io.siterepo.*;

/**
 *  ABTMMRepoDriver is the ABT Repository driver for the Widgeon (Methodology) application.
 *  It is instantiated by the Widgeon application.
 *
 *  <pre>
 *       ABTMMRepoDriver driver = new ABTMMRepoDriver();
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTDriver, ABTRepositoryDriver
 */

public class ABTMMRepoDriver extends ABTRepositoryDriver 
      implements IABTIOMethRepoConstants, com.abtcorp.idl.IABTMMRuleConstants, com.abtcorp.io.siterepo.IABTSiteRepoConstants
{
   private static String component_ = "ABTMMRepoDriver";
   private ABTObject site_ = null;
   private ABTCursor resCursor_ = null;
   private ABTCursor estCursor_ = null;
   private ABTCursor custCursor_ = null;
   private ABTCursor adjCursor_ = null;
   
//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTMMRepoDriver default constructor.
 */
   public ABTMMRepoDriver(){super();}

/**
 *	Create an ABTRepositoryDriver that is associated with an ABTObjectSpace.
 *	@param space: The ABTObjectSpace object with which this ABTRepositoryDriver is associated.
 * @param session: the reference to the user session.
 */
   public ABTMMRepoDriver(ABTObjectSpace space, ABTUserSession session)
   {
      super(space, session);
   }


//====================================================================================
// public methods: populate(), save(), execute(), etc.
//====================================================================================


/**
 *		Populates the ABTObjectSpace with objects from the ABT Repository.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.  If an error occurs, an ABTError is returned.
 */
   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      boolean lock = false;
      boolean thinly = false;
      ABTValue val = null;
      boolean transactionStarted = false;
      ABTArray extIDs = null;

      val = checkParms(space, session, args, MOD_POPULATE);
      if (ABTError.isError(val))
         return val;

      // make sure the site object has been populated in the object space.
      val = getSite();
      if (ABTError.isError(val))
         return val;
      else
         site_ = (ABTObject)val;

      try
      {
         // start the transaction now
         session.startTransaction();
         transactionStarted = true;

         // get object type from hash table
         String type = getStringValue(args, KEY_TYPE);
         // populate the method object(s)
         if (type.equalsIgnoreCase(TYPE_METHOD))
         {
            // check if this is a "thinly" populate
            String subtype = getStringValue(args, KEY_SUBTYPE);
            if ((subtype != null) && (subtype.equalsIgnoreCase(SUBTYPE_METHODONLY)))
               thinly = true;
            
            // get lock flag
            lock = getBooleanValue(args, KEY_LOCK, false);
            
            // can not lock method if populate "thinly"
            if (thinly && lock)
               val = new ABTError(component_,
                         MOD_POPULATE,
                         errorMessages.ERR_CANNOT_LOCK_THINLY,
                         "The method can not be locked when it is populated thinly.");
                         
            else
            {
               // get extID or extIDs from the hash table
               // NOTE: I should be using ABTArrayLocal instead of ABTArray however,
               // the ABTArrayLocal's add() method is not working!!!
               extIDs = new ABTArray();
               String extID = getStringValue(args, KEY_EXTID);
               if (extID != null)
                  extIDs.insert(0, extID);
               else
               {
                  val = (ABTValue) args.getItemByString(KEY_EXTIDS);
                  if (val instanceof ABTArray)
                     extIDs = (ABTArray) val;

                  // make sure the ext id list is not empty if populate fully.
                  if (!thinly && ((extIDs == null) || (extIDs.size() == 0)))
                     val = new ABTError(component_,
                               MOD_POPULATE,
                               errorMessages.ERR_INVALID_ID,
                               "The method external ID(s) need to be specified.");
               }
            }            
            
            // populate if everything is OK
            if (!ABTError.isError(val))
               val = populateMethods(extIDs, lock, thinly, args);
         }

         else
            // input type is invalid
            val = new ABTError(component_,
                     MOD_POPULATE,
                     errorMessages.ERR_INVALID_TYPE,
                     "Can not populate objects of type " + type );

      }     // end try block
      catch (ABTException e)
      {
         val = e.getError();
         // turn ABTException into ABTError if it wasn't constructed with one.
         if (val == null)
            val = new ABTError(component_, MOD_POPULATE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Throwable e)
      {
         // turn Java Exception or Error into ABTError.
         val = new ABTError(component_, MOD_POPULATE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      finally
      {
      }

      // If an error occurred, roll back the transaction.
      if (transactionStarted)
      {
         if (ABTError.isError(val))
            session.rollbackTransaction();
         else
            session.commitTransaction();
         transactionStarted = false;
      }
      
      return val;
   }


/**
 *		Saves object or objectset identified in the hashtable back to the repository.
 *		User must have "prMethodologyAuthor" right in order to write data to the repository.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *    @return ABTValue ABTError if an error occurred; null, otherwise.
 */
   public ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      boolean unlock = false;
      boolean saveAs = false;
      String saveAsExtID = null;
      ABTValue val = null;

      // check space, user session, repository, etc.
      val = checkParms(space, session, args, MOD_SAVE);
      if (ABTError.isError(val))
         return val;

      // Verify the rights of this user. Must be method author.
      if (!getRepository().checkRight(IS_METHODAUTHOR))
         return new ABTError(component_,
                  MOD_SAVE,
                  errorMessages.ERR_INSUFFICIENT_RIGHT,
                  "user '" + getUser() + "' does not have '" + IS_METHODAUTHOR + "' right");

      // get source object or object set from the hash table
      ABTValue obj = getSource(args);
      if (obj instanceof ABTError)
         return obj;
         
      // check if this is a "save-as" request
      String subtype = getStringValue(args, KEY_SUBTYPE);
      if ((subtype != null) && (subtype.equalsIgnoreCase(SUBTYPE_SAVEAS)))
      {
         saveAsExtID = getStringValue(args, KEY_EXTID);
         if ((saveAsExtID == null) || (saveAsExtID.length() == 0))
            return new ABTError(component_,
               MOD_SAVE,
               errorMessages.ERR_MISSING_EXTID,
               "ExtID is null or empty. It must be provided for SaveAs.");
         else
            saveAs = true;
      }

      // get unlock flag (temp code, will be removed later)
      unlock = getBooleanValue(args, KEY_UNLOCK, false);
      if (unlock == true)
         return new ABTError(component_,
               MOD_SAVE,
               errorMessages.ERR_INVALID_KEY,
               "Unlock is not supported as a key for save()");
               
      try
      {
         // save methods.
         val = saveMethods(obj, saveAs, saveAsExtID);

      }                    // end try block

      catch (ABTException e)
      {
         val = e.getError();
         // turn ABTException into ABTError if it wasn't constructed with one.
         if (val == null)
            val = new ABTError(component_, MOD_SAVE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Throwable e)
      {
         // turn Java Exception or Error into ABTError.
         val = new ABTError(component_, MOD_SAVE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      finally
      {
      }

      return val;
   }


/**
 *		executes special commands issued by the user.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.  If an error occurs, an ABTError is returned.
 */
   public ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      boolean lock = false;
      ABTValue val = null;

      val = checkParms(space, session, args, MOD_EXECUTE);
      if (ABTError.isError(val))
         return val;

      try
      {
         // get command from the hash table
         String cmd = getStringValue(args, KEY_COMMAND);

         // get type from hash table
         String type = getStringValue(args, KEY_TYPE);

         if (cmd.equalsIgnoreCase(CMD_LIST))
         {
            // get list of methods from repository
            if (type.equalsIgnoreCase(TYPE_METHOD))
               val = getMethodNameList();

            else
               // call the super execute to deal with other types (repository, etc.)
               val = super.execute(space, session, args);
         }
         else if (cmd.equalsIgnoreCase(CMD_UNLOCK))
         {
            // unlock the method specified by external id
            String extID = getStringValue(args, KEY_EXTID);
            val = unlock(extID);
         }
         else if (cmd.equalsIgnoreCase(CMD_GETUSERNAME))
         {
            // retrieve the user's login name
            //val = getUserName(getSession().getUserID());
            val = new ABTString(getSession().getUserName());
         }
         else
            // input command is invalid
            val = new ABTError(component_,
                     MOD_EXECUTE,
                     errorMessages.ERR_INVALID_COMMAND,
                     "Command '" + cmd +  "' is not supported." );

      }                    // end try block

      catch (ABTException e)
      {
         val = e.getError();
         // turn ABTException into ABTError if it wasn't constructed with one.
         if (val == null)
            val = new ABTError(component_, MOD_EXECUTE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Throwable e)
      {
         // turn Java Exception or Error into ABTError.
         val = new ABTError(component_, MOD_EXECUTE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      finally
      {
      }

      return val;
   }


//====================================================================================
// private methods
//====================================================================================

/**
 * Populate the methods that match the specified external IDs. User must have
 * "prMethodologyAuthor" right in order to lock the methods. If the site (global)
 * object hasn't been populated, it will be done here before the methods are populated.
 * @param extIDs: array of the unique external ID of the desired methods
 * @param lock: whether or not to populate method with lock (true=lock, false=do not lock)
 * @param args: the hash table.
 *	@return an object set which contains the populated methods.
 *	@exception Throwable Thrown if an unrecoverable error occurs.
 */
   private ABTValue populateMethods(ABTArray extIDs, boolean lock, boolean thinly, ABTHashtable args) throws Throwable
   {
      ABTValue val = null;

      try
      {
         // get cursors for global data (needed for missing global objects and looking
         // up external ids or names)
         resCursor_ = getCursor(QRY_RESOURCEROLES, TBL_RESOURCE + "." + FLD_ID);
         estCursor_ = getCursor(QRY_ESTMODELS, TBL_MRESTMODEL + "." + FLD_ID);
         custCursor_ = getCursor(QRY_CUSTOMFIELDS, TBL_MRCUSTOMFIELD + "." + FLD_ID);
         adjCursor_ = getCursor(QRY_ADJRULES, TBL_MRADJRULE + "." + FLD_ID);

         // populate the missing global objects
         populateMissingGlobals();

         // populate the specified method objects
         ABTIOMethRepoMethod methodHelper = new ABTIOMethRepoMethod(this);
         if (thinly)
            val = methodHelper.populateThinly();
         else
            val = methodHelper.populate(extIDs, lock);
      }
      finally
      {
         // release the global cursors after all the methods have been populated
         resCursor_.release();
         estCursor_.release();
         custCursor_.release();
         adjCursor_.release();
      }
      
      return val;
   }

/**
 * Populate the missing global objects using helpers in the site repo driver package.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
private void populateMissingGlobals() throws ABTException
{
      com.abtcorp.io.siterepo.Resource resHelper =
         new com.abtcorp.io.siterepo.Resource(this, site_);
      resHelper.populate(resCursor_, true);

      com.abtcorp.io.siterepo.EstModel estHelper = 
         new com.abtcorp.io.siterepo.EstModel(this, site_);
      estHelper.populate(estCursor_, true);

      com.abtcorp.io.siterepo.CustomField custHelper =
         new com.abtcorp.io.siterepo.CustomField(this, site_);
      custHelper.populate(custCursor_, true);

      com.abtcorp.io.siterepo.AdjRule adjHelper = 
         new com.abtcorp.io.siterepo.AdjRule(this, site_);
      adjHelper.populate(adjCursor_, true);
}

/**
 * Save methods back to the repository.
 * @param obj: the object or object set to be saved.
 * @param unlock: whether or not to unlock the method. (true=unlock, false=do not unlock)
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue saveMethods(ABTValue obj, boolean saveAs, String saveAsExtID ) throws ABTException
   {
      ABTValue val = null;
      ABTObjectSet oSet = null;

      // convert the input value to ABTObject or ABTObjectSet.
      if (obj instanceof ABTObject)
      {
		   val = getSpace().createObjectSet(getUserSession(), OBJ_MM_METHOD);
         if( ABTError.isError( val ) )
            throw new ABTException((ABTError)val);
         oSet = (ABTObjectSet) val;
         oSet.add(getUserSession(), (ABTObject) obj);
      }
      else if (obj instanceof ABTObjectSet)
      {
         oSet = (ABTObjectSet) obj;
         
         // can't be object set for save-as
         if (saveAs && (oSet.size(getUserSession()) > 1))
            return new ABTError(component_,
               MOD_SAVE,
               errorMessages.ERR_INVALID_SOURCE,
               "The source can not contain more than one object for SaveAs.");
      }
      
      try
      {
         // get cursors for global data (needed for external id or name lookup)
         // (no adjrule cursor is needed because there is no explicit reference
         // to the adjrule table from other method tables)
         resCursor_ = getCursor(QRY_RESOURCEROLES, TBL_RESOURCE + "." + FLD_ID);
         estCursor_ = getCursor(QRY_ESTMODELS, TBL_MRESTMODEL + "." + FLD_ID);
         custCursor_ = getCursor(QRY_CUSTOMFIELDS, TBL_MRCUSTOMFIELD + "." + FLD_ID);

         // save the methods
         ABTIOMethRepoMethod helper = new ABTIOMethRepoMethod(this);
         val = helper.save(oSet, saveAs, saveAsExtID);
      }
      finally
      {
         // release the global cursors after all the methods have been saved
         resCursor_.release();
         estCursor_.release();
         custCursor_.release();
      }
      
      return val;

   }

public ABTCursor getResCursor()   {return resCursor_;}
public ABTCursor getCustCursor()  {return custCursor_;}
public ABTCursor getEstCursor()   {return estCursor_;}
public ABTCursor getAdjCursor()   {return adjCursor_;}


 /**
 *		Get a list of all the method external ids and names.
 *		@return  An ABTHashtable of method external ids and names.
 */
   private ABTValue getMethodNameList() throws ABTException
   {
      ABTCursor cursor = getRepository().select(QRY_ALLMETHODS);
      ABTHashtable hash = new ABTHashtable();

      // For each tuple in the method table, read method name and external id
      // and put them in the hashtable.
      while(cursor.moveNext())
      {
         // the key is of "String" type while the value is ABTValue.
         ABTString extID = new ABTString(cursor.getFieldString(FLD_EXTERNALID));
         ABTString name = new ABTString(cursor.getFieldString(FLD_NAME));
         hash.put(extID, name);
      }

      cursor.release();								// release the ABTCursor
      return hash;
   }


/**
 *		Opens a connection to a specific ABT Repository.  This version of open() overrides
 *    the parent class's version of open() because we want to retry login processing if
 *    loginAs fails.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return  true  open succeeded; false: open failed
 */
	public ABTValue open(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args)
	{
   	ABTValue val = null;    // assume success

      try
      {
         setSpace(space);
         setUserSession(usersession);        // object space session
         String repoName = null;
         String userID = null;
         String password = null;
         String product = null;

         ABTSession session = getSession();  // repository session

         // first see if there are any login arguments in the hashtable
         if (args != null && args.size() > 0)
         {
            repoName = getStringValue(args, KEY_REPONAME);
            userID = getStringValue(args, KEY_USERNAME);
            password = getStringValue(args, KEY_PASSWORD);
            product = getStringValue(args, KEY_PRODUCT);
         }

      	//
      	// If there is no repository session, perform some type of login.  Which type
      	// of login processing will be performed depends upon whether a user ID and
      	// password are present.
      	//
      	if (session == null)
      	{
      		if (userID == null && password == null)
      		   session = ABTSession.login();
      		else
      		{
      		   session = ABTSession.loginAs(userID, password);

      		   // pop up a login dialog box is loginAs fails.
      		   //
      		   // NOTE: This functionality is a request from the client app developers.
      		   // If the driver runs remotely, the client will not see the login prompt.
      		   //
      		   if (session == null)
      		      session = ABTSession.login();
      		}

      	   //
      	   // If we still don't have a valid repository session, we can't proceed.
      	   // Return false to the caller.
      	   //
      	   if (session == null)
      	   {
               return new ABTError(component_,
                  MOD_OPEN,
                  errorMessages.ERR_UNABLE_TO_CONNECT,
                  "Unable to connect to repository " + getRepositoryName() + " with user " + getUser());
      	   }
      		setSession(session);
         }

         //
         // Perform the parent's open() processing to pick up licensing, etc.
         // The parent's open() will also establish a connection to the desired repository, if
         // that is required.
         //
      val = super.open(space, usersession, args);

      }     // end try block
      catch (Throwable e)
      {
         // turn Java Exception or Error into ABTError.
         val = new ABTError(component_, MOD_OPEN, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      finally
      {
      }
      
      return val;
   }

/**
 *  Unlock a method in the repository.
 *	 @param  the external id of the method to be unlocked
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue unlock(String extID) throws ABTException
   {
      ABTValue val = null;

      ABTCursor cursor = getRepository().select(QRY_METHOD + "'" + extID + "'");

      if (cursor == null)
         return new ABTError(component_,
            MOD_EXECUTE,
            errorMessages.ERR_SELECT_ERROR,
            "Error selecting '" + extID + "' from table " + TBL_MRMETHOD);

      if (cursor.moveNext())
      {
         // Verify lock is held by current user.
         int userID = getSession().getUserID();
         int lockID = cursor.checkLock(LCK_METHOD, false);

         if (lockID != userID)
            val = new ABTError(component_,
               MOD_EXECUTE,
               errorMessages.ERR_LOCK_NOT_HELD,
               "user id '" + userID + "' does not have a lock on " + extID);
         else
            lockID = cursor.unlock(LCK_METHOD);

      }	// end if
      else
         val = new ABTError(component_,
               MOD_EXECUTE,
               errorMessages.ERR_RECORD_NOT_FOUND,
               "Method external id '" + extID + "' is not found in the repository.");

      if (cursor != null)
      {
         cursor.release();
         cursor = null;
      }

      return val;
   }

/**
 *  gets source object(s) to be saved from hashtable.
 *	 @param args the hashtable
 *  @return the ABTObject or ABTObjectSet retrieved from hashtable or ABTError.
 */
   private ABTValue getSource(ABTHashtable args)
   {
      String type = null;
      ABTValue obj = null;
      
      obj = (ABTValue) args.getItemByString(KEY_SOURCE);

      // make sure the object/object set is not empty.
      if (ABTValue.isNull(obj))
         return new ABTError(component_,
            MOD_SAVE,
            errorMessages.ERR_INVALID_SOURCE,
            "The source object is null.");            
            
      // the source must be an object or object set
      if (obj instanceof ABTObject)
         type = ((ABTObject)obj).getObjectType();      
         
      else if (obj instanceof ABTObjectSet)
         type = ((ABTObjectSet)obj).getObjectSetType();            
         
      else
         return new ABTError(component_,
            MOD_SAVE,
            errorMessages.ERR_INVALID_SOURCE,
            "The source must be an ABTObject or ABTObjectSet.");

      // make sure the object is of method type
      if (!type.equals(OBJ_MM_METHOD))
         return new ABTError(component_,
            MOD_SAVE,
            errorMessages.ERR_INVALID_TYPE,
            "expected object type = " + OBJ_MM_METHOD + ", bad type = " + type);

      return obj;
   }

   public ABTObject getSiteObject() {return site_;}

/**
 * selects a cursor from repository and sort it to the specified order.
 * @param query      the select statement.
 * @param sortField  if provided, set cursor to the order of this field.
 * @return    the cursor
 * @exception  ABTException if error occurred
 */
   protected ABTCursor getCursor(String query, String sortField) throws ABTException
   {
      // select cursor from the repository
      ABTCursor cur = getRepository().select(query);
      if (cur == null)
         processError(component_,
                      "getCursor",
                      errorMessages.ERR_SELECT_ERROR,
                      "Query = '" + query + "'");

      // set sort order if needed
      if (sortField != null)
         cur.setSort(sortField);

      return cur;
  }

}