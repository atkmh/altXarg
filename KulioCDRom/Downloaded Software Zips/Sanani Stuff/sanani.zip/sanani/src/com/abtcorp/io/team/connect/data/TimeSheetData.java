package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTProperty;

public class TimeSheetData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public TimeSheetData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_TIMESHEET) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         // Skip the object references. The ids are already saved for these fields.
         if (property.getName().equals(FLD_TW_DIRECTENTRIES) || property.getName().equals(FLD_TW_INDIRECTENTRIES) || property.getName().equals(FLD_TW_MODIFIED) || property.getName().equals(FLD_TW_ADJUSTED_TIMESHEET)) continue;

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            if (property.getName().equals(FLD_TW_TIMEPERIOD)) {
               ABTValue object = object_.getValue(session_,FLD_TW_TIMEPERIOD);
               if (object instanceof ABTObject) {
                  table.put(property.getName(),((ABTObject)object).getValue(session_,FLD_TW_INTERNALID));
               }
            } else if (property.getName().equals(FLD_TW_RESOURCE)) {
               ABTValue object = object_.getValue(session_,FLD_TW_RESOURCE);
               if (object instanceof ABTObject) {
                  table.put(property.getName(),((ABTObject)object).getValue(session_,FLD_TW_INTERNALID));
               }
            } else if (property.getName().equals(FLD_TW_ENTRIES)) storeTimeEntries(table,property.getName());
            else if (property.getName().equals(FLD_TW_NOTES)) table.put(property.getName(),getNotes((ABTObjectSet)value));
            else table.put(property.getName(),value);
         }
      }
      return table;
   }

   private void storeTimeEntries(Hashtable table, String property)
   {
      ABTValue value = object_.getValue(session_,property);

      if (value == null || ABTError.isError(value) || ABTEmpty.isEmpty(value)) return;

      ABTObjectSet entries = (ABTObjectSet)value;
      DataArray array = new DataArray();

      for (int i = 0;i < entries.size(session_);i++) {
         TimeEntryData data = new TimeEntryData((ABTObject)entries.at(session_,i),session_);
         array.add(data.getValues());
      }

      table.put(property,array);
   }
}
