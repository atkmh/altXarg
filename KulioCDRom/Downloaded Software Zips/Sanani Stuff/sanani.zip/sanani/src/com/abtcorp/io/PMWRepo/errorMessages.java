package com.abtcorp.io.PMWRepo;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.io.PMWRepo".intern();
public static final ABTErrorCode ERR_WBSSEQUENCE_NULL = new ABTErrorCode(Package, "ERR_WBSSEQUENCE_NULL", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_PROJECT_NOT_FROM_REPO = new ABTErrorCode(Package, "ERR_PROJECT_NOT_FROM_REPO", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_TEAM_NO_RESOURCE = new ABTErrorCode(Package, "ERR_TEAM_NO_RESOURCE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_IPD_PREDTASK_NOT_FOUND = new ABTErrorCode(Package, "ERR_IPD_PREDTASK_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_IPD_SUCCTASK_NOT_FOUND = new ABTErrorCode(Package, "ERR_IPD_SUCCTASK_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_VIEW_RIGHT = new ABTErrorCode(Package, "ERR_NO_VIEW_RIGHT", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_VIEWABLE_PROJECTS = new ABTErrorCode(Package, "ERR_NO_VIEWABLE_PROJECTS", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_PROJECT_LOCKED_BY_ANOTHER = new ABTErrorCode(Package, "ERR_PROJECT_LOCKED_BY_ANOTHER", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_LOCK_TYPE = new ABTErrorCode(Package, "ERR_INVALID_LOCK_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_UNABLE_TO_CONNECT = new ABTErrorCode(Package, "ERR_UNABLE_TO_CONNECT", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_LOCK_STILL_HELD = new ABTErrorCode(Package, "ERR_LOCK_STILL_HELD", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_LOCK_NOT_HELD = new ABTErrorCode(Package, "ERR_LOCK_NOT_HELD", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_EXTIDS_ARG = new ABTErrorCode(Package, "ERR_EXTIDS_ARG", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INPUT_OBJECT_MISSING = new ABTErrorCode(Package, "ERR_INPUT_OBJECT_MISSING", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_SAVEAS_NULL_EXTID = new ABTErrorCode(Package, "ERR_SAVEAS_NULL_EXTID", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_PROJECT_EXTID_MISSING = new ABTErrorCode(Package, "ERR_PROJECT_EXTID_MISSING", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_PROJECT_READONLY = new ABTErrorCode(Package, "ERR_PROJECT_READONLY", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_TARGET_EXISTS_SPACE = new ABTErrorCode(Package, "ERR_TARGET_EXISTS_SPACE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_TARGET_EXISTS_REPO = new ABTErrorCode(Package, "ERR_TARGET_EXISTS_REPO", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_SAVEAS_RIGHTS = new ABTErrorCode(Package, "ERR_NO_SAVEAS_RIGHTS", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NOT_LOCKED = new ABTErrorCode(Package, "ERR_NOT_LOCKED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_REPO_SESSION = new ABTErrorCode(Package, "ERR_NO_REPO_SESSION", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_BAD_VERSIONS = new ABTErrorCode(Package, "ERR_BAD_VERSIONS", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_BAD_TYPE = new ABTErrorCode(Package, "ERR_BAD_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_TASK_FOR_CONSTRAINT = new ABTErrorCode(Package, "ERR_NO_TASK_FOR_CONSTRAINT", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_EST_MODEL = new ABTErrorCode(Package, "ERR_NO_EST_MODEL", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_TASK_FOR_TASK_EST = new ABTErrorCode(Package, "ERR_NO_TASK_FOR_TASK_EST", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_TASK_FOR_CUSTOM_FIELD = new ABTErrorCode(Package, "ERR_NO_TASK_FOR_CUSTOM_FIELD", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_TASK_FOR_NOTE = new ABTErrorCode(Package, "ERR_NO_TASK_FOR_NOTE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NOT_IMPLEMENTED = new ABTErrorCode(Package, "ERR_NOT_IMPLEMENTED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_COULD_NOT_GET_LOCK = new ABTErrorCode(Package, "ERR_COULD_NOT_GET_LOCK", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_PROJECT_NOT_FOUND = new ABTErrorCode(Package, "ERR_PROJECT_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA = new ABTErrorCode(Package, "ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_MISSING_TASK_EXTID = new ABTErrorCode(Package, "ERR_MISSING_TASK_EXTID", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_MISSING_PROJECT_IDS = new ABTErrorCode(Package, "ERR_MISSING_PROJECT_IDS", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_ASSIGNMENT_RESOURCE_NOT_FOUND = new ABTErrorCode(Package, "ERR_ASSIGNMENT_RESOURCE_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_POPULATE_TYPE = new ABTErrorCode(Package, "ERR_INVALID_POPULATE_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_ORIG_REPONAME_NULL = new ABTErrorCode(Package, "ERR_ORIG_REPONAME_NULL", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_OBJECT_SPACE_MISSING = new ABTErrorCode(Package, "ERR_OBJECT_SPACE_MISSING", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_USER_SESSION_MISSING = new ABTErrorCode(Package, "ERR_USER_SESSION_MISSING", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_ARGS_MISSING = new ABTErrorCode(Package, "ERR_ARGS_MISSING", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_TYPE_MISSING = new ABTErrorCode(Package, "ERR_TYPE_MISSING", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_SUBPROJECT_LOCK = new ABTErrorCode(Package, "ERR_SUBPROJECT_LOCK", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_EXCEPTION_OCCURRED = new ABTErrorCode(Package, "ERR_EXCEPTION_OCCURRED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_REPO_NAME_NULL = new ABTErrorCode(Package, "ERR_REPO_NAME_NULL", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NEW_RESOURCES = new ABTErrorCode(Package, "ERR_NEW_RESOURCES", UNRECOVERABLE_ERROR );

}