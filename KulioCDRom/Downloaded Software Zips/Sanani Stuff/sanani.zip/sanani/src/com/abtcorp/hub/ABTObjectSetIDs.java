
package com.abtcorp.hub;

import com.abtcorp.core.*;

import java.io.*;
import java.util.*;

public class ABTObjectSetIDs extends ABTValue implements Serializable
{
   private ABTArray    deletedIDs_;
   private Vector    activeIDs_;

   public ABTObjectSetIDs( ABTUserSession session, ABTObjectSet os )
   {
      activeIDs_  = new Vector();

      Enumeration e = os.elements( session );
      while( e.hasMoreElements() )
      {
         ABTObject obj = (ABTObject)e.nextElement();
         ABTID id = obj.getID();
         activeIDs_.addElement( id );
      }

      deletedIDs_ = new ABTArray();

      ABTArray deletedElements = os.getDeletedData( session );
      for (int i=0; i < deletedElements.size(); i++)
      {
         if (deletedElements.at(i) instanceof ABTRemoteID)
            deletedIDs_.add( deletedElements.at(i) );
      }
   }

   public Enumeration getActiveIDs()
   {
      return activeIDs_.elements();
   }

   public void setDeletedIDs(ABTUserSession session, ABTObjectSet set)
   {
      set.setDeletedIDs (session,deletedIDs_);
   }
}



