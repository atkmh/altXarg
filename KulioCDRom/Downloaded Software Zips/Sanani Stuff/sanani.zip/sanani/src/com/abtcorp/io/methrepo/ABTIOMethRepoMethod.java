package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoMethod.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-16-98    LZX         Initial Implementation
 * 06-30-98    LZX         Added child task list to the method object.
 * 07-02-98    LZX         Implemented "save()" to write method data back to the repository.
 * 07-07-98    LZX         Replaced "child tasks" property with "last child task", etc.
 * 07-10-98    LZX         Support transactions
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTBoolean;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTIOMethRepoMethod is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the driver application.
 *
 *  <pre>
 *       ABTIOMethRepoMethod pp = new ABTIOMethRepoMethod(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTMMRepoDriver
 */

public class ABTIOMethRepoMethod extends ABTIOMethRepoHelper
{
   private Hashtable taskHash_;        // task hash table
   private Hashtable delivHash_;       // deliverable hash table
   private Hashtable pageHash_;        // page hash table
   private Hashtable packHash_;        // package hash table
   private ABTObject curMethod_;       // the current method object
   private String curExtID_;           // the current method external id
   private long curMethodID_;          // the current method id
   private int userID_;                // the user id (for repository)
   private boolean lock_ = false;      // whether or not to lock the record
   private boolean thinly_ = false;    // whether or not to populate the methods thinly
   private boolean readOnly_ = true;   // whether or not the user has method author right
   private ABTString userName_;        // the user name

/**
 *    ABTIOMethRepoMethod constructor.
 *    @param driver: the reference to the driver.
 */
   public ABTIOMethRepoMethod(ABTMMRepoDriver driver)
   {
      super(driver, null, TBL_MRMETHOD, OBJ_MM_METHOD);
      taskHash_ = null;
      delivHash_ = null;
      pageHash_ = null;
      packHash_ = null;
      curMethod_ = null;
      curExtID_ = null;
      userID_ = driver_.getSession().getUserID();
      userName_ = driver_.getUserName(userID_);
      component_ = "ABTIOMethRepoMethod";
   }

/**
 *  Populate the method object set "thickly". The methods will be populated based
 *  on the input extIDs along with their subordinate objects (tasks, etc.)
 *  @param extIDs the external ID array of the desired methods.
 *  @param lock   whether or not to lock the method. (true=yes, false=no)
 *  @return the method object populated with data.
 *  @exception Throwable (any Exception or Error) Thrown if an unrecoverable error occurs.
 */
   public ABTValue populate(ABTArray extIDs, boolean lock) throws Throwable
   {
      ABTValue object = null;    // local handle for objects
      ABTValue oSet = null;      // local handle for object sets
      boolean locked = false;    // whether a lock is placed for this method
                                 // THIS TIME (may not be needed if user already had a lock)

      lock_ = lock;
      thinly_ = false;

      // check right and set readonly status
      checkRight();

      // go thru the ext ids and populate them
      oSet = createObjectSet(OBJ_MM_METHOD);
      for (int i = 0; i < extIDs.size(); i++)
      {
         curExtID_ = extIDs.at(i).toString();

         if ((curExtID_ == null) || (curExtID_.length() == 0))
            processError(MOD_POPULATE,
                        errorMessages.ERR_INVALID_ID,
                        "The input extenal method ID is empty");

         cursor_ = getCursorForPopulate();

         try
         {
            // populate object space and object set with fields from the method cursor...
    		   // for every method in the result set... (there should be only one
    		   // row in the cursor for full populate)
            while(cursor_.moveNext())
            {
               locked = false; // reset the locked flag

               // check lock info and lock the record if user requested so AND
               // it hasn't been locked
               if (lock_)
                  locked = lock();

               // Create a remote ID for this method.
               curMethodID_ = cursor_.getFieldInt(FLD_ID);
               ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(),
                                                                    curMethodID_);

               // See if the method already exists in the object space.
               object = find(OBJ_MM_METHOD, id);

               if (object instanceof ABTObject)
               {
                  // if found, update/merge this method
                  object = update((ABTObject)object);
               }
               else
               {
                  // if not found, create an object for this method in the object space
                  //  and set its property values.
                  object = create(OBJ_MM_METHOD, id, null);
               }

               if (object == null)
                  processError(MOD_POPULATE,
                               errorMessages.ERR_RECORD_NOT_FOUND,
                               "method external id = " + curExtID_);

               // populate the subordinate objects of the method
               populateOtherObjects((ABTObject)object);

               // add this method to the object set to be returned
               add((ABTObjectSet)oSet, (ABTObject)object);

            }   // end while(cursor.moveNext())

         }  // end try

         catch (Throwable e)
         {
            // NOTE: need to catch and throw all Throwable (including Exception
            // and Error) here because if a lock was placed just now, we need to
            // release it under any error conditions. Catching only ABTException
            // would not be sufficient here.
            if (locked)
               cursor_.unlock(LCK_METHOD);

            throw e;
         }

         finally
         {
            // release the cursor at the end
            closeCursor(cursor_);

            // Drop references to temporary hashtables.
            taskHash_ = null;
            delivHash_ = null;
            pageHash_ = null;
            packHash_ = null;
         }

      } // end for loop

      System.gc();               // indicate garbage collection should run
      System.runFinalization();  // run finalize() method(s)

      return oSet;
   }

/**
 *  Populate the method object set "thinly". Only the method scalar properties
 *  will be populated. No object references will be set for tasks, deliverables, etc..
 *  @return the method object populated with data.
 *  @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue populateThinly() throws ABTException
   {
      ABTValue object = null;    // local handle for objects
      ABTValue oSet = null;      // local handle for object sets

      thinly_ = true;

      // check right and set readonly status
      checkRight();

      // populate object space and object set with fields from the method cursor...
	   // for every method in the result set...

      oSet = createObjectSet(OBJ_MM_METHOD);

      cursor_ = getCursorForPopulate();

      while(cursor_.moveNext())
      {
         // Create a remote ID for this method.
         curMethodID_ = cursor_.getFieldInt(FLD_ID);
         ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(),
                                                              curMethodID_);

         // See if the method already exists in the object space.
         object = find(OBJ_MM_METHOD, id);

         if (object instanceof ABTObject)
         {
            // if found, update/merge this method
            object = update((ABTObject)object);
         }
         else
         {
            // if not found, create an object for this method in the object space
            //  and set its property values.
            object = create(OBJ_MM_METHOD, id, null);
         }

         // add this method to the object set to be returned
         add((ABTObjectSet)oSet, (ABTObject)object);
      }                 // end while(cursor.moveNext())

      closeCursor(cursor_);

      return oSet;
   }


/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
		ABTObject object = (ABTObject)super.create(type, id, params);

      // set FullyPopulated flag to false if we are creating a new
      // thinly-populated method (the only time this flag can be set to
      // false is when the object is populated thinly for the first time)
      if (thinly_)
         setValue(object, OFD_ISFULLYPOPULATED, ABTBoolean.False());
      else
         setValue(object, OFD_ISFULLYPOPULATED, ABTBoolean.True());

      return object;
   }

/**
 * Update an existing object in the object space with properties from the repository.
 *	@param object: the object to be updated.
 *	@return ABTValue: a reference to the object updated or an ABTError.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue update(ABTObject object) throws ABTException
   {
      // override everything for now.
		object = (ABTObject)super.update(object);

      // set FullyPopulated flag to true if we are not populating thinly
      // (if populate thinly again later, the flag won't be set back to
      // false again)
      if (!thinly_)
         setValue(object, OFD_ISFULLYPOPULATED, ABTBoolean.True());

      return object;
   }

/**
 *  Set method property values.
 *  @param       ps: the method property list.
 *  @param       dlvCursor: the method cursor.
 *  @param       obj: the method object.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps,
                            ABTCursor cursor,
                            ABTObject methodObject) throws ABTException
   {
   	// Set the method's property values from the ABT repository method table tuple.
   	setPropertyValues(ps, cursor, methodObject);

     	// set the lock and right status
   	int lockid = cursor_.checkLock(LCK_METHOD, false);
      setValue(methodObject, OFD_LOCKEDBYME, (lockid == userID_) ?
                    ABTBoolean.True() : ABTBoolean.False());
      setValue(methodObject, OFD_LOCKEDBY, (lockid == userID_) ?
                    userName_ : driver_.getUserName(lockid) );
   	setValue(methodObject, OFD_READONLYRIGHT, readOnly_ ?
   	              ABTBoolean.True() : ABTBoolean.False());

   	// set RepoName property and blank out the FromFile property.
      setValue(methodObject, OFD_REPONAME, new ABTString(driver_.getRepositoryName()));
      setValue(methodObject, OFD_FROMFILE, null);

   	// if the record is locked, increase the version number by 1 in the object space
   	// NOTE: this should be done after the setPropertyValues()!!!
   	if (lock_)
   	{
  	      short newVersion = (short) (cursor.getFieldShort(FLD_VERSION) + 1);
     	   setValue(methodObject, OFD_VERSION, new ABTShort(newVersion));
     	}
   }

   private void populateOtherObjects(ABTObject methodObject) throws ABTException
   {
   	// Retrieve all the tasks associated with this method.
   	ABTIOMethRepoTask taskHelper = new ABTIOMethRepoTask(driver_, methodObject);
   	taskHelper.populate();
   	taskHash_ = taskHelper.getHash();   	// get task hash table for later use

   	// After finished all the tasks, retrieve and populate the assignments
   	// associated with the method.
   	ABTIOMethRepoAssignment assignHelper = new ABTIOMethRepoAssignment(driver_, methodObject, taskHash_);
   	assignHelper.populate();

   	// Retrieve and populate the task estimates associated with the method.
   	ABTIOMethRepoTaskEstimate taskEstHelper = new ABTIOMethRepoTaskEstimate(driver_, methodObject, taskHash_);
   	taskEstHelper.populate();

   	// Retrieve and populate dependency objects.
   	ABTIOMethRepoDependency dependHelper = new ABTIOMethRepoDependency(driver_, methodObject, taskHash_);
   	dependHelper.populate();

   	// Retrieve and populate deliverable objects.
   	ABTIOMethRepoDeliverable delivHelper = new ABTIOMethRepoDeliverable(driver_, methodObject, taskHash_);
   	delivHelper.populate();
   	delivHash_ = delivHelper.getHash();   	// get deliverable hash table for later use

   	// Retrieve and populate page objects.
   	ABTIOMethRepoPage pageHelper = new ABTIOMethRepoPage(driver_, methodObject);
   	pageHelper.populate();
   	pageHash_ = pageHelper.getHash();      // get page hash table

   	// Retrieve and populate the page members associated with the method.
   	ABTIOMethRepoPageMember pageMemberHelper =  new ABTIOMethRepoPageMember(driver_, methodObject, pageHash_);
   	pageMemberHelper.populate();

   	// Retrieve and populate package objects.
   	ABTIOMethRepoPackage packageHelper = new ABTIOMethRepoPackage(driver_, methodObject);
   	packageHelper.populate();
   	packHash_ = packageHelper.getHash();   // get package hash table

   	// Retrieve and populate package member objects.
   	ABTIOMethRepoPackageMember packageMemberHelper = new ABTIOMethRepoPackageMember(driver_, methodObject, taskHash_, delivHash_, packHash_);
   	packageMemberHelper.populate();

   }


/**
 *  Saves the method objects back to the repository. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (checking locks, etc.)
 *	 @param oSet: the method object set to be saved back to the repository
 *  @param unlock: whether or not to unlock the method. (true=yes, false=no)
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(ABTObjectSet oSet, boolean saveAs, String saveAsExtID) throws ABTException
   {
      Exception exception = null;
      boolean isNew = false;

      // get property set from the dictionary for later use
	   ps_ = dataDictionary_.getPropertiesFromDataModel(table_);

   	// loop through all the methods in the object set, for save-as, there is supposedly
   	// only one in the set.
      for (int i = 0; i < size(oSet); i++)
      {
         ABTObject method = (ABTObject)at(oSet, i);

         if (saveAs)
            curExtID_ = saveAsExtID;
         else
         {
            ABTValue val = getValue(method, OFD_EXTERNALID);
            curExtID_ = val.toString();

            // check if the method originated from the currently connected
            // repository. if not, reconnect.
            checkRepoConnection(method);
         }

         try
         {
            // make sure the globals referenced by this method exist in the
            // repository
            checkAllGlobals(method);

            // select cursor from the repository where the ext id matches the
            // current ext id (a cursor is selected for each method separately)
            cursor_ = getCursorForSave();
            cursor_.setSort(table_ + "." + FLD_ID);

            // check if the saveAsExtID already exists in the cursor
            if (saveAs)
               checkSaveAsExtID(method, cursor_, saveAsExtID);

            // add or edit cursor depending on whether this is a new object
            // force add-new for save-as.
				if (saveAs || isNewObject(method, cursor_))
            {
               isNew = true;

               // go to the end of the cursor and add a new row for the method.
               // (the prID of the new row will be greater than the existing ones
               // therefore cursor will still be in order)
            	cursor_.moveEOF();
               cursorAddNew(cursor_);
		      }
            else
            {
               // Method found in the repository. Verify lock is held by current user.
               int lockid = cursor_.checkLock(LCK_METHOD, false);

               if (lockid == 0 || (lockid != 0 && lockid != userID_))
                  processError(MOD_SAVE,
                              errorMessages.ERR_LOCK_NOT_HELD,
                              "user does not have a lock on method '" + curExtID_ + "'.");

               // Modifying the existing method
               cursorEdit(cursor_);
            }

            // set fields and update the cursor
				setCursorValues(ps_, cursor_, method, this, isNew);
            cursorUpdate(cursor_);

            // lock the new method in repoistory.
            if (isNew)
               lock();

            // update misc. properties in the object space
            updateProperties(method, cursor_, isNew);

         }
         finally
         {
            closeCursor(cursor_);
         }

         // save the subordinate objects of this method
         saveOtherObjects(method, saveAs);

      }  // end for loop

      return oSet;

   }


/**
 * Set cursor values and update the repository.
 * @param   ps: the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param   cur: the cursor reference to which values will be set
 * @param   obj: the object from which values will be gotten
 * @param   helper: the helper object which has checkExeption() method that will be called to handle
 *          exception-based writing to the repository
 * @param   isNew: a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *          operation is an add
 *	@return  void
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject method, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
      // for existing methods, make sure the version number in the object space
      // is greater than the ones in the repository.
   	// NOTE: this should be done before the setCursorValues()!!!
      if (!isNew)
      {
   	   ABTValue val = getValue(method, OFD_VERSION);
   	   if (val instanceof ABTShort)
   	   {
   	      short osVersion = val.shortValue();
   	      short repoVersion = cur.getFieldShort(FLD_VERSION);

   	      if (osVersion <= repoVersion)
               processError("setCursorValues",
                         errorMessages.ERR_INVALID_SOURCE,
                         "Version of method '" + curExtID_ + "' in object space is not greater than the one in repository.");

      	}
      	else
            processError("->setCursorValues",
                         errorMessages.ERR_INVALID_TYPE,
                         "Version of method '" + curExtID_ + "' is not an ABTShort.");
      }

		// set the scalar property values
		super.setCursorValues(ps_, cur, method, this, isNew);

   }

/**
 * updates the properties in the object space after saving.
 * @param   cur: the cursor reference to which values will be set
 * @param   method: the method object in the space
 * @param   isNew: whether the method was a newly created method
 *	@return  void
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private void updateProperties(ABTObject method, ABTCursor cur, boolean isNew) throws ABTException
   {
      if (isNew)
      {
         // Set the prID and remote ID for this new object after successful update
         ABTValue prID = cur.getField(FLD_ID);
         setValue(method, OFD_ID, prID);
         ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID.intValue() );
         method.getID().setRemote(userSession_, id);

         // set new method version to 2. (new method has version 1 in the
         // repository and 2 in the space since it is locked)
         setValue(method, OFD_VERSION, new ABTShort((short)2));
      }
      else
      {
         // for existing method, increase the version # in object space
      	short curVersion = getValue(method, OFD_VERSION).shortValue();
      	setValue(method, OFD_VERSION, new ABTShort((short)(curVersion+1)));
      }

   	// set the lock and right status
   	setValue(method, OFD_READONLYRIGHT, ABTBoolean.False());
      setValue(method, OFD_LOCKEDBYME, ABTBoolean.True());
      setValue(method, OFD_LOCKEDBY, userName_);

   	// set RepoName property and blank out the FromFile property.
      setValue(method, OFD_REPONAME, new ABTString(driver_.getRepositoryName()));
      setValue(method, OFD_FROMFILE, null);
   }

   private void saveOtherObjects(ABTObject method, boolean saveAs) throws ABTException
   {
      // set the WBSVALIDATE flag to true so that the rules will re-calculate
      // the WBS sequence and level before saving the tasks.
      setValue(method, OFD_WBSVALIDATE, new ABTBoolean(true));

      // save all the tasks in the method.
   	ABTIOMethRepoTask taskHelper = new ABTIOMethRepoTask(driver_, method);
    	taskHelper.save(method, OFD_ALLTASKS, saveAs);

   	// save all the assignments associated with the method.
   	ABTIOMethRepoAssignment assignHelper = new ABTIOMethRepoAssignment(driver_, method, null);
    	assignHelper.save(method, OFD_ALLASSIGNMENTS, saveAs);

   	// Retrieve and populate the task estimates associated with the method.
   	ABTIOMethRepoTaskEstimate taskEstHelper = new ABTIOMethRepoTaskEstimate(driver_, method, null);
    	taskEstHelper.save(method, OFD_ALLTASKESTIMATES, saveAs);

   	// Retrieve and populate dependency objects.
   	ABTIOMethRepoDependency dependHelper = new ABTIOMethRepoDependency(driver_, method, null);
    	dependHelper.save(method, OFD_ALLDEPENDENCIES, saveAs);

   	// Retrieve and populate deliverable objects.
   	ABTIOMethRepoDeliverable delivHelper = new ABTIOMethRepoDeliverable(driver_, method, null);
    	delivHelper.save(method, OFD_ALLDELIVERABLES, saveAs);

   	// Retrieve and populate page objects.
   	ABTIOMethRepoPage pageHelper = new ABTIOMethRepoPage(driver_, method);
    	pageHelper.save(method, OFD_ALLPAGES, saveAs);

   	// Retrieve and populate the page members associated with the method.
   	ABTIOMethRepoPageMember pageMemberHelper = new ABTIOMethRepoPageMember(driver_, method, null);
    	pageMemberHelper.save(method, OFD_ALLPAGEMEMBERS, saveAs);

   	// Retrieve and populate package objects.
   	ABTIOMethRepoPackage packageHelper = new ABTIOMethRepoPackage(driver_, method);
    	packageHelper.save(method, OFD_ALLPACKAGES, saveAs);

   	// Retrieve and populate package member objects.
   	ABTIOMethRepoPackageMember packageMemberHelper = new ABTIOMethRepoPackageMember(driver_, method, null, null, null);
    	packageMemberHelper.save(method, OFD_ALLPACKAGEMEMBERS, saveAs);
   }


/**
 * Select method from the repository that matches the current external id.
 * @return the ABTCursor containing the selected rows.
 */
   protected ABTCursor getCursorForPopulate()
   {
      if (thinly_)
         return (repo_.select(QRY_ALLMETHODS));
      else
         return (repo_.select(QRY_METHOD + repo_.sqlString(curExtID_)));
   }

/**
 * Select method from the repository that matches the current external id.
 * @return the ABTCursor containing the selected rows.
 */
   protected ABTCursor getCursorForSave()
   {
      return (repo_.select(QRY_METHOD + repo_.sqlString(curExtID_)));
   }

/**
 * locks a method if it is not already locked by another user.
 *	@return  true - lock was placed successfully this time
 *          false - no lock was placed this time
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private boolean lock() throws ABTException
   {
      boolean ret = false;

      // check if there is a lock on the record
      int lockid = cursor_.checkLock(LCK_METHOD, false);

      if (lockid == userID_)
         // the user had already locked the record. do nothing.
         ret = false;

      else if (lockid == 0)
      {
         // no lock yet, lock it!
         lockid = cursor_.lock(LCK_METHOD, false);
         // check if locking was successful
         if ((lockid == 0) || (lockid != userID_))
            // nope
            processError("lock",
                        errorMessages.ERR_LOCK_ERROR,
                        "Unable to lock method '" + curExtID_ + "'. user id = '" + userID_ + "', lock id = '" + lockid + "'");
         else
            // yes!!!
            ret = true;
      }
      else
         // someone else already locked the record
         processError("lock",
                     errorMessages.ERR_LOCK_NOT_HELD,
                     "Method '" + curExtID_ + "' is already locked by another user. user id = '" + userID_ + "', lock id = '" + lockid + "'");

      return ret;
   }


/**
 * performs various checks on the method to be saved: a) for save-as, make sure the
 * ext id does not exist in the repository already. b) for save, make sure the
 * repository to save to matches the origin.
 * @param method        the method object to be saved
 * @param cur           the method cursor selected from the repository
 * @param saveAs        where this is a "save-as"
 * @param saveAsExtID   the new ext id for "save-as"
 *	@return  void
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private void checkSaveAsExtID(ABTObject method, ABTCursor cur, String saveAsExtID) throws ABTException
   {
      // for save-as, make sure the external id doesn't already exist          // in the repository
      //if (extIDExistsInCursor(cur, saveAsExtID))
      if (cur.getRecordCount()>0)
         // alreaday exists, not OK
         processError("checkSaveAsExtID",
                     errorMessages.ERR_DUPLICATE_METHOD,
                     "Unable to save method as '" + saveAsExtID + "', it exists in repository '" + repo_.getName() + "' already.");
      else
         // OK, update the ext id in the method object
         // (the rule will return an error if there is a dup found in the space)
         setValue(method, OFD_EXTERNALID, new ABTString(saveAsExtID));
   }

/**
 * check if the user has method author right and set the readonly flag.
 *	@return  void
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private void checkRight() throws ABTException
   {
      // check if the user has method author right
      if (repo_.checkRight(IS_METHODAUTHOR))
         readOnly_ = false;
      else
         readOnly_ = true;

      // If locking is requested and the user does not have the right, return error.
      if ((lock_ == true) && readOnly_)
         processError("setRightStatus",
                      errorMessages.ERR_INSUFFICIENT_RIGHT,
                      "user does not have " + IS_METHODAUTHOR + " right");
   }


/**
 * checks if all of the global objects referenced by the method exist in the repository
 * @param method  the method to be saved
 *	@exception ABTException Thrown if an unrecoverable error occurs or
 *            there are globals that don't exist in the repository.
 */
   private void checkAllGlobals(ABTObject method) throws ABTException
   {
      ABTArray newGlobals = new ABTArray();

      // go through all the global objects and save the ones that are not
      // present in the repository into the newGlobals array.

      // check resources...
      newGlobals = checkGlobals(newGlobals, method, OFD_ALLASSIGNMENTS, OFD_RESOURCE, driver_.getResCursor(), OFD_EXTERNALID);

      // check estimate models...
      newGlobals = checkGlobals(newGlobals, method, OFD_ALLTASKESTIMATES, OFD_ESTMODEL, driver_.getEstCursor(), OFD_NAME);

      // check custom fields...
      newGlobals = checkGlobals(newGlobals, method, OFD_ALLPAGEMEMBERS, OFD_CUSTOMFIELD, driver_.getCustCursor(), OFD_NAME);

      // return error along with the newGlobals array as the info object if it
      // has 1 or more entries.
      if (newGlobals.size() > 0)
         processError("checkAllGlobals",
                     errorMessages.ERR_GLOBAL_NOT_FOUND,
                     newGlobals);
   }

/**
 * checks if the global objects referenced by the method exist in the repository
 * @param newGlobals       the array to store the globals not present in repo
 * @param method           the method to be saved
 * @param list             the name of the object set that reference to globals
 * @param globalField      the name of the global field
 * @param globalCursor     the cursor that contains global data selected from repo
 * @param altSearchField   the alternate field used to search the global cursor
 *                         (e.g., prExternalID, prName, etc.)
 *	@return an ABTArray of the global objects that are not present in the repository
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTArray checkGlobals(ABTArray newGlobals, ABTObject method, String list, String globalField, ABTCursor globalCursor, String altSearchField) throws ABTException
   {
      ABTArray ar = newGlobals;

      // Loop through all of the objects that contain references to global objects.
      // For any global object that is not present in the repository, i.e., it is a "new"
      // global, add the global object to an array of ABTObject.

      // retrieve the object set from the method
   	ABTValue val = getValue(method, list);
   	if (!(val instanceof ABTObjectSet) || ABTValue.isNull(val))
   	{
         processError("checkGlobals",
                     errorMessages.ERR_OBJECTSET_NOT_FOUND,
                     list + " object set is not found in method " + getValue(method, OFD_EXTERNALID));
         return null;
      }

      ABTObjectSet oset = (ABTObjectSet)val;

      int size = size(oset);
      for (int i = 0; i < size; i++)
      {
         ABTObject obj = (ABTObject) at(oset, i);
         val = getValue(obj, globalField);
      	if (!(val instanceof ABTObject) || ABTValue.isNull(val))
      	{
            processError("checkGlobals",
                        errorMessages.ERR_OBJECT_NOT_FOUND,
                        globalField + " object is not found in method " + getValue(method, OFD_EXTERNALID));
            return null;
         }

         ABTObject globalObj = (ABTObject)val;
         if (isNewGlobal(globalObj, globalCursor, altSearchField))
            ar.add(globalObj);
      }

      return ar;
   }


/**
 * checks if the method came from the currently connected repository.
 * @param   method: the method object to be saved
 *	@return  void
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private void checkRepoConnection(ABTObject method) throws ABTException
   {
      String repoName = getValue(method, OFD_REPONAME).stringValue();
      if (!repoName.equals(driver_.getRepositoryName()))
      {
         ABTHashtable args = new ABTHashtable();
         args.putItemByString(KEY_REPONAME, new ABTString(repoName));
         // connect to the specified repo
         driver_.open(getSpace(), getUserSession(), args);
         // reset repository handle
   	   repo_ = driver_.getRepository();
      }
   }

}
