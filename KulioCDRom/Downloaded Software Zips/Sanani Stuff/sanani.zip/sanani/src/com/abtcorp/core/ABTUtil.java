/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTUtil.java, 9, 10/22/98 5:04:43 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.util.*;
import java.security.MessageDigest;

public class ABTUtil
{
   public static final int MajorVersion  = 4;
   public static final int MinorVersion  = 0;
   public static final int Build         = 1;

   public static int random(int ref[])
   {
   	ref[0] = ref[0] * 214013 + 2531011;

   	return (ref[0] >> 16) & 0x7fff;
   }

   public static char rotate(char c, int d)
   {
      int x = 0;

   	if 	  (Character.isDigit(c))      x = c - '0';
   	else if (Character.isUpperCase(c))  x = c - 'A' + 10;
   	else						               x = c - 'a' + 36;

   	x = (x + 62 + (d % 62)) % 62;

   	if (x < 10) return (char)(x + '0');
   	if (x < 36) return (char)(x + 'A' - 10);

   	return (char)(x + 'a' - 36);
   }

   public static String encrypt(String string, int seed)
   {
      int length = string.length();

   	int ref[] = {seed};

   	char result[] = string.toCharArray();

   	int prev = 0;

   	for (int i = 0; i < length; i++) {
   		char c = result[i];

   		if (Character.isLetterOrDigit(c)) result[i] = rotate(c, random(ref) ^ prev);

   		prev = (int)c;
   	}

   	return new String(result);
   }

   public static String decrypt(String string, int seed)
   {
      int length = string.length();

   	int ref[] = {seed};

   	char result[] = string.toCharArray();

   	int prev = 0;

   	for (int i = 0; i < length; i++) {
   		char c = result[i];

   		if (Character.isLetterOrDigit(c)) result[i] = rotate(c, - (random(ref) ^ prev));

   		prev = (int)result[i];
   	}

   	return new String(result);
   }

    
    public static String newLine(int indent)
    {
        StringBuffer sb = new StringBuffer("\n");
        for (int i = 0; i < indent; i++)
            sb.append("\t");
        return sb.toString();
    }

   private static char encode(byte c)
   {
	   c &= 0x3f;

	   char ret = (char)((c != 0) ? c + 0x20 : 0x60);
	   return ret;
   }

   public final static String hash(String s)
   {
	   if (s == null) return null;
	   
	   byte[] array = null;
	   byte[] input = null;
	   
	   try {
   	   MessageDigest md = MessageDigest.getInstance("MD5");
   	   array = s.getBytes(); // TODO: verify international characters (Japanese) works correctly here!
   	   md.update(array);
   	   input = md.digest();
         md.reset();
         
   	   if (input.length != 16) return null; // MD5 should always return a 16 byte array.
   	} catch (Exception e) {
   	   e.printStackTrace(); // In case the MD5 algorithm isn't supported.
   	   return null;
   	}
	   
	   byte[] temp = new byte[18];	// add two characters for encoding
	   
	   System.arraycopy(input,0,temp,0,input.length);
	   
	   StringBuffer buffer = new StringBuffer(18);
	   
	   for (int i = 0; i < 18; i+=3) {
   	   // Since Java treats everything as signed we must take off significant bytes after the shift is performed.
	      byte b = (byte)((temp[i] >> 2) & 0x3f);
		   buffer.append(encode(b));
		   b = (byte)(((temp[i] << 4) & 0xf0) | ((temp[i+1] >> 4) & 0x0f));
		   buffer.append(encode(b));
		   b = (byte)(((temp[i+1] << 2) & 0xfc) | ((temp[i+2] >> 6) & 0x03));
		   buffer.append(encode(b));
		   buffer.append(encode((byte)temp[i+2]));
	   }

	   buffer.setLength(buffer.length() - 2); // Truncate the last two characters since they are only needed for the encoding.
	   return new String(buffer);
   }
}
