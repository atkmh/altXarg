
package com.abtcorp.hub;

/*
 * IABTDestroyableObject.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */


interface IABTDestroyableObject
{
    public void destroy();
}

