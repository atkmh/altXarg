/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTImmutableValue.java
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import java.io.*;

public abstract class ABTImmutableValue extends ABTValue
{
    private static final long serialVersionUID = -3308839073460785010L;
    public abstract void fromByte(byte[] input);
    public abstract byte[] fromByte();
}
