package  com.abtcorp.objectModel.abt.fr;

/*
 * ResourceDOHDOT.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author          Description
 * 10-08-98       SOB             Initial Design
 *
 */

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.ABTCalendar;

/**
 * This field rule enforces date-of-hire (DOH) and date-of-termination (DOT) depedendencies
 * in a Resource object.
 *
 * @version	1.0
 * @author  S.O. Bursch
 */

public class ResourceDOHDOT extends SiteFieldRule
{
   /**
    * The new value, if not empty and not null, must conform to the following rule
    *   DOH <= DOT
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, 
                             ABTObject parent, 
                             ABTProperty property, 
                             ABTValue myValue, 
                             ABTValue newValue, 
                             ABTHashtable parameters )
   {
      //
      // If the caller wants to set the property to null or empty, let the modification proceed.
      // Otherwise, we need to make more checks.
      //
      if ( !ABTValue.isNull( newValue ) )
      {
         if ( !(newValue instanceof ABTTime) && !(newValue instanceof ABTDate) )
            return new ABTError("ResourceDOHDOT",
               "onSet", 
               errorMessages.ERR_DOH_DOT,
               "");
            
         //
         // Convert the input date (or time) value to an ABTTime.  We want to use only ABTTime objects for
         // DOH/DOT manipulation.
         //
         ABTTime newTimeValue = (newValue instanceof ABTTime) ? (ABTTime) newValue : new ABTTime((ABTDate)newValue);
         ABTDate newDate = newTimeValue.dateValue(false);
         
         ABTValue v;
         boolean isDOH = false;
         if ( property.getName().equals(OFD_DOH) )
            isDOH = true;
      
         // get site object 
         v = parent.getValue(session, OFD_SITE, parameters);
         if ( ABTError.isError( v ) )
            return v;
         ABTObject site = (ABTObject)v;
         // get standard calendar and save for later use
         v = site.getValue(session, OFD_CALENDAR, parameters);
         if ( ABTError.isError( v ) )
            return v;
         ABTCalendar stdCalendar = (ABTCalendar)v;
         
         //
         // If the property being set is DOH, get the parent's DOT value. If the DOT is null, allow
         // the setting of the DOH to proceed.  Otherwise, make the appropriate comparison.
         //
         // If the property being set is DOT, get the parent's DOH value. If the DOH is null, allow
         // the setting of the DOT to proceed.  Otherwise, make the appropriate comparison.
         //
         // In all cases, make sure the comparison is performed with ABTTime objects.
         //
         if ( isDOH )
         {
            v = parent.getValue(session, OFD_DOT, parameters);
            if ( ABTError.isError( v ) )
               return v;
            if ( !ABTValue.isNull( v ) )
            {
               ABTTime DOTTimeValue = (v instanceof ABTTime) ? (ABTTime) v : new ABTTime((ABTDate) v);

               // if the termination date is null or hire date > termination date, 
               // adjust the termination date/time to the end of the hire date.
               if ( newTimeValue.compareTo(DOTTimeValue) > 0 )
               {
                  ABTTime finishWorktime = stdCalendar.finishWorktime(newDate);
                  ABTTime adjustedDOT = ABTTime.max(newTimeValue, finishWorktime);
                  v = write(session, parent, parent.getProperty(session, OFD_DOT), DOTTimeValue, adjustedDOT, false);
                  if ( ABTError.isError( v ) )
                     return v;                  
               }
            }
         }
         else
         {
            v = parent.getValue(session, OFD_DOH, parameters);
            if ( ABTError.isError( v ) )
               return v;
            if ( !ABTValue.isNull( v ) )
            {
               ABTTime DOHTimeValue = (v instanceof ABTTime) ? (ABTTime) v : new ABTTime((ABTDate) v);

               // if termination date < hire date, adjust the hire date/time
               // to the beginning of the termination date.
               if ( newTimeValue.compareTo(DOHTimeValue) < 0 ) 
               {
                  ABTTime startWorktime = stdCalendar.startWorktime(newDate);
                  ABTTime adjustedDOH = ABTTime.min(newTimeValue, startWorktime);
                  v = write(session, parent, parent.getProperty(session, OFD_DOH), DOHTimeValue, adjustedDOH, false);
                  if ( ABTError.isError( v ) )
                     return v;                  
               }     
            }
         }
      }
      else
      {
         if (newValue instanceof ABTEmpty)
            newValue = null;
      }
      
      return write( session, parent, property, myValue, newValue, false );
   }
   
}
