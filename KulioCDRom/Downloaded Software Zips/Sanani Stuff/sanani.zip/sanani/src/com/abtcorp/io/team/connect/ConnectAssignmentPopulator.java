package com.abtcorp.io.team.connect;

import java.util.Date;
import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.AssignmentPopulator;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTDouble;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTDate;
import com.abtcorp.core.ABTBoolean;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.hub.ABTProperty;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ConnectAssignmentPopulator extends AssignmentPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants, IABTPropertyType
{
   private String server_;

   public ConnectAssignmentPopulator() {}

   public ConnectAssignmentPopulator(ABTRepositoryDriver driver, ABTObjectSpace space, ABTUserSession session)
   {
      super(driver,space,session);
      checkProperties(OBJ_TW_ASSIGNMENT,FLD_TW_PESET,PROP_BOOLEAN);
      checkProperties(OBJ_TW_ASSIGNMENT,FLD_TW_REPOESTIMATE,PROP_DOUBLE);
   }

   protected void setServerName(String name) {server_ = name;}
   protected String getServerName()         {return server_;}


   public void addProperties()
   {
      checkProperties(OBJ_TW_ASSIGNMENT,FLD_TW_PESET,PROP_BOOLEAN);
      checkProperties(OBJ_TW_ASSIGNMENT,FLD_TW_REPOESTIMATE,PROP_DOUBLE);
   }

   public String getActiveAssignmentQuery(boolean strict, int start, int finish)
   {
      ABTTime end = new ABTTime(ABTDate.toDate(finish+1,0));
      ABTTime begin = new ABTTime(ABTDate.toDate(start,0));

      if (strict) {
         return new String("select PRAssignment.*, PRTask.prProjectID from PRAssignment, PRTask, PRProject, PRResource, PRTeam where " +
                           "PRAssignment.prTaskID=PRTask.prID and " +
                           "PRAssignment.prResourceID=PRResource.prID and " +
                           "PRTask.prProjectID=PRProject.prID and " +
                           "PRTeam.prProjectID=PRProject.prID and " +
                           "PRTeam.prResourceID=PRResource.prID and " +
                           "PRAssignment.prStart<" + end.toSQL() + " and " +
                           "PRAssignment.prFinish>" + begin.toSQL() + " and " +
                           "PRTask.prStatus<>2 and " +
                           "(PRProject.prIsOpen<>0 and PRProject.prTrackMode=2) and " +
                           "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0 and PRResource.prServerName = '" + server_ + "') and " +
                           "PRTeam.prIsOpen<>0 " +
                           "order by PRTask.prProjectID");
      } else
         return new String("select PRAssignment.*, PRTask.prProjectID from PRAssignment, PRTask, PRProject, PRResource, PRTeam where " +
                           "PRAssignment.prTaskID=PRTask.prID and " +
                           "PRAssignment.prResourceID=PRResource.prID and " +
                           "PRTask.prProjectID=PRProject.prID and " +
                           "PRTeam.prProjectID=PRProject.prID and " +
                           "PRTeam.prResourceID=PRResource.prID and " +
                           "PRTask.prStart<" + end.toSQL() + " and " +
                           "PRTask.prFinish>" + begin.toSQL() + " and " +
                           "PRTask.prStatus<>2 and " +
                           "(PRProject.prIsOpen<>0 and PRProject.prTrackMode=2) and " +
                           "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0 and PRResource.prServerName = '" + server_ + "') and " +
                           "PRTeam.prIsOpen<>0 " +
                           "order by PRTask.prProjectID");
   }
}