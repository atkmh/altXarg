package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileChargeCode.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-1-98     MXA         Initial Implementation
 *
 */

/**
 *  ABTIOSiteFileChargeCode is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOSiteFileDriver.
 *
 *  <pre>
 *       ABTIOSiteFileChargeCode fr = new ABTIOSiteFileChargeCode(driver,parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOSiteFileDriver
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;

public class ABTIOSiteFileChargeCode extends ABTIOSiteFileHelper implements IABTRuleConstants
{
//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOSiteFileChargeCode constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOSiteFileChargeCode(ABTIOSiteFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_CHARGECODE);
      site_ = parent;
   }

/**
 * Populate site's Charge Code.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
 protected ABTValue populate() throws ABTException
 {
        ABTValue     val       = null;
	    ABTValue     ret       = null;
        ABTRemoteID  remoteId  = null;
        IABTLocalID   id        = null;
        ABTObjectSetIDList chargeCodeIds = null;        
        Object             obj         = null;        
        
        
        id = driver_.getSiteId();
        val = getIDs(id,OBJ_SITE, OFD_CHARGECODES);
        //val = getHashValue(site.getArr(), site.getPropertySet(), OFD_CHARGECODES);
	                                 
        if (val instanceof ABTObjectSetIDList) 
            chargeCodeIds  = (ABTObjectSetIDList)val;
        else 
            throw new ABTException("Wrong Cast");   
        Enumeration itID = chargeCodeIds.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
            obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            id_ = (IABTLocalID)obj;           
           else
            throw new ABTException("Wrong Cast");
           ret = super.populate();   
        }
        return ret;
 }

/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
      reqParams_.putItemByString(OFD_SITE, (ABTValue)site_);
      return (super.create(type, id, reqParams_));
   }

}
