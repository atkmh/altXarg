package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoTask.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-10-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-09-98    SOB            mods to support transactions
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-20-98    SOB            Mods to support save functionality
 * 07-21-98    SOB            Mods to support required params on create
 * 08-03-98    SOB            Mods to support task creation changes
 * 08-03-98    SOB            More Mods to support task creation.
 * 08-04-98    SOB            Mods to support new server class hierarcy.
 * 08-06-98    SOB            Fix a couple of bugs relating to updating already-existing task data
 * 08-27-98    SOB            Mods to support exception-based populating.
 * 09-30-98    SOB            New save logic to accommodate removal of WBSSequence as a task object property
 * 10-09-98    SOB            Beginnings of progress reporting
 * 11-04-98    SOB            Fix a bug in getParentTask()
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoTask is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTTask object in the object space.
 *  <pre>
 *       ABTIOPMWRepoTask rt = new ABTIOPMWRepoTask(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTID;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoTask extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
	private Vector taskVector_ = null;
   private ABTValue passNumber_ = null;
   private boolean forceAddNew_ = false;
   private ABTArray WBSTaskArray_ = null;

   /**
    *    Default constructor.
    *
    */
   public ABTIOPMWRepoTask() {/* implicit call to super() here */}

   /**
    *    Constructor to support populate().
    *
    */
   public ABTIOPMWRepoTask(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_TASK, OBJ_TASK, progress);
      projObj_ = projObj;
      projectID_ = projID;

      //
      // Now obtain the propert index vector for task objects.  We need to update
      // the property flags of each task's External ID to bypass reading the External ID
      // if that ID is null (or zero length) in the repository.  Later, in the
      // isPopulateException() method, the flag will be tested.
      //
      Vector piv = getPropertyIndexVector(ps_);
      int size = piv.size();
      for (int i = 0; i < size; i++)
      {
         PropertyIndex pi = (PropertyIndex) piv.elementAt(i);
         if (pi.prapiName_.equals(FLD_EXTERNALID))
            pi.propertyFlags_ += FLAG_SKIP_READ_ON_NULL;
      }
   }

   /**
    *    Constructs a helper object to save task objects to the repository
    *    @param space ABTObjectSpace reference
    *    @param driver ABTRepository reference
    *    @param Project object reference
    *    @forceAddNew true if an addNew() operation is being forced to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoTask(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_TASK, OBJ_TASK, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(project, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with task objects for a given project
    *    @param parms (not currently used)
    *    @return null
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object = null;    // local handle for results

      taskVector_ = new Vector();      // get a new Vector for these task objects

      try
      {
         getCursor();

         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this task.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the task object already exists in the object space.
            //
            object = find(OBJ_TASK, id_);

            //
            // If the object found is an ABTObject, then the task object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new task object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }

   			taskVector_.addElement(object);          // save for calculating parent task info
         }              // end while (cursor_.moveNext())

      }                 // end try
      finally
      {
         closeCursor();
         taskVector_ = null;
      }

      return (ABTValue) null;
   }

   /**
    *    Creates a new task object.
    *    @param parms (currently not used)
    *    @return the newly-created task object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Create a new task object.
      //
      //
      // Get the parent task of this incoming task.  If there is no parent task,
      // then the project object is the parent.
      //
      ABTObject candidateParent = getParentTask(cursor_.getFieldInt(FLD_WBSLEVEL), 
                                                cursor_.getFieldBoolean(FLD_ISTASK));

      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_PROJECT, projObj_);
      if (candidateParent!=null)
         reqparms.putItemByString(OFD_PARENTTASK, candidateParent);

      ABTObject newtask = createObject(OBJ_TASK, id_, reqparms);

      //
      // Initialize repository property values of the new task object.
      //
      setValues(newtask);


      return newtask;
   }

   /**
    *    Updates an existing task object.
    *    @param parms the existing task object to be updated
    *    @return the updated task object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, don't do anything for pre-existing Task objects.  If we issue setValues(object),
      // we will clobber any data that may have been set by the application.
      //
      //   setValues(object);
      //
      // For now, just return the newly-updated task object.  Bypass setting the parent object
      // property in the task.  Because the task object already exists, the parent object must
      // be known.
      //
      return object;

   }

   private void setValues(ABTObject obj) throws ABTException
   {
   	setPropertyValues(ps_, cursor_, obj);
   }

   private ABTObject getParentTask(int wbsLevel, boolean isTask) throws ABTException
   {
      ABTObject parentObj = null;

      //
      // Enter a loop which searches the taskVector_ collection of ABTObjects in reverse
      // order.  If the input task's WBSLevel is equal to the WBSLevel of the task being
      // inspected in the Vector, or if they are both leaf nodes (Task.isTask == true), 
      // then the input task's parent is the same as the parent of the
      // one in the Vector.  If the input task's WBSLevel is greater than the WBSLevel of the
      // task being inspected in the Vector, then the input task's parent is the task being
      // inspected in the Vector.
      //
      // It could happen that the beginning of the Vector is reached before any parent is
      // found for the input task.  In that case, assume the task is parentless.  The caller
      // will assign the project object itself as the parent of the task.
      //
      // Searching the task vector in reverse order works because the tasks are presented in
      // the result set sorted ascending by WBSSequence, and are placed into the vector in the
      // order they are received.
      //

      for (int i = taskVector_.size() - 1; i > -1; i--)
      {
         ABTObject possibleParentObj = (ABTObject) taskVector_.elementAt(i);
         int vLevel = getValue(possibleParentObj, OFD_WBSLEVEL).intValue();         // get this element's WBSLevel value
         boolean vIsTask = getValue(possibleParentObj, OFD_ISTASK).booleanValue();  // get this element's isTask value
         
         //  #675
         // If the WBS level of the task from the Vector is greater than the WBS level of the
         // task whose parent we are trying to find, get the next task from the Vector.  The 
         // task from the Vector cannot possibly be the parent, nor can that task's parent be 
         // the parent of the task whose parent we are trying to find.  The parent must be 
         // further back in the WBS sequence.
         
         if ( vLevel > wbsLevel )   /* #675 */
            continue;
            
         //
         // If the WBS levels are the same, or if they are both tasks,
         // then the two tasks are siblings and the parent of the task
         // in the vector is also the parent of the task being tested.
         //
         if ( vLevel == wbsLevel ||
             (vIsTask && isTask) )
         {
            ABTValue val = getValue(possibleParentObj, OFD_PARENTTASK);
            parentObj = ABTValue.isNull(val) ? null : (ABTObject) val;
            break;
         }

         // #675
         // The WBS level of the task from the Vector is definitely less than the
         // WBS level of the task whose parent we are trying to find.  Therefore, 
         // the task from the Vector is the desired parent task.
         //
         parentObj = possibleParentObj;
         break;
      }

      return parentObj;
   }

   /**
    *    Creates and returns a Hashtable of task objects
    *    @return a Hashtable of task objects
    *    @exception ABTException if an unrecoverable error occurs
    */
   public Hashtable getTaskHashtable() throws ABTException
   {
      ABTObjectSet tos = getObjectSet(projObj_, OFD_ALLTASKS);
      int   size = tos.size(driver_.getUserSession());
      Hashtable ht = new Hashtable();

      //
      // For each task object in the set of all task objects for the current project,
      // create a Hashtable entry.  The hash table can be used for quick look-up of
      // tasks later in the populate process.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject obj = (ABTObject) tos.at(driver_.getUserSession(), i);
         ABTValue val = obj.getValue(driver_.getUserSession(), OFD_ID);
         if (ABTError.isError(val)) continue;
   	   ht.put(new Long(val.intValue()), obj);
      }

      return ht;
   }


   private void getCursor()
   {
   	closeCursor();

   	//
   	// Select all the tasks for the desired project.  The following SELECT
   	// invocation is modeled from the FIX export/import C++ PVISION code.
   	// (see PVTaskTable object constructor in IMPTASK.CPP.)  Because it is convenient
   	// to fetch the task tuples in WBSSequence order, an ORDER BY clause is tacked
   	// onto the end of the query.
   	//

   	String s = QRY_TASKSET + projectID_ + ORDERBY_WBSSEQUENCE;
   	cursor_ = repo_.select(s);
   }

   // -------------------------------------------------------------------------------
   // save logic begins here.
   // -------------------------------------------------------------------------------

   /**
    *    Saves task objects to the repository.  Saving of task objects is a two-pass
    *    process.
    *    @param parms the current pass number for the saving of task objects
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // The saving of tasks to the repository is a 2-pass process.  It's not clear why this
      // is so, given that the PM data model is identical to that in the repository, and that
      // PM field rules govern the setting of property values and that these rules must be the
      // same as those that exist in PVision.  However, we are using the FIX IMPORT process as
      // the basic model for saving objects back to the repository, and that process uses a
      // two-pass mechanism.  It may be that certain PVision rules kicked-in between pass 1 and
      // pass 2, thereby necessitating a second pass.
      //
      Enumeration e = parms.elements();
      passNumber_ = (ABTValue) e.nextElement();

      //
      // Compute WBS sequence and WBS level for each task, but only on
      // the first pass.  
      //
      switch (passNumber_.intValue())
      {
         case PASS_ONE:
            ABTValue v = getValue(projObj_, OFD_WBSSEQUENCE);
            if ( ABTValue.isNull( v ) )
               throw new ABTException( new ABTError(COMP_PMREPODRIVER, 
                                                   "ABTIOPMWRepoTask->save", 
                                                   errorMessages.ERR_WBSSEQUENCE_NULL, 
                                                   null) );
            WBSTaskArray_ = (ABTArray) v;   
            break;

         case PASS_TWO:
            break;
      }

      //
      // Get a task cursor.
      //
      getSaveCursor();

      //
      // The generalized save() support for IOHelper objects takes an objectset as a single
      // input parameter.  Get the ALLTASKS collection property from the project and use that.
      // Set some properties before saving them.
      //
      ABTObjectSet oSet = getObjectSet(projObj_, OFD_ALLTASKS);
      setSomeProperties(oSet);


      //
      // Call the general save() method to save all of the task objects to the repository.
      // Delete all tasks from the repository that were deleted from the object space by the
      // application.
      //
      save(oSet);

      //
      // For any remaining tasks in the repository result set, set the WBS sequence to null.
      // This procedure is also followed in the FIX file import process for PVision.  See IMPTASK.CPP, import1().
      // Evidently, setting the WBS sequence to null causes a PVision rule to kick-in that
      // makes such tasks be marked as "unplanned."  Sorting the remaining tasks in the result set ascending by
      // their current WBS Sequence will ensure that the tasks become "unplanned" in the proper order.
      //
      switch (passNumber_.intValue())
      {
         case PASS_ONE:
            cursor_.sort(FLD_WBSSEQUENCE);
            while (cursor_.moveFirst())
            {
               cursor_.edit();
               cursor_.setFieldNull(FLD_WBSSEQUENCE);
               cursor_.update();
               cursor_.drop();
            }
            break;

         case PASS_TWO:
            break;
      }

      closeCursor();
   }

/**
 * Saves objects from the object space back to the repository.  The order of the tuples
 * in the cursor's result set is assumed to be ascending by prID. NOTE: This method overrides
 * the save(oSet) method in the parent helper class.  Overriding is necessary because of the
 * the special way that WBSSequence is dynamically calculated.  WBSSequence is necessary for the
 * ABT Repository, but is not accurately maintained in the object space.
 * @param oSet: the object set containing the objects to be saved 
 * @return void
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected void save(ABTObjectSet oSet) throws ABTException
   {
      try 
      {
         //
         // Get the data model from the data dictionary.
         //
         Vector ps = dataDictionary_.getPropertiesFromDataModel(table_);
         
         //
         // Iterate through all the objects in the array of task objects in WBSTaskArray.
         // Update corresponding tuples in the cursor's result set;  add new
         // tuples where a corresponding tuples do not exist.  Compute a WBSSequence value
         // for each task in the array that belongs to the parent project.
         //
         short WBSSequence = 0;              
         int size = WBSTaskArray_.size();
         for (int i = 0; i < size; i++) 
         {
            ABTObject obj = (ABTObject) WBSTaskArray_.at(i);
            
            //
            // Does the current task object belong to the project being saved?  If not,
            // get the next task.  In the case of a project having subprojects (or portions of
            // projects as subprojects), tasks could be present in the WBSTaskArray_ that do
            // not belong to the parent (master) project being saved.  Those tasks must be
            // skipped.
            //
            ABTObject taskProj = getObject(obj, OFD_PROJECT);
            if ( !taskProj.equals(projObj_) )
               continue;

				WBSSequence++;       // increment to next WBSSequence number
				
				//
				// Is a new repository tuple required?  Add one, if so; otherwise,
				// update an existing tuple.
				//
				boolean addNew = addNewRequired(obj);
				if (addNew)
            {
            	// add a new row to the end of the cursor so that the order of the cursor won't
            	// get messed up (the ID of the new row will be greater than the ID of the last 
            	// row in the cursor).
            	cursor_.moveEOF();
               cursor_.addNew();
           	
               //
               // save the prID back to the object for future use 
               //
               ABTValue prID = cursor_.getField(FLD_ID);
               setValue(obj, OFD_ID, prID);
               
               //
               // Create and save a remote ID for this object.
               //
               // NOTE:  the following logic is dependent upon being able to set a new remote ID even
               //        if one already exists for the object.
               //
               ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID.intValue() );
               obj.getID().setRemote(userSession_, id);
		      }
            else 
				{
					//
					// pre-existing object
					//
               cursor_.edit();
            }

            //
            // Perform exception-based updating of the tuple at the current cursor position.
            // Note that FLD_WBSSEQUENCE is treated as a save exception and is NOT written back
            // to the repository by setCursorValues().  It is written here, instead, using the
            // dynamically-calculated value.
            //
            setCursorValues(ps, cursor_, obj, this, addNew);
            cursor_.setFieldShort(FLD_WBSSEQUENCE, WBSSequence);
            cursor_.update();
            
            //
            // Drop the current row from the cursor's result set.  Doing this
            // will facilitate deleting remaining rows in the result set after all
            // add/update/delete processing has taken place.  However, this method
            // will not delete remaining rows in the result set.  That operation is
            // up to the caller.
            //
				cursor_.drop();
				
         }	// end for loop
         
         //
         // Now process the deleted objects associated with the input object set.  The
         // remote ID's of these deleted objects are presented in an ABTArray.
         //
         ABTArray da = oSet.getDeletedData(userSession_);
         Enumeration rmtIDEnum = da.elements();
         
         //
         // For each deleted object in the object set, see if a corresponding tuple exists in the cursor's
         // result set.  If it exists, delete it.  If it doesn't exist, skip the object and get the next
         // one; the tuple has already been deleted.  If the ABTArray contains an object which is not of type
         // ABTRemoteIDRepository, skip it and get the next object.
         //
         while ( rmtIDEnum.hasMoreElements() )
         {
            Object rmtID = rmtIDEnum.nextElement();
            if ( !(rmtID instanceof ABTRemoteIDRepository) )
               continue;
            int id = (int) ((ABTRemoteIDRepository)rmtID).getPrID();
            if ( cursor_.bsearchFirst(FLD_ID, new ABTInteger(id)) )
               cursor_.delete();
         }
      }        // end try block 
      finally 
      {
         //
         // For now, there is no finally-related processing.
         //
      }
   }

   /**
    *    Checks for exceptions in reading some columns from the repository.  This method supports
    *    exception-based repository reading.  This method is entered for every PRAPI field that is
    *    a candidate for being read from the repository and set into an ABTObject property in the space.
    *    @param   obj the ABTObject which is about to have one of its properties set
    *    @param   val the ABTValue which contains the data to be set into obj
    *    @param   idx a PropertyIndex object which contains useful information about the property which is about to
    *             be set, including the index of the property in the set of all properties for obj
    *    @return  true if there is an exception to the data being checked and it should NOT be set in obj;
    *             false if the the data should be set in obj.
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isPopulateException(ABTObject obj, ABTValue val, PropertyIndex idx) throws ABTException
   {
      if ( super.isPopulateException(obj, val, idx) ) return true;

      boolean ret = false;       // assume it's NOT an exception

      //
      // If we are to skip a field from the repository because it is null (or is a string of zero length),
      // then check for that now.  One such field is FLD_EXTERNALID of task objects.

      if ((idx.propertyFlags_ & FLAG_SKIP_READ_ON_NULL) == FLAG_SKIP_READ_ON_NULL )
      {
         if (val == null)
            ret = true;          // it's null, therefore it's an exception
         else
         {
            if (val instanceof ABTString)
            {
               if ( ((ABTString)val).compareTo("") == 0 )
                  ret = true;    // the string has zero length, therefore it's an exception
            }
         }
      }
      return ret;
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName the PRAPI column name that is about to be written to the repository
    *    @param   obj the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew true if the data being written is new to the repository, i.e., the
    *             operation is an add; false, otherwise.
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository.
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      boolean ret = false;       // assume NO exception, i.e., assume we will allow the field to be written back to the repository

      //
      // Invoke the parent's isException() method.  If it claims an exception, honor it; otherwise,
      // make our own exception checks.
      //
      if ( super.isSaveException(prapiName, obj, prapiFlags, isNew) )
         ret = true;
      else
      {
         //
         // Never set FLD_MODTIME, FLD_WBSSEQUENCE (FLD_WBSSEQUENCE is handled by save logic elsewhere)
         //
         if (prapiName.equals(FLD_MODTIME) ||
             prapiName.equals(FLD_WBSSEQUENCE) )
            ret = true;
         else
         {
            switch (passNumber_.intValue())
            {
               //
               // Pass 1:  All fields are written.
               //
               case PASS_ONE:
                  break;

               //
               // Pass 2:  only a few fields are written; therefore, return true for most.
               //
               case PASS_TWO:
                  if (!prapiName.equals(FLD_STATUS) &&
                      !prapiName.equals(FLD_START) &&
                      !prapiName.equals(FLD_FINISH) &&
                      !prapiName.equals(FLD_PCTCOMPLETE))
                     ret = true;
                  break;
            }              // end switch
         }
      }

      return ret;
   }
   private void getSaveCursor()
   {
   	closeCursor();

   	//
   	// Select all the tasks for the desired project.  The tasks are ordered by
   	// prID to facilitate searching later.
   	//
   	String s = QRY_TASKSET + projectID_ + ORDERBY_ID;
   	cursor_ = repo_.select(s);
   }

   private void setSomeProperties(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);
      ABTBoolean FALSE = new ABTBoolean(false);
      for (int i = 0; i < size; i++)
      {
         ABTObject task = at(oSet, i);
         setValue(task, OFD_PROJECTID, new ABTInteger((int) projectID_) );
         setValue(task, OFD_ISUNPLANNED, FALSE);
      }
   }

 }