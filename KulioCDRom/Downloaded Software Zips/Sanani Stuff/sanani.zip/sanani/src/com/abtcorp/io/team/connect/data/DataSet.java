package com.abtcorp.io.team.connect.data;

import java.io.Serializable;

import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTValue;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTUserSession;


public class DataSet implements Serializable
{
   private static final long serialVersionUID = -1124886611817881666L;
   private int type_;
   private DataArray rows_;

   public DataSet(int type)
   {
      type_ = type;
      rows_ = new DataArray();
   }

   public void add(DataRow row)
   {
      rows_.add(row);
   }

   public int getType()          {return type_;}
   public DataArray getDataRows() {return rows_;}

   public static DataSet createDataSet(String type, ABTObjectSet data, ABTUserSession session)
   {  
      DataSet set = new DataSet(FileManager.mapType(type));
      if (data == null || session == null) return set;

      for (int i = 0;i < data.size(session);i++) {
         ABTObject object = (ABTObject)data.at(session,i);
         set.add(new DataRow(ObjectDataAdapter.createObjectData(object,session),FileManager.mapType(type)));
      }

      return set;
   }
   
   public final synchronized Object find(Object object)
   {
      return rows_.find(object);
   }
   
   public final synchronized int indexOf(Object object)
   {
      return rows_.indexOf(object);
   }

   public int size()                {return rows_.size();}
   public Object at(int index)      {return rows_.at(index);}
   public synchronized final void remove(int index)    {rows_.remove(index);}
   
   public synchronized final void setFileManagerKey(Object managerKey)
   {
      for (int i = 0;i < rows_.size();i++) {
         try {
            DataRow row = (DataRow)rows_.at(i);
            row.setFileManagerKey(managerKey);
         } catch (Exception e) {
         }
      }
   }
}
