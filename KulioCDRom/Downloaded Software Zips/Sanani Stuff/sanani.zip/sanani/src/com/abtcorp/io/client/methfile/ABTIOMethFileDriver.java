package com.abtcorp.io.client.methfile;

/*
 * ABTIOMethFileDriver.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
* 10-20-98    MXA         Initial Implementation.
*/

import java.io.File;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.EOFException;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTMMRuleConstants;
import com.abtcorp.idl.IABTDriver;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTTime;

import com.abtcorp.api.local.ABTHashTable;
import com.abtcorp.api.local.ABTDriverLocal;

import com.abtcorp.io.client.ABTFileDriver;

/**
 *  ABTIOMethFileDriver is the ABT local file driver for the Widgeon (Methodology) object.
 *  It is instantiated by the Widgeon application.
 *
 *  <pre>
 *       ABTIOMethFileDriver driver = new ABTIOMethFileDriver();
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 M. Abadian
 * @see         ABTDriver, ABTFileDriver
 */

public class ABTIOMethFileDriver extends ABTFileDriver  implements IABTRuleConstants, IABTMMRuleConstants
{
   private   IABTHashTable    intermediateTable_     = null;
   private   IABTHashTable    lookupTable_           = null;
   private   IABTLocalID      methodId_              = null;
   private   IABTHashTable    siteIntermediateTable_ = null;
   private   IABTLocalID      siteId_                = null;


//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTIOMethFileDriver default constructor.
 */
   public ABTIOMethFileDriver(){super();}

//====================================================================================
// Populate
//====================================================================================

/**
 * Populates the object space with methodology objects from a Local file.
 * It catches any exception and returns as an error.
 * @param space: the space to which the site will be populated.
 * @param args: the hash table of optional, application specific, parameters.
 * @return ABTValue if no exception occurs and an ABTError otherwise
 */
  public ABTValue populate(IABTObjectSpace space, IABTHashTable args)
  {
      boolean transactionStarted = false;
      ABTValue   ret      = null;
      IABTObject method   = null;
      int        command  = POPULATE;

      try
      {
        checkParms(space, args);
        checkType(args);

        String fileName = getSourceFileName(args);

        //Set up the work Space
        intermediateTable_ = (getSpace()).newABTHashTable();
        lookupTable_       = (getSpace()).newABTHashTable();
        siteIntermediateTable_   = null;
        siteId_                  = null;


        //
        // Start a transaction.  Any changes made to the space during save() will be
        // rolled back if an error occurs.
        //

        space.startTransaction();
        transactionStarted = true;

        setFile(fileName);
        populateHashTableFromLocalFile();

        processSite(POPULATE,args);
        checkSiteObject();
        ret = processMethodology(POPULATE, method, args);

        //Commmit the transaction
        space.commitTransaction();

      }
      catch (ABTException e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "populate",
                            errorMessages.ERR_EXCEPTION_OCCURED,
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      catch (Exception e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "populate", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      finally
      {

        //Clean up the work Space
        intermediateTable_       = null;
        lookupTable_             = null;
        methodId_               = null;
        siteIntermediateTable_   = null;
        siteId_                  = null;

        cleanupFile();
        // Return an ABTValue here
         return ret;
      }

  }

/**
 * Populates the intermediate hash table from a local file
 * @exception ABTException if an unrecoverable error ocurs.
 */
   public void populateHashTableFromLocalFile() throws ABTException
   {
     System.out.println("This is populateHashTableFromLocalFile.");
      try{
         FileInputStream fin  =  new FileInputStream(getFile());
         ObjectInputStream in =  new ObjectInputStream(fin);
         methodId_            = (IABTLocalID) in.readObject();
         siteId_                  =  (IABTLocalID)  in.readObject();
         intermediateTable_       =  (getSpace()).newABTHashTable(in);
         siteIntermediateTable_   =  (getSpace()).newABTHashTable(in);
         in.close();
      } catch (EOFException e) {
         throw new ABTException(e.getMessage());
      }catch(ClassNotFoundException e) {
         throw new ABTException(e.getMessage());
      }catch (IOException e) {
         throw new ABTException(e.getMessage());
      }

   }


//====================================================================================
// Save
//====================================================================================

/**
 * Saves  methodology objects into a Local file.
 * It catches any exception and returns as an error.
 * @param space: the space from which the site will be saved.
 * @param args: the hash table of optional, application specific, parameters.
 * @return ABTValue if no exception occurs and an ABTError otherwise
 */
  public ABTValue save(IABTObjectSpace space, IABTHashTable args)
  {
      boolean transactionStarted = false;
      ABTValue   ret    = null;
      IABTObject method = null;
      try
      {
        checkParms(space, args);
        checkType(args);
        checkSiteObject();


        String fileName = getDestinationFileName(args);
        ABTValue source = getSource(args);
        checkSourceParm(source);
        if (source instanceof IABTObject)
            method = (IABTObject)source;
        else
            new ABTError(getClass(),
                         "save", 
                         errorMessages.ERR_EXPECTED_IABTObject, 
                         source);

        //Set up the work Space


       intermediateTable_       = (getSpace()).newABTHashTable();
       lookupTable_             = (getSpace()).newABTHashTable();
       siteIntermediateTable_   = (getSpace()).newABTHashTable();

       methodId_ = null;
       siteId_   = null;



        //
        // Start a transaction.  Any changes made to the space during save() will be
        // rolled back if an error occurs.
        //

        space.startTransaction();
        transactionStarted = true;

        setFile(fileName);


        if (source instanceof IABTObject)
        {
            processSite(SAVE, args);
            ret = processMethodology(SAVE, method, args);
        }
        else
            new ABTError(getClass(),
                         "save",
                         errorMessages.ERR_EXPECTED_IABTObject, 
                         source);

        saveHashTableToLocalFile();

        //Commmit the transaction
        space.commitTransaction();

      }
      catch (ABTException e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "save", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      catch (Exception e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "save", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      finally
      {
      //Clean up the work Space
        intermediateTable_       = null;
        lookupTable_             = null;
        siteIntermediateTable_   = null;
        methodId_                = null;
        siteId_                  = null;

        cleanupFile();
        // Return an ABTValue here
        return ret;
      }

  }

//====================================================================================
// save (from object space to file)
//====================================================================================
/**
 * Saves a HashTable  to a local file
 * @exception ABTException if an unrecoverable error ocurs.
 */
   public void saveHashTableToLocalFile() throws ABTException {
      try{
         FileOutputStream fout  = new FileOutputStream(getFile());
         ObjectOutputStream out = new ObjectOutputStream(fout);
         out.writeObject(methodId_);
         out.writeObject(siteId_);
         out.writeObject(intermediateTable_);
         out.writeObject(siteIntermediateTable_);
         out.flush();
         out.close();
      } catch (IOException e) {
         throw new ABTException(e.getMessage());
      }
   }


   /**
 *	save or populate or refresh site object along with type codes and charge codes from/to local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processSite(int command, IABTHashTable args) throws ABTException
 {
      IABTDriver lcldriver_  = null;
      lcldriver_ = (getSpace()).newABTDriver("com.abtcorp.io.client.sitefile.ABTIOSiteFileDriver",null);

      ABTValue       siteVal   = null;
      IABTHashTable  arguments = (getSpace()).newABTHashTable();
      String         filename  = null;

      switch (command)
      {
         case POPULATE:
            filename = getSourceFileName(args);

            arguments.putItemByString(KEY_MODE,               new ABTString(MODE_INTERNAL));
            arguments.putItemByString(KEY_SITE_ID,            (ABTValue)siteId_);
            arguments.putItemByString(KEY_INTERMEDIATE_TABLE, (ABTValue)siteIntermediateTable_);
            arguments.putItemByString(KEY_LOOKUP_TABLE,       (ABTValue)lookupTable_);
	        arguments.putItemByString(KEY_TYPE ,              new ABTString(TYPE_ALL));

            lcldriver_.populate(arguments);
            break;
         case SAVE:
            filename = getDestinationFileName(args);
            siteVal  = getSite();

            arguments.putItemByString(KEY_MODE,               new ABTString(MODE_INTERNAL));
            //Change This! Delete This
            arguments.putItemByString(KEY_SITE_ID,            (ABTValue)siteId_);
            arguments.putItemByString(KEY_INTERMEDIATE_TABLE, (ABTValue)siteIntermediateTable_);
            arguments.putItemByString(KEY_LOOKUP_TABLE,       (ABTValue)lookupTable_);
	        arguments.putItemByString(KEY_TYPE ,              new ABTString(TYPE_ALL));
	        arguments.putItemByString(KEY_SOURCE,             siteVal);

            lcldriver_.save(arguments);
            ABTValue val = null;
            val = arguments.getItemByString(KEY_SITE_ID);
            if (val instanceof IABTLocalID)
                siteId_ = (IABTLocalID)val;
            else
                throw new ABTException("An error in ABTIOPMWFIleDriver processSite.");
            break;
         default:
            break;
      }
      return null;
 }



/**
 *	populate all methodology objects from the local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the site object if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processMethodology(int command, IABTObject method, IABTHashTable args) throws ABTException
   {
         ABTValue val = processMethod(command, args);

         if (val instanceof IABTObject)
            method = (IABTObject) val;
         else
         {
            processError(SEVERITY_ONE,
                     "processMethodology",
                     EXC_RECORD_NOT_FOUND,
                     "Method data is not found." );
            return null;
         }

      // process tasks
      processTask(command, method, args);

      // process assignments
      processAssignment(command, method, args);

      // process Task Estimates
      processTaskEstimate(command, method, args);

      // process Dependencies
      processDependency(command, method, args);

      // process Deliverable
      processDeliverable(command, method, args);

      //process Pages
      processPage(command, method, args);

      //process Page Member
      processPageMember(command, method, args);

      //process Package
      processPackage(command, method, args);

      //process Package Member
      processPackageMember(command, method, args);

      return (ABTValue)method;
   }


//====================================================================================
// private methods
//====================================================================================
/**
 *	populate or refresh Method object from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processMethod(int command, IABTHashTable args) throws ABTException
 {
      IABTObject method = null;
      ABTValue   val  = null;

      // Instantiate a method helper object and invoke its populate() or refresh()
      // method depending on the input command.
      ABTIOMethFileMethod methHelper = new ABTIOMethFileMethod(this);

      switch (command)
      {
         case POPULATE:
            val = methHelper.populate();
            break;
         case SAVE:
            ABTValue source1 = getSource(args);
            checkSourceParm(source1);
            if (source1 instanceof IABTObject)
                method = (IABTObject)source1;
            else
                new ABTError(getClass(), 
                             "save", 
                             errorMessages.ERR_EXPECTED_IABTObject, 
                             source1);

            val = methHelper.save(method);
            break;
         default:
            break;
      }

      if ((val instanceof IABTObjectSet) && (((IABTObjectSet)val).size() > 0))
      {
         // there should be only one method object
         method = (IABTObject) ((IABTObjectSet)val).at(0);
      }
      else
      {
         processError(SEVERITY_ONE,
                  "processSite",
                  EXC_RECORD_NOT_FOUND,
                  "Site data is not found." );
      }

      return (ABTValue) method;

   }


/**
 *	populate or refresh Task objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processTask(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the tasks
      ABTIOMethFileTask helper = new ABTIOMethFileTask(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLTASKS);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh Assignment objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processAssignment(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the assignment
      ABTIOMethFileAssignment helper = new ABTIOMethFileAssignment(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLASSIGNMENTS);
            break;

         default:
            // error
      }

      return val;

   }


/**
 *	populate or refresh Task Estimate objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processTaskEstimate(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the task estimate
      ABTIOMethFileTaskEstimate helper = new ABTIOMethFileTaskEstimate(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLTASKESTIMATES);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh Dependency objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processDependency(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the dependency
      ABTIOMethFileDependency helper = new ABTIOMethFileDependency(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLDEPENDENCIES);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh Deliverable objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processDeliverable(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the deliverable
      ABTIOMethFileDeliverable helper = new ABTIOMethFileDeliverable(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLDELIVERABLES);
            break;

         default:
            // error
      }

      return val;

   }


/**
 *	populate or refresh Page objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processPage(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the page
      ABTIOMethFilePage helper = new ABTIOMethFilePage(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLPAGES);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh Page Member objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processPageMember(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the page
      ABTIOMethFilePageMember helper = new ABTIOMethFilePageMember(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLPAGEMEMBERS);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh Package objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processPackage(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the package
      ABTIOMethFilePackage helper = new ABTIOMethFilePackage(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLPACKAGES);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh Package Member objects from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processPackageMember(int command, IABTObject method, IABTHashTable args) throws ABTException
 {
    ABTValue val = null;

   	// process the package Member
      ABTIOMethFilePackageMember helper = new ABTIOMethFilePackageMember(this, method);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(method, OFD_ALLPACKAGEMEMBERS);
            break;

         default:
            // error
      }

      return val;

   }

//====================================================================================
// miscellaneous private utilities
//====================================================================================
   private void checkParms(IABTObjectSpace space, IABTHashTable args) throws ABTException
   {
      // make sure the space is set.
      if (space != null)
         setSpace(space);
      else
         throw new ABTException( EXC_OBJECTSPACE_NOT_SET +
                                 "Object space needs to be specified.");

      // make sure the hashtable is not null
      if ((args == null) || args.isEmpty())
         throw new ABTException( EXC_INVALID_HASH +
                                 "Hashtable must be populated.");

   }

   private void checkType(IABTHashTable args) throws ABTException
   {
        String type = getStringValue(args, KEY_TYPE);
        if (type == null || !type.equalsIgnoreCase(TYPE_METHOD) )
            throw new ABTException(EXC_INVALID_TYPE);
   }


   private void checkSourceParm(ABTValue source) throws ABTException
   {
        if (source == null || (source instanceof ABTEmpty ))
            throw new ABTException(EXC_EMPTY_SOURCE);
        if (ABTError.isError(source))
            throw new ABTException(EXC_SOURCE_ERROR);
   }

   private String getSourceFileName(IABTHashTable args) throws ABTException
   {
        String fileName = getStringValue(args, KEY_SOURCENAME);
        if (fileName == null)
            throw new ABTException(EXC_FILENAME_NOT_SET);
        return fileName;
   }

    private String getDestinationFileName(IABTHashTable args) throws ABTException
   {
        String fileName = getStringValue(args, KEY_DESTINATIONNAME);
        if (fileName == null)
            throw new ABTException(EXC_FILENAME_NOT_SET);
        return fileName;
   }

   private ABTValue getSource(IABTHashTable args) throws ABTException
   {
    try
    {
        ABTValue source = args.getItemByString(KEY_SOURCE);
        if (source == null)
            return null;
        else
            return source;
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private void checkSiteObject() throws ABTException
   {
      ABTValue site = getSite();
      if ( ABTError.isError( site ) )
         throw new ABTException((ABTError) site);
   }

//====================================================================================
// miscellaneous utilities
//====================================================================================

/**
  * return IABTLocalID - the method ID
  */
  public IABTLocalID getMethodId()
  {
    return methodId_;
  }
/**
  * return void set the method ID
  */
  public void setMethodId(IABTLocalID id)
  {
    methodId_ = id;
  }


/**
  * return  IABTLocalID- the Site ID
  */
  public IABTLocalID getSiteId()
  {
    return siteId_;
  }
/**
  * return void set the Set ID
  */
  public void setSiteId(IABTLocalID id)
  {
    siteId_ = id;
  }

/**
  *  intermediateTableGet
  *  Get the Object associated with the key in the intermediate hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object

  */

  public Object intermediateTableGet(Object key) throws ABTException
  {
    if (key instanceof ABTValue)
        return (intermediateTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("intermediateTableGet() wrong cast");
  }

/**
  *  intermediateTablePut
  *  Put the Object associated with the key in the intermediate hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object intermediateTablePut(Object key, Object elem) throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (intermediateTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("intermediateTablePut() wrong cast");
  }

/**
  *  isIntermediateTableNull
  *  return boolean
  */

  public boolean isIntermediateTableNull()
  {
    boolean ret = false;
    if (intermediateTable_==null)
        ret = true;
    return ret;
  }



/**
  *  lookupTableGet
  *  Get the Object associated with the key in the lookup hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public Object lookupTableGet(Object key)throws ABTException
  {
    if (key instanceof ABTValue)
        return (lookupTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("lookupTableGet() wrong cast");
  }

/**
  *  lookupTablePut
  *  Put the Object associated with the key in the lookup hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object lookupTablePut(Object key, Object elem)throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (lookupTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("lookupTablePutt() wrong cast");
  }



/**
  *  siteIntermediateTableGet
  *  Get the Object associated with the key in the site intermediate hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object

  */

  public Object siteIntermediateTableGet(Object key) throws ABTException
  {
    if (key instanceof ABTValue)
        return (siteIntermediateTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("siteIntermediateTableGet() wrong cast");
  }

/**
  *  siteIntermediateTablePut
  *  Put the Object associated with the key in the site intermediate hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object siteIntermediateTablePut(Object key, Object elem) throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (siteIntermediateTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("siteIntermediateTablePut() wrong cast");
  }

/**
  *  isSiteIntermediateTableNull
  *  return boolean
  */

  public boolean isSiteIntermediateTableNull()
  {
    boolean ret = false;
    if (siteIntermediateTable_==null)
        ret = true;
    return ret;
  }




}