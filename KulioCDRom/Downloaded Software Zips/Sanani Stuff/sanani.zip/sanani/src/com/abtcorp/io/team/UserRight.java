package com.abtcorp.io.team;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;
import com.abtcorp.hub.ABTObject;

public class UserRight implements ABTNames, ABTComparable
{
	private ABTSortedArray rights_;
	private int userid_;
	private ABTObject user_;
	
	public UserRight(int userid)
   {
   	userid_ = userid;
   	rights_ = new ABTSortedArray();
   }
	
	public int getUserID() {return userid_;}
	
	public ABTObject getUser() {return user_;}
	public void setUserObject(ABTObject user) {user_ = user;}
   
   public void addRight(Right right)
   {
   	rights_.add(right);
   }
   
   public Right getRight(Right right)
   {
   	int index = rights_.indexOf(right);
   	if (index >= 0) return (Right)rights_.at(index);
   	
   	return null;
   }
   
   public boolean hasRight(String name, ABTCursor cursor, String table, int record)
   {
      int repositoryID = cursor.getRepository().getID();
      Right temp = new Right(name,table,userid_,0,repositoryID);
      // See if we even have that right in our list.
      int start = rights_.indexOf(temp);
      if (start >= 0) {
      	
         for (int i = start;i < rights_.size() && name.equals(((Right)rights_.at(i)).getName());i++) {
            Right r = (Right)rights_.at(i);
            if (r.getRepository() == 0) return true;
            if (r.getRepository() == repositoryID) {
               if (r.getTable() == null) return true;
               if (r.getTable().equals(table)) {
                  if (r.getRecord() == 0) return true;
                  if (r.getRecord() == record) return true;
               }
            }
         }
      }
      
      temp = new Right(IS_SUPERUSER,null,userid_,0,repositoryID);
      
      // Check super user right.
   	int idx = rights_.indexOf(temp);
      if (idx >= 0) return true;
      
      return false; // Doesn't have the right.
   }
	
	public int compareTo(Object object)
   {
   	if (object instanceof UserRight) {
   	   UserRight u = (UserRight)object;
   		if (u.userid_ == userid_) return 0;
   		if (u.userid_ < userid_) return -1;
   		return 1;
   	}
   	return -1;
    
   }
	
	public boolean equals(Object object) 
   {
   	if (object instanceof UserRight)
      {
      	return ((UserRight)object).userid_ == userid_;
      }
   	return false;
   }
	
	public String toString()
   {
   	String rights = new String();
   	for(int i = 0;i < rights_.size();i++) {
   		rights = rights.concat(" " + rights_.at(i).toString());
   	}
   	
   	return new String("Userid = " + userid_ + " rights = " + rights); 
   }
}