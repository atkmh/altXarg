package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileTaskEstimate.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;

import java.util.Hashtable;

//DEBUG
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTObjectSetIDList;

/**
 *  ABTIOPMWFileTaskEstimate is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileTaskEstimate ft = new ABTIOPMWFileTaskEstimate(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileTaskEstimate extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       taskEstimateVector_ = null;
//====================================================================================
// Constructors
//====================================================================================

/**
 *    ABTIOPMWFileTaskEstimate constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileTaskEstimate(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_                = OBJ_TASKESTIMATE;
      taskEstimateVector_  = new Vector();
   }
//====================================================================================
// Populate  Task Estimate from the Intermediate Hash Table
//====================================================================================

/**
 * Populate  Task Estimate object from the Intermediate Hash Table to the space
 * @param Hashtable parms,
 * @return an ABTValue the Task Estimate which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue populate(Hashtable parms) throws ABTException
   {
    ABTObjectSetIDList taskEstIDs   = null;
    IABTObject         project      = null;
    IABTObject         targetObj    = null;
    Object             object       = null;

    try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        //Get the Target object which this Task Estimate belongs to
        object = parms.get(TARGET_OBJ);
        if (object instanceof IABTObject)
            targetObj  = (IABTObject)object;

        //Get the Task Estimate IDs
        object = parms.get(TASKESTIMATES_ID);
        if (object instanceof ABTObjectSetIDList)
            taskEstIDs  = (ABTObjectSetIDList)object;

        Enumeration itID = taskEstIDs.getActiveIDs();
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);
            reqparms.put(TARGET_OBJ, targetObj);
            reqparms.put(TASKESTIMATES_ID,(IABTLocalID)itID.nextElement());

            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }


   }
/**
 * Create a new object in the object space and initialize it with  appropriate values
 * @param Hashtable parms
 * @return ABTValue the newly created Task Estimate value
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   { 
      IABTLocalID taskEstID    = null;
      IABTObject  project      = null;
      IABTObject  targetObj    = null;
      Object      object       = null;
      IABTObject  taskEstObj   = null;
      ABTValue    val          = null;

      //Get the Task Estimate value ID
      object = null;
      object = parms.get(TASKESTIMATES_ID);
      if (object instanceof IABTLocalID)
         taskEstID  = (IABTLocalID)object;

      //Check if Task Estimate has already been created
        object = null;
        object = driver_.lookupTableGet(taskEstID);
        if ( object!= null && object instanceof IABTObject)
        {
         // TO DO UPDATE
           ;
        }
        else
        {
          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object;

          //Get the Target object which this Task Estimate belongs to
          object = null;
          object = parms.get(TARGET_OBJ);
          if (object instanceof IABTObject)
             targetObj  = (IABTObject)object;

          // Get the array of value associated with Task Estimate value
          IABTArray   taskEstArr  = null;
          object = null;

          object = driver_.intermediateTableGet(taskEstID);
          if (object instanceof IABTArray)
            taskEstArr = (IABTArray) object;

          //Get the property set associated with the Task Estimate value
          IABTPropertySet propSet = null;
          propSet = getProperties(type_);

          //Get Associated Estimating Model
          val = null;
          IABTLocalID estModelID = null;
          IABTObject estModelObj = null;
          object = null;

          val = getHashValue(taskEstArr, propSet, OFD_ESTMODEL);
          if (val instanceof IABTLocalID)
             estModelID  = (IABTLocalID)val;
          object = driver_.lookupTableGet(estModelID);
          if ( object != null && object instanceof IABTObject )
            estModelObj = (IABTObject)object;
          else
            throw new ABTException("Task Estimate CREATE: Estimating Model Object is not valid");


          //Get the required parms to create Task Estimate Object
          IABTHashTable  reqparms = (getSpace()).newABTHashTable();
          reqparms.putItemByString(OFD_TASK,     (ABTValue)targetObj  );
          reqparms.putItemByString(OFD_ESTMODEL, (ABTValue)estModelObj);

          //Get Task Estimate Remote ID
          val = null;
          val = getHashValue(taskEstArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            taskEstObj = createObject(type_,(ABTRemoteID)val, reqparms);
          else if (ABTValue.isNull(val))
            taskEstObj = createObject(type_,(ABTRemoteID)null, reqparms);
          else
            new ABTException(" WRONG TYPE CAST");

          //Set Task Estimate's scalar values.
          setScalarValues(propSet, taskEstArr, taskEstObj);

        }

    driver_.lookupTablePut(taskEstID, taskEstObj);

    return (ABTValue)taskEstObj;

   }
//====================================================================================
// Save Task Estimate to an Intermediate Hash Table
//====================================================================================

/**
 * Saves taskEstimate objects from the object space back to the Intermediate Hash Table
* @param Hashtable parms 
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
        IABTObject project = null;
        
        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 

        IABTObjectSet taskEstimateOs = getObjectSet(project, OFD_ALLTASKESTIMATES);

        for (int i =0; i < size(taskEstimateOs); i++)
        {
            IABTObject  taskEstimateObj     = (IABTObject)at(taskEstimateOs, i);

            // Make sure the object is of type taskEstimate
            if (!taskEstimateObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the taskEstimate in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(taskEstimateObj);
            if (arr==null)
                throw new ABTException("The arr of taskEstimate values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID taskEstimateId = taskEstimateObj.getID();
            if (taskEstimateId == null)
                throw new ABTException("taskEstimate ID is null.");

            if (( driver_.intermediateTablePut(taskEstimateId, arr)) != null)
                throw new ABTException("The taskEstimate ID already exist.");

            //DEBUG
            taskEstimateVector_.addElement(taskEstimateId);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


}