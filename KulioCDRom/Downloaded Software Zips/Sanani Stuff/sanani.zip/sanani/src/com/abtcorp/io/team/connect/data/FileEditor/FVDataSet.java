package com.abtcorp.io.team.connect.data.FileEditor;

//import com.abtcorp.io.team.*;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.blob.ABTCurve;
import com.abtcorp.blob.ABTCalendar;
import com.abtcorp.io.team.connect.data.DataSet;
import com.abtcorp.io.team.connect.data.DataRow;
import com.abtcorp.io.team.connect.data.DataArray;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

public class FVDataSet extends DataSet implements Expandable{

    int nHeaders_ = 0;
    String[] headerNames_;
    
    FVDataSet(DataSet ds){
       super(ds.getType());
       headerNames_ = new String[35];
       for(int i=0; i<ds.size();i++)
       {
            this.add((DataRow)ds.at(i));
       }
    }

    public String toString(){ return (new String("Data Set {}")); }

    public Hashtable expand()
    {
        Hashtable hashData = new Hashtable(this.size());
        DataArray rows = this.getDataRows();
        
        for(int i = 0; i < rows.size(); i ++)
        {
            DataRow row = (DataRow) rows.at(i);
            
            Vector col;
            
            if(hashData.containsKey("Key"))
            {
                col = (Vector)hashData.get("Key");
            }
            else 
            {
                col = new Vector(50);
            }
            col.addElement("" + i);
            hashData.put("Key", col);
            
            Hashtable rowData = row.getValues();
            
            /*
             *I don't like this, but It seems to work, so leave it for now
             *   (Maybe i should change the TableDataModel) 
             *
             * Find things that are not in @values and add
             * emtpy values to hashData
             */
            if(rowData.size() < hashData.size()){
                for(Enumeration e3 = hashData.keys(); e3.hasMoreElements();){
                    String maybe_missing = (String) e3.nextElement();
                    if((maybe_missing.intern() != "Key".intern()) && (rowData.get(maybe_missing) == null)){
                        rowData.put(maybe_missing, "null");
                    }
                }                
            }
            
            //Hashtable rowData = row.getValues();
            for(Enumeration e = rowData.keys(); e.hasMoreElements();)
            {
                int n_rows = 0;
                Object key = e.nextElement();
                Object value = rowData.get(key);
                Vector column;
                
                if(hashData.containsKey("" + key)){
                    column = (Vector)hashData.get("" + key);
                }
                else{
                    column = new Vector(35);
                    for(int k=0; k < n_rows; k++){
                        column.addElement("null");
                    }
                }
                
                if (value instanceof ABTArray)        column.addElement(new FVArray((ABTArray)value));
                else if(value instanceof Hashtable)   column.addElement(new FVHashtable((Hashtable)value));
                else if(value instanceof DataSet)     column.addElement(new FVDataSet((DataSet)value));
                else if(value instanceof ABTCurve)    column.addElement(new String("<ABTCurve>"));
                else if(value instanceof ABTCalendar) column.addElement(new String("<ABTCalendar>"));
                else                                  column.addElement(new String("" + value + ""));
                
                hashData.put("" + key, column);
                n_rows++; 
            }
            
         }
         
         return hashData;
    }	
	
	
    //public int getNumHeaders()       { return 2;                    }
/*
    public Vector expand()
    {
    	   Vector data = new Vector();
    	   DataArray rows = this.getDataRows();
    	
        for(int i = 0; i < rows.size(); i++)
        {
            
            DataRow row = (DataRow)rows.at(i);
           	   
            rowData.addElement(row.getKey());
            FVDataRow dataRow = new FVDataRow(row);

            Vector tempData = dataRow.expand();                
            Vector rowData = new Vector(30);
            
            for(int i = 0; i < tempData.size(); i++)
            {
                int index = matchHeaderName("" + field + "");
                if(index > 0){

                    if (value instanceof ABTArray)        rowData[index] = new FVArray((ABTArray)value);
                    else if(value instanceof Hashtable)   rowData[index] = new FVHashtable((Hashtable)value);
                    else if(value instanceof DataSet)     rowData[index] = new FVDataSet((DataSet)value);
                    else if(value instanceof ABTCurve)    rowData[index] = new String("<ABTCurve>");
                    else if(value instanceof ABTCalendar) rowData[index] = new String("<ABTCalendar>");
                    else                                  rowData[index] = new String("" + value + "");
                }

            }

            data.addElement(rowData);
        }	
        return data;
     }
     */
     
     /* public int matchHeaderName(String name){
        for(int i=0; i < nHeaders_; i++)
        {
            if(name.compareTo(headerNames_[i]) == 0)
                return i;
        }

        return -1;
    }
    */


   /*public String[] getHeaderNames()
   {
       DataArray rows = this.getDataRows();
        
       for(int i = 0; i < rows.size(); i++)
       {   
            DataRow row = (DataRow)rows.at(i);
            FVDataRow dataRow = new FVDataRow(row);
            
            String[] headers = dataRow.getHeaderNames();
            for(int j = 0; j < dataRow.getNumHeaders(); j++)
            {
                if(matchHeaderName(headers[j]) == -1)
                {
                    headerNames_[nHeaders_] = new String(headers[j]);
                    nHeaders_++;
                }
            }
       }
       
       return headerNames_;
   }*/
}