package com.abtcorp.hub;
/*
 * ABTErrorHub.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-05-98	   HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



/**
 * Basic ABTErrorHub class - provides basic functionality for Error Handling
 * prepared for localization
 * <p>
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.core.ABTError
 */

public class ABTErrorHub extends ABTError
{
   /**
   *  default constructor
   *  @param component_ name of creator
   *  @param method_ name of routine creating it
   *  @param message_ textual representation of error
   */
   public ABTErrorHub(
               String component_,
               String method_,
               ABTErrorCode code_,
               Object info_)
   {
      super(component_,method_,code_,info_);
   }

   /**
   *  default constructor
   *  @param method_ name of routine creating it
   *  @param message_ textual representation of error
   */
   public ABTErrorHub(
               String method_,
               ABTErrorCode code_,
               Object info_)
   {
      super("HUB",method_,code_,info_);
   }

}