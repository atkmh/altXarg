
package com.abtcorp.hub;

/*
 * ABTFunctionDestroy.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.*;

public class ABTFunctionDestroy implements IABTFunction
{
    public void execute( ABTFunctionParameter object)
    {
//ABTRow
    if (object.object instanceof IABTDestroyableObject )
            ((IABTDestroyableObject)(object.object)).destroy();
    }
}

