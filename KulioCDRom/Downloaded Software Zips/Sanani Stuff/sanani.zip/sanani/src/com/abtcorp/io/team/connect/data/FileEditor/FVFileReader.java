package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.blob.ABTCurve;
import com.abtcorp.blob.ABTCalendar;
import com.abtcorp.io.team.connect.data.DataSet;
import com.abtcorp.io.team.connect.data.DataRow;
import com.abtcorp.io.team.connect.data.FileManager;
import com.abtcorp.io.team.connect.data.StructuredFile;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;
import java.io.FileNotFoundException;

public class FVFileReader implements Expandable{
    
    private String file_;
    private String directory_;
    private int type_ = 0;

    FVFileReader(){
        
    }
    
    FVFileReader(String file, String dir){
        this.file_ = file;
        this.directory_ = dir;

         if(file_.intern() == "team.Outgoing".intern())
            type_ = FileManager.OUTGOING;
         else
            type_ = FileManager.mapType(file_);
    }
    
    public String toString(){
        return (new String("com.abtcorp.test.io.team.data.FileEditor.FVFileReader"));   
    }

/*
    public boolean isValidFile()
    {
       try {
          FileManager.getManager(directory_).openFiles(directory_);

          StructuredFile datfile = FileManager.getManager(directory_).getFile(type_,false);
          Enumeration e = datfile.keys();
          FileManager.getManager(directory_).closeFiles();
         
          if (e.hasMoreElements())
             return true;
          else
             return false;
    
       } 
       catch (Exception exception) {
          exception.printStackTrace();
       }  
       return true;
    }
*/
 
    public Hashtable expand()
    {
        Hashtable data = null;
        
        try {
            FileManager.getManager(directory_).openFiles(directory_);
            StructuredFile datfile = FileManager.getManager(directory_).getFile(type_,false);
                       
            if(type_ == FileManager.OUTGOING)
                data = expandOutgoing(datfile);     
            else
                data = expandNormal(datfile);
                
            FileManager.getManager(directory_).closeFiles(); 
         }catch(FileNotFoundException e){ 
             return null;
         }catch (Exception exception) {
            exception.printStackTrace();
         }
        return data;
    }

    public Hashtable expandNormal(StructuredFile datfile) throws ClassNotFoundException, IOException
    {
        Hashtable hashData = new Hashtable();
        
        
        for (Enumeration e = datfile.keys();e.hasMoreElements();) 
        {
            
            ABTValue key = (ABTValue)e.nextElement();
            DataRow row = (DataRow)datfile.readObject(key);
            Hashtable values = row.getValues();

            if(hashData.get("Key") == null)
            {
                Vector col = new Vector(35);
                col.addElement(new String("" + key));
                hashData.put("Key", col);
            }
            else
            {
                ((Vector)hashData.get("Key")).addElement(new String("" + key));
            }
            
            //I don't like this, but It seems to work, so leave it for now
            //   (Maybe i should change the TableDataModel)
            if(values.size() < hashData.size()){
                //Find things that are not in @values and add
                // emtpy values to hashData
                for(Enumeration e3 = hashData.keys(); e3.hasMoreElements();){
                    String maybe_missing = (String) e3.nextElement();
                    if((maybe_missing.intern() != "Key".intern()) && (values.get(maybe_missing) == null)){
                        values.put(maybe_missing, "nil");
                    }
                }                
            }

            for (Enumeration e2 = values.keys();e2.hasMoreElements();)
            {
                Object field = e2.nextElement();
                Object value = values.get(field);
                int rows = 0;
                
            	  Vector column;
            	  
            	  if(hashData.containsKey("" + field))
            	  {
            	      column = (Vector)hashData.get("" + field);        	  
            	  }
            	  else
            	  {
                   column = new Vector(50);
            	     
            	     // Catch up with other columns so element is in the correct
                   //  row and column is the right size...
                   for(int i=0; i < rows; i++){
                      column.addElement("nil");
                   }
            	  }
            	
            	  //add value to table
            	  //TODO:  sort it by value in "Key"
                if (value instanceof ABTArray)        column.addElement(new FVArray((ABTArray)value));
                else if(value instanceof Hashtable)   column.addElement(new FVHashtable((Hashtable)value));
                else if(value instanceof DataSet)     column.addElement(new FVDataSet((DataSet)value));
                else if(value instanceof ABTCurve)    column.addElement(new String("<ABTCurve>"));
                else if(value instanceof ABTCalendar) column.addElement(new String("<ABTCalendar>"));
                else                                  column.addElement(new String("" + value + ""));
                
                hashData.put("" + field, column);
                rows++;
            }
        }
        return hashData;
    }

 
    private Hashtable expandOutgoing(StructuredFile datfile) throws ClassNotFoundException, IOException
    {
        Hashtable data = new Hashtable();
        Vector keyColumn = new Vector();
        Vector dataColumn = new Vector();

        for(Enumeration e = datfile.keys(); e.hasMoreElements();)
        {
            ABTValue key = (ABTValue) e.nextElement();
            DataRow value = (DataRow) datfile.readObject(key);
            
        	FVDataRow datarow = new FVDataRow(value);
        	keyColumn.addElement(key);
        	dataColumn.addElement(datarow);
        }
    	
    	data.put("Key", keyColumn);
    	data.put("Data", dataColumn);
    	
        return data;     
    }
	
	private void dumpKeys(Vector vect) 
    {      
        System.out.println("");
        System.out.println("-----------------------");
        for(int i = 0; i < vect.size(); i++)
            System.out.println(i + ": " + (String)((Vector)vect.elementAt(i)).elementAt(0));
    }
	
}