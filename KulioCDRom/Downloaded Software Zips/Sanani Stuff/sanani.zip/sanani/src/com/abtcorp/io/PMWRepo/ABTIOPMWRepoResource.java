package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoResource.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-09-98    SOB            transaction support
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-20-98    SOB            Mods to support save() functionality
 * 07-21-98    SOB            Mods to support required params on object create
 * 08-12-98    SOB            Mods to support new ABTRemoteID API
 * 09-02-98    SOB            Mods to support better resource duplication detection
 * 10-09-98    SOB            Beginnings of progress reporting
 * 10-20-98    SOB            Mods to support doing "find" by external ID, rather than by remote ID
 * 11-20-98    SOB            This entire source file is now defunct. Populating of Resource objects is
 *                            handled by a Site Repo Driver Resource populator (helper) object
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoResource is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTResource object in the object space.
 *  <pre>
 *       ABTIOPMWRepoResource rd = new ABTIOPMWRepoResource(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

public class ABTIOPMWRepoResource 
{

}