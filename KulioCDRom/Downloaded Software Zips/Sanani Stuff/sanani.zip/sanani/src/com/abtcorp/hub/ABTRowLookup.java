
package com.abtcorp.hub;

/*
 * ABTRowLookup.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
import java.io.*;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

public class ABTRowLookup extends ABTValue
{
    public ABTValue id;
    public ABTRow row;


  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compareTo  (Object  object)
   {
      if (object == null) return 1;
      if (object instanceof ABTRowLookup)
         return id.compareTo(((ABTRowLookup)object).id);
      if (object instanceof ABTValue)
         return id.compareTo(((ABTValue)object));

      return 1;
   }


    protected ABTRowLookup(ABTValue id_, ABTRow row_)
    {
        id = id_;
        row = row_;
    }

    protected void delete()
    {
        id = null;
        row = null;
    }

    protected void setValue(ABTValue id_)
    {
        id = id_;
    }

    protected void setRow(ABTRow row_)
    {
        row = row_;
    }

    protected boolean isValid()
    {
        return (row != null);
    }

}

