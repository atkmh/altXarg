/*package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.io.team.*;
import com.abtcorp.io.team.connect.data.*;
import com.sun.java.swing.*;
import java.applet.*;

class FileViewerApplet extends Applet implements Runnable
{
    public static void main(String[] args)
    {
        FileViewer fileViewer = new FileViewer(new FileViewerApplet(), 640, 480);
    }

    public void run(){}
}*/