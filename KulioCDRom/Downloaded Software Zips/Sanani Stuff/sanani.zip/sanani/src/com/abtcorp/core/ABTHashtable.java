/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTHashtable.java, 14, 12/7/98 5:24:07 PM, Hans-Joachim Birthelmer$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import java.util.Hashtable;
import java.util.Enumeration;

public class ABTHashtable extends ABTValue
{
   private static final long serialVersionUID = 3395277261591290203L;
   protected Hashtable _htable;

   public ABTHashtable()
   {
      super();
      _htable = new Hashtable();
   }

   public ABTHashtable(int initialCapacity, float loadFactor)
   {
      super();
      _htable = new Hashtable(initialCapacity,loadFactor);
   }

   public ABTHashtable(ABTHashtable table)
   {
      this();
      Enumeration e = table.keys();
      while (e.hasMoreElements())
      {
			Object okey = e.nextElement();
			if (okey instanceof ABTValue)
            put((ABTValue)okey,table.get((ABTValue)okey));
         // what if we hit a key that isn't an ABTValue?
      }
   }

   public Hashtable getHashtable() { return _htable; }

   public synchronized void clear() { _htable.clear(); }
   public synchronized boolean contains(ABTValue value) { return _htable.contains(value); }
   public synchronized boolean containsKey(ABTValue key) { return _htable.containsKey(key); }
   public synchronized boolean containsKey(ABTString key) { return _htable.containsKey(key.stringValue()); }
   public synchronized boolean isEmpty() { return _htable.isEmpty(); }

   public synchronized ABTValue remove(ABTValue key) {
      Object oret = _htable.remove(key);
      if (oret instanceof ABTValue) return (ABTValue)oret;
      if (oret == null) return null;
      return new ABTErrorCore("ABTHashtable",
                              "remove",
                              errorMessages.CORE_ERR_INVALID_TYPE,
                              null);
      }
   public synchronized int size() { return _htable.size(); }
   public synchronized String toString() { return _htable.toString(); }

   public synchronized Enumeration keys() { return _htable.keys(); }
   public synchronized Enumeration elements() { return _htable.elements(); }

   public ABTValue get(ABTValue key){
      Object rval = _htable.get(key);
      if (rval == null) return null;
      if (rval instanceof ABTValue) return (ABTValue)rval;
      return new ABTErrorCore("ABTHashtable",
                              "get",
                              errorMessages.CORE_ERR_INVALID_TYPE,
                              null);
      }
   public ABTValue getItemByKey(ABTValue key){ return get(key); }
   public ABTValue getItemByInt(int key){ return get(new ABTInteger(key)); }
   public ABTValue getItemByString(String key){return get(new ABTString(key));  }

   public ABTValue put(ABTValue key,ABTValue value){
      Object rval = _htable.put(key, value);
      if (rval == null) return null;
      if (rval instanceof ABTValue) return (ABTValue) rval;
      return new ABTErrorCore("ABTHashtable",
                              "put",
                              errorMessages.CORE_ERR_INVALID_TYPE,
                              null);
      }
   public ABTValue putItemByKey(ABTValue key,ABTValue value){ return put(key,value); }
   public ABTValue putItemByInt(int key,ABTValue value){ return put(new ABTInteger(key), value); }
   public ABTValue putItemByString(String key,ABTValue value){ return put(new ABTString(key), value); }

   public synchronized Object clone()
   {
      ABTHashtable result = (ABTHashtable)super.clone();

      result._htable = (Hashtable)_htable.clone();

      return result;
   }
}