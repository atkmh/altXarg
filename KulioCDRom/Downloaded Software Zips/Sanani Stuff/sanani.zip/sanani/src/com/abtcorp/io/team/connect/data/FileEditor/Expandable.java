
package com.abtcorp.io.team.connect.data.FileEditor;

import java.util.Hashtable;


public abstract interface Expandable{

    public Hashtable expand();
}