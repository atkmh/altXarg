package com.abtcorp.io.client.mppfile;

/**
 * ABTClientMppResources.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date		Author			Description
  * 08-27-98	ATW 			Initial Implementation
  * 10-14-98	ATW 			Improved search 'n update logic for populate and save
  *
  */

/**
*  ABTClientMppResources is a helper class which performs the conversion between
*  resources in a Microsoft Project file (MPP) and resources being created
*  in a Sanani project object.
*
*
*  @version 	1.0
*  @author		A. Waller
*  @see 		ABTClientMppHelper
*/


import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTDouble;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.Project;
import com.abtcorp.autowrap.msproject.Resource;
import com.abtcorp.autowrap.msproject.Resources;
import com.abtcorp.autowrap.msproject.Application;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;

public class ABTClientMppResources extends ABTClientMppHelper implements IABTPMRuleConstants,
																		 IABTClientMppDriverConstants,
                                                                         IABTPropertyType
{
	private Project 			mppProject_;
	private IABTObject			projObj_;
	private ABTClientMppRemoteID id_;
	private Hashtable			resHash_;
	private int					convRate;
    private MppFormat			format_;

	// Formatting goodies for converting MSP data to Sanani
	private String				currSymbol_;
	private int 				currSymPos_;
	private short				currDigits_;

	private int 				dateOrder_;
	private int 				dateFormat_;
//	private String				hrLabel_;
	private String				amText_;
	private String				pmText_;

	private String				thouSeparator_;
	private String				dateSeparator_;
	private String				decSeparator_;
	private String				timeSeparator_;

	/**
	*  Empty constructor which calls the constructor of the parent class.
	*/
	public ABTClientMppResources() {/* implicit call to super() here */}

	/**
	*  Construct a resource helper using a Microsoft Project file as the source for the resource data.
	*  @param space an IABTObjectSpace in which the project object has been constructed
	*  @param driver the ABTClientMppDriver calling this helper
	*  @param projectObject the IABTObject project object the resources belong to
	*  @param mppProject a Project reference to the project object in the opened
	*  MPP file from which this helper will read resources
	*  @param populateFully a boolean indicating whether or not the resource
	*  data will modify or replace resource data if it already exists
	*/
	public ABTClientMppResources(IABTObjectSpace space,
								 ABTClientMppDriver driver,
								 IABTObject projectObject,
								 Project mppProject,
								 MppFormat format)
	{
		super( space, driver );
		mppProject_ = mppProject;
		projObj_ = projectObject;
		format_ = format;
	}

	/**
	*  Populate an object space with the resources from an MPP file.
	*  @return an ABTValue which, if successful is a reference to the set of resource
	*  objects in the object space.  Otherwise, return an ABTError.
	*  @exception ABTException if an unrecoverable error occurs.
	*/
	public ABTValue populate() throws ABTException
	{
		ABTValue resObject = null;
		Vector	 resRecs = null;

		initProperties();

		//
		// Iterate through the resources in the MS Project project object and
		// create a resource object for each.
		//
		try
		{
			if ( mppProject_ instanceof Project )
			{
				//
				// Get the resource collection in the MSP project
				//
				Resources resSet = mppProject_.getResources();

				if ( resSet != null )
				{
					int i, count = resSet.getCount();
					if ( count > 0 )
					{
						resRecs = new Vector();
						//
						// Get all the resources from the file at once so we
						// can release the collection object.
						//
						for ( i = 1; i <= count ; i++ )
						{
							Resource mspRes = resSet.getItem( new ABTInteger(i) );
							if ( mspRes != null )
							{
								resRecs.addElement( mspRes );
								mspRes.release();
							}
						}
						resSet.release();

						i = 0; // Reset for use as hash table key.

						//
						// All the resources have been safely extracted.  Now get their data.
						//
						Enumeration e = resRecs.elements();
						while ( e.hasMoreElements() && !ABTError.isError(resObject) )
						{
							Resource rec = (Resource) e.nextElement();
							//
							// Create a remote ID from the project's name and resource's unique ID.
							// Use this to check for an existing resource in the object space.	If
							// it already exists, simply overwrite (update) it.
							//
							id_ = new ABTClientMppRemoteID( mppProject_.getFullName(), rec.getUniqueID() );
							resObject = foundInSpace( rec );

                     		//
                            // Not found in the object space?.  Create it.  The create method will
                            // assign the remote ID that we now know is unique to this new resource.
                            //
							if ( resObject == null )
								resObject = create( null );

							//
							// Either a resource object was created or found in the space.  Put values
							// from the MPP resource into its properties.
							//
							if ( resObject != null && !ABTError.isError( resObject ) )
							{
								IABTObject abtobject = (IABTObject) resObject;
								setValues( rec, abtobject );
								//
								// Successful create and set.  Add it to the hash table of resources.
								// The team populator will use this to create its team records.
								//
								resHash_.put( new ABTInteger( i++ ), abtobject );

								// ** ALERT ** Dave, what if this resource didn't come from this file?
								format_.map_.addResourceToMap(rec, abtobject, rec.getUniqueID());
							}
						}
					}
				}
			}
			else
				resObject = createErrorObject( this.getClass(), ERR_RESOURCE + ERR_POP,
										  ERR_INVAL_IN + mppProject_.getName() );
		}
		catch ( ABTException e )
		{
			resObject = new ABTError( this.getClass(), ERR_POP, e.getMessage(), e );
		}
		catch ( Exception e )
		{
			resObject = new ABTError( this.getClass(), ERR_POP + ERR_JAVA_EXCEPTION, e.getMessage(), e );
		}
		finally
		{
			return resObject;
		}
	}

	/**
	*  Creates a new resource object
	*  @param params optional construction parameters - currently unused
	*  @return an ABTValue which is the newly-created resource object
	*  @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue create( ABTArray params ) //throws ABTException
	{
		ABTValue object = null;
		IABTHashTable reqparms = space_.newABTHashTable();

		try
		{
			// Resources belong to the site we're in.  Get a reference to it.
			IABTObject site = (IABTObject)driver_.getSite( space_ );

			if ( site instanceof IABTObject )
			{
				reqparms.putItemByString( OFD_SITE, (ABTValue)site );
				object = (ABTValue)createObject( OBJ_RESOURCE, id_, reqparms );
			}
		}
		catch ( ABTException e )
		{
			object = createErrorObject( this.getClass(), ERR_RESOURCE + "create", e.getMessage() );
		}
		finally
		{
			return object;
		}
	}

	/**
	*  Updates an existing resource object
	*  @param parms an ABTArray with new settings for the resource object
	*  @return an ABTValue reference which should be the resource object
	*  @exception an ABTException if an unrecoverable error occurs
	*/
	protected ABTValue update( ABTArray parms ) throws ABTException
	{
		ABTValue object = create( parms );
		return object;
	}

	/**
	*  Sets new values into the resource object's properties from values
	*  in a Microsoft Project file's resource.
	*  @param mppResource a Resource in the MPP file
	*  @param obj an IABTObject reference to the resource object currently being modified
	*  @exception an ABTException if an unrecoverable error occurs
	*/
	private void setValues( Resource mppResource, IABTObject obj ) throws ABTException
	{
		String tempStr = null;

		// Fields that other things seem to look for.
		obj.setValue( OFD_NAME, new ABTString( mppResource.getName() ) );
		obj.setValue( OFD_ID, new ABTInteger( mppResource.getUniqueID() ) );

		tempStr = mppResource.getGroup();
		if ( tempStr != null && tempStr.length() > 0 )
			obj.setValue( OFD_CATEGORY, new ABTString( mppResource.getGroup() ) );

		obj.setValue( OFD_COUNT, new ABTDouble( mppResource.getMaxUnits() ) );

		tempStr = mppResource.getInitials();
		if ( tempStr != null && tempStr.length() > 0 )
			obj.setValue( OFD_EXTERNALID, new ABTString( tempStr ) );

		// Get the resource's notes
		tempStr = mppResource.getNotes();
		if ( tempStr.length() > 0 )
		{
			IABTObjectSet noteOSet = getObjectSet( obj, OFD_NOTES );
			IABTObject noteObj = (IABTObject)createObject( OBJ_NOTE, null );
			noteObj.setValue( OFD_VALUE, new ABTString( tempStr ) );
			addListMember( noteOSet, noteObj );
		}

		// Stuff that looks optional but easy to set, so why not?
		obj.setValue( OFD_AVAILUNIT, new ABTShort( (short)0 ) ); // "Day"
		obj.setValue( OFD_ISOPEN, ABTBoolean.True() );
		obj.setValue( OFD_ISROLE, ABTBoolean.False() );
		obj.setValue( OFD_READONLY, ABTBoolean.False() );
		obj.setValue( OFD_TRACKMODE, new ABTShort( (short)2 ) );  // "Team Workbench"
		obj.setValue( OFD_TYPE, new ABTShort( (short)0 ) );  // "Employee"
		obj.setValue( OFD_UNIT, new ABTShort( (short)1 ) );  // "Hours"

		//
		// Using default format settings (and assuming the user hasn't done
		// anything creative with the settings for just these items) get the
		// rate information from the money-per-time representation strings.
		//
		ABTString str = new ABTString (importMoney( (mppResource.getStandardRate()).toString() ) );
		if ( str != null && (str.toString()).length() > 0 )
		{
			ABTDouble money = new ABTDouble( str.doubleValue() / 3600 );
			obj.setValue( OFD_RATE, new ABTDouble ( money ) );
		}
		str = new ABTString( importMoney( (mppResource.getOvertimeRate()).toString() ) );
		if ( str != null && (str.toString()).length() > 0 )
		{
			ABTDouble money = new ABTDouble( str.doubleValue() / 3600 );
			obj.setValue( OFD_OVERTIMERATE, new ABTDouble ( money ) );
		}
	}

   // -------------------------------------------------------------------------------
   // Save methods.
   // -------------------------------------------------------------------------------

	/**
	*  Sets values from a resource object in the object space into an Microsoft Project
	*  Resource object in an MPP file.
	*  @return an ABTError if not successful, null if successful
	*  @exception ABTException if an unrecoverable error occurs
	*/
	public ABTValue save() throws ABTException
	{
		ABTValue resObject = null;

		initProperties();

		//
		// Iterate through the resources in the MS Project.  Save resources that are
		// still in the team objectset, add resources that are new, and leave any
		// resources found which are now unconnected to tasks alone.
		//
		try
		{
			if ( mppProject_ instanceof Project )
			{
				Resources resMPPSet = mppProject_.getResources();
				int i;

				IABTObjectSet teamOSet = getObjectSet( projObj_, OFD_TEAMRESOURCES );
				int teamSetSize = teamOSet.size();

				IABTObject teamObj = null, resObj = null;

				for ( i = 0; i < teamSetSize; i++ )
				{
					Resource mspRes = null;
					teamObj = at( teamOSet, i );
					resObj = getObject( teamObj, OFD_RESOURCE );
					ABTRemoteID id = (ABTRemoteID)resObj.getValue( PROP_REMOTEID );

					//
					// If this resource in the team doesn't have our type of remote ID, it was created
					// in the team while in the object space and wasn't read from this MPP file.  Or if
					// it is from an MPP file but not THIS file, also try to match it in this file.
					// If there's no match, it needs to be added to the file.
					//
					if ( id == null || ( (id instanceof ABTRemoteID) && !(id instanceof ABTClientMppRemoteID) ) ||
						 !((((ABTClientMppRemoteID)id).getFileName()).equalsIgnoreCase((resMPPSet.getParent()).getFullName())) )
						mspRes = foundInFile( resObj, resMPPSet );
					else if ( id instanceof ABTClientMppRemoteID )
                    {
						// Is this the same file the resource was read from?  If so, try to locate it again.
						if ( (((ABTClientMppRemoteID)id).getFileName()).equalsIgnoreCase((resMPPSet.getParent()).getFullName()) )
                        	mspRes = resMPPSet.getUniqueID( ((ABTClientMppRemoteID)id).getUniqueID() );
					}

					if ( mspRes == null )
						mspRes = resMPPSet.Add( resObj.getValue( OFD_NAME ), ABTEmpty.getEmpty() );

					// Having finally been able to get or create an MPP resource, update it from the object.
					if ( mspRes instanceof Resource )
					{
						getValues( mspRes, resObj );
		                format_.map_.addResourceToMap(mspRes, resObj, mspRes.getUniqueID()); // **** ddp added 11/5/98 
						// If this resource is completely new, give it our remote ID.
						if ( id == null )
						{
							id = new ABTClientMppRemoteID( mppProject_.getFullName(),
														   mspRes.getUniqueID() );
							resObj.setValue( PROP_REMOTEID, id );
						}
					}

					// Done with this MPP record.
					if ( mspRes != null )
						mspRes.release();
				}

				// Done with the resources collection in the MPP file.
				resMPPSet.release();
			}
			else
				resObject = createErrorObject( this.getClass(), ERR_SAVE,
										  ERR_INVAL_IN + mppProject_.getName() );
		}
		catch ( ABTException e )
		{
			resObject = createErrorObject( this.getClass(), ERR_SAVE, e.getMessage() );
		}
		catch ( Exception e )
		{
			resObject = new ABTError( this.getClass(), ERR_SAVE + ERR_JAVA_EXCEPTION, e.getMessage(), e );
		}

		return resObject;  // Null if successful, ABTError if not
	}


	/**
	*  Transfers values from a Sanani resource object's properties to
	*  a Microsoft Project Resource object.
	*  @param mppResource a Resource in an MPP file to save into
	*  @param obj an IABTObject reference to the resource object to save data from
	*  @exception ABTException if an unrecoverable error occurs
	*/
	private void getValues( Resource mppRes, IABTObject obj ) throws ABTException
	{
		ABTString tempStr = null;
		ABTValue  val = null;
		ABTInteger tempInt = null;
		ABTDouble tempDbl = null;
		String str = null;

		tempStr = new ABTString( getValue( obj, OFD_NAME ) );
		if ( tempStr != null && ((tempStr.stringValue()).length() > 0) )
			mppRes.setName( tempStr.stringValue() );

		tempStr = new ABTString( getValue( obj, OFD_EXTERNALID ) );
		if ( tempStr != null && ((tempStr.stringValue()).length() > 0) )
			mppRes.setInitials( tempStr.stringValue() );

		tempStr = new ABTString( getValue( obj, OFD_CATEGORY ) );
		if ( tempStr != null && tempStr.stringValue() != null )
			mppRes.setGroup( tempStr.stringValue() );

		mppRes.setMaxUnits( new ABTDouble( getValue( obj, OFD_COUNT ) ) );

		val = getValue( obj, OFD_RATE );
		if ( val instanceof ABTDouble )
		{
			tempDbl = (ABTDouble)val;
			str = new String( exportMoney( tempDbl.doubleValue() ) );
			if ( str != null && str.length() > 0 )
				mppRes.setStandardRate( new ABTString( str ) );
		}

		val = getValue( obj, OFD_OVERTIMERATE );
		if ( val instanceof ABTDouble )
		{
			tempDbl = (ABTDouble)val;
			str = new String( exportMoney( tempDbl.doubleValue() ) );
			if ( str != null && str.length() > 0 )
				mppRes.setOvertimeRate( new ABTString( str ) );
		}

		//
        // Do the availability from/to dates from the team object for this resource.
		//
		ABTValue teamObj = find( OFD_TEAM, (ABTRemoteID)obj.getValue( PROP_REMOTEID ) );
		if ( teamObj instanceof IABTObject )
		{
			ABTValue from = ((IABTObject)teamObj).getValue( OFD_AVAILSTART );
			ABTValue to = ((IABTObject)teamObj).getValue( OFD_AVAILFINISH );
			if ( from instanceof ABTTime )
				mppRes.setAvailableFrom( from );
			if ( to instanceof ABTTime )
				mppRes.setAvailableTo( to );
		}

		//
		// Concatenate all notes.
		//
		IABTObjectSet noteSet = getObjectSet( obj, OFD_NOTES );
		if ( noteSet.size() > 0 )
		{
			StringBuffer noteBuf = new StringBuffer();

			for ( int k = 0; k < noteSet.size(); k++ )
			{
				IABTObject noteObj = (IABTObject) noteSet.at( k );
				val = noteObj.getValue( OFD_VALUE );
				tempStr = (ABTString)val;
				if ( tempStr != null && (tempStr.stringValue()).length() > 0 )
					noteBuf.append( tempStr.stringValue() + " " );
			}
			mppRes.setNotes( noteBuf.toString() );
		}
		else  // Assume there should be no notes if there are no notes.
			mppRes.setNotes( "" );
	}

	// -------------------------------------------------------------------------------
	// Utility and initialization methods.
	// -------------------------------------------------------------------------------

	/**
	*  Returns a reference to the resource object hashtable that was
	*  created during the populate process
	*  @return the Hashtable containing references to all the resources in the project
	*/
	public Hashtable getResourceHashTable()
	{
		return resHash_;
	}

	/**
	*  Initialize settings variables from MSP data.
	*/
	private void initProperties()
	{
		Application mspApp = mppProject_.getApplication();
		ABTString tempStr = null;
		int idx = -1;

		// Get these conversion settings and strings.
		currSymbol_ = mppProject_.getCurrencySymbol();
		currSymPos_ = mppProject_.getCurrencySymbolPosition();
		currDigits_ = mppProject_.getCurrencyDigits();

		dateOrder_ = mspApp.getDateOrder();
		dateFormat_ = mspApp.getDefaultDateFormat();
		amText_ = mspApp.getAMText();
		pmText_ = mspApp.getPMText();

		thouSeparator_ = mspApp.getThousandSeparator();
		dateSeparator_ = mspApp.getDateSeparator();
		decSeparator_ = mspApp.getDecimalSeparator();
		timeSeparator_ = mspApp.getTimeSeparator();

		// Assume resource cost rate will be in money-per-hour.  If not, 
		// the conversion multiplier/divider has to be changed.
		convRate = 3600;

		// Initialize table used to pass resources to other populators.
		if ( resHash_ == null )
			resHash_ = new Hashtable();
	}

	/**
	*  Find a resource in the MPP file matching a resource object in the
	*  object space.  Search is done by matching the initials in the
	*  resource object to the initials of a resource in the file.
	*  @param resObj the IABTObject reference to the resource to be located
	*  @param resSet the Resources set from the currently open MPP file
	*  @return a Resource if found in the MPP file, null if not found
	*/
	private Resource foundInFile( IABTObject resObj, Resources resSet )
	{
		Resource resRec = null;
		int count = resSet.getCount();

		ABTString extIDStr = new ABTString( resObj.getValue( OFD_EXTERNALID ) );

		//
		// If there is a resource in the file with initials matching the
		// resource object's external ID, return it for update.
		//
		for ( int i = 1; i <= count; i++ )
		{
			resRec = resSet.getItem( new ABTInteger(i) );
			if ( (resRec.getInitials()).equals( extIDStr.toString() ) )
				break;
        	resRec = null;
		}

		return resRec;
	}

	/**
	*  Find a resource in the object space matching an MPP resource.
	*  Search is done by first matching the unique ID part of the
	*  resource object's remote ID to the unique ID of a resource in the file.  If
    *  there is no unique ID / remote ID match, this method then tries to find
    *  the resource by comparing the external ID of the resource object in the space
    *  with the initials field of each resource in the file.
	*  @param mppRes a Resource from the currently open MPP file
	*  @return an ABTValue reference to the resource object if found in the
	*  space, null if not found
	*  @exception ABTException thrown if an error occurs. The return value becomes
	*  a formatted ABTError.
	*/
	private ABTValue foundInSpace( Resource mppRes ) throws ABTException
	{
		ABTValue retVal = null, tempVal = null;
		String extIDStr = mppRes.getInitials();
		IABTObjectSet resOSet = null;

		//
		// Search for a resource with this remote ID.  If there isn't one, search
		// for one with matching initials (external ID).
		//
//		try
		{
			retVal = find( OBJ_RESOURCE, id_ );
			if( ABTError.isError( retVal ) )
			{
				retVal = null;
				resOSet = getObjectSet( ((IABTObject)driver_.getSite( space_ )), OFD_RESOURCES );

				// Try to match the Resource initials to a resource object external ID.
				for ( int k = 0; k < resOSet.size(); k++ )
				{
					IABTObject resObj = (IABTObject) resOSet.at( k );
					ABTValue val = resObj.getValue( OFD_EXTERNALID );

					String tempStr = ((ABTString)val).stringValue();
					if ( tempStr != null && tempStr.length() > 0 &&
						 tempStr.equals( extIDStr ) )
					{
						retVal = (ABTValue)resObj;
						break;
					}
					retVal = null;
				}
			}
		}
//		catch ( ABTException e )
//		{
//			retVal = createErrorObject( this.getClass(), ERR_POP, e.getMessage() );
//		}

		return retVal;
	}
	
	/**
	*  Strip extraneous information from the string returned from getting
	*  the standard rate field of a Microsoft Project resource.  This method
	*  removes the currency symbol wherever it is in the string, embedded blanks,
	*  and the "/hours" at the end of the string.
	*  @param inString the String object returned from the getStandardRate call
	*  @return a String object containing the amount with decimal places preserved
	*/
	private String importMoney( String inString )
	{
		int separatorIdx = -1;
		double tempInt = 0;
		String retStr = null;

		if ( inString != null && inString.length() > 0 )
		{
			separatorIdx = inString.indexOf( "/" );

			// Save whatever string we're using in this file to specify "hours"
//			if ( hrLabel_ == null )
//				hrLabel_ = new String( inString.substring( separatorIdx+1 ) );

			// If currency symbol is at the beginning of the string, the
			// amount follows and the string up to the "/" is it.  If the
			// currency symbol follows the amount, the portion of the string
			// before it must be the amount. (currSymPos_ is a value from
			// an enum, not the actual position.)
			if ( currSymPos_ == 0 || currSymPos_ == 2 )
			{
				retStr = new String( inString.substring( 1, separatorIdx ) );
			}
			else  // Symbol follows the amount.
			{
				int tempIdx = inString.indexOf( currSymbol_ );
				retStr = new String( inString.substring( 0, tempIdx ) );
			}

			// Remove leading/trailing spaces.
			retStr.trim();
		}

		return retStr;
	}

	/**
	*  Build a string representing the MPP resource's standard rate for passing to
	*  the setStandardRate method of a Microsoft Project resource.	This method
	*  formats the string using the default currency symbol and currency string
	*  format settings from the MPP file.
	*  @param money a double representing the Resource's standard rate in
	*  dollars (or whatever the currency really is) per second
	*  @return a String object formatted for the MSP file. Example:"$150.00/hr"
	*/
	private String exportMoney( double money )
	{
		String retStr = null;
		Double moneyDbl = new Double( money * 3600 ); //Per second -> per hour

		// Convert the amount to a string and add the currency specifier
		// and other characters to make a well-formed string for MSP.
		switch ( currSymPos_ )
		{
			case 0:
				retStr = currSymbol_ + moneyDbl.toString() + "/h"; // + hrLabel_;
				break;

			case 1:
				retStr = moneyDbl.toString() + currSymbol_ + "/h"; // + hrLabel_;
				break;

			case 2:
				retStr = currSymbol_ + " " + moneyDbl.toString() + "/h"; // + hrLabel_;
				break;

			case 3:
				retStr = moneyDbl.toString() + " " + currSymbol_ + "/h"; // + hrLabel_;
				break;
		}

		return retStr;
	}
}
