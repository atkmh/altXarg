package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileTask.java 08/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-05-98    MXA         Initial Implementation
 *
 *
 */
import java.io.File;
import java.util.Hashtable;

//DEBUG
import java.util.Vector;
import java.util.Enumeration;
//DEBUG
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTHashTable;

// DEBUG
import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTObjectSetIDList;

import  com.abtcorp.api.local.ABTHashTable;

/**
 *  ABTIOPMWFileTask is a helper class for the ABT PMW Local File driver.
 *  It is instantiated by the ABTIOPMWFileProject object.
 *
 *  <pre>
 *        ABTIOPMWFileTask ft = new ABTIOPMWFileTask(driver, project);
 *
 *  </pre>

 * @version	1.0
 * @author		 M. Abadian
 */

public class ABTIOPMWFileTask extends ABTIOPMWFileHelper implements IABTPMRuleConstants,IABTIOPMWFileConstants
{
   static  Vector       taskVector_ = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTIOPMWFileTask constructor.
 * @param driver:  the reference to the ABTIOPMWFileDriver.
 * @param parent:  the project that owns all the tasks.

 */
   ABTIOPMWFileTask(ABTIOPMWFileDriver driver)
   {
     super(driver);
     type_ = OBJ_TASK;
     taskVector_ = null;

   }

//====================================================================================
// Populate Task from the Intermediate Hash Table
//====================================================================================

/**
 * Populate task objects from the Intermediate Hash Table to the space
 * @param Hashtable parms,
 * @return an ABTValue the task object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */

 public ABTValue populate(Hashtable parms) throws ABTException
 {
    IABTLocalID taskID  = null;
    IABTObject  project = null;
    IABTObject  parent  = null;
    IABTLocalID parentLastChildID = null;
    Object      object  = null;
    ABTValue    task    = null;

    System.out.print(" Populate Task: ");
    try
    {
        //Get the task ID
        object = null;
        object = parms.get(TASK_ID);
        if (object instanceof IABTLocalID)
            taskID = (IABTLocalID)object;


        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        //Get the parent object
        object = null;
        object = parms.get(PARENT_OBJ);
        if (object == PARENT_OBJ)
            parent = null;
        if (object instanceof IABTObject)
            parent  = (IABTObject)object;

        //Get the parent last child task ID
        object = null;
        object = parms.get(PARENTLASTCHILD_ID);
        if (object instanceof IABTLocalID)
            parentLastChildID  = (IABTLocalID)object;

        //Create Task
        task = createTask(taskID, project, parent, parentLastChildID);

        //Get the All task IDs
        object = null;
        object = parms.get(ALLTASK_ID);

        if (object instanceof ABTObjectSetIDList)
        {
            ABTObjectSetIDList allTaskIDs  = (ABTObjectSetIDList)object;
            setReferences(allTaskIDs);
        }
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
        return task;
    }
 }
protected ABTValue setReferences(ABTObjectSetIDList allTaskIDs)throws ABTException
{
    ABTValue        val       = null;
    IABTArray       taskArr   = null;
    Object          object    = null;
    IABTObject      curTask   = null;
    IABTPropertySet propSet   = null;

    try
    {
        //Get the property set associated with the task
        propSet = null;
        propSet = getProperties(type_);

        if (allTaskIDs != null)
        {
            Enumeration itID = allTaskIDs.getActiveIDs();
            while( itID.hasMoreElements() )
            {
                IABTLocalID taskID = (IABTLocalID)itID.nextElement();

                // Get the array of value associated with task
                object = null;
                object = driver_.intermediateTableGet(taskID);
                if (object instanceof IABTArray)
                    taskArr = (IABTArray) object;


                //Get Predecessor Dependency IDs
                ABTValue predDepIDs = null;
                predDepIDs = getHashValue(taskArr, propSet, OFD_PREDDEPENDENCIES);
                if (predDepIDs != null)
                {
                    ABTIOPMWFileDependency predDepHelper = new ABTIOPMWFileDependency(driver_);
                    Hashtable reqPredDepParms = new Hashtable();
                    reqPredDepParms.put(DEPENDENCIES_ID,      predDepIDs );
                    predDepHelper.populate(reqPredDepParms);
                }

                //Get Successor Dependency IDs
                ABTValue succDepIDs = null;
                succDepIDs = getHashValue(taskArr, propSet, OFD_SUCCDEPENDENCIES);
                if (succDepIDs != null)
                {
                    ABTIOPMWFileDependency succDepHelper = new ABTIOPMWFileDependency(driver_);
                    Hashtable reqPredDepParms = new Hashtable();
                    reqPredDepParms.put(DEPENDENCIES_ID,      succDepIDs);
                    succDepHelper.populate(reqPredDepParms);
                }


            }
        }
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
    return (ABTValue)null;
    }

}

 /**
 * Create a new Task in the object space and initialize it with appropriate values
 * @param associated task id in the intermediate hash table,the project object,
 *                         the parent object and the parent's last child id.
 * @return ABTValue the newly created task
 * @exception ABTException if an unrecoverable error occurs.
 */

 protected ABTValue createTask(IABTLocalID taskID, IABTObject project, IABTObject parent, IABTLocalID  parentLastChildID) throws ABTException
 {
      ABTValue    val              = null;
      IABTArray    taskArr          = null;
      IABTArray    projectArr       = null;
      Object      object           = null;
      IABTLocalID  firstChildTaskID = null;
      IABTLocalID  lastChildTaskID  = null;
      IABTLocalID  nextTaskID       = null;
      IABTObject  curTask          = null;
      Hashtable   reqparms         = null;
      IABTPropertySet propSet      = null;

      try
      {
          //Create the task
          reqparms = new Hashtable();
          reqparms.put(TARGET_OBJ, taskID);
          reqparms.put(OFD_PROJECT, project);
          if (parent == null)
            reqparms.put(OFD_PARENTTASK, OFD_PARENTTASK);
          else
            reqparms.put(OFD_PARENTTASK, parent);

          //Set the current task
          curTask = (IABTObject)create(reqparms);

          // Get the array of value associated with task
          object = null;
          object = driver_.intermediateTableGet(taskID);
          if (object instanceof IABTArray)
            taskArr = (IABTArray) object;

          //Get the property set associated with the task
          propSet = null;
          propSet = getProperties(type_);

          //Get task's first child task ID
          val = null;
          firstChildTaskID = null;

          val = getHashValue(taskArr, propSet, OFD_FIRSTCHILDTASK);
          if (val instanceof IABTLocalID)
            firstChildTaskID = (IABTLocalID)val;

          //Get task's last child task ID
          val = null;
          lastChildTaskID = null;

          val = getHashValue(taskArr, propSet, OFD_LASTCHILDTASK);
          if (val instanceof IABTLocalID)
            lastChildTaskID = (IABTLocalID)val;

          //Get task's next task ID
          val = null;
          nextTaskID = null;

          val = getHashValue(taskArr, propSet, OFD_NEXTTASK);
          if (val instanceof IABTLocalID)
            nextTaskID = (IABTLocalID)val;



          if ( firstChildTaskID != null )
              createTask(firstChildTaskID, project, curTask, lastChildTaskID);


          if ( taskID.equals(lastChildTaskID))
            return (ABTValue)curTask;

          if ( nextTaskID != null)
            createTask(nextTaskID, project, parent, lastChildTaskID);
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
    return (ABTValue)curTask;
    }
 }



 /**
 * Create a new object in the object space and initialize it with appropriate values
 * @param Hashtable parms, the Task ID (in the intermesiate hash table), the project that the task belong to,
 *                         the parent task associated with the task.
 * @return ABTValue the newly created team
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue create(Hashtable parms) throws ABTException
   {
          IABTLocalID taskID   = null;
          IABTObject project   = null;
          IABTObject parent    = null;
          Object object        = null;
          IABTObject taskObj   = null;
      try
      {
          //Get the task ID
          object = parms.get(TARGET_OBJ);
          if (object instanceof IABTLocalID)
             taskID  = (IABTLocalID)object;

          //Check if task has been created
          object = null;
          object = driver_.lookupTableGet(taskID);
          if (object != null && object instanceof IABTObject)
          {
            taskObj = (IABTObject)object;
            return (ABTValue)taskObj;
          }

          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object;

          //Get the parent of the task
          object = null;
          object = parms.get(OFD_PARENTTASK);
          if (object == OFD_PARENTTASK)
            parent = null;
          if (object instanceof IABTObject)
            parent = (IABTObject)object;


          // Get the array of value associated with task
          IABTArray   taskArr  = null;
          object = null;

          object = driver_.intermediateTableGet(taskID);
          if (object instanceof IABTArray)
            taskArr = (IABTArray) object;

          //Get the property set associated with the task
          IABTPropertySet propSet = null;
          propSet = getProperties(type_);

          //Get the task's RemoteID
          ABTValue  id = null;
          taskObj = null;

          id = getHashValue(taskArr, propSet, PROP_REMOTEID);
          if (id instanceof ABTEmpty)
            id = null;
          if ( (ABTValue.isNull(id)) || (id instanceof ABTRemoteID) )
          {
            IABTHashTable reqparms = (getSpace()).newABTHashTable();
            reqparms.putItemByString(OFD_PROJECT, (ABTValue)project);
            if ( parent!= null )
                reqparms.putItemByString(OFD_PARENTTASK, (ABTValue)parent);

            taskObj = createObject(type_,(ABTRemoteID)id, reqparms);
            //Add it to the LookupTable
            driver_.lookupTablePut(taskID, taskObj);
          }
          else
            new ABTException(" WRONG TYPE CAST");

          //Set Resource's scalar values.
          setScalarValues(propSet, taskArr, taskObj);

          //Get task's assignment IDs
          ABTValue assignmentIDs = null;
          assignmentIDs = getHashValue(taskArr, propSet, OFD_ASSIGNMENTS);
          if (assignmentIDs != null)
          {
            ABTIOPMWFileAssignment assignmentHelper = new ABTIOPMWFileAssignment(driver_);
            Hashtable reqAssgnParms = new Hashtable();
            reqAssgnParms.put(OFD_PROJECT, project);
            reqAssgnParms.put(ASSIGNMENT_ID, assignmentIDs);
            reqAssgnParms.put(TARGET_OBJ, taskObj);
            assignmentHelper.populate(reqAssgnParms);
          }

          //Get task's deliverable IDs
          ABTValue deliverableIDs = null;
          deliverableIDs = getHashValue(taskArr, propSet, OFD_DELIVERABLES);
          if (deliverableIDs != null)
          {
            ABTIOPMWFileDeliverable deliverableHelper = new ABTIOPMWFileDeliverable(driver_);
            Hashtable reqDeliverableParms = new Hashtable();
            reqDeliverableParms.put(OFD_PROJECT, project);
            reqDeliverableParms.put(DELIVERABLE_ID, deliverableIDs);
            reqDeliverableParms.put(TARGET_OBJ, taskObj);
            deliverableHelper.populate(reqDeliverableParms);
          }
          //Get task's Constraint IDs
          ABTValue constraintIDs = null;
          constraintIDs = getHashValue(taskArr, propSet, OFD_CONSTRAINTS);
          if (constraintIDs != null)
          {
            ABTIOPMWFileConstraint constraintHelper = new ABTIOPMWFileConstraint(driver_);
            Hashtable reqConstraintParms = new Hashtable();
            reqConstraintParms.put(OFD_PROJECT,     project);
            reqConstraintParms.put(CONSTRAINT_ID, constraintIDs);
            reqConstraintParms.put(TARGET_OBJ,      taskObj);
            constraintHelper.populate(reqConstraintParms);
          }

          //Get task's Custom Field IDs
          ABTValue custfieldIDs = null;
          custfieldIDs = getHashValue(taskArr, propSet, OFD_CUSTFIELDVALUES);
          if (custfieldIDs != null)
          {
            ABTIOPMWFileCustomFieldValue custfieldHelper = new ABTIOPMWFileCustomFieldValue(driver_);
            Hashtable reqCustfieldParms = new Hashtable();
            reqCustfieldParms.put(OFD_PROJECT,     project);
            reqCustfieldParms.put(CUSTOMFIELD_ID,  custfieldIDs);
            reqCustfieldParms.put(TARGET_OBJ,      taskObj);
            custfieldHelper.populate(reqCustfieldParms);
          }

          //Get task's Task Estimate ID
          ABTValue taskEstID = null;
          taskEstID = getHashValue(taskArr, propSet, OFD_TASKESTIMATES);
          if (taskEstID != null)
          {
            ABTIOPMWFileTaskEstimate taskEstHelper = new ABTIOPMWFileTaskEstimate(driver_);
            Hashtable reqTaskEstParms = new Hashtable();
            reqTaskEstParms.put(OFD_PROJECT,     project);
            reqTaskEstParms.put(TASKESTIMATES_ID,  taskEstID);
            reqTaskEstParms.put(TARGET_OBJ,      taskObj);
            taskEstHelper.populate(reqTaskEstParms);
          }



        //Populate Task's notes
        ABTValue  noteVal = null;
        noteVal = getHashValue(taskArr, propSet, OFD_NOTES);

        ABTIOPMWFileNote noteHelper = new ABTIOPMWFileNote(driver_);

        Hashtable reqNoteParms = new Hashtable();
        reqNoteParms.put(OFD_PROJECT,project);

        if (noteVal == null)
            reqNoteParms.put(OFD_NOTES,OFD_NOTES);
        else
            reqNoteParms.put(OFD_NOTES,noteVal);

        reqNoteParms.put(TARGET_OBJ, taskObj);

        noteHelper.populate(reqNoteParms);
      }
      catch (Exception e)
      {
        throw new ABTException(e.getMessage());
      }
      finally
      {
        return (ABTValue)taskObj;
      }
   }

//====================================================================================
// Save Task to an Intermediate Hash Table
//====================================================================================

/**
 * Saves objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms,
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   IABTObjectSet  tasks = null;
   IABTArray       arr   = null;

   taskVector_        = new Vector();

   try{
        IABTObject project = null;

        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        if (project == null)
            throw new ABTException("The current project is null.");

        //Get the All task Obj
        object = null;
        object = parms.get(ALLTASK_OBJ);

        if (object instanceof IABTObjectSet)
        {
            tasks  = (IABTObjectSet)object;
        }
        else
            return;

      for (int i = 0; i < size(tasks); i++)
      {
         IABTObject task = (IABTObject)at(tasks, i);

         // Make sure the object is of type task
         if (!task.getObjectType().equals(type_))
            processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

         // Load the values of the properties associated with the task in an array
         arr = loadObjectPropertyValues(task);
         if (arr==null)
            throw new ABTException("The TASK arr is null.");

         //Get the Intermediate Hash Table
         if (driver_.isIntermediateTableNull())
            throw new ABTException("The Intermediate Hash Table is null.");

        IABTLocalID taskId = task.getID();
        if (taskId == null)
            throw new ABTException("TASK ID is null.");

        
        driver_.intermediateTablePut(taskId, arr);
        //if (( driver_.intermediateTablePut(taskId, arr)) != null)
        //   throw new ABTException("The ID already exist.");

         //DEBUG
         taskVector_.addElement(taskId);

      }
   }  catch (Exception e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }





 }