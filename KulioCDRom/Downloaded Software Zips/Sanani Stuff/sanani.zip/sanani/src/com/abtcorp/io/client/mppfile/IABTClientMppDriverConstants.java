package com.abtcorp.io.client.mppfile;
/*
 * IABTMppFileDriverConstants.java 08/17/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date		Author			Description
  * 08-17-98	ATW 			Initial Implementation
  *
  */

/**
 *	IABTMppFileDriverConstants is a Java interface specifying string constants for exceptions
 *	and error messages for the MPP file driver.
 *
 *
 * @version 	1.0
 * @author		A. Waller
 * @see 		ABTClientDriver
 */


public interface IABTClientMppDriverConstants
{
//	public static final String RULE_BASE		   = "com.abtcorp.objectModel".intern();

	// General errors.
	public static final String ERR_NO_PROJ		   = "Project object not found".intern();
	public static final String ERR_NO_TASK_OSET    = "Task object set not found".intern();
	public static final String ERR_NO_RES_OSET	   = "Resource object set not found".intern();
	public static final String ERR_BAD_PARAM	   = "Required parameter is invalid".intern();
	public static final String ERR_MISSING_PARAM   = "Required parameter is missing".intern();
	public static final String ERR_JAVA_EXCEPTION  = "Java exception ".intern();

	
	// Helper name strings for formatting error messages.
	public static final String ERR_PROJECT		   = "Project ".intern();
	public static final String ERR_TASK 		   = "Task ".intern();
	public static final String ERR_RESOURCE 	   = "Resource ".intern();
	public static final String ERR_ASSIGNMENT	   = "Assignment ".intern();
	public static final String ERR_DEPENDENCY	   = "Dependency ".intern();
	public static final String ERR_NOTE 		   = "Note ".intern();
	public static final String ERR_CONSTRAINT	   = "Constraint ".intern();
	public static final String ERR_TEAM 		   = "Team ".intern();


	// Text for open errors.
	public static final String ERR_OPEN 		   = "Open error: ".intern();
	public static final String ERR_OPEN_OBJ_SPACE  = "No object space specified".intern();
	public static final String ERR_OPEN_BAD_OS	   = "Invalid object space".intern();
	public static final String ERR_OPEN_FILE_OPEN1 = "File ".intern();
	public static final String ERR_OPEN_FILE_OPEN2 = " is already open".intern();
	public static final String ERR_OPEN_CLOSEFIRST = " is open.  Close before opening ".intern();
	public static final String ERR_OPEN_NO_FILE	   = "No filename specified".intern();
	public static final String ERR_OPEN_BADPATH	   = "Invalid filename or path not absolute".intern();
	public static final String ERR_OPEN_NOTFOUND   = "Can't find MPP file ".intern();
	public static final String ERR_OPEN_BAD_KEY    = "Invalid argument".intern();

	
	// Text for populate errors.
	public static final String ERR_POP			   = "Populate error: ".intern();
	public static final String ERR_POP_CREATE	   = "Unable to create Project ".intern();
	public static final String ERR_POP_BAD_MSTASK  = "Bad MSP task object".intern();
	public static final String ERR_POP_BAD_MSTASKS = "Bad MSP task collection".intern();


	// Text for save errors.
	public static final String ERR_SAVE 		   = "Save error: ".intern();
	public static final String ERR_SAVE_FILE	   = "Error saving file ".intern();


	// Text for close errors.
	public static final String ERR_CLOSE		   = "Close error: ".intern();
	public static final String ERR_CLOSE_FILE	   = "Error closing file ".intern();


	// Text for errors in MPP file objects.
	public static final String ERR_OPEN_MSP 	   = "Unable to open Microsoft Project".intern();
	public static final String ERR_CLOSE_MSP	   = "Error closing Microsoft Project".intern();
	public static final String ERR_BAD_MSPROJ	   = "Bad MSP active project".intern();
	public static final String ERR_BAD_MSTASK	   = "Bad MSP task object".intern();
	public static final String ERR_BAD_MSTASKS	   = "Bad MSP task collection".intern();
	public static final String ERR_INVAL_IN 	   = "Invalid project in ".intern();
}