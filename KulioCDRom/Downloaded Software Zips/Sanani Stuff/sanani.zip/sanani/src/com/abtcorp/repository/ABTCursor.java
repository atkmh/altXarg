package com.abtcorp.repository;

import com.abtcorp.core.*;

public class ABTCursor extends ABTNative
{
   ABTRepository repository_;

   public final static int ABSOLUTE = 1;
   public final static int RELATIVE = 2;

   public final static int FIRST    = 1;
   public final static int LAST	   = 2;
   public final static int NEXT	   = 3;
   public final static int PREV	   = 4;
   public final static int BINARY	= 8;

   public final static int NPOS     = -1;

   ABTCursor(int handle, ABTRepository repository) {super(handle); repository_ = repository; repository_.addref();}

   public void addref()                  {super.addref(); repository_.addref();}
   public void release(boolean finalize) {super.release(finalize); repository_.release(false);}

   public ABTRepository getRepository() {return repository_;}

   public native String    getTableName();
   public native boolean   isValid();
   public native int       getRecordCount();
   public native int       getCurrentRecord();
   public native ABTTime   getCursorTime();

   public native String    getFilter();
   public native void      setFilter(String filter);
   public native void      andFilter(String term);
   public native void      orFilter(String term);

   public native String    getSort();
   public native void      setSort(String sort);
   public native void      addSort(String term);

   public native void      sort(String field, boolean ascending);

   public native void      refresh();
   public native int       addNew();
   public native int       edit();
   public native int       update();
   public native void      cancel();
   public native boolean   delete();
   public native void      deleteAll();
   public native boolean   drop();

   public native int       procedure(String name);
   public native int       checkLock(String name, boolean wait);
   public native int       lock(String name, boolean wait);
   public native int       unlock(String name);

   public native ABTValue  getField(String field);
   public native int       setField(String field, ABTValue value);
   public native boolean   move(int type, int n);
   public native boolean   search(String field, ABTValue value, int type);

   public void sort(String field)   {sort(field, true);}

   public boolean getFieldBoolean(String field)          
   {
      ABTValue value = getField(field);
      
      if (value == null) return false;
      
      return value.booleanValue();
   }
   
   public short   getFieldShort(String field)            
   {
      ABTValue value = getField(field);
      
      if (value == null) return 0;
      return value.shortValue();
   }
   
   public int		getFieldInt(String field)              
   {
      ABTValue value = getField(field);
      
      if (value == null) return 0;
      return value.intValue();
   }
   
   public double  getFieldDouble(String field)           
   {
      ABTValue value = getField(field);
      
      if (value == null) return 0.0;
      
      return value.doubleValue();
   }
   public String  getFieldString(String field)           
   {
      ABTValue value = getField(field);
      
      if (value == null) return null;
      
      return value.stringValue();
   }
   
   public ABTDate	getFieldDate(String field, boolean pm) 
   {
      ABTValue value = getField(field);
      
      if (value == null) return null;
      
      return value.dateValue(pm);      
   }
   
   public ABTTime getFieldTime(String field)
   {
      ABTValue value = getField(field);
      
      if (value == null) return null;
      
      return value.timeValue();
   }
   public boolean isFieldNull(String field)              {return getField(field) == null;}

   public int  setFieldBoolean(String field, boolean value) {return setField(field, new ABTBoolean(value));}
   public int  setFieldShort(String field, short value)     {return setField(field, new ABTShort(value));}
   public int  setFieldInt(String field, int value)         {return setField(field, new ABTInteger(value));}
   public int  setFieldDouble(String field, double value)   {return setField(field, new ABTDouble(value));}
   public int  setFieldString(String field, String value)   {return setField(field, new ABTString(value));}
   public int  setFieldDate(String field, ABTDate value)    {return setField(field, value);}
   public int  setFieldTime(String field, ABTTime value)    {return setField(field, value);}
   public int  setFieldNull(String field)                   {return setField(field, null);}

   public boolean moveBOF()      {return move(ABSOLUTE, NPOS);}
   public boolean moveEOF()      {return move(ABSOLUTE, getRecordCount());}
   public boolean moveFirst()    {return move(ABSOLUTE, 0);}
   public boolean moveLast()     {return move(ABSOLUTE, getRecordCount() - 1);}
   public boolean moveNext()     {return move(RELATIVE, +1);}
   public boolean movePrev()     {return move(RELATIVE, -1);}
   public boolean moveTo(int n)  {return move(ABSOLUTE, n);}

   public boolean lsearchFirst(String field, ABTValue value)   {return search(field, value, FIRST);}
   public boolean lsearchLast(String field, ABTValue value)    {return search(field, value, LAST);}
   public boolean lsearchNext(String field, ABTValue value)    {return search(field, value, NEXT);}
   public boolean lsearchPrev(String field, ABTValue value)    {return search(field, value, PREV);}

   public boolean bsearchFirst(String field, ABTValue value)   {return search(field, value, BINARY | FIRST);}
   public boolean bsearchLast(String field, ABTValue value)    {return search(field, value, BINARY | LAST);}
   public boolean bsearchNext(String field, ABTValue value)    {return search(field, value, BINARY | NEXT);}
   public boolean bsearchPrev(String field, ABTValue value)    {return search(field, value, BINARY | PREV);}

   public boolean lsearchFirstBoolean(String field, boolean value)   {return lsearchFirst(field, new ABTBoolean(value));}
   public boolean lsearchFirstShort(String field, short value)       {return lsearchFirst(field, new ABTShort(value));}
   public boolean lsearchFirstInt(String field, int value)           {return lsearchFirst(field, new ABTInteger(value));}
   public boolean lsearchFirstDouble(String field, double value)     {return lsearchFirst(field, new ABTDouble(value));}
   public boolean lsearchFirstString(String field, String value)     {return lsearchFirst(field, new ABTString(value));}
   public boolean lsearchFirstDate(String field, ABTDate value)      {return lsearchFirst(field, value);}
   public boolean lsearchFirstTime(String field, ABTTime value)      {return lsearchFirst(field, value);}
   public boolean lsearchFirstNull(String field)                     {return lsearchFirst(field, null);}

   public boolean lsearchLastBoolean(String field, boolean value)    {return lsearchLast(field, new ABTBoolean(value));}
   public boolean lsearchLastShort(String field, short value)        {return lsearchLast(field, new ABTShort(value));}
   public boolean lsearchLastInt(String field, int value)            {return lsearchLast(field, new ABTInteger(value));}
   public boolean lsearchLastDouble(String field, double value)      {return lsearchLast(field, new ABTDouble(value));}
   public boolean lsearchLastString(String field, String value)      {return lsearchLast(field, new ABTString(value));}
   public boolean lsearchLastDate(String field, ABTDate value)       {return lsearchLast(field, value);}
   public boolean lsearchLastTime(String field, ABTTime value)       {return lsearchLast(field, value);}
   public boolean lsearchLastNull(String field)                      {return lsearchLast(field, null);}

   public boolean lsearchNextBoolean(String field, boolean value)    {return lsearchNext(field, new ABTBoolean(value));}
   public boolean lsearchNextShort(String field, short value)        {return lsearchNext(field, new ABTShort(value));}
   public boolean lsearchNextInt(String field, int value)            {return lsearchNext(field, new ABTInteger(value));}
   public boolean lsearchNextDouble(String field, double value)      {return lsearchNext(field, new ABTDouble(value));}
   public boolean lsearchNextString(String field, String value)      {return lsearchNext(field, new ABTString(value));}
   public boolean lsearchNextDate(String field, ABTDate value)       {return lsearchNext(field, value);}
   public boolean lsearchNextTime(String field, ABTTime value)       {return lsearchNext(field, value);}
   public boolean lsearchNextNull(String field)                      {return lsearchNext(field, null);}

   public boolean lsearchPrevBoolean(String field, boolean value)    {return lsearchPrev(field, new ABTBoolean(value));}
   public boolean lsearchPrevShort(String field, short value)        {return lsearchPrev(field, new ABTShort(value));}
   public boolean lsearchPrevInt(String field, int value)            {return lsearchPrev(field, new ABTInteger(value));}
   public boolean lsearchPrevDouble(String field, double value)      {return lsearchPrev(field, new ABTDouble(value));}
   public boolean lsearchPrevString(String field, String value)      {return lsearchPrev(field, new ABTString(value));}
   public boolean lsearchPrevDate(String field, ABTDate value)       {return lsearchPrev(field, value);}
   public boolean lsearchPrevTime(String field, ABTTime value)       {return lsearchPrev(field, value);}
   public boolean lsearchPrevNull(String field)                      {return lsearchPrev(field, null);}

   public boolean bsearchFirstBoolean(String field, boolean value)   {return bsearchFirst(field, new ABTBoolean(value));}
   public boolean bsearchFirstShort(String field, short value)       {return bsearchFirst(field, new ABTShort(value));}
   public boolean bsearchFirstInt(String field, int value)           {return bsearchFirst(field, new ABTInteger(value));}
   public boolean bsearchFirstDouble(String field, double value)     {return bsearchFirst(field, new ABTDouble(value));}
   public boolean bsearchFirstString(String field, String value)     {return bsearchFirst(field, new ABTString(value));}
   public boolean bsearchFirstDate(String field, ABTDate value)      {return bsearchFirst(field, value);}
   public boolean bsearchFirstTime(String field, ABTTime value)      {return bsearchFirst(field, value);}
   public boolean bsearchFirstNull(String field)                     {return bsearchFirst(field, null);}

   public boolean bsearchLastBoolean(String field, boolean value)    {return bsearchLast(field, new ABTBoolean(value));}
   public boolean bsearchLastShort(String field, short value)        {return bsearchLast(field, new ABTShort(value));}
   public boolean bsearchLastInt(String field, int value)            {return bsearchLast(field, new ABTInteger(value));}
   public boolean bsearchLastDouble(String field, double value)      {return bsearchLast(field, new ABTDouble(value));}
   public boolean bsearchLastString(String field, String value)      {return bsearchLast(field, new ABTString(value));}
   public boolean bsearchLastDate(String field, ABTDate value)       {return bsearchLast(field, value);}
   public boolean bsearchLastTime(String field, ABTTime value)       {return bsearchLast(field, value);}
   public boolean bsearchLastNull(String field)                      {return bsearchLast(field, null);}

   public boolean bsearchNextBoolean(String field, boolean value)    {return bsearchNext(field, new ABTBoolean(value));}
   public boolean bsearchNextShort(String field, short value)        {return bsearchNext(field, new ABTShort(value));}
   public boolean bsearchNextInt(String field, int value)            {return bsearchNext(field, new ABTInteger(value));}
   public boolean bsearchNextDouble(String field, double value)      {return bsearchNext(field, new ABTDouble(value));}
   public boolean bsearchNextString(String field, String value)      {return bsearchNext(field, new ABTString(value));}
   public boolean bsearchNextDate(String field, ABTDate value)       {return bsearchNext(field, value);}
   public boolean bsearchNextTime(String field, ABTTime value)       {return bsearchNext(field, value);}
   public boolean bsearchNextNull(String field)                      {return bsearchNext(field, null);}

   public boolean bsearchPrevBoolean(String field, boolean value)    {return bsearchPrev(field, new ABTBoolean(value));}
   public boolean bsearchPrevShort(String field, short value)        {return bsearchPrev(field, new ABTShort(value));}
   public boolean bsearchPrevInt(String field, int value)            {return bsearchPrev(field, new ABTInteger(value));}
   public boolean bsearchPrevDouble(String field, double value)      {return bsearchPrev(field, new ABTDouble(value));}
   public boolean bsearchPrevString(String field, String value)      {return bsearchPrev(field, new ABTString(value));}
   public boolean bsearchPrevDate(String field, ABTDate value)       {return bsearchPrev(field, value);}
   public boolean bsearchPrevTime(String field, ABTTime value)       {return bsearchPrev(field, value);}
   public boolean bsearchPrevNull(String field)                      {return bsearchPrev(field, null);}
}