
package com.abtcorp.hub;

/*
 * IABTParserVisitor.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 04-09-98	HJB		getInstanceCount, getObjectType
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;

/**
 *  IABTParserVisitor is the base class allowing common handling of notification of rowchanges
 *  By implementing this interface an object can 'listen' to
 *  any rowchanges
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */

public interface IABTParserVisitor
{

}