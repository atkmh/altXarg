/*
 * CustomEnum.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date          Author       Description
  * 07-27-98      LZX          Initial implementation.
  *
  */

package com.abtcorp.objectModel.abt;

import  com.abtcorp.objectModel.*;
import  com.abtcorp.core.*;
import  com.abtcorp.hub.*;

/**
 * CustomEnum is the object rule class that handles the custom enum business rules.
 *
 *
 * @version	1.0
 * @author      L. Xiao
 */

public class CustomEnum extends SiteRule
{

  /**
   * Default Constructor
   */
   public CustomEnum()
   {
      super();
   }

   /**
   * sets default properties for the methodology custom enum object.
   */
   protected void setDefaultProperties()
   {
      //
      // Relationship Properties
      //
      addProperty( OFD_CUSTOMFIELD, OFD_CUSTOMFIELD_CAP, PROP_OBJECT, false, true, true, false, OBJ_CUSTOMFIELD, FR_DISALLOWRESET, null );

      //
      // CustomEnum Properties
      //
      addProperty( OFD_FIELDID, OFD_FIELDID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_VALUE, OFD_VALUE_CAP, PROP_SHORT, false, true, true, false, null, null, null );

      ABTProperty prop;

      addProperty( OFD_CAPTION, OFD_CAPTION_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(64));

   }

   /**
    * Rules to invoke when a custom enum object is created.
    *<ul>
    *<li>Enforces that the following parameters have been included in requiredParameters:
    *<ul>       OFD_CUSTOMFIELD     (the parent custom field this custom enum belongs to)</ul>
    *<li>Set the OFD_CUSTOMFIELD reference and add this custom enum to its OFD_CUSTOMENUMS list.
    *</ul>
    *
    * @param session             the session object for transaction support
    * @param object              the new object being created
    * @param requiredParameters  hash table containing the required parameters
    *
    * @return ABTValue - Return <code>ABTError</code> that may have been encountered
    *                    while accessing or setting properties.
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTHashtable requiredParameters )
   {
      // set required parameter custom field reference and add this custom enum field object to the custom enum
      // list of the referenced custom field.
      return super.setReqParm( session, object, requiredParameters, OFD_CUSTOMFIELD, OFD_CUSTOMENUMS, "abt.CustomEnum->onInitialize" );
   }

   /**
    * Rules to invoke when a custom enum object is deleted.
    *<ul>
    *<li>Remove it from the OFD_CUSTOMENUMS list of the parent OFD_CUSTOMFIELD object.
    *</ul>
    * @param session    the session object for transaction support
    * @param parent     the object to be removed
    * @return ABTValue  check for ABTError....
    */
   protected ABTValue onDelete( ABTUserSession session, ABTObject parent )
   {
      // Get the custom field and remove from it's custom enum list this custom enum
      ABTValue v = removeFromList( session, parent, OFD_CUSTOMFIELD, OFD_CUSTOMENUMS, "abt.CustomEnum->onDelete" );
      if( ABTError.isError( v ) )
         return v;

      // delete the custom enum object itself
      return deleteObject( session, parent );
   }
}
