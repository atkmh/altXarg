package com.abtcorp.io.team;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_0.getCode(),"Unknown argument type."},
{ERR_1.getCode(),"Exception occurred getting site object."},
{ERR_2.getCode(),"Could not delete timesheet entries."},
{ERR_3.getCode(),"Could not obtain timesheet lock."},
{ERR_4.getCode(),"Project does not allow time tracking."},
{ERR_5.getCode(),"No query provided for delete time entries method."},
{ERR_6.getCode(),"Error during driver execute."},
{ERR_7.getCode(),"Invalid timesheet."},
{ERR_8.getCode(),"Invalid timesheet object set."},
{ERR_9.getCode(),"No arguments passed to driver."},
{ERR_10.getCode(),"Error encountered during populate."},
{ERR_11.getCode(),"No query string passed to driver."},
{ERR_12.getCode(),"No type passed for code populator."},
{ERR_13.getCode(),"Unable to load class."},
{ERR_14.getCode(),"No populator class passed to driver"},
{ERR_15.getCode(),"Project is invalid."},
{ERR_16.getCode(),"Task is invalid."},
{ERR_17.getCode(),"Assignment is invalid."},
{ERR_18.getCode(),"Type code is invalid."},
{ERR_19.getCode(),"Indirect entry has no charge code."},
{ERR_20.getCode(),"Charge code is invalid."},
{ERR_21.getCode(),"Time entry is invalid."},
{ERR_22.getCode(),"Time period closed or does not exist."},
{ERR_23.getCode(),"Resource closed or uses incorrect track mode."},
{ERR_24.getCode(),"Exception occurred processing timesheet."},

 };
}