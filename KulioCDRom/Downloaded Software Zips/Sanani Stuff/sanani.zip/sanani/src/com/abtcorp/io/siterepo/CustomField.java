package com.abtcorp.io.siterepo;

/*
 * CustomField.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 07-16-98    LZX         Initial Implementation
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  CustomField is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTSiteRepoDriver.
 *
 *  <pre>
 *       CustomField rt = new CustomField(driver, site);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTSiteRepoDriver
 */

public class CustomField extends ABTSiteRepoHelper 
{

/**
 *    CustomField constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the parent (site) object that owns the custom fields.
 */
   public CustomField(ABTRepositoryDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_MRCUSTOMFIELD, OBJ_CUSTOMFIELD);
      site_ = parent;
      reqParams_.putItemByString(OFD_SITE, site_);
      matchField_ = OFD_NAME;
   }


/**
 * Update an existing object in the object space with properties from the repository.
 *	@param object: the object to be updated.
 *	@return ABTValue: a reference to the object updated or an ABTError.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue update(ABTCursor cur, ABTObject object, ABTRemoteIDRepository id, boolean updateSpace) throws ABTException
   {
      if (updateSpace)
      {
         // NOTE: temporary code - commit transaction before deleting the child
         // objects since otherwise the object space does not work properly. 
         getUserSession().commitTransaction();
         getUserSession().startTransaction();

         // when updating a custom field, delete the old aggregate field and 
         // custom enum list of this custom field object in the object space.
         // (don't mix old agg fields and custom enums with new ones.)
         deleteList (object, OFD_AGGREGATEFIELDS);
         deleteList (object, OFD_CUSTOMENUMS);     
      }      
      return (super.update(cur, object, id, updateSpace));
   }


/**
 * Populate subordinate objects, set references, etc.. 
 * @param cur  the cursor used to populate.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   protected void populateOthers(ABTCursor custCursor) throws ABTException
   {
   	// populate the custom enums.
   	CustomEnum ceHelper = new CustomEnum(driver_, site_, custCursor);
    	ceHelper.populate(null, QRY_CUSTOMENUMS);

   	// populate the aggregate fields if there is any.
   	AggregateField afHelper = new AggregateField(driver_, site_, custCursor);
    	afHelper.populate(null, QRY_AGGREGATEFIELDS);
   }

/**
 *  Saves the custom field objects back to the repository. This method overrides 
 *  the save() method in super class because saving methods requires special
 *  treatment (saving custom enums, aggregate fields, etc.)
 *	 @param oSet   the custom field object set to be saved back to the repository
 *  @return       the objects set that got saved.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(ABTObjectSet oSet, String query) throws ABTException
	{
	   // first save the custom fields
	   ABTValue val = super.save(oSet, query);
	   
	   // then save the custom enums and aggregate fields
	   saveOthers(oSet);
	   
	   return val;
	}


/**
 *  Saves the subordinate objects (custom enums and aggregate fields).
 *	 @param oSet   the custom field object set to be saved back to the repository
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   private void saveOthers(ABTObjectSet oSet) throws ABTException
   {
   	// loop through all the objects in the object set
      for (int i = 0; i < size(oSet); i++)
      {
         ABTObject obj = (ABTObject)at(oSet, i);
        	long id = getValue(obj, OFD_ID).intValue();

      	// save the custom enums (first clean up the old custom enums)
         String query = QRY_CUSTOMENUMS2 + id;
         ABTCursor cur = getCursor(query, null);
         cur.deleteAll();         
         closeCursor(cur);
      	CustomEnum ceHelper = new CustomEnum(driver_, obj, null);
       	ceHelper.save(obj, OFD_CUSTOMENUMS, query);

      	// save the aggregate fields (first clean up the old aggr fields) 
        	query = QRY_AGGREGATEFIELDS + " where " + 
                        TBL_MRAGGREGATEFIELD + "." + FLD_SOURCEFIELDID + "=" + id + " or " +
                        TBL_MRAGGREGATEFIELD + "." + FLD_TARGETFIELDID + "=" + id;         
         cur = getCursor(query, null);
         cur.deleteAll();         
         closeCursor(cur);
      	AggregateField afHelper = new AggregateField(driver_, obj, null);
       	afHelper.save(obj, OFD_AGGREGATEFIELDS, query);
      }
   }

}