
package com.abtcorp.hub;

/*
 * ABTPropertySet.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 07-20-98   SDP      added countProperties and made countNonVirtualProperties public
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.*;
//import com.objectspace.jgl.Array;
//import com.objectspace.jgl.OrderedSet;
import java.util.Enumeration;
/**
 * PropertySet contains the functionallity needed to manage the list of properties for a BO
 * <p>
 * @see com.abtcorp.core.ABTArray
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.objectspace.jgl.Array
 */
public class ABTPropertySet extends ABTArray implements Cloneable
{
   ABTSortedArray sortedNames = new ABTSortedArray(new ABTPropertyComparator());
   private String lastRequest = null;
   private int lastIndex = 0;
   private ABTRule parentRule;
   private int nonVirtualCount = 0;


   /**
   *  merge another propertyList into mine and update the index references.
   * if no other list is referenced just re-index me.
   */
   protected ABTError extend(ABTPropertySet set_)
   {
      ABTProperty p1,p2;
      int i,j,k;

      ABTArray errorList = null;

      Enumeration it_;
      // if set_ is null then walk through list and set index position
      // sequentailly
      if (set_ == null)
      {
         sortedNames.clear();
         i = 0;
         k = 0;
         it_ = elements();
         while (it_.hasMoreElements())
         {
            ABTProperty prop = ((ABTProperty)(it_.nextElement()));
            if (!(prop.isVirtual()))
                prop.setRowIndex(i++);
            prop.setIndex(k++);
            prop.setRuleSet(parentRule);
            sortedNames.add(prop);
         }
         it_ = null;
         return null;
      }

      i = nonVirtualCount;
      k = size();
      it_ = set_.elements();

      while (it_.hasMoreElements())
      {
         p1 = ((ABTProperty)(it_.nextElement()));
         j = indexOf(p1);
         if (j >= 0) // this property already exists in my list
         {
            // we should create a list of items not being used for further validation
            if (errorList == null)
            {
               errorList = new ABTArray();
            }
            errorList.add(
               new ABTErrorHub("ABTPropertySet->extend",
                               errorMessages.ERR_24,
                               p1
                              )
            );
//            p1.setIndex(((ABTProperty)at(j)).getIndex());
         }
         else
         {
            if (!(p1.isVirtual()))
                p1.setRowIndex(i++);
            p1.setIndex(k++);
            p1.setRuleSet(parentRule);
            add(p1);
            sortedNames.add(p1);
         }
      }
      it_ = null;
      if (errorList != null)
         return new ABTErrorHub("ABTPropertySet->extend",
                               errorMessages.ERR_25,
                               errorList);
      else
         return null;
   }



  /**
   * add a property to my list
   * @param property to be added
   * @return ABTError or null if successfull
   */
   protected ABTError addProperty(ABTProperty prop)
   {
      int j = indexOf(prop);
      if (j >= 0) // this property already exists in my list
      {
            return new ABTErrorHub("ABTPropertySet->extend",
                            errorMessages.ERR_24,
                            prop);
      }
      else
      {
         prop.setRuleSet(parentRule);
         add(prop);
         if (!(prop.isVirtual()))
         {
            prop.setRowIndex(nonVirtualCount);
            nonVirtualCount++;
         }
         prop.setIndex(size()-1);
         sortedNames.add(prop);
      }
      return null;
   }


   /**
   * Default constructor
   * @param rule_ parent rule
   */
	protected ABTPropertySet(ABTRule rule_)
   {
      super();
      parentRule = rule_;
   }


   /**
   * find an index for a property by name
   * @param name of property
   * @return int index or -1 for not found
   */
   public int indexForName(String name)
   {
      int index = -1;
      if ( (lastRequest != null) && (lastRequest.equals(name)))
         return lastIndex;

      try
      {
          int myIndex = sortedNames.indexOf(name);
          if (myIndex < 0 ) // couldn't find it....
             return -1;
          index = ((ABTProperty)sortedNames.at(myIndex)).getIndex();
      }
      catch (Exception e)
      {
        index = -1;
      }
        // couldn't find property
      lastIndex = index;
      lastRequest = name;
      return lastIndex;
   }


   /**
   * return number of non-virtual Properties
   * @return int
   */
   public int countProperties()
   {
      return size();

   }

   /**
   * return number of non-virtual Properties
   * @return int
   */
   public int countNonVirtualProperties()
   {
      return nonVirtualCount;

   }


   /**
   * find a name for a property by index
   * @param  index index of property in set
   * @return name of property or null
   */
   public String nameForIndex(int index)
   {
      if ((index < 0) || (index >= size()))
         return null;
      lastIndex = index;

      lastRequest = ((ABTProperty)at(index)).getName();
      return lastRequest;
   }


   protected void destroy()
   {
      lastRequest = null;
      lastIndex = 0;
      parentRule = null;
      sortedNames.clear();
   }

   public void finalize()
   {
      destroy();
   }
   public String dump(int indent,int level)
   {
      StringBuffer sb = new StringBuffer();


      if (level > 0)
         sb.append(this.getClass() + ":");
      int i = 0;
      Enumeration e = elements();
      while (e.hasMoreElements())
      {
         Object o = e.nextElement();

         if (o instanceof ABTProperty)
            sb.append(com.abtcorp.core.ABTUtil.newLine(indent+1) + i + ((ABTProperty)o).dump(indent+1,level));
         else
            if (o != null)
               sb.append(com.abtcorp.core.ABTUtil.newLine(indent+1) + i + o.toString());
            else
               sb.append(com.abtcorp.core.ABTUtil.newLine(indent) + i + " - null");
         i++;
      }
      return sb.toString();

   }


}