package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;
import com.abtcorp.core.ABTRemoteID;

public class ABTClientMppTasks extends ABTClientMppHelper
{
	private boolean               populateFully_                        = false;
	private boolean               previouslyExisted_                    = false;
	private boolean               forceNewSave_                         = false;
	private ABTRemoteID           remoteId_                             = null;
	private Project               mppProject_                           = null;
	private IABTObject            projectObject_                        = null;
   private MppFormat             utl_                                  = null;
   private Vector                taskWbsVector_                        = null;
   private int                   taskWbsLevel_                         = 0;
   public  Vector                objectsThatHaveBeenUpdated_           = null;
	/**
	*
	*/
	public ABTClientMppTasks() {/* implicit call to super() here */}

	/**
	*    Constructor used by the populate process.
	*/
	public ABTClientMppTasks( IABTObjectSpace       space,
                              ABTClientMppDriver   driver,
                              IABTObject           projectObject,
                              Project              mppProject,
                              boolean              populateFully,
                              MppFormat            format
                              )
	{
		super( space, driver );
		projectObject_    =  projectObject;
		mppProject_       =  mppProject;
		populateFully_    =  populateFully;
      utl_           =  format;
	}

	public ABTClientMppTasks(  IABTObjectSpace      space,
                              ABTClientMppDriver   driver,
                              IABTObject           project,
                              boolean              forceAddNew
                              ) throws ABTException
	{
		super( space, driver );
		projectObject_  = project;
		forceAddNew_    = forceAddNew;
	}

	public boolean previouslyExisted() {return previouslyExisted_;}

	public ABTValue populate() throws ABTException
	{

      taskWbsVector_                   = new Vector();

		ABTValue       createReturnValue = null;
		IABTObject     taskObject        = null;

      Enumeration mppTasksEnumerator = utl_.map_.getMppTasksEnumeration(mppProject_, true);

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch match = (MppOsMatch) mppTasksEnumerator.nextElement();

         createRemoteId(match);

         ABTValue taskAbtValue = find(OBJ_TASK, remoteId_);

         if (!utl_.isFound(taskAbtValue)) {

            // *** ADD

            ABTArray parms = new ABTArray(); parms.add(match);

 	   	   createReturnValue = create(parms);

            checkCreateReturnValue(createReturnValue);

            utl_.map_.complete(match, (IABTObject) createReturnValue, remoteId_);

            setValues(match, (IABTObject) createReturnValue);

         } else {

            // *** UPDATE

            utl_.map_.complete(match, (IABTObject) taskAbtValue, remoteId_);

            setValues(match, (IABTObject) taskAbtValue);
         }

      }

      // *** Delete

      Vector       objectSetTasksInProjectVector = getVectorOfProjectTasksInObjectSpace();

      for (int j = 0; j < objectSetTasksInProjectVector.size(); j++) {

         taskObject = (IABTObject) objectSetTasksInProjectVector.elementAt(j);

         remoteId_ = utl_.getRemoteId(taskObject);

         if (!utl_.map_.hasBeenUpdated(remoteId_, taskObject)) {

            taskObject.delete();

         }

   	}

      return createReturnValue;

   }

	/**
	*    Creates a new task object
	*    @return the newly-created task object
	*    @exception ABTException if an unrecoverable error occurs
	*/

	protected ABTValue create( ABTArray params) throws ABTException
	{

      MppOsMatch match = (MppOsMatch) params.at(0);

      Task mppTask = (Task) match.getMppObject();

      IABTHashTable reqparms = space_.newABTHashTable();

      //by default add this to the Hashtable

      reqparms.putItemByString(OFD_PROJECT, (ABTValue)projectObject_);

      IABTObject parent = getParentObject(mppTask);

      if (parent != null) reqparms.putItemByString(OFD_PARENTTASK, (ABTValue)parent);

      ABTValue object = null;

      object = (ABTValue)createObject(OBJ_TASK,  remoteId_, reqparms);

      taskWbsVector_.addElement(object);

      return object;

	}

	/**
	*    Updates an existing task object
	*    @param parms the existing task object
	*    @return the updated task object
	*    @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue update(ABTArray parms) throws ABTException
	{
		Enumeration e = parms.elements();
		ABTValue object = (ABTValue) e.nextElement();
		if (!populateFully_) return object;

		//    setValues(ps, object);

		return object;
	}

	private void setValues( MppOsMatch match, IABTObject obj ) throws ABTException
	{
      match.setOsObject(obj);  //also to hash map
      match.tagAsUpdated();

      Task task = (Task) match.getMppObject();

      utl_.osSetString   (OFD_NAME,         task.getName(),               obj);
      utl_.osSetTime     (OFD_EARLYSTART,   task.getEarlyStart(),         obj);
      utl_.osSetTime     (OFD_EARLYFINISH,  task.getEarlyFinish(),        obj);
      utl_.osSetTime     (OFD_LATESTART,    task.getLateStart(),          obj);
      utl_.osSetTime     (OFD_LATEFINISH,   task.getLateFinish() ,        obj);
      utl_.osSetPercent  (OFD_PCTCOMPLETE,  task.getPercentComplete(),    obj);
      utl_.osSetPercent  (OFD_PCTEXPENDED,  task.getPercentWorkComplete(),obj);
      utl_.osSetTime     (OFD_BASESTART,    task.getBaselineStart(),      obj);
      utl_.osSetTime     (OFD_BASEFINISH,   task.getBaselineFinish(),     obj);
      utl_.osSetDuration (OFD_DURATION,     task.getDuration(),           obj);
      utl_.osSetDuration (OFD_BASEDURATION, task.getBaselineDuration(),   obj);
      utl_.osSetDuration (OFD_DELAY,        task.getLevelingDelay(),      obj);
      utl_.osSetBoolean  (OFD_ISCRITICAL,   task.getCritical(),           obj);
      utl_.osSetBoolean  (OFD_ISMILESTONE,  task.getMilestone(),          obj);
      utl_.osSetPriority (OFD_PRIORITY,     task.getPriority(),           obj);
      utl_.osSetDuration (OFD_TOTALFLOAT,   task.getTotalSlack(),         obj);
      utl_.osSetInteger  (OFD_WBSSEQUENCE,  task.getID(),                 obj);
      utl_.osSetSummary  (OFD_ISTASK,       task.getSummary(),            obj);
      utl_.osSetBoolean  (OFD_ISUNPLANNED,  false,                        obj);


      //??OFD_ISFIXED, new ABTBoolean( task.GetField( pj) ) );

	}

	// -------------------------------------------------------------------------------
	// save logic begins here.
	// -------------------------------------------------------------------------------

	/**
	*    Saves a Project object to an MPP file
	*    @param parms contains the save parameters for the ABTDispatch invoke() call
	*    @exception ABTException if an unrecoverable error occurs
	*/

	public ABTValue save() throws ABTException
	{

      Enumeration mppTasksEnumerator = utl_.map_.getMppTasksEnumeration(mppProject_, true);

      //******************************** Update ******************************

      ABTValue taskAbtValue;

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch match = (MppOsMatch) mppTasksEnumerator.nextElement();

         Task mppTask = (Task) match.getMppObject();

         createRemoteId(match);

         taskAbtValue = find(OBJ_TASK, remoteId_);

         if (utl_.isFound(taskAbtValue)) {

            IABTObject taskObject = (IABTObject) taskAbtValue;

            getValues(mppTask, taskObject);

            utl_.map_.complete(match, taskObject, remoteId_);

         }

		}

      //******************************** ADD ******************************

      Vector         vectorOfOSTasks = getVectorOfProjectTasksInObjectSpace();

      for (int j = 0; j < vectorOfOSTasks.size(); j++) {

         IABTObject taskObject = (IABTObject) vectorOfOSTasks.elementAt(j);

         remoteId_ = utl_.getRemoteId(taskObject);

         if (!utl_.map_.hasBeenUpdated(remoteId_, taskObject)) {

            Task mppTask = null;

            mppTask = addMppTask(taskObject, vectorOfOSTasks, j);

            MppOsMatch match = new MppOsMatch(mppTask, new ABTInteger(mppTask.getUniqueID()));

            utl_.map_.mppAdd(match);

            getValues((Task)match.getMppObject(), taskObject);

            createRemoteId(match);

            utl_.osSetRemoteId(remoteId_, taskObject); //once added it has a different remote id

            utl_.map_.complete(match, taskObject, remoteId_);

         }

      }

      //******************************** Delete ******************************

      mppTasksEnumerator = utl_.map_.getMppTasksEnumeration(mppProject_, false);

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch match = (MppOsMatch) mppTasksEnumerator.nextElement();

         if (!match.hasItBeenUpdated()) utl_.map_.delete(match);

		}

      utl_.map_.removeToBeDeleted();

      //******************************** Clean Up WBS ******************************

      mppTasksEnumerator = utl_.map_.getMppTasksEnumeration(mppProject_, false);

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch match = (MppOsMatch) mppTasksEnumerator.nextElement();

         match.adjustMppWbs();

		}

      return null;

   }

	/**
	*    adds a task into the msp file. In order to do that, it has to get the id
   *    of the mpp task that IT WILL BE BEFORE. In other words the OLE add function
   *    takes an argument "before" which refers to the task that this will be added
   *    before.
	*    @taskObject the object in the object space that needs to be added to the mpp file
	*    @vectorOfOSTasks a vector of Object space tasks that does not include interproject
   *    dependency tasks
   *    @indexInVector is the index in the vector that the taskObject refers to
   */

   public Task addMppTask(IABTObject taskObject, Vector vectorOfOSTasks, int indexInVector)
   {

      //this is the index that will be used by the add function
      //it will remain 0 if it is the very first task

      int indexToBeUsedForTheAddFunction = 1; //one based

      //has to find the task that is before this task

      int sizeOfOSTasksVector = vectorOfOSTasks.size();

      IABTObject nextTaskObject = null;

      if (sizeOfOSTasksVector < indexInVector)

         //make sure that index+1 is not out of bounds

         nextTaskObject = (IABTObject) vectorOfOSTasks.elementAt(indexInVector + 1);

      if (nextTaskObject instanceof IABTObject) {

         MppOsMatch nextTaskMatch = utl_.map_.getTaskMatch(nextTaskObject);

         if (nextTaskMatch != null) {

            Task nextMppTask = (Task)nextTaskMatch.getMppObject();

            indexToBeUsedForTheAddFunction = nextMppTask.getID();

         } else {

            indexToBeUsedForTheAddFunction = utl_.tasks_.getCount()+1;

         }

      } else {

            //there is no coresponding next task in the mpp file
            //will have to append it to the last one

            indexToBeUsedForTheAddFunction = utl_.tasks_.getCount()+1;

      }

      return utl_.createMppTask(taskObject.getValue(OFD_NAME), new ABTInteger(indexToBeUsedForTheAddFunction));

   }

   //returns a vector of object space tasks that have dummy inter project
   //dependency tasks filtered out
	public Vector getVectorOfProjectTasksInObjectSpace() throws ABTException
   {

      Vector projectTasksInObjectSpaceVector = new Vector();

   	ABTValue v = projectObject_.getValue(OFD_WBSSEQUENCE);

      if (ABTValue.isNull(v)) return projectTasksInObjectSpaceVector; //or throw

	   IABTArray WBSTaskArray_ = (IABTArray) v;

      int size = WBSTaskArray_.size();

      for (int i = 0; i < size; i++) {

         IABTObject taskObject = (IABTObject) WBSTaskArray_.get(i);

         IABTObject taskProject = utl_.osGetObject(taskObject, OFD_PROJECT);

         if (!taskProject.equals(projectObject_)) continue;

   	   projectTasksInObjectSpaceVector.addElement(taskObject);

      }

      return projectTasksInObjectSpaceVector;

   }

   private void getValues(Task mppTask, IABTObject obj) throws ABTException
   {

      utl_.mppSetTaskField(OFD_NAME,        obj, mppTask);
      utl_.mppSetTaskField(OFD_EARLYSTART,  obj, mppTask);
      //      utl_.mppSetTaskField(OFD_EARLYFINISH, obj, mppTask);
      utl_.mppSetTaskField(OFD_LATESTART,   obj, mppTask);
      //      utl_.mppSetTaskField(OFD_LATEFINISH,  obj, mppTask);
      utl_.mppSetTaskField(OFD_PCTCOMPLETE, obj, mppTask);
      utl_.mppSetTaskField(OFD_PCTEXPENDED, obj, mppTask);
      //      utl_.mppSetTaskField(OFD_BASESTART,   obj, mppTask);
      //      utl_.mppSetTaskField(OFD_BASEFINISH,  obj, mppTask);
      utl_.mppSetTaskField(OFD_DURATION,    obj, mppTask);
      utl_.mppSetTaskField(OFD_BASEDURATION,obj, mppTask);
      utl_.mppSetTaskField(OFD_DELAY,       obj, mppTask);
      utl_.mppSetTaskField(OFD_ISCRITICAL,  obj, mppTask);
      utl_.mppSetTaskField(OFD_ISMILESTONE, obj, mppTask);
      utl_.mppSetTaskField(OFD_PRIORITY,    obj, mppTask);
      utl_.mppSetTaskField(OFD_TOTALFLOAT,  obj, mppTask);
      utl_.mppSetTaskField(OFD_WBSSEQUENCE, obj, mppTask);
      utl_.mppSetTaskField(OFD_ISTASK,      obj, mppTask);

   }

	// -------------------------------------------------------------------------------
	// misc functions
	// -------------------------------------------------------------------------------

   private void checkCreateReturnValue(ABTValue createReturnValue) throws ABTException
   {
   	if ( ABTError.isError(createReturnValue))
	      throw new ABTException(((ABTError)createReturnValue).getMessage());
   }

   private void createRemoteId(MppOsMatch match)
   {
      Task mppTask = (Task) match.getMppObject();
      remoteId_ = new   ABTClientMppRemoteID(
                        mppProject_.getFullName(),
						      mppTask.getUniqueID()
                        );
   }

   private IABTObject getParentObject(Task mppTask)
   {

      //the last task info is the key to determine parent

      IABTObject  lastTaskInVector           = null;
      int         lastTaskInVectorWbsLevel   = -1;
      boolean     addTaskToWbsVectorPlease   = false;

      int         mppTaskOutlineLevel        = mppTask.getOutlineLevel();

      IABTObject parent = null;

      if (taskWbsVector_.size() > 0) {

         lastTaskInVector           = (IABTObject) taskWbsVector_.lastElement();
         lastTaskInVectorWbsLevel   = lastTaskInVector.getValue(OFD_WBSLEVEL).intValue();

      }

      //Only  three possiblities exist regarding wbs, indented, same, outdented

      // *******  indented ******************************************

      if (mppTaskOutlineLevel > lastTaskInVectorWbsLevel) {
            //means previous task is it's parent
            if (taskWbsVector_.size() > 0)
               parent = (IABTObject) taskWbsVector_.lastElement();
            addTaskToWbsVectorPlease = true;
      } else if (mppTaskOutlineLevel == lastTaskInVectorWbsLevel) {

      // *******  same level ****************************************

         if (taskWbsVector_.size() > 1) {
            //a task is garaunteed to be parent instead of project
            parent = (IABTObject) taskWbsVector_.elementAt(taskWbsVector_.size() - 2);
            //this will take it's place as the last element
            //the next child can only be it's own, the previous task did
            //not have a child
            taskWbsVector_.removeElement(lastTaskInVector);
            addTaskToWbsVectorPlease = true;
         } else {
            //the project is the parent since there is nothing in wbs vector
            parent = null;
            addTaskToWbsVectorPlease = true;
         }
      } else if (mppTaskOutlineLevel < lastTaskInVectorWbsLevel) {

      // *******  outdented *****************************************

         while (taskWbsVector_.size() > 0) { //since I will be removing again and again

            //remove all elements in vector that are less that or == in wbs
            //if anything is left the last element is the parent

            lastTaskInVectorWbsLevel = ((IABTObject) taskWbsVector_.lastElement()).getValue(OFD_WBSLEVEL).intValue();

            if (mppTaskOutlineLevel  < lastTaskInVectorWbsLevel) {
               taskWbsVector_.removeElement(taskWbsVector_.lastElement());

               //pop it since it is not going to be anyones parent anymore
               //this task is more outdented and can be the parent
               //of any new children

            }

            if (mppTaskOutlineLevel  == lastTaskInVectorWbsLevel) {
               taskWbsVector_.removeElement(taskWbsVector_.lastElement());
               break;
            }

         }

         if (taskWbsVector_.size() > 0) {

            parent = (IABTObject) taskWbsVector_.lastElement();
            addTaskToWbsVectorPlease = true;

         } else {

            //means project is parent again
            addTaskToWbsVectorPlease = true;

         }
      }

      return parent;
    }

}
