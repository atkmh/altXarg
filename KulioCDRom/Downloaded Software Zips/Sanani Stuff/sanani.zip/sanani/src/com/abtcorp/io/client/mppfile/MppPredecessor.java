package com.abtcorp.io.client.mppfile;


//each mpp task may have one or more of these

public class MppPredecessor
{

   public   int      predecessorUniqueId_;
   public   int      type_;
   public   char     operator_;
   public   double   lagOrLead_;
   public   int      percentOrAmount_;

}
