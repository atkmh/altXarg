package com.abtcorp.io.client.methfile;

/*
 * ABTIOMethFileTask.java 10/21/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-21-98    MXA         Initial Implementation
 *
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTMMRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTPropertySet;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;



/**
 *  ABTIOMethFileTask is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOMethFileDriver.
 *
 *  <pre>
 *       ABTIOMethFileTask fr = new ABTIOMethFileTask(driver, parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOMethFileDriver
 */

public class ABTIOMethFileTask extends ABTIOMethFileHelper implements IABTRuleConstants, IABTMMRuleConstants
{
    protected IABTObject taskParent_ = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTIOMethFileTask constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOMethFileTask(ABTIOMethFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_MM_TASK);
      method_ = parent;
   }


/**
 *  Saves the task objects back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving notes)
 *	@param oSet   the resource object set to be saved back to the loal file
 *  @return       the objects set that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObjectSet oSet) throws ABTException
   {
    try
    {
        super.save(oSet);

    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
       return (ABTValue)oSet;
    }


   }


/**
 * Populate the task object.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
  protected ABTValue populate() throws ABTException
  {
    ABTValue        val              = null;
    IABTLocalID     methId           = null;
    IABTArray       methArr          = null;
    IABTObject      methObj          = null;
    IABTPropertySet methPropSet      = null;
    IABTLocalID     firstChildTaslID = null;
    IABTLocalID     lastChildTaslID  = null;
    Object          obj              = null;
    ABTValue        ret              = null;

    methPropSet = getProperties(OBJ_MM_METHOD);
    methId = driver_.getMethodId();
    obj    = null;
    obj    = driver_.intermediateTableGet(methId);

    if (!(obj instanceof IABTArray))
        throw new ABTException(" Wrong type cast Objec Array");
    else
        methArr = (IABTArray)obj;

    obj = null;
    obj =  driver_.lookupTableGet(methId);
    if (obj instanceof IABTObject)
        methObj = (IABTObject) obj;


     val      = null;
     val = getHashValue(methArr, methPropSet, OFD_FIRSTCHILDTASK);
     if ( val instanceof IABTLocalID )
        firstChildTaslID = (IABTLocalID)val;
     else
        throw new ABTException(" Wrong type cast");


     val = null;
     val = getHashValue(methArr, methPropSet, OFD_LASTCHILDTASK);
     if ( val instanceof IABTLocalID )
         lastChildTaslID = (IABTLocalID)val;
     else
        throw new ABTException(" Wrong type cast");


     populateTasks(firstChildTaslID, methObj, null, lastChildTaslID);


    return ret;
   }

/**
 * Create a new Task in the object space and initialize it with appropriate values
 * @param associated task id in the intermediate hash table,the project object,
 *                   the parent object and the parent's last child id.
 * @return ABTValue the newly created task
 * @exception ABTException if an unrecoverable error occurs.
 */

 protected ABTValue populateTasks(IABTLocalID taskID, IABTObject method, IABTObject parent, IABTLocalID  parentLastChildID) throws ABTException
 {
      ABTValue        val              = null;
      IABTArray       taskArr          = null;
      IABTArray       projectArr       = null;
      Object          object           = null;
      IABTLocalID     firstChildTaskID = null;
      IABTLocalID     lastChildTaskID  = null;
      IABTLocalID     nextTaskID       = null;
      IABTObject      curTask          = null;
      IABTPropertySet propSet          = null;

      try
      {
          //Populate the task
          curTask = (IABTObject)populateTask(taskID, method, parent);

          // Get the array of value associated with task
          object = null;
          object = driver_.intermediateTableGet(taskID);
          if (object instanceof IABTArray)
            taskArr = (IABTArray) object;

          //Get the property set associated with the task
          propSet = null;
          propSet = getProperties(type_);

          //Get task's first child task ID
          val = null;
          firstChildTaskID = null;

          val = getHashValue(taskArr, propSet, OFD_FIRSTCHILDTASK);
          if (val instanceof IABTLocalID)
            firstChildTaskID = (IABTLocalID)val;

          //Get task's last child task ID
          val = null;
          lastChildTaskID = null;

          val = getHashValue(taskArr, propSet, OFD_LASTCHILDTASK);
          if (val instanceof IABTLocalID)
            lastChildTaskID = (IABTLocalID)val;

          //Get task's next task ID
          val = null;
          nextTaskID = null;

          val = getHashValue(taskArr, propSet, OFD_NEXTTASK);
          if (val instanceof IABTLocalID)
            nextTaskID = (IABTLocalID)val;



          if ( firstChildTaskID != null )
              populateTasks(firstChildTaskID, method, curTask, lastChildTaskID);


          if ( taskID.equals(lastChildTaskID))
            return (ABTValue)curTask;

          if ( nextTaskID != null)
            populateTasks(nextTaskID, method, parent, lastChildTaskID);
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
    return (ABTValue)curTask;
    }
 }



/**
 * populateTask a new object in the object space and initialize it with appropriate values
 * @param Hashtable parms, the Task ID (in the intermesiate hash table), the project that the task belong to,
 *                         the parent task associated with the task.
 * @return ABTValue the newly created team
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue populateTask(IABTLocalID taskID, IABTObject method, IABTObject parent) throws ABTException
   {
        ABTValue ret = null;
        taskParent_ = parent;
        id_ = taskID;
        ret = super.populate();
        return ret;
   }

 /**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
        reqParams_.putItemByString(OFD_METHOD, (ABTValue)method_);
        if(taskParent_ != null)
            reqParams_.putItemByString(OFD_PARENTTASK, (ABTValue)taskParent_);
        return (super.create(type, id, reqParams_));
   }




 }