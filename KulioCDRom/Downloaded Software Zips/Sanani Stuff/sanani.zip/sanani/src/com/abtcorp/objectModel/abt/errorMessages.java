package com.abtcorp.objectModel.abt;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.objectModel.abt".intern();
public static final ABTErrorCode ERR_ACCESS_DENIED = new ABTErrorCode(Package, "ERR_ACCESS_DENIED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_TYPE = new ABTErrorCode(Package, "ERR_INVALID_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_OPERATION_DENIED = new ABTErrorCode(Package, "ERR_OPERATION_DENIED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_ADD_FAILED = new ABTErrorCode(Package, "ERR_ADD_FAILED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_VALUE_HAS_BEEN_SET = new ABTErrorCode(Package, "ERR_VALUE_HAS_BEEN_SET", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NULL_VALUE = new ABTErrorCode(Package, "ERR_NULL_VALUE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INTEGRITY_ERROR = new ABTErrorCode(Package, "ERR_INTEGRITY_ERROR", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_MISSING_REQ_PARM = new ABTErrorCode(Package, "ERR_MISSING_REQ_PARM", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_PROPERTY = new ABTErrorCode(Package, "ERR_INVALID_PROPERTY", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_OBJECT_ALREADY_EXISTS = new ABTErrorCode(Package, "ERR_OBJECT_ALREADY_EXISTS", UNRECOVERABLE_ERROR );

}