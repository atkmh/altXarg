package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;

import com.abtcorp.blob.ABTCalendar;

public class ABTClientMppDependencies extends ABTClientMppHelper implements MppFormatConstants
{
	private boolean                         populateFully_            = false;
	private boolean                         previouslyExisted_        = false;
	private boolean                         forceNewSave_             = false;
	private ABTClientMppDependencyRemoteID  remoteId_                 = null;
	private Project                         mppProject_               = null;
	private IABTObject                      projectObject_		      = null;
   private ABTClientMppTasks               abtClientMppTasks_        = null;
   private MppFormat                       utl_                      = null;
   private int                             ObjectSpaceHoursPerDay_   = 8;

	public ABTClientMppDependencies() {/* implicit call to super() here */}

	/**
	*    Constructor used by the populate process.
	*/
	public ABTClientMppDependencies(
                              IABTObjectSpace space,
                              ABTClientMppDriver  driver,
                              IABTObject          projectObject,
                              Project             mppProject,
                              boolean             populateFully,
                              ABTClientMppTasks   abtClientMppTasks,
                              MppFormat           format
                              )
	{
		super(space, driver);
		projectObject_          =  projectObject;
		mppProject_             =  mppProject;
		populateFully_          =  populateFully;
      abtClientMppTasks_      =  abtClientMppTasks;
      utl_                    =  format;
	}

	public ABTClientMppDependencies(
                              IABTObjectSpace space,
                              ABTClientMppDriver  driver,
                              IABTObject          projectObject,
                              Project             mppProject,
                              ABTClientMppTasks   abtClientMppTasks,
                              MppFormat           format
                              )
	{
		super( space, driver );
		projectObject_          =  projectObject;
		mppProject_             =  mppProject;
      abtClientMppTasks_      =  abtClientMppTasks;
      utl_                    =  format;
	}

	public boolean previouslyExisted() {return previouslyExisted_;}

   //   Pattern is:
   //   iterate match objects, task or resource or assigment or dependency
   //   once you have a valid object/objects go through these 4 steps
   //   1.createRemoteId
   //   2.createReturnValue = create(parms); with it's params
   //   3.checkCreateReturnValue(createReturnValue) and throw abterror if necessary
   //   4.setValues();

	public ABTValue populate() throws ABTException
	{

		ABTValue    createReturnValue = null;

      utl_.setLabelDisplayDefaults(mppProject_);

      Enumeration mppDependenciesEnum = getMppDependenciesEnumeration(mppProject_);

      while (mppDependenciesEnum.hasMoreElements()) {

         MppOsDependencyMatch match = (MppOsDependencyMatch) mppDependenciesEnum.nextElement();

         createRemoteId(match);

         ABTArray params = new ABTArray(); params.add(match);

         createReturnValue = create(params);

         checkCreateReturnValue(createReturnValue);

 		   setValues(match, (IABTObject)createReturnValue);

         match.tagAsUpdated();

      }

      utl_.setLabelDisplayDefaultsToOriginal(mppProject_);

      return createReturnValue;
	}

	/**
	*    Creates a new project object
	*    @return the newly-created Project object
	*    @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue create(ABTArray params) throws ABTException
	{

      MppOsDependencyMatch match = (MppOsDependencyMatch) params.at(0);

      Task              mppTask              = match.getMppDependency().successorMppTask_;
      IABTObject        successorTaskObject  = match.getOsSuccessor();
      IABTObject        precessorTaskObject  = match.getOsPredecessor();
      MppDependency     mppDependency        = match.getMppDependency();

      ABTInteger depType      = new ABTInteger  (mppDependency.getType());
      ABTInteger amountType   = new ABTInteger  (mppDependency.getPercentOrAmount());
      ABTDouble  amount       = new ABTDouble   (mppDependency.getLagOrLead());

      IABTHashTable reqparms = space_.newABTHashTable();

      reqparms.putItemByString(OFD_PREDTASK,  (ABTValue)precessorTaskObject);
      reqparms.putItemByString(OFD_SUCCTASK,  (ABTValue)successorTaskObject);
      reqparms.putItemByString(OFD_TYPE,      (ABTValue)depType);

		if (amountType.intValue() == PR_DAILY_DEPENDENCY
         || amountType.intValue() == PR_PERCENT_DEPENDENCY)
         reqparms.putItemByString(OFD_AMOUNTTYPE, (ABTValue)amountType);

      if (amountType.intValue() == PR_DAILY_DEPENDENCY) {
         double objectSpacehoursPerDay = getObjectSpaceHoursPerDay();
         ABTDouble amountOfLagInDays = new ABTDouble(mppDependency.getLagOrLead() / objectSpacehoursPerDay);
			reqparms.putItemByString(OFD_AMOUNT, (ABTValue) amountOfLagInDays);
      }

      if (amountType.intValue() == PR_PERCENT_DEPENDENCY)
         reqparms.putItemByString(OFD_AMOUNT, amount);

      return (ABTValue)createObject(OBJ_DEPENDENCY, remoteId_, reqparms);

   }


	/**
	*    Updates an existing Project object
	*    @param parms the existing Project object
	*    @return the updated Project object
	*    @exception ABTException if an unrecoverable error occurs
	*/
	protected ABTValue update(ABTArray parms) throws ABTException
	{
		Enumeration e = parms.elements();
		ABTValue object = (ABTValue) e.nextElement();
		if (!populateFully_) return object;

		//    setValues(ps, object);

		return object;
	}

	private void setValues(MppOsDependencyMatch match, IABTObject obj) throws ABTException
	{
      MppDependency  mppDependency =  match.getMppDependency();
	}

	// -------------------------------------------------------------------------------
	// save logic begins here.
	// -------------------------------------------------------------------------------


   public Enumeration getMppDependenciesEnumeration(Project mppProject)
   {

      Enumeration mppTasksEnumerator = utl_.map_.getMppTasksEnumeration(mppProject, false);

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch taskMatch = (MppOsMatch) mppTasksEnumerator.nextElement();

         Task mppTask = (Task) taskMatch.getMppObject();

         createAndAddMppDependenciesToVector(taskMatch);
      }

     return utl_.map_.getDependenciesEnumerator();

   }

	/**
	*    Saves a Project object to an MPP file
	*    @param parms contains the save parameters for the ABTDispatch invoke() call
	*    @exception ABTException if an unrecoverable error occurs
	*/

	public ABTValue save() throws ABTException
	{

      IABTObjectSet taskObjectSet = utl_.osGetObjectSet(projectObject_, OFD_ALLTASKS);

      for (int j = 0; j < taskObjectSet.size(); j++) {

         IABTObject     successorTaskObject        = (IABTObject) taskObjectSet.at(j);

         MppOsMatch     successorMatch             = utl_.map_.getTaskMatch(successorTaskObject);

         IABTObjectSet  dependencyObjectSet        = utl_.osGetObjectSet(successorTaskObject, OFD_PREDDEPENDENCIES);

         String         UniqueIDPredecessorsString = new String("");

         for (int d = 0; d < dependencyObjectSet.size(); d++) {

            if (UniqueIDPredecessorsString.length() > 0) UniqueIDPredecessorsString = UniqueIDPredecessorsString + ",";

            IABTObject dependencyObject       = (IABTObject) dependencyObjectSet.at(d);

            IABTObject predecessorTaskObject  =  utl_.osGetObject(dependencyObject, OFD_PREDTASK);

            MppOsMatch predecessorMatch       =  utl_.map_.getTaskMatch(predecessorTaskObject);

            int        predecessorUniqueId    =  ((Task)predecessorMatch.getMppObject()).getUniqueID();

            UniqueIDPredecessorsString        =  UniqueIDPredecessorsString +

                           convertDependencyToString( //dummy amounts
                                            predecessorUniqueId,
                                            PR_FIN_START_DEP,
                                            PR_DAILY_DEPENDENCY,
                                            0
                                            );


            createRemoteId(successorMatch.getMppKeyAbtValue().intValue(),
                           predecessorUniqueId
                          );

            utl_.osSetRemoteId(remoteId_, dependencyObject);

        }

        ((Task)successorMatch.getMppObject()).setUniqueIDPredecessors(UniqueIDPredecessorsString);

   }

      return null;
   }


   public String        convertDependencyToString(
                           int   predecessorUniqueId,
                           int   dependencyType,
                           int   percentOrAmount,
                           int   lagOrLead
                           )

   {

   	String        compositeString = new String("");

   	compositeString = Integer.toString(predecessorUniqueId);

   	compositeString = compositeString + convertDepencencyTypeShortToString(dependencyType);

   	if (percentOrAmount == PR_DAILY_DEPENDENCY) {
	   	if (lagOrLead > 0)
		   	compositeString = compositeString + new String("+") + convertTimeQuantityToString(lagOrLead / utl_.defaultHoursPerDay_, DAYS);
   		if (lagOrLead < 0)
	   		compositeString = compositeString + convertTimeQuantityToString(lagOrLead / utl_.defaultHoursPerDay_, DAYS);
   	}
   	if (percentOrAmount == PR_PERCENT_DEPENDENCY) {
	   	if (lagOrLead > 0)
		   	compositeString = compositeString + new String("+") + Double.toString(lagOrLead);
   		if (lagOrLead < 0)
	   		compositeString = compositeString + Double.toString(lagOrLead);
   	}
   	return compositeString;
   }

   public String convertTimeQuantityToString(double a, int b)
   {
      return new String("");
   }

   String        convertDepencencyTypeShortToString(int dependencyType)
   {

      switch (dependencyType) {

      	case PR_FIN_START_DEP: 	   return new String("FS");
      	case PR_START_START_DEP: 	return new String("SS");
   	   case PR_FIN_FIN_DEP:    	return new String("FF");
      	case PR_START_FIN_DEP:   	return new String("SF");

      }

   	return new String("FS");
   }


   private void getValues(Task mppTask, IABTObject obj) throws ABTException
   {


   }

	public boolean isException(String prapiName, IABTObject obj, long prapiFlags, boolean isNew) throws ABTException
	{
		boolean ret = false;       // assume NO exception
		return ret;
	}

	// -------------------------------------------------------------------------------
	// misc functions
	// -------------------------------------------------------------------------------

   private void checkCreateReturnValue(ABTValue createReturnValue) throws ABTException
   {
   	if ( ABTError.isError(createReturnValue))
	      throw new ABTException(((ABTError)createReturnValue).getMessage());
   }

   private void createRemoteId(   int successorUniqueId,
                                  int predecessorUniqueId
                              )
   {

      remoteId_ = new ABTClientMppDependencyRemoteID (
                                                      mppProject_.getName(),
                                                      successorUniqueId,
                                                      predecessorUniqueId
                                                     );
   }

   private void createRemoteId(MppOsDependencyMatch match)
   {
      MppDependency  mppDependency        =  match.getMppDependency();
      int            successorUniqueId    =  mppDependency.getSuccessorUniqueId();
      int            predecessorUniqueId  =  mppDependency.getPredecessorUniqueId();

      remoteId_ = new ABTClientMppDependencyRemoteID (
                                                      mppProject_.getName(),
                                                      successorUniqueId,
                                                      predecessorUniqueId
                                                     );
   }

   private IABTObject getPredecessorTaskObject(MppOsDependencyMatch dependencyMatch)
   {

      int predecessorUniqueId = dependencyMatch.getMppDependency().getPredecessorUniqueId();

      MppOsMatch predecessorTaskMatch = utl_.map_.getTaskMatch(predecessorUniqueId);

      dependencyMatch.setPredecessorMatch(predecessorTaskMatch);

      return dependencyMatch.getOsPredecessor();

   }

   private void createAndAddMppDependenciesToVector(MppOsMatch taskMatch)
   {

      Task mppTask = (Task) taskMatch.getMppObject();

 	   if (mppTask.getUniqueIDPredecessors().length() > 0) {

         String uniqueIdPredecessors = mppTask.getUniqueIDPredecessors();

         Vector uniqueIDPredecessorList = utl_.fillUniqueIDPredecessorsListFromString(uniqueIdPredecessors);

  		   for (int j = 0; j < uniqueIDPredecessorList.size(); j++) {

            MppPredecessor mppPredecessor = utl_.convertStringToMppPredecessor((String)uniqueIDPredecessorList.elementAt(j));

		      if (mppPredecessor != null && mppPredecessor.predecessorUniqueId_ != -1) {

               MppDependency mppDependency = new MppDependency(mppTask, mppPredecessor);
               MppOsDependencyMatch match =  new MppOsDependencyMatch(taskMatch, mppDependency);

               getPredecessorTaskObject(match);

               utl_.map_.mppAdd(match);

            }
		   }
  	   }
   }

   private double getObjectSpaceHoursPerDay()
   {

      double returnValueHoursPerDay = 0;

      ABTValue    siteAbtValue   = driver_.getSite(getSpace());
      IABTObject  siteObject     = (IABTObject) siteAbtValue;

		if (siteObject instanceof IABTObject) {

         try {

            ABTValue calendarAbtValue  = siteObject.getValue(OFD_CALENDAR);
            if (ABTError.isError(calendarAbtValue))
               throw new ABTException(((ABTError)calendarAbtValue).getMessage());
            ABTCalendar calendar = (ABTCalendar)calendarAbtValue;;
            returnValueHoursPerDay  = calendar.getHoursPerDay();

         } catch(ABTException e) {
            return 8;
         }
      }
      return returnValueHoursPerDay;
   }
}


