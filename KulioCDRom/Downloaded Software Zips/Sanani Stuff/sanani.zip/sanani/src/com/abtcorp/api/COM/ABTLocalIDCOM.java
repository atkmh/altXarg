package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.ms.com.Variant;

public class ABTLocalIDCOM implements IABTLocalIDCOM
   {
   public ABTLocalIDCOM(IABTLocalID id)
      {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(id);
      /**/
      }
   // aggregated ABTBaseJavaCOM access wrapper
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private IABTLocalID _id;
   private IABTLocalID id() {
      if (_id == null) _id = (IABTLocalID)getObject();
      return _id;
      }


   public IABTErrorCOM setRemote(IABTRemoteIDCOM id){
      ABTRemoteID rid = (ABTRemoteID)id.getObject();
      ABTError er = id().setRemote(rid);
      if (er == null) return null;
      return new ABTErrorCOM(er);
      }

   public void setOriginal(IABTRemoteIDCOM id){
      ABTRemoteID rid = (ABTRemoteID)id.getObject();
      id().setOriginal(rid);
      }

   public int getLocal(){
      return id().getLocal();
      }

   public Variant getRemote(){
      return  VariantMunger.ValueToVariant(id().getRemote());
      }

   public Variant getOriginal(){
      return  VariantMunger.ValueToVariant(id().getOriginal());
      }

   public boolean equals (IABTLocalIDCOM object){
      IABTLocalID lid = (IABTLocalID)object.getObject();
      return id().equals(lid);
      }

   public int compareTo  (IABTLocalIDCOM object)
   {
      if (object == null) return 1;

      IABTLocalID lid = (IABTLocalID)object.getObject();
      return id().compareTo(lid);
      }

   }