package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTRemoteID;

public interface ObjectData
{
   public Hashtable getValues();
   public ABTValue getID();
   public ABTRemoteID getRemoteID();
}