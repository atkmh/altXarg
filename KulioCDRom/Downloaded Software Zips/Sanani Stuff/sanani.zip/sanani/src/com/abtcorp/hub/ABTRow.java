
package com.abtcorp.hub;

/*
 * ABTRow.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;

import java.util.Enumeration;
//import java.util.Observable;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



/**
 * Row carries the physical data row for the Business Objects
 * and implements ABTSet
 * <p>
 * @see com.abtcorp.core.ABTArray
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTRow implements ABTComparable,IABTTransactionInstance, IABTDestroyableObject
{
   ABTTransactionContainer data;
   ABTID my_id;
   ABTRowSet myParent;
   ABTObject myObject;

   ABTRowLookup  my_lookup = null;


   protected final void destroy_me()
   {
     ABTFunctionParameter par = new ABTFunctionParameter(this,null,myObject.getObjectSpace());
     if (my_lookup != null)
        my_lookup.setRow(null);
     myObject.getObjectSpace().addDestroyThread(par);
     return;

   }
   /**
   * remove all pending references
   */
	public synchronized void destroy()
	{
/*          ABTValue val1 = (ABTValue)data.at(1); // remote ID
          if ((val1 != null) && (val1 instanceof ABTRemoteID))
          {
    	  System.out.println("Delete " + ((ABTRemoteID)val1).toString());
    	  }
    	  else
    	  System.out.println("Delete unknown RemoteID");
  */

/*      try
      {
          ABTValue val = (ABTValue)data.at(1); // remote ID
          if ((val != null) && (val instanceof ABTRemoteID))
          {
            myParent.removeRemoteID((ABTRemoteID)val);
            myObject.setRemoteID((ABTRemoteID)val);
          }
      }
      catch (Exception e)
      {
        //whoops, don't worry....
      }

  	   if (virtualData != null)
      {
  	      virtualData.clear();
  	      virtualData = null;
      }
*/  	   myParent = null;
      if (myObject != null)
      {
         myObject.destroy();
         myObject = null;
      }
      if (data != null)
      {
//  	      data.clear();
  	      data = null;
      }
  	   my_id = null;
	}

   /**
   * remove all pending references
   */
   public void finalize()
   {
      destroy();
   		//{{CLEANUP
		//}}
}



   public String dump(int indent,int level)
   {
        return "not implemented";//data.dump(indent,level);
   }
   public ABTUserSession getLockHolder()
   {
     if (data != null)
        return data.getLockHolder();
     else return null;   
   }



   public synchronized boolean lock(ABTUserSession requestor)
   {
     if (data != null)
         return data.lock(requestor);
     else return false;    
   }

   public synchronized void removeOnelock(ABTUserSession requestor)
   {
    if (data != null)

        data.removeOnelock(requestor);
   }

    private ABTRowData getActive(ABTUserSession session,boolean create)
    {
           if (data != null)
            return (ABTRowData)data.getActive(session,create);
           else return null; 
    }

   public synchronized boolean unLock(ABTUserSession requestor)
   {
    if (data != null)

        return data.unLock(requestor);
    else return false;    
   }

   public void rollback(ABTUserSession session)
   {
    if (data != null)

        data.rollback(session);
   }

   protected void commitAll(ABTUserSession session,boolean recall)
   {
         if (data != null)
            data.commitAll(session,recall);

   }
   public void commit(ABTUserSession session)
   {
         if (data != null)
            data.commit(session);
   }


   protected synchronized Object at(ABTUserSession session, int index)
   {
      ABTRowData ar = getActive(session,false);
      if (ar != null) 
            return ar.at(index);
     else return null;       
   }

   /**
   *  default constructor
   */
   protected ABTRow(ABTRowSet parent_,ABTID id)
   {
      data = new ABTTransactionContainer(this,ABTTransactionContainer.SINGLE,new ABTRowData());
      myParent= parent_;
      my_id = id;
   		//{{INIT_CONTROLS
		//}}
}

   protected ABTRule getRule()
   {
    return myParent.getRule();
   }
   protected ABTObject getObject()
   {
    return myObject;
   }
   protected void setObject(ABTObject object)
   {
    myObject = object;
   }


   /**
   * check whether deleted-flag is set
   */
   protected boolean isDeleted(ABTUserSession session)
   {
      ABTRowData ar = getActive(session,false);
      if (ar == null) return true;
      ABTValue val = (ABTValue)ar.at(0);
      if (
            (!(ABTValue.isNull(val)))
             &&
            (((ABTValue)val).booleanValue())
          )
        return true;;
      return false;
   }

   /**
   * set deleted
   */
   protected ABTError delete(ABTUserSession session)
   {
      ABTValue val = setValue(session,0,-1,null,ABTBoolean.True());
      if (ABTError.isError(val)) return (ABTError)val;
      myParent.remove(session,this);
      return null;
   }

   /**
   * set deleted
   */
   protected ABTError unDelete(ABTUserSession session)
   {
      /*
         setField makes sure that if you set a property with a reference to another row/rowset,
         it updates the reference information for that row correctly

      */
      int i;

      if (! lock(session))
        return new ABTErrorHub("ABTRow->unDelete",errorMessages.ERR_10,this);

      ABTRowData ar = getActive(session,true);
      ar.put(0,ABTBoolean.False());
      ABTValue val = null;
      try
      {
         val = (ABTValue)ar.at(1);
      }
      catch (Exception e)
      {
      }

      myParent.undelete(session,this,val);
      return null;
   }



   /**
   *  return the ABTID of this row
   *  @return ABTID id of this row
   */
   public ABTID getID()
   {
      return my_id;
   }



  /**
   * Return true if I'm equal to another object.
   * @param object The object to compare myself against.
   */
   public boolean  equals  (Object  object)
   {
      if (object instanceof ABTRow)
         return my_id.equals(((ABTRow)object).getID());
      if (object instanceof ABTID)
         return my_id.equals(((ABTID)object));

      return false;
   }

  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compareTo  (Object  object)
   {
      if (object == null) return 1;
      if (object instanceof ABTRow)
         return my_id.compareTo(((ABTRow)object).getID());
      if (object instanceof ABTID)
         return my_id.compareTo(((ABTID)object));

      return 1;
   }


	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */
	public int hashCode()
	{
		return my_id.hashCode();
	}



   /**
   * Get the value for a the parameter with a given name
   * @param parameterIndex index of parameter to be accessed in parameter list
   * @param parametername namoe of parameter to be accessed in parameter list
   * @return Object - success / null
   */
  protected synchronized ABTValue getValue (ABTUserSession session, int parameterIndex_)
  {

      ABTRowData ar = getActive(session,false);
      if (ar == null) 
         return new ABTErrorHub("ABTRow->getValue",errorMessages.ERR_26, "object deleted");
      if  (( parameterIndex_ < 0) ||
         ( parameterIndex_ >= myParent.numberOfProperties())
         )
         return new ABTErrorHub("ABTRow->getValue",errorMessages.ERR_26, new ABTInteger(parameterIndex_));
      if (parameterIndex_ >= ar.size())
         return ABTEmpty.getEmpty();

      ABTValue val = (ABTValue)ar.at(parameterIndex_);
      if (val != null)
         return val.eval();
      return  null;
  }
   /**
   * Set the value for a the parameter with a given name
   * @param object Caller
   * @param parameterIndex index of parameter to be accessed in parameter list
   * @param parametername name of parameter to be accessed in parameter list
   * @param value - new value
   * @return ABTValue - sets the value and returns the new one
   */
   protected ABTValue setValue (ABTUserSession session,int parameterIndex_,int lookupIndex_,ABTProperty property,ABTValue value_)
   {
      /*
         setField makes sure that if you set a property with a reference to another row/rowset,
         it updates the reference information for that row correctly

      */
      int i;

      if (! lock(session))
        return new ABTErrorHub("ABTRow->setValue",errorMessages.ERR_10,this);

      if ((parameterIndex_ >= 0) && (myParent.numberOfProperties() < parameterIndex_   ))
      {
        removeOnelock(session);
         return new ABTErrorHub("ABTRow->setValue",errorMessages.ERR_26,new ABTInteger(parameterIndex_));
      }


      ABTRowData ar = getActive(session,true);
      if (ar == null) 
         return new ABTErrorHub("ABTRow->setValue",errorMessages.ERR_26, "object deleted");

//      i = size();
      if (parameterIndex_ >= ar.size())
      {
         //extend the array to fit values
         // check the dictionary first whether this is a valid index....
         i = ar.size()-1;
         while (i++ <= parameterIndex_)
            ar.add(ABTEmpty.getEmpty());
      }
      if (lookupIndex_ > -1)
      {
         myParent.setIndex(session,this,parameterIndex_,lookupIndex_,(ABTValue)ar.at(parameterIndex_),value_);
      }
      if (!(ABTValue.isNull(value_)))
         ar.put(parameterIndex_,value_.eval());
      else
         ar.put(parameterIndex_,value_);
      return value_;
   }




	//{{DECLARE_CONTROLS
	//}}
}

