
package com.abtcorp.core;

/***
 * A class that implements a simple locking mechanism.
 *
 * A lock can be set in exclusive mode or non-exclusive mode. The default
 * setting of the lock is non-exclusive. The thread can wait for the lock to become available
 * or return immediately with an indication that the lock was not set.
 *
 * A single thread can set the lock more than once in non-exclusive mode, however, a single
 * thread cannot set the lock more than once in exclusive mode. If a thread has set the lock
 * more than once, it is that thread's responsibility to call release() as many times as it called
 * set() to ensure the reference count of the lock is decremented properly.
 *
 */
public class ABTLock {
   /***
    * Indicator for no timeout on the wait for the lock's availability.
    */
   public static final long FOREVER = -1;
   /***
    * Setting for a non-exclusive lock.
    */
   public static final int NONEXCLUSIVE = 0;
   /***
    * Setting for the exclusive lock.
    */
   public static final int EXCLUSIVE = 1;
   /***
    * A reference count for the number of threads having set this lock.
    */
   private int refcnt_;
   /***
    * Indicator as to whether this lock is held exclusively or not.
    */
   private int lockMode_;
   /***
    * The thread object that currently holds this lock in exclusive mode.
    */
   private Runnable exclusiveHolder_;
   /***
    * Count of threads wishing to place an exclusive lock on an object.
    */
   private int exclusiveCount_;

   /***
    * Creates a ABTLock.
    */
   public ABTLock() {
      refcnt_ = 0;
      exclusiveCount_ = 0;
      lockMode_ = 0;
      exclusiveHolder_ = null;
   }

   /***
    * Releases the lock.
    * This decrements the lock's reference count and calls notify to alert
    * any waiting threads that the lock has been released. If the lock is in exclusive mode, only the
    * the thread that set the exclusive lock can release the lock.
    */
   public synchronized void release() {

      if (refcnt_ == 0) {
         notifyAll();
         return;  // Don't let the reference count go negative!
      }

      if (lockMode_ != EXCLUSIVE) {
         decrement(); // Decrement reference count.
         notifyAll(); // Notify all threads wanting the lock.
      } else {
         if(exclusiveHolder_ == Thread.currentThread()) {
            decrement();
            notifyAll();        // Notify other threads that may want locks.
         }
      }
   }

   /***
    * Requests the lock in non-exclusive mode.
    * The thread will not wait for the lock to become available.
    * @return boolean - True = the lock was successfully set; false = the lock was not set.
    */
   public synchronized boolean set() {
      return doSet(NONEXCLUSIVE,0);
   }

   /***
    * Requests the lock.
    * If the mode is EXCLUSIVE The thread will wait for timeout milliseconds for the lock to become available.
    * If the lock is not available when the time expires the method will return false;
    * @param mode The mode to set the lock.
    * @param timeout The amount of time to wait for the lock to become available.
    * @return boolean - True = the lock was successfully set; false = the lock was not set.
    */
   public synchronized boolean set(int mode,long timeout) {
      return doSet(mode,timeout);
   }

   /***
    * Requests the lock.
    * If mode is NONEXCLUSVE the thread will not wait for the lock to become available.
    * If mode is EXCLUSIVE the thread will wait indefinitely for the lock to becomde available.
    * @param mode The mode to set the lock. It can be either EXCLUSIVE or NONEXCLUSIVE.
    * @return boolean - True = the lock was successfully set; false = the lock was not set.
    */
   public synchronized boolean set(int mode) {
      if(mode == EXCLUSIVE) {
         return doSet(mode,FOREVER);
      } else {
         return doSet(mode,0);
      }
   }

   /***
    * Requests the lock.
    * The lock will be requested in non-exclusive mode.
    * @param timeout Time to wait in milliseconds for the lock to become available.
    */
   public synchronized boolean set(long timeout) {
      return doSet(NONEXCLUSIVE,timeout);
   }

   /***
    * Requests the lock on behalf of a thread.
    * @param mode The mode the lock is to be set. The mode can be one of EXCLUSVE or NONEXCLUSIVE.
    * @param timeout The amount of time the thread will wait for the lock to become available.
    *                If the thread passes FOREVER the thread will block until the lock becomes available.
    * @return boolean - True = the lock was successfully set; false = the lock was not set.
    */
   private boolean doSet(int mode,long timeout) {
      boolean locked = false;

      // The lock has been set in exclusive mode.
      if (isExclusive()) {
         if (exclusiveHolder_ != null && exclusiveHolder_ == Thread.currentThread()) {
            locked = true; // Ok, if this thread is the one who has the exclusive control.
         } else {
            locked = lockit(mode,timeout);
         }
      } else {
         locked = lockit(mode,timeout);
      }

      if(locked) {
         increment(mode);
      } else {
         System.out.println("Failed to set lock for " + this);
      }

      return locked;
   }

   /***
    * Checks if this lock is in exclusive mode or not.
    * @return boolean - True = the lock is in exclusive mode; false = the lock is not.
    */
   public synchronized boolean isExclusive() {
      if (lockMode_ == EXCLUSIVE) return true;
      return false;
   }

   /***
    * Returns the number of threads waiting for exclusive control of this lock.
    * @return int - The number of threads waiting for exclusive control of this lock.
    */
   public synchronized int getExclusiveCount() {
      return exclusiveCount_;
   }

   /***
    * Sets the lock.
    * @param mode The mode to set the lock. The mode can be EXCLUSIVE or NONEXCLUSIVE. The default is NONEXCLUSIVE.
    * @param timeout The amount of time in milliseconds to wait before the lock is available.
    * @return boolean - Whether the lock was successfully set or not.
    */
   private boolean lockit(int mode,long timeout) {
      boolean locked = false;

      if (mode == EXCLUSIVE) {
         // Someone's got the lock and thread doesn't want to block.
         if(!isAvailable(mode) && timeout == 0) return false;

         exclusiveCount_++;     // This thread wants an exclusive lock
         doWait(timeout,mode);
         exclusiveCount_--;     // Thread no longer wants an exclusive lock

         locked = isAvailable(mode);

      } else {
         if (isAvailable(mode)) { // Let others in as long as someone doesn't want an exclusive lock.
            locked = true;
         } else {
            if(timeout != 0) {
               doWait(timeout,mode);
               locked = isAvailable(mode);
            }
         }
      }

      return locked;
   }

   public synchronized String toString() {
      String string = new String("ABTLock: refcnt_ = " + refcnt_ + " exclusiveCount_ = " + exclusiveCount_ + " lockMode_ = " + lockMode_);
      return string;
   }

   /***
    * Blocks the thread for the specified time.
    * @param timeout The number of milliseconds to wait. If this value is FOREVER, the thread blocks until the lock is available.
    * @param mode The mode the thread wants the lock to be set in.
    */
   private void doWait(long timeout,int mode) {
      long start = System.currentTimeMillis();

      while(!isAvailable(mode)) {
         try {
            if(timeout != FOREVER) {
               wait(timeout);
            } else {
               wait();
            }
         } catch (Exception e) {
         }

         if(timeout > 0 && refcnt_ > 0) { // See if the timeout expired or we were notified.
            long end = System.currentTimeMillis();
            if((end - start) > timeout) {
               break;
            } else {
               timeout = end - start;
            }
         }
      } // while
   }

   /***
    * Checks the availablility of the lock.
    * @param mode The mode that the thread wants to set the lock in.
    * @return boolean - True = the lock is available to the thread; false the lock is not available.
    */
   public synchronized boolean isAvailable(int mode) {
      boolean available = false;

      if(mode == EXCLUSIVE) {

        if(refcnt_ == 0) available = true;

      } else {

        if(lockMode_ != EXCLUSIVE && exclusiveCount_ == 0) available = true;

      }

      return available;
   }

   /***
    * Increments the reference count for the lock indicating that a thread has it.
    * @param mode The mode to set the lock.
    */
   private void increment(int mode) {
      refcnt_++;
      lockMode_ = mode;
      if(mode == EXCLUSIVE) {
         exclusiveHolder_ = Thread.currentThread();
      }
   }

   /***
    * Decrements the reference count for the lock indicating that a thread released it.
    */
   private void decrement() {
      refcnt_--;
      if(lockMode_ == EXCLUSIVE) {
         lockMode_ = NONEXCLUSIVE;
         exclusiveHolder_ = null;
      }
   }
}