package com.abtcorp.core;
import java.util.*;

/***
 * A class which implements a lock manager to associate a lock with any object.
 *
 * @see ABTLock
 */

public class ABTLockManager {
   /***
    * A collection of locked objects.
    */
   Hashtable lockedObjects_ = new Hashtable();
   /***
    * The one instance of the lock manager.
    */
   static ABTLockManager instance_ = new ABTLockManager();

   /***
    * Returns the lock manager instance.
    * @return ABTLockManager - The instance of the lock manager for this instance of the VM.
    */
   public static ABTLockManager getManager() {return instance_;}

   /***
    * Sets a default lock on an object.
    * The lock set is a non-exclusive, non-blocking lock.
    * @param Object The object that is to be locked.
    */
   public boolean set(Object object) {
      return getLock(object).set();
   }

   /***
    * Sets a lock on an object.
    * @param Object The object that is to be locked.
    * @param mode The type of lock to set. This value can be either ABTLock.EXCLUSIVE or ABTLock.NONEXCLUSIVE.
    * @param timeout The amount of time in milliseconds to wait for the lock to become available.
    * @return boolean Flag indicating whether the lock was successfully set or not.
    */
   public boolean set(Object object, int mode, long timeout) {
      return getLock(object).set(mode,timeout);
   }

   /***
    * Sets a lock on an object.
    * @param Object The object that is to be locked.
    * @param mode The type of lock to set. This value can be either ABTLock.EXCLUSIVE or ABTLock.NONEXCLUSIVE.
    * If the mode is EXCLUSIVE, the thread will block until the lock becomes available. If the mode is NONEXCLUSIVE,
    * the thread will not block if the lock is unavailable.
    * @return boolean Flag indicating whether the lock was successfully set or not.
    */
   public boolean set(Object object, int mode) {
      return getLock(object).set(mode);
   }

   /***
    * Sets a lock on an object.
    * @param Object The object that is to be locked.
    * @param timeout The amount of time in milliseconds to wait for the lock to become available. This method will set
    * a non-exclusive lock.
    * @return boolean Flag indicating whether the lock was successfully set or not.
    */
   public boolean set(Object object, long timeout) {
      return getLock(object).set(timeout);
   }

   /***
    * Releases the lock on an object.
    * @param Object The object that is to be released.
    */
   public void release(Object object) {
      ABTLock lock = getLock(object);
      lock.release();
   }

   /***
    * Returns the lock object held on a particular object.
    * @param object The object that is locked.
    * @return ABTLock The lock object held on the object.
    */
   public ABTLock get(Object object) {return getLock(object);}

   /***
    * Gets a lock on an object.
    * @param Object The object that is to be locked.
    * @return ABTLock The lock object associated with the object being locked.
    */
   private synchronized ABTLock getLock(Object object) {
      ABTLock lock = (ABTLock)lockedObjects_.get(object);
      if(lock == null) {
         lock = new ABTLock();
         lockedObjects_.put(object,lock);
      }
      return lock;
   }

   public int getNumberOfLockedObjects() {return lockedObjects_.size();}
}