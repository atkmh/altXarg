package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoPackage.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-16-98    LZX         Initial Implementation
 * 07-10-98    LZX         Support transactions
 * 07-23-98    LZX         populate package members after all packages are done. 
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTBoolean;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTIOMethRepoPackage is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTIOMethRepoMethod object.
 *
 *  <pre>
 *       ABTIOMethRepoPackage rt = new ABTIOMethRepoPackage(
 *                                     driver,
 *                                     method);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTIOMethRepoMethod
 */

public class ABTIOMethRepoPackage extends ABTIOMethRepoHelper 
{
   private Hashtable packHash_ = null;	// package hash table
   private ABTObject method_ = null;

/**
 *    ABTIOMethRepoPackage constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the method object that owns the packages.
 */
   ABTIOMethRepoPackage(ABTMMRepoDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_MRPACKAGE, OBJ_MM_PACKAGE);
      method_ = parent;
     	packHash_ = new Hashtable();     // get a new Hashtable for these task objects
      component_ = "ABTIOMethRepoPackage";

      Vector piv = getPropertyIndexVector(ps_);
      PropertyIndex pi = null;

      // Loop through all of the properties in the MRPackge table and set the
      // SKIP_READ flag for prHidden field. prHidden is a required parameter
      // and is set when a package object is created. We do not want to 
      // set it again during populate since it is an immutable property.
      // The setPropertyValues() method will not set values for the properties
      // that is flagged SKIP_READ. 
      int size = piv.size();
      for (int i = 0; i < size; i++)
      {
         pi = (PropertyIndex) piv.elementAt(i);
         if (pi.prapiName_.equals(FLD_HIDDEN))
            pi.propertyFlags_ += FLAG_SKIP_READ;
      }

   }


/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
      // reset the req parm hashtable everytime since to prevent "left-over" items
      if (reqParams_ != null)
         reqParams_.clear();

      reqParams_.putItemByString(OFD_METHOD, method_);
      
      // get prHidden flag from cursor. 
      boolean hidden = cursor_.getFieldBoolean(FLD_HIDDEN);
      
      if (hidden == true)
         // set value to empty if the rec condition is not set in the repository
         reqParams_.putItemByString(OFD_HIDDEN, new ABTBoolean(true));
      else
         // otherwise set value to the corresponding value
         reqParams_.putItemByString(OFD_HIDDEN, new ABTBoolean(false));
      
      return (super.create(type, id, reqParams_));
   }


/**
 *  Set package values.
 *  @param       ps: the package properties.
 *  @param       cur: the package cursor.
 *  @param       obj: the package object.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps, ABTCursor cur, ABTObject packageObject) throws ABTException
   {
      setPropertyValues(ps, cur, packageObject);
      
      //
      // Create an object set for the package members that are associated with this
      // package. The actual populating of the object set will be done later.
      //
      //setValue(packageObject, OFD_PACKAGEMEMBERS, createObjectSet(OBJ_MM_PACKAGEMEMBER));

      // add to package hashtable
      long fldID = cur.getFieldInt(FLD_ID);   
		packHash_.put(new Long(fldID), packageObject); 
   }

/**
 *  Retrieves the package hash table.
 *  @return the package hash table
 *  @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public Hashtable getHash() throws ABTException
   {
      return packHash_;
   }

   
/**
 * Sets cursor values and updates the repository.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// first set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);
		
		// for new records, get method id from the method object and set it.
		if (isNew)
   	   cursorSetField(cur, FLD_METHODID, getValue(method_, OFD_ID));
   }
   

/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      // prMethodID can not be modified after add-new
      if (!isNew && prapiName.equals(FLD_METHODID))    
         return true;
         
      return super.isSaveException(prapiName, obj, prapiFlags, isNew);            
   }
   

/**
 * Select cursor from the repository for populate.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForPopulate() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODPACKAGES + id ));
   }

/**
 * Select cursor from the repository for save.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForSave() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODPACKAGES + id));
   }
}