
package com.abtcorp.hub;

/*
 * ABTRowComparator.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
import java.io.*;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

public class ABTRemoteComparator implements ABTComparator, Serializable
{


  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compare(Object object1, Object object2)
   {
      if ((object1 instanceof ABTRowLookup) && (object2 instanceof ABTRowLookup))
         return (((ABTRowLookup)object1).id.compareTo(((ABTRowLookup)object2).id));
      if ((object1 instanceof ABTRemoteID) && (object2 instanceof ABTRowLookup))
         return (((ABTRemoteID)object1).compareTo(((ABTRowLookup)object2).id));
      if ((object1 instanceof ABTRowLookup) && (object2 instanceof ABTRemoteID))
         return (((ABTRowLookup)object1).id.compareTo(object2));
      return -1;
   }

}

