/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.core.*;
import com.abtcorp.idl.*;

import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class ListenerProxy implements IABTListener
   {
   IABTListenerCOM _listn;
   public ListenerProxy(IABTListenerCOM obj) {
      _listn = obj;
      _listn.setProxy(this);
      }

   /**
   * get notified !after! a rowchange took place
   * @param object - ABTObject or ABTObjectSet that has changed
   * @param action - see list of constants above
   * @param property - the property which has changed (if applicable)
   * @param newValue - value of field after the change or ABTObject added/removed
   * @param oldValue - original value (if applicable)
   */
   public void hasChanged( ABTValue object,  int action, IABTProperty property, ABTValue newValue, ABTValue oldValue) {
      Variant obj = VariantMunger.ValueToVariant(object);
      Variant newVal=VariantMunger.ValueToVariant(newValue);
      Variant oldVal=VariantMunger.ValueToVariant(oldValue);
      _listn.hasChanged(obj, action, new ABTPropertyCOM(property),newVal,oldVal);
      }
}