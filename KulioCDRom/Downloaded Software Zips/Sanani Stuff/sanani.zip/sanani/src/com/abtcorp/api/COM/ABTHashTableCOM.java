/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.com;

import java.util.Enumeration;
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.api.local.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class ABTHashTableCOM implements IABTHashTableCOM
{
//   public ABTHashTableCOM() { this( new com.abtcorp.api.local.ABTHashTable()); }
   public ABTHashTableCOM(IABTHashTable ht) {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base   = new ABTBaseJavaCOM(ht);
      /**/
      }

   //aggregated access wrapper
   /**/
   protected ABTBaseJavaCOM _base;      // aggregated base array object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()      { return _base.getObject(); }
   public String toString()       { return _base.toString();};
   public String ToString()       { return _base.ToString();};
   public int  getHashCode()      { return _base.hashCode();}
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo()   { return _base.getClassInfo();}
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private IABTHashTable _ht;
   private IABTHashTable ht() {
      if (_ht == null) _ht = (IABTHashTable)getObject(); 
      return _ht;
      }


   public IABTObjectSpaceCOM getObjectSpace(){
      IABTHashTable ht = (IABTHashTable)getObject();
      IABTObjectSpace os = ht.getObjectSpace();
      return new ABTObjectSpaceCOM(os);
      }

   public boolean containsKey(Variant key)  {
      // this is fake for now
      return ht().containsKey(VariantMunger.VariantToValue(key));
      }

   public boolean containsValue(Variant key)  {
      return ht().containsKey(VariantMunger.VariantToValue(key));
      }

   public boolean isEmpty() {
      return ht().isEmpty();
      }

   public int size() {
      return ht().size();
      }

   public void clear() {
      ht().clear();
      }


   public IABTEnumeratorCOM getElements()
      { return new PropertyEnumerator(ht()); }

   public IABTEnumeratorCOM getKeys() {
      return new KeyEnumerator(ht());
      }

   public Variant getItemByKey(Variant key)  {
      ABTValue V1 = (ABTValue)ht().getItemByKey(VariantMunger.VariantToValue(key));
      return VariantMunger.ValueToVariant(V1);
      }

   public Variant getItemByInt(int key)  {
      return VariantMunger.ValueToVariant((ABTValue)ht().getItemByInt(key));
      }

   public Variant getItemByString(String key) {
     return VariantMunger.ValueToVariant((ABTValue)ht().getItemByString(key));
     }

   public Variant putItemByKey(Variant key, Variant value)  {
      ABTValue _key = VariantMunger.VariantToValue(key);
      ABTValue _val = VariantMunger.VariantToValue(value);
      ABTValue V1 = (ABTValue)ht().putItemByKey(_key, _val);
      return VariantMunger.ValueToVariant(V1);
      }

   public Variant putItemByInt(int key, Variant value)  {
      ABTValue _val = VariantMunger.VariantToValue(value);
      ABTValue V1 = (ABTValue)ht().putItemByInt(key, _val);
      return VariantMunger.ValueToVariant(V1);
      }

   public Variant putItemByString(String key, Variant value) {
      ABTValue _val = VariantMunger.VariantToValue(value);
      ABTValue V1 = (ABTValue)ht().putItemByString(key, _val);
      return VariantMunger.ValueToVariant(V1);
     }


private class PropertyEnumerator implements IEnumVariant,IABTEnumeratorCOM
     {
      IABTEnumerator _en;
      IABTHashTable _os;

      public PropertyEnumerator(IABTHashTable os)
         {
         _os = os;
         _en = _os.getElements();
         }

      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }
      public Variant nextElement()
         {
         Object ne = _en.nextElement();
         if (ne instanceof ABTValue)
            return VariantMunger.ValueToVariant((ABTValue)ne);
         return new Variant(ne);
         }

      public void Skip(int n) {
         while (n-- > 0 && _en.hasMoreElements()) {
            _en.nextElement(); }
         }
      public void Reset() 
         { _en = _os.getElements();  }
      public IEnumVariant Clone()
         { return new PropertyEnumerator(_os); }

      public void Next(int n, Variant[]v, int[]pfetched) {
         pfetched[0] = 0;
         try {
            while (n-- > 0 && _en.hasMoreElements()){
               v[(pfetched[0])++] = nextElement();
               }
            }
         catch (Exception e){throw new com.ms.com.ComFailException(e.getMessage()); }
         }
     }

private class KeyEnumerator implements IEnumVariant,IABTEnumeratorCOM
     {
      IABTEnumerator _en;
      IABTHashTable _os;

      public KeyEnumerator(IABTHashTable os) {
         _os = os;
         _en = _os.getKeys();
         }

      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }
      public Variant nextElement()
         {
         Object ne = _en.nextElement();
         if (ne instanceof ABTValue)
            return VariantMunger.ValueToVariant((ABTValue)ne);
         return new Variant(ne);
         }

      public void Skip(int n) {
         while (n-- > 0 && _en.hasMoreElements()) {
            _en.nextElement(); }
         }
      public void Reset()
         { _en = _os.getKeys(); }
      public IEnumVariant Clone()
         { return new KeyEnumerator(_os); }

      public void Next(int n, Variant[]v, int[]pfetched) {
         pfetched[0] = 0;
         try {
            while (n-- > 0 && _en.hasMoreElements()){
               v[(pfetched[0])++] = nextElement();
               }
            }
         catch (Exception e){throw new com.ms.com.ComFailException(e.getMessage()); }
         }
     }
   
}