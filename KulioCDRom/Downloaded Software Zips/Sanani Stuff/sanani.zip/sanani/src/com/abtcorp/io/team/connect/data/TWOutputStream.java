package com.abtcorp.io.team.connect.data;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Hashtable;

public class TWOutputStream extends ObjectOutputStream implements StreamNames
{
   Hashtable      properties_ = new Hashtable(10,(float)1.0);
   URLConnection  connection_;

   private static URLConnection getURLConnection(URL url) throws IOException
   {
      URLConnection connection = url.openConnection();

      connection.setDoOutput(true);
      connection.setUseCaches(false);
      connection.setRequestProperty("Content-Type","binary/object");

      return connection;
   }

   public TWOutputStream(OutputStream stream) throws IOException
   {
      super(stream);
   }

   public TWOutputStream(String path) throws IOException
   {
      this(new FileOutputStream(path));
   }

   public TWOutputStream(URLConnection connection) throws IOException
   {
      this(connection.getOutputStream());

      connection_ = connection;
   }

   public TWOutputStream(URL url) throws IOException
   {
      this(getURLConnection(url));
   }

   public TWOutputStream(URL url, String path) throws IOException
   {
      this(new URL(url, path));
   }

   public void close() throws IOException
   {
      super.close();

      if (connection_ != null) {
         InputStream stream = connection_.getInputStream();
         stream.close();
      }
   }

   public TWInputStream getInputStream() throws IOException
   {
      if (connection_ == null) return null;

      TWInputStream stream = new TWInputStream(connection_);

      stream.properties_ = properties_;

      return stream;
   }

   public Object set(Object key)                {return set(key, new Boolean(true));}
   public Object set(Object key, Object value)  {return properties_.put(key, value);}
   public Object get(Object key)                {return properties_.get(key);}
   public Object reset(Object key)              {return properties_.remove(key);}

   public void setAllIncludes()
   {
      set(INCLUDE_USER_RESOURCES);
      set(INCLUDE_RESOURCE_PROJECTS);
      set(INCLUDE_ASSIGNMENT_DETAILS);
   }
}