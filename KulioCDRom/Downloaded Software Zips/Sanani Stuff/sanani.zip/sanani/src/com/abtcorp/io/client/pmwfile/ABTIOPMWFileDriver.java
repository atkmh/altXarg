package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileDriver.java 05/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
* 07-14-98    MXA         Initial Implementation.
* 08-03-98    MXA         Change the imports.
*
*/

import java.io.File;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.EOFException;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTDriver;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTTime;

import com.abtcorp.api.local.ABTHashTable;
import com.abtcorp.api.local.ABTDriverLocal;

import com.abtcorp.io.client.ABTFileDriver;

/**
 *  ABTIOPMWFileDriver is the ABT local file driver for the PMW application.
 *  It is instantiated by the PMW application.
 *
 *  <pre>
 *       ABTIOPMWFileDriver driver = new ABTIOPMWFileDriver();
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 M. Abadian
 * @see         ABTDriver, ABTFileDriver
 */

public class ABTIOPMWFileDriver extends ABTFileDriver implements IABTIOPMWFileConstants
{
   private   IABTHashTable    intermediateTable_       = null;
   private   IABTHashTable    lookupTable_             = null;
   private   IABTLocalID      projectId_               = null;
   private   IABTHashTable    siteIntermediateTable_ = null;
   private   IABTLocalID      siteId_                = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTIOPMWFileDriver default constructor.
 */
   public ABTIOPMWFileDriver(){super();}


//====================================================================================
// Populate Project from a local file.
//====================================================================================
/**
 * Populates a Project from a Local file.
 * It catches any exception and returns as an error.
 * @param space: the spce from which the project will be saved.
 * @param args: the hash table of optional, application specific, parameters.
 * @return ABTValue if no exception occurs and an ABTError otherwise
 */
 public ABTValue populate(IABTObjectSpace space, IABTHashTable args)
  {
      boolean transactionStarted = false;
      ABTValue ret = null;

      try
      {
        checkParms(space, args);
        checkType(args);


        String fileName = getSourceFileName(args);

        //Set up the work Space
        intermediateTable_       = (getSpace()).newABTHashTable();
        lookupTable_             = (getSpace()).newABTHashTable();
        projectId_               = null;
        siteIntermediateTable_   = null;
        siteId_                  = null;


        // Start a transaction.
        // Any changes made to the space during save() will be rolled back if an error occurs.
        space.startTransaction();
        transactionStarted = true;

        setFile(fileName);
        populateHashTableFromLocalFile(intermediateTable_);

        
        processSite(POPULATE,args);
        checkSiteObject();
        ret = populateProject(projectId_);

        //Commmit the transaction
        space.commitTransaction();
      }
      catch (ABTException e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(),
                            "populate",
                            errorMessages.ERR_NOT_IN_LIST,
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      finally
      {
        //Clean up the work Space

        intermediateTable_       = null;
        lookupTable_             = null;
        projectId_               = null;
        siteIntermediateTable_ = null;
        siteId_                = null;

        cleanupFile();
        // Return an ABTValue here
         return ret;
      }

  }

 /**
  *    Ensures all conditions are correct for populating the project.
  *    @return an ABTValue for the project
  *    @exception ABTException if an unrecoverable error occurs
  */
  protected ABTValue populateProject(IABTLocalID projectId) throws ABTException
  {
      //Make sure the driver is initialized properly
      checkInitStatus();
      //TO DO:
      //** Checking to see if it exists and it is readable
      //** Verify the rights of this user.

      ABTValue val = null;
      // populate the Project
      ABTIOPMWFileProject prjHelper = new ABTIOPMWFileProject(this);
      val = prjHelper.populate(projectId);

      return val;
  }

//====================================================================================
// Save
//====================================================================================

/**
 * Saves  a Project into a Local file.
 * It catches any exception and returns as an error.
 * @param space: the spce from which the project will be saved.
 * @param args: the hash table of optional, application specific, parameters.
 * @return ABTValue if no exception occurs and an ABTError otherwise
 */
  public ABTValue save(IABTObjectSpace space, IABTHashTable args)
  {
      boolean transactionStarted = false;
      ABTValue ret = null;

      try
      {
        checkParms(space, args);
        checkType(args);
        checkSiteObject();

        String fileName = getDestinationFileName(args);
        ABTValue source = getSource(args);
        checkSourceParm(source);

        //Set up the work Space

       intermediateTable_       = (getSpace()).newABTHashTable();
       lookupTable_             = (getSpace()).newABTHashTable();
       siteIntermediateTable_   = (getSpace()).newABTHashTable();

       
       projectId_     = null;
       siteId_        = null;

        //
        // Start a transaction.  Any changes made to the space during save() will be
        // rolled back if an error occurs.
        //

        space.startTransaction();
        transactionStarted = true;

        setFile(fileName);

        if (source instanceof IABTObject)
        {
            processSite(SAVE,args);
            projectId_ = ((IABTObject)source).getID();
            ret = saveProject((IABTObject)source);

        }
        else
            new ABTError(getClass(),
                         "save",
                         errorMessages.ERR_EXPECTED_IABTOBJECT,
                         null);

        saveHashTableToLocalFile();

        //Commmit the transaction
        space.commitTransaction();

      }
      catch (ABTException e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(),
                            "save",
                            errorMessages.ERR_EXCEPTION,
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      catch (Exception e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(),
                            "save",
                            errorMessages.ERR_EXCEPTION,
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      finally
      {
        //Clean up the work Space
        intermediateTable_       = null;
        lookupTable_             = null;
        siteIntermediateTable_   = null;
        projectId_               = null;
        siteId_                  = null;

        cleanupFile();
        // Return an ABTValue here
        return ret;
      }

  }



/**
 *	save or populate or refresh site object along with type codes and charge codes from/to local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processSite(int command, IABTHashTable args) throws ABTException
 {
      IABTDriver lcldriver_  = null;
      lcldriver_ = (getSpace()).newABTDriver("com.abtcorp.io.client.sitefile.ABTIOSiteFileDriver", null);
     
      ABTValue       siteVal   = null;
      IABTHashTable  arguments = (getSpace()).newABTHashTable();
      String         filename  = null;
      ABTValue       ret       = null;

      switch (command)
      {
         case POPULATE:
            filename = getSourceFileName(args);
            
            arguments.putItemByString(KEY_MODE,               new ABTString(MODE_INTERNAL));
            arguments.putItemByString(KEY_SITE_ID,            (ABTValue)siteId_);
            arguments.putItemByString(KEY_INTERMEDIATE_TABLE, (ABTValue)siteIntermediateTable_);
            arguments.putItemByString(KEY_LOOKUP_TABLE,       (ABTValue)lookupTable_);
	        arguments.putItemByString(KEY_TYPE ,              new ABTString(TYPE_PMW));

            ret = lcldriver_.populate(arguments);
            break;
         case SAVE:
            filename = getDestinationFileName(args);
            siteVal  = getSite();
            
            arguments.putItemByString(KEY_MODE,               new ABTString(MODE_INTERNAL));
            //Change This! Delete This
            arguments.putItemByString(KEY_SITE_ID,            (ABTValue)siteId_);
            arguments.putItemByString(KEY_INTERMEDIATE_TABLE, (ABTValue)siteIntermediateTable_);
            arguments.putItemByString(KEY_LOOKUP_TABLE,       (ABTValue)lookupTable_);
	        arguments.putItemByString(KEY_TYPE ,              new ABTString(TYPE_PMW));
	        arguments.putItemByString(KEY_SOURCE,             siteVal);

            lcldriver_.save(arguments);
            ABTValue val = null;
            val = arguments.getItemByString(KEY_SITE_ID);
            if (val instanceof IABTLocalID)
                siteId_ = (IABTLocalID)val;
            else
                throw new ABTException("An error in ABTIOPMWFIleDriver processSite.");
            break;
         default:
            break;
      }
      return ret;
 }






//====================================================================================
// save (from object space to file)
//====================================================================================
/**
  *    Causes a master (main) project to be saved from the object space to a Local File.
  *    @return a value indicating success/failure of the save operation
  *    @exception ABTException if an unrecoverable error occurs
  */
  protected ABTValue saveProject(IABTObject project) throws ABTException
  {
      //Make sure the driver is initialized properly
      checkInitStatus();

      // save the Project
      ABTIOPMWFileProject prjHelper = new ABTIOPMWFileProject(this);
      Hashtable reqProjParms = new Hashtable();
      if (project == null)
        throw new ABTException(" The project is null.");
      else
      {
        reqProjParms.put(PROJECT_OBJ, project);
        IABTLocalID projectId = null;
        projectId = ((IABTObject)project).getID();        
        if ( (projectId == null) || (projectId instanceof ABTEmpty) || (ABTError.isError(projectId)) )
            throw new ABTException("The project Id is not correct");
        else
            reqProjParms.put(PROJECT_ID, projectId);  
        
      }
      prjHelper.save(reqProjParms);

      //Debug
      prjHelper.trace();
      return (ABTValue) null;
   }

/**
 * Saves a HashTable  to a local file
 * @exception ABTException if an unrecoverable error ocurs.
 */
   public void saveHashTableToLocalFile() throws ABTException {
      try{
         FileOutputStream fout  = new FileOutputStream(getFile());
         ObjectOutputStream out = new ObjectOutputStream(fout);
         out.writeObject(projectId_);
         out.writeObject(siteId_);         
         out.writeObject(intermediateTable_);
         out.writeObject(siteIntermediateTable_);
         out.flush();
         out.close();
      } catch (IOException e) {
         throw new ABTException(e.getMessage());
      }
   }


/**
 * Populates the intermediate hash table from a local file
 * @exception ABTException if an unrecoverable error ocurs.
 */
   public void populateHashTableFromLocalFile(IABTHashTable driverInterHashTable) throws ABTException
   {
      projectId_ = null;
      try{
         FileInputStream fin      =  new FileInputStream(getFile());
         ObjectInputStream in     =  new ObjectInputStream(fin);
         projectId_               =  (IABTLocalID)  in.readObject();
         siteId_                  =  (IABTLocalID)  in.readObject();
         intermediateTable_       =  (getSpace()).newABTHashTable(in);
         siteIntermediateTable_   =  (getSpace()).newABTHashTable(in);
         in.close();
      } catch (EOFException e) {
         throw new ABTException(e.getMessage());
      }catch(ClassNotFoundException e) {
         throw new ABTException(e.getMessage());
      }catch (IOException e) {
         throw new ABTException(e.getMessage());
      }

   }




//====================================================================================
// miscellaneous utilities
//====================================================================================
/**
  * return  IABTLocalID- the project ID
  */
  public IABTLocalID getProjectId()
  {
    return projectId_;
  }
/**
  * return void set the project ID
  */
  public void setProjectId(IABTLocalID id)
  {
    projectId_ = id;
  }
/**
  * return  IABTLocalID- the Site ID
  */
  public IABTLocalID getSiteId()
  {
    return siteId_;
  }
/**
  * return void set the Set ID
  */
  public void setSiteId(IABTLocalID id)
  {
    siteId_ = id;
  }

/**
  *  intermediateTableGet
  *  Get the Object associated with the key in the intermediate hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object

  */

  public Object intermediateTableGet(Object key) throws ABTException
  {
    if (key instanceof ABTValue)
        return (intermediateTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("intermediateTableGet() wrong cast");
  }

/**
  *  intermediateTablePut
  *  Put the Object associated with the key in the intermediate hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object intermediateTablePut(Object key, Object elem) throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (intermediateTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("intermediateTablePut() wrong cast");
  }

/**
  *  isIntermediateTableNull
  *  return boolean
  */

  public boolean isIntermediateTableNull()
  {
    boolean ret = false;
    if (intermediateTable_==null)
        ret = true;
    return ret;
  }



/**
  *  lookupTableGet
  *  Get the Object associated with the key in the lookup hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public Object lookupTableGet(Object key)throws ABTException
  {
    if (key instanceof ABTValue)
        return (lookupTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("lookupTableGet() wrong cast");
  }

/**
  *  lookupTablePut
  *  Put the Object associated with the key in the lookup hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object lookupTablePut(Object key, Object elem)throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (lookupTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("lookupTablePutt() wrong cast");
  }



/**
  *  siteIntermediateTableGet
  *  Get the Object associated with the key in the site intermediate hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object

  */

  public Object siteIntermediateTableGet(Object key) throws ABTException
  {
    if (key instanceof ABTValue)
        return (siteIntermediateTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("siteIntermediateTableGet() wrong cast");
  }

/**
  *  siteIntermediateTablePut
  *  Put the Object associated with the key in the site intermediate hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object siteIntermediateTablePut(Object key, Object elem) throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (siteIntermediateTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("siteIntermediateTablePut() wrong cast");
  }

/**
  *  isSiteIntermediateTableNull
  *  return boolean
  */

  public boolean isSiteIntermediateTableNull()
  {
    boolean ret = false;
    if (siteIntermediateTable_==null)
        ret = true;
    return ret;
  }


//====================================================================================
// private methods
//====================================================================================

   private void checkParms(IABTObjectSpace space, IABTHashTable args) throws ABTException
   {
      // make sure the space is set.
      if (space != null)
         setSpace(space);
      else
         throw new ABTException( EXC_OBJECTSPACE_NOT_SET +
                                 "Object space needs to be specified.");

      // make sure the hashtable is not null
      if ((args == null) || args.isEmpty())
         throw new ABTException( EXC_INVALID_HASH +
                                 "Hashtable must be populated.");

   }

   private void checkSourceParm(ABTValue source) throws ABTException
   {
        if (source == null || (source instanceof ABTEmpty ))
            throw new ABTException(EXC_EMPTY_SOURCE);
        if (ABTError.isError(source))
            throw new ABTException(EXC_SOURCE_ERROR);
            
        IABTLocalID projectId = null;
        if ( !(source instanceof IABTObject) )
             throw new ABTException(EXC_SOURCE_ERROR);           
        projectId =  ((IABTObject)source).getID();
        if ( (source == null) || (source instanceof ABTEmpty) || (ABTError.isError(projectId)) )
            throw new ABTException("The project Id is not correct");
                   
            
   }


   private void checkType(IABTHashTable args) throws ABTException
   {
        String type = getStringValue(args, KEY_TYPE);
        if (type == null || !type.equalsIgnoreCase(TYPE_PROJECT) )
            throw new ABTException(EXC_INVALID_TYPE);
   }


   private String getSourceFileName(IABTHashTable args) throws ABTException
   {
        String fileName = getStringValue(args, KEY_SOURCENAME);
        if (fileName == null)
            throw new ABTException(EXC_FILENAME_NOT_SET);
        return fileName;
   }

   private String getDestinationFileName(IABTHashTable args) throws ABTException
   {
        String fileName = getStringValue(args, KEY_DESTINATIONNAME);
        if (fileName == null)
            throw new ABTException(EXC_FILENAME_NOT_SET);
        return fileName;
   }

   private ABTValue getSource(IABTHashTable args) throws ABTException
   {
    try
    {
        ABTValue source = args.getItemByString(KEY_SOURCE);
        if (source == null)
            return null;
        else
            return source;
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private void checkSiteObject() throws ABTException
   {
      ABTValue site = getSite();
      if ( ABTError.isError( site ) )
         throw new ABTException((ABTError) site);
   }

}