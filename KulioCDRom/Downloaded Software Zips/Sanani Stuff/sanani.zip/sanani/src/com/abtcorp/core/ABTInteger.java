/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTInteger.java, 16, 10/8/98 8:33:56 AM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.io.*;
import java.text.*;

public class ABTInteger extends ABTImmutableValue
{
   // We cannot extend from Integer since it is final

   private static final long serialVersionUID = 1360826667806852920L;

   protected int value_;
    public void fromByte(byte[] input){};
    public byte[] fromByte(){ return null;};

   public ABTInteger(int      value) {value_ = value;}
   public ABTInteger(ABTValue value) {value_ = value.intValue();}

   public boolean booleanValue() {return value_ != 0;}
   public short   shortValue()   {return (short)value_;}
   public int     intValue()     {return value_;}
   public double  doubleValue()  {return value_;}
   public String  stringValue()  {return NumberFormat.getInstance().format(value_);}

   public static ABTInteger valueOf(String string) {return new ABTInteger(new ABTString(string));}
   
   public int hashCode() {return value_;}

   // Warning: This is a loose compare since we will convert the argument
   //          using rounding, truncation or parsing

   public int compareTo(Object object) 
   {
    if (object == null) return 1;     
    return compareTo(((ABTValue)object).intValue());
   }

   public final int compareTo(int value)
   {
      if (value_ == value) return 0;
      
      return value_ < value ? -1 : +1;
   }

   // This optimizes the serialization

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeInt(value_);
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      value_ = stream.readInt();
   }
}