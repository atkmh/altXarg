
package com.abtcorp.hub;

/*
 * ABTProperty.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 12-04-98   SOB      #647
  *
  *
  * TO DO:
  *
  * 1-  define constants for type description
  * 2-
  */
import com.abtcorp.core.*;
import  java.io.Serializable;
import java.lang.StringBuffer;


/**
 *  ABTProperty - describes a property(field) for the ABT ObjectSpace
 *  The collection of ABTProperties ("ABTPropertySet") contains all the accessable
 *  fields for an ABTObject
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.hub.ABTPropertySet
 */
public class ABTProperty extends ABTValue implements com.abtcorp.idl.IABTPropertyType, Serializable
{

   final static int DELETED_PROPERTY = 0;

	/**
	 * name of property
	 */
	private String my_name;

	/**
	 * caption of property
	 */
	private String my_caption;

   /**
   *  type of property
    */
   private int my_type;

   /**
   * index in main property list
   */
   private int my_index;


   /**
   * base-type of property if object or objectset (e.g. "ABTTASK")
   */
   private ABTRule referenceType;

   /**
   * index in main property list
   */
   private int my_RowIndex;


   /**
   * handle to the rule for object/objectset properties
   */
   private ABTRule myRule;

   /**
   * handle to the rule for my field validation routines
   */
   private ABTFieldRule myFieldRule;



   /**
   * enum for possible values and pretty description
   * where the key of an element denotes a legal value, the
   * associated element a pretty display
   */
   private ABTExtendedPropertyList extendedProperties;


   private int lookupIndex;

   private boolean isIndex_;

//methods==========================================================================================
	/**
	 *	default constructor - set name and type to UnKnown....
	 */
	protected ABTProperty ( String name_, String caption_, int type_)
	{
      extendedProperties = new ABTExtendedPropertyList();

	   my_name = name_;
	   my_caption = caption_;
	   my_type = type_;
	   my_index = -1;
      myRule = null;
      myFieldRule = null;
      referenceType = null;
      lookupIndex = -1;
      isIndex_ = false;
      setPropertyKey(PROP_KVIRTUAL, ABTBoolean.False());
      setPropertyKey(PROP_KUPDATABLE, ABTBoolean.True());
      setPropertyKey(PROP_KVISIBLE,ABTBoolean.True());
      setPropertyKey(PROP_KTRANSIENT,ABTBoolean.False());
      setPropertyKey(PROP_KINTERNALUSE,ABTBoolean.False());
      setPropertyKey(PROP_KEDITABLE,ABTBoolean.True());
      setPropertyKey(PROP_KHIDDEN,ABTBoolean.False());
      setPropertyKey(PROP_KUSEDEFAULT,ABTBoolean.False());


	}

   protected int getLookupIndex()
   {
      return lookupIndex;
   }
   protected void  setLookupIndex(int lookupIndex_ )
   {
      lookupIndex = lookupIndex_;
   }

   protected boolean isIndex()
   {
      return isIndex_;
   }

   /*#647*/ protected void makeIndex()
   {
      isIndex_ = true;
   }
   /**
   * return whether this property is a scalar property
   * unless it is an object or an object reference - it is a scalar
   */
   public boolean isScalar()
   {
//         if ((type_ == PROP_OBJECT) || (type_ == PROP_OBJECTSET))
        if (referenceType == null)
            return true;
        else
            return false;
   }
   public String dump(int indent, int level)
   {
      StringBuffer sb;
      switch (level)
      {
         case 0:
            return (my_name + " / " + my_caption);
         default:
            sb = new StringBuffer();
            sb.append(my_name + " / " + my_caption + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
      	   sb.append("my_type : " + my_type + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
      	   sb.append("my_index " + my_index + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            sb.append("virtual : " + isVirtual() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            sb.append("updatabale : " + isUpdatable() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            sb.append("visible : " + isVisible() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            sb.append("transient : " + isTransient() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            if (myRule == null)
               sb.append("myRule = null  - " + com.abtcorp.core.ABTUtil.newLine(indent) );
            else
               sb.append("myRule : " + myRule.getClass() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            if (myFieldRule == null)
               sb.append("myFieldRule = null" + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            else
               sb.append("myFieldRule : " + myFieldRule.getClass() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            if (referenceType == null)
               sb.append("referenceType = null" + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            else
               sb.append("referenceType : " + referenceType.getClass() + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            if (get(PROP_KDEFAULTVALUE) == null)
               sb.append("defaultValue = null" + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            else
               sb.append("defaultValue : " + get(PROP_KDEFAULTVALUE).dump(indent,1) + com.abtcorp.core.ABTUtil.newLine(indent) + " - ");
            return sb.toString();
      }

   }

//======================================
// Getters
//======================================

   /**
   * return the extendedProperties as a hashtable
   */
   public ABTExtendedPropertyList getExtendedProperties()
   {
      return extendedProperties;
   }


   /**
   * return the default value for property-field by key
   * @param key key of property as abtvalue
   */
   public ABTValue getPropertyKey(ABTValue key)
   {
      try
      {
          ABTValue val = extendedProperties.get(key);
          if (val == null)
             return new ABTErrorHub("ABTProperty.getPropertyKey",errorMessages.ERR_23,key);
          else
             return val;
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTProperty.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }

   /**
   * return the default value for property-field by key
   * @param key key index of property
   */
   public ABTValue getPropertyKey(int key)
   {
      try
      {
          ABTValue val = extendedProperties.get(key);
          if (val == null)
             return new ABTErrorHub("ABTProperty.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
          else
             return val;
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTProperty.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }

   /**
   * return the default value for property-field by key
   * @param key name of property
   */
   public ABTValue getPropertyKey(String key)
   {
      try
      {
          ABTValue val = extendedProperties.get(key);
          if (val == null)
             return new ABTErrorHub("ABTProperty.getPropertyKey",errorMessages.ERR_23,key);
          else
             return val;
      }
      catch (Exception e)
      {
             return new ABTErrorHub("ABTProperty.getPropertyKey",errorMessages.ERR_23,new ABTString("Index at " + key ));
      }

   }

   /**
   * return the associated parent (ABTRule)
   * @return ABTRule - the parent
   */

   final public ABTRule getRuleSet()
   {
      return myRule;
   }


   /**
   * return the associated field validation routine
   * @return ABTFieldRule
   */
   final public ABTFieldRule getFieldRule()
   {
      return myFieldRule;
   }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isUpdatable()
   {
      return get(PROP_KUPDATABLE).booleanValue();
   }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isVisible()
   {
      return get(PROP_KVISIBLE).booleanValue();
   }


   /**
   * return whether this property is internal use only
   * @return boolean true for internal properties
   */
   public boolean isInternal()
   {
      ABTValue val = get(PROP_KINTERNALUSE);
      if ((val != null) && (val instanceof ABTBoolean))
        return val.booleanValue();
      else
        return false;
   }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isTransient()
   {
      return get(PROP_KTRANSIENT).booleanValue();
   }


   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isVirtual()
   {
      return get(PROP_KVIRTUAL).booleanValue();
   }

   /**
   * return the name of this property
   * @return String name
   */
   public String getName()
   {
      return my_name;
   }

   /**
   * return the caption of this property
   * @return String caption
   */
   public String getCaption()
   {
      return my_caption;
   }


   /**
   *  return the type of this property
   * @return int type
   */
   public int getType()
   {
      return my_type;
   }


   /**
   *  get the referenced type of the property
   * @return ABTRule type or null if not reference
   */
   public ABTRule  getReferenceType()
   {
      return referenceType;
   }


   /**
   *  get the default value for this field
   * @return ABTValue
   */
   public ABTValue  getDefaultValue()
   {
        return get(PROP_KDEFAULTVALUE);
   }

   /**
   * set the indexKeyRowIndex of this property
   * @param indexKey_ new indexKey in associated rowset
   */
   protected void setRowIndex(int RowIndex_)
   {
      my_RowIndex = RowIndex_;
   }

   /**
   * getRowIndex in propertySet
   * @return int RowIndex in rowset or -1 for NOT SET
   */
   public int getRowIndex()
   {
      return my_RowIndex;
   }


   /**
   * getIndex in propertySet
   * @return int index in rowset or -1 for NOT SET
   */
   public int getIndex()
   {
      return my_index;
   }



//=============================================
// Setters
//=============================================


   /**
   *  set the default value for this field
   * @param default_ ABTValue
   */
   protected void   setDefaultValue(ABTValue default_)
   {
      if (!(ABTValue.isNull(default_)))
          setPropertyKey(PROP_KUSEDEFAULT,ABTBoolean.True());
      extendedProperties.add(PROP_KDEFAULTVALUE,default_);
   }

   /**
   * set the caption of this property
   * @param caption_ new caption
   */
   protected void setCaption(String caption_)
   {
      my_caption = caption_;
   }

   /**
   * set the parent ruleSet
   * @param parent_ parent rule
   */
   protected void  setRuleSet(ABTRule parent_)
   {
      myRule = parent_;
   }


   /**
   * set the associated field validation routine
   * @param fieldRule_ new fieldrule
   */
   protected void setFieldRule(ABTFieldRule fieldRule_)
   {
       myFieldRule = fieldRule_;
   }

   /**
   * set this property to be updatable
   */
   protected void setUpdatable()
   {
      setPropertyKey(PROP_KUPDATABLE, ABTBoolean.True());
   }

   /**
   * set this property to be Not updatable
   */
   protected void setNotUpdatable()
   {
      setPropertyKey(PROP_KUPDATABLE, ABTBoolean.False());
   }


   /**
   * set this property to be visible
   */
   protected void setVisible()
   {
      setPropertyKey(PROP_KVISIBLE,ABTBoolean.True());
   }

   /**
   * set this property to be Not visible
   */
   protected void setNotVisible()
   {
      setPropertyKey(PROP_KVISIBLE,ABTBoolean.False());
   }



   /**
   * set this property to be transient
   */
   protected void setTransient()
   {
      setPropertyKey(PROP_KTRANSIENT,  ABTBoolean.True());
   }

   /**
   * set this property to be Not transient
   */
   protected void setNotTransient()
   {
      setPropertyKey(PROP_KTRANSIENT,  ABTBoolean.False());
   }


   /**
   * set this property to be virual
   */
   protected void setVirtual()
   {
      setPropertyKey(PROP_KVIRTUAL, ABTBoolean.True());
   }

   /**
   * set this property to be Not virtual
   */
   protected void setNotVirtual()
   {
      setPropertyKey(PROP_KVIRTUAL, ABTBoolean.False());
   }



   /**
   *  set the subtype of the property
   * @param referenceType_ new referenced Type of property
   */
   protected void  setReferenceType(ABTRule referenceType_)
   {
      referenceType = referenceType_;
   }

   /**
   * set the index of this property
   * @param index_ new index in associated rowset
   */
   protected void setIndex(int index_)
   {
      my_index = index_;
   }



//================================================
// Array requirements
//================================================

   /**
   *  - required routine to allow storing in sorted sets
   * @param object - to compare against
   * @return boolean true for equal
   */
   public boolean  equals  (Object object)
   {
      if  (object instanceof ABTProperty)

         return my_name.equalsIgnoreCase(((ABTProperty)object).my_name);
      else
         if  (object instanceof String)
            return my_name.equalsIgnoreCase((String)object);
         else
             if  (object instanceof ABTString)
                return my_name.equalsIgnoreCase(((ABTString)object).stringValue());
             else
                return false;
   }

   /**
   *  required routine to allow unique access in sets
   * @return int - hashcode
   */
   public int hashCode()
   {
      return my_name.hashCode();
   }

//================================================
// Internals
//================================================

   /**
   * internal use - release my handles
   */

   protected void destroy()
   {
	   my_name = null;
	   my_type = 0;
	   my_index = -1;
      extendedProperties.clear();
      myRule = null;
      myFieldRule = null;
      referenceType = null;
   }


   protected void finalize()
   {
      destroy();
   }
     /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compareTo  (Object  object)
   {
      if (object == null) return 1;
      if ((object instanceof ABTProperty) || (object instanceof String))
         return compareTo(object);
//       return my_name.toUpperCase().compareTo(object.toString());
       return my_name.compareTo(object.toString());
   }

   public int compareTo  (String  object)
   {
//       return my_name.toUpperCase().compareTo(object.toUpperCase());
       return my_name.compareTo((String)object);
   }

   public int compareTo  (ABTProperty  object)
   {
//       return my_name.toUpperCase().compareTo(object.getName().toUpperCase());
       return my_name.compareTo(object.getName());
   }

   /**
   * set the default value for property-field by key (internal use)
   * @param key index of property
   * @param value - new default
   */
   public void setPropertyKey(int key,ABTValue value)
   {
        if (key == PROP_KDEFAULTVALUE)
            setDefaultValue(value);
        else
            extendedProperties.add(key,value);
   }

   /**
   * set the default value for property-field by key (internal use)
   * @param key name of property
   * @param value - new default
   */
   public void setPropertyKey(String key,ABTValue value)
   {
      extendedProperties.add(key,value);
   }

   /**
   * set the default value for property-field by key (internal use)
   * @param key key of property in abtvalue format
   * @param value - new default
   */
   public void setPropertyKey(ABTValue key,ABTValue value)
   {
    if ((key instanceof ABTShort) || (key instanceof ABTInteger))
        setPropertyKey(key.intValue(),value);
    else    
      extendedProperties.add(key,value);
   }

   /**
   * return the default value for property-field by key (internal use)
   * @param key key of property in abtvalue format
   */
   private ABTValue get(ABTValue key)
   {
      return extendedProperties.get(key);
   }

   /**
   * return the default value for property-field by key (internal use)
   * @param key index of property
   */
   private ABTValue get(int key)
   {
      return extendedProperties.get(key);
   }

  /**
   * check whether the provided ABTValue is of the exactly correct type
   * @param value ABTValue to check against this property
   * @return ABTBoolean (true/false)
   */
   public boolean isExactType(ABTValue value)
   {
        return ABTProperty.isExactType(my_type,referenceType,value);
   }

   /**
   * check whether the provided ABTValue is of a compatible type
   * @param value ABTValue to check against this property
   * @return ABTBoolean (true/false)
   */
   public boolean isCloseEnoughType(ABTValue value)
   {
        return ABTProperty.isCloseEnoughType(my_type,referenceType,value);
   }

   /**
   * check whether the provided ABTValue is of a compatible type
   * and munge it into the exactly correct type
   * @param value ABTValue to check against this property
   * @return ABTBoolean (true/false)
   */
   public ABTValue coerceType(ABTValue value)
   {
        return ABTProperty.coerceType(my_type,referenceType,value);
   }



  /**
   * check whether the provided ABTValue is of the exactly correct type
   * @param referenceType ABTRule of referenced type
   * @param value ABTValue to check against this property
   * @return ABTBoolean (true/false)
   */
   public static boolean  isExactType(int my_type, ABTRule referenceType, ABTValue value)
   {
        switch (my_type)
        {
            case PROP_UNKNOWN:// anything can be an unknown
              return true;

            case PROP_STRING:
              return (value instanceof ABTString);

            case PROP_OBJECT:
               {
               if (!(value instanceof ABTObject)) break;
               // check its type
               ABTObject obj = (ABTObject)value;
               String newType = obj.getObjectType();
               if (newType.equals(referenceType.getName())) return true;
               return false;
               }

            case PROP_OBJECTSET:
               {
               if  (!(value instanceof ABTObjectSet)) break;
               // check its type
               ABTObjectSet oset = (ABTObjectSet)value;
               String newType = oset.getRule().getName();
               if (newType.equals(referenceType.getName())) return true;
               return false;
               }

            case PROP_INT:    // that's a C++ int, a java short
               return (value instanceof ABTShort);

            case PROP_LONG:   // that's a C++ long, a java int
               return (value instanceof ABTInteger);

            case PROP_BLOB:
               if (value instanceof com.abtcorp.blob.ABTCalendar) return true;
               return (value instanceof com.abtcorp.blob.ABTCurve);

            case PROP_BOOLEAN:
               return (value instanceof ABTBoolean);

            case PROP_DOUBLE:
               return (value instanceof ABTDouble);

            case PROP_SHORT:
               return (value instanceof ABTShort);

            case PROP_ARRAY:
               return (value instanceof ABTArray);

            case PROP_HASH:
               return (value instanceof ABTHashtable);

            case PROP_ID:
               return (value instanceof ABTRemoteID);

            case PROP_DATE:
               return (value instanceof ABTDate);

            case PROP_TIME:
            case PROP_TIMESTAMP:
               return  (value instanceof ABTTime);
           }
      return false;
   }

   /**
   * check whether the provided ABTValue is of a compatible type
   * @param referenceType ABTRule of referenced type
   * @param value ABTValue to check against this property
   * @return ABTBoolean (true/false)
   */
   public static boolean isCloseEnoughType(int my_type, ABTRule referenceType, ABTValue value)
   {
      if (isExactType(my_type, referenceType,value) == true) return true; // that's close enough
      switch (my_type)
         {
         case PROP_STRING: // any ABTValue can be a string
            return true;

         case PROP_LONG:   // that's a C++ long, a java int
            return (value instanceof ABTShort);

         case PROP_DOUBLE:
            if (value instanceof ABTShort)   return true;
            return (value instanceof ABTInteger);
         case PROP_OBJECTSET:
         /* #46 verification for onAdd...*/
               {
               if  (!(value instanceof ABTObject)) break;
               // check its type
               ABTObject oset = (ABTObject)value;
               String newType = oset.getRule().getName();
               if (newType.equals(referenceType.getName())) return true;
               return false;
               }
         }

      return false;
   }

   /**
   * check whether the provided ABTValue is of a compatible type
   * and munge it into the exactly correct type
   * @param referenceType ABTRule of referenced type
   * @param value ABTValue to check against this property
   * @return ABTBoolean (true/false)
   */
   public static ABTValue coerceType(int my_type, ABTRule referenceType, ABTValue value)
   {
      // does it even need to be coerced
      if (isExactType(my_type, referenceType, value) == true) return value;

      if (isCloseEnoughType(my_type, referenceType, value) == false)
         return new ABTError("ABTProperty", "coerceType", errorMessages.ERR_45, null);

      switch (my_type)
         {
         case PROP_STRING: // any ABTValue can be a string
            return new ABTString(value.stringValue());

         case PROP_LONG:   // that's a C++ long, a java int
            return new ABTInteger(value.intValue());

         case PROP_DOUBLE:
            return new ABTDouble(value.doubleValue());
         }
      return new ABTError("ABTProperty", "coerceType", errorMessages.ERR_45, null);
   }

}