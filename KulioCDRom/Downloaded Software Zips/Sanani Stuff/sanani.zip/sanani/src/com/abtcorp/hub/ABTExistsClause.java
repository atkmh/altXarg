package com.abtcorp.hub;

/*
 * ABTExistsClause.java 05/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author        Description
  * 05-05-98	 JSE           Initial Design
  *
  *
  * TO DO:
  *
  * 1-  optimize with field-index access
  * 2-
  */


/**
 * Basic ABTExistsClause class - base class for handling
 * an exists call
 *
 * @version	1.0
 * @author      Scott Ellis
 * @see         com.abtcorp.core.ABTValue
 */

import java.util.*;
import com.abtcorp.core.*;

public class ABTExistsClause extends ABTParserFunction
{
   /**
   * class constructor for an exists clause
   * e.g. : Exists( Childtasks.PRNAME like 'SANANI' )
   */
   public ABTExistsClause( ABTUserSession session,ABTArray instances_, String field_ , String subfield_, int operation_, ABTValue value_ )
   {
      super( session,instances_, field_, subfield_, operation_, value_ );
   }

   /**
   *  evaluate the expression
   *  @return boolean
   */
   public boolean booleanValue()
   {

      ABTValue val = lookup();
      if (val == null)
         return false; //?whoops

      if( val instanceof ABTObject )
      {
         ABTObject object = (ABTObject)val;
         ABTValue v = object.getValue( mySession, subfield, null );
         if( ABTError.isError( v ) )
            return false;

         return evaluatePos( v, value );
      }

      if (!(val instanceof ABTObjectSet))
         return false; //?whoops

      Enumeration e = ((ABTObjectSet)val).elements(mySession);
      while( e.hasMoreElements() )
      {
         // abolute index-access better be in correct bounds - otherwise
         // there will be an array-out-of-bounds exception
         ABTValue v1 = (ABTValue) e.nextElement();
         if( !ABTError.isError( v1 ) )
         {
             ABTObject o = (ABTObject)v1;
             if( evaluatePos( o.getValue(mySession, subfield,null ), value ) )
                return true;
         }
         
      }

      return false;
   }
}

