package com.abtcorp.objectModel.abt;

/*
 * Calendar.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date          Author       Description
  * 09-18-98      SOB          Initial implementation.
  *
  */

import  com.abtcorp.objectModel.*;
import  com.abtcorp.core.*;
import  com.abtcorp.hub.*;
import  com.abtcorp.idl.*;

/**
 * Calendar is the object rule class that handles the Calendar object business rules.
 * This is a temporary class in order to support the method driver.
 *
 *
 * @version	$Version
 * @author  S. Bursch
 */

public class Calendar extends SiteRule
{

  /**
   * Default Constructor
   */
   public Calendar()
   {
      super();
   }

      /**
    * Initializes the calendar object.
    *
    *
    * @param session             - The current user session handle
    * @param object              - The new object
    * @param requiredParameters  - List of required parameters
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTHashtable parameters )
   {
      ABTValue v;

      //
      // Check required parameters.
      //
      v = setReqParm( session, object, parameters, OFD_SITE, OFD_CALENDARS, "abt.Calendar->onInitialize" );
      if ( ABTError.isError( v ) )
         return v;

      //
      // Set the name property to a default, non-null value.  The value will also be unique in the object space,
      // but that is not a requirement.
      //
      v = object.setValue( session, OFD_NAME, new ABTString( object.getID().getUniqueId() ), parameters );
      if( ABTError.isError( v ) )
         return v;

      return null;
   }

/**
   * Sets default properties for the site object.
   */
   protected void setDefaultProperties()
   {
      //
      // Relationship Properties
      //
      addProperty( OFD_SITE, OFD_SITE_CAP, PROP_OBJECT, false, true, true, false, OBJ_SITE, null, null );
      addProperty( OFD_BASECALENDAR, OFD_BASECALENDAR_CAP, PROP_OBJECT, false, true, true, false, OBJ_CALENDAR, FR_CALENDAR_BASECALENDAR, null );


      //
      // Field Properties
      //
      addProperty( OFD_BASECALENDARID, OFD_BASECALENDARID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_RESOURCEID, OFD_RESOURCEID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_VALUE, OFD_VALUE_CAP, PROP_BLOB, false, true, true, false, null, null, null );

      ABTProperty prop;

      addProperty( OFD_NAME, OFD_NAME_CAP, PROP_STRING, false, true, true, false, null, FR_DISALLOWNULLORZERO, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(32));

  }

   /**
    * Add a new object to an object set by calling the SiteRule method
    *    <code>addToSet(String type, ABTUserSession,ABTValue,boolean)</code>.
    *
    * @param session    - The session object for transaction support
    * @param parent     - The <code>ABTObjectSet</code> that the new element is being added to.
    * @param newValue   - The new <code>ABTObject</code> being added to the list
    * @param existing   - true if <code>newValue</code> has been created by the caller
    *                     , false if it has been initialized with default values
    *
    * @return ABTValue  - ABTValue if successful, ABTError if not
    */
   protected ABTValue onAdd( ABTUserSession session, ABTObjectSet parent, ABTValue newValue, boolean existing )
   {
      return parent.addToSet( session, newValue, existing );
   }

  /**
   * Deletes a calendar object.
   * @param parent - the object to be removed
   * @return ABTValue - check for ABTError....
   */
   protected ABTValue onDelete(ABTUserSession session, ABTObject parent)
   {
      //
      // For the time being, prohibit deletion of calendar objects.
      //
      return new ABTError( "Calendar",
                           "onDelete",                                
                           errorMessages.ERR_ACCESS_DENIED,
                           "Cannot delete calendar objects" );
   }
}
