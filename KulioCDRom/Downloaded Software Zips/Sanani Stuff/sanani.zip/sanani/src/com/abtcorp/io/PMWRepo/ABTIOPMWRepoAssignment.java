package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoAssignment.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-09-98    SOB            transaction support
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support save() functionality
 * 07-21-98    SOB            Mods to support required params on object create
 * 10-06-98    SOB            Assignment's resource ID reference gotten from associated Team object, not Resource object
 * 10-09-98    SOB            Beginnings of progress reporting
 * 12-02-98    SOB            #637
 * 12-07-98    SOB            #553
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoAssignment is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTAssignment object in the object space.
 *  <pre>
 *       ABTIOPMWRepoAssignment rd = new ABTIOPMWRepoAssignment(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoAssignment extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTRemoteIDRepository resID_ = null;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private Hashtable ht_;
   private Hashtable hr_;
   private ABTCursor resCursor_ = null;
   private ABTObjectSet resOs_ = null;
   private int repoID_;

   public ABTIOPMWRepoAssignment() {/*implicit call to super() here*/}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoAssignment(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable ht,
                       Hashtable hr,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_ASSIGNMENT, OBJ_ASSIGNMENT, progress);
      projObj_ = projObj;
      projectID_ = projID;
      ht_ = ht;
      hr_ = hr;
      repoID_ = driver.getRepository().getID();
   }

   /**
    *    Constructor used by the save process.
    *    @param space: an object space reference
    *    @param driver: a driver reference
    *    @param project: a project object reference
    *    @param forceAddNew: if true, all objects to be saved are forced to be "new"; otherwise,
    *           new objects are only determined by the presence of a non-null remote ID
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoAssignment(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_ASSIGNMENT, OBJ_ASSIGNMENT, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with objects appropriate to this helper class.
    *    @param parms: an ABTArray of parameters meaningful to the populate process
    *    @return an ABTValue indicating the success/failure of the populate process
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;

      try
      {
         getCursor();

      	//System.out.println("Processing " + cursor_.getRecordCount() + " assignment objects.");
      	//int i = 0;
      	while (cursor_.moveNext())		// for every assignment entry in the result set...
      	{
            //i++;
            //if ( (i % 100) == 0 )
            //   System.out.println("Completed processing " + i + " assignments at " + new Date());
            
            //
            // Create a remote ID for this assignment object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the assignment object already exists in the object space.
            //
            object = find(OBJ_ASSIGNMENT, id_);

            //
            // If the object found is an ABTObject, then the assignment object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new assignment object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray prms = new ABTArray();
               prms.add(object);      // identify the assignment object for update()
               object = update(prms);
            }
            else
            {
               object = create(null);
            }
      	}           // end while (cursor_.moveNext())
      }              // end try
      finally
      {
         closeCursor();
         /*#553*/
         if (resCursor_ != null)
            resCursor_.release();
      }

      return (ABTValue) null;
   }

   /**
    *    Creates a new object appropriate to this helper class.
    *    @param parms: an ABTArray of parameters meaningful to the create process
    *    @return the ABTObject created
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Get the associated task object reference for this assignment object.
      // Lookup the associated task in the task hash table.  This is a required param
      // for assignment object creation.
      //
      Long associatedTaskID = new Long(cursor_.getFieldInt(FLD_TASKID));
      ABTObject associatedTask = (ABTObject) ht_.get(associatedTaskID);

      //
      // Now get the associated resource object reference for this assignment object.
      // Lookup the associated resource in the resource hash table.  This is a required param
      // for assingment object creation.  If the associated resource came from the same
      // repository as the project being populated, it will be in the hash table of
      // resources.  If it's not there, we need to lookup the resource in the repository and find its
      // external ID.  We need to use the resource's external ID to find the resource in the space.
      //
      /*#553*/
      ABTValue resid = cursor_.getField(FLD_RESOURCEID);
      if (resID_ == null) resID_ = new ABTRemoteIDRepository();
      
      //
      // First, build a remote ID, assuming that the resource object was populated from the same
      // repository from which the current project is being populated.
      //
      resID_.setRepositoryID(repoID_);
      resID_.setPrID(resid.intValue());
      
      ABTObject associatedResource = (ABTObject) hr_.get(resID_);

      //
      // Was the resource object found?  If not, open up a repository cursor of all of the
      // project's resources.  The desired resource must be present in the repository.  It's
      // an error if it's not.
      //
      /*#553*/
      if (associatedResource == null)
      {
         if (resCursor_ == null)
         {
            resCursor_ = repo_.select(QRY_PROJECTRESOURCES);
            resCursor_.andFilter(TBL_RESOURCE + "." + FLD_ID + " = " + TBL_TEAM + "." + FLD_RESOURCEID);
            resCursor_.andFilter(TBL_TEAM + "." + FLD_PROJECTID + " = " + projectID_);
            resCursor_.setSort(TBL_RESOURCE + "." + FLD_ID);
         }
         
         if ( resCursor_.bsearchFirstInt(FLD_ID, resid.intValue()) )
         {
            ABTValue resExtID = resCursor_.getField(FLD_EXTERNALID);
            if ( resOs_ == null )
            {
               ABTObject site = (ABTObject) driver_.getSite();
               resOs_ = getObjectSet(site, OFD_RESOURCES);
            }
            
            //
            // Search for the resource object in the set of resource objects held by the
            // Site object in the object space.  It must be there.
            //
            ABTValue val = resOs_.select(userSession_, OFD_EXTERNALID + " = " + ABTString.normalizeQuotes((ABTString)resExtID) );
            if (ABTError.isError(val)) throw new ABTException((ABTError) val);
            ABTObjectSet os = (ABTObjectSet) val;
            if ( os.size(userSession_) > 0 )
               associatedResource = (ABTObject) os.at(userSession_, 0);
            else
               throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                                   "ABTIOPMWRepoAssignment->create",
                                                   errorMessages.ERR_ASSIGNMENT_RESOURCE_NOT_FOUND,
                                                   null));
   	      //
   	      // Since a resource can be associated with more than one assignment object, add this
   	      // resource object to the hash table of resources for quick lookup, in case it is needed
   	      // again.
   	      //
   	      hr_.put(resID_, associatedResource);
         }
         else
            throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                                "ABTIOPMWRepoAssignment->create",
                                                errorMessages.ERR_ASSIGNMENT_RESOURCE_NOT_FOUND,
                                                null));
      }           // end if (associatedResource == null)
      
      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_TASK, associatedTask);
      reqparms.putItemByString(OFD_RESOURCE, associatedResource);

      /*#637*/
      //
      // Can this driver be trusted to create a unique assignment for the given task?
      // It can be trusted only if the project is marked as READONLY.
      //
      ABTValue readonly = getValue(projObj_, OFD_READONLY);
      if ( readonly.booleanValue() )
         reqparms.putItemByString(kTRUSTED, ABTBoolean.True() );
      
      //
      // Ask the object space to create a new assignment object.  Check for errors
      // locally (here, in this method).  If an error occurred creating the 
      // assignment object, skip the assignment by returning null to the caller.
      //
      ABTValue v = createObject(OBJ_ASSIGNMENT, id_, reqparms, false);
      if (ABTError.isError( v )) 
         return null;
      
      //
      // Initialize repository properties of the new assignment object.
      //
      setValues((ABTObject) v);

      return v;
   }

   /**
    *    Updates an existing object appropriate to this helper class.
    *    @param parms: an ABTArray of parameters meaningful to the update process
    *    @return the ABTObject updated
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }


   private void setValues(ABTObject obj) throws ABTException
   {
      setPropertyValues(ps_, cursor_, obj);
   }

   public Hashtable getAssignmentHashtable() throws ABTException
   {
      ABTObjectSet aos = getObjectSet(projObj_, OFD_ALLASSIGNMENTS);
      int   size = aos.size(driver_.getUserSession());
      Hashtable ht = new Hashtable();

      //
      // For each assignment object in the set of all assignment objects for the current project,
      // create a Hashtable entry.  The hash table can be used for quick look-up of
      // assignments later in the populate process.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject obj = (ABTObject) aos.at(driver_.getUserSession(), i);
         ABTValue val = obj.getValue(driver_.getUserSession(), OFD_ID);
         if (ABTError.isError(val)) continue;
   	   ht.put(new Long(val.intValue()), obj);
      }

      return ht;
   }

   private void getCursor()
   {
   	//
   	// Select all the assignments for the desired project.  The following SELECT
   	// invocation is modeled from the FIX export/import C++ PVISION code.
   	// (see PVAssignmentTable object constructor in IMPASSGN.CPP.)
   	//
   	cursor_ = repo_.select(QRY_PROJECTASSIGNMENTS);
   	cursor_.andFilter(TBL_TASK + "." + FLD_PROJECTID + "=" + projectID_ +
   	                  " AND " +
   	                  TBL_TEAM + "." + FLD_PROJECTID + "=" + projectID_);
   }

   /**
    *    Saves objects appropriate to this helper object back to the ABT Repository.
    *    @param parms: an ABTArray containing parameters for the save process (currently none)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get an assignment cursor into the repository and set the sequence to be the prID, ascending.
      //
      getCursor();
      cursor_.setSort(TBL_ASSIGNMENT + "." + FLD_ID);
      String s = cursor_.getSort();

      //
      // Loop through all of the assignment objects and make sure the appropriate IDs for the
      // assignment's task and resource object references are set correctly in the assignment
      // object.  Set other properties, as appropriate.
      //
      ABTObjectSet assOs = getObjectSet(projObj_, OFD_ALLASSIGNMENTS);
      setSomeProperties(assOs);

      //
      // Save back all the assignment objects to the repository.
      //
      save(assOs);

      closeCursor();
   }

   private void setSomeProperties(ABTObjectSet assOs) throws ABTException
   {
      int size = size(assOs);

      ABTValue isUnplanned = new ABTBoolean(false);

      //
      // For every assignment object in this project, make sure each assignment's
      // reference ID to an associated task and associated resource is correct.
      // Since both tasks (pass 1) and team objects have been previously written to the
      // repository, any new tasks will have their respective prID fields
      // set into those objects.  The resource ID is obtained from the Team object, rather
      // than the Resource object because, during the saving of the Team object, the associated
      // Resource was verified to exist in the target repository.  It could happen that the 
      // Resource object was created new in the object space, but has an external ID that matches
      // a resource tuple in the Repository, but hasn't been populated by the Site repo driver yet.
      // In that case, the OFD_ID of that Resource object will not have been set.  The Team object,
      // however, has the correct ID of that Resource object.
      //
      // Set other properties, as appropriate.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject assmt = at(assOs, i);
         ABTObject task = getObject(assmt, OFD_TASK);
         ABTObject team = getObject(assmt, OFD_TEAM);
         ABTValue  resID = getValue(team,  OFD_RESOURCEID);
         setValue(assmt, OFD_TASKID, getValue(task, OFD_ID));
         setValue(assmt, OFD_RESOURCEID, resID);
         setValue(assmt, OFD_ISUNPLANNED, isUnplanned);
      }
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: a boolean value which indicates whether the data being added is new to the repository, i.e., the
    *             operation is an add.
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      //
      // Invoke the parent's isException() method.  If it says we shouldn't write the current field back
      // to the repository, then we must honor that.
      //
      if (super.isSaveException(prapiName, obj, prapiFlags, isNew))
         return true;

      //
      // We can never save the following fields for an assignment:
      //
      // prActSum, prBaseSum, prEstSum, prFinish, prStart
      //
      if (prapiName.equals(FLD_ACTSUM) ||
          prapiName.equals(FLD_BASESUM) ||
          prapiName.equals(FLD_ESTSUM) ||
          prapiName.equals(FLD_FINISH) ||
          prapiName.equals(FLD_START) )
         return true;

      boolean ret = false;    // assume NOT an exception

      //
      // The following logic conditionally allows/prohibits some assignment fields from being
      // written back based on values in other objects, and on whether the tuple being written
      // to the repository is new or previously existed.
      //
      // If the project's track mode is NOT 0 ("none") and the resource's track mode is NOT 0
      // ("none") then we cannot save prActCurve, prActThru, or prPendActSum.
      //
      if (prapiName.equals(FLD_ACTCURVE) ||
          prapiName.equals(FLD_ACTTHRU) ||
          prapiName.equals(FLD_PENDACTSUM))
         ret = trackModeNotZero(obj);
      else if (!isNew)
      {
         //
         // The following fields are read-only if an existing assignment tuple is
         // being written back to the repository.
         //
         if (prapiName.equals(FLD_RESOURCEID) ||
             prapiName.equals(FLD_STATUS) ||
             prapiName.equals(FLD_TASKID) )
            ret = true;
      }

      return ret;
   }
   private boolean trackModeNotZero(ABTObject obj) throws ABTException
   {
      //
      // If the project's track mode is zero, return false.
      //
      ABTValue projTrackMode = getValue(projObj_, OFD_TRACKMODE);
      if (projTrackMode == null ||
          projTrackMode instanceof ABTEmpty ||
          projTrackMode.intValue() == 0)
          return false;

      //
      // The project's track mode is not zero.  Check the resource's
      // track mode.  If the resource's track mode is zero, return false.
      //
      ABTObject res = getObject(obj, OFD_RESOURCE);
      ABTValue resTrackMode = getValue(res, OFD_TRACKMODE);
      if (resTrackMode == null ||
          resTrackMode instanceof ABTEmpty ||
          resTrackMode.intValue() == 0)
          return false;

      ///
      // Both the project's track mode and the resource's track mode are
      // nonzero.  Return true.
      //
      return true;
   }
}