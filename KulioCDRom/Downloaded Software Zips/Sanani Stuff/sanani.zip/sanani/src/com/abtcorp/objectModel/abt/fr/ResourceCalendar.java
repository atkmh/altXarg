package  com.abtcorp.objectModel.abt.fr;

/*
 * ResourceCalendar.java 08/21/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author         Description
 * 08-21-98       JSE         Initial Design
 * 09-22-98       SOB         Mods to support new onGet() logic, per Benoit
 *
 */

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.*;

/**
 * Field rule for the calendar in a resource. If the calendar has never been set,
 * then return the calendar for the site.
 *
 * @version	1.0
 * @author  Scott Ellis
 */

public class ResourceCalendar extends SiteFieldRule
{
   /**
    * Gets a resource calendar value.  If the current value of the resource calendar is null or empty, then return
    * an empty calandar whose parent calendar is the one specified in the resource object (OFD_BASECALENDAR).  Otherwise, 
    * return the resource's calendar object with its parent calendar newly-set to the base calendar.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The current value of the property
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue (ABTCalendar object) if successful, ABTError if not
    */
   protected ABTValue onGet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters )
   {
      ABTCalendar calendar = (ABTValue.isNull( myValue)) ? new ABTCalendar() : (ABTCalendar) myValue;
      
      //
      // Get the resource object's base calendar object (the object, not the blob property value)
      //
      ABTValue v = parent.getValue(session, OFD_BASECALENDAR, parameters);
      if ( ABTError.isError( v ) )
         return v;
      
      if ( v == null || v instanceof ABTEmpty )
      {
         //
         // Oops! It's not there.  Get the standard calendar from the Site object and make it
         // be the base calendar for the calendar being returned.
         //
         v = parent.getValue(session, OFD_SITE, parameters);
         if ( ABTError.isError( v ) )
            return v;
         ABTObject site = (ABTObject) v;
         v = site.getValue(session, OFD_STDCALENDAR, parameters);
         if ( ABTError.isError( v ) )
            return v;
      }
      
      ABTObject baseCalendarObj = (ABTObject) v;
      
      //
      // We have a valid calendar object which is the base calendar object for this resource.  Get 
      // the blob value of that calendar.  We will set that value as the parent calendar.
      //
      v = baseCalendarObj.getValue(session, OFD_VALUE, parameters);
      if ( ABTError.isError( v ) )
         return v;
      if ( v == null || (v instanceof ABTEmpty) )
         return new ABTError( "ResourceCalendar",
                              "onGet", 
                              errorMessages.ERR_BASE_CALENDAR, 
                              "Base calendar value is null or empty" );
                                   
      ABTCalendar baseCalendarVal = (ABTCalendar) v;
      
      //
      // Set the base calendar blob value as the parent of the calendar blob object we will
      // be returning to the caller.  The base calendar may have changed since the last time
      // the OFD_CALENDAR property was retrieved, and setting the parent now will correct
      // any discrepancy.
      //
      calendar.setParent( baseCalendarVal );
      return calendar;
   }
}
