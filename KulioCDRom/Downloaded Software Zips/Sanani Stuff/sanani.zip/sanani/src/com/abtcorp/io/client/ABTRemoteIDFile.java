package com.abtcorp.io.client;

/*
 * ABTRemoteIDRepository.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-02-98      SOB           Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */


/**
 *  ABTRemoteIDFile class implements the the IABTRemoteID interface for file drivers.
 *
 *  <pre>
 *			This class implements all methods of the IABTRemoteID interface.
 *       The purpose is to provide a way of uniquely identifying the remote source for
 *       an ABTObject.
 *
 *       Example:
 *       IABTObjectSpace ObjectSpace;  (just assume it gets set somehow)
 *			ABTRemoteIDFile id = new ABTRemoteIDFile();
 *       IABTHashTable requiredParameters = null;
 *
 *		   ...
 *
 *      --- set object specif TBD info -----
 *
 *       object = ObjectSpace.createObject("pm.Project", id, requiredParameters);
 *
 *       ...
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Pierson
 */

public class ABTRemoteIDFile extends com.abtcorp.core.ABTRemoteID
{

   /**
    *		Create a default ABTRemoteIDFile object.
    */
    public ABTRemoteIDFile()
    {
    }


    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return int 0 => equal, -1 => me < object2, 1 => me > object2
    */
    public int  compareTo  (Object object)
    {
      if (!(object instanceof ABTRemoteIDFile))
         return -1;
      return 0;
    }


     /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    public boolean   equals (Object object)
    {
      return compareTo(object) == 0 ? true : false;
    }

	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */

   public int hashCode()
   {
      return (int) 0;
   }

}