package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTProperty;

public class TaskData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public TaskData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_TASK) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = new Hashtable(50,(float).85); // Optimize for lots of potential tasks.

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();
         
         // Don't save session specific flags (created or modified during a session).
         if (property.getName().equals(FLD_TW_MODIFIED) || property.getName().equals(FLD_TW_CREATED)) continue;

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            // Object references are saved as ids, except for parent. Since parent can be a project or a task,
            // we'll save the entire hashtable of values for the parent and place a special key called "type" into
            // the hashtable to tell us what kind of object the parent is.
            if (property.getName().equals(FLD_TW_PROJECT) || property.getName().equals(FLD_TW_LAST) || property.getName().equals(FLD_TW_PREVIOUS) || property.getName().equals(FLD_TW_FIRST) || property.getName().equals(FLD_TW_NEXT)) {

               ABTValue object = object_.getValue(session_,property.getName());
               if (ABTError.isError(object) || ABTEmpty.isEmpty(object)) continue;

               ABTValue id = ((ABTObject)object).getValue(session_,FLD_TW_INTERNALID);
               table.put(property.getName(),id);

            } else if (property.getName().equals(FLD_TW_PARENT)) {

               ABTValue object = object_.getValue(session_,property.getName());
               if (ABTError.isError(object) || ABTEmpty.isEmpty(object)) continue;

               Hashtable parent = new Hashtable(2,(float)1.0); // Only two elements ever in this hashtable
               if (((ABTObject)object).getObjectType().equals(OBJ_TW_PROJECT)) {
                  parent.put("Type",OBJ_TW_PROJECT);
                  parent.put(FLD_TW_ID,((ABTObject)object).getValue(session_,FLD_TW_INTERNALID));
               } else {
                  parent.put("Type",OBJ_TW_TASK);
                  parent.put(FLD_TW_ID,((ABTObject)object).getValue(session_,FLD_TW_INTERNALID));
               }
               table.put(property.getName(),parent);
            }
            else if (property.getName().equals(FLD_TW_NOTES)) table.put(property.getName(),getNotes((ABTObjectSet)value));
            else if (property.getName().equals(FLD_TW_PROJECTID)) {
               ABTValue project = object_.getValue(session_,FLD_TW_PROJECT);   
               if (project instanceof ABTObject) {
                  table.put(property.getName(),((ABTObject)project).getValue(session_,FLD_TW_INTERNALID));
               }
            } else table.put(property.getName(),value);
         }
      }
      return table;
   }

   private void storeTask(String property, Hashtable table)
   {
      ABTValue temp = object_.getValue(session_,property);
      if (temp == null ||ABTEmpty.isEmpty(temp) || ABTError.isError(temp)) return;

      ABTObject task = (ABTObject)temp;
      try {
         TaskData data = new TaskData(task,session_);

         table.put(property,data.getValues());
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}
