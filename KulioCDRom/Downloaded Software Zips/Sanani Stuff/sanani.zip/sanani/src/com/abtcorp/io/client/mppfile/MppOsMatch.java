package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.idl.IABTPMRuleConstants;

//this is the "match" base class
//there is a one to one match  of
//mpp task to Object Space task
//or mpp resource to Object Space resource
//or mpp assignment to Object Space assignment
//or mpp successor to Object Space successor

public class MppOsMatch extends UpdateIndicator implements IABTPMRuleConstants
{

   private ABTValue        mppObject_;
   private IABTObject      osObject_;
   private ABTValue        mppKey_;
   private ABTValue        osKey_;
   public  boolean         toBeDeleted_;

   MppOsMatch(ABTValue mppAbtValue, IABTObject osObject, ABTValue mppKey)
   {

      mppObject_        =  mppAbtValue;
      osObject_         =  osObject;
      mppKey_           =  mppKey;
      toBeDeleted_      =  false;
   }

   MppOsMatch(IABTObject osObject, ABTValue mppAbtValue, ABTValue osKey)
   {

      mppObject_        =  mppAbtValue;
      osObject_         =  osObject;
      osKey_            =  osKey;
      toBeDeleted_      =  false;

   }

   MppOsMatch(IABTObject obj)
   {
         mppObject_        = null;
         osObject_         = obj;
         osKey_            = getRemoteId(obj);
   }

   MppOsMatch(ABTValue abtValue, ABTValue key)
   {
      if (abtValue instanceof IABTObject){

         mppObject_        = null;
         osObject_         = (IABTObject)abtValue;
         osKey_            = getRemoteId(((IABTObject) abtValue));

      } else {

         mppObject_        = abtValue;
         osObject_         = null;
         mppKey_           = key;

      }
   }

   public ABTRemoteID getRemoteId(IABTObject obj)
   {

      ABTClientMppRemoteID remoteID = null;

      ABTValue id = obj.getValue("ABTRemoteID");

      if ((id instanceof ABTRemoteID))
         return (ABTRemoteID)id;
      return null;
   }

   public ABTValue getMppKeyAbtValue()
   {
      return mppKey_;
   }

   public ABTValue getOsKeyAbtValue()
   {
      return osKey_;
   }

   public ABTValue getMppObject()
   {
      return mppObject_;
   }

   public IABTObject getOsObject()
   {
      return osObject_;
   }

   public void setMppKeyAbtValue(ABTValue key)
   {
      mppKey_ = key;
   }

   public void setOsKeyAbtValue(ABTValue key)
   {
      osKey_ = key;
   }

   public void setMppObject(ABTValue obj)
   {
      mppObject_ = obj;
   }

   public void setOsObject(IABTObject obj)
   {
      osObject_ = obj;
   }

   public void complete(IABTObject iAbtObject, ABTValue key)throws ABTException
   {

      osObject_ = iAbtObject;
      osKey_ = key;

      if (mppObject_ == null)
            throw new ABTException("mppObject_ was null when complete was called in MppOsMatch.java");

      if (mppKey_ == null)
            throw new ABTException("mppKey_ was null when complete was called in MppOsMatch.java");

      tagAsUpdated();
   }

   public void complete(ABTValue mppAbtValue, ABTValue key)throws ABTException
   {

      mppObject_ = mppAbtValue;
      mppKey_ = key;

      if (osObject_ == null)
            throw new ABTException("osObject_ was null when complete was called in MppOsMatch.java");

      if (osKey_ == null)
            throw new ABTException("osKey_ was null when complete was called in MppOsMatch.java");

      tagAsUpdated();

   }

   public void adjustMppWbs()
   {

      if (!(mppObject_ instanceof Task)) return;

      ABTValue wbsLevelAbtValue  =  osObject_.getValue(OFD_WBSLEVEL);

      Task mppTask = (Task) mppObject_;

      while (mppTask.getOutlineLevel() != wbsLevelAbtValue.shortValue()) {

         if (mppTask.getOutlineLevel() < wbsLevelAbtValue.shortValue()) mppTask.OutlineIndent();

         else mppTask.OutlineOutdent();

      }
   }

   //will outdent to a particular wbs level
   public void outdentTo(Task mppTask, int wbsLevel)
   {

      while (mppTask.getOutlineLevel() != wbsLevel) {

         if (mppTask.getOutlineLevel() > wbsLevel) mppTask.OutlineOutdent();

         else mppTask.OutlineOutdent();

      }
   }

   //this only applies to tasks
   //due to the fact that deleting a summary task
   //automatically will delete it's children
   //all it's children have to be outdented so they
   //do not get deleted

   public void deleteMppTask()
   {
      Task mppTask = (Task)mppObject_;

      if (mppTask.getSummary().shortValue() != 1)

            mppTask.Delete();

      else {

         Tasks tasks = mppTask.getOutlineChildren();
         Task task = tasks.getItem(new ABTInteger(1));
         task.OutlineOutdent(); //that will clear it of children
         mppTask.Delete();

      }
   }

   public void delete()
   {

      if (mppObject_ != null) {

         if (mppObject_ instanceof Task) {
            deleteMppTask();
         }
         else if (mppObject_ instanceof Task)
            ((Resource)mppObject_).Delete();
         else if (mppObject_ instanceof Task)
            ((Assignment)mppObject_).Delete();

      } else {       //if (osObject_!= null)

      }

   }
}
