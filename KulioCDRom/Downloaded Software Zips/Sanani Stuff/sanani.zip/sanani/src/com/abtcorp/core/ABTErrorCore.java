/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTErrorCore.java, 10, 12/7/98 5:24:07 PM, Hans-Joachim Birthelmer$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;
/*
 * ABTErrorCore.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-05-98	   HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



/**
 * Basic ABTErrorCore class - provides basic functionality for Error Handling
 * prepared for localization
 * <p>
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.core.ABTError
 */

public class ABTErrorCore extends ABTError
{
   private static final long serialVersionUID = -2382868325552986336L;
   final static int ERROROFFSET = 3000;
   /**
   *  default constructor
   *  @param component_ name of creator
   *  @param method_ name of routine creating it
   *  @param code_ error key
   */
   public ABTErrorCore(
               String component_,
               String method_,
               String code_,
               Object info_)
   {
      super("com.abtcorp.core",component_,method_,code_,info_);
   }
   public ABTErrorCore(
               String component_,
               String method_,
               ABTErrorCode code_,
               Object info_)
   {
      super(component_,method_,code_,info_);
   }

   /**
   *  default constructor
   *  @param component_ name of creator
   *  @param method_ name of routine creating it
   *  @param code_ ErrorCode
   */
   public ABTErrorCore(
            String component_,
            String method_,
            int code_,
            Object info_)
   {
      super("com.abtcorp.core",component_,method_,code_ + ERROROFFSET,info_);
   }


}