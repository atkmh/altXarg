package com.abtcorp.io;

/*
 * ABTDriver.java 03/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98      SA          Initial Implementation
  * 03-27-98		SOB			Initial Documentor
  * 03-31-98      SOB         Add default constructor & setSpace() method
  * 04-16-98      SOB         Changed ABTObjectSelector to String in populate() method
  * 04-30-98      SOB         open() returns boolean instead of void
  * 05-05-98      SOB         change addProperties() to support property names in ABTRepoDataDictionary form
  * 06-19-98      LZX         change addProperties() from package default to public.
  * 07-14-98      SOB         remove addProperties() and move it to ABTIOPreoHelper
  * 07-23-98      LZX         add getRulebase() and setRulebase().
  * 07-29-98      SDP         Stripped-out references to ABTObjectSpace and ABTUserSession
  * 08-11-98      SOB         Mods to support new public API
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import java.util.Enumeration;
import java.util.Vector;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTError;

/**
 *  ABTDriver is the base abstract class for all drivers which will access persistent data.
 *
 *			This class is not meant to be instantiated directly, but to be extended by
 *       special-purpose drivers which access persistent data in an application-specific
 *       way, e.g.,
 *
 *  <pre>
 *       public class ABTRepositoryDriver extends ABTDriver
 *       {
 *          ... add/override methods for repository-specific requirements ...
 *       }
 *
 *  </pre>
 *
 * @version	    $Revision: 20$
 * @author      S. Asire
 * @author		 S. Bursch
 */

public abstract class ABTDriver implements com.abtcorp.idl.IABTDriverConstants
{
/**
 *		Creates an ABTDriver that has no associated ABTObjectSpace.  If this
 *    constructor is used, the setSpace() method must be used subsequently
 *    to associate the driver with an ABTObjectSpace object.
 */

   public ABTDriver() {}


/**
 *		Opens a connection to a specific data source.
 *    @param args ABTHashtable of parameters
 *		@return ABTValue if an error occurred, an ABTError; otherwise, null.
 */

   public abstract ABTValue open(ABTHashtable args);

/**
 *		Populates the ABTObjectSpace with objects from the data source. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *    @param args ABTHashtable of parameters
 *		@return an ABTValue object, which is really an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.
 *		@exception ABTException  if an unrecoverable error occurs 
 */

   public abstract ABTValue populate(ABTHashtable args) throws ABTException;

/**
 *		Saves the ABTObjects identified in the ABTObjectSet object back to the data source.
 *    @param args ABTHashtable of parameters
 *		@exception ABTException  if an unrecoverable error occurs 
 */

   public abstract ABTValue save(ABTHashtable args) throws ABTException;

/**
 *		Closes a connection to a specific data source.
 *    @param args ABTHashtable of parameters
 *		@exception ABTException if an unrecoverable error occurs 
 */

   public abstract ABTValue close(ABTHashtable args) throws ABTException;


/**
 *    Processes an error situation raised by the caller.  If the severity level is 1, an
 *    exception is thrown.  For all other levels, a return to the caller is effected.
 *    @param severityLevel  level of severity of the error; low numbers are more severe
 *    @param objType type of Sanani object in trouble
 *    @param exceptionName exception identifier string
 *    @param errorMessage further text describing the error condition
 *    @return some sort of value (for now the severity level)
 *    @exception ABTException if the severity level is 1 (the highest severity)
 */
 public int processError(int severityLevel, String objType, String exceptionName, String errorMessage) throws ABTException
 {
   //
   // Construct a simple error message.
   //
   String s = ERR_OBJECTTYPE + objType + ", " + ERR_EXCEPTIONNAME + ", " + ERR_TEXT + errorMessage;

   //
   // Process this error.
   //
   // For severity 1 errors, throw an ABTException.
   // For other severity errors, decide what to do, perhaps writing to a log.
   //
   switch (severityLevel)
   {
      case SEVERITY_ONE:
         throw new ABTException(s);

      case SEVERITY_TWO:
      case SEVERITY_THREE:
      default:
         break;
   }

   return severityLevel;
 }

}