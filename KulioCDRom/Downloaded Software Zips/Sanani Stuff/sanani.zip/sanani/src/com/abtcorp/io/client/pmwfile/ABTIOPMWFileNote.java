package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileNote.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
//DEBUG
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTObjectSetIDList;



/**
 *  ABTIOPMWFileNote is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileNote fn = new ABTIOPMWFileNote(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileNote extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{   
    //DEBUG
     static  Vector  noteVector_      = null;

//====================================================================================
// Constructors
//====================================================================================
     
/**
 *    ABTIOPMWFileNote constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileNote(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_        = OBJ_NOTE;      
      noteVector_  = new Vector();
   }
   
//====================================================================================
// Populate Note from the Intermediate Hash Table
//====================================================================================

/**
 * Populate note object from the Intermediate Hash Table to the spce
 * @param Hashtable parms,
 * @return an ABTValue the team object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(Hashtable parms) throws ABTException 
   {
    ABTObjectSetIDList noteIDs   = null;    
    IABTObject         project   = null;
    IABTObject         targetObj = null;
    Object             object    = null;
        
    try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
            
        //Get the Target object which this note belongs to   
        object = parms.get(TARGET_OBJ);
        if (object instanceof IABTObject) 
            targetObj  = (IABTObject)object;
                     
        //Get the Note ID 
        object = parms.get(OFD_NOTES);
        if (object instanceof ABTObjectSetIDList) 
            noteIDs  = (ABTObjectSetIDList)object;
            
        Enumeration itID = noteIDs.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);
            reqparms.put(TARGET_OBJ, targetObj);
            reqparms.put(OFD_NOTES,(IABTLocalID)itID.nextElement());
            
            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }
    
   }

 /**
 * Create a new object in the object space and initialize it witha ppropriate values 
 * @param Hashtable parms 
 * @return ABTValue the newly created note
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {
    
      IABTLocalID noteID    = null;      
      IABTObject project   = null;
      IABTObject targetObj = null;
      Object object        = null;
      IABTObject noteObj   = null;
      
      //Get the Note ID 
      object = null;
      object = parms.get(OFD_NOTES);
      if (object instanceof IABTLocalID) 
         noteID  = (IABTLocalID)object;
            
      //Check if Note has already been created
        object = null;
        object = driver_.lookupTableGet(noteID);
        if ( object!= null && object instanceof IABTObject)
        {
         // TO DO UPDATE
           ;
        }
        else
        {
          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object; 
          
          
          //Get the Target object which this note belongs to 
          object = null;
          object = parms.get(TARGET_OBJ);
          if (object instanceof IABTObject) 
             targetObj  = (IABTObject)object;
             
          
          // Get the array of value associated with team
          IABTArray   noteArr  = null;
          object = null;
          
          object = driver_.intermediateTableGet(noteID);
          if (object instanceof IABTArray)
            noteArr = (IABTArray) object;
          
          //Get the property set associated with the note
          IABTPropertySet propSet = null;
          propSet = getProperties(type_); 
          
          //Get Note's Remote ID
          ABTValue  val = null;      
                    
          val = getHashValue(noteArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            noteObj = createObject(type_,(ABTRemoteID)val, null);    
          else if (ABTValue.isNull(val)) 
            noteObj = createObject(type_,(ABTRemoteID)null, null); 
          else
            new ABTException(" WRONG TYPE CAST");

          //Set Note's scalar values.  
          setScalarValues(propSet, noteArr, noteObj);
          
         //Add the Note to Target Object's Note List
         IABTObjectSet oSet;
         if (targetObj == null) 
            throw new ABTException (" The Note's Target Object is null.");
         else
         {
            oSet = getObjectSet(targetObj, OFD_NOTES);
            addListMember(oSet, noteObj);
         }
      
    }
    driver_.lookupTablePut(noteID, noteObj);   
    return (ABTValue)noteObj;
}
//====================================================================================
// Save Note to an Intermediate Hash Table
//====================================================================================
   
/**
 * Saves note objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms 
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
        IABTObject project = null;
        
        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
    
        if (project == null)
            throw new ABTException("The current project is null.");
    
        if (project == null)
            throw new ABTException("The current project is null.");

        IABTObjectSet prjNoteOs   = getObjectSet(project, OFD_NOTES);
        saveNotes(prjNoteOs);
        IABTObjectSet taskNoteOs  = getObjectSet(project, OFD_ALLTASKS);
        saveNoteSet(taskNoteOs);
        IABTObjectSet assgnNoteOs = getObjectSet(project, OFD_ALLASSIGNMENTS);
        saveNoteSet(assgnNoteOs);
        IABTObjectSet teamOs = getObjectSet(project, OFD_TEAMRESOURCES);
        for (int i =0; i < size(teamOs); i++)
        {
            IABTObject team = (IABTObject)at(teamOs, i);
            IABTObject resource = (IABTObject)getObject(team, OFD_RESOURCE);
            IABTObjectSet resourceNoteOs = getObjectSet(resource, OFD_NOTES);
            saveNotes(resourceNoteOs);
        }
   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


 private void saveNoteSet(IABTObjectSet oSet) throws ABTException
 {
    int size = size(oSet);
    for (int i =0; i<size; i++)
    {
        
        IABTObject obj = (IABTObject)at(oSet, i);
        IABTObjectSet noteOs =  getObjectSet(obj, OFD_NOTES);
       // for (int j =0; j < size(noteOs); j++)
       // {
           // IABTObject  noteObj     = (IABTObject)at(noteOs, j);
           // saveNote(noteObj);
      //  }
      saveNotes(noteOs);
        
    }
 }

private void saveNotes(IABTObjectSet noteOs) throws ABTException
{
    for (int j =0; j < size(noteOs); j++)
        {
            IABTObject  noteObj     = (IABTObject)at(noteOs, j);
            // Make sure the object is of type note
            if (!noteObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the note in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(noteObj);
            if (arr==null)
                throw new ABTException("The arr of note values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID noteId = noteObj.getID();
            if (noteId == null)
                throw new ABTException("note ID is null.");
                                        
            
            if  (( driver_.intermediateTableGet(noteId)) != null)
                if (( driver_.intermediateTablePut(noteId, arr)) != null)
                   throw new ABTException("The note ID already exist.");
                else
                    //DEBUG
                    noteVector_.addElement(noteId);
        }
       
}


}