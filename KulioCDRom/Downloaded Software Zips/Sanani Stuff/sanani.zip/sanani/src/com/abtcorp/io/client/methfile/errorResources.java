package com.abtcorp.io.client.methfile;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_EXCEPTION_OCCURED.getCode(),"An Exception occured"},

 };
}