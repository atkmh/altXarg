
package com.abtcorp.hub;

/*
 * ABTRowComparator.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *                             
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

public class ABTObjectComparator implements ABTComparator
{    
   
  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compare(Object object1, Object object2)
   {
      if ((object1 instanceof ABTID) && (object2 instanceof ABTID))
         return ((ABTID)object1).compareTo((ABTID)object2);      
      if ((object1 instanceof ABTRow) && (object2 instanceof ABTID))
         return ((ABTRow)object1).getID().compareTo((ABTID)object2);      
      if ((object1 instanceof ABTRow) && (object2 instanceof ABTRow))
         return ((ABTRow)object1).getID().compareTo(((ABTRow)object2).getID());      
      if ((object1 instanceof ABTID) && (object2 instanceof ABTRow))
         return ((ABTID)object1).compareTo(((ABTRow)object2).getID());      
      return 0; 
   }

}

