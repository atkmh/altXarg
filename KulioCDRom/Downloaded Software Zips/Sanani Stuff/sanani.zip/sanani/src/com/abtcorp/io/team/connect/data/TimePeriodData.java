package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTProperty;

public class TimePeriodData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public TimePeriodData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_TIMEPERIOD) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            if (property.getName().equals(FLD_TW_TIMESHEETS)) continue; // FLD_TW_TIMESHEETS is a virtual field.
            else table.put(property.getName(),value);
         }
      }
      return table;
   }
}
