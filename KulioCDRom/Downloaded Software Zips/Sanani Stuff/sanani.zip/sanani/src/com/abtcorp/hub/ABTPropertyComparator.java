
package com.abtcorp.hub;

/*
 * ABTPropertyComparator.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

public class ABTPropertyComparator implements ABTComparator
{
  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compare(Object object1, Object object2)
   {
      if ((object1 instanceof ABTProperty) && (object2 instanceof ABTProperty))
         return ((ABTProperty)object1).compareTo((ABTProperty)object2);
      if ((object1 instanceof ABTProperty) && (object2 instanceof String))
         return ((ABTProperty)object1).compareTo((String)object2);
      if ((object2 instanceof ABTProperty) && (object1 instanceof String))
         return -(((ABTProperty)object2).compareTo((String)object1));
      if ((object1 instanceof ABTProperty) && (object2 instanceof ABTString))
         return ((ABTProperty)object1).compareTo(((ABTString)object2).stringValue());
      if ((object2 instanceof ABTProperty) && (object1 instanceof ABTString))
         return -((ABTProperty)object2).compareTo(((ABTString)object1).stringValue());
      return 0;
   }

}

