/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * .
 */
package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.core.ABTValue;
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;

class ValueMunger
{
   static public Object MarshalIn(Object caller, ABTValue v)
      {
      if (v instanceof IABTActiveProgressListener)
         return new ABTActiveProgressListenerLocal((IABTActiveProgressListener)v);

      if (v instanceof IABTProgressListener)
         return new ABTProgressListenerLocal((IABTProgressListener)v);

      if (v instanceof ABTSessionObject)
         return ((ABTSessionObject)v).getObject();


      // it's an ABTValue, but it's not a local api wrapper object
      // check to see that it's an un-marshalable object
      if (v instanceof com.abtcorp.core.ABTHashtable)
         return new ABTError(caller.getClass(),"MarshalIn", errorMessages.ERR_ILLEGAL_HASHTABLE, null);
      if (v instanceof com.abtcorp.core.ABTSortedArray)
         return new ABTError(caller.getClass(),"MarshalIn", errorMessages.ERR_ILLEGAL_ARRAY, null);
      if (v instanceof com.abtcorp.core.ABTArray)
         return new ABTError(caller.getClass(),"MarshalIn", errorMessages.ERR_ILLEGAL_SORTED_ARRAY, null);

      return v;
      }


   static public ABTValue MarshalOut(ABTSessionObject s, Object val) {
      if (val instanceof com.abtcorp.hub.ABTObject) {
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTObjectLocal(s,(com.abtcorp.hub.ABTObject)val);
         }

      if (val instanceof com.abtcorp.hub.ABTObjectSet){
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTObjectSetLocal(s,(com.abtcorp.hub.ABTObjectSet)val);
         }

      if (val instanceof com.abtcorp.core.ABTHashtable){
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTHashTable(s,(com.abtcorp.core.ABTHashtable)val);
         }

      if (val instanceof com.abtcorp.core.ABTArray){
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTArrayLocal(s,(com.abtcorp.core.ABTArray)val);
         }

      if (val instanceof com.abtcorp.core.ABTSortedArray){
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTArrayLocal(s,(com.abtcorp.core.ABTSortedArray)val);
         }

      if (val instanceof ABTExtendedPropertyList){
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTExtendedPropertyListLocal(s,(ABTExtendedPropertyList)val);
         }

      if (val instanceof ABTID){
         if (s.getUserSession() == null)
            return new ABTError(s.getClass(),"MarshalOut",errorMessages.ERR_INVALID_OBJSPACE, null);
         return new ABTLocalID(s,(ABTID)val);
         }

      if (val instanceof ABTError){
         ABTError inVal = (ABTError) val;
         Object info = inVal.getInfo();
         // check the info object to see if it needs marhsalling
         if (info == null || (info instanceof ABTSessionObject))
            return inVal; // it's fine.  pass it up

         // If it's an ABTValue, marshal it out and
         // roll the error object into a new one,
         if (info instanceof ABTValue){
            ABTValue vinfo = null;
            vinfo = MarshalOut(s, (ABTValue)info);
            return new ABTError(inVal.getComponent(),
                                inVal.getMethod(),
                                inVal.getErrorCode(),
                                vinfo);
            }
         
         // It's not an ABTValue, if it's serializable, leave it alone
         if (info instanceof java.io.Serializable)
            return inVal;

         }

      return (ABTValue)val;
      }
}