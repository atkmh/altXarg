package com.abtcorp.io.client;
/*
 * ABTIOFileHelper.java 07/14/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date       Author         Description
  * 07-16-98   MXA            Initial Implementation
  */

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;

import com.abtcorp.idl.IABTObjectSpace;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTEmpty;

/**
 *  ABTIOFileHelper is an abstract class that contains useful methods.
 *	It is extended by various ABT file helper classes.
 *
 *  </pre>
 *		  ABTIOFileHelper fh = new ABTIOFileHelper(ABTObjectSpace space, ABTUserSession session);
 *
 *  </pre>
 *
 * @version	1.0
 * @author  M. Abadian
 * @see     ABTIOHelper
 */

public abstract class ABTFileHelper extends ABTClientHelper
{

    private Hashtable propertyTable_ = null;

/**
 * ABTIOFileHelper default constructor. Associating an object space
 * and user session with this class will be deferred until later.
 */
    public ABTFileHelper() { /* implicit call to super() here */ }

/**
 * ABTIOFileHelper constructor.
 * @param space: the reference to the object space.
 * @param session: the user session
 */
   public ABTFileHelper(IABTObjectSpace space)
   {
    super();
   }
 
}