package com.abtcorp.objectModel.abt.fr;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_INVALID_VALUE.getCode(),"Invalid value"},
{ERR_OPERATION_DENIED.getCode(),"Operation denied"},
{ERR_INVALID_TYPE.getCode(),"Invalid Type"},
{ERR_BASE_CALENDAR.getCode(),"Base calendar value access error"},
{ERR_DUPLICATE_DETECTED.getCode(),"Duplicate Detected"},
{ERR_DOH_DOT.getCode(),"DOH/DOT must be an ABTDate or ABTTime"},
{ERR_GUIDELINE.getCode(),"Error in forming guideline"},
{ERR_CIRCULAR_REFERENCE.getCode(),"Circular Reference Error"},
{ERR_DATA_CONVERSION.getCode(),"Data conversion failed"},
{ERR_SITE_ACCESS.getCode(),"Site Access Error"},

 };
}