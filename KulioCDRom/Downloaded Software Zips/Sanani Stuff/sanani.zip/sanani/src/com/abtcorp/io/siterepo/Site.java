package com.abtcorp.io.siterepo;

/*
 * Site.java 07/17/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 07-17-98    LZX         Initial Implementation
 * 08-04-98    SOB         Mods to support importing of com.abtcorp.io.server.*;
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.objectModel.abt.*;
import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  Site is a helper class for the ABT Repository site/global driver.
 *  It is instantiated by the site driver.
 *
 *  <pre>
 *       Site pp = new Site(driver, null);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTSiteRepoDriver
 */

public class Site extends ABTSiteRepoHelper 
{
   private Long calID_;

/**
 *    Site constructor.
 *    @param   driver: the reference to the driver.
 */
   Site(ABTRepositoryDriver driver)
   {
      super(driver, null, TBL_SITE, OBJ_SITE);
      matchField_ = null;
   }


/**
 * Populate the site object. This overrides the populate() in super class.
 * @return ABTValue: the desired object or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
	   ABTValue object = null;             
   	ABTObjectSet oSet = null;
   
      // select site cursor and set the sort order to prID. In case there are
      // more than 1 rows in the site cursor, we will use the oldest one.
      cursor_ = getCursor(QRY_SITE, table_ + "." + FLD_ID);
      
      try
      {
      	while (cursor_.moveNext())		// for every row in the result set...
      	{
            long prID = cursor_.getFieldInt(FLD_ID);
            ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID);
            
            // See if the object already exists in the object space. If found, replace it with 
            // the new site data regardless where the old site object came from.
            object = driver_.getSite();

            if (object instanceof ABTObject)
            {
               // if found, update/merge
               object = update(cursor_, (ABTObject)object, id, true);
            }
            else
            {
               // if not found, create an object for this site in the 
               // object space and set its property values.
               object = create(cursor_, type_, id, null);                
            }
            
            // populate the type code, charge code and base calendar objects
            // that are associate with this site.
            populateOthers((ABTObject)object);
            
            // jump out of the loop after populating the 1st row (there is only
            // one site object in the space).
            break; 
            
      	}  // end while()
      }
      finally
      {
         closeCursor(cursor_);
      }

      return object;
	}



/**
 *  Set site property values.
 *  @param       ps: the aggfield property hash.
 *  @param       cur: the aggfield cursor.
 *  @param       obj: the aggfield object.
 *  @return      the aggfield object or error
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps, ABTCursor cur, ABTObject site) throws ABTException
   {
      // first set the scalar property values
      setPropertyValues(ps, cur, site);
      
      // since week start is 0-based in repository and 1-based in sanani(Java),
      // we need to add 1 to it when populate.
      setValue(site, OFD_WEEKSTART, new ABTInteger(cur.getFieldInt(FLD_WEEKSTART)+1));

      // save the site calendar id for later use
      calID_ = new Long (cur.getFieldInt(FLD_CALENDARID));
/*
      // then set site calendar blob explicitly (it's a virtual field in PRSITE table
      // and was skipped in setPropertyValues())
      // will remove this when the rule for getting this virtual field is in place
      setValue(site, OFD_CALENDAR, cur.getField(FLD_CALENDAR));
      
      // then set site calendar object reference
      ABTValue calID = getValue(site, OFD_CALENDARID);
      Calendar helper = new Calendar(driver_, site);
      ABTValue val = helper.populate(null, QRY_SITECALENDAR + calID.intValue());      
      
      // there should be only one site calendar object found
      if (val instanceof ABTObject)
      {         
         // set the site calendar object reference.
         setValue(site, OFD_STDCALENDAR, (ABTObject)val);
      }
      else
      {
         processError("setValues",
                  errorMessages.ERR_RECORD_NOT_FOUND,
                  "Site calendar is not found in the repository." );
      }
*/      
   }


/**
 * Populate subordinate objects, set references, etc.. 
 * @param cur  the cursor used to populate.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   protected void populateOthers(ABTObject site) throws ABTException
   {
   	// populate the type codes
      TypeCode tcHelper = new TypeCode(driver_, site);
      tcHelper.populate(OFD_TYPECODES, QRY_TYPECODES);

      // populate the charge codes
      ChargeCode ccHelper = new ChargeCode(driver_, site);
      ccHelper.populate(OFD_CHARGECODES, QRY_CHARGECODES);

      // populate the base calendars
      Calendar calHelper = new Calendar(driver_, site);
      calHelper.populate(OFD_CALENDARS, QRY_BASECALENDARS);

      // wire the site calendar reference...
      
      // retrieve the calendar hash table
      Hashtable calHash = calHelper.getHash();
      
      // find the site calendar object reference in calendar hash table
      ABTObject cal = (ABTObject) calHash.get(calID_);
      if (cal == null)
         processError("populateOthers",
                     errorMessages.ERR_OBJECT_NOT_FOUND,
                     "Site calendar not found in hash table. prID = " + calID_.toString());

      // set the site calendar object reference
      setValue(site, OFD_STDCALENDAR, cal);
      
   }


}
