package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import com.abtcorp.idl.IABTPMRuleConstants;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;

import com.abtcorp.core.*;
//import com.abtcorp.core.ABTDate;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.blob.ABTCalendar;
import com.abtcorp.blob.ABTCurve;

//import com.abtcorp.blob.*;

public class ABTClientMppAssignments extends ABTClientMppHelper
{
    private boolean                 populateFully_          = false;
    private boolean                 previouslyExisted_      = false;
    private boolean                 forceNewSave_           = false;
	 private ABTRemoteID             remoteId_               = null;
    private Project                 mppProject_             = null;
    private IABTObject              projectObject_          = null;
    private MppFormat               utl_                    = null;

    public ABTClientMppAssignments() {/* implicit call to super() here */}

    public ABTClientMppAssignments( IABTObjectSpace space,
							   ABTClientMppDriver    driver,
							   Project               mppProject,
							   boolean               populateFully,
                        ABTClientMppTasks     abtClientMppTasks,
                        ABTClientMppResources abtClientMppResources,
                        MppFormat             format,
                        IABTObject            project
                )
	{
		super( space, driver );
		mppProject_             = mppProject;
		populateFully_          = populateFully;
      utl_                    = format;
      projectObject_          = project;

	}

    //save constructor

    public ABTClientMppAssignments(
                        IABTObjectSpace         space,
							   ABTClientMppDriver      driver,
                        IABTObject              projectObject,
							   Project                 mppProject,
                        MppFormat               format

                )
	{

		super( space, driver );
		mppProject_          = mppProject;
      utl_                 = format;
      projectObject_       = projectObject;
	}

	public boolean previouslyExisted() {return previouslyExisted_;}

   //   Pattern is:
   //   iterate item, task or resource or assigment or dependency
   //   once you have a valid object go through these 4 steps
   //   1.createRemoteId
   //   2.createReturnValue = create(parms); with it's params (ahead of it)
   //   3.checkCreateReturnValue(createReturnValue) and throw abterror if necessary
   //   4.setValues();

	public ABTValue populate() throws ABTException
	{

		ABTValue  createReturnValue         = null;

      Enumeration assignmentsEnumerator   = utl_.map_.getAssignmentsEnumeration(mppProject_, true);

      while (assignmentsEnumerator.hasMoreElements()) {

         MppOsAssignmentMatch match = (MppOsAssignmentMatch) assignmentsEnumerator.nextElement();

         createRemoteId(match);

         ABTValue assignmentAbtValue = find(OBJ_ASSIGNMENT, remoteId_);

         if (!utl_.isFound(assignmentAbtValue)) {

            // *** ADD

            ABTArray parms = new ABTArray(); parms.add(match);

            createReturnValue = create(parms);

            checkCreateReturnValue(createReturnValue);

            utl_.map_.complete(match, (IABTObject) createReturnValue, remoteId_);

            setValues(match, (IABTObject) createReturnValue);


         } else {

            // *** UPDATE

            utl_.map_.complete(match, (IABTObject) assignmentAbtValue, remoteId_);

            setValues(match, (IABTObject) assignmentAbtValue);
         }

      }

      // *** Delete

      IABTObjectSet assignmentObjectSet = utl_.osGetObjectSet(projectObject_, OFD_ALLASSIGNMENTS);

      if (assignmentObjectSet != null){

         for (int j = 0; j < assignmentObjectSet.size(); j++) {

            IABTObject assignmentObject = (IABTObject) assignmentObjectSet.at(j);

            remoteId_ = utl_.getRemoteId(assignmentObject);

            if (!utl_.map_.hasBeenUpdated(remoteId_, assignmentObject))

               assignmentObject.delete();

         }

      }

      return createReturnValue;

   }

   private void checkCreateReturnValue(ABTValue createReturnValue) throws ABTException
   {
   	if ( ABTError.isError(createReturnValue))
	      throw new ABTException(((ABTError)createReturnValue).getMessage());
   }

   private void createRemoteId(MppOsAssignmentMatch match)
   {

      Assignment mppAssignment = match.getMppAssignment();

      remoteId_ = new ABTClientMppRemoteID(  mppProject_.getFullName(),
	                  							   mppAssignment.getUniqueID()
                                          );
   }

	protected ABTValue create(ABTArray params) throws ABTException
	{

      MppOsAssignmentMatch match = (MppOsAssignmentMatch) params.at(0);

      Assignment mppAssignment   = match.getMppAssignment();
      IABTObject resourceObject  = match.getOsResource();
      IABTObject taskObject      = match.getOsTask();

      IABTHashTable reqparms = space_.newABTHashTable();

      reqparms.putItemByString(OFD_TASK,      (ABTValue) taskObject);
      reqparms.putItemByString(OFD_RESOURCE,  (ABTValue) resourceObject);

		ABTValue object = null;

      object = (ABTValue) createObject(OBJ_ASSIGNMENT, remoteId_, reqparms);

      return object;
	}

   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e     = parms.elements();
      ABTValue object   = (ABTValue) e.nextElement();
      if (!populateFully_) return object;

//    setValues(ps, object);

      return object;
   }

	private void setValues(MppOsAssignmentMatch match, IABTObject assignmentObject) throws ABTException
	{

      match.setOsObject(assignmentObject);
      match.tagAsUpdated();

      Assignment mppAssignment = match.getMppAssignment();

      IABTObject  resourceObject    = utl_.osGetObject   (assignmentObject,   OFD_RESOURCE);
      IABTObject  taskObject        = utl_.osGetObject   (assignmentObject,   OFD_TASK);
      ABTCalendar resourceCalendar  = utl_.osGetCalendar (resourceObject,     OFD_CALENDAR);
   	ABTValue    unitsAbtValue     = mppAssignment.getUnits();

      int               resourceUniqueId  = mppAssignment.getResourceUniqueID();
      Resources         resources         = mppProject_.getResources();
   	Resource          resource          = resources.getUniqueID(resourceUniqueId);
     	ABTValue          maxUnitsAbtValue  = resource.getMaxUnits();

      if (unitsAbtValue.doubleValue() != maxUnitsAbtValue.doubleValue())
         utl_.osSetDouble(OFD_ESTMAX, unitsAbtValue, assignmentObject);

      utl_.osSetBoolean (OFD_ISUNPLANNED, false,                   assignmentObject);

	   // get assignment start... guessing MSP's order of attack:

	   ABTTime assignmentStart = utl_.getMppTime(mppAssignment.getStart());

	   // assignment start... might be NA

      Task task = match.getMppTask();

	   ABTTime resume		= utl_.getMppTime(task.getResume());
	   ABTTime finish		= utl_.getMppTime(task.getFinish());

	   int	delay		   = mppAssignment.getDelay().intValue()        *60;
	   int	totalWork	= mppAssignment.getWork().intValue()         *60;
	   int	actualWork	= mppAssignment.getActualWork().intValue()   *60;
	   int	plannedWork = mppAssignment.getBaselineWork().intValue() *60;

   	// Now... walk through the ActCurve/EstCurve one segment at a time...

      String x = assignmentStart.toString();

      //***	   ABTTime	tmpStart = resourceCalendar.subWorktime(assignmentStart, delay);
      ABTTime tmpStart = assignmentStart;    //until subworktime works
   	// import actual... only if not tracked and they didn't disable the MSP actuals

   	// ***** IMPORT ACTUALS

      boolean actualFlag = trackModeNotZero(assignmentObject);

	if (actualFlag ) {

   //		assignmentCursor->setFieldNull(FLD_ACTCURVE);	// clear to eliminate impact of biz rules
   //		assignmentCursor->setFieldNull(FLD_ACTTHRU);		// ditto

		ABTCurve curve = new ABTCurve(ABTCurve.VALUECURVE);

		if (actualWork > 0) {

			if (delay > 0) {  // zero segment for Delay... goes in the ActCurve if there is one

				ABTTime tmpFinish = resourceCalendar.addWorktime(tmpStart, delay);

				curve.setSegment(tmpStart, tmpFinish, 0, resourceCalendar);

				tmpStart = tmpFinish; // advance the start... (now it's the potential start of actual work)

			}

			// actual work segment

			ABTTime tmpFinish = resourceCalendar.addWorktime(tmpStart, (int)(actualWork/unitsAbtValue.doubleValue()));

			if (tmpFinish.compareTo(resume) > 0) tmpFinish = resume;

			curve.setSegment(tmpStart, tmpFinish, actualWork, resourceCalendar);

			tmpStart = tmpFinish; // advance the start again... (now it's the potential start of remaining work)
		}

      assignmentObject.setValue(OFD_ESTCURVE,   curve);
      assignmentObject.setValue(OFD_ACTTHRU,    resume);

	} else { // due to ini flag estimate start has not been set  so it will be set now
		if (actualWork > 0) {

			if (delay > 0) tmpStart = resourceCalendar.addWorktime(tmpStart, delay);

			tmpStart = resourceCalendar.addWorktime(tmpStart, (int)(actualWork / unitsAbtValue.doubleValue()));

		}
	}

	// import remaining... always

	// if there's a resume, remaining gets "bumped" past it

	if (tmpStart.compareTo(resume) < 0) tmpStart = resume;

	// remaining work is generally total-actual, but, if actualFlag is off (tracked is on),
	// we decrement by the actuals IN THE REPOSITORY so as to account for "new" actuals

	double remainingWork;

   double actSum = getActSum(assignmentObject);

	if (actualFlag) remainingWork = totalWork - actualWork;
	else				 remainingWork = totalWork - actSum;

	// ***** IMPORT REMAINING

	ABTCurve curve = new ABTCurve(ABTCurve.VALUECURVE);

	if (remainingWork > 0) {
		// remaining work segment

		if (actualWork == 0 && delay > 0) {	// zero segment for delay, goes in EstCurve only if it didn't belong in ActCurve

			ABTTime tmpFinish = resourceCalendar.addWorktime(tmpStart, delay);

			curve.setSegment(tmpStart, tmpFinish, 0, resourceCalendar);

			tmpStart = tmpFinish; // advance the start... (now it's the potential start of remaining work)
		}

		ABTTime tmpFinish = resourceCalendar.addWorktime(tmpStart, (int) (remainingWork/unitsAbtValue.doubleValue()));

		if (tmpFinish.compareTo(finish) > 0) tmpFinish = finish;

		curve.setSegment(tmpStart, tmpFinish, remainingWork, resourceCalendar);

		tmpStart = tmpFinish;
	}

   assignmentObject.setValue(OFD_ESTCURVE, curve);


	ABTTime assignmentFinish = tmpStart;	// will need this for the baseline curve

	// ***** IMPORT BASELINE

	curve = new ABTCurve(ABTCurve.VALUECURVE);

	if (plannedWork > 0) curve.setSegment(assignmentStart, assignmentFinish, plannedWork, resourceCalendar);

      assignmentObject.setValue(OFD_BASECURVE, curve);

	}

   // -------------------------------------------------------------------------------
   // save logic begins here.
   // -------------------------------------------------------------------------------

   /**
    *    Saves a Project object to an MPP file
    *    @param parms contains the save parameters for the ABTDispatch invoke() call
    *    @exception ABTException if an unrecoverable error occurs
    */

   public IABTObject getCorespondingTaskObject(Task mppTask)
   {

      int         taskUniqueId   = mppTask.getUniqueID();

      ABTClientMppRemoteID remoteId = new ABTClientMppRemoteID
                                       (
                                       mppProject_.getFullName(),
                                       mppTask.getUniqueID()
                                       );

      ABTValue taskAbtValue = find(OBJ_TASK, remoteId);

		if (!ABTError.isError(taskAbtValue)) return (IABTObject) taskAbtValue;

      return null;

   }

   public IABTObject getCorespondingResourceObject(Assignment mppAssignment)
   {

      int         resourceUniqueId   = mppAssignment.getResourceUniqueID();

      ABTClientMppRemoteID remoteId = new ABTClientMppRemoteID
                                       (
                                       mppProject_.getFullName(),
                                       resourceUniqueId
                                       );

      ABTValue resourceAbtValue = find(OBJ_RESOURCE, remoteId);

		if (!ABTError.isError(resourceAbtValue)) return (IABTObject)resourceAbtValue;

      return null;

   }

   public IABTObject getCorespondingAssignmentObject(Assignment mppAssignment)
   {

      int         assignmentUniqueId   = mppAssignment.getUniqueID();

      ABTClientMppRemoteID remoteId = new ABTClientMppRemoteID
                                       (
                                       mppProject_.getFullName(),
                                       mppAssignment.getUniqueID()
                                       );

      ABTValue assignmentAbtValue = find(OBJ_ASSIGNMENT, remoteId);

		if (!ABTError.isError(assignmentAbtValue))return (IABTObject)assignmentAbtValue;

      return null;

   }

   public ABTValue save() throws ABTException
   {

      Enumeration mppAssignmentsEnumerator   = utl_.map_.getAssignmentsEnumeration(mppProject_, true);

      //******************************** Update ******************************

      while (mppAssignmentsEnumerator.hasMoreElements()) {

         MppOsAssignmentMatch match = (MppOsAssignmentMatch) mppAssignmentsEnumerator.nextElement();

         createRemoteId(match);

         ABTValue assignmentAbtValue = find(OBJ_ASSIGNMENT, remoteId_);

         if (utl_.isFound(assignmentAbtValue)) {

            IABTObject assignmentObject = (IABTObject) assignmentAbtValue;

            utl_.map_.complete(match, assignmentObject, remoteId_);

            if (match.getOsTask().getValue(OFD_ISTASK).booleanValue())

               getValues(match, assignmentObject);

         }
      }
      //******************************** ADD ******************************

      IABTObjectSet assignmentObjectSet = utl_.osGetObjectSet(projectObject_, OFD_ALLASSIGNMENTS);

      if (assignmentObjectSet != null){

         for (int j = 0; j < assignmentObjectSet.size(); j++) {

            IABTObject assignmentObject = (IABTObject) assignmentObjectSet.at(j);

            remoteId_ = utl_.getRemoteId(assignmentObject);

            if (!utl_.map_.hasBeenUpdated(remoteId_, assignmentObject)) {

               MppOsAssignmentMatch match = createAssignmentMatch(assignmentObject);

               utl_.map_.mppAdd(match);

               Assignment mppAssignment = createMppAssignment(match);

               utl_.map_.complete(mppAssignment, new ABTInteger(mppAssignment.getUniqueID()), match);

               if (match.getOsTask().getValue(OFD_ISTASK).booleanValue()) //may change

                  getValues(match, assignmentObject);

               createRemoteId(match);

               utl_.osSetRemoteId(remoteId_, assignmentObject); //once added it has a different remote id

            }
         }
      }

      //******************************** Delete ******************************

      mppAssignmentsEnumerator = utl_.map_.getAssignmentsEnumeration(mppProject_, false);

      while (mppAssignmentsEnumerator.hasMoreElements()) {

         MppOsMatch match = (MppOsMatch) mppAssignmentsEnumerator.nextElement();

         if (!match.hasItBeenUpdated()) utl_.map_.delete(match);

		}

      utl_.map_.removeToBeDeleted();

      return null;

   }

   MppOsAssignmentMatch createAssignmentMatch(IABTObject osAssignment)
   {

      IABTObject taskObject = (IABTObject)osAssignment.getValue(OFD_TASK);
      IABTObject resourceObject = (IABTObject)osAssignment.getValue(OFD_RESOURCE);

      MppOsMatch taskMatch       = utl_.map_.getTaskMatch(taskObject);
      MppOsMatch resourceMatch   = utl_.map_.getResourceMatch(resourceObject);

      return new MppOsAssignmentMatch(
                                 osAssignment,
                                 taskMatch,
                                 resourceMatch
                                 );
   }

   public Assignment createMppAssignment(MppOsAssignmentMatch match)
   {
      Task     mppTask     = utl_.map_.getCorespondingTaskObject(match.getOsTask());

      Resource mppResource = utl_.map_.getCorespondingResourceObject(match.getOsResource());

      Assignments assignments = mppTask.getAssignments();

      return assignments.Add(new ABTInteger(mppTask.getID()), new ABTInteger(mppResource.getID()), new ABTInteger(1));
   }

   private ABTTime getObjectSpaceAssignmentStart(ABTCurve actCurve, ABTCurve estCurve)
   {
      if (actCurve != null) return actCurve.getStart();

      return estCurve.getStart();
   }

   private double getActSum(IABTObject assignmentObject) throws ABTException
   {

      ABTCurve actualCurve = utl_.osGetCurve(assignmentObject, OFD_ACTCURVE);

      if (actualCurve != null)

         return Math.round(actualCurve.getSum(actualCurve.getStart(),  actualCurve.getFinish()));

      return 0;

   }

   private void getValues(MppOsAssignmentMatch match, IABTObject assignmentObject ) throws ABTException
   {

      boolean pm = true; //check out with benoit
      boolean am = false;

      Assignment assignment         = match.getMppAssignment();
      IABTObject AssignmentObject   = match.getOsObject();

      ABTCurve actualCurve       = utl_.osGetCurve(assignmentObject, OFD_ACTCURVE);
      ABTCurve estimateCurve     = utl_.osGetCurve(assignmentObject, OFD_ESTCURVE);

//temp code

      long actualSumInMinutes    = 0;
      if (actualCurve != null) actualSumInMinutes = Math.round(actualCurve.getSum(actualCurve.getStart(),  actualCurve.getFinish()) / 60);

      long remainingSumInMinutes = 0;
      if (estimateCurve != null) remainingSumInMinutes = Math.round(estimateCurve.getSum(estimateCurve.getStart(),  estimateCurve.getFinish()) / 60);

      assignment.setActualWork(new ABTInteger((int)actualSumInMinutes));
      assignment.setRemainingWork(new ABTInteger((int)remainingSumInMinutes));

      return;

//end temp code
/*
   	if (!trackedByObjectSpace_) return; //do not set actuals if not tracked (what is in msp, stays valid)

   	int workContour = assignment.getWorkContour();

  		if (workContour != 8) {

   		double units = AssignmentObject.getValue(OFD_ESTMAX).doubleValue();

  			Resource resource = match.getMppResource();

  			double maxUnits = resource.getMaxUnits().doubleValue();

  			if (units > maxUnits) units = maxUnits;

  			assignment.setUnits(new ABTDouble (units));	// setting units now ahead of time, god knows
  													// what msp will do with it (only for non-contour)
   	}

  		ABTDate start  = new ABTDate(assignment.getStart().timeValue(),  	am);
  		ABTDate finish = new ABTDate(assignment.getFinish().timeValue(),  pm);

  		ABTDate as = null;
      ABTDate af = null;

  		if (actualCurve != null) {
  			as = new ABTDate(actualCurve.getStart(),  am);
   		af = new ABTDate(actualCurve.getFinish(), pm);
  		}

  		ABTDate s = ABTDate.min(start,  as);
  		ABTDate f = ABTDate.max(finish, af);

  		TimeScaleValues tsv = assignment.s(
                                          new ABTTime(s, 0),
                                          new ABTTime(f.next(), 0),
                                          new ABTInteger(10),
                                          new ABTInteger(4),
                                          new ABTInteger(1)
                                          );

  		int index = 1;
      try {

     		for (ABTDate d = s; d.compareTo(f) <= 0; d = d.next()) {

            TimeScaleValue value = null;

      		value = tsv.getItem(index++);

     			long actuals = 0;

            if (actualCurve != null)
               actuals = Math.round(actualCurve.getSum(new ABTTime(d, 0), new ABTTime (d.next(), 0)) / 60);

      		if (value.getValue().intValue() != actuals) {
	      		if (actuals > 0) value.setValue(new ABTInteger((int)actuals));
		      	else			 value.Clear();
     			}
      	}

      } catch (Throwable e) {

      }


      if (assignment.getWorkContour() != workContour) assignment.setWorkContour(workContour);
*/

   }

   private boolean trackModeNotZero(IABTObject obj) throws ABTException
   {

      //
      // If the project's track mode is zero, return false.
      //

      ABTValue projTrackMode = getValue(projectObject_, OFD_TRACKMODE);

      if (projTrackMode == null ||
          projTrackMode instanceof ABTEmpty ||
          projTrackMode.intValue() == 0)
          return false;

      //
      // The project's track mode is not zero.  Check the resource's
      // track mode.  If the resource's track mode is zero, return false.
      //

      IABTObject res = getObject(obj, OFD_RESOURCE);

      ABTValue resTrackMode = getValue(res, OFD_TRACKMODE);

      if (resTrackMode == null ||
          resTrackMode instanceof ABTEmpty ||
          resTrackMode.intValue() == 0)
          return false;

      ///
      // Both the project's track mode and the resource's track mode are
      // nonzero.  Return true.
      //

      return true;

   }


   public boolean isException(String prapiName, IABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      boolean ret = false;       // assume NO exception
      return ret;
   }

}




