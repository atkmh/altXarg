package com.abtcorp.io.server;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;

public class errorMessages extends ListResourceBundle
{
public Object[][] getContents() {
			return contents; 
}


public static final String Package = "com.abtcorp.io.server".intern();
public static final ABTErrorCode SERVER_ERR_NO_SITE = new ABTErrorCode(Package, "100");
public static final ABTErrorCode SERVER_ERR_INVALID_PROPERTY = new ABTErrorCode(Package, "101");
public static final ABTErrorCode SERVER_ERR_CURSOR_ADDNEW = new ABTErrorCode(Package, "102");
public static final ABTErrorCode SERVER_ERR_CURSOR_SETFIELD = new ABTErrorCode(Package, "103");
public static final ABTErrorCode SERVER_ERR_CURSOR_EDIT = new ABTErrorCode(Package, "104");
public static final ABTErrorCode SERVER_ERR_CURSOR_UPDATE = new ABTErrorCode(Package, "105");
public static final ABTErrorCode SERVER_ERR_ERROR = new ABTErrorCode(Package, "106");
public static final ABTErrorCode SERVER_ERR_NO_OBJECT_SPACE = new ABTErrorCode(Package, "107");
public static final ABTErrorCode SERVER_ERR_INVALID_HASH = new ABTErrorCode(Package, "108");
public static final ABTErrorCode SERVER_ERR_NO_USER_SESSION = new ABTErrorCode(Package, "109");
public static final ABTErrorCode SERVER_ERR_NO_REPO = new ABTErrorCode(Package, "110");
public static final ABTErrorCode SERVER_ERR_MISSING_CMD_KEYWORD = new ABTErrorCode(Package, "111");
public static final ABTErrorCode SERVER_ERR_INVALID_CMD = new ABTErrorCode(Package, "112");
public static final ABTErrorCode SERVER_ERR_MISSING_TYPE_KEYWORD = new ABTErrorCode(Package, "113");
public static final ABTErrorCode SERVER_ERR_INVALID_TYPE = new ABTErrorCode(Package, "114");



static final Object[][] contents = {
{SERVER_ERR_NO_SITE.getCode(),"Site object inaccessible or not found"},
{SERVER_ERR_INVALID_PROPERTY.getCode(),"Invalid property"},
{SERVER_ERR_CURSOR_ADDNEW.getCode(),"Cursor addnew failure"},
{SERVER_ERR_CURSOR_SETFIELD.getCode(),"Cursor setfield failure"},
{SERVER_ERR_CURSOR_EDIT.getCode(),"Cursor edit failure"},
{SERVER_ERR_CURSOR_UPDATE.getCode(),"Cursor update failure"},
{SERVER_ERR_ERROR.getCode(),"An error has occurred"},
{SERVER_ERR_NO_OBJECT_SPACE.getCode(),"Object space not set"},
{SERVER_ERR_INVALID_HASH.getCode(),"Hashtable  parameters are invalid"},
{SERVER_ERR_NO_USER_SESSION.getCode(),"User session not set"},
{SERVER_ERR_NO_REPO.getCode(),"ABT Repository not connected"},
{SERVER_ERR_MISSING_CMD_KEYWORD.getCode(),"Command keyword missing"},
{SERVER_ERR_INVALID_CMD.getCode(),"Invalid execute command"},
{SERVER_ERR_MISSING_TYPE_KEYWORD.getCode(),"Type keyword missing"},
{SERVER_ERR_INVALID_TYPE.getCode(),"Invalid execute type"},

 };
}