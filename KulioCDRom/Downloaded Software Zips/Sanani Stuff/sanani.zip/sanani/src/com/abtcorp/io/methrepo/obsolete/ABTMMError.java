package  com.abtcorp.io.methrepo;

/*
 * ABTMMError.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 10-9-98	    LZX		        Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



/**
 * This class provides basic functionality for Error Handling for
 * the methodology repo driver.
 * <p>
 *
 *
 * @version	1.0
 * @author      L. Xiao
 * @see         <path to another class> %%%%% cross reference
 */

public class ABTMMError extends ABTError
{
   private static String defaultPackage_ = "com.abtcorp.io.methrepo";
   
   /**
   *  default constructor
   *  @param method_ name of routine creating it
   *  @param code_ ErrorCode
   */
   public ABTMMError(
            String component,
            String method,
            int code,
            Object info)
   {  super(defaultPackage_, component, method, code, info);  }
   
   /**
   *  default constructor
   *  @param method_ name of routine creating it
   *  @param code_ ErrorCode
   */
   public ABTMMError(
            String component,
            String method,
            String code,
            Object info)
   {  super(defaultPackage_, component, method, code, info);  }
   
}