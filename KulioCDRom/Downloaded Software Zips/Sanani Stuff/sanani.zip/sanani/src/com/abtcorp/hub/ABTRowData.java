

package com.abtcorp.hub;

import com.abtcorp.core.*;
public class ABTRowData extends ABTValue implements IABTTransactionData
{
      private ABTArray myData = null;

      public ABTRowData()
      {
        myData = new ABTArray();
      }

      public ABTRowData(ABTRowData from)
      {
        myData = new ABTArray(from.myData);
      }

      public IABTTransactionData rollUp(IABTTransactionData target)
      {
        return this;
      }

      public IABTTransactionData copyData()
      {

         return new ABTRowData(this);
     }

     protected synchronized void add(ABTValue newValue)
     {
       myData.add(newValue);
     }

     protected synchronized void put(int index,ABTValue newValue)
     {
       myData.put(index,newValue);
     }

     protected int size()
     {
      return myData.size();
     }
     protected synchronized ABTValue at(int index)
     {
      try
      {
        return (ABTValue)(myData.at(index));
      }
      catch (Exception e)
      {
        return null;
      }
     }


}