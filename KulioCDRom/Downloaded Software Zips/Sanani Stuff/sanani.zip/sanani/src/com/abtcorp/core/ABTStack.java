/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTStack.java, 5, 12/7/98 5:24:07 PM, Hans-Joachim Birthelmer$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import com.objectspace.jgl.Stack;
import java.util.Enumeration;
import java.io.Serializable;
import java.lang.StringBuffer;

public class ABTStack extends ABTValue implements Serializable
{
  private static final long serialVersionUID = 522388019257366302L;
  Stack myStack = null;
  /**
   * Construct myself to be an empty Stack.
   * Use an Array for my underlying implementation.
   */
  public ABTStack()
    {
        myStack = new Stack();
    }
  /**
   * Return the last object that was pushed onto me.
   * @exception com.objectspace.jgl.InvalidOperationException if the Stack is empty.
   */
  public synchronized Object peek()
    {
    return myStack.top();
    }


  /**
   * Construct myself to be a shallow copy of a specified Stack.
   * @param stack The Stack to be copied.
   */
  protected ABTStack( Stack stack )
    {
        myStack = new Stack(stack);
    }

  /**
   * Construct myself to be a shallow copy of a specified Stack.
   * @param stack The Stack to be copied.
   */
  public ABTStack( ABTStack stack )
    {
        myStack = new Stack(stack.myStack);
    }


  public void removeAllElements()
  {
    myStack.clear();
  }
  /**
   * Become a shallow copy of a specified Stack.
   * A shallow copy is made of the Stack's underlying sequence.
   * @param stack The Stack to be copied.
   */
  public synchronized void copy( ABTStack stack )
    {
    synchronized( stack )
      {
      if ( this != stack )
        myStack = (Stack)stack.myStack.clone();
      }
    }

  /**
   * Return a shallow copy of myself.
   */
   public synchronized Object clone()
   {
      ABTStack result = (ABTStack)super.clone();

      result.myStack = (Stack)myStack.clone();

      return result;
   }


  /**
   * Return a string that describes me.
   */
  public synchronized String toString()
    {
    return "Stack( " + myStack.toString() + " )";
    }

  /**
   * Return true if object is a Stack whose underlying sequence is equal to mine.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof ABTStack && equals( (ABTStack)object );
    }

  /**
   * Return true if a specified Stack's sequence is equal to mine.
   * @param stack The Stack to compare myself against.
   */
  public synchronized boolean equals( Stack stack )
    {
    return myStack.equals( stack );
    }

  /**
   * Return my hash code for support of hashing containers
   */
  public synchronized int hashCode()
    {
    return myStack.hashCode();
    }

  /**
   * Return true if I contain no objects.
   */
  public boolean isEmpty()
    {
    return myStack.isEmpty();
    }

  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myStack.size();
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myStack.maxSize();
    }

  /**
   * Return the last object that was pushed onto me.
   * @exception com.objectspace.jgl.InvalidOperationException if the Stack is empty.
   */
  public synchronized Object top()
    {
    return myStack.top();
    }

  /**
   * Push an object.  Return null as add's always work for Stacks
   * @param object The object to push.
   */
  public synchronized Object add( Object object )
    {
    myStack.add( object );
    return null;
    }

  /**
   * Push an object.
   * @param object The object to push.
   */
  public void push( Object object )
    {
        myStack.add( object );
    }

  /**
   * Pop the last object that was pushed onto me.
   * @exception com.objectspace.jgl.InvalidOperationException if the Stack is empty.
   */
  public synchronized Object pop()
    {
    return myStack.pop();
    }

  /**
   * Remove all of my objects.
   */
  public synchronized void clear()
    {
    myStack.clear();
    }

  /**
   * Return an Enumeration of my components.
   */
  public synchronized Enumeration elements()
    {
    return myStack.elements();
    }


}