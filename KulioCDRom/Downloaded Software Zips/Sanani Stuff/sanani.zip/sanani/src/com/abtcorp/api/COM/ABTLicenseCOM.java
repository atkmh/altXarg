package com.abtcorp.api.com;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

//
//
// ABTLicenseCOM
//
//

public class ABTLicenseCOM implements IABTLicenseCOM
{
   public ABTLicenseCOM(ABTLicense l)
     {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(l);
      /**/
     }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
  /**/
   
   private ABTLicense _lic;
   private ABTLicense lic() {
      if (_lic == null)
         _lic = (ABTLicense)getObject();
      return _lic;
      }

   public IABTSessionCOM getSession()
      { return new ABTSessionCOM(lic().getSession()); }
}