/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTSortOrderDefinition;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import com.abtcorp.hub.*;

class ABTObjectSetLocal extends ABTSessionObject implements IABTObjectSet
{
  protected ABTObjectSetLocal(ABTSessionObject s, ABTObjectSet obj)
     {
     super(s, obj);
     }


  private ABTObjectSet _OSet;
   private ABTObjectSet OSet() {
      if (_OSet == null) _OSet = (ABTObjectSet)getObject();
      return _OSet;
      }

   public synchronized IABTObjectSpace getObjectSpace() {
      return new ABTObjectSpaceLocal(this);
    }
   
   public synchronized IABTEnumerator getElements()
      { return new ObjectEnumerator(this,OSet().elements(getUserSession())); }
   public IABTEnumerator getSortedElements(IABTSortOrderDefinition def) {
      ABTSortOrderDefinition sod = null;
      if (def instanceof SortOrderDef)
         sod = (ABTSortOrderDefinition)((SortOrderDef)def).getObject();
      return new ObjectEnumerator(this,OSet().sortedElements(getUserSession(),sod) );
      }

  public synchronized int size()
     { return OSet().size(getUserSession()); }

  public synchronized ABTValue at(int index) {
     return ValueMunger.MarshalOut(this,OSet().at(getUserSession(),index));
     }

  public synchronized ABTValue getBack()
      { return ValueMunger.MarshalOut(this,OSet().back(getUserSession())); }

  public synchronized ABTValue getFront()
      { return ValueMunger.MarshalOut(this,OSet().front(getUserSession())); }

  public synchronized void clear()
      { OSet().clear(getUserSession()); }

  public synchronized IABTSortOrderDefinition getSortOrder()
      { return new SortOrderDef(this,OSet().getSortOrder(getUserSession())); }

  /**
   * Remove the element at a particular index.
   * @param index The index of the element to remove.
   * @return The object removed.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
   public synchronized ABTValue removeAt( int index )
      { return ValueMunger.MarshalOut(this,OSet().remove(getUserSession(),index)); }

  /**
   * Remove the element pointed to by object and return the removed object
   * @param object The object to remove.
   * @return ABTObject removed or ABTError
   */
   public synchronized ABTValue remove( IABTObject object ) {
      ABTObject innerObj = (ABTObject)(((ABTObjectLocal)object).getObject());
      return ValueMunger.MarshalOut(this,OSet().remove(getUserSession(),innerObj));
      }

  /**
   * Add an object after my last element or in sorted order.  
   * @param object The object to add.
   * @return added object or ABTError
   */
   public synchronized ABTValue add( IABTObject object ) {
      return ValueMunger.MarshalOut(
         this,OSet().add(getUserSession(),(ABTObject)ValueMunger.MarshalIn(this, (ABTValue)object))
         );
      }


  /**
   * Add a new object 
   * @return added object or ABTError
   */
   public synchronized ABTValue addNew()
      { return ValueMunger.MarshalOut(this,OSet().addNew(getUserSession())); }

  

  /**
   * Return the deleted flag for the object at index
   * @param index The index.
   * @return boolean true if deleted or element doesn't exist
   */
   public synchronized boolean isDeleted( int index )
      { return OSet().isDeleted(getUserSession(),index); }

   /**
   * check whether a given index is valid
   * @param index to be checked
   * @return boolean true for valid, false otherwise
   */
   public synchronized boolean checkIndex(int index)
      { return OSet().checkIndex(getUserSession(),index); }

   
   /**
   * Return true if I contain a particular object.
   * @param object The object in question.
   */
   public synchronized boolean contains( IABTObject object )  {
      ABTObject innerObj = (ABTObject)(((ABTObjectLocal)object).getObject());
      return OSet().contains(getUserSession(),innerObj);
      }

   
   /**
   *  return the set of properties for this class
    */
   public synchronized IABTPropertySet getProperties()
      { return (IABTPropertySet)OSet().getProperties(); }


   /**
   * Return an objectset containing all elements 
   * where the provided criteria computes to true
   * @param criteria String with SQL-like sysntax
   * @return newly created Objectset with same rule set or ABTError
   */
   public synchronized ABTValue select( String criteria)
      { return ValueMunger.MarshalOut(this, OSet().select(getUserSession(),criteria)); }


   public synchronized String getObjectType()
   {
      return OSet().getObjectSetType();
   }

   public synchronized IABTArray getDeletedData()
      {
      return new ABTArrayLocal(this, OSet().getDeletedData(getUserSession()));
      }

   public boolean isEmpty() {
      return OSet().isEmpty(getUserSession());
      }
     


private class SortOrderDef extends ABTSessionObject implements IABTSortOrderDefinition
   {
   private ABTSortOrderDefinition _sod;
   public SortOrderDef(ABTSessionObject s, ABTSortOrderDefinition sod){
      super(s,sod);
      _sod = sod;
      }

   public ABTValue add(String property_, boolean asc_){
      return ValueMunger.MarshalOut(this, _sod.add(property_,asc_));
      }
   public IABTEnumerator getElements(){
      return new ObjectEnumerator(this,_sod.elements());
      }
   public ABTValue get(int index){
      return ValueMunger.MarshalOut(this, _sod.at(index));
      }
   public void clear(){
      _sod.clear();
      }
   public ABTValue add(ABTValue object){
      return ValueMunger.MarshalOut(this,_sod.add(object));
      }
   public ABTValue removeAt( int index ){
      return ValueMunger.MarshalOut(this, _sod.remove(index));
      }
   public int remove( ABTValue object ){
      return _sod.remove(object);
      }
   public int size(){
      return _sod.size();
      }
   public boolean isEmpty(){
      return _sod.isEmpty();
      }
   public boolean contains( ABTValue object ){
      return _sod.contains(object);
      }

   public IABTObjectSpace getObjectSpace(){
      return new ABTObjectSpaceLocal(this);
      }

   }


private class ObjectEnumerator extends ABTSessionObject implements IABTEnumerator
     {
      java.util.Enumeration _en;
      IABTObjectSet _os;
      IABTSortOrderDefinition _sortby;
      boolean _sorted;

      public ObjectEnumerator(ABTSessionObject s, java.util.Enumeration en) {
         super(s,en);
         _en = en;
         }

      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }
      public ABTValue nextValue()
         { return ValueMunger.MarshalOut(this,(ABTValue)_en.nextElement());  }
      public Object nextElement()
         { return ValueMunger.MarshalOut(this,(ABTValue)_en.nextElement());  }

     }

   public ABTValue toValue() {
      return this;
      }

   public ABTValue setValues(IABTHashTable pairs) {
      getUserSession().startTransaction();
      ABTValue retVal = null;
      try {
         ABTHashTable hT = (ABTHashTable)pairs;
         ABTHashtable ht = (ABTHashtable)hT.getObject();
         retVal = OSet().setValues((ABTUserSession)getUserSession(),ht);
         }
      catch (Exception e)
         {
         getUserSession().rollbackTransaction();
         return new ABTError(getClass(), "setValues", errorMessages.ERR_EXCEPTION, e);
         }
      if (retVal instanceof ABTError)
         getUserSession().rollbackTransaction();
      else
         getUserSession().commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }

}
