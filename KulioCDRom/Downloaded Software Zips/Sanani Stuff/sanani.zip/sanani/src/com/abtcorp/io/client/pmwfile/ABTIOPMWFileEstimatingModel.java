package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileEstimatingModel.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;

import java.util.Hashtable;

//DEBUG
import java.util.Vector;
import java.util.Enumeration;
import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;


import com.abtcorp.io.client.ABTObjectSetIDList;
import com.abtcorp.io.client.ABTFileHelper;

/**
 *  ABTIOPMWFileEstimatingModel is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileEstimatingModel fe = new ABTIOPMWFileEstimatingModel(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileEstimatingModel extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       estModelVector_ = null;
     
//====================================================================================
// Constructors
//====================================================================================
                         
/**
 *    ABTIOPMWFileEstimatingModel constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileEstimatingModel(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_            = OBJ_ESTIMATINGMODEL;
      estModelVector_  = new Vector();
   }
   
//====================================================================================
// Populate Estimating Model from the Intermediate Hash Table
//====================================================================================

/**
 * Populate  Estimating Model object from the Intermediate Hash Table to the sapce
 * @param Hashtable parms,
 * @return an ABTValue the Estimating Model object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
 
   public ABTValue populate(Hashtable parms) throws ABTException 
   {
    ABTObjectSetIDList estModelIDs   = null;    
    IABTObject         project       = null;  
    Object             object        = null;
     
    try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
            
        //Get the  Estimating Model IDs 
        object = parms.get(OFD_ESTMODELS);
        if (object instanceof ABTObjectSetIDList) 
            estModelIDs  = (ABTObjectSetIDList)object;
            
        Enumeration itID = estModelIDs.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);            
            reqparms.put(ESTMODELS_ID,(IABTLocalID)itID.nextElement());
            
            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }      
   } 
   
/**
 * Create a new object in the object space and initialize it with  appropriate values 
 * @param Hashtable parms 
 * @return ABTValue the newly created Estimating Model 
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {    
      IABTLocalID estModelID     = null;      
      IABTObject project         = null;      
      Object     object          = null;
      IABTObject estModelObj     = null;
     
      //Get Estimating Model ID 
      object = null;
      object = parms.get(ESTMODELS_ID);
      if (object instanceof IABTLocalID) 
         estModelID  = (IABTLocalID)object;
            
      //Check if Estimating Model has already been created
        object = null;
        object = driver_.lookupTableGet(estModelID);
        if ( object!= null && object instanceof IABTObject)
        {
         // TO DO UPDATE
           ;
        }
        else
        {
          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object; 
                       
          // Get the array of value associated with Estimating Model
          IABTArray   estModelArr  = null;
          object = null;
          
          object = driver_.intermediateTableGet(estModelID);
          if (object instanceof IABTArray)
            estModelArr = (IABTArray) object;
          
          //Get the property set associated with the Estimating Model
          IABTPropertySet propSet = null;
          propSet = getProperties(type_); 
          
         
          //Get custom field values Remote ID
          ABTValue  val = null;      
          
          IABTHashTable  reqparms = (getSpace()).newABTHashTable();
          reqparms.putItemByString(OFD_PROJECT,     (ABTValue)project);
          
          val = getHashValue(estModelArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            estModelObj = createObject(type_,(ABTRemoteID)val, reqparms);  
          else if (ABTValue.isNull(val)) 
            estModelObj = createObject(type_,(ABTRemoteID)null, reqparms);
          else
            new ABTException(" WRONG TYPE CAST");

          //Set Estimating Model's scalar values.  
          setScalarValues(propSet, estModelArr, estModelObj);         
        }
           
    driver_.lookupTablePut(estModelID, estModelObj);   
    
    return (ABTValue)estModelObj;
   }    
   
//====================================================================================
// Save Estimating Model to an Intermediate Hash Table
//====================================================================================   

/**
 * Saves estModel objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms 
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms ) throws ABTException
 {
   try
   {
        IABTObject project = null;
        
        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
        
        if (project == null)
            throw new ABTException("The current project is null.");

        IABTObjectSet estModelOs = getObjectSet(project, OFD_ESTMODELS);

        for (int i =0; i < size(estModelOs); i++)
        {
            IABTObject  estModelObj     = (IABTObject)at(estModelOs, i);

            // Make sure the object is of type estModel
            if (!estModelObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the estModel in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(estModelObj);
            if (arr==null)
                throw new ABTException("The arr of estModel values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID estModelId = estModelObj.getID();
            if (estModelId == null)
                throw new ABTException("estModel ID is null.");
            
            if (( driver_.intermediateTablePut(estModelId, arr)) != null)
                throw new ABTException("The estModel ID already exist.");

            //DEBUG
            estModelVector_.addElement(estModelId);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


}