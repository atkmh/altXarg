package com.abtcorp.hub;

/*
 * ABTUserSession.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 10-01-98    HJB     #118 - commitAll changed to decrement transactionlevel correctly.
  *
  */

//import com.objectspace.jgl.*;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import java.io.Serializable;
import java.util.Enumeration;
/**
 *  ABTUserSession - the mother of all ....
 *  owned/instantiated by an application offers the management of different views (ABTDictionary)
 *  and objects (ABTObject) and their associated data and description.
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTUserSession extends ABTValue implements Serializable {

final static int MAXTRANSACTIONNESTING = 100;

private int transactionLevel;
private ABTArray pendingRows=null;
private int [] startingLevels;
private ABTString currentUser;
//==============================================================
// constructorsarray
//==============================================================

/**
*	Default constructor
*/
protected ABTUserSession(ABTHashtable arguments)
{
    pendingRows = new ABTArray();
    transactionLevel = -1;
    currentUser = new ABTString("Unknown");
}

public int getTransactionLevel()
{
    return transactionLevel;
}

protected void addInstance(IABTTransactionInstance instance, int level)
{
    ABTStack stack = (ABTStack) pendingRows.at(level);
    stack.push(instance);
}

//==============================================================
// Transaction support
//==============================================================


public ABTError startTransaction()
{
    if (transactionLevel >= MAXTRANSACTIONNESTING)
        return new ABTErrorHub("ABTUserSession->startTransaction",errorMessages.ERR_40,new ABTInteger(MAXTRANSACTIONNESTING));

    transactionLevel++;
    if (pendingRows.size() > transactionLevel)
        pendingRows.put(transactionLevel, new ABTStack());
    else
        pendingRows.add(new ABTStack());
    
    
    return null;
}

public synchronized ABTError rollbackTransaction()
{
    if (transactionLevel == -1)
        return new ABTErrorHub("ABTUserSession->rollbackTransaction",errorMessages.ERR_44,null);
    //rollback all transactions for the last level
    ABTStack stack = (ABTStack) pendingRows.at(transactionLevel);
    Enumeration e = stack.elements();
    while (e.hasMoreElements())
    {
        IABTTransactionInstance o = (IABTTransactionInstance)(e.nextElement());
        o.rollback(this);
    }
    stack.clear();
    pendingRows.put(transactionLevel,null);
    transactionLevel--;
    return null;
}

public synchronized ABTError rollbackAll()
{
    if (transactionLevel == -1)
        return new ABTErrorHub("ABTUserSession->rollbackAll",errorMessages.ERR_44,null);

    //rollback all transactions for the last level
    for (int i = transactionLevel; i >= 0; i--)
    {
        ABTStack stack = (ABTStack) pendingRows.at(i);
        Enumeration e = stack.elements();
        while (e.hasMoreElements())
        {
            IABTTransactionInstance o = (IABTTransactionInstance)(e.nextElement());
            o.rollback(this);
        }
        stack.clear();
        pendingRows.put(i,null);
    }        
    transactionLevel = -1;
    return null;
}

public synchronized ABTError commitTransaction()
{
    if (transactionLevel == -1)
        return new ABTErrorHub("ABTUserSession->commitTransaction",errorMessages.ERR_44,null);
    //rollback all transactions for the last level
//    if (transactionLevel > 0)
//    {
//        transactionLevel--;
//        return null;
//    }

    ABTStack stack = (ABTStack) pendingRows.at(transactionLevel);
    Enumeration e = stack.elements();
    while (e.hasMoreElements())
    {
        IABTTransactionInstance o = (IABTTransactionInstance)(e.nextElement());
        o.commit(this);
    }
    stack.clear();
    pendingRows.put(transactionLevel,null);
    transactionLevel--;
    return null;
}

public synchronized ABTError commitAll()
{
    if (transactionLevel == -1)
        return new ABTErrorHub("ABTUserSession->commitAll",errorMessages.ERR_44,null);
    //rollback all transactions for the last level
    //rollback all transactions for the last level
    
    while (transactionLevel > -1)
    {
        ABTStack stack = (ABTStack) pendingRows.at(transactionLevel);
        Enumeration e = stack.elements();
        while (e.hasMoreElements())
        {
            IABTTransactionInstance o = (IABTTransactionInstance)(e.nextElement());
            o.commit(this);
        }
        stack.clear();
        pendingRows.put(transactionLevel,null);
        transactionLevel--;
    }        
    return null;
}

public String getUser()
{
    return currentUser.stringValue();
}

public ABTString getABTUser()
{
    return currentUser;
}


}