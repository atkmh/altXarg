package com.abtcorp.io.team.connect;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.team.TimeEntryPopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.RemoteID;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ConnectTimeEntryPopulator extends TimeEntryPopulator implements TWRepoDriverConstants, IABTTWRuleConstants, ABTNames
{
   private ABTObject timesheet_ = null;
   
   public ConnectTimeEntryPopulator(ABTRepositoryDriver driver) {super(driver);}
   public ConnectTimeEntryPopulator() {}

   /* Adds the time entry to the object space. There is no need to set FLD_TW_ASSIGNMENT */
   /*  here because it is set during object initialization.                              */
   protected ABTValue addObject(ABTObjectSet timeEntries)
   {
      double multiplier = 1;
      ABTObject resource = null;

      ABTHashtable args = new ABTHashtable(1,(float)1.0);
      ABTValue assignID = cursor_.getField(FLD_ASSIGNMENTID);
      if (!ABTError.isError(assignID) && !ABTValue.isEmpty(assignID) && assignID != null)
         args.put(new ABTString(REPO_ASSIGNMENTID),assignID);
      ABTObject timeEntry = (ABTObject)getDriver().getSpace().createObject(getSession(),OBJ_TW_TIMEENTRY,null,args);

      if (timeEntry instanceof ABTObject) {

         ABTValue id = null;
         
         ABTObject timesheet = null;
         if (timesheet_ != null) timesheet = timesheet_;
         else {
            id = cursor_.getField(FLD_TIMESHEETID);
            if (id != null &&  !ABTEmpty.isEmpty(id) && !ABTError.isError(id)) {
            	int idx = timeSheets_.indexOf(new Integer(id.intValue()));
            	if (idx >= 0) timesheet = (ABTObject)timeSheets_.at(idx);
            }
         }

         if (timesheet != null) {
            timeEntry.setValue(getSession(),FLD_TW_ID,cursor_.getField(FLD_ID));
   
            timeEntry.setValue(getSession(),FLD_TW_ACTUALS,cursor_.getField(FLD_ACTCURVE));

            timeEntry.setValue(getSession(),FLD_TW_TIMESHEET,timesheet);

            ABTValue test = timesheet.getValue(getSession(),FLD_TW_RESOURCE,null);
            if (test instanceof ABTObject) {
               resource = (ABTObject)test;
               switch (resource.getValue(getSession(),FLD_TW_UNIT,null).intValue()) {
                  case RESOURCE_DAYS:   multiplier /= resource.getValue(getSession(),FLD_TW_HOURS_PER_DAY,null).doubleValue();
                  case RESOURCE_HOURS:  multiplier /= 3600;
               }
            }
            
            id = cursor_.getField(FLD_CHARGECODEID);
            if (id != null && !ABTEmpty.isEmpty(id) && !ABTError.isError(id)) {
            	int idx = chargeCodes_.indexOf(new Integer(id.intValue()));
            	if (idx >= 0) timeEntry.setValue(getSession(),FLD_TW_CHARGECODE,(ABTObject)chargeCodes_.at(idx));
            }

            id = cursor_.getField(FLD_TYPECODEID);
            if (id != null && !ABTEmpty.isEmpty(id) && !ABTError.isError(id)) {
               int idx = chargeCodes_.indexOf(new Integer(id.intValue()));
               if (idx >= 0) timeEntry.setValue(getSession(),FLD_TW_TYPECODE,(ABTObject)typeCodes_.at(idx));
            }
         }

         scaleCurve(timeEntry,multiplier,FLD_TW_ACTUALS);

         RemoteID.setRemoteID(timeEntry,getSession()); // Tag the object with the remote id.
      }

      return timeEntry;
   }
}