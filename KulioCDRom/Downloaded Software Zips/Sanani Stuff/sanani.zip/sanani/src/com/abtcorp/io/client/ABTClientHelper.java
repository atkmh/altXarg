package com.abtcorp.io.client;
/*
 * ABTIOHelper.java 06/04/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 06-04-98    SOB             Initial Implementation
  * 06-22-98    SOB             get/setSpace(); get/setDriver()
  * 06-26-98    SOB             more helper methods
  * 07-09-98    SOB             basic transaction support
  * 07-14-98    SOB             integrate Methodology IO helper methods
  * 08-04-98    MXA             Added getProperties().
  * 11-07-98    MXA             Added Transient Flag.
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import java.util.Enumeration;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;

import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTEnumerator;
import com.abtcorp.io.ABTIOHelper;

import com.abtcorp.api.local.ABTArrayLocal;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTString;

import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTRemoteID;

/**
 *  ABTIOHelper is the base abstract class for all driver helper classes.  Helper
 *  classes are those which assist the drivers in accessing persistent storage and the object
 *  space.
 *
 *  <pre>
 *			This class is not meant to be instantiated directly, but to be extended by various
 *          classes that a driver will instantiate to assist it in populating the object space.
 *
 *			public class ABTIOPMWRepoProject extends ABTIOHelper
 *			{
 *				... override find(), create(), update(), etc., methods for PMW-specific requirements ...
 *			}
 *
 *  </pre>
 *
 * @version	1.0
 * @author  S. Bursch
 * @see     ABTDriver
 */

public abstract class ABTClientHelper extends com.abtcorp.io.ABTIOHelper implements IABTPropertyType
{
/**
 *    space_ is a reference to the object space being used by this helper.
 */
   protected  IABTObjectSpace space_;

/**
 *		Create an ABTIOHelper that is not associated with an ABTObjectSpace or ABTDriver.
 *    Associating an object space with this class will be deferred until later.
 */

   public   ABTClientHelper() { /* implicit call to super() here */ }

/**
 *		Create an ABTIOHelper that is associated with an ABTObjectSpace.
 *
 */

   public   ABTClientHelper(IABTObjectSpace space)
   {
    space_ = space;
   }

/**
 *    Populate an object space with an object (or objects) as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public abstract   ABTValue populate(ABTArray parms) throws ABTException;

/**
 *    Populate an object space with an object (or objects) as appropriate to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */
   protected abstract   ABTValue populate() throws ABTException;

/**
 *    Save an object (or objects) from the object space as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return void
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public abstract   void save(ABTArray parms) throws ABTException;

/**
 *		Set the object space reference.
 *    @param space is a reference to the object space
 *
 */
   public   void setSpace(IABTObjectSpace space) {space_ = space;}

/**
 *		Get the object space reference.
 *
 *
 */
   public   IABTObjectSpace getSpace() {return space_;}

/**
 *		Check for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value is the ABTValue returned from the invocation of an object space
 *             or ABTObject method.
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public void checkError( ABTValue value ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage());
   }

/**
 *		Check for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value is the ABTValue returned from the invocation of an object space
 *             or ABTObject method.
 *    @param propname is the property name being get/set
 *    @param settingvalue is the value being get/set
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public void checkError( ABTValue value, String propname, ABTValue settingvalue ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage() + " (" + propname + ", " + settingvalue + ")");
   }

/**
 *		Check for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value is the ABTValue returned from the invocation of an object space
 *             or ABTObject method.
 *    @param propindex is the property index of the property being get/set
 *    @param settingvalue is the value being get/set
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public void checkError( ABTValue value, int propindex, ABTValue settingvalue ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage() + " (" + propindex + ", " + settingvalue + ")");
   }

/**
 *		Set a property value into an ABTObject.
 *    @param object is the ABTObject whose property is being set
 *    @param propname is the property name being set
 *    @param value is the value being set
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public ABTValue setValue( IABTObject object, String propname, ABTValue value ) throws ABTException
   {
    ABTValue ret = null;
    try{
       ret = object.setValue(propname, value );

    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
        return ret;
    }
   }


/**
 *		Set a property value into an IABTObject.
 *    @param object is the IABTObject whose property is being set
 *    @param propindex is the property index of the property being set
 *    @param value is the value being set
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
/*
   public void setValue( IABTObject object, int propindex, ABTValue value ) throws ABTException
   {
      ABTValue err = object.setValue(propindex, value );
      checkError( err, propindex, value );
   }
*/

/**
 *		Get a property value from an IABTObject.
 *    @param object is the IABTObject whose property is being gotten
 *    @param propname is the property name whose value is being gotten
 *    @return an ABTValue which is the property's value
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public ABTValue getValue( IABTObject object, String propname ) throws ABTException
   {
      ABTValue err = object.getValue(propname );
      checkError( err );
      return err;
   }

/**
 *		Get a property value from an IABTObject.
 *    @param object is the IABTObject whose property is being gotten
 *    @param propindex is the property index of the property whose value is being gotten
 *    @return an ABTValue which is the property's value
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
 /*
   public ABTValue getValue( IABTObject object, int propindex ) throws ABTException
   {
      ABTValue err = object.getValue(propindex );
      checkError( err );
      return err;
   }
*/

/**
 * getProperties -Get the propertySet for a given ObjectType
 * @param type -name of type
 * @return ABTPropertySet - properties for this object or null for error
 * @exception ABTException if an unrecoverable error occurs.
 */

 public IABTPropertySet getProperties(String type)throws ABTException
 {
   IABTPropertySet val = space_.getProperties(type);
   if ( val == null || ABTError.isError(val))
      throw new ABTException("There is No property associated with type " + type);
   return val;
 }


/**
 *		Add an existing IABTObject to an object set.
 *    @param set is the object set to which an IABTObject will be added
 *    @param object is the IABTObject which will be added to the indicated object set
 *    @return void
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public void addListMember( IABTObjectSet set, IABTObject object ) throws ABTException
   {
      set.add(object );
   }

/**
 *		Add a new IABTObject to an object set.  The IABTObject is created first, and
 *    then added to the object set.  The type of the IABTObject to be created will
 *    be the same type as that of the object set.  The IABTObject is created without
 *    an ABTRemoteID, so if the object needs an ABTRemoteID, it will need to be added
 *    later.
 *    @param set is the object set to which an IABTObject will be added after that IABTObject
 *    has been created
 *    @return the IABTObject which was created and then added to the object set
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public IABTObject addNew( IABTObjectSet set ) throws ABTException
   {
      ABTValue err = set.addNew();
      checkError( err );
      return (IABTObject)err;
   }

/**
 *		Remove an existing IABTObject from an object set.  The IABTObject is not deleted.
 *    @param set is the object set from which an IABTObject will be removed
 *    @param object is the IABTObject to be removed from the object set
 *    @return void
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public void removeListMember( IABTObjectSet set, IABTObject object ) throws ABTException
   {
      ABTValue err = set.remove(object );
      checkError( err );
   }

/**
 *		Create a new IABTObject.  The new IABTObject will be created without an
 *    ABTRemoteID.
 *    @param type is the type of IABTObject which will be created
 *    @param params is an ABTHashtable of parameters which may be used by rules
 *    processing in the creation of the object and in the placement of the object
 *    into an object model hierarcy.
 *    @return the IABTObject which was newly created
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public IABTObject createObject( String type, IABTHashTable params ) throws ABTException
   {
      return createObject( type, (ABTRemoteID) null, params );
   }

/**
 *		Create a new IABTObject.
 *    @param type is the type of IABTObject which will be created
 *    @param id is the ABTRemoteID to be assigned to the new object
 *    @param params is an ABTHashtable of parameters which may be used by rules
 *    processing in the creation of the object and in the placement of the object
 *    into an object model hierarcy.
 *    @return the IABTObject which was newly created
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public IABTObject createObject( String type, ABTRemoteID id, IABTHashTable params ) throws ABTException
   {
      ABTValue v = space_.createObject(type, id, params );
      checkError( v );
      return (IABTObject)v;
   }

/**
 *		Get an object set from an IABTObject.
 *    @param object is the IABTObject from which the object set will be gotten
 *    @param objectSetName is the property name of the object set to be gotten from the object
 *    @return the requested IABTObjectSet
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public IABTObjectSet getObjectSet( IABTObject object, String objectSetName )
      throws ABTException
   {
      ABTValue err = object.getValue( objectSetName );
      checkError( err );
      return (IABTObjectSet)err;
   }

/**
 *		Get an IABTObject from another IABTObject.
 *    @param object is the IABTObject from which the object will be gotten
 *    @param objectName is the property name of the object to be gotten
 *    @return the requested IABTObject
 *		@exception ABTException if an unrecoverable error occurs.
 *
 */
   public IABTObject getObject( IABTObject object, String objectName )
      throws ABTException
   {
      ABTValue err = object.getValue(objectName );
      checkError( err );
      return (IABTObject)err;
   }

/**
 * Add object to an object set.  The semantics of this method are similar to addListMember().
 *	@param oSet: the object set to add to.
 *	@param object: the object to be added to the object set.
 *	@return ABTValue: the value of the new object set.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   public void add(IABTObjectSet oSet, IABTObject object) throws ABTException
   {
      oSet.add(object);
   }

/**
 * Retrieve an object in the specified position within an object set.
 *	@param oSet: the object set that contains the object.
 *	@param index: the position of the object to be retrieved.
 *	@return ABTValue: the value of the retrieved object.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   public IABTObject at(IABTObjectSet oSet, int index) throws ABTException
   {
      return((IABTObject) oSet.at(index));
   }

/**
 * Return the size of an object set.
 *	@param oSet: the object set.
 *	@return the size of the object set.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   public int size(IABTObjectSet oSet) throws ABTException
   {
      return(oSet.size());
   }

// ------------------------------------------------------------------------------
// The following methods have "protected" member visibility.
// ------------------------------------------------------------------------------

/**
 * Create an object set in the object space.
 *	@param type: the type of the object set.
 *	@return ABTValue: the value of the object set created.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected IABTObjectSet createObjectSet(String type) throws ABTException
   {
		ABTValue val = space_.createNewObjectSet(type);
      checkError( val );
      return (IABTObjectSet) val;
   }

/**
 * Find an object of type type and remote ID id in the object space.
 * @param type - the type of object to search for, e.g., "ABTProject", "ABTMethod"
 * @param id - the remote ID of the object to search for
 * @return an ABTValue which, if the search is successful, will be a reference to the
 *          the desired object.  Otherwise, an ABTError.
 */
   protected   ABTValue find(String type, ABTRemoteID id)
   {
      return space_.findObjectByRemoteID(type, id);
   }


/**
 * Create a new object in the object space and initialize it with values appropriate to the
 * driver being used.
 *	@param ABTArray parms, the elements of which are meaningful as parameters to the particular
 * helper
 *	@return an ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected abstract ABTValue create(ABTArray parms) throws ABTException;

/**
 *    Update an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param ABTArray parms, the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object updated in the
 *    object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */

   protected abstract ABTValue update(ABTArray parms) throws ABTException;



   public ABTValue getHashValue(IABTArray valueArr, IABTPropertySet propset, String propName) throws ABTException
   {

    if (valueArr == null)
        throw new ABTException("getHashValue()  valueArray is null");
    if (propset== null)
        throw new ABTException("getHashValue()  property set is null");

    Enumeration itp_    = propset.getElements();
    IABTEnumerator ita_ = valueArr.getElements();
    //Enumeration ita_  = valueArr.elements();

    while(itp_.hasMoreElements())
    {

      IABTProperty prop = ((IABTProperty)(itp_.nextElement()));
      if ((!prop.isVirtual())&& (ita_.hasMoreElements())&& (prop.isVisible())&& (!prop.isTransient()))
      {
        ABTValue val  = null;
        Object valObj = ita_.nextElement();
        if (propName.equals(prop.getName()) &&( (valObj==null) || (valObj instanceof ABTValue)))
        {
             val = (ABTValue)(valObj);
             return val;
        }
      }

    }

    return null;


   }


/**
 * loadObjectPropertyValues
 * @param object:
 * @return IABTArray
 * @exception ABTException if an unrecoverable error ocurs.
 */
   protected IABTArray loadObjectPropertyValues(IABTObject object)
   {
      IABTArray result = space_.newABTArray();

      ABTValue    val = null;
      IABTLocalID id  = null;
      try
      {
     
      IABTPropertySet propertySetVar = object.getProperties();
      Enumeration it_ = propertySetVar.getElements();
      while(it_.hasMoreElements())
      {
         IABTProperty prop = ((IABTProperty)(it_.nextElement()));
         if( (prop instanceof IABTProperty) && (!prop.isVirtual()) && (prop.isVisible()) && (!prop.isTransient()))
         {

            int propType = prop.getType();

            switch (propType)
            {  case PROP_INT:
               case PROP_STRING:
               case PROP_LONG:
               case PROP_BOOLEAN:
               case PROP_DOUBLE:
               case PROP_DATE:
               case PROP_TIME:
               case PROP_TIMESTAMP:
               case PROP_BLOB:
               case PROP_SHORT:
               case PROP_ID:
               case PROP_ARRAY:
               case PROP_UNKNOWN:
                     val = getValue(object, prop.getName());
                     result.add(val);
                     break;
               case PROP_OBJECT:
                     val = getValue(object, prop.getName());
                     if ( val instanceof IABTObject)
                     {
                        id = ((IABTObject)val).getID();
                        if ( id instanceof IABTLocalID)
                            result.add((ABTValue)id);
                     }
                     else if (val == null || val instanceof ABTEmpty)
                     {
                        result.add(val);
                     }
                     //TO DO See what needs to be done in case of an error
                     else
                     {
                      // Check val for error
                      // if( ABTError.isError(val) || val == null || (val instanceof ABTEmpty) )
                      val = new ABTString("NULL");
                      result.add(val);
                     }
                     break;
               case PROP_OBJECTSET:
                      val = getValue(object, prop.getName());
                      if ( val instanceof IABTObjectSet)
                      {
                          ABTObjectSetIDList ids = new ABTObjectSetIDList((IABTObjectSet)val);
                          result.add(ids);
                      }
                     else
                     {
                       //Check val for error
                       //if( ABTError.isError(val) || val == null || (val instanceof ABTEmpty) )
                       val = new ABTString("NULL");
                       result.add(val);
                     }
                     break;


               default:
                     //throw new ABTException("Property Type Unknown");
                     val = new ABTString("NULL");
                     result.add(val);
                     break;
            }
         }
      }

      } catch (Exception e)
      {
         e.printStackTrace();
      }
      return result;
   }


  protected void setScalarValues(IABTPropertySet propSet, IABTArray valueArr, IABTObject object) throws ABTException
   {
        if (valueArr == null)
            throw new ABTException("setScalarValues()  valueArray is null");
        if (propSet== null)
            throw new ABTException("setScalarValues()  property set is null");

        Enumeration     itp_  = propSet.getElements();
        IABTEnumerator  ita_  = valueArr.getElements();
        ABTValue val      = null;
        while(itp_.hasMoreElements())
        {
          IABTProperty prop = ((IABTProperty)(itp_.nextElement()));
          String propName = prop.getName();

          if (!prop.isVirtual() && ita_.hasMoreElements()&& (prop.isVisible()) && (!prop.isTransient()) )
          {
            val = null;
            Object valObj = ita_.nextElement();
            val           = (ABTValue)(valObj);

            if ( prop.getType()!= PROP_OBJECT && prop.getType()!= PROP_OBJECTSET)
            {
                ABTValue ret = null;
                ret = setValue(object, prop.getName(), val);
                if (ret instanceof ABTError || ABTError.isError( ret))
                    System.out.println(" An errror in setting the Field: " + prop.getName());
            }
          }
        }
        return;
   }




}
