package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.core.ABTArray;
import com.abtcorp.io.team.connect.data.DataSet;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

public class FVHashtable extends Hashtable implements Expandable{
    
    FVHashtable(){
        super();
    }

    FVHashtable(Hashtable ht){
        for(Enumeration e = ht.keys();e.hasMoreElements();)
        {
            Object key = e.nextElement();
            Object value = ht.get(key);
            this.put(key,value);
            
        }
    }

    public String toString() { return new String("Hashtable{}"); }

    public Hashtable expand(){
        Hashtable data = new Hashtable();
        for(Enumeration e = this.keys(); e.hasMoreElements();)
        {
            Object key = e.nextElement();
            Object value = this.get(key);
            
            Vector dataColumn = new Vector();
            
            if(value instanceof ABTArray)
                dataColumn.addElement(new FVArray((ABTArray)value));
            else if(value instanceof DataSet)
                dataColumn.addElement(new FVDataSet((DataSet)value));
            else if(value instanceof Hashtable)
                dataColumn.addElement(new FVHashtable((Hashtable)value));    
            else 
                dataColumn.addElement(value.toString());

            data.put("" + key, dataColumn);
        }

        return data;
    }
}