package com.abtcorp.io;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTError;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.idl.IABTDriverConstants;

/*
 * IABTServerDriver.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98      SOB         Initial Implementation
  * 08-18-98      SOB         Added execute() signature
  *
  *
  */
public interface IABTServerDriver
{
/**
 *		Opens a connection to a specific data source.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return ABTValue indicating success/failure of the open() request.  If open()
 *             was unsuccessful, then this method returns an ABTError with an
 *             explanatory message.  Otherwise, null;
 */
   public ABTValue open(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Populates the ABTObjectSpace with objects from the data source. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is really an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.
 */
   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Saves the ABTObjects identified in the ABTObjectSet object back to the data source.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *    @return ABTValue indicating success/failure of the save operation.  If a failure occurred, an ABTError;
 *             null, otherwise.
 */
   public ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Closes a connection to a specific data source.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public ABTValue close(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Executes a driver-specific command.  All command arguments arrive via the args
 *    hash table.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

}