package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

public class UserData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public UserData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_USER) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            // Store ids of the various objects.
            if (property.getName().equals(FLD_TW_RESOURCES) || property.getName().equals(FLD_TW_EPP_PROJECTS) || property.getName().equals(FLD_TW_RESOURCE_APPROVAL) || property.getName().equals(FLD_TW_MGR_PROJECTS)) storeObjectIds(table,property.getName());
            else table.put(property.getName(),value);
         }
      }
      return table;
   }

   private void storeObjectIds(Hashtable table, String property)
   {
      DataArray ids = new DataArray();
      ABTValue temp = object_.getValue(session_,property);

      if (ABTError.isError(temp) || ABTEmpty.isEmpty(temp)) return;

      ABTObjectSet set = (ABTObjectSet)temp;
      for (int i = 0;i < set.size(session_);i++) {
         ABTObject object = (ABTObject)set.at(session_,i);

         ABTValue id = object.getValue(session_,FLD_TW_INTERNALID);

         if (ABTError.isError(id) || ABTEmpty.isEmpty(id)) continue;
         ids.add(id);
      }

      table.put(property,ids);
   }
}
