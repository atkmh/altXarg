package com.abtcorp.io.team.connect.data;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Hashtable;

public class TWInputStream extends ObjectInputStream implements StreamNames
{
   Hashtable properties_              = new Hashtable(10,(float)1.0);
   boolean enableResolve_             = false;

   private static URLConnection getURLConnection(URL url) throws IOException
   {
      URLConnection connection = url.openConnection();

      connection.setDoInput(true);
      connection.setDoOutput(false);
      connection.setUseCaches(false);

      return connection;
   }

   public TWInputStream(InputStream stream) throws IOException, StreamCorruptedException
   {
      super(stream);
   }

   public TWInputStream(String path) throws IOException
   {
      this(new FileInputStream(path));
   }

   public TWInputStream(URLConnection connection) throws IOException
   {
      this(connection.getInputStream());
   }

   public TWInputStream(URL url) throws IOException
   {
      this(getURLConnection(url));
   }

   public TWInputStream(URL url, String path) throws IOException
   {
      this(new URL(url, path));
   }

   protected Object resolveObject(Object object) throws IOException
   {
      if (object instanceof DataRow) {
         DataRow record = (DataRow)object;
         
         ManagerKey mKey = (ManagerKey)get(MANAGER_KEY);
         
         return record.resolve(mKey);
      }

      return super.resolveObject(object);
   }

   public Object set(Object key)                {return set(key, new Boolean(true));}
   public Object set(Object key, Object value)  {return properties_.put(key, value);}
   public Object get(Object key)                {return properties_.get(key);}
   public Object reset(Object key)              {return properties_.remove(key);}

   public void close() throws IOException
   {
      super.close();
      properties_ = null;
   }

   public void setEnableResolve(boolean flag)
   {
      enableResolve_ = flag;
      enableResolveObject(flag);
   }

   public boolean isResolvingObjects() {return enableResolve_;}

   public void setAllIncludes()
   {
      set(INCLUDE_USER_RESOURCES);
      set(INCLUDE_RESOURCE_PROJECTS);
      set(INCLUDE_ASSIGNMENT_DETAILS);
   }
}