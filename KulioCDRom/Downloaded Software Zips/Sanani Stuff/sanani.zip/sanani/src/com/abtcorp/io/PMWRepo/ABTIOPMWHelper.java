package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWHelper.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-14-98    SOB            changes to support new IO helper architecture
 * 07-15-98    SOB            changes to support common save() processing
 * 08-12-98    SOB            Mods to support new ABTRemoteID API
 * 08-25-98    SOB            Mods to support Hajo's new deleted objects API
 * 10-09-98    SOB            Beginnings of progress reporting
 * 12-04-98    SOB            #643
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWHelper is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to provide helper methods for reading and writing PMW objects to and from the
 *  ABT repository.
 *  <pre>
 *       ABTIOPMWRepoResource rd = new ABTIOPMWRepoResource(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */
import com.abtcorp.idl.*;
import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Enumeration;
import java.util.Vector;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;


public abstract class ABTIOPMWHelper extends ABTIORepoHelper implements IABTPMRuleConstants, IABTPMWRepoConstants

{
   /**
   *  forceAddNew_ is a boolean flag which when true, indicates that a new tuple must be added to a repository table.
   */
   protected boolean forceAddNew_ = false;

   /**
   *  wbsSequence_ is used to calculate a task's WBS sequence property prior to the task object being
   *  written to the repository.
   */
   private int wbsSequence_;

   /**
   *  wbsLevel_ is used to calculate a task's WBS level property prior to the task object being
   *  written to the repository.
   */
   private int wbsLevel_;

   /**
   *  TASKLEVELWBS is an internal constant which will be set into a task's WBS level property when
   *  it can be determined that the task object truly a task, i.e., its OFD_ISTASK property is true.
   */
   private static final int TASKLEVELWBS = 16;

   protected ABTCursor cursor_ = null;
   protected ABTRepositoryDriver driver_ = null;
   protected ABTRepository repo_ = null;

   public ABTIOPMWHelper() {/* implicit call to super() here*/}

   public ABTIOPMWHelper(ABTRepositoryDriver driver,
                         String table,
                         String type,
                         IABTInternalProgressListener progress)
   {
      super(driver, table, type, progress);
      driver_ = driver;
      repo_ = driver_.getRepository();
   }

   protected void closeCursor()
   {
      if (cursor_ != null)
      {
         cursor_.release();
         cursor_ = null;
      }
   }

   protected void getDataDictionary()
   {
      //
      // Get the repository data dictionary
      //
      if (dataDictionary_ == null) dataDictionary_ = new ABTRepoDataDictionary();
     	if (!dataDictionary_.isValid()) dataDictionary_.createRepoDataDictionary(driver_.getSession());
   }

/**
 *		Set the WBS sequence and WBS level of each task in a project.  This is
 *    accomplished via a depth-first traversal of the linked list of tasks
 *    anchored in the project.
 *		@return  void
 *		@exception ABTException if a non-recoverable error occurs.
 */
   public void setWBSSequence(ABTObject projObj) throws ABTException
   {
      wbsSequence_ = 1;
      wbsLevel_ = 0;
      ABTObject currentChild = getObject(projObj, OFD_FIRSTCHILDTASK);
      while (currentChild != null)
      {
         depthFirstTraversal(currentChild);
         currentChild = getObject(currentChild, OFD_NEXTTASK);
      }
   }

   private void depthFirstTraversal(ABTObject obj) throws ABTException
   {
      //
      // Set the current value of the WBS sequence number into the current task object.
      // Increment the WBS sequence to the next value.
      //
      setValue(obj, OFD_WBSSEQUENCE, new ABTInteger(wbsSequence_));
      wbsSequence_++;

      //
      // Since we have increased the depth by 1 level, increase the WBS level number by 1 also.
      //
      wbsLevel_++;

      //
      // If the current task object is truly a task, set its WBS level property to TASKLEVELWBS,
      // otherwise set its WBS level property to the value in wbsLevel_.  In the if statement,
      // below, checks are first made for errors, and then the boolean value is checked.
      //
      ABTValue val = getValue(obj, OFD_ISTASK);
      if ( val == null || val instanceof ABTEmpty || !val.booleanValue() )
         setValue(obj, OFD_WBSLEVEL, new ABTInteger(wbsLevel_));
      else
         setValue(obj, OFD_WBSLEVEL, new ABTInteger(TASKLEVELWBS));

      //
      // Get first child task, if any.  Perform a depth first traversal on the first and subsequent child tasks.
      // Handle siblings of those child tasks.
      //
      ABTObject currentChild = getObject(obj, OFD_FIRSTCHILDTASK);
      if ( currentChild != null )
      {
         while (currentChild != null )
         {
            depthFirstTraversal(currentChild);
            currentChild = getObject(currentChild, OFD_NEXTTASK);
         }
      }

      //
      // We are leaving one level of the depth traversal, so decrement the global WBS level value.
      //
      wbsLevel_--;
   }

/**
 *		populate with no parms.  Not used in PMW Repo process.
 *		@return  null
 *		@exception ABTException if a non-recoverable error occurs.
 */
   protected ABTValue populate() throws ABTException
   {
      return null;
   }

   /**
    *    Saves objects from the object space back to the repository.  The order of the tuples
    *    in the cursor's result set is assumed to be ascending by prID.
    *    @param parms: an ABTArray of input parameters meaning to the save process
    *    @exception ABTException if an unrecoverable error occurs.
    */
   public void save(ABTArray parms) throws ABTException
   {
      throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                           "PMWHelper->save(ABTArray parms)",
                                           errorMessages.ERR_NOT_IMPLEMENTED,
                                           "save() using ABTArray parms not implemented!") );
   }

/**
 * Saves objects from the object space back to the repository.  The order of the tuples
 * in the cursor's result set is assumed to be ascending by prID.
 * @param oSet: the object set containing the objects to be saved
 * @return void
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected void save(ABTObjectSet oSet) throws ABTException
   {
      try
      {
         //
         // Get the data model from the data dictionary.
         //
         Vector ps = dataDictionary_.getPropertiesFromDataModel(table_);

         //
         // Iterate through all the non-deleted objects in the object set.
         // Update corresponding tuples in the cursor's result set;  add new
         // tuples where a corresponding tuples do not exist.
         //
         int size = size(oSet);
         for (int i = 0; i < size; i++)
         {
            ABTObject obj = (ABTObject)at(oSet, i);

				//
				// Is a new repository tuple required?  Add one, if so; otherwise,
				// update an existing tuple.
				//
				boolean addNew = addNewRequired(obj);
				if (addNew)
            {
            	// add a new row to the end of the cursor so that the order of the cursor won't
            	// get messed up (the ID of the new row will be greater than the ID of the last
            	// row in the cursor).
            	cursor_.moveEOF();
               cursor_.addNew();

               //
               // save the prID back to the object for future use
               //
               ABTValue prID = cursor_.getField(FLD_ID);
               setValue(obj, OFD_ID, prID);

               //
               // Create and save a remote ID for this object.
               //
               // NOTE:  the following logic is dependent upon being able to set a new remote ID even
               //        if one already exists for the object.
               //
               ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID.intValue() );
               obj.getID().setRemote(userSession_, id);
		      }
            else
				{
					//
					// pre-existing object
					//
               cursor_.edit();
            }

            //
            // Perform exception-based updating of the tuple at the current cursor position.
            //
            setCursorValues(ps, cursor_, obj, this, addNew);
            cursor_.update();

            //
            // Drop the current row from the cursor's result set.  Doing this
            // will facilitate deleting remaining rows in the result set after all
            // add/update/delete processing has taken place.  However, this method
            // will not delete remaining rows in the result set.  That operation is
            // up to the caller.
            //
				cursor_.drop();

         }	// end for loop

         //
         // Now process the deleted objects associated with the input object set.  The
         // remote ID's of these deleted objects are presented in an ABTArray.
         //
         ABTArray da = oSet.getDeletedData(userSession_);
         Enumeration rmtIDEnum = da.elements();

         //
         // For each deleted object in the object set, see if a corresponding tuple exists in the cursor's
         // result set.  If it exists, delete it.  If it doesn't exist, skip the object and get the next
         // one; the tuple has already been deleted.  If the ABTArray contains an object which is not of type
         // ABTRemoteIDRepository, skip it and get the next object.
         //
         while ( rmtIDEnum.hasMoreElements() )
         {
            Object rmtID = rmtIDEnum.nextElement();
            if ( !(rmtID instanceof ABTRemoteIDRepository) )
               continue;
            int id = (int) ((ABTRemoteIDRepository)rmtID).getPrID();
            if ( cursor_.bsearchFirst(FLD_ID, new ABTInteger(id)) )
               cursor_.delete();
         }
      }        // end try block
      finally
      {
         //
         // For now, there is no finally-related processing.
         //
      }
   }

   protected boolean addNewRequired(ABTObject obj) throws ABTException
   {
      //
      // If we need to force an add-new operation, then that overrides any other
      // tests we might make to determine whether an add-new operation needs to take
      // place.
      //
      if (forceAddNew_) return true;

      boolean ret = true;    // assume a cursor addNew() is required

      //
      // A cursor addNew()is NOT required if all of the following are true:
      //
      // 1. The object's remote ID is not null.
      // 2. The object's remote ID is an instance of the ABTRemoteIDRepository class.
      // 3. The repository ID of the object is the same as the repository ID of the
      //    repository to which we are connected.
      // 4. The object's corresponding tuple exists in the cursor's result set.
      //
      // If any of the above is not true, a cursor addNew() is required, and this method
      // must return true to the caller.
      //
      ABTValue rmtID = obj.getID().getRemote(userSession_);
      if (rmtID != null &&
          rmtID instanceof ABTRemoteIDRepository &&
          ((ABTRemoteIDRepository)rmtID).getRepositoryID() == repo_.getID() )
      {
		   ABTValue id = getValue(obj, OFD_ID);
      	if ( cursor_.bsearchFirst(FLD_ID, id) )
      	   ret = false;
      }                 // end if

      return ret;
   }

   public int acquireLock(String extID, long projectID) throws ABTException
   {
      int ret = 0;
      ABTCursor cursor = null;
      int userID = repo_.getSession().getUserID();
      try
      {
         //
         // Obtain a cursor and make sure it is positioned on the project's tuple.  If the logged-on user already has the
         // lock, merely return to the caller.  Otherwise, attempt to get the import/export lock
         // for the project.  If the user ID returned from the lock() invocation is equal to the user ID of the person owning
         // the repository session, then all is well and the lock is held.  Otherwise, it's time to report an error.
         //
         cursor = repo_.select( TBL_PROJECT );
         String proj = (extID != null) ? (FLD_EXTERNALID + " = " + repo_.sqlString( extID ) ) :
                       (FLD_ID + " = " + projectID);
         cursor.andFilter(proj);
         if (cursor.moveFirst())
         {
            if ( cursor.checkLock(LCK_IMPORTEXPORT, false ) == userID )
               ret = LOCK_ALREADY_HELD;
            else if ( cursor.lock(LCK_IMPORTEXPORT, false ) == userID )
               ret = LOCK_ACQUIRED;
         }
         else
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "PMWHelper->acquireLock",
                                                 errorMessages.ERR_COULD_NOT_GET_LOCK,
                                                 null) );
         return ret;
      }
      finally
      {
         cursor.release();
         //return ret;
      }
   }

   public long releaseLock(String extID)
   {
      long  lockHolderUID = 0;

      ABTCursor cursor = repo_.select(LOCK_SELECT + /*#643*/ repo_.sqlString(extID) );
      if ( cursor.moveFirst() )
         lockHolderUID = cursor.unlock(LCK_IMPORTEXPORT);
      cursor.release();
      return lockHolderUID;
   }

}