
package com.abtcorp.hub;

/*
 * ABTRowSetDelta.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.ABTSortedArray;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTSortedArray;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTDefaultComparator;
import java.util.Enumeration;

public class ABTRowSetDelta implements IABTTransactionData
{
   boolean root = false;

   private ABTSortedArray data;
   private ABTArray dataLookup;

   private ABTSortedArray newRows;
   private ABTSortedArray removedRows;

   private int indices;


   private ABTArray newRowsL;
   private ABTArray removedRowsL;




   public ABTRowSetDelta(ABTArray indices_)
   {
      root = true;
      data = new ABTSortedArray(new ABTRowComparator());

      dataLookup = new ABTArray();


      indices = indices_.size();

      for (int j = 0; j < indices; j++)
      {
         ABTSortedArray ar = new ABTSortedArray(new ABTDefaultComparator());
         dataLookup.add(ar);
      }
      newRows = null;
      removedRows = null;
      newRowsL = null;
      removedRowsL = null;
   }

   /**
   *  default constructor
    * creates the internal row-management structure
    * @param rule_ associated ruleset
    */
   public ABTRowSetDelta(ABTRowSetDelta parent)
   {
      data = parent.data;
      dataLookup = parent.dataLookup;
      indices = parent.indices;

      int i = indices;


      if (parent.newRows != null)
      {
        newRows = new ABTSortedArray(parent.newRows);
        removedRows = new ABTSortedArray(parent.removedRows);
        newRowsL = new ABTArray();
        removedRowsL = new ABTArray();

        for (int j = 0; j < i; j++)
        {
            ABTSortedArray ar = new ABTSortedArray(
                                    (ABTSortedArray)(parent.newRowsL.at(j))
                                    );
            newRowsL.add(ar);
            ar = new ABTSortedArray(
                                    (ABTSortedArray)(parent.removedRowsL.at(j))
                                    );
            removedRowsL.add(ar);
        }
      }
      else
      {
        newRows = new ABTSortedArray(new ABTRowComparator());
        removedRows = new ABTSortedArray(new ABTRowComparator());
        newRowsL = new ABTArray();
        removedRowsL = new ABTArray();
        for (int j = 0; j < i; j++)
        {
           ABTSortedArray ar = new ABTSortedArray(new ABTDefaultComparator());
           newRowsL.add(ar);
           ar = new ABTSortedArray(new ABTDefaultComparator());
           removedRowsL.add(ar);
        }
      }
   }


   /**
   *  default constructor
    * creates the internal row-management structure based on an existing one...
    * @param rule_ associated ruleset
    */
   protected void removeRow(ABTRow row)
   {
     if (root)
     {
        data.remove(row);
     }
     else
     {
       if (newRows.remove(row) == 0)
          removedRows.add(row);
     }
   }


   protected void removeIndex(ABTRow row, int index, ABTValue id)
   {
      if ((index < 0) || (index >= indices))
         return;
      if (ABTValue.isNull(id))
         return;
     try
     {
        if (root)
        {
           ABTSortedArray ar = (ABTSortedArray)(dataLookup.at(index));
           ar.remove(id);
        }
        else
        {
          ABTSortedArray ar = (ABTSortedArray)(newRowsL.at(index));
          if (ar.remove(id) == 0)
          {
             ar = (ABTSortedArray)(removedRowsL.at(index));
             ar.add(new ABTRowLookup(id,row));
          }
        }
     }
     catch (Exception e)
     {
     }
   }


   protected void addRow(ABTRow newRow)
   {
     if (root)
     {
       data.add(newRow);
     }
     else
     {
        if (removedRows.remove(newRow) == 0)
          newRows.add(newRow);
     }
   }

   protected void addIndex(ABTRow newRow, int index, ABTValue id)
   {
   if ((index < 0) || (index >= indices))
      return;
   if (ABTValue.isNull(id))
      return;
   try
   {
       if (root)
       {
          ABTSortedArray ar = (ABTSortedArray)(dataLookup.at(index));
          ar.add(new ABTRowLookup(id,newRow));
       }
        else
        {
          ABTSortedArray ar = (ABTSortedArray)(removedRowsL.at(index));
          if (ar.remove(id) == 0)
          {
             ar = (ABTSortedArray)(newRowsL.at(index));
             ar.add(new ABTRowLookup(id,newRow));
          }
        }
    }
     catch (Exception e)
     {
     }

   }

    protected ABTArray getArray()
    {
      ABTSortedArray array = new ABTSortedArray(data);
      if (!(root))
          merge(array);
      return array;
    }


      public IABTTransactionData copyData()
      {

         return new ABTRowSetDelta(this);
     }


   public IABTTransactionData rollUp(IABTTransactionData target_)
   {
      ABTRowSetDelta target = (ABTRowSetDelta)target_ ;
      synchronized(data)
      {
      if (!(target.root))
      {
        target.newRows = newRows;
        target.removedRows = removedRows;
        target.newRowsL = newRowsL;
        target.removedRowsL = removedRowsL;
      }
      else
      {
        data.merge(newRows);
        data.remove(removedRows);

        int i = indices;
        for (int j = 0; j < i; j++)
        {
            ABTSortedArray mtarget = (ABTSortedArray)(dataLookup.at(j));
            ABTSortedArray msource = (ABTSortedArray)(newRowsL.at(j));
            mtarget.merge(msource);
            msource.clear();
            msource = (ABTSortedArray)(removedRowsL.at(j));
            mtarget.remove(msource);
            msource.clear();
        }
        Enumeration e = removedRows.elements();
        while (e.hasMoreElements())
        {
            ABTRow r1 = (ABTRow) e.nextElement();
            r1.destroy();
        }
        removedRows.clear();
      }
      newRows = null;
      removedRows = null;
      newRowsL = null;
      removedRowsL = null;
      data = null;
      }
      return target;
   }


   protected void merge(ABTSortedArray data_)
   {
        data_.merge(newRows);
        data_.remove(removedRows);
   }



   /**
   *  return a row with a given search value
   *  @param id ABTID of row
   *  @return ABTRow if successfull or null if not found
   */
   protected final ABTRow get(int index,ABTValue id)
   {
      if ((index < 0) || (index >= indices))
         return null;
      if (ABTValue.isNull(id))
         return null;

      try
      {
         // first try to find it in the original set
         ABTSortedArray mtarget = (ABTSortedArray)(dataLookup.at(index));
         int i = mtarget.indexOf(id);
         if (i > -1)
         {
            // was it deleted?
            if (!(root))
            {
               ABTSortedArray starget = (ABTSortedArray)(removedRowsL.at(index));
               int i2 = starget.indexOf(id);
               if (i2 > -1)
                  return null;
            }
            return ((ABTRowLookup)mtarget.at(i)).row;
         }
      }
      catch (Exception e)
      {
         return null;
      }
      if (root)
          return null;

      try
      {
         ABTSortedArray mtarget = (ABTSortedArray)(newRowsL.at(index));
         int i = mtarget.indexOf(id);
         if (i > -1)
            return ((ABTRowLookup)mtarget.at(i)).row;
         else
            return null;
      }
      catch (Exception e)
      {
         return null;
      }

   }


   /**
   *  return a row with a given id
   *  @param id ABTID of row
   *  @return ABTRow if successfull or null if not found
   */
   protected final ABTRow get(ABTID id)
   {
      int index = data.indexOf(id);
      if (index > -1)
      {
         // was it deleted?
         if (!(root))
         {
            int index2 = removedRows.indexOf(id);
            if (index2 > -1)
               return null;
         }
         return ((ABTRow)data.at(index));
      }
      if (root)
          return null;
      index = newRows.indexOf(id);
      if (index > -1)
         return ((ABTRow)newRows.at(index));
      else
         return null;
   }


   /**
   *  return a row with a given id
   *  @param id ABTID of row
   *  @return ABTRow if successfull or null if not found
   */
   protected final ABTRow getExisting(int index,ABTValue id)
   {
      if ((index < 0) || (index >= indices))
         return null;
      if (ABTValue.isNull(id))
         return null;
      try
      {
         ABTSortedArray mtarget = (ABTSortedArray)(dataLookup.at(index));
         int i = mtarget.indexOf(id);
         if (i > -1)
            return ((ABTRowLookup)mtarget.at(i)).row;
         if (root)
             return null;
         mtarget = (ABTSortedArray)(newRowsL.at(index));
         i = mtarget.indexOf(id);
         if (i > -1)
            return ((ABTRowLookup)mtarget.at(i)).row;
      }
      catch (Exception e)
      {
         return null;
      }
      return null;
   }




}

