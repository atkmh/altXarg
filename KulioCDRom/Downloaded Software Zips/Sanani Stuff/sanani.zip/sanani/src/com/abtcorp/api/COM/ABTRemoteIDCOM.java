package com.abtcorp.api.com;

import com.abtcorp.core.*;

public class ABTRemoteIDCOM implements IABTRemoteIDCOM
   {
   public ABTRemoteIDCOM() { this( null ); }
   public ABTRemoteIDCOM(ABTRemoteID rid) {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base   = new ABTBaseJavaCOM(rid);
      /**/
      }

   //aggregated access wrapper
   /**/
   protected ABTBaseJavaCOM _base;      // aggregated base array object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()      { return _base.getObject(); }
   public String toString()       { return _base.toString();};
   public String ToString()       { return _base.ToString();};
   public int  getHashCode()      { return _base.hashCode();}
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo()   { return _base.getClassInfo();}
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   }