/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

/** @com.register(clsid=71D14CB0-F986-11d1-ADFA-00E029143BC6,
                typelib=A2FAB780-BDD1-11D1-ADE6-00E029143BC6,
                progid="com.abtcorp.api.com.ABTCalendarCOM.1",
                version="1.0")*/

public class ABTCalendarCOM implements IABTCalendarCOM
   {
   public ABTCalendarCOM() {
      this(new ABTCalendar());
      }

   public ABTCalendarCOM(ABTCalendar cal)
      {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(cal);
      /**/
      }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private ABTCalendar _cal;
   private ABTCalendar cal() {
      if (_cal == null) _cal = (ABTCalendar)getObject();
      return _cal;
      }

   public IABTCalendarCOM getParent()
      { 
      ABTCalendar pcal = cal().getParent();
      if (pcal == null) return null;
      return new ABTCalendarCOM(pcal);
      }

   public void setParent(IABTCalendarCOM parent){
      if (parent == null)
         cal().setParent(null);
      else
         cal().setParent((ABTCalendar)parent.getObject());
      }

   public IABTExceptionListCOM getExceptions()
      {
      ABTExceptionList exceps = cal().getExceptions();
      if (exceps == null) return null;
      return new ABTExceptionListCOM(exceps);
      }

   public int      getWorkweek()
      { return cal().getWorkweek(); }

   public void     setWorkweek(int workweek)
      { cal().setWorkweek(workweek); }

   public IABTShiftListCOM getShiftsForDay(int day, boolean composite)
      {
      ABTShiftList sl = cal().getShifts(day,composite);
      if (sl == null) return null;
      return new ABTShiftListCOM(sl);
      }

   public IABTShiftListCOM getShiftsForDate(Variant date, boolean composite)
      {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      ABTShiftList sl = cal().getShifts(Adate, composite);
      if (sl == null) return null;
      return new ABTShiftListCOM(sl);
      }

   public void     resetShiftsForDay(int day)
      { cal().resetShifts(day); }

   public void     setShiftsForDay(int day, IABTShiftListCOM shifts) {
      ABTShiftList slist = null;
      if (shifts != null)
         slist = (ABTShiftList)shifts.getObject();
      cal().setShifts(day, slist);
      }

   public void     resetShifts(Variant start, Variant finish) {
      ABTDate Astart = new ABTDate(VariantMunger.VariantToValue(start),false);
      ABTDate Afinish= new ABTDate(VariantMunger.VariantToValue(finish),false);
      cal().resetShifts(Astart,Afinish);
      }

   public void     setShifts(Variant start, Variant finish, IABTShiftListCOM shifts) {
      ABTShiftList slist = null;
      if (shifts != null)
         slist = (ABTShiftList)shifts.getObject();
      ABTDate Astart = new ABTDate(VariantMunger.VariantToValue(start),false);
      ABTDate Afinish= new ABTDate(VariantMunger.VariantToValue(finish),false);
      cal().setShifts(Astart,Afinish,slist);
      }

   public void     resetShiftsForDate(Variant date){
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      cal().resetShifts(Adate);
      }

   public void     setShiftsForDate(Variant date, IABTShiftListCOM shifts) {
      ABTShiftList slist = null;
      if (shifts != null)
         slist = (ABTShiftList)shifts.getObject();
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      cal().setShifts(Adate, slist);
      }

   public boolean  isDayException(int day)
      { return cal().isException(day); }

   public boolean  isDateException(Variant date, boolean composite) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return cal().isException(Adate,composite);
      }

   public boolean  isDayWorkday(int day) {return cal().isWorkday(day); }
   public boolean  isDateWorkday(Variant date)
      {return cal().isWorkday(new ABTDate(VariantMunger.VariantToValue(date),false));}

   public Variant  nextWorkday(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().nextWorkday(Adate));
      }

   public Variant  prevWorkday(Variant date){
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().prevWorkday(Adate));
      }

   public Variant  nextHoliday(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().nextHoliday(Adate));
      }

   public Variant  prevHoliday(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().prevHoliday(Adate));
      }

	public Variant	nextHolitime(Variant time)
	   {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return VariantMunger.ValueToVariant(cal().nextHolitime(t));
	   }

	public Variant	prevHolitime(Variant time)
      {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return VariantMunger.ValueToVariant(cal().prevHolitime(t));
      }

   public Variant  addWorkday(Variant date, int days) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().addWorkday(Adate,days));
      }

   public Variant  subWorkday(Variant date, int days) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), true);
      Variant newVal = VariantMunger.ValueToVariant(cal().subWorkday(Adate,days));
      double dv = newVal.toDouble() + 1;
      newVal.putDate(dv);
      return newVal;
      }

   public int      diffWorkday(Variant start, Variant finish) {
      ABTDate Astart = new ABTDate(VariantMunger.VariantToValue(start),false);
      ABTDate Afinish= new ABTDate(VariantMunger.VariantToValue(finish),false);
      return cal().diffWorkday(Astart,Afinish);
      }

   public boolean  isWorktime(Variant time) {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return cal().isWorktime(t);
      }

   public Variant  nextWorktime(Variant time) {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return VariantMunger.ValueToVariant(cal().nextWorktime(t));
      }

   public Variant  prevWorktime(Variant time) {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return VariantMunger.ValueToVariant(cal().prevWorktime(t));
      }

   public Variant  addWorktime(Variant time, int seconds) {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return VariantMunger.ValueToVariant(cal().addWorktime(t, seconds));
      }

   public Variant  subWorktime(Variant time, int seconds) {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return VariantMunger.ValueToVariant(cal().subWorktime(t, seconds));
      }

   public int      diffWorktime(Variant time1, Variant time2) {
      ABTTime t1  = (ABTTime)VariantMunger.VariantToValue(time1);
      ABTTime t2  = (ABTTime)VariantMunger.VariantToValue(time2);
      return cal().diffWorktime(t1,t2);
      }

   public Variant  startWorktime(Variant date) {
      ABTDate td = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().startWorktime(td));
      }

   public Variant  finishWorktime(Variant date){
      ABTDate td = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(cal().finishWorktime(td));
      }

   public void     optimize()
      { cal().optimize(); }

   public double   getHoursPerDay()
      { return cal().getHoursPerDay(); }

   public double   getHoursPerWeek()
      { return cal().getHoursPerWeek(); }

   public double   getHoursPerMonth()
      { return cal().getHoursPerMonth(); }

   public double   getHoursPerYear()
      { return cal().getHoursPerYear(); }

   public IABTCalendarCOM Clone(){
      return new ABTCalendarCOM((ABTCalendar)cal().clone());
      }

   public IABTShiftListCOM standardWorkday(){
      return new ABTShiftListCOM(ABTShiftList.WORK);
      }

   public IABTShiftListCOM standardHoliday(){
      return new ABTShiftListCOM(ABTShiftList.HOLIDAY);
      }

   }
