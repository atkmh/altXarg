package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.io.team.*;
import com.abtcorp.io.team.connect.data.*;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Point;

import javax.swing.*;

class ViewerTableDataModel extends javax.swing.table.AbstractTableModel
{
    int rowCount_ = 0;
    int columnCount_ = 0;
    Vector columns_;
    String[] headers_;

    ViewerTableDataModel(Hashtable data){
        columnCount_ = data.size();
 
        columns_ = new Vector();
        headers_ = new String[columnCount_];
            
        int i = 0;
        if(data.containsKey("Key"))  // Make sure "Key" column (if present), 
        {                            //  is alwasy farthest left
            headers_[i] = new String("Key");
            columns_.addElement(data.get("Key"));
            data.remove("Key");
            i++;
        }
            
        for(Enumeration e = data.keys(); e.hasMoreElements(); i++){
            String header = (String)e.nextElement();
            headers_[i] = new String(header);
            columns_.addElement(data.get(header));
        }
        
        if(!isEmpty())
        {
            rowCount_ = ((Vector)columns_.elementAt(0)).size();
            columns_.trimToSize(); 
        }
    }

	public Object getValueAt( int iRowIndex, int iColumnIndex ){	    
        try{
            return "" + ((Vector)columns_.elementAt(iColumnIndex)).elementAt(iRowIndex);
        }
        catch(ArrayIndexOutOfBoundsException e){
            return "nil";
        }
	}

    public Object getObjectAt(int iRowIndex, int iColumnIndex){
        return ((Vector)columns_.elementAt(iColumnIndex)).elementAt(iRowIndex);

    }
    
    public void setValueAt( Object aValue, int iRowIndex, int iColumnIndex ){ /*nothing to do here*/ }
    
    public int getColumnCount()             {return columnCount_; }
    public int getRowCount()                {return rowCount_; }
    public String getColumnName(int column) {return headers_[column]; }

    public boolean isEmpty(){    
        if(columnCount_ <= 0)
            return true;
        else return false;
    }
    
    public Point findKey(String val){
        Vector column = (Vector)columns_.elementAt(0);
        int row = -1;
        for(int i=0; i<column.size(); i++){
            String current = "" + column.elementAt(i);
            if(current.intern() == val.intern()){
                row = i;
            }
        }
        if(row >= 0)
            return new Point(0,row);
        else return null;
    }
	
	public void dump(){
	    for(int i=0; i < columnCount_; i++){
           System.out.println(headers_[i] + "");
	       for(int j = 0; j < rowCount_; j++){
	           System.out.println("" + ((Vector)columns_.elementAt(i)).elementAt(j));
	       }
	    
	    }   
	}
}