package com.abtcorp.io.client.mppfile;

import com.abtcorp.core.ABTRemoteID;

/*
 * ABTClientMppRemoteID.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date          Author        Description
  * 04-02-98      SOB           Initial Design
  * 08-25-98      ATW           Subclassed for MPP driver
  *
  *
  */


/**
 *  ABTClientMppRemoteID class extends the the ABTRemoteID abstract class for
 *  the Microsoft Project MPP file driver.
 *
 *  <pre>
 *       This class implements all methods of the ABTRemoteID abstract class.
 *       The purpose is to provide a way of uniquely identifying the remote source for
 *       an ABTObject.
 *
 *  </pre>
 *
 * @version	    1.0
 * @author      A. Waller
 * @see	        ABTRemoteID
 */

public class ABTClientMppRemoteID extends ABTRemoteID
{
	private String fileName_;
	private int uniqueID_;

	/**
	*    Create a default ABTClientMppRemoteID object.  If this
	*    constructor is used, the setFileName() & setUniqueID() methods must be used
	*    subsequently to complete the construction of the object.
	*/

	public ABTClientMppRemoteID()
	{
		fileName_ = null;
		uniqueID_ = 0;
	}

	/**
	*    Create a ABTClientMppRemoteID object using the file name and the
	*    unique ID of the element in the MPP file.
	*/

	public ABTClientMppRemoteID ( String fileName, int uniqueID )
	{
		fileName_ = fileName;
		uniqueID_ = uniqueID;
	}

	/**
	*    Get the MPP file name component of this ABTClientMppRemoteID object.
	*
	*/

	public String getFileName() { return fileName_; }

	/**
	*    Set the file name component of this ABTClientMppRemoteID object.
	*    @param repositoryID The MPP file name (minus the path) the object came from.
	*    This value, along with the unique ID Microsoft Project assigns to each
	*    element of a project, uniquely identifies the source of the ABTObject.
	*
	*/

	public void setFileName( String fileName ) { fileName_ = fileName;}

	/**
	*    Get the uniqueID component of this ABTClientMppRemoteID object.
	*
	*/

	public int getUniqueID() { return uniqueID_; }

	/**
	*    Set the uniqueID component of this ABTClientMppRemoteID object.
	*    @param uniqueID The unique ID with which this object is associated.  This value,
	*    along with the MPP file name, uniquely identifies the source of the
	*    ABTObject.
	*
	*/

	public void setUniqueID( int uniqueID ) { uniqueID_ = uniqueID; }

	/**
	*  - required routine to allow storing in sorted sets
	*    @param object - to compare against
	*    @return int 0 => equal, -1 => me < object2, 1 => me > object2
	*/
	public int compareTo( Object object )
	{
      if (object == null) return 1;
		if (!( object instanceof ABTClientMppRemoteID ))
			return -1;

		String nameIn = ( (ABTClientMppRemoteID) object ).getFileName();
		int idIn = ( (ABTClientMppRemoteID) object ).getUniqueID();

		//
		// If both of the file names are equal, and both of
		// the uniqueIDs are equal, then the remote IDs are equal.
		//

		if ( fileName_.equals( nameIn ) && uniqueID_ == idIn )
			return 0;

		//
		// IDs are not equal.  Is it the fileName components that
		// are not the same?
		//

		if ( fileName_.compareTo( nameIn ) < 0 )
			return -1;
		else if ( fileName_.compareTo( nameIn ) > 0 )
			return +1;

		//
		// File names are equal; the uniqueIDs are not equal.
		//

		return idIn < uniqueID_ ? -1 : +1;
	}


	/**
	*  - required routine to allow storing in sorted sets
	*    @param object - to compare against
	*    @return boolean true for equal
	*/
	public boolean equals ( Object object )
	{
		return compareTo( object ) == 0 ? true : false;
	}

	/**
	*    required routine to allow unique access in sets
	*    @return int - hashcode
	*/

	public int hashCode()
	{
		return uniqueID_;
	}

}