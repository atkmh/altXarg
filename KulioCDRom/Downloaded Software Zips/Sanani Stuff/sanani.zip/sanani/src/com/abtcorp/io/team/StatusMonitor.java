package com.abtcorp.io.team;

// Interface used to monitor the status of operations in the object space.
public interface StatusMonitor
{
   public void updateStatus(Object operation, Object object, int total, int completed);
}