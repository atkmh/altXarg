package com.abtcorp.io.team;

import com.abtcorp.core.ABTString;

public interface TWRepoDriverConstants
{
   public final static String USER_QUERY           = "select * from PRUser order by prID".intern();
   public final static String CHARGECODE_QUERY     = "select * from PRChargeCode where prIsOpen<>0".intern();
   public final static String TYPECODE_QUERY       = "select * from PRTypeCode where prIsOpen<>0".intern();
   public final static String TIMEPERIOD_QUERY     = "select * from PRTimePeriod where prIsOpen<>0 order by PRTimePeriod.prStart".intern();
   public final static String CALENDAR_QUERY       = "select prID, prValue from PRCalendar".intern();
   public final static String CATEGORY_QUERY       = "select * from PREnum where prName='prABTNotesCategory' order by prCaption".intern();


   public final static int RESOURCE_DAYS           = 0;
   public final static int RESOURCE_HOURS          = 1;
   public final static int RESOURCE_COST           = 2;
   public final static int RESOURCE_QUANTITY       = 3;

   public final static int FIXED_LOADPATTERN       = 1;

   public static final int PROJECT_NOTE            = 0;
   public static final int TASK_NOTE               = 1;
   public static final int TIMESHEET_NOTE          = 2;

   public static final int USER_RIGHT              = 1;
   public static final int ENTER_TIME_RIGHT        = 2;
   public static final int APPROVE_RIGHT           = 4;

   // Keys used by TWRepoDriver arguments
   public final static ABTString POPULATOR            = new ABTString("Populator".intern());
   public final static ABTString QUERY                = new ABTString("Query".intern());
   public final static ABTString USE_SYSTEM           = new ABTString("USE_SYSTEM".intern());
   public final static ABTString TYPE                 = new ABTString("Type".intern());
   public final static ABTString START                = new ABTString("Start".intern());
   public final static ABTString FINISH               = new ABTString("Finish".intern());
   public final static ABTString STRICT               = new ABTString("Strict".intern());
   public final static ABTString SESSION_ID           = new ABTString("SessionID".intern());
   public final static ABTString USER_ID              = new ABTString("UserID".intern());
   public final static ABTString SESSION_NAME         = new ABTString("SessionName".intern());
   public final static ABTString DELETE_RECORDS       = new ABTString("DeleteRecords".intern());
   public final static ABTString SAVE_NOTES           = new ABTString("SaveNotes".intern());
   public final static ABTString SAVE_TASK            = new ABTString("SaveTask".intern());
   public final static ABTString SERVER_NAME          = new ABTString("ServerName".intern());
   public final static ABTString RELEASE              = new ABTString("Release".intern());
   public final static ABTString SUM_QUERY            = new ABTString("SumQuery".intern());
   public final static ABTString TS_SEARCH_KEY        = new ABTString("TSSearchKey".intern());
   public final static ABTString SUM_FIELD_NAME       = new ABTString("SumFieldName".intern());
   public final static ABTString DELETE_TIMESHEET     = new ABTString("DeleteTimesheet".intern());
   public final static ABTString FORCE_LOAD           = new ABTString("ForceLoad".intern());
   public final static ABTString SESSION              = new ABTString("Session".intern());
   public final static ABTString MONITOR              = new ABTString("Monitor".intern());
   public final static ABTString TE_TIMESHEET         = new ABTString("TE_Timesheet".intern());
   public final static ABTString PROJ_ASSIGN_QUERY 	= new ABTString("Proj_Assign_Query".intern());
   public final static ABTString PROJ_TEAM_QUERY 		= new ABTString("Proj_Team_Query".intern());
   public final static ABTString PROJ_NOTE_QUERY 		= new ABTString("Proj_Note_Query".intern());
   public final static ABTString TIMESHEET_NOTE_QUERY = new ABTString("Timesheet_Note_Query".intern());
	
   // Connect specific queries to support Server designated resources
   // Note these queries require substitutions of the %s string with the URL.
	public final static String SERVER_RESOURCE_QUERY = "select PRResource.*, PRTemporary.prFlags, PRTemporary.prRecordID2 FROM PRResource, PRTemporary" +
                                                      " WHERE PRResource.prID = PRTemporary.prRecordID1" +
                                                      " AND PRTemporary.prSessionID = %d" +
                                                      " AND PRTemporary.prName = 'ResourceRights'" +
                                                      " AND PRResource.prServerName = '%s'" +
                                                      " ORDER BY PRResource.prID";

  public final static String SERVER_PROJECT_QUERY =       "SELECT PRProject.* FROM PRProject, PRTeam, PRTemporary" +
                                                          " WHERE PRProject.prIsOpen <> 0" +
                                                          " AND PRProject.prTrackMode = 2" +
                                                          " AND PRProject.prID = PRTeam.prProjectID" +
                                                          " AND PRTeam.prResourceID = PRTemporary.prRecordID1" +
                                                          " AND PRTemporary.prSessionID = %d" +
                                                          " AND PRTemporary.prName = 'ResourceRights'" +
                                                          " ORDER BY PRProject.prID";

   public final static String SERVER_ASSIGNMENTENTRY_QUERY = "select PRAssignment.*, PRTask.prProjectID, PRTask.prID, prTask.prWBSSequence from PRAssignment, PRTask, PRTimeEntry, PRTimeSheet, PRTimePeriod, PRResource where " +
                                                        "PRAssignment.prTaskID=PRTask.prID and " +
                                                         "PRTimeEntry.prAssignmentID=PRAssignment.prID and " +
                                                         "PRTimeEntry.prTimeSheetID=PRTimeSheet.prID and " +
                                                         "PRAssignment.prResourceID=PRResource.prID and " +
                                                         "PRTimeSheet.prTimePeriodID=PRTimePeriod.prID and " +
                                                         "PRTimeEntry.prCorrectID is null and " +
                                                         "PRTimePeriod.prIsOpen<>0 and " +
                                                         "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0 and PRResource.prServerName='%s') and " +
                                                         "(PRTimeSheet.prStatus<>5) " +
                                                         "order by PRTask.prWBSSequence";
   public final static String SERVER_TIMESHEET_QUERY =    "SELECT PRTimeSheet.* FROM PRTimeSheet, PRTimePeriod, PRTemporary, PRResource" +
                                                          " WHERE PRTemporary.prRecordID1 = PRTimeSheet.prResourceID" +
                                                          " AND PRTemporary.prSessionID = %d" + 
                                                          " AND PRTimeSheet.prResourceID = PRResource.prID" + 
                                                          " AND PRTemporary.prName = 'ResourceRights'" +
                                                          " AND (PRResource.prDOH is null or PRResource.prDOH <= PRTimePeriod.prFinish) and " +
                                                          " (PRResource.prDOT is null or PRResource.prDOT >= PRTimePeriod.prStart)" +
                                                          " AND PRTimeSheet.prTimePeriodID = PRTimePeriod.prID" +
                                                          " AND PRTimePeriod.prIsOpen <> 0" +
                                                          " AND PRTimeSheet.prStatus <> 5" + 
                                                          " ORDER BY PRTimeSheet.prID, PRTimeSheet.prResourceID";
   public final static String SERVER_TIMEENTRY_QUERY      = "select PRTimeEntry.* from PRTimeEntry, PRTimeSheet, PRTimePeriod, PRResource where" +
                                                         " PRTimeEntry.prCorrectID is null and" +
                                                         " PRTimeEntry.prTimeSheetID = PRTimeSheet.prID and" +
                                                         " (PRResource.prDOH is null or PRResource.prDOH <= PRTimePeriod.prFinish) and " +
                                                         " (PRResource.prDOT is null or PRResource.prDOT >= PRTimePeriod.prStart) and " +
                                                         " PRTimeSheet.prResourceID = PRResource.prID and" +
                                                         " PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0 and PRResource.prServerName='%s' and" +
                                                         " PRTimeSheet.prTimePeriodID = PRTimePeriod.prID and" +
                                                         " PRTimePeriod.prIsOpen<>0".intern();
}