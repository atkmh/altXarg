package com.abtcorp.api.local;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;

public class errorMessages extends ListResourceBundle
{
public Object[][] getContents() {
			return contents; 
}


public static final String Package = "com.abtcorp.api.local".intern();
public static final ABTErrorCode ERR_ILLEGAL_HASHTABLE = new ABTErrorCode(Package, "100");
public static final ABTErrorCode ERR_ILLEGAL_ARRAY = new ABTErrorCode(Package, "101");
public static final ABTErrorCode ERR_ILLEGAL_SORTED_ARRAY = new ABTErrorCode(Package, "102");
public static final ABTErrorCode ERR_INVALID_OBJSPACE = new ABTErrorCode(Package, "103");
public static final ABTErrorCode ERR_EXCEPTION = new ABTErrorCode(Package, "104");
public static final ABTErrorCode ERR_INVALID_VALUE = new ABTErrorCode(Package, "105");
public static final ABTErrorCode ERR_READ_ONLY = new ABTErrorCode(Package, "106");
public static final ABTErrorCode ERR_CLASS_NOTFOUND = new ABTErrorCode(Package, "107");
public static final ABTErrorCode ERR_CANT_INSTANTIATE = new ABTErrorCode(Package, "108");
public static final ABTErrorCode ERR_ILLEGAL_ACCESS = new ABTErrorCode(Package, "109");
public static final ABTErrorCode ERR_INVALID_DRIVER = new ABTErrorCode(Package, "110");



static final Object[][] contents = {
{ERR_ILLEGAL_HASHTABLE.getCode(),"clients should not use core.ABTHashtable.  Use api.local.ABTHashTable instead."},
{ERR_ILLEGAL_ARRAY.getCode(),"clients should not use core.ABTSortedArray.  Use api.local.ABTSortedArrayLocal instead."},
{ERR_ILLEGAL_SORTED_ARRAY.getCode(),"clients should not use core.ABTArray.  Use api.local.ABTArrayLocal instead."},
{ERR_INVALID_OBJSPACE.getCode(),"Invalid object space"},
{ERR_EXCEPTION.getCode(),"An unexpected exception was caught"},
{ERR_INVALID_VALUE.getCode(),"found a non-ABTValue element"},
{ERR_READ_ONLY.getCode(),"This class is read-only"},
{ERR_CLASS_NOTFOUND.getCode(),"Class not found exception caught"},
{ERR_CANT_INSTANTIATE.getCode(),"Instantiation exception caught"},
{ERR_ILLEGAL_ACCESS.getCode(),"IllegalAccess exception caught"},
{ERR_INVALID_DRIVER.getCode(),"Attempt to access invalid driver"},

 };
}