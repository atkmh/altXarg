

package com.abtcorp.core;


public class ABTSequenceNode extends ABTValue
{
   ABTArray _levels;
   short _level = 0;

   ABTValue _value = null;

   public ABTSequenceNode(ABTValue val_)
   {
      _value = val_;
      _levels = new ABTArray();
   }
   public void addLevel(short level_)
   {
         if (_level == 0)
            _levels.add(new ABTShort(level_));
         else
         {
            ABTArray _levelst = new ABTArray();
            _levelst.add(new ABTShort(level_));
            for (int i = 0; i < _level; i++)
               _levelst.add(_levels.at(i));
           _levels = _levelst;
         }
         _level++;
   }

   public ABTSequenceNode parent(ABTSequenceNode other_)
   {
      short max = _level<other_._level?_level:other_._level;
      for (int i = 0 ; i<max;i++)
      {
         if (((ABTShort)_levels.at(i)).compareTo(((ABTShort)other_._levels.at(i)))!=0)
            return null; // not the same path;
      }
      return _level<other_._level?this:other_;
   }

   public ABTValue getValue()
   {
      return _value;
   }

} 