package com.abtcorp.blob;

import com.abtcorp.core.*;
import java.text.*;
import java.io.Serializable;

public final class ABTShift implements ABTComparable, Serializable
{
   private static final long serialVersionUID = 8765435929047748252L;
	private int start_;
   private int finish_;

   public ABTShift(int start, int finish) {start_ = start; finish_ = finish;}

   public final int getStart()    {return start_;}
   public final int getFinish()   {return finish_;}
   public final int getDuration() {return finish_ - start_;}

   public boolean equals(Object object)
   {
      if (this == object) return true;

      return object != null && object instanceof ABTShift && compareTo(object) == 0;
   }

   public int compareTo(Object object)
   {
    if (object == null) return 1;
    return compareTo((ABTShift)object);
   }

   public final int compareTo(ABTShift shift)
   {
      if (start_  < shift.start_)   return -1;
      if (start_  > shift.start_)   return +1;
      if (finish_ < shift.finish_)  return -1;
      if (finish_ > shift.finish_)  return +1;

      return 0;
   }

   public String toString()
   {
      DateFormat format = DateFormat.getTimeInstance(DateFormat.SHORT);

      return format.format(ABTDate.toDate(0, start_)) + "-" + format.format(ABTDate.toDate(0, finish_));
   }
}