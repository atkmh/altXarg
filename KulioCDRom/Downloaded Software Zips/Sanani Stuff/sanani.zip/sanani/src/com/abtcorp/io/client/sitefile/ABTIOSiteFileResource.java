package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileResource.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-1-98    MXA         Initial Implementation
 *
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;



/**
 *  ABTIOSiteFileResource is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOSiteFileDriver.
 *
 *  <pre>
 *       ABTIOSiteFileResource fr = new ABTIOSiteFileResource(driver, parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOSiteFileDriver
 */

public class ABTIOSiteFileResource extends ABTIOSiteFileHelper implements IABTRuleConstants
{

//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOSiteFileResource constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOSiteFileResource(ABTIOSiteFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_RESOURCE);
      site_ = parent;
   }
/**
 *  Saves the resource objects back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving notes)
 *	@param oSet   the resource object set to be saved back to the loal file
 *  @return       the objects set that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObjectSet oSet) throws ABTException
   {
    try
    {
        super.save(oSet);
      // save the subordinate objects of all the resource in the object set.
       saveOtherObjects(oSet);
    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
       return (ABTValue)oSet;
    }


   }

   private void saveOtherObjects(IABTObjectSet oSet) throws ABTException
   {
   	// loop through all the objects in the object set
      for (int i = 0; i < size(oSet); i++)
      {
        IABTObject obj = (IABTObject)at(oSet, i);

      	// save the notes.
      	ABTIOSiteFileNote noteHelper = new ABTIOSiteFileNote(driver_, obj);
       	noteHelper.save(obj, OFD_NOTES);
      }
   }


/**
 * Populate site's resource.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
 protected ABTValue populate() throws ABTException
 {
        ABTValue     val       = null;
	    ABTValue     ret       = null;
        ABTRemoteID  remoteId  = null;
        IABTLocalID   id       = null;
        ABTObjectSetIDList resourceIds = null;
        IABTLocalID        curId       = null;
        Object             obj         = null;

        id = driver_.getSiteId();
        val = getIDs(id,OBJ_SITE, OFD_RESOURCES);

        if (val instanceof ABTObjectSetIDList)
            resourceIds  = (ABTObjectSetIDList)val;
        else
            throw new ABTException("Wrong Cast");
        Enumeration itID = resourceIds.getActiveIDs();
        while( itID.hasMoreElements() )
        {

           obj = null;
           obj = itID.nextElement();
           if ((obj instanceof IABTLocalID) || (obj == null))
            id_ = (IABTLocalID)obj;
           else
            throw new ABTException("Wrong Cast");

           curId = id_;
           ret = super.populate();

           populateNoteObjects(curId);
        }
        return ret;
 }


   private void populateNoteObjects(IABTLocalID resourceId) throws ABTException
   {
   	// populate the note fields if there is any.
   	ABTIOSiteFileNote nHelper = new ABTIOSiteFileNote(driver_, site_);
    nHelper.populate(resourceId);
   }

/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
     Object object = null;
      //step 1: Set site object reference in the req parm hashtable
      reqParams_.putItemByString(OFD_SITE, (ABTValue)site_);

      //step 2: set base calendar object reference
      ABTValue    val            = null;
      IABTLocalID baseCalendarID = null;

      val = getHashValue(objArr_, propSet_, OFD_BASECALENDAR);
      if (val instanceof IABTLocalID)
        baseCalendarID = (IABTLocalID)val;
      //else
       // throw new ABTException("Wrong Cast");

      if (baseCalendarID != null)
      {
        object = null;
        object = driver_.lookupTableGet(baseCalendarID);

        if (object instanceof IABTObject && object != null)
            reqParams_.putItemByString(OFD_BASECALENDAR, (ABTValue)object);
        else
            processError(SEVERITY_ONE,
                     helper_ + "->create()",
                     EXC_OBJECT_NOT_FOUND,
                     "Type code object not found in object space.");
      }


      IABTLocalID typeCodeID = null;

      val = getHashValue(objArr_, propSet_, OFD_TYPECODE);
      if (ABTValue.isNull(val))
        typeCodeID = (IABTLocalID)null;
      else if (val instanceof IABTLocalID)
        typeCodeID = (IABTLocalID)val;
     // else
     //   throw new ABTException("Wrong Cast");

     if (typeCodeID != null)
     {
        object = null;
        object = driver_.lookupTableGet(typeCodeID);

        if (object instanceof IABTObject && object != null)
            reqParams_.putItemByString(OFD_TYPECODE, (ABTValue)object);
        else
        processError(SEVERITY_ONE,
                     helper_ + "->create()",
                     EXC_OBJECT_NOT_FOUND,
                     "Type code object not found in object space.");
     }




      return (super.create(type, id, reqParams_));
   }


}