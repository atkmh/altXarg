package com.abtcorp.hub;
/*
 * ABTDynamicValue.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-05-98	   HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  optimize with field-index access
  * 2-
  */



/**
 * Basic ABTDynamicValue class - base class for handling
 * dynamic (complex) values
 * An ABTDynamicValue has three parts, the key of the element,
 * the field to be accessed and the array of possible instances
 * <p>
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.core.ABTValue
 */



import java.util.*;
import com.abtcorp.core.*;

public class ABTDynamicValue extends ABTValue
{
   ABTArray instances;
   String   key;
   String   field;
   ABTUserSession  mySession = null;
   /**
   * class constructor for dynamic value
   * @param instances_ - operand
   * @param right - right operand
   * @param oper - operation to be performed
   */
   public ABTDynamicValue(ABTUserSession session,ABTArray instances_, String key_, String field_)
   {
      setInstances(instances_);
      setKey(key_);
      setField(field_);
      mySession = session;
   }

  /**
   * reset the instances reference
   * @param instances_ - operand
   */
   public void setInstances(ABTArray instances_)
   {
      instances = instances_;
   }

  /**
   * reset the key
   * @param key_ new key
   */
   public void setKey(String key_)
   {
      key = key_;
   }

  /**
   * reset the field
   * @param field_ new field
   */
   public void setField(String field_)
   {
      field = field_;
   }

  /**
   * get the instances reference
   * @return ABTArray -  instances_
   */
   public ABTArray getInstances()
   {
      return instances;
   }

  /**
   * get the key
   * @return String - key_
   */
   public String getKey()
   {
      return key;
   }
  /**
   * get the field
   * @return String -  field_
   */
   public String getField()
   {
      return field;
   }

   /**
   *  return the ABTObject currently in the instances
   *  @return ABTObject
   */
   public ABTValue lookup()
   {
        ABTObject o = (ABTObject)instances.at(0);
        if (o != null)
            return o.getValue(mySession,field,null);
        return new ABTErrorCore( "ABTDynamicValue","lookup",
            "103",new ABTString(key));
   }


   /**
   *  evaluate the expression
   *  @return boolean
   */
   public boolean booleanValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.booleanValue();
      return super.booleanValue();
   }

   /**
   *  by default return the error code
   *  @return short
   */
   public short shortValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.shortValue();
      return super.shortValue();
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int intValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.intValue();
      return super.intValue();
   }

   /**
   *  by default return the error code
   *  @return double
   */
   public double doubleValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.doubleValue();
      return super.doubleValue();
   }

   /**
   *  by default return null
   *  @return Date
   */
   public ABTDate dateValue(boolean pm)
   {
      ABTValue val = lookup();
      if (val != null)
        return val.dateValue(pm);
      return super.dateValue(pm);
   }

   /**
   *  by default return the true/false
   *  @return String
   */
   public String stringValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.stringValue();
      return super.stringValue();
   }

   /**
   *  by default return the time this thing was created
   *  @return ABTTime
   */
   public ABTTime timeValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.timeValue();
      return super.timeValue();
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int hashCode()
   {
      ABTValue val = lookup();
      if (val != null)
         return val.hashCode();
      return super.hashCode();
   }

   /**
   *  compare to ABTDynamicValues: first use the errorcode and (if not available)
   *  use the error message
   *  @param object - to compare me to
   *  @return int (0=equal, -1/+1 as usual)
   */
   public int compareTo(Object object)
   {
      if (object == null) return 1;     
      ABTValue val = lookup();
      if (val != null)
          return val.compareTo(object);
      else
          if (object == null)
             return 0;
          else
             return 1;
   }
}

