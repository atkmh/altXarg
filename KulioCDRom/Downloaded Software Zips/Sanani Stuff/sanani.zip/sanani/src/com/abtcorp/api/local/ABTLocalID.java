
package com.abtcorp.api.local;
/*
 * ABTLocalID.java 05/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
*                         Initial Implementation.
* 08-05-98    MXA         Added Serializable
* 08-07-98    TOMO        modified getRemote() and getOriginal() to return values rather than null
*
*/

import com.abtcorp.core.*;
import com.abtcorp.api.*;
import com.abtcorp.idl.*;
import com.abtcorp.hub.ABTID;
import java.io.Serializable;

class ABTLocalID extends ABTSessionObject implements IABTLocalID, Serializable
{

  /**
   * default constructor
   */
    protected ABTLocalID (ABTSessionObject s,ABTID id) {
       super(s,id);
       }

   private ABTID _id;
   private ABTID id() {
      if (_id == null) _id = (ABTID)getObject();
      return _id;
      }


   /**
    * set the remote ID - !immutable only valid ONCE
    * @param id - remote ID
    * @return ABTError if already set or null if successfull
    */
    public ABTError setRemote(ABTRemoteID id) {
       return id().setRemote(getUserSession(),id);
       }

    /**
    * set the original ID- !immutable only valid ONCE
    * @param id - original ID
    * @return ABTError if already set or null if successfull
    */
    public void setOriginal(ABTRemoteID id) {
       id().setOriginal(getUserSession(),id);
       }

    /**
    *  get the local ID
    * @return Object - local id or NULL if unknown
     */
    public int getLocal() {
       return id().getLocal();
       }

    /**
    *  get the remote ID
    * @return Object - remote id or NULL if unknown
     */
    public ABTValue getRemote(){
      return id().getRemote(getUserSession());
      }
     /**
    *  get the Original ID
    * @return Object - original id or NULL if unknown
    */
    public ABTValue getOriginal() {
       return id().getOriginal(getUserSession());
       }

    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    public boolean equals   (IABTLocalID object) {
      return super.equals((Object)object);
   }

  /**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compareTo  (IABTLocalID  object)
   {
      if (object == null) return 1;
      ABTID objID = (ABTID)((ABTLocalID)object).getObject();
      return id().compareTo(objID);
   }

}