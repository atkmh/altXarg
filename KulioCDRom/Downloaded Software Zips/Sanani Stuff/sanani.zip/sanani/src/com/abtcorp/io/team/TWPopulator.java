package com.abtcorp.io.team;

import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTSortedArray;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTID;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTRepository;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

public abstract class TWPopulator implements ABTNames, IABTTWRuleConstants
{
   public static final String USERPROJECT_RIGHTS = "RightsOverProjects".intern();
   public static final String USERRESOURCE_RIGHTS = "RightsOverResources".intern();

   ABTRepositoryDriver driver_;
   String selection_;
   protected ABTCursor cursor_;
   ABTUserSession session_;
   ABTObjectSpace space_;
   protected StatusMonitor monitor_;
   protected int total_ = 0;
   protected int count_ = 0;

	protected static ObjectIDSortedArray timePeriods_;
	protected static ObjectIDSortedArray chargeCodes_;
	protected static ObjectIDSortedArray typeCodes_;
	protected static ObjectIDSortedArray timeSheets_;
	protected static ObjectIDSortedArray resources_;
	protected static ABTSortedArray userRights_;
	
   public TWPopulator() {}

   public TWPopulator(ABTRepositoryDriver driver)
   {
      setDriver(driver,null,null);
   }

   public void setDriver(ABTRepositoryDriver driver, ABTObjectSpace space, ABTUserSession session)
   {
      driver_ = driver;
      session_ = session;
      space_ = space;
   }

   public void setPopulatorCursor(String query, boolean useSystem) throws ABTException
   {
      ABTException exception = null;

      try {

         if (useSystem) cursor_ = getDriver().getRepository().getSession().getSystem().select(query);
         else   cursor_ = getDriver().getRepository().select(query);

         if (cursor_ != null) total_ = cursor_.getRecordCount();
            
      } catch (Exception e) {
         if (e instanceof ABTException) exception = (ABTException)e;
         else e.printStackTrace();
      }

      if (exception != null) throw(exception);
   }

   public void closePopulatorCursor() throws ABTException
   {
      if (cursor_ != null) cursor_.release();

      cursor_ = null;
   }

   public abstract ABTValue populate() throws ABTException;
   
   public void setMonitor(StatusMonitor monitor) {monitor_ = monitor;}
   public StatusMonitor getMonitor()             {return monitor_;}
   
   protected ABTRepositoryDriver getDriver()       {return driver_;}
   protected ABTCursor getPopulatorCursor()        {return cursor_;}

   protected final ABTObjectSet getObjectSet(String type)
   {
      ABTObjectSet set = null;
      try {
         ABTObjectSpace space = getDriver().getSpace();
         set = (ABTObjectSet)space.createObjectSet(session_,type);
      } catch (Exception e) {
         e.printStackTrace();
      }
      return set;
   }

   public static final ABTObject checkObject(ABTValue value)
   {
      ABTObject object = null;

      if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) {
         try {
            object = (ABTObject)value;
         } catch (Exception e) {
            object = null;
         }
      }
      return object;
   }

   protected void addToSetBasedOnRight (ABTCursor rightCursor, String setName, String setType) throws ABTException
   {
      ABTObject user = null;
      if (rightCursor.moveFirst()) {
         do  {
            String objectSelector = null;
            String userSelector = null;

            // First, find the user that matches the USERID field in the rightCursor, if necessary.
            if (user == null || user.getValue(session_,FLD_ID,null).intValue() != rightCursor.getFieldInt(FLD_USERID)) {
               userSelector = FLD_TW_ID + " = " + rightCursor.getFieldInt(FLD_USERID);
               ABTValue value = getDriver().getSpace().findObject(session_,OBJ_TW_USER,userSelector);

               if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) {
                  ABTObjectSet users = (ABTObjectSet)value;
                  if (users.size(session_) > 0) user = (ABTObject)users.at(session_,0);
               }
            }

            if (user != null) {
               // Now find the object that matches the RECORDID field in the cursor.
               ABTObject object = null;

               objectSelector = FLD_TW_ID + " = " + rightCursor.getFieldInt(FLD_RECORDID);
               ABTValue value = getDriver().getSpace().findObject(session_,setType,objectSelector);

               if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) {
                  ABTObjectSet objects = (ABTObjectSet)value;

                  if (objects.size(session_) > 0) {
                     object = (ABTObject)objects.at(session_,0);

                     ABTValue set = user.getValue(session_,setName,null);

                     if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
                        // Maintain uniqueness of the set.
                        if (((ABTObjectSet)set).contains(session_,object)) continue;
                        ((ABTObjectSet)set).add(session_,object);
                     }
                  }
               }
            }
         } while (rightCursor.moveNext());
      }
   }

   // Adds a new property (non-virtual, non-transient, etc.) to an object.
   protected void checkProperties(String object, String field, int type)
   {
      boolean found = false;
      // Add the saved field to the object if it hasn't already been added.
      Enumeration e = getDriver().getSpace().getProperties(object).elements();
      while (e.hasMoreElements()) {
         ABTProperty property = (ABTProperty)e.nextElement();
         if (property.getName().equals(field)) {
            found = true;
            break;
         }
      }
      // Add the new property.
      if (!found) getDriver().getSpace().addProperty(object,field,field,type,false,true,true,false,null,null,null);
   }

   public void addProperties() {} // Do nothing. Various populators can override this to extend the object model.

   public ABTObjectSpace getSpace() {return space_;}
   public ABTUserSession getSession() {return session_;}

   public static String substitute(int[] subs, String base)
   {
      if (subs == null || subs.length == 0) return base;
      return substitute(null,subs,'d',base);
   }

   public static String substitute(String[] subs, String base)
   {
      if (subs == null || subs.length == 0) return base;
      return substitute(subs,null,'s',base);
   }
	
	public static void close()
   {
   	if (resources_ != null) {
   		resources_.clear();
   		resources_ = null;
   	}
   	if (timeSheets_ != null) {
   		timeSheets_.clear();
   		timeSheets_ = null;
   	}
   	if (chargeCodes_ != null) {
   		chargeCodes_.clear();
   		chargeCodes_ = null;
   	}
   	if (typeCodes_ != null) {
   		typeCodes_.clear();
   		typeCodes_ = null;
   	}
   	if (timePeriods_ != null) {
   		timePeriods_.clear();
   		timePeriods_ = null;
   	}
   	if (userRights_ != null) {
   		userRights_.clear();
   		userRights_ = null;
   	}
   }

   private static String substitute(String[] strSubs, int[] intSubs, char search, String base)
   {
      if (search == 'd' && (intSubs == null || intSubs.length == 0)) return base;

      boolean done = false;
      int subIndex = 0;
      int fromIndex = 0;

      while(!done) {
         int idx = base.indexOf('%',fromIndex);

         if (idx == -1) done = true;
         else {
            char c = base.charAt(idx+1);
            if (c == search) {
               String temp = base.substring(0,idx);

               if (search == 's') {
                  temp = temp.concat(strSubs[subIndex]);
               } else {
                  temp = temp.concat("" + intSubs[subIndex]);
               }

               temp = temp.concat(base.substring(idx+2,base.length()));
               base = temp;
               subIndex++;

               if (search == 's') {
                  if (subIndex == strSubs.length) done = true;
               } else {
                  if (subIndex == intSubs.length) done = true;
               }

            } else {
               fromIndex = idx + 2;
            }
         }
      }

      return base;
   }

   protected ABTCursor getTimeEntryRightCursor(boolean inGroup) throws ABTException
   {
      if (inGroup) {
         return getDriver().getSession().getSystem().select("select distinct PRMember.prUserID, PRRight.prRecordID, PRRight.prName from PRRight, PRMember, PRGroup where (PRRight.prName='prTimeEntry' or PRRight.prName='prApproveActuals') and PRRight.prTableName='PRResource' and PRRight.prRepositoryID=" + getDriver().getRepository().getID() +
                                                            " and (PRRight.prGroupID=PRMember.prGroupID and PRMember.prGroupID=prGroup.prID) order by PRMember.prUserID");
      } else {
         return getDriver().getSession().getSystem().select("select * from PRRight where (prName='prTimeEntry' or prName='prApproveActuals') and prTableName='PRResource' and prRepositoryID=" + getDriver().getRepository().getID() +
                                                            " order by prUserID");
      }
   }

   protected ABTCursor getApproveActualRightCursor(boolean inGroup) throws ABTException
   {
      if (inGroup) {
         return getDriver().getSession().getSystem().select("select distinct PRMember.prUserID, PRRight.prRecordID from PRRight, PRMember, PRGroup where ((PRRight.prName='prApproveActuals' and PRRight.prTableName='PRResource' and PRRight.prRepositoryID=" + getDriver().getRepository().getID() + ") or (PRRight.prName = 'prSuperUser'))" +
                                                            " and (PRRight.prGroupID=PRMember.prGroupID and PRMember.prGroupID=PRGroup.prID) order by PRMember.prUserID");
      } else {
         return getDriver().getSession().getSystem().select("select * from PRRight where (prName='prApproveActuals' and prTableName='PRResource' and prRepositoryID=" + getDriver().getRepository().getID() + ") or (PRRight.prName = 'prSuperUser')" +
                                                            " order by prUserID");
      }
   }
   
   protected void updateStatus(ABTObject object)
   {
      if (monitor_ == null) return;
      
      if (object == null || ABTEmpty.isEmpty(object) || ABTError.isError(object)) return;
      
      monitor_.updateStatus(this,object.getObjectType(),total_,count_++);
   }


	protected boolean checkRight(ABTCursor cursor, String right)
   {
      return cursor.checkRight(right);
   }
	
	protected boolean checkRightForUser(ABTCursor cursor, String right, ABTObject user)
   {
   	return false; // Must be implemented by PVISION.
   }
	
	protected Right createRight(ABTCursor cursor, int userid)
   {
      String name = null, table = null;
      int repositoryID = 0, recordid = 0;
      
      ABTValue value = cursor.getField(FLD_NAME);
      if (value != null) name = value.stringValue();
      value = cursor.getField(FLD_TABLENAME);
      if (value != null) table = value.stringValue();
      value = cursor.getField(FLD_RECORDID);
      if (value != null) recordid = value.intValue();
      value = cursor.getField(FLD_REPOSITORYID);
      if (value != null) repositoryID = value.intValue();
      
      return new Right(name,table,userid,recordid,repositoryID);
   }
}