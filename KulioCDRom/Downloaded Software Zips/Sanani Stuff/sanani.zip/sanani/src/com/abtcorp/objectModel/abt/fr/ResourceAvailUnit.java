package  com.abtcorp.objectModel.abt.fr;

/*
 * ResourceAvailUnit.java 08/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 08-13-98       LZX           Initial Design
 *
 */

import   java.util.*;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule will check if the new value to be set to is valid.
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class ResourceAvailUnit extends SiteFieldRule
{

   /**
    * Validate the value that is being set into the parent object container.
    * Return an ABTError if the value is invalid.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      short availunit = RES_DAILY;  // default to daily

      if (!ABTValue.isNull(newValue))
      {
         availunit = newValue.shortValue();

         // if the new value is NOT one of the valid enum values, set it to default.
         if ((availunit != RES_DAILY) &&
             (availunit != RES_WEEKLY) &&
             (availunit != RES_PERCENT))
            availunit = RES_DAILY;

         // if the new value is cost or quantity and the AvailUnit is percent,
         // set Unit to days (default)
         if (availunit == RES_PERCENT)
         {
            ABTValue v = parent.getValue(session, OFD_UNIT);
            if (ABTError.isError(v))
               return (ABTError) v;               
            short unit = v.shortValue();
            if ((unit == RES_COST) || (unit == RES_QUANTITY))
               return new ABTError( "ResourceAvailUnit",
                  "onSet",
                  errorMessages.ERR_INVALID_VALUE,
                  "Resource.AvailUnit can not be PERCENT if UNIT is COST or QUANTITY.");
         }
      }
      return write( session, parent, property, myValue, new ABTShort(availunit), false );
   }
}
