package com.abtcorp.core;

/*
 * ABTRemoteID.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
   * abtract class to be implemented by drivers....
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */
import com.abtcorp.core.ABTValue;


public abstract class ABTRemoteID extends ABTImmutableValue
{
   private static final long serialVersionUID = 2689889452511322320L;
   public void fromByte(byte[] input){};
   public byte[] fromByte(){ return null;};

    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    abstract public boolean  equals  (Object object);

    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return int 0 => equal, -1 => me < object2, 1 => me > object2
    */
    abstract public int  compareTo  (Object object);

	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */
	abstract public int hashCode();


   }