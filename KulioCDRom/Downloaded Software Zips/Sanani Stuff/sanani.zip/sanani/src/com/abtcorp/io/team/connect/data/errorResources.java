package com.abtcorp.io.team.connect.data;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
   public Object[][] getContents() 
   {
      return contents; 
   }

   static final Object[][] contents = {
      {ERR_0.getCode(),"Timestamp validation failed. Unable to update resource."},
   };
}