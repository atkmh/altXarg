package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoNote.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support required params on create
 * 07-24-98    SOB            Mdds to support save() processing
 * 09-16-98    SOB            Mods to support saving prTableName, as well as prRecordID
 * 09-24-98    SOB            Mods to remove saving of Resource object notes; those will be handled by the Site Driver
 * 10-09-98    SOB            Beginnings of progress reporting
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoNote is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTNote object in the object space.
 *  <pre>
 *       ABTIOPMWRepoNote rd = new ABTIOPMWRepoNote(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoNote extends ABTIOPMWHelper
{
   private static final int PROJECT    = 1;
   private static final int TASK       = 2;
   private static final int ASSIGNMENT = 3;
   
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private int type_;
   private long projectID_ = -1;
   private ABTObjectSet noteos_;
   private Hashtable tasks_;
   private Hashtable resources_;
   private Hashtable assignments_;

   public ABTIOPMWRepoNote() {/*implicit call to super() here*/}

   /**
    *    Constructor used by populate process.
    *
    */
   public ABTIOPMWRepoNote(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable tasks,
                       Hashtable resources,
                       Hashtable assignments,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_NOTE, OBJ_NOTE, progress);
      projObj_ = projObj;
      projectID_ = projID;
      tasks_ = tasks;
      resources_ = resources;
      assignments_ = assignments;
   }

   /**
    *    Constructs a helper object to be used to save Note objects back to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepository reference
    *    @param a Project object reference
    *    @forceAddNew true if an addNew() operation is being forced to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoNote(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_NOTE, OBJ_NOTE, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with Note objects for projects, tasks, assignments, and resources.
    *    @param parms (currently not used)
    *    @return null
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      populateNotes(PROJECT);
      populateNotes(TASK);
      populateNotes(ASSIGNMENT);
      //populateNotes(RESOURCE); //handled by Site Repo Driver, Resource populator

      return (ABTValue) null;
   }

   private void populateNotes(int type) throws ABTException
   {
      ABTValue object;

      type_ = type;

      try
      {
         getCursor();

         //
         // For each note tuple in the result set, make sure one exists in the
         // object space.
         //
         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this note object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the note object already exists in the object space.
            //
            object = find(OBJ_NOTE, id_);

            //
            // If the object found is an ABTObject, then the note object was
            // found in the object space.  Update (merge) its properties with those from the
            // repository.
            //
            // Otherwise, create a new note object in the object space and
            // initialize its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }
         }              // end while (cursor_.moveNext())
      }                 // end try block
      finally
      {
         closeCursor();
      }
   }

   /**
    *    Creates a new Note object
    *    @param parms (currently not used)
    *    @return the newly-created Note object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // No required params are necessary for note object creation.
      //
      ABTObject object = createObject(OBJ_NOTE, id_, null);

      setValues(object);
      setReferences(object);

      return object;
   }

   /**
    *    Updates an existing Note object
    *    @param parms the existing Note object
    *    @return the updated Note object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
      setPropertyValues(ps_, cursor_, obj);
   }

   private void setReferences(ABTObject obj) throws ABTException
   {
      ABTObjectSet os;
      Long recordID;
      ABTObject targobj = null;

      recordID = new Long(cursor_.getFieldInt(FLD_RECORDID));
      switch (type_)
      {
         case PROJECT:
            targobj = projObj_;
            break;

         case TASK:
            targobj = (ABTObject) tasks_.get(recordID);
            if (targobj == null) 
               throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                    "RepoNote->setReferences",
                                                    errorMessages.ERR_NO_TASK_FOR_NOTE,
                                                    null) );
            break;

         case ASSIGNMENT:
            targobj = (ABTObject) assignments_.get(recordID);
            //
            // Some assignments which exist in the repository may be skipped (not built) in the object
            // space due to rule violations.  If an assignment object cannot be found, assume
            // it was skipped puposefully and don't report an error.
            //
            if (targobj == null) 
               //throw new ABTException("Cannot find associated assignment for an assignment note.");
               return;
            break;

      }
      os = getObjectSet(targobj, OFD_NOTES);
      addListMember(os, obj);
   }

   private void getCursor()
   {
      closeCursor();
      switch (type_)
      {
         case PROJECT:
            cursor_ = repo_.select(QRY_PROJECTNOTES + projectID_);
            break;
         case TASK:
            cursor_ = repo_.select(QRY_TASKNOTES + projectID_);
            break;
         case ASSIGNMENT:
            cursor_ = repo_.select(QRY_ASSIGNMENTNOTES + projectID_);
            break;
      }
   }

   /**
    *    Saves all Note objects for a project, tasks, and assignments.
    *    @param parms (currently not used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      saveNotes(PROJECT);
      saveNotes(TASK);
      saveNotes(ASSIGNMENT);
   }

   private ABTValue saveNotes(int type) throws ABTException
   {
      type_ = type;
      getCursor();
      cursor_.setSort(TBL_NOTE + "." + FLD_ID);

      ABTObjectSet oSet = null;
      switch (type_)
      {
         case PROJECT:
            oSet = createObjectSet(OBJ_PROJECT);
            addListMember(oSet, projObj_);
            break;

         case TASK:
            oSet = getObjectSet(projObj_, OFD_ALLTASKS);
            break;

         case ASSIGNMENT:
            oSet = getObjectSet(projObj_, OFD_ALLASSIGNMENTS);
            break;

      }

      saveNoteSet(oSet);

      closeCursor();
      return (ABTValue) null;
   }

   private void saveNoteSet(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);

      //
      // For each candidate object in the input object set (these will be either projects, tasks, assignments,
      // or resources), inspect its OFD_NOTES collection object set.  If the candidate object has a
      // non-empty set of notes, then set some properties in each owned note object prior to the object's set
      // of notes being written back to the repository.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject obj = at(oSet, i);
         ABTObjectSet noteSet = getObjectSet(obj, OFD_NOTES);
         if (size(noteSet) > 0)
         {
            setSomeProperties(noteSet, obj);

            //
            // Save this set of notes back to the repository.
            //
            save(noteSet);
         }
      }
   }

   private void setSomeProperties(ABTObjectSet oSet, ABTObject owningObj) throws ABTException
   {
      int size = size(oSet);

      //
      // For each note in the input object set of notes, make sure the prRecordID and prTableName are set 
      // correctly to their respective values.  Neither the application, nor any rules processing, can 
      // properly take care of assigning these values of the owning object if the owning object represents 
      // a new entry in the repository.  The prID of new objects is not known until they are created in the 
      // repository.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject note = at(oSet, i);
         setValue(note, OFD_RECORDID, getValue(owningObj, OFD_ID));
         String s = null;
         switch (type_)
         {
            case PROJECT:
               s = TBL_PROJECT;
               break;
            
            case TASK:
               s = TBL_TASK;
               break;
            
            case ASSIGNMENT:
               s = TBL_ASSIGNMENT;
               break;
            
         }
         setValue( note, OFD_TABLENAME, new ABTString(s) );
      }
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: true if the data being written is new to the repository, i.e., the
    *             operation is an add; false, otherwise
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         //
         // Call the parent version of isException().  If that method returns true, then honor that
         // by immediately returning true to the caller.
         //
         if (super.isSaveException(prapiName, obj, prapiFlags, isNew))
            return true;

         boolean  ret = false;            // assume no exception

         //
         // prCreatedBy, prCreatedTime, and prRecordID can only be set when creating a new note.
         // Setting of these columns is disallowed when updating an existing note.  All columns
         // (except prID) all allowed to be saved when a new note is created.
         //
         if (!isNew)
         {
            if (prapiName.equals(FLD_CREATEDBY) ||
                prapiName.equals(FLD_CREATEDTIME) ||
                prapiName.equals(FLD_RECORDID) )
               ret = true;
         }

         return ret;
   }


}