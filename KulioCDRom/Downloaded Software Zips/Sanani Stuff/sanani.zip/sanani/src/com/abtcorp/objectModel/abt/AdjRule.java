/*
 * AdjRule.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date          Author       Description
  * 06-05-98      LZX          Initial implementation.
  * 10-01-98      SOB          StarTeam Change Request 153
  *
  */

package com.abtcorp.objectModel.abt;

import  com.abtcorp.objectModel.*;
import  com.abtcorp.core.*;
import  com.abtcorp.hub.*;

/**
 * AdjRule is the object rule class that handles the adjustment rule business rules.
 * An AdjRule object is a global object. It can be added to or removed from an object
 * set that contains AdjRule objects.
 *
 * @version	1.0
 * @author      L. Xiao
 */

public class AdjRule extends SiteRule
{

  /**
   * Default Constructor
   */
   public AdjRule()
   {
      super();
   }

   /**
   * sets default properties for the methodology recommendation rule object.
   */
   protected void setDefaultProperties()
   {
      //
      // Relationship properties
      //
      addProperty( OFD_SITE, OFD_SITE_CAP, PROP_OBJECT, false, true, true, false, OBJ_SITE, null, null );

      //
      // Field Properties
      //
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );

      ABTProperty prop;

      addProperty( OFD_NAME, OFD_NAME_CAP, PROP_STRING, false, true, true, false, null, FR_UNIQUEINOBJECTSPACE, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(32));
      makeIndex(prop);

      addProperty( OFD_VALUE, OFD_VALUE_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_MEMO, ABTBoolean.True());
   }

   /**
    * adds a new object to an object set by calling the ABTObjectSet method
    *    <code>addToSet(String type, ABTUserSession,ABTValue,boolean)</code>.
    *
    * @param session    the session object for transaction support
    * @param parent     the <code>ABTObjectSet</code> that the new element is being added to.
    * @param newValue   the new <code>ABTObject</code> being added to the list
    * @param existing   true if <code>newValue</code> has been created by the caller, false if it has been initialized with default values
    *
    * @return ABTValue  ABTValue if successful, ABTError if not
    */
   protected ABTValue onAdd( ABTUserSession session, ABTObjectSet parent, ABTValue newValue, boolean existing )
   {
      return parent.addToSet( session, newValue, existing );
   }

   /**
    * removes an object from an object set by calling the ABTObjectSet method
    * <code>removeFromSet(ABTUserSession,ABTValue,int)</code>.
    *
    * @param session    the session object for transaction support
    * @param parent     the <code>ABTObjectSet</code> that the element is being removed from.
    * @param myValue    the <code>ABTObject</code> being removed
    * @param myIndex    the position within this <code>ABTObjectSet</code> of <code>myValue</code>
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onRemove( ABTUserSession session, ABTObjectSet parent, ABTValue myValue, int myIndex )
   {
      return parent.removeFromSet( session, myValue, myIndex );
   }

  /**
   * removes all elements from the set by calling the ABTObjectSet method
   * <code>clearSet(ABTUserSession)</code>.
   *
   * @param parent      the <code>ABTObjectSet</code> that is being cleared.
   * @param property    the property accessed
   * @param myValue     the value currently available i.e. the ABTObject at this position
   * @return ABTValue   check for ABTError....
   */
  protected ABTValue onClear (ABTUserSession session,ABTObjectSet parent)
  {
      return parent.clearSet(session);
  }

   /**
    * Rules to invoke when an estimating model object is created.
    *
    * @param session             the session object for transaction support
    * @param object              the new object being created
    * @param requiredParameters  hash table containing the required parameters
    *
    * @return ABTValue returns any <code>ABTError</code> that may have been encountered
    *                    while accessing or setting properties.
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTHashtable parameters )
   {
      ABTValue v;

      //
      // Check required parameters.
      //
      v = setReqParm( session, object, parameters, OFD_SITE, OFD_ADJRULES, "abt.AdjRule->onInitialize" );
      if ( ABTError.isError( v ) )
         return v;

      // Set the name property to a default unique value
      return object.setValue( session, OFD_NAME, new ABTString( object.getID().getUniqueId() ), parameters ) ;
   }

  /**
   * Deletes a adjustment rule object.
   * @param parent - the object to be removed
   * @return ABTValue - check for ABTError....
   */
   protected ABTValue onDelete(ABTUserSession session, ABTObject parent)
   {
      // Remove this adj rule object from the site's adj rule list
      ABTValue v = removeFromList( session, parent, OFD_SITE, OFD_ADJRULES, "abt.AdjRule->onDelete" );
      if( ABTError.isError( v ) )
         return v;

      // delete the object itself
      return deleteObject( session, parent );
   }
}
