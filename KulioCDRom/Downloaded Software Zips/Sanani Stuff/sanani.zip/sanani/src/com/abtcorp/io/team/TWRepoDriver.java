package com.abtcorp.io.team;

import java.util.BitSet;
import java.util.Enumeration;
import java.util.Hashtable;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.ABTNotImplementedException;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTValue;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTSortOrderDefinition;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;

public class TWRepoDriver extends ABTRepositoryDriver implements IABTTWRuleConstants, TWRepoDriverConstants, errorMessages
{
   private Hashtable populators_ = new Hashtable(10,(float)1.0);

   private        boolean  dataLoaded        = false;
   private        BitSet   openProjects_     = new BitSet();
   private        BitSet   openChargeCodes_  = new BitSet();
   private        BitSet   openTypeCodes_    = new BitSet();
   private        BitSet   openResources_    = new BitSet();
   private        BitSet   openTimePeriods_  = new BitSet();

   public TWRepoDriver() {} // Default constructor used by client API.

   public TWRepoDriver(ABTObjectSpace space, ABTUserSession session, String repository, String user, String password)
   {
      super(space,session);

      setRepositoryName(repository);
      setUser(user);
      setPassword(password);
   }

   public TWRepoDriver(ABTObjectSpace space, ABTUserSession session)
   {
      super(space,session);
   }

   public ABTValue open(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue value = super.open(space,session,args);
      if (value != null) return value;
      
      setSpace(space);
      
      // Create a site object in the object space. This is needed for guidelines.
      ABTCursor siteCursor = getRepository().select("select * from PRSite");
      try {
         while(siteCursor.moveNext()) {
            ABTValue siteObject = space.createObject(session,OBJ_TW_SITE,null,null);
            if (siteObject instanceof ABTObject) {
               ((ABTObject)siteObject).setValue(session,FLD_TW_ID,siteCursor.getField(FLD_ID));
               ((ABTObject)siteObject).setValue(session,FLD_TW_GUIDELINES,siteCursor.getField(FLD_GUIDELINES));
            } 
         }
      } catch (Exception e) {
         e.printStackTrace();
         value = new ABTError(getClass(),"open",ERR_1,e.getMessage());
      }

      return value;
   }

   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue value = null;

      if (args != null) {             

         ABTValue className = (ABTValue)args.get(POPULATOR);
         if (className == null || ABTEmpty.isEmpty(className) || ABTError.isError(className)) return new ABTError(getClass(),"populate",ERR_14,null);

         TWPopulator populator = createPopulator(className.stringValue(),space,session);

         if (populator == null) return new ABTError(getClass(),"populate",ERR_13,className);

         populator.setMonitor((StatusMonitor)args.get(MONITOR));

         if (populator instanceof CodePopulator) {
            ABTValue type = (ABTValue)args.get(TYPE);
            if (type == null || ABTEmpty.isEmpty(type) || ABTError.isError(type)) return new ABTError(getClass(),"populate",ERR_12,null);
            ((CodePopulator)populator).setType(type.stringValue());
         }

         if (populator instanceof TimeSheetPopulator) {
            ABTValue sumQuery = (ABTValue)args.get(SUM_QUERY);
            if (!ABTEmpty.isEmpty(sumQuery) && !ABTError.isError(sumQuery) && sumQuery != null) {
               ABTValue TSSearchKey = (ABTValue)args.get(TS_SEARCH_KEY);
               if (!ABTEmpty.isEmpty(TSSearchKey) && !ABTError.isError(TSSearchKey) && TSSearchKey != null) {
                  ABTValue sumFieldName = (ABTValue)args.get(SUM_FIELD_NAME);
                  if (!ABTEmpty.isEmpty(sumFieldName) && !ABTError.isError(sumFieldName) && sumFieldName != null) {
                     ((TimeSheetPopulator)populator).setSumQuery(sumQuery.stringValue(), TSSearchKey.stringValue(), sumFieldName.stringValue());
                  }
               }
            }

      		ABTValue noteQuery = (ABTValue)args.get(TIMESHEET_NOTE_QUERY);
            if (noteQuery != null && !ABTEmpty.isEmpty(noteQuery) && !ABTError.isError(noteQuery)) {
            	((TimeSheetPopulator)populator).setNoteCursor(noteQuery.stringValue());
            }
         }

      	if (populator instanceof TimeEntryPopulator) {
            ABTValue timesheet = (ABTValue)args.get(TE_TIMESHEET);
            if (timesheet != null && !ABTEmpty.isEmpty(timesheet) && !ABTError.isError(timesheet)) {
            	((TimeEntryPopulator)populator).setTimesheet((ABTObject)timesheet);
            }
         }

      	if (populator instanceof ProjectPopulator) {
            ABTValue assignQuery = (ABTValue)args.get(PROJ_ASSIGN_QUERY);
            if (assignQuery != null && !ABTEmpty.isEmpty(assignQuery) && !ABTError.isError(assignQuery)) {
            	((ProjectPopulator)populator).setTaskAssignmentQuery(assignQuery.stringValue());
            }

      		ABTValue teamQuery = (ABTValue)args.get(PROJ_TEAM_QUERY);
            if (teamQuery != null && !ABTEmpty.isEmpty(teamQuery) && !ABTError.isError(teamQuery)) {
            	((ProjectPopulator)populator).setTeamCursor(teamQuery.stringValue());
            }

      		ABTValue noteQuery = (ABTValue)args.get(PROJ_NOTE_QUERY);
            if (noteQuery != null && !ABTEmpty.isEmpty(noteQuery) && !ABTError.isError(noteQuery)) {
            	((ProjectPopulator)populator).setNoteCursor(noteQuery.stringValue());
            }
      	}

         ABTValue query = (ABTValue)args.get(QUERY);
         if (query == null || ABTEmpty.isEmpty(query) || ABTError.isError(query)) return new ABTError(getClass(),"populate",ERR_11,null);

         ABTValue useSystem = (ABTValue)args.get(USE_SYSTEM);
         if (useSystem == null || ABTEmpty.isEmpty(useSystem) || ABTError.isError(useSystem)) useSystem = new ABTBoolean(false);

         try {
            populator.setPopulatorCursor(query.stringValue(),((ABTBoolean)useSystem).booleanValue());
         } catch (Exception e) {
            return new ABTError(getClass(),"populate",ERR_10,e);
         }

      	session.startTransaction();

         try {
            value = populator.populate();
         } catch (Exception e) {
            e.printStackTrace();
         }

         session.commitTransaction();

      } else value = new ABTError(getClass(),"populate",ERR_9,null);

      return value;
   }


   /**
   * load the BitSets for checking validity of objects
   */
   public void prepareToSave(boolean forceLoad) {
      if (!dataLoaded || forceLoad) {
         loadOpenProjects();
         loadOpenChargeCodes();
         loadOpenTypeCodes();
         loadOpenResources();
         loadOpenTimePeriods();
         dataLoaded = true;
      }
   }


   /**
   * save a timesheet back to the repository
   */
   public ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {

      // get the timesheet to save
      ABTValue value = null;
      value = (ABTValue)args.get(new ABTString(OBJ_TW_TIMESHEET));
      if (value == null || ABTError.isError(value) || ABTValue.isEmpty(value))
         return new ABTError(getClass(),"save",ERR_7,null);
      ABTObject timesheet = (ABTObject)value;

      // load the data BitSets if necessary
      boolean forceLoad = false;
      value = (ABTValue)args.get(FORCE_LOAD);
      if (value != null && !ABTError.isError(value) && !ABTValue.isEmpty(value)) {
         forceLoad = value.booleanValue();
      }
      prepareToSave(forceLoad);

      // make sure the timesheet can be saved
      value = validateTimesheet(timesheet, session);
      if (isError(value)) return value;

      ABTObject resource   = (ABTObject)timesheet.getValue(session, FLD_TW_RESOURCE);
      ABTObject timePeriod = (ABTObject)timesheet.getValue(session, FLD_TW_TIMEPERIOD);

      // get a time sheet cursor
      String sqlText = "SELECT * FROM PRTimeSheet" +
                       " WHERE prResourceID = " + resource.getValue(session, FLD_TW_ID).intValue() +
                       " AND prTimePeriodID = " + timePeriod.getValue(session, FLD_TW_ID).intValue() +
                       " AND prStatus < 4";
      ABTCursor tsCursor = getRepository().select(sqlText);

      // set the timesheet status to unsubmitted so the entries can be changed.
      int oldStatus = -1;
      if (tsCursor.moveFirst()) {
         oldStatus = tsCursor.getField(FLD_STATUS).intValue();
         tsCursor.edit();
         tsCursor.setField(FLD_STATUS, new ABTInteger(PR_UNSUBMITTED_TSHEET));
         ABTValue id = timesheet.getValue(session,FLD_TW_ID);
         if (id.intValue() == 0) timesheet.setValue(session,FLD_TW_ID,tsCursor.getField(FLD_ID));  
         tsCursor.update();
      } else {
         value = createTimesheetInRepository(resource, timePeriod, timesheet, space, session, tsCursor);
      }

      // update the time entry records for this timesheet
      value = updateTimeEntries(timesheet, resource, space, session);
      if (ABTError.isError(value)) {
         if (oldStatus != -1) {
            tsCursor.edit();
            tsCursor.setField(FLD_STATUS, new ABTInteger(oldStatus));
            tsCursor.update();
         }
         tsCursor.release();
         tsCursor = null;
         return value;
      }

      // update the timesheet record; this also locks the timesheet
      value = updateTimesheet(resource, timePeriod, timesheet, space, session, tsCursor);
      if (ABTError.isError(value)) {
         tsCursor.release();
         tsCursor = null;
         return value;
      }

      // unlock the time sheet
      tsCursor.unlock(LCK_TIMEENTRY);
      tsCursor.release();
      timesheet.setValue(session, FLD_TW_MODIFIED, new ABTBoolean(false));

      // save all notes on the timesheet
      saveNotes(timesheet,session);

      return null;
   }
	
	public ABTValue close(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
   	return super.close(space,session,args);
   }


   public ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue value = null;
      ABTValue retVal = null;

      if (args.get(USER_ID) != null) {
         try {
           int id = getSession().getUserID();
           retVal = new ABTInteger(id);
         } catch (Exception e) {
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else if (args.get(SESSION_ID) != null) {
         try {
           int id = getSession().getID();
           retVal = new ABTInteger(id);
         } catch (Exception e) {
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else if (args.get(SESSION_NAME) != null) {
         try {
            String name = getSession().getUserName();
            retVal = new ABTString(name);
         } catch (Exception e) {
            e.printStackTrace();
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else if (args.get(DELETE_RECORDS) != null) {
         try {
            ABTString query = (ABTString)args.get(QUERY);
            if (query != null && !ABTError.isError(query) && !ABTEmpty.isEmpty(query)) retVal = deleteRecords(query.stringValue());
            else retVal = new ABTError(getClass(),"execute",ERR_5,null);
         } catch (Exception e) {
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else if (args.get(SAVE_NOTES) != null) {
         try {
            value = args.get(SAVE_NOTES);
            if (!ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {
               saveNotes( (ABTObject) value, session); // TODO: Handle errors if save notes fails!
            }
         } catch (Exception e) {
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else if (args.get(SAVE_TASK) != null) {
         try {
            value = args.get(SAVE_TASK);
            if (!ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {
               saveTask( (ABTObject) value, session); // TODO: Handle errors if save tasks fails!
            }
         } catch (Exception e) {
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else if (args.get(DELETE_TIMESHEET) != null) {
         try {
            value = args.get(DELETE_TIMESHEET);
            if (!ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {
               retVal = deleteTimesheetFromRepository( (ABTObject) value, session);
            }
         } catch (Exception e) {
            retVal = new ABTError(getClass(),"execute",ERR_6,e);
         }
      } else retVal = new ABTError(getClass(),"execute",ERR_0,null);

      return retVal;
   }

   // given a charge/type code, return its ID if it is not null
   private ABTValue getCodeID(ABTValue inObject, ABTUserSession session)
   {
      ABTValue id = null;
      if (!isError(inObject) && inObject != null) id = ((ABTObject)inObject).getValue(session, FLD_TW_ID);
      return (ABTValue)id;
   }


   // create a new curve scaled to the units needed in the repository
   protected ABTCurve rescaleCurve(ABTValue curve, double multiplier)
   {

      ABTCurve newCurve = new ABTCurve();
      // Time entry with no actuals fence post case.
      if (ABTEmpty.isEmpty(curve) || curve == null || ABTError.isError(curve)) return null;

      newCurve.setCurve((ABTCurve)curve);

      if (newCurve == null || newCurve.getSum() == 0) return newCurve;

      newCurve.scaleRate(multiplier);

      return newCurve;
   }


   // create assignment in repository if necessary
   //   passed cursor should include all assignments for desired resource ordered by prTaskID
   private void createAssignInRepository(ABTObject project, ABTObject assignment, ABTCursor assignCursor, ABTUserSession session)
   {
      if (!assignCursor.bsearchFirstInt(FLD_TASKID, assignment.getValue(session, FLD_TW_TASKID).intValue())) {

         ABTObject task = (ABTObject)assignment.getValue(session, FLD_TW_TASK);
         if (task.getValue(session, FLD_TW_CREATED).booleanValue() || task.getValue(session, FLD_TW_ID).intValue() == 0) {
            createTaskInRepository(project, task, session);
         }
         assignCursor.addNew();
         assignCursor.setField(FLD_RESOURCEID, assignment.getValue(session, FLD_TW_RESOURCEID));
         assignCursor.setField(FLD_TASKID, task.getValue(session, FLD_TW_ID));
         assignCursor.setField(FLD_ISUNPLANNED, new ABTBoolean(true));
         assignCursor.update();
      }
      assignment.setValue(session, FLD_TW_ID, assignCursor.getField(FLD_ID));
   }


   // create a new task in the repository
   private void createTaskInRepository(ABTObject project, ABTObject task, ABTUserSession session)
   {
      // get a task cursor
      String sqlText = "SELECT * FROM PRTask WHERE prID = -1";
      ABTCursor cursor = getRepository().select(sqlText);
      cursor.addNew();
      cursor.setField(FLD_EXTERNALID, task.getValue(session, FLD_TW_EXTERNALID));
      cursor.setField(FLD_NAME, task.getValue(session, FLD_TW_NAME));
      cursor.setField(FLD_PROJECTID, project.getValue(session, FLD_TW_ID));
      cursor.setField(FLD_ISTASK, task.getValue(session, FLD_TW_ISTASK));
      cursor.setField(FLD_ISMILESTONE, task.getValue(session, FLD_TW_ISMILESTONE));
      cursor.setField(FLD_ISUNPLANNED, task.getValue(session, FLD_TW_ISUNPLANNED));
      cursor.setField(FLD_STATUS, task.getValue(session, FLD_TW_STATUS));
      cursor.setField(FLD_WBSLEVEL, task.getValue(session, FLD_TW_LEVEL));
      cursor.setField(FLD_START, task.getValue(session, FLD_TW_START));
      cursor.setField(FLD_FINISH, task.getValue(session, FLD_TW_FINISH));
      cursor.update();
      task.setValue(session, FLD_TW_ID, cursor.getField(FLD_ID));
      task.setValue(session, FLD_TW_MODIFIED, new ABTBoolean(false));
      task.setValue(session, FLD_TW_CREATED, new ABTBoolean(false));

      // save all notes on the task
      saveNotes(task,session);

      cursor.release();
   }

   // save the notes associated with the passed object into the repository
   private void saveNotes(ABTObject inObject, ABTUserSession session)
   {
      String tableName = "";
      if (inObject == null) return;
      // get table name for passed in object
      if (inObject.getObjectType().equals(OBJ_TW_TIMESHEET)) tableName = "PRTimeSheet";
      else if (inObject.getObjectType().equals(OBJ_TW_PROJECT)) tableName = "PRProject";
      else if (inObject.getObjectType().equals(OBJ_TW_TASK)) tableName = "PRTask";
      else return;

      // get notes for passed in object
      ABTValue value = inObject.getValue(session, FLD_TW_NOTES);
      if (isError(value) || value == null) return;
      ABTObjectSet notes = (ABTObjectSet)value;

      // get the notes for this object out of the database
      String sqlText = "SELECT * FROM PRNote WHERE prTableName = '" + tableName + "'" +
                       " AND prRecordID = " + inObject.getValue(session, FLD_TW_ID).intValue() +
                       " ORDER BY prID";
      ABTCursor cursor = getRepository().select(sqlText);

      // for each note in the object space, look for it in the cursor
      for (int i=0; i<notes.size(session); i++) {
         ABTObject note = (ABTObject)notes.at(session, i);
         if (cursor.bsearchFirst(FLD_ID, ((ABTObject)notes.at(session, i)).getValue(session, FLD_TW_ID))) {
            // note found, update it
            cursor.edit();
            cursor.setField(FLD_CATEGORY, note.getValue(session, FLD_TW_CATEGORY));
            cursor.setField(FLD_VALUE, note.getValue(session, FLD_TW_TEXT));
            cursor.setField(FLD_MODTIME, note.getValue(session, FLD_TW_MODIFIEDTIME));
            cursor.setField(FLD_MODBY, note.getValue(session, FLD_TW_MODIFIEDBY));
            cursor.update();
         } else {
            // note not found, create a new one
            cursor.addNew();
            cursor.setField(FLD_TABLENAME, new ABTString(tableName));
            cursor.setField(FLD_RECORDID, inObject.getValue(session, FLD_TW_ID));
            cursor.setField(FLD_CATEGORY, note.getValue(session, FLD_TW_CATEGORY));
            cursor.setField(FLD_VALUE, note.getValue(session, FLD_TW_TEXT));
            cursor.setField(FLD_CREATEDTIME, note.getValue(session, FLD_TW_CREATEDTIME));
            cursor.setField(FLD_CREATEDBY, note.getValue(session, FLD_TW_CREATEDBY));
            cursor.setField(FLD_MODTIME, note.getValue(session, FLD_TW_MODIFIEDTIME));
            cursor.setField(FLD_MODBY, note.getValue(session, FLD_TW_MODIFIEDBY));
            cursor.update();
            note.setValue(session, FLD_TW_ID, cursor.getField(FLD_ID));
         }
         note.setValue(session, FLD_TW_MODIFIED, new ABTBoolean(false));
         // note has been dealt with in cursor, drop it
         cursor.drop();
      }

      // all notes that remain in cursor must have been deleted, get rid of them from the repository
      cursor.deleteAll();

      if (cursor != null) cursor.release();
      cursor = null;
   }

   // save the given task to the repository
   private void saveTask(ABTObject task, ABTUserSession session)
   {
      if (task == null) return;

      // get a cursor containing the task
      String sqlText = "SELECT * FROM PRTask WHERE prID = " + task.getValue(session, FLD_TW_ID).intValue();
      ABTCursor cursor = getRepository().select(sqlText);

      // look for the task in the cursor
      if (cursor.bsearchFirst(FLD_ID, task.getValue(session, FLD_TW_ID))) {
         // task found, update it
         cursor.edit();
         cursor.setField(FLD_EXTERNALID, task.getValue(session, FLD_TW_EXTERNALID));
         cursor.setField(FLD_NAME, task.getValue(session, FLD_TW_NAME));
         cursor.update();
      } else {
         // task not found, create a new one
         ABTValue value = task.getValue(session, FLD_TW_PROJECT);
         if (!ABTError.isError(value) && !ABTValue.isEmpty(value)) {
            ABTObject project = (ABTObject)value;
            createTaskInRepository(project, task, session);
         }
      }
      task.setValue(session, FLD_TW_MODIFIED, new ABTBoolean(false));
      task.setValue(session, FLD_TW_CREATED, new ABTBoolean(false));

      if (cursor != null) cursor.release();
      cursor = null;

   }


  	public static boolean isError(ABTValue value)
   {
		if (ABTError.isError(value) || ABTValue.isEmpty(value))
			return true;
      return false;
   }

   public TWPopulator createPopulator(String name, ABTObjectSpace space, ABTUserSession session)
   {
      if (name == null) return null;
      TWPopulator populator = (TWPopulator)populators_.get(name);
      if (populator != null) return populator;

      try {
         Class cl = Class.forName("com.abtcorp.io.team." + name);
         populator = (TWPopulator)cl.newInstance();
         populator.setDriver(this,space,session);
         populators_.put(name,populator);
         populator.addProperties(); // To add any properties
      } catch (Exception e) {
         e.printStackTrace();
      }

      return populator;
   }

   private ABTValue deleteRecords(String query)
   {
      ABTCursor cursor = getRepository().select(query);
     
      // TODO: Need to check rights for agent deletion.
      
      if (cursor.moveFirst()) cursor.deleteAll();

      int count = cursor.getRecordCount();

      cursor.release();
      return new ABTInteger(count);
   }

   private ABTValue validateTimesheet(ABTObject timesheet, ABTUserSession session)
   {
      String sqlText = null;

      ABTObject resource   = (ABTObject)timesheet.getValue(session, FLD_TW_RESOURCE);
      ABTObject timePeriod = (ABTObject)timesheet.getValue(session, FLD_TW_TIMEPERIOD);

      // make sure that resource is open
      if (!openResources_.get(resource.getValue(session, FLD_TW_ID).intValue())) {
         return new ABTError(getClass(),"validateTimesheet",ERR_23,null);
      }

      // make sure that time period is open
      if (!openTimePeriods_.get(timePeriod.getValue(session, FLD_TW_ID).intValue())) {
         return new ABTError(getClass(),"validateTimesheet",ERR_22,null);
      }

      // now validate the entries on this timesheet
      return validateTimeEntries(timesheet, session);

   }

   private ABTValue validateTimeEntries(ABTObject timesheet, ABTUserSession session)
   {

		ABTValue value = null;
		ABTObject entry = null;
      ABTObjectSet entries = null;

		value = timesheet.getValue(session, FLD_TW_DIRECTENTRIES);
		if (!isError(value)) {
		   entries = (ABTObjectSet)value;
   		for (int i=0; i<entries.size(session); i++) {
   		   value = entries.at(session, i);
   		   if (!ABTError.isError(value) && !ABTValue.isEmpty(value)) {
               entry = (ABTObject)value;
               value = validateEntry(entry, session, true);
               if (ABTError.isError(value)) return value;
   		   } else return new ABTError(getClass(),"validateTimeEntries",ERR_21,null);
   		}
		}

		value = timesheet.getValue(session, FLD_TW_INDIRECTENTRIES);
		if (!isError(value)) {
		   entries = (ABTObjectSet)value;
   		for (int i=0; i<entries.size(session); i++) {
   		   value = entries.at(session, i);
   		   if (!ABTError.isError(value) && !ABTValue.isEmpty(value)) {
               entry = (ABTObject)value;
               value = validateEntry(entry, session, false);
               if (ABTError.isError(value)) return value;
   		   } else return new ABTError(getClass(),"validateTimeEntries",ERR_21,null);
   		}
		}

		return null;
   }

   private ABTValue validateEntry(ABTObject entry, ABTUserSession session, boolean direct)
   {

      String sqlText = null;
      ABTValue value = null;

      // check the charge code
      value = entry.getValue(session, FLD_TW_CHARGECODE);
      if (!ABTError.isError(value) && !ABTValue.isEmpty(value) && value != null) {
         ABTObject chargeCode = (ABTObject)value;
         if (!openChargeCodes_.get(chargeCode.getValue(session, FLD_TW_ID).intValue())) {
            return new ABTError(getClass(),"validateEntry",ERR_20,null);
         }
      } else if (!direct) return new ABTError(getClass(),"validateEntry",ERR_19,null);

      // check the type code
      value = entry.getValue(session, FLD_TW_TYPECODE);
      if (!ABTError.isError(value) && !ABTValue.isEmpty(value) && value != null) {
         ABTObject typeCode = (ABTObject)value;
         if (!openTypeCodes_.get(typeCode.getValue(session, FLD_TW_ID).intValue())) {
            return new ABTError(getClass(),"validateEntry",ERR_18,null);
         }
      }

      // check the task and project
      if (direct) {
         value = entry.getValue(session, FLD_TW_ASSIGNMENT);
         if (isError(value))
            return new ABTError(getClass(),"validateEntry",ERR_17,null);
         ABTObject assignment = (ABTObject)value;

         value = assignment.getValue(session, FLD_TW_TASK);
         if (isError(value))
            return new ABTError(getClass(),"validateEntry",ERR_16,null);
         ABTObject task = (ABTObject)value;

         value = task.getValue(session, FLD_TW_PROJECT);
         if (isError(value))
            return new ABTError(getClass(),"validateEntry",ERR_15,null);
         ABTObject project = (ABTObject)value;

         if (!openProjects_.get(project.getValue(session, FLD_TW_ID).intValue())) {
            return new ABTError(getClass(),"validateEntry",ERR_4,null);
         }

      }

		return null;
   }

   private ABTValue updateTimesheet(ABTObject resource, ABTObject timePeriod, ABTObject timesheet, ABTObjectSpace space, ABTUserSession session, ABTCursor tsCursor)
   {

      ABTValue value = null;

      // if timesheet was found in the repository update it, else add it
      if (tsCursor.moveFirst()) {
         // lock the time sheet - get out if it is locked by someone else
         if (tsCursor.lock(LCK_TIMEENTRY, false) != getSession().getUserID()) return new ABTError(getClass(),"save",ERR_3,null);

         tsCursor.edit();
         tsCursor.setField(FLD_STATUS, timesheet.getValue(session, FLD_TW_STATUS));
         tsCursor.setField(FLD_SUBMITTEDBY, timesheet.getValue(session,FLD_TW_SUBMITTEDBY));
         tsCursor.setField(FLD_APPROVEDBY, timesheet.getValue(session,FLD_TW_APPROVEDBY));
       

         // save the adjusted timesheet id if it exists
         value = timesheet.getValue(session, FLD_TW_ADJUSTED_TIMESHEETID);
         if (!ABTError.isError(value) && !ABTValue.isEmpty(value) && value != null) {
            String selection = FLD_TW_INTERNALID + " = '" + value + "'";

            value = space.findObject(session,OBJ_TW_TIMESHEET,selection);
            if (!ABTError.isError(value) && !ABTValue.isEmpty(value) && value != null) {
               ABTObjectSet set = (ABTObjectSet) value;
               if (set.size(session) > 0) tsCursor.setField(FLD_ADJUSTEDID, ((ABTObject) set.at(session, 0)).getValue(session, FLD_TW_ID));
            }
         }

         tsCursor.update();
         timesheet.setValue(session, FLD_TW_ID, tsCursor.getField(FLD_ID));
      } else {
         createTimesheetInRepository(resource, timePeriod, timesheet, space, session, tsCursor);
      }

      return null;
   }

   private ABTValue createTimesheetInRepository(ABTObject resource, ABTObject timePeriod, ABTObject timesheet, ABTObjectSpace space, ABTUserSession session, ABTCursor tsCursor)
   {

      ABTValue value = null;

      // add the timesheet to the cursor
      tsCursor.addNew();

      tsCursor.setField(FLD_RESOURCEID,resource.getValue(session,FLD_TW_ID));
      tsCursor.setField(FLD_TIMEPERIODID, timePeriod.getValue(session, FLD_TW_ID));
      tsCursor.setField(FLD_STATUS, new ABTInteger(PR_UNSUBMITTED_TSHEET));

      // save the adjusted timesheet id if it exists
      value = timesheet.getValue(session, FLD_TW_ADJUSTED_TIMESHEETID);
      if (!ABTError.isError(value) && !ABTValue.isEmpty(value) && value != null) {
         String selection = FLD_TW_INTERNALID + " = '" + value + "'";

         value = space.findObject(session,OBJ_TW_TIMESHEET,selection);
         if (!ABTError.isError(value) && !ABTValue.isEmpty(value) && value != null) {
            ABTObjectSet set = (ABTObjectSet) value;
            if (set.size(session) > 0) tsCursor.setField(FLD_ADJUSTEDID, ((ABTObject) set.at(session, 0)).getValue(session, FLD_TW_ID));
         }
      }

      tsCursor.update();
      timesheet.setValue(session, FLD_TW_ID, tsCursor.getField(FLD_ID));
      // lock the time sheet - get out if it is locked by someone else
      if (tsCursor.lock(LCK_TIMEENTRY, false) != getSession().getUserID()) return new ABTError(getClass(),"save",ERR_3,null);

      return null;
   }

   private ABTValue updateTimeEntries(ABTObject timesheet, ABTObject resource, ABTObjectSpace space, ABTUserSession session)
   {

      String sqlText = null;
      double multiplier = 1;

      switch (resource.getValue(session, FLD_TW_UNIT).intValue()) {
         case RESOURCE_DAYS:   multiplier *= resource.getValue(session, FLD_TW_HOURS_PER_DAY).doubleValue();
         case RESOURCE_HOURS:  multiplier *= 3600;
      }

      // get a time entry cursor
      sqlText = "SELECT PRTimeEntry.* FROM PRTimeEntry, PRTimeSheet" +
                " WHERE PRTimeEntry.prTimeSheetID = PRTimeSheet.prID" +
                " AND PRTimeSheet.prID = " + timesheet.getValue(session, FLD_TW_ID).intValue();
      ABTCursor teCursor = getRepository().select(sqlText);

      // get an assignment cursor
      sqlText = "SELECT PRAssignment.* FROM PRAssignment, PRResource" +
                " WHERE PRAssignment.prResourceID = PRResource.prID" +
                " AND PRResource.prID = " + resource.getValue(session, FLD_TW_ID).intValue() +
                " ORDER BY prTaskID";
      ABTCursor assignCursor = getRepository().select(sqlText);

      // get object space timesheet entries for time sheet
      //   ***must get them before timesheet ID is set so that internalID continues to work
      ABTValue directValue = timesheet.getValue(session, FLD_TW_DIRECTENTRIES);
      ABTValue indirectValue = timesheet.getValue(session, FLD_TW_INDIRECTENTRIES);

      // delete all of the time entries in the repository
      teCursor.deleteAll();
      if (teCursor.getRecordCount() > 0) {
         assignCursor.release();
         teCursor.release();
         return new ABTError(getClass(),"updateTimeEntries",ERR_2,null);
      }

      // save direct entries
      if (!isError(directValue)) {
         ABTObjectSet directEntries = (ABTObjectSet)directValue;
         for (int i=0; i<directEntries.size(session); i++) {
            ABTObject timeEntry = (ABTObject)directEntries.at(session, i);
            teCursor.addNew();
            teCursor.setField(FLD_TIMESHEETID, timesheet.getValue(session, FLD_TW_ID));

            // create the assignment if necessary
            ABTValue value = timeEntry.getValue(session, FLD_TW_ASSIGNMENT);
            if (!isError(value)) {
               ABTObject assignment = (ABTObject)value;
               if (assignment.getValue(session, FLD_TW_ID).intValue() <= 0) {
                  ABTObject project = (ABTObject) ((ABTObject) assignment.getValue(session, FLD_TW_TASK)).getValue(session, FLD_TW_PROJECT);
                  createAssignInRepository( project, assignment, assignCursor, session );
               }
               teCursor.setField(FLD_ASSIGNMENTID, assignment.getValue(session, FLD_TW_ID));
            }

            teCursor.setField(FLD_CHARGECODEID, getCodeID(timeEntry.getValue(session, FLD_TW_CHARGECODE),session));
            teCursor.setField(FLD_TYPECODEID, getCodeID(timeEntry.getValue(session, FLD_TW_TYPECODE),session));
            teCursor.setField(FLD_ACTCURVE, rescaleCurve(timeEntry.getValue(session, FLD_TW_ACTUALS), multiplier));
            teCursor.update();
            timeEntry.setValue(session, FLD_TW_ID, teCursor.getField(FLD_ID));
         }
      }

      // save indirect entries
      if (!isError(indirectValue)) {
         ABTObjectSet indirectEntries = (ABTObjectSet)indirectValue;
         for (int i=0; i<indirectEntries.size(session); i++) {
            ABTObject timeEntry = (ABTObject)indirectEntries.at(session, i);
            teCursor.addNew();
            teCursor.setField(FLD_TIMESHEETID, timesheet.getValue(session, FLD_TW_ID));
            teCursor.setField(FLD_CHARGECODEID, getCodeID(timeEntry.getValue(session, FLD_TW_CHARGECODE),session));
            teCursor.setField(FLD_TYPECODEID, getCodeID(timeEntry.getValue(session, FLD_TW_TYPECODE),session));
            teCursor.setField(FLD_ACTCURVE, rescaleCurve(timeEntry.getValue(session, FLD_TW_ACTUALS), multiplier));
            teCursor.update();
            timeEntry.setValue(session, FLD_TW_ID, teCursor.getField(FLD_ID));
         }
      }
      assignCursor.release();
      teCursor.release();
      return null;
   }

   // create a BitSet of all the project that are open and use team workbench;
   //   this will be used later to quickly validate tasks on a timesheet
   private void loadOpenProjects() {

      openProjects_ = new BitSet();

      String sqlText = "SELECT prID FROM PRProject" +
                       " WHERE PRProject.prIsOpen <> 0" +
                       " AND PRProject.prTrackMode = 2";
      ABTCursor projCursor = getRepository().select(sqlText);

      while(projCursor.moveNext()) {
         openProjects_.set(projCursor.getFieldInt(FLD_ID));
      }
      projCursor.release();
   }

   // create a BitSet of all the open charge codes;
   //   this will be used later to quickly validate entries on a timesheet
   private void loadOpenChargeCodes() {

      openChargeCodes_ = new BitSet();

      String sqlText = "SELECT prID FROM PRChargeCode WHERE prIsOpen <> 0 ORDER BY prID";
      ABTCursor ccCursor = getRepository().select(sqlText);

      while(ccCursor.moveNext()) {
         openChargeCodes_.set(ccCursor.getFieldInt(FLD_ID));
      }
      ccCursor.release();
   }

   // create a BitSet of all the open type codes;
   //   this will be used later to quickly validate entries on a timesheet
   private void loadOpenTypeCodes() {

      openTypeCodes_ = new BitSet();

      String sqlText = "SELECT prID FROM PRTypeCode WHERE prIsOpen <> 0 ORDER BY prID";
      ABTCursor tcCursor = getRepository().select(sqlText);

      while(tcCursor.moveNext()) {
         openTypeCodes_.set(tcCursor.getFieldInt(FLD_ID));
      }
      tcCursor.release();
   }

   // create a BitSet of all the open resource;
   //   this will be used later to quickly validate a timesheet
   private void loadOpenResources() {

      openResources_ = new BitSet();

      String sqlText = "SELECT prID FROM PRResource" +
                       " WHERE prIsOpen <> 0" +
                       " AND prIsRole = 0" +
                       " AND prTrackMode = 2" +
                       " ORDER BY prID";
      ABTCursor resCursor = getRepository().select(sqlText);

      while(resCursor.moveNext()) {
         openResources_.set(resCursor.getFieldInt(FLD_ID));
      }
      resCursor.release();
   }

   // create a BitSet of all the open time periods;
   //   this will be used later to quickly validate a timesheet
   private void loadOpenTimePeriods() {

      openTimePeriods_ = new BitSet();

      String sqlText = "SELECT prID FROM PRTimePeriod" +
                       " WHERE prIsOpen <> 0" +
                       " ORDER BY prID";
      ABTCursor periodCursor = getRepository().select(sqlText);

      while(periodCursor.moveNext()) {
         openTimePeriods_.set(periodCursor.getFieldInt(FLD_ID));
      }
      periodCursor.release();
   }

   private ABTValue deleteTimesheetFromRepository(ABTObject timesheet, ABTUserSession session) {

      // check if timesheet is in repository
      int timesheetID = timesheet.getValue(session, FLD_TW_ID).intValue();
      if (timesheetID > 0) {

         // get a cursor containing this timesheet
         String sqlText = "SELECT * FROM PRTimeSheet WHERE prID = " + timesheetID;
         ABTCursor timesheetCursor = getRepository().select(sqlText);

         // if it is, get the record and make sure its status is unsubmitted
         if (timesheetCursor.moveFirst()) {
            if (timesheetCursor.getFieldInt(FLD_STATUS) < PR_POSTED_TSHEET) {
               timesheetCursor.setFieldInt(FLD_STATUS, PR_UNSUBMITTED_TSHEET);
               timesheetCursor.update();
            } else {
               timesheetCursor.release();
               return new ABTError(getClass(),"deleteTimesheetFromRepository",ERR_1,null);
            }
         }

         // delete the record from the repository
         boolean retVal = timesheetCursor.delete();

         timesheetCursor.release();
         if (! retVal) new ABTError(getClass(),"deleteTimesheetFromRepository",ERR_1,null);

      }

      return null;
   }

}