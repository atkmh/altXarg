
package com.abtcorp.hub;

/*
 * ABTObjectSpace.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

//import com.objectspace.jgl.*;
import java.util.Date;
import java.util.Hashtable;
import java.util.Enumeration;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import java.io.Serializable;
/**
 *  ABTObjectSpace - the mother of all ....
 *  owned/instantiated by an application offers the management of different views (ABTDictionary)
 *  and objects (ABTObject) and their associated data and description.
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTObjectSpace implements Serializable {

	/**
	 *	content : handle to object-space dictionary, the list of all available/known
	 *	business objects and business object collections
    * for now implemented in an array
  * TO DO:
  *
  * 1-  change implementation to more sophisticated structure
	 */
//	private ABTHashtable content;

   /**
    * Used later to carry user/application information for callback....
    */
   private ABTArray owners;

   /**
    * remember the created classes I have
    */
   protected Hashtable classList;
   
   /**
   *    handle to rowsets (by type)
   */
   private ABTHashtable rowsets;
   
   /**
   *    handle to lookuptable for remoteID
   */
   private ABTHashtable remoteIDs;
   /**
   *    handle to lookuptable for localID
   */
   private ABTHashtable localIDs;

   /**
   *    Current default classPath for rules
   */
   private String my_ClassPath;


   /**
   *    Current default for objectPaht
   */
   private String objectPath;

   /**
   *    Current default for objectExtension
   */
   private String objectExtension;

   /**
   * listener facility
   */
   private ABTAdapter adapter;

   static int objectCounter = 0;

   ABTThreadHandler destroyThread = null;

   ABTUserSession defaultSession;

   boolean defaultSet;

//==============================================================
// listeners
//==============================================================

/**
*
*/

   /**
   * add a listener
   * @param Listener - caller
   * @param target - listen to
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
    public void  addListener(ABTUserSession session, int action,  IABTListener Listener, ABTObject target, int parameterindex_)
    {
      adapter.addListener(session, Listener, action,target,  parameterindex_)   ;
    }
   /**
   * remove a particular listener 
   * @param Listener - caller
   * @param target - listen to or null for all
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   public void removeListener(ABTUserSession session, IABTListener Listener, ABTObject target, int parameterindex_)
   {
      adapter.removeListener(session,Listener, target,  parameterindex_)   ;
   }

   /**
   * remove a particular target from the listener list
   * @param target - object to be removed
   */
   public void removeListenedTo(ABTObject target)
   {
        adapter.removeListenedTo(target);
   }

//==============================================================
// constructors
//==============================================================

/**
*	Default constructor
*/
public ABTObjectSpace()
{
    owners = new ABTArray();
//    content = new ABTHashtable(false);
    classList = new Hashtable();
    rowsets = new ABTHashtable();
    adapter = new ABTAdapter(this);
    my_ClassPath = new String("com.abtcorp.objectModel");

    destroyThread = new ABTThreadHandler (this, new ABTFunctionDestroy());
    defaultSession = new ABTUserSession(null);
    defaultSet = false;

}
/**
* Instanciate the objectSpace. The default reader/writers are installed/set and (if applicable)
* the previous state is rebuilt
* Note: We need some kind of user/application identification at this point
* TO DO:
*
* 1-  change implementation to be able to read content
*/



//==============================================================
// getters/setters
//==============================================================

public ABTUserSession startSession(ABTHashtable arguments)
{
    ABTUserSession session = new ABTUserSession(arguments);
    owners.add(session);
    if (!(defaultSet))
    {
      defaultSession = session;
      defaultSet = true;
    }
    return session;
}

public void endSession(ABTUserSession session)
{

    owners.remove(session);
}
 /**
 * Get the propertySet for a given Object
 * @param object - ABTObject to inspect
 * @return ABTPropertySet - properties for this object or null for error
 */
 public ABTPropertySet getProperties(ABTObject object)
 {
    if (object != null)
         return object.getProperties();
    else    return null;         
 }

 /**
 * Get the propertySet for a given ObjectSet
 * @param object - ABTObjectSet to inspect
 * @return ABTPropertySet - properties for this object or null for error
 */
 public ABTPropertySet getProperties(ABTObjectSet object)
 {
    if (object != null)
     return object.getProperties();
    else    return null;         
 }

 /**
 * Get the propertySet for a given ObjectType
 * @param type  - name of type
 * @return ABTPropertySet - properties for this object or null for error
 */
 public ABTPropertySet getProperties(String type)
 {
    ABTRule rule;  
    Object obj =  loadRule(type);
    
    if ((obj == null) || (obj instanceof ABTError))
        return null;;
    if (obj instanceof ABTRule)
       rule = (ABTRule)obj;
    else
       return  null;
       /*new ABTErrorHub( "ABTObjectSpace->getProperties",
                             "unexpected object type",obj);
       */
     if (rule != null)
         return rule.getProperties();
     return null;            
 }


 /**
 * Get the current classpath for rule objects (e.g. ABTTask)
  * @return String - current path to rule objects
  */
 public String getRulebase()
 {
     return my_ClassPath;
 }

 /**
 * set the current classpath for rule objects (e.g. ABTTask)
 * @param classPath_ - path (e.g. "com.abtcorp.rules") to rule base
 */
 protected void setRulebase(String classPath_)
 {
     my_ClassPath = classPath_;
 }



/**
* set the extension for all abtobjects created (e.g. 
*  ABTObjectCOM, ABTObjectSetCOM
*  @param newExtension new extension
*/
protected void setExtension(String newExtension)
{
   objectExtension = newExtension;
}

/**
* set the class Path for all abtobjects created 
*  @param newPath  new path
*/
protected void setObjectPath(String newPath)
{
   objectPath = newPath;
}

/**
* get the extension for all abtobjects created (e.g. 
*  ABTObjectCOM, ABTObjectSetCOM
*  @return String ObjectExtension 
*/
public String getExtension()
{
   return objectExtension;
}

/**
* get the class Path for all abtobjects created 
*  @return String - path to ABTObjects
*/
public String getObjectPath()
{
   return objectPath;
}

   
//==========================================================================================

/**
* Get a handle to the content
* returns the HashTable with the type name as key and the ObjectSet containing ALL instances  as value
* @return ABTHashtable  - success / null
*/
//public ABTHashtable getContent() 
//{
//    return content;
//}

/**
* Returns a collection of all elements in the dictionary of a given type
*
* @return ABTObjectSet - success / null
*/
//public ABTObjectSet getContent(String type) 
//{
//    Object temp = content.get(type);
//    if (temp == null)
//        return null;
//    else
//        return (ABTObjectSet)temp;
//}


//==============================================================
// Services
//==============================================================


 /**
 *  loads a rule if necessary and attempts to add the property 
 *  to it
 *  @param rule name of rule to load (e.g. 'ABTTask')
 *  @param name_ - name of property
 *  @param caption_ - caption of property
 *  @param type_  valid type of property
 *  @param virtual_ true if property does not occupy physical storage
 *  @param visible_ true if this property can be retrieved
 *  @param updatable_ true if this property is updatable
 *  @param transient_ true if this property is transient
 *  @param referenceType_ name of Rule if this property is an objectSet/Object
 *  @param propertyRule_ name of property-rule file or null if no specific rules
 *  @return ABTError - or null if none
 * ToDo:  
 */
   public ABTError addProperty(  String rule_,
                                 String name_,
                                 String caption_,
                                 int type_,
                                 boolean virtual_,
                                 boolean visible_,
                                 boolean updatable_,
                                 boolean transient_,
                                 String referenceType,
                                 String propertyRule,
                                 ABTValue defaultValue
                                 )
   {
      ABTRule rule;  
      if ((rule_ == null)  || (rule_.length() < 1))
       return  new ABTErrorHub( "ABTObjectSpace->addProperty",
                             errorMessages.ERR_18,"rule name must be set");
      if ((name_ == null)  || (name_.length() < 1))
       return  new ABTErrorHub( "ABTObjectSpace->addProperty",
                             errorMessages.ERR_18,"name must be set");
      Object obj =  loadRule(rule_);
      if (obj == null)
             return  new ABTErrorHub( "ABTObjectSpace->addProperty",
                             errorMessages.ERR_19,"load rule returned null");
      if (obj instanceof ABTError)
      
        return (ABTError)obj;
      if (obj instanceof ABTRule)
       rule = (ABTRule)obj;
      else
       return  new ABTErrorHub( "ABTObjectSpace->addProperty",
                             errorMessages.ERR_20,obj);
      return rule.addProperty(  
                                 name_,
                                 caption_,
                                 type_,
                                 virtual_,
                                 visible_,
                                 updatable_,
                                 transient_,
                                 referenceType,
                                 propertyRule,
                                 defaultValue
                                 );
   }

 /**
 *  Create an ABTObject based on a given type with the new name with the subset of properties
 *  @param type - base type name
 *  @param id - remote id of target object or null
 *  @param requiredParameters - ABTHashtable containing properties to extend the existing rule properties or null if none
 *  @return ABTValue - newly instantiated ABTObject or ABTError for error
 * ToDo:  
 *   1 - through appropriate exception for classnotfound or invalid classname
 *   2-  optimize the class loading (i.e. allow UDCs through byte-loading...)
 */
 public ABTValue createObject(ABTUserSession session,
                              String type,
                              ABTRemoteID id,
                              ABTHashtable requiredParameters)
 {
    ABTRule rule;  
      if (type == null) 
       return  new ABTErrorHub( "ABTObjectSpace->createObject",
                             errorMessages.ERR_18,"type name must be set");
    Object obj =  loadRule(type);
      if (obj == null)
             return  new ABTErrorHub( "ABTObjectSpace->createObject",
                             errorMessages.ERR_19,"load rule returned null");
    if (obj instanceof ABTError)
        return (ABTError)obj;
    if (obj instanceof ABTRule)
       rule = (ABTRule)obj;
    else
       return  new ABTErrorHub( "ABTObjectSpace->createObject",
                             errorMessages.ERR_20,obj);

    if (id != null)
    {
        ABTValue searchresult = rule.findExistingObject(session,IABTPropertyType.PROP_REMOTEIDINDEX,id); // create an instance of the object
        if (searchresult instanceof ABTObject)
        {
            ((ABTObject)searchresult).undelete(session);
            return searchresult;
        }
    }
    // create a new ID    
    // instantiate will look through the rowset (based on the remote ID) and will either create a new row or
    // set the internal pointer to an existing row
    ABTID aid_ = createNewABTID();

    ABTValue result = rule.getInstance(session,aid_,requiredParameters); // create an instance of the object
    if (result instanceof ABTObject)
    {
        aid_.setParent((ABTObject)result);       
        if (id != null)
            aid_.setRemote(session,id);
    }            
    return result;
 }


public Hashtable getRules()
{
     return classList;
}


/**
*  Create an ABTObjectSet based on a given type with the new name with the subset of properties
* @param type - base type name
*   @return ABTObjectSet - newly instantiated object or null for error
* ToDo:
*   1 - through appropriate exception for classnotfound or invalid classname
*   2-  optimize the class loading (i.e. allow UDCs through byte-loading...)
*/
public ABTValue createObjectSet( ABTUserSession session, String type)
{
    ABTRule rule;
      if (type == null) 
       return  new ABTErrorHub( "ABTObjectSpace->createObjectSet",
                             errorMessages.ERR_18,"type name must be set");
    Object obj =  loadRule(type);
      if (obj == null)
             return  new ABTErrorHub( "ABTObjectSpace->createObjectSet",
                             errorMessages.ERR_19,"load rule returned null");
    if (obj instanceof ABTError)
        return (ABTError)obj;
    if (obj instanceof ABTRule)
       rule = (ABTRule)obj;
    else
       return  new ABTErrorHub( "ABTObjectSpace->createObjectSet",
                             errorMessages.ERR_20,obj);
    ABTValue result = rule.getSet(session); // create an instance of the object
    return result;
}


 /**
 *  Return all ABTObjects of a given type
 *  @param subType - type of object
 *  @return ABTValue - ABTObjectSet or ABTError for error
 * ToDo:
 *   1 - implement
 */
 public ABTValue getObjects(  ABTUserSession session,String type)
 {
    ABTRule rule;  
      if (type == null) 
       return  new ABTErrorHub( "ABTObjectSpace->getObjects",
                             errorMessages.ERR_18,"type name must be set");
    Object obj =  loadRule(type);
      if (obj == null)
             return  new ABTErrorHub( "ABTObjectSpace->getObjects",
                             errorMessages.ERR_19,"load rule returned null");
    if (obj instanceof ABTError)
        return (ABTError)obj;
    if (obj instanceof ABTRule)
       rule = (ABTRule)obj;
    else
       return  new ABTErrorHub( "ABTObjectSpace->getObjects",
                             errorMessages.ERR_20,obj);
    ABTValue result = rule.returnCurrentSet(session); // create an instance of the object
    return result;
 }


 /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - local id of target object
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:  
 *   1 - implement
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              ABTID localID)
 {
   return findObject(session,subType, localID.getLocal());
 }

 /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - local id of target object
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:
 *   1 - implement
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              int localID)
 {
    ABTRule rule;
    Object o = findRule(subType);
    if (o instanceof ABTRule)
      rule = (ABTRule)o;
    else
      return (ABTValue)o;
    ABTValue result = rule.findObject(session,localID); // create an instance of the object
    return result;
 }



 /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param criteria - search expression
 *  @return ABTValue - ABTObjectSet containing all ABTObject matching the search criteria or ABTError for error
 * ToDo:
 *   1 - implement
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              String criteria)
 {
    ABTRule rule;
    Object o = findRule(subType);
    if (o instanceof ABTRule)
      rule = (ABTRule)o;
    else
      return (ABTValue)o;
    ABTValue result = rule.findObject(session,criteria); // create an instance of the object
    return result;
 }


 /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - remote id
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              ABTRemoteID id)
 {
    return findObject(session,subType,IABTPropertyType.PROP_REMOTEIDINDEX,id);
 }

 /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - remote id
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              String index,
                              ABTValue id)
 {
    ABTRule rule;
    Object o = findRule(subType);
    if (o instanceof ABTRule)
      rule = (ABTRule)o;
    else
      return (ABTValue)o;
    ABTProperty prop = null;
    try
    {
      prop = rule.getProperty(session,index);
    }
    catch (Exception e)
    {
       return  new ABTErrorHub( "ABTObjectSpace->findObject",
                        errorMessages.ERR_34,"Couldn't access property");
    }


    return findObjectinRule(session,rule,prop,id);
 }




  /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - remote id
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              int index,
                              ABTValue id)
 {
    ABTRule rule;
    Object o = findRule(subType);
    if (o instanceof ABTRule)
      rule = (ABTRule)o;
    else
      return (ABTValue)o;
    ABTProperty prop = null;
    try
    {
      prop = rule.getProperty(session,index);
    }
    catch (Exception e)
    {
       return  new ABTErrorHub( "ABTObjectSpace->findObject",
                        errorMessages.ERR_34,"Couldn't access property");
    }


    return findObjectinRule(session,rule,prop,id);
 }


  /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - remote id
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:
 */
 public ABTValue findObject(  ABTUserSession session,
                              String subType,
                              ABTString index,
                              ABTValue id)
 {
    return findObject(session,subType,index.stringValue(),id);
 }



//==============================================================
// internal/private functions
//==============================================================

 private Object findRule(String subType)
 {
    ABTRule rule;
    if (subType == null)
        return  new ABTErrorHub( "ABTObjectSpace->findObject",
                         errorMessages.ERR_18,"subType must be set");
    Object obj =  loadRule(subType);
      if (obj == null)
             return  new ABTErrorHub( "ABTObjectSpace->findObject",
                             errorMessages.ERR_19,"load rule returned null");
    if (obj instanceof ABTError)
        return (ABTError)obj;
    if (obj instanceof ABTRule)
       return (ABTRule)obj;
    else
       return  new ABTErrorHub( "ABTObjectSpace->findObject",
                        errorMessages.ERR_34,"load rule returned null");
 }
 /**
 *  Return an existing ABTObject based on a given type with the new name with the subset of properties
 *  @param subType - type of object
 *  @param id - remote id
 *  @return ABTValue - existing ABTObject or ABTError for error
 * ToDo:
 */
 private ABTValue findObjectinRule(  ABTUserSession session,
                              ABTRule rule,
                              ABTProperty property,
                              ABTValue id)
 {
   return rule.findObject(session,property,id); // create an instance of the object
 }


/** 
* generate a new ABTID with an unique internal/local id
* @return ABTID new abtid
*/
protected ABTID createNewABTID()
{
   return new ABTID(++objectCounter);
}

static protected Object loadObject(   String classPath_,
                                   String name_)
         throws ABTException
{
   Class newClass;
   Object myObject;
   String classname;


   // create classname
   if (classPath_ != null)
       classname = classPath_ + "." + name_;
   else
       classname = "com.abtcorp.hub." + name_;
   // attempt to load rule class
   try
   {
      newClass = Class.forName (classname);
   }
   catch (Exception e)
   {
         throw new ABTException(
            new ABTErrorHub( "ABTObjectSpace->loadObject",
                          errorMessages.ERR_21,e));
   }
   if (newClass == null) //whoops...
         throw new ABTException(
            new ABTErrorHub( "ABTObjectSpace->loadObject",
                          errorMessages.ERR_21,new ABTString(classname + " not found")));
   // create a new entry in the dictionary
   try
   {
      myObject = newClass.newInstance();
   }
   catch (Exception e)
   {
      throw new ABTException(
            new ABTErrorHub( "ABTObjectSpace->loadObject",
                          errorMessages.ERR_21,e));
   }
   if (myObject == null)
         throw new ABTException(
            new ABTErrorHub( "ABTObjectSpace->loadObject",
                          errorMessages.ERR_21,new ABTString(classname + " not instantiated")));

   return myObject;
}




/**
*  return a rule object for a given type
*  to the rules
*  @param classPath - path to rules
*  @param type - name of base type
*  @param additionalProperties - properties to extend the existing rule properties or null if none
*  @return ABTRule new ABTRule or ABTError  if error
*/
protected Object loadRule( String type)
{
  Object result;
  if (type == null) return null;
  result = classList.get(type);
  if (result == null)
  {
      // attempt to load rule class
      try
      {
         result =  loadObject(getRulebase(),type);
      }
      catch (Exception e)
      {
            return new ABTErrorHub( "ABTObjectSpace->new",
                             errorMessages.ERR_21,e);
      }

      if (result == null)
            return new ABTErrorHub( "ABTObjectSpace->new",
                             errorMessages.ERR_21,new ABTString(getRulebase()+ "." + type + " not instantiated"));
      classList.put(type,result);
      if (result instanceof ABTRule)
      {
         ABTError err = ((ABTRule)result).instantiate(this,type,getObjectPath(),getExtension());
         if (err != null)
         {
            classList.remove(type);
            return err;
         }            
         ((ABTRule)result).setDefaultProperties();
         ((ABTRule)result).setDefaultIndex();
         ((ABTRule)result).createDefaultObject(defaultSession);

      }
  }
  return result;
}


public ABTHashtable unloadedList()
{
   ABTHashtable result = new ABTHashtable();
   Object o;
   Enumeration e = classList.elements();
   while (e.hasMoreElements())
   {
      o = e.nextElement();
      if (o instanceof ABTRule)
      {
         ABTRule r = (ABTRule)o;
         if (r.anyUnloadedProperties().booleanValue())
            result.put(new ABTString(r.getName()),r.getUnloadedProperties());
      }
   }
   return result;
}

protected final void addDestroyThread(ABTFunctionParameter par)
{
       destroyThread.put_message(par);
}
}