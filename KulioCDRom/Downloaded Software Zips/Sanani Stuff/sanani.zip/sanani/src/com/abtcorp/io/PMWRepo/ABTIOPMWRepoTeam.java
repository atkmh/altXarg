package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoTeam.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-09-98    SOB            transaction support
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support save() processing
 * 07-21-98    SOB            Mods to support required params for object creation
 * 10-06-98    SOB            Mods to support better handling of Resource objects during save operations
 * 10-09-98    SOB            Beginnings of progress reporting
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoTeam is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTTeam object in the object space.
 *  <pre>
 *       ABTIOPMWRepoTeam rd = new ABTIOPMWRepoTeam(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator ABTProjectSaver
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

import com.abtcorp.io.siterepo.Resource;

public class ABTIOPMWRepoTeam extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private Resource resHelper_ = null;
   private Hashtable hr_ = null;
   private ABTCursor resCursor_ = null;

   public ABTIOPMWRepoTeam() {/* implicit call to super() here */}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoTeam(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_TEAM, OBJ_TEAM, progress);
      projObj_ = projObj;
      projectID_ = projID;
      ABTObject siteObj = (ABTObject) driver.getSite();  // it MUST be there
      resHelper_ = new Resource(driver, siteObj);
      getResCursorForPopulate();
   }

   /**
    *    Constructs a helper object to save team objects to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepository reference
    *    @param a Project object reference
    *    @forceAddNew true if an addNew() operation is being forced to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoTeam(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_TEAM, OBJ_TEAM, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with team objects for a given project
    *    @param parms (not currently used)
    *    @return null
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;


      try
      {
         getCursor();

      	while (cursor_.moveNext())		// for every team entry in the result set...
      	{
            //
            // Create a remote ID for this team object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the team object already exists in the object space.
            //
            object = find(OBJ_TEAM, id_);

            //
            // If the object found is an ABTObject, then the team object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new team object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray prms = new ABTArray();
               prms.add(object);      // identify the team object for update()
               object = update(prms);
            }
            else
            {
               object = create(null);
            }
      	}           // end while (cursor_.moveNext())
      }              // end try
      finally
      {
         closeCursor();
         resCursor_.release();
      }

      return null;
   }

   /**
    *    Creates a new team object.
    *    @param parms (currently not used)
    *    @return the newly-created team object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
   	//
      // Get the resource ID from the team tuple, position on the associated resource tuple, and
      // ask the Site Repo Driver's Resource populator to populate the Resource object.
   	//
      ABTValue resID = cursor_.getField(FLD_RESOURCEID);
      if ( !resCursor_.bsearchFirst(FLD_ID, resID) )
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "RepoTeam->create",
                                              errorMessages.ERR_TEAM_NO_RESOURCE,
                                              null) );
      //
      // Populate a single resource object only.  If the Site Driver's Resource populator
      // does not return an ABTError, it will return an ABTObject of type OBJ_RESOURCE.
      //
      ABTValue val = resHelper_.populate(resCursor_, false);
      if (ABTError.isError(val)) throw new ABTException( (ABTError)val );

      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_PROJECT, projObj_);
      reqparms.putItemByString(OFD_RESOURCE, (ABTObject) val);

      //
      // Ask the object space to create a new team object.
      //
      ABTValue object = createObject(OBJ_TEAM, id_, reqparms);

      //
      // Initialize repository properties of the new team object.
      //
      setValues((ABTObject) object);

      return object;
   }

   /**
    *    Updates an existing team object.
    *    @param parms the existing task object to be updated
    *    @return the updated task object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
   	//
   	// Set the team object's property values from the team cursor.
   	//
   	setPropertyValues(ps_, cursor_, obj);
   }

   private void getCursor()
   {
      closeCursor();

   	//
   	// Select all the team members for the desired project.  The following SELECT
   	// invocation is modeled from the FIX export/import C++ PVISION code.
   	// (see PVTeamTable object constructor in IMPRES.CPP.)
   	//

   	cursor_ = repo_.select(TBL_TEAM);
   	cursor_.andFilter(FLD_PROJECTID + " = " + projectID_);

   	//
   	// Now set the sort sequence (SQL ORDER BY clause).  (see the export() method
   	// in the PVTeamTable class, in the EXPRES.CPP file of the PVISION code.)
   	//

   	cursor_.addSort(FLD_ID);
   }

   private void getResCursorForPopulate()
   {
      resCursor_ = repo_.select(QRY_PROJECTRESOURCES);
      resCursor_.andFilter(TBL_RESOURCE + "." + FLD_ID + " = " + TBL_TEAM + "." + FLD_RESOURCEID );
      resCursor_.andFilter(TBL_TEAM + "." + FLD_PROJECTID + " = " + projectID_ );
      resCursor_.addSort(TBL_RESOURCE + "." + FLD_ID);
   }

   /**
    *    Saves team objects to an ABTRepository.
    *    @param parms: (currently not used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      getSaveCursor();

      //
      // Loop through all of the team objects and make sure that the resource ID and the
      // project ID is set correctly.
      //
      ABTObjectSet teamOs = getObjectSet(projObj_, OFD_TEAMRESOURCES);
      setReferenceIDs(teamOs);

      //
      // Save team objects back to the repository.
      //
      save(teamOs);

      closeCursor();
   }

   private void getSaveCursor()
   {
      closeCursor();

   	//
   	// Select all the team members for the desired project.  The following SELECT
   	// invocation is modeled from the FIX export/import C++ PVISION code.
   	// (see PVTeamTable object constructor in IMPRES.CPP.)
   	//

   	cursor_ = repo_.select(TBL_TEAM);
   	cursor_.andFilter(FLD_PROJECTID + " = " + projectID_);

   	//
   	// Now set the sort sequence (SQL ORDER BY clause).
   	//
   	cursor_.addSort(FLD_ID);
   }

   private void setReferenceIDs(ABTObjectSet teamOs)  throws ABTException
   {
      ABTCursor resCur = getResourceCursor();

      int size = size(teamOs);
      ABTValue projID = getValue(projObj_, OFD_ID);

      try
      {
         //
         // For each team object in this project, make sure the project ID and
         // the resource ID are set correctly.
         //
         // The resource ID (prID) is obtained from the corresponding resource tuple in the
         // target repository, and not from the resource object in the object space.  The ID
         // held by the resource object in the space may be incorrect for any of the
         // following reasons:
         //
         // 1.  It's a new resource object and not yet been populated by a Site driver, but
         //     it has an external ID that matches a resource tuple in the target repository.
         //
         // 2.  It's a resource that has been populated by a Site driver or by the PMW Repo
         //     driver, but it came from a different repository than the target repository for
         //     the current save operation.  The resource's external ID matches a resource tuple
         //     in the target repository.
         //
         for (int i = 0; i < size; i++)
         {
            ABTObject team = at(teamOs, i);
            setValue(team, OFD_PROJECTID, projID);
            ABTObject resource = getObject(team, OFD_RESOURCE);
            setValue(team, OFD_RESOURCEID, getResourceID(resource, resCur));
         }
      }
      finally
      {
         resCur.release();
      }
   }

   private ABTValue getResourceID(ABTObject resource, ABTCursor cur) throws ABTException
   {
      ABTValue ret;

      //
      // Call the driver's isNewResource() method to position on the correct resource object.
      // The resource should be there, because the driver checked for it before beginning the
      // save operation.
      //
      if ( !((ABTPMWRepoDriver)driver_).isNewResource(resource, cur) )
         ret = cur.getField(FLD_ID);
      else
         throw new ABTException ( new ABTError(COMP_PMREPODRIVER,
                                               "ABTIOPMWRepoTeam->getResourceID",
                                               errorMessages.ERR_TEAM_NO_RESOURCE,
                                               null) );

      return ret;
   }

   private ABTCursor getResourceCursor()
   {
      //
      // Open a cursor into the repository resource table.
      //
   	ABTCursor cur = repo_.select(RESOURCE_SELECT);
   	cur.setSort(FLD_ID);
   	return cur;
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: true if the data being written is new to the repository, i.e., the
    *             operation is an add; false, otherwise
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      //
      // If the parent's isException() method says it's an exception, then we must honor that.
      //
      if (super.isSaveException(prapiName, obj, prapiFlags, isNew))
         return true;

      boolean ret = false;       // assume NOT an exception

      //
      // If this save operation is an update of an existing repository team object, then
      // prProjectID and prResourceID are read-only fields.  They cannot be rewritten and
      // are therefore exceptions.
      //
      if (!isNew)
      {
         if (prapiName.equals(FLD_PROJECTID))
            ret = true;
         else if (prapiName.equals(FLD_RESOURCEID))
            ret = true;
      }

      return ret;
   }

}