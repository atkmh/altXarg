package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTValue;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTUserSession;

public class SimpleData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public SimpleData(ABTObject object, ABTUserSession session)
   {
      super(object,session);
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         // Don't save session specific flags (modified or created during a session).
         if (property.getName().equals(FLD_TW_MODIFIED) || property.getName().equals(FLD_TW_CREATED)) continue;
         
         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) table.put(property.getName(),value);
      }
      return table;
   }
}
