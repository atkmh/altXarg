package com.abtcorp.io.client;

import com.abtcorp.core.*;
import com.abtcorp.idl.*;

import java.io.*;
import java.util.*;

public class ABTObjectSetIDList extends ABTValue implements Serializable
{
   private Vector    deletedIDs_;
   private Vector    activeIDs_;

   public ABTObjectSetIDList(IABTObjectSet os )
   {
      activeIDs_  = new Vector();

      IABTEnumerator e = os.getElements( );
      while( e.hasMoreElements() )
      {
         IABTObject obj = (IABTObject)e.nextValue();
         IABTLocalID id = obj.getID();
         activeIDs_.addElement(id);
      }

      deletedIDs_ = new Vector();

      IABTArray data = os.getDeletedData();
      for (int i = 0;i < data.size();i++)
      {
         ABTValue val = data.get(i);
         if ( val instanceof ABTRemoteID)
         {
            // IABTObject obj = (IABTObject)val;
            // IABTLocalID id = obj.getID();
             deletedIDs_.addElement(val);
         }

      }
   }

   public Enumeration getActiveIDs()
   {
      return activeIDs_.elements();
   }

   public Enumeration getDeletedIDs()
   {
      return deletedIDs_.elements();
   }
}



