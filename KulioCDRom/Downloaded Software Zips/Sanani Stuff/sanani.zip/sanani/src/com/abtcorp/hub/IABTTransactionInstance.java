
package com.abtcorp.hub;

/*
 * IABTTransactionInstance.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *                             
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



interface IABTTransactionInstance
{    
   ABTUserSession getLockHolder();
   boolean lock(ABTUserSession requestor);

   boolean unLock(ABTUserSession requestor);
   void rollback(ABTUserSession session);
   void commit(ABTUserSession session);
 
}

