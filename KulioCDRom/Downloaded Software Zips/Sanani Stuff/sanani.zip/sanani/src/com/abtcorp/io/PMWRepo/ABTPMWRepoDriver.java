package com.abtcorp.io.PMWRepo;

/*
 * ABTPMWRepoDriver.java 03/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author          Description
* 04-20-98     SOB         Initial Implementation
* 04-23-98		SOB			Add project note support
* 04-23-98     SOB         Add parent task property support for task objects
* 04-27-98     SOB         populate() throws an exception when Object Space returns an error
* 04-28-98     SOB         Add dependency support
* 04-29-98     SA          Initial save support
* 04-29-98     SOB         Add team and resource support
* 05-01-98     SDP         Fix curly brace bug in ParseSelector
* 05-01-98     SA          Removed ABTException being thrown on open().
* 05-04-98     SOB         Add assignments support
* 05-04-98     SOB         Change predecessor/successor task containers to be containers of ABTDependencyPMW objects
* 05-05-98     SOB         Object types and rule base are string constants
* 05-05-98     SOB         Set property values of an object using a data model properties list
* 05-06-98     SOB         Set task-, assignment-, resource-related notes.
* 05-13-98     SOB         Projects are populated via the ABTProjectPopulator object
* 05-28-98     SOB         Minor mods to save() processing
* 06-09-98     SDP         Changed getProjectNameList method to return an ABTExtendedPropertyList (hashtable)
* 06-25-98     SOB         Changed field/object name constants
* 07-09-98     SOB         transaction support
* 07-13-98     SOB         Added special loginAs() support to open()
* 07-14-98     SOB         Mods to support new IO Helper functionality
* 07-20-98     SDP         modified getProjectNameList to return ABTHashtable
* 07-27-98     SOB         Removed last vestiges of original save() logic.
* 08-11-98     SOB         New public API for drivers.
* 08-13-98     SOB         Check for ABTString as values in an ABTHashtable
* 08-14-98     SOB         Minor mods to comments
* 08-17-98     SOB         Make sure 'Type' is present in the input arguments for populate() and save()
* 08-18-98     SOB         Implement execute()
* 08-20-98     SOB         Implement populate() with lock
* 08-20-98     SOB         Implement save() with unlock
* 08-31-98     SOB         Implement thinly populated projects
* 09-02-98     SOB         Added isNewResource() method for use by this driver and by its helpers
* 09-03-98     SOB         Mods to support Steve P.'s changes to ABTHashtable keys
* 09-09-98     SOB         Mods to support UNLOCK in execute()
* 09-10-98     SOB         Logic to lock a project on populate() moved to the project IO helper class
* 09-11-98     SOB         Relaxed READONLY logic on save to allow projects with no RemoteIDRepository objects
* 09-14-98     SOB         Reorganized the code into different sections of support
* 09-16-98     SOB         Removed transaction support during save() processing per Benoit
* 09-23-98     SOB         Populate() checks for presence of a Site object before proceeding
* 10-05-98     SOB         save() checks to make sure that project originally came from the target repository
* 10-08-98     SOB         during save(), when new resources are found, send back an ABTArray, not an ABTObjectSet
* 10-15-98     SDP         fixed multiple repository bug when populating projects thinly
* 10-26-98     SOB         during save processing, search for an existing resource by remoteID first, external ID second
* 11-30-98     SOB         mods to support defect #613
* 12-08-98     SOB         #657
* 12-08-98     SOB         #613 (more)
* 12-09-98     SOB         #656
* 12-14-98     SOB         #667
*
*
* TO DO:
*
* 1-  complete implementation
* 2-
*/

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTExtendedPropertyList;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
// import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTArrayEnumeration;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTPMWRepoDriver is the ABT Repository driver for the PMW application.  It is instantiated
 *  by the PMW application.
 *
 *  <pre>
 *     ABTPMWRepoDriver driver = new ABTPMWRepoDriver();
 *
 *  </pre>
 *
 * @version	$Revision: 106$
 * @author		 S. Bursch
 * @see         ABTServerDriver
 * @see         ABTRepositoryDriver
 */

public class ABTPMWRepoDriver extends ABTRepositoryDriver implements IABTPMWRepoConstants,
                                                                     IABTPMRuleConstants
{
   private ABTRepoDataDictionary dataDictionary_ = null;


   /**
    *    Constructs an ABTPMWRepoDriver using space and session input parameters
    */
   public ABTPMWRepoDriver(ABTObjectSpace space, ABTUserSession session) {super(space, session);}

   /**
    *    Constructs an ABTPMWRepoDriver using no input parameters
   */
   public ABTPMWRepoDriver(){super();}

   /**
    *    Constructs an ABTPMWRepoDriver using various input parameters
    *    @exception ABTException if an unrecoverable error occurs
    *    @exception ABTInvalidLoginException if an invalid login occurs
    *    @exception ABTInvalidLicenseException if an invalid license is presented
    *    @exception ABTInvalidRepositoryException if an error with the repository occurs
    */
   public ABTPMWRepoDriver(ABTObjectSpace space, ABTUserSession session, String server, String repository, String user, String password, String product) throws ABTException, ABTInvalidLoginException, ABTInvalidLicenseException, ABTInvalidRepositoryException
   {
      super(space, session, server, repository, user, password, product);
   }

   /**
    *    Gets a repository data dictionary object and returns it to the caller
    *    @return an ABTRepoDataDictionary object
    */
   public ABTRepoDataDictionary getDataDictionary() { return dataDictionary_; }

//-----------------------------------------------------------------------------------------------------------------------
// Inner class for supporting repository connections
//-----------------------------------------------------------------------------------------------------------------------
   private class RepoConnection
   {
      public boolean releaseConnection_;
      public ABTRepository repo_;

      public RepoConnection(ABTRepository repo, boolean release)
      {
         repo_ = repo;
         releaseConnection_ = release;
      }
   }

//-----------------------------------------------------------------------------------------------------------------------
//  Open, close, populate, save, and execute methods
//-----------------------------------------------------------------------------------------------------------------------

/**
 *		Opens a connection to a specific ABT Repository.  This version of open() overrides
 *    the parent class's version of open() because we want to retry login processing if
 *    auto login fails.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return  true  open succeeded; false: open failed
 */

	public ABTValue open(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args)
	{
   	ABTValue ret = null;    // assume success

      saveSpaceAndSession(space, usersession);
      String repoName = null;
      String userID = null;
      String password = null;
      String product = null;

      ABTSession session = getSession();

      try
      {
         // first see if there are any login arguments in the hashtable
         if (args != null && args.size() > 0)
         {
            repoName = getStringValue(args, KEY_REPONAME);
            userID = getStringValue(args, KEY_USERNAME);
            password = getStringValue(args, KEY_PASSWORD);
            product = getStringValue(args, KEY_PRODUCT);
         }

      	//
      	// If there is no repository session, perform some type of login.  Which type
      	// of login processing will be performed depends upon whether a user ID and
      	// password are present.
      	//
      	if (session == null)
      	{
      		if (userID == null && password == null)
      		   session = ABTSession.login();
      		else
      		{
      		   session = ABTSession.loginAs(userID, password);
      		   if (session == null)
      		      session = ABTSession.login();
      		}

      	   //
      	   // If we still don't have a valid repository session, we can't proceed.
      	   // Return false to the caller.
      	   //
      	   if (session == null)
      	   {
      	      //String s = "Unable to connect to repository " + getRepositoryName() + " with user " + getUser();
               return new ABTError(COMP_PMREPODRIVER,
                                   MOD_OPEN,
                                   errorMessages.ERR_UNABLE_TO_CONNECT,
                                   "Repository = '" + getRepositoryName() + "', user = '" + getUser() + "'");
      	   }
      		setSession(session);
         }

         //
         // Perform the parent's open() processing to pick up licensing, etc.
         // The parent's open() will also establish a connection to the desired repository, if
         // that is required.
         //
         if ((ret = super.open(space, usersession, args)) == null)    // did parent open successfully?
         {
            if (dataDictionary_ == null) dataDictionary_ = new ABTRepoDataDictionary();

            // Get the repository data dictionary

         	if (!dataDictionary_.isValid()) dataDictionary_.createRepoDataDictionary(getSession());

         }
      }                       // end outer try block
      catch (Exception e)
      {
         ret = new ABTError(COMP_PMREPODRIVER,
                            MOD_OPEN,
                            errorMessages.ERR_EXCEPTION_OCCURRED,
                            e);
         /*
         try
         {
            close(space, usersession, args);
         }
         catch (Exception e2)
         {
            e2.printStackTrace();
         }
         */
      }
		return ret;
	}

   /**
    *    Performs populate operations on various objects.  The most common operation will be to
    *    populate an object space with data from an ABT Repository.
    *    @param space object space this driver instance will use
    *    @param session user session this driver instance will use
    *    @param args hash table of optional, application-specific, parameters. These parameters identify
    *          the object to be populated
    *    @return if successful, various ABTValue objects, depending on the input args; otherwise, an
    *    ABTError
    */

   public ABTValue populate(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args)
   {
      ABTValue val = null;
      ABTArray extIDs = null;
      boolean transactionStarted = false;

      try
      {
         //
         // Check for required and optional parameters.
         //
         checkRequiredParms(space, usersession, args);
         checkSiteObject();
         saveSpaceAndSession(space, usersession);

         //
         // Start a transaction in the space.
         //
         usersession.startTransaction();
         transactionStarted = true;
         int howToPopulate = getPopulateCommand(args);
         switch (howToPopulate)
         {
            case PM_GETPROJECTFULL:
               val = populateProject(space, usersession, args);
               break;

            case PM_PROJECTONLY:
            case PM_PROJECTANDTASKSONLY:
            case PM_PROJECTANDCUSTFIELDSONLY:
               extIDs = getExtIDsParm(args);
               val = populateProjectsThinly(/*SDP ->*/space, usersession,/*<-SDP*/args, extIDs, howToPopulate);
               break;

            case PM_UNKNOWN:
            default:
               val = new ABTError(COMP_PMREPODRIVER,
                                  MOD_POPULATE,
                                  errorMessages.ERR_INVALID_POPULATE_TYPE,
                                  null);
               break;
         }

         //
         // If an error occurred, roll back the transaction.
         //
         if (transactionStarted)
         {
            if (ABTError.isError(val))
               usersession.rollbackTransaction();
            else
               usersession.commitTransaction();
            transactionStarted = false;
         }

      }                    // end try block
      catch( Exception e )
      {
         // I, Scott Ellis, put this here to make this compile
         val = new ABTError(COMP_PMREPODRIVER,
                            MOD_POPULATE,
                            errorMessages.ERR_EXCEPTION_OCCURRED,
                            e);
      }
      finally
      {
         return val;
      }
   }

   /**
    *    Saves a project into an ABT Repository.  Support for "saveas" is effected by
    *    a parameter in the input args hash table.  Plain vanilla save requires that the
    *    project exist in the repository, whereas, with "saveas," the target project need
    *    not exist.  Save() supports saving a stand-alone project object, or saving a project
    *    which is contained in an object set.
    *    @param space object space this driver instance will use
    *    @param session user session this driver instance will use
    *    @param args hash table of optional, application-specific, parameters
    *    @return ABTError if an error occurred, otherwise null
    */
   public ABTValue save(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args)
   {
      ABTValue ret = null;
      boolean unlock = false;
      boolean force  = false;
      ABTCursor projCursor = null;
      String repoName = null;

      try
      {
         checkRequiredParms(space, usersession, args);
         checkSiteObject();
         saveSpaceAndSession(space, usersession);

         checkSaveType(args);
         ABTObject projObj =     getProjObject(args);
         String newExtID   =     getSaveAsParm(args);
         repoName          =     getRepoParm(args, KEY_DESTINATIONNAME);
         // unlock            =     getUnlockParm(args);
         // force             =     getForceParm(args);     // FORCE parameter is deprecated

         boolean saveAs = (newExtID != null) ? true : false;

         if (!saveAs)
            connectToOriginalRepo(projObj);  /* #656 */
         else if (repoName != null)
            reconnect(space, usersession, args, repoName);

         projCursor = getProjectCursor(projObj, newExtID);

         checkFatalErrorConditions(projObj, newExtID, saveAs, projCursor);

         if (saveAs)
            setExternalID(usersession, projObj, newExtID);

         //
         // Instantiate a project saver object.  This object is designed to be capable of being
         // instantiated recursively as the save progresses.
         //
         ABTProjectSaver ps = new ABTProjectSaver(this,
                                                  projObj,
                                                  saveAs,
                                                  getProgressParm(args) );
         //
         // Invoke the project saver's save() method.  This will save the master project.  Currently,
         // if subprojects need to be saved as well, those will need separate invocations of this
         // driver's save() method.
         //
         ps.save();

         //
         // Currently, unlock is not supported as a part of save()
         //
         // if (unlock)
         //   unlockProject(projObj);

      }
      catch (ABTException e)
      {
         //
         // Trap the exception and don't let it pass upward to the application.
         //
         //e.printStackTrace();
         ret = e.getError();
         if (ret == null)
            ret = new ABTError(COMP_PMREPODRIVER,
                               MOD_SAVE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               e);
      }
      catch (Exception e)
      {
         ret = new ABTError(COMP_PMREPODRIVER,
                            MOD_SAVE,
                            errorMessages.ERR_EXCEPTION_OCCURRED,
                            e);
      }
      finally
      {
         if (projCursor != null)
            projCursor.release();

         return ret;
      }
   }

   /**
    *    Executes a driver-specific command.  Driver-specific commands are those which are implemented
    *    to support an application requirement which cannot be satisfied via populate() or save().  An example
    *    is to provide support for PM driver applications to unlock a project without first calling save(), or perhaps to
    *    provide a list of available data repositories.  If this execute() can't handle the command, it will percolate
    *    the request up to the next driver level for processing.
    *    @param space a reference to the object space
    *    @param usersession a reference to the ABTUserSession object
    *    @param args an ABTHashtable of pertinent commands and arguments
    *    @return an ABTValue which is the result of the command execution
    */
   public ABTValue execute(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args)
   {
      ABTSession sess = null;
      ABTValue ret = null;
      //
      // Execute the command.  If we don't know what to do, percolate the command up to the parent
      // driver's execute() method.
      //
      switch (getExecuteCommand(args))
      {
         case PM_LISTPROJECTS:
            // If we are connected to a repository, get the list; otherwise, it's an error.
            if (getSession() != null)
               ret = getProjectNameList(args);
            else
               ret = new ABTError(COMP_SERVERREPODRIVER,
                                  MOD_EXECUTE,
                                  errorMessages.ERR_NO_REPO_SESSION,
                                  null);
            break;

         case PM_UNLOCK:
            ret = unlockProject(args);
            break;

         case PM_FILTER_PROJECTS_BY_TASK:          /* #613 */
            ret = filterProjectsByTask(usersession, args);
            break;

         case PM_FILTER_PROJECTS_BY_CRITERIA:      /* #613 */
            ret = filterProjectsByCriteria(usersession, args);
            break;

         case PM_GET_TASK_ESTIMATES:               /* #613 */
            ret = getTaskEstimates(usersession, args);
            break;

         case PM_GET_PROJECT_ESTIMATES:            /* #613 */
            ret = getProjectEstimates(usersession, args);
            break;

         case PM_GET_USER_NAME:                    /* #657 */
            sess = getSession();
            if (sess != null)
               ret = new ABTString(sess.getUserName());  // get currently logged on user name
            else
               ret = new ABTError(COMP_SERVERREPODRIVER,
                                  MOD_EXECUTE,
                                  errorMessages.ERR_NO_REPO_SESSION,
                                  null);
            break;

         case PM_UNKNOWN:
         default:
            ret = super.execute(space, usersession, args);
            break;
      }

      return ret;
   }

//-----------------------------------------------------------------------------------------------------------------------
// Methods to support populating a project, or a group of projects.
//-----------------------------------------------------------------------------------------------------------------------

   private ABTValue populateProject(ABTObjectSpace space,
                                    ABTUserSession usersession,
                                    ABTHashtable args)
   {
      ABTValue val = null;
      String extID = null;

      try
      {
         extID = getExtIDParm(args);
         boolean toGetLock = getLockParm(args);
         boolean relaxSubprojectLocking = getRelaxingParm(args);
         String repoName = getRepoParm(args, KEY_SOURCENAME);

         //
         // We've got to have a valid Repository server and data repository connection established
         // before proceeding.
         //
         if (repoName != null)
            reconnect(space, usersession, args, repoName);
         else
            checkRepoConnection();

         //
         // Instantiate a project populator object and invoke its populate() method.
         // The populator's populate() method will return a single project object, the master
         // project.  If there are subprojects, those projects will be automagically populated
         // by separate instances of the populator class, each instance of which will have been
         // instantiated by a method in the project populator object.
         //
         ABTProjectPopulator pp = new ABTProjectPopulator(this,
                                                          new ABTString(extID),
                                                          PM_GETPROJECTFULL,
                                                          toGetLock,
                                                          relaxSubprojectLocking,     /* #667 */
                                                          getProgressParm(args));
         ABTValue projObj = pp.populate();
         if ( !ABTError.isError( projObj ) )
         {
            //
            // Get an object set object from the object space.  Check for errors.
            //
            val  = ((ABTObject) projObj).setValue(usersession,OFD_RESOLVEIPD,null);
            if ( ABTError.isError(val) )
               return val;

            val = getSpace().createObjectSet(usersession, OBJ_PROJECT);
            if ( !ABTError.isError(val) )
            {
               //
               // Add the project object to the object set
               //
              ((ABTObjectSet) val).add(usersession, (ABTObject) projObj);

// resolve the pending Interproject dependencies

            }
            else
               throw new ABTException( (ABTError) val );
         }
         else
            throw new ABTException( (ABTError) projObj );

      }
      catch (ABTException e)
      {
         //
         // Trap all ABTExceptions here.  Do not let them percolate upward to the
         // calling application.
         //
         //System.out.println(e);
         val = e.getError();
         if (val == null)
            val = new ABTError(COMP_PMREPODRIVER,
                               MOD_POPULATE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               e);

      }
      catch (Exception e)
      {
         //System.out.println(e);
         //e.printStackTrace();

         val = new ABTError(COMP_PMREPODRIVER,
                            MOD_POPULATE,
                            errorMessages.ERR_EXCEPTION_OCCURRED,
                            e);

      }
      finally
      {
         return val;
      }
   }

   private ABTValue populateProjectsThinly(ABTObjectSpace space,
                                           ABTUserSession usersession,
                                           ABTHashtable args,
                                           ABTArray extIDs,
                                           int howToPopulate)
   {
      ABTValue val = null;
      ABTCursor cursor = null;
      ABTString extID = null;
      ABTObjectSet oSet = null;
      IABTInternalProgressListener progress = getProgressParm(args);

      try
      {
         String repoName = getRepoParm(args, KEY_SOURCENAME);
         // We've got to have a valid Repository server and data repository connection established
         // before proceeding.
         if (repoName != null)
            reconnect(space, usersession, args, repoName);
         else
            checkRepoConnection();

         val = getSpace().createObjectSet(getUserSession(), OBJ_PROJECT);
         if (ABTError.isError(val)) throw new ABTException( (ABTError)val );
         oSet = (ABTObjectSet) val;    // explicit cast

         int size = 0;

         //
         // Populate the object space with thin projects (or projects and tasks only).
         // If the array of project external IDs is not null and has 1 or more entries,
         // drive the populate process the desired external IDs.  Otherwise, drive the
         // populate process from the repository cursor.
         //
         if (extIDs != null && (size = extIDs.size()) > 0 )
         {
            for (int i = 0; i < size; i++)
            {
               extID = (ABTString) extIDs.at(i);
               populateProjectThinly(extID, howToPopulate, oSet, progress);
            }
         }
         else
         {
            cursor = getProjectsCursor(args);
            while (cursor.moveNext())
            {
               extID = (ABTString) cursor.getField(FLD_EXTERNALID);
               populateProjectThinly(extID, howToPopulate, oSet, progress);
            }
         }
      }
      catch (ABTException e)
      {
         val = e.getError();
         if (val == null)
            val = new ABTError(COMP_PMREPODRIVER,
                               MOD_POPULATE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               e);
      }
      finally
      {
         if (cursor != null) cursor.release();
         if ( val instanceof ABTError )
            return val;
         if ( oSet.size(getUserSession()) > 0 )
            return oSet;
         else
            return new ABTError(COMP_PMREPODRIVER,
                                MOD_POPULATE,
                                errorMessages.ERR_NO_VIEWABLE_PROJECTS,
                                null);
      }
   }

   private void populateProjectThinly(ABTString extID,
                                      int howToPopulate,
                                      ABTObjectSet oSet,
                                      IABTInternalProgressListener progress) throws ABTException
   {
      ABTProjectPopulator pp = new ABTProjectPopulator(this,
                                                       extID,
                                                       howToPopulate,
                                                       false,
                                                       false,   /* #667 */
                                                       progress);

      ABTValue object = pp.populate();
      if (!ABTError.isError(object))
         oSet.add(getUserSession(), (ABTObject)object);
   }

   //----------------------------------------------------------------------------------------------------------------------
   // Methods to support execute().
   //----------------------------------------------------------------------------------------------------------------------

/**
 *		Gets a list of ABT Project names from a specific repository.
 *		@return  An ABTHashtable of names of projects in the named repository
 */

   private ABTValue getProjectNameList(ABTHashtable args)
   {
      String repoName = getStringValue(args, KEY_REPONAME);
      if (repoName == null)
         return new ABTError(COMP_PMREPODRIVER,
                             "getProjectNameList",
                             errorMessages.ERR_REPO_NAME_NULL,
                             null);
      ABTRepository repo = getSession().connect(repoName);
      //ABTCursor cursor = repo.select("select prName, prExternalID from PRProject");
      ABTCursor cursor = repo.select("select * from PRProject");
      ABTHashtable names = new ABTHashtable();
      //
      // For each tuple in the project table, contstruct 2 array entries which serve to
      // identify the project.  The first entry for a tuple is a string containing the
      // project's name; the second entry for a tuple is a string containing the project's
      // external ID.
      //
      while(cursor.moveNext())
      {
         //
         // Only show projects which the current user is allowed to see
         //
         if (cursor.checkRight(IS_PROJECTVIEWER))
         {
            ABTString pName = new ABTString(cursor.getFieldString(FLD_NAME));
            ABTString pID = new ABTString(cursor.getFieldString(FLD_EXTERNALID));
            names.put(pID, pName);
         }
      }
      cursor.release();								// release the ABTCursor
      repo.release();								// release the ABTRepository
      return names;
   }

   /**
    *    Unlocks a project that has been previously locked.  This method is intended for releasing a
    *    project lock via EXECUTE processing.
    *    @param args an ABTHashtable that contains all applicable parameters and argument values to
    *          perform the unlock operation
    *    @return an ABTValue indicating the success (null) or failure (ABTError) of the unlock operation
    */
   private ABTValue unlockProject(ABTHashtable args)
   {
      ABTError ret = null;
      ABTCursor cursor = null;
      RepoConnection repoCon = null;

      try
      {
         if ( getSession() == null )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->unlockProject",
                                                 errorMessages.ERR_NO_REPO_SESSION,
                                                 null) );
         String extID      =     getExtIDParm(args);
         String lockType   =     getLockTypeParm(args);

         if ( lockType != null && !lockType.equalsIgnoreCase(LCK_IMPORTEXPORT) )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->unlockProject",
                                                 errorMessages.ERR_INVALID_LOCK_TYPE,
                                                 null) );

         repoCon = getRepoConnection(args, "Execute->unlockProject");

         //
         // Get a project cursor.
         //
         cursor = repoCon.repo_.select(LOCK_SELECT +  getRepository().sqlString(extID) );

         //
         // If the user has the lock currently, release it.
         //
         if ( userHasLock(cursor) )
         {
            long lockUID = releaseLock(cursor);
            if (lockUID != 0)
               throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                    "Execute->unlockProject",
                                                    errorMessages.ERR_LOCK_STILL_HELD,
                                                    null) );
         }
         else
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->unlockProject",
                                                 errorMessages.ERR_LOCK_NOT_HELD,
                                                 null) );

      }        // end try {}
      catch (ABTException e)
      {
         ABTError err = e.getError();
         if (err == null)
            err = new ABTError(COMP_PMREPODRIVER,
                               MOD_EXECUTE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               null);
         ret = err;
      }
      finally
      {
         if (cursor != null) cursor.release();
         if (repoCon != null && repoCon.releaseConnection_) repoCon.repo_.release();

         return ret;
      }
   }

   private ABTValue filterProjectsByTask(ABTUserSession sess, ABTHashtable args) /* #613 */
   {

      ABTValue ret = null;
      ABTRepository repo = null;
      ABTCursor cursor = null;
      ABTArray projArray = null;
      RepoConnection repoCon = null;

      try
      {
         if ( getSession() == null )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->filterProjectsByTask",
                                                 errorMessages.ERR_NO_REPO_SESSION,
                                                 null) );
         String extID      =     getTaskExtIDParm(args);

         repoCon = getRepoConnection(args, "Execute->filterProjectsByTask");

         //
         // Get a project cursor where the selected projects are those which contain a task
         // whose external ID matches the external ID passed in via the input arguments.
         //
         cursor = repoCon.repo_.select( PROJECTS_BY_TASK );
         cursor.andFilter( TBL_TASK + "." + FLD_EXTERNALID + " = " + getRepository().sqlString(extID) );

         while ( cursor.moveNext() )
         {
            //
            // If the user has rights to view this project, put the external ID into the output array.
            // Create a new array, if one has not already been created.
            //
            if ( cursor.checkRight(IS_PROJECTVIEWER) )
            {
               ABTString projExtID = (ABTString) cursor.getField(FLD_EXTERNALID);
               if ( projArray == null ) projArray = new ABTArray();
               projArray.add( projExtID );
            }
         }

         ret = ( projArray != null ) ? (ABTValue) projArray : new ABTError(COMP_PMREPODRIVER,
                                                                           "Execute->filterProjectsByTask",
                                                                           errorMessages.ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA,
                                                                           null);
      }        // end try {}
      catch (ABTException e)
      {
         ABTError err = e.getError();
         if (err == null)
            err = new ABTError(COMP_PMREPODRIVER,
                               MOD_EXECUTE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               null);
         ret = err;
      }
      finally
      {
         if (cursor != null) cursor.release();
         if (repoCon != null && repoCon.releaseConnection_) repoCon.repo_.release();

         return ret;
      }
   }

   private ABTValue filterProjectsByCriteria(ABTUserSession sess, ABTHashtable args) /* #613 */
   {
      ABTValue ret = null;
      ABTCursor cursor = null;
      ABTArray projArray = null;
      ABTArray tempArray = null;
      ABTString projExtID = null;
      RepoConnection repoCon = null;

      try
      {
         if ( getSession() == null )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->filterProjectsByCriteria",
                                                 errorMessages.ERR_NO_REPO_SESSION,
                                                 null) );
         double pctExpended   =     getPctExpendedParm(args);

         //
         // If we're still not connected to the desired repository, bag this request.
         //
         repoCon = getRepoConnection(args, "Execute->filterProjectsByCriteria");

         //
         // Get a project cursor that calculates Actuals criteria.  All the projects in the repository will
         // be used in the calculations.
         //
         cursor = repoCon.repo_.select( FILTER_BY_CRITERIA );

         while ( cursor.moveNext() )
         {
            projExtID = (ABTString) cursor.getField(FLD_EXTERNALID);
            ABTValue val   = cursor.getField(ACTUALS);
            double actuals = (ABTValue.isNull( val) ? 0.0 : val.doubleValue() );
            val = cursor.getField(TOTAL);
            double total = (ABTValue.isNull( val ) ? 0.0 : val.doubleValue() );

            if (total <= 0)
               continue;

            if ( (actuals / total) >= pctExpended )
            {
               if ( tempArray == null ) tempArray = new ABTArray();
               tempArray.add( projExtID );
            }
         }

         //
         // If some projects were found that meet the criteria, scan through them and
         // make sure the user has privileges to view the projects.  tempArray contains
         // all the external IDs of those projects which meet the criteria.  projArray
         // will contain all those external IDs which meet the criteria and which the
         // user has privileges to see.  Two arrays are used to avoid issues with removing
         // entries from an array being used with an enumerator.
         //
         if ( tempArray != null )
         {
            cursor.release();
            cursor = repoCon.repo_.select("select PRProject.* from PRProject order by PRProject.prExternalID");
            ABTArrayEnumeration e = new ABTArrayEnumeration(tempArray);
            while ( e.hasMoreElements() )
            {
               projExtID = (ABTString) e.nextElement();
               cursor.bsearchFirst(FLD_EXTERNALID, projExtID);
               if ( cursor.checkRight(IS_PROJECTVIEWER) )
               {
                  if (projArray == null) projArray = new ABTArray();
                  projArray.add( projExtID );
               }
            }
         }

         //
         // If there are any project external IDs to hand back to the user, do so now.  Otherwise, report an error.
         //
         ret = ( projArray != null && projArray.size() > 0 ) ? (ABTValue) projArray : new ABTError(COMP_PMREPODRIVER,
                                                                           "Execute->filterProjectsByCriteria",
                                                                           errorMessages.ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA,
                                                                           null);
      }        // end try {}
      catch (ABTException e)
      {
         ABTError err = e.getError();
         if (err == null)
            err = new ABTError(COMP_PMREPODRIVER,
                               MOD_EXECUTE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               null);
         ret = err;
      }
      finally
      {
         if (cursor != null) cursor.release();
         if (repoCon != null && repoCon.releaseConnection_) repoCon.repo_.release();
         return ret;
      }
   }

   private ABTValue getTaskEstimates(ABTUserSession sess, ABTHashtable args) /* #613 */
   {
      ABTValue ret = null;
      ABTRepository repo = null;
      ABTCursor cursor = null;
      ABTHashtable projHash = null;
      RepoConnection repoCon = null;
      StringBuffer sqlStmt = new StringBuffer(100);
      boolean foundMinSeq = false;
      ABTValue minSeq = null;
      try
      {
         if ( getSession() == null )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->getTaskEstimates",
                                                 errorMessages.ERR_NO_REPO_SESSION,
                                                 null) );
         String taskExtID    = getTaskExtIDParm(args);
         ABTArray projectIDs = getProjectIDsParm(args);

         repoCon = getRepoConnection(args, "Execute->getTaskEstimates");

         //
         // For each project ID in the input array, perform the set of SQL queries to get
         // task estimates.
         //
         ABTArrayEnumeration e = new ABTArrayEnumeration( projectIDs );
         while ( e.hasMoreElements() )
         {
            ABTInteger curProjectID = (ABTInteger) e.nextElement();

            //
            // Query 0:
            //
            cursor = repoCon.repo_.select( GET_TASK_ESTIMATES_QRY0 );
            cursor.andFilter( TBL_TASK + "." + FLD_EXTERNALID + " = " + repoCon.repo_.sqlString(taskExtID) );
            cursor.andFilter( TBL_TASK + "." + FLD_PROJECTID + " = " + curProjectID.intValue() );

            if ( cursor.moveFirst() )
            {
               ABTValue WBSSequence = cursor.getField(FLD_WBSSEQUENCE);
               ABTValue WBSLevel    = cursor.getField(FLD_WBSLEVEL);

               //
               // Query 1:
               //
               sqlStmt.setLength(0);      // truncate buffer
               sqlStmt.append( GET_TASKESTIMATES_QRY1A );
               sqlStmt.append( WBSSequence.intValue() );
               sqlStmt.append( GET_TASKESTIMATES_QRY1B );
               sqlStmt.append( WBSLevel.intValue() );
               sqlStmt.append( GET_TASKESTIMATES_QRY1C );
               sqlStmt.append( curProjectID.intValue() );
               sqlStmt.append( GET_TASKESTIMATES_QRY1D );

               cursor = repoCon.repo_.select( sqlStmt.toString() );
               //System.out.println("Query 1: " + sqlStmt.toString() );

               cursor.moveFirst();
               if (cursor.isValid())
               {
                  minSeq = cursor.getField(MINSEQ);
                  foundMinSeq = true;
               }

               //
               // Query 2:
               //
               sqlStmt.setLength(0);
               sqlStmt.append( GET_TASKESTIMATES_QRY2A );
               sqlStmt.append( GET_TASKESTIMATES_QRY2B );
               sqlStmt.append( WBSSequence.intValue() );

               //
               // If query #1, above, failed to produce a task minimum WBS Sequence number, then
               // bypass inserting that minimum sequence number into query #2. Otherwise, use
               // the minimun WBS Sequence number found to help restrict the scope of query #2.
               //
               if (foundMinSeq)
               {
                  sqlStmt.append( GET_TASKESTIMATES_QRY2C );
                  sqlStmt.append( minSeq.intValue() );
               }
               sqlStmt.append( GET_TASKESTIMATES_QRY2D );
               sqlStmt.append( curProjectID.intValue() );
               sqlStmt.append( GET_TASKESTIMATES_QRY2E );

               cursor = repoCon.repo_.select( sqlStmt.toString() );
               //System.out.println("Query 2: " + sqlStmt.toString() );

               if ( cursor.moveFirst() )
               {
                  ABTValue expr1 = cursor.getField(EXPR1);
                  if ( projHash == null ) projHash = new ABTHashtable();
                  projHash.putItemByKey(curProjectID, expr1);
               }
               else
                  continue;      // error: get next project ID from array
            }
            else
               continue;            // error: get next project ID from array

         }                          // end while ( e.hasMoreElements() )


         ret = ( projHash != null ) ? (ABTValue) projHash : new ABTError(COMP_PMREPODRIVER,
                                                                         "Execute->getTaskEstimates",
                                                                         errorMessages.ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA,
                                                                         null);
      }        // end try {}
      catch (ABTException e)
      {
         ABTError err = e.getError();
         if (err == null)
            err = new ABTError(COMP_PMREPODRIVER,
                               MOD_EXECUTE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               null);
         ret = err;
      }
      finally
      {
         if (cursor != null) cursor.release();
         if (repoCon != null && repoCon.releaseConnection_) repoCon.repo_.release();

         return ret;
      }
   }

   private ABTValue getProjectEstimates(ABTUserSession sess, ABTHashtable args) /* #613 */
   {
      ABTValue ret = null;
      ABTCursor cursor = null;
      ABTHashtable projHash = null;
      RepoConnection repoCon = null;
      StringBuffer sqlStmt = new StringBuffer(100);

      try
      {
         if ( getSession() == null )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "Execute->getProjectEstimates",
                                                 errorMessages.ERR_NO_REPO_SESSION,
                                                 null) );
         ABTArray projectIDs = getProjectIDsParm(args);

         repoCon = getRepoConnection(args, "Execute->getProjectEstimates");

         //
         // For each project ID in the input array, perform a SQL query to get
         // task estimates for an entire project.
         //
         ABTArrayEnumeration e = new ABTArrayEnumeration( projectIDs );
         while ( e.hasMoreElements() )
         {
            ABTInteger curProjectID = (ABTInteger) e.nextElement();

            sqlStmt.setLength(0);      // truncate buffer
            sqlStmt.append( GET_PROJECTESTIMATES_QRY1A );
            sqlStmt.append( curProjectID.intValue() );      // insert project's prID into the query
            sqlStmt.append( GET_PROJECTESTIMATES_QRY1B );   // group by clause

            cursor = repoCon.repo_.select( sqlStmt.toString() );

            if ( cursor.moveFirst() )
            {
               ABTValue expr1 = cursor.getField(EXPR1);
               if ( projHash == null ) projHash = new ABTHashtable();
               projHash.putItemByKey(curProjectID, expr1);
            }
         }                          // end while ( e.hasMoreElements() )

         ret = ( projHash != null ) ? (ABTValue) projHash : new ABTError(COMP_PMREPODRIVER,
                                                                         "Execute->getProjectEstimates",
                                                                         errorMessages.ERR_NO_PROJECTS_MEET_SELECTION_CRITERIA,
                                                                         null);
      }        // end try {}
      catch (ABTException e)
      {
         ABTError err = e.getError();
         if (err == null)
            err = new ABTError(COMP_PMREPODRIVER,
                               MOD_EXECUTE,
                               errorMessages.ERR_EXCEPTION_OCCURRED,
                               null);
         ret = err;
      }
      finally
      {
         if (cursor != null) cursor.release();
         if (repoCon != null && repoCon.releaseConnection_) repoCon.repo_.release();

         return ret;
      }
   }

//---------------------------------------------------------------------------------------------------------
//  Utility methods begin here.  Some utility methods are desginated "public."  This is to allow access
//  from the IO Helper classes.
//---------------------------------------------------------------------------------------------------------

   /**
    *    Determines if a resource object represents a new resource tuple in the Repository
    *    or if it already exists in the Repository.  If the resource object exists in the Repository,
    *    the ABTCursor object will be positioned on the existing tuple upon return. This method,
    *    while declared public, is
    *    not intended for use by applications.  Rather, it is intended for use by the PM Repo
    *    driver itself and by helper objects instantiated by that driver.
    *    @param obj an ABTObject of type Resource
    *    @param cur an ABTCursor object where the result set is ordered by prExternalID
    *    @return true if the resource object is new to the Repository, false if exists in the
    *          repository
    *    @exception ABTException if the resource object's external ID or ID cannot be obtained.
    */
   public boolean isNewResource(ABTObject obj, ABTCursor cur) throws ABTException
   {
      boolean ret = true;        // assume resource is a new resource (doesn't exist in the repo)

      // Get the resource's remote ID, if any.
      //
      ABTRemoteID rmtID = obj.getRemoteID(getUserSession());

      //
      // If the remote ID came from a repository, check to see if it is the same repository
      // to which the input cursor is connected.
      //
      if (rmtID instanceof ABTRemoteIDRepository)
      {
         //
         // If the resource object's repository is the same as that of the currently connected
         // cursor, search the cursor for a match on the prID field of the resource.
         //
         if ( ((ABTRemoteIDRepository)rmtID).getRepositoryID() == getRepository().getID() )
         {
            ABTValue id = obj.getValue(getUserSession(), OFD_ID);
            if (ABTError.isError(id)) throw new ABTException((ABTError) id);
            // The following code assumes the cursor is ordered by prID.  If it's not
            // ordered by prID, the code won't work and will give improper results.
            if ( cur.bsearchFirst(FLD_ID, id) )
               ret = false;                     // it exists
         }
      }

      //
      // If the we still haven't positively identified the resource as being present in the
      // currently connected repository, i.e., ret is still true, then perform a search by external ID.
      //
      if ( ret )
      {
         ABTValue externalID = obj.getValue(getUserSession(), OFD_EXTERNALID);
         if (ABTError.isError(externalID)) throw new ABTException( (ABTError) externalID );
         if ( cur.lsearchFirst(FLD_EXTERNALID, externalID))
         {
            ret = false;            // it exists
         }
      }

      return ret;
   }

   private int getExecuteCommand(ABTHashtable args)
   {
      int ret = PM_UNKNOWN;
      String exeCmd = getStringValue(args, KEY_COMMAND);

      //
      // Is it a list command?  Check its type, if so.
      //
      if (exeCmd.equalsIgnoreCase(CMD_LIST))
      {
         String exeType = getStringValue(args, KEY_TYPE);

         //
         // Is the type present?  Check for "Project", if so.
         //
         if (exeType != null)
         {
            if (exeType.equalsIgnoreCase(TYPE_PROJECT))
               ret = PM_LISTPROJECTS;
         }
      }
      else if (exeCmd.equalsIgnoreCase(CMD_UNLOCK))
         ret = PM_UNLOCK;
      else if (exeCmd.equalsIgnoreCase(CMD_FILTER_PROJECTS_BY_TASK))
         ret = PM_FILTER_PROJECTS_BY_TASK;
      else if (exeCmd.equalsIgnoreCase(CMD_FILTER_PROJECTS_BY_CRITERIA))
         ret = PM_FILTER_PROJECTS_BY_CRITERIA;
      else if (exeCmd.equalsIgnoreCase(CMD_GET_TASK_ESTIMATES))
         ret = PM_GET_TASK_ESTIMATES;
      else if (exeCmd.equalsIgnoreCase(CMD_GET_PROJECT_ESTIMATES))
         ret = PM_GET_PROJECT_ESTIMATES;
      else if (exeCmd.equalsIgnoreCase(CMD_GETUSERNAME))
         ret = PM_GET_USER_NAME;

      return ret;
   }

   private ABTArray getExtIDsParm(ABTHashtable args) throws ABTException
   {
      Object obj = getABTValue(args, KEY_EXTIDS);
      if ( obj != null && !(obj instanceof ABTArray) )
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "getExtIDsParm",
                                              errorMessages.ERR_EXTIDS_ARG,
                                              null) );

      return (ABTArray) obj;
   }

   private ABTObject getProjObject(ABTHashtable args) throws ABTException
   {
      ABTValue obj = getABTValue(args, KEY_SOURCE);
      if (obj instanceof ABTObject) return (ABTObject) obj;
      if (obj instanceof ABTObjectSet && ((ABTObjectSet)obj).size(getUserSession()) > 0)
         return (ABTObject)((ABTObjectSet)obj).at(getUserSession(), 0);

      throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                           "getExtIDsParm",
                                           errorMessages.ERR_INPUT_OBJECT_MISSING,
                                           null) );
   }

   private String getSaveAsParm(ABTHashtable args) throws ABTException
   {
      String saveAs = getStringValue(args, KEY_SUBTYPE);
      if (saveAs == null || !saveAs.equalsIgnoreCase(SUBTYPE_SAVEAS))
         return null;
      String extID = getStringValue(args, KEY_EXTID);
      if (extID == null)
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "getSaveAsParm",
                                              errorMessages.ERR_PROJECT_EXTID_MISSING,
                                              null) );
      return extID;
   }

   private boolean getUnlockParm(ABTHashtable args)
   {
      //
      // See if the caller wants to unlock the project after the save operation completes.
      // If the unlock parameter is not present, assume the default value of false, i.e., do not
      // release the the lock.
      //
      return getBooleanValue(args, KEY_UNLOCK, false);
   }

   private double getPctExpendedParm(ABTHashtable args)
   {
      return getDoubleValue(args, KEY_PCTEXPENDED, 0.0);
   }

   private String getTaskExtIDParm(ABTHashtable args) throws ABTException
   {
      String taskExtID = getStringValue(args, KEY_TASKEXTID);
      if (taskExtID == null)
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "getTaskExtIDParm",
                                              errorMessages.ERR_MISSING_TASK_EXTID,
                                              null) );
      return taskExtID;
   }

   private ABTArray getProjectIDsParm(ABTHashtable args) throws ABTException
   {
      ABTValue projIDs = getABTValue(args, KEY_PROJECTIDS);
      if ( !(projIDs instanceof ABTArray) )
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "getProjectIDParm",
                                              errorMessages.ERR_MISSING_PROJECT_IDS,
                                              null) );
      return (ABTArray) projIDs;
   }

   private String getExtIDParm(ABTHashtable args) throws ABTException
   {
      String extID = getStringValue(args, KEY_EXTID);
      if (extID == null)
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "getExtIDParm",
                                              errorMessages.ERR_PROJECT_EXTID_MISSING,
                                              null) );
      return extID;
   }

   private boolean getLockParm(ABTHashtable args) throws ABTException
   {
      //
      // Check the input args hash table for the "Lock" key.  If the corresponding
      // value is present and valid, return it to the caller; otherwise return false
      // to the caller.
      //
      return getBooleanValue(args, KEY_LOCK, false);
   }

   private boolean getRelaxingParm(ABTHashtable args) throws ABTException
   {
      //
      // Check the input args hash table for the RelaxSubprojectLocking key.  If the corresponding
      // value is present and valid, return it to the caller; otherwise return false
      // to the caller.
      //
      return getBooleanValue(args, KEY_RELAXSUBPROJECTLOCKING, false);
   }

   private String getRepoParm(ABTHashtable args, String repokey)
   {
     return getStringValue(args, repokey);
   }

   private boolean getForceParm(ABTHashtable args)
   {
      //
      // See if the caller wants to force a project out to the repository regardless if
      // certain recoverable errors occur.  If the force parameter is not present, assume
      // a default value of false, i.e., do not force the project out to the repository if
      // errors occur.
      //
      return getBooleanValue(args, KEY_FORCE, false);
   }

   private String getLockTypeParm(ABTHashtable args)
   {
      return getStringValue(args, KEY_LOCKTYPE);
   }

   private String getExternalID(ABTObject obj) throws ABTException
   {
      ABTValue extID = obj.getValue(getUserSession(), OFD_EXTERNALID);
      checkError(extID);
      return extID.stringValue();
   }

   private ABTCursor getProjectCursor(ABTObject obj, String newExtID) throws ABTException
   {
      //
      // Position a cursor onto the target project tuple in the repository, if it exists.
      //
      String  oldExtID = getExternalID(obj);
      String  extID = (newExtID != null) ? newExtID : oldExtID;
      ABTCursor cursor = getRepository().select(LOCK_SELECT + getRepository().sqlString( extID ));
      return cursor;
   }

   private ABTCursor getProjectsCursor(ABTHashtable args)
   {
      String repoName = getStringValue(args, KEY_SOURCENAME);
      ABTRepository repo = (repoName == null) ? getRepository() : getSession().connect(repoName);
      return repo.select("select * from PRProject");
   }

   private ABTCursor getResourceCursor()
   {
   	ABTCursor cur = getRepository().select(RESOURCE_SELECT);
   	cur.setSort(FLD_ID);
   	return cur;
   }

   private long releaseLock(String extID)
   {
      ABTCursor cursor = getRepository().select(LOCK_SELECT + getRepository().sqlString( extID ));
      long lockHolderUID = releaseLock(cursor);
      cursor.release();
      return lockHolderUID;
   }

   private long releaseLock(ABTCursor cursor)
   {
      long lockHolderUID = 0;
      if ( cursor.moveFirst() )
         lockHolderUID = cursor.unlock(LCK_IMPORTEXPORT);
      return lockHolderUID;
   }

   private void saveSpaceAndSession(ABTObjectSpace space, ABTUserSession usersession)
   {
      //
      // TO DO:  this implementation must change when drivers become thread safe.
      //         saving the space and the user session references implies saving state.
      //         eventually, the drivers must be stateless.
      //
      setSpace(space);
      setUserSession(usersession);
   }

   private String setExternalID(ABTUserSession usersession, ABTObject project, String newExtID) throws ABTException
   {
      ABTValue val = project.getValue(usersession, OFD_EXTERNALID);
      if (ABTError.isError(val)) throw new ABTException( (ABTError) val );
      String oldExtID = val.stringValue();
      //
      // Only set the external ID if it has not already been set by the caller
      //
      if ( !newExtID.equals( oldExtID ) )
      {
         val = project.setValue(usersession, OFD_EXTERNALID, new ABTString(newExtID));
         if (ABTError.isError(val)) throw new ABTException( (ABTError) val );
      }

      return oldExtID;
   }

   private boolean projectIsReadOnly(ABTObject obj) throws ABTException
   {
      ABTUserSession sess = getUserSession();

      //
      // If the project's remote ID is null, or is not an instance of
      // ABTRemoteIDRepository, then it's a new object and the READONLY
      // property need not be checked.  The assumption here is that the application
      // invoking the save processing knows what it is doing with this project.  Return
      // false to the caller, indicating the project is not READONLY.
      //
      ABTValue rmtID = obj.getID().getRemote(sess);
      if ( rmtID == null ||
          !(rmtID instanceof ABTRemoteIDRepository) )
         return false;

      //
      // The project object has a remote ID and the project came from a repository.
      // We need to inspect the readonly property of the project object.
      //
      ABTValue readonly = obj.getValue(getUserSession(), OFD_READONLY);
      checkError(readonly);

      //
      // If we can't determine for sure what the readonly state of the project
      // is, then assume assume the most restrictive:  readonly.  Otherwise,
      // return what the READONLY property indicates.
      //
      return (readonly == null) ? true : readonly.booleanValue();
   }

   private void checkSiteObject() throws ABTException
   {
      ABTValue site = getSite();
      if ( ABTError.isError( site ) )
         throw new ABTException((ABTError) site);
   }

   private void checkError(ABTValue val) throws ABTException
   {
      if (ABTError.isError(val))
         throw new ABTException((ABTError) val);
   }

   private void checkFatalErrorConditions(ABTObject obj, String newExtID, boolean saveAs, ABTCursor cursor) throws ABTException
   {
      //
      // If the project is marked READONLY, it cannot be saved.
      //
      if ( projectIsReadOnly(obj) )
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "checkFatalErrorConditions",
                                              errorMessages.ERR_PROJECT_READONLY,
                                              null) );

      if (saveAs)
      {
         //
         // Check for new resources.  Any new resources for the project being saved will force the saveAs operation to abort.
         //
         checkNewResources(obj);

         //
         // If the target project exists in the object space, disallow saving of the project.
         //
         if (projectExistsInSpace(newExtID))
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "checkFatalErrorConditions",
                                                 errorMessages.ERR_TARGET_EXISTS_SPACE,
                                                 null) );

         //
         // If the target project exists in the repository, disallow saving of the project.  All "saveAs"
         // projects must be saved as brand new projects.
         //
         if ( !projectExistsInRepo(cursor) )
         {
            //
            // The target project does not exist in the repository, so make sure the user has appropriate
            // rights to save the new project.  It should be the case that the result set contains no
            // tuples at all.  However, to make absolutely sure that the cursor is NOT positioned on a
            // tuple in the result set, the following ABTCursor methods are used to position beyond the
            // end of the result set.
            //
            cursor.moveEOF();    // move to the end of the result set  /* #665 */
            cursor.moveNext();   // attempt to move past the end of the result set  /* #665 */
            if (!cursor.checkRight(IS_PROJECTAUTHOR))  /* #665 */
               throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                    "checkFatalErrorConditions",
                                                    errorMessages.ERR_NO_SAVEAS_RIGHTS,
                                                    null) );
            cursor.moveFirst();  // restore cursor  /* #665 */
         }
         else
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "checkFatalErrorConditions",
                                                 errorMessages.ERR_TARGET_EXISTS_REPO,
                                                 null) );
      }
      else
      {
         //
         // Make sure the project being saved came from a repository and that the target repository is the same
         // as the project's original repository.
         //
         checkRepoIDs(obj);

         //
         // Check for new resources.  Any new resources for the project being saved will force the save operation to abort.
         //
         checkNewResources(obj);

         //
         // The user must have the import/export lock for this existing project being saved.
         //
         if ( !userHasLock(cursor) )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "checkFatalErrorConditions",
                                                 errorMessages.ERR_NOT_LOCKED,
                                                 null) );

         //
         // Check the project's version number as it exists in the object space vs. the version number as it exists
         // in the repository.  The project's version number in the space must be greater than that in the repository.
         //
         checkVersionNumber(obj, cursor);
      }
   }

   private void checkRepoIDs(ABTObject proj) throws ABTException
   {
      long repoID = getRepository().getID();
      long projRepoID = getRepoID(proj);
      if ( projRepoID != repoID )
         throw new ABTException ( new ABTError(COMP_PMREPODRIVER,
                                               MOD_SAVE,
                                               errorMessages.ERR_PROJECT_NOT_FROM_REPO,
                                               null) );
   }

   private ABTObjectSet getTeamResources(ABTObject obj) throws ABTException
   {
      ABTValue oSet = obj.getValue(getUserSession(), OFD_TEAMRESOURCES);
      checkError(oSet);
      return (ABTObjectSet) oSet;
   }

   private ABTObject getResource(ABTObject teamObj) throws ABTException
   {
      ABTValue obj = teamObj.getValue(getUserSession(), OFD_RESOURCE);
      checkError(obj);
      return (ABTObject) obj;
   }

   private int getVersionNumber(ABTObject obj) throws ABTException
   {
      ABTValue version = obj.getValue(getUserSession(), OFD_VERSION);
      checkError(version);
      return version.intValue();
   }

   private String getRepoName(ABTObject obj) throws ABTException
   {
      ABTValue repoName = obj.getValue(getUserSession(), OFD_REPONAME);
      checkError(repoName);

      return (ABTValue.isNull(repoName) ? "" : repoName.stringValue());
   }

   private long getRepoID(ABTObject obj) throws ABTException
   {
      ABTValue rmtID = obj.getID().getRemote( getUserSession() );
      checkError( rmtID );
      if ( ABTValue.isNull( rmtID ) ||
           !(rmtID instanceof ABTRemoteIDRepository) )
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              MOD_SAVE,
                                              errorMessages.ERR_PROJECT_NOT_FROM_REPO,
                                              null) );
      return ((ABTRemoteIDRepository) rmtID).getRepositoryID();
   }

   private void deleteProjectInRepo(ABTCursor cur)
   {
      if ( cur.moveFirst() )
         cur.delete();
   }

   private void reconnect(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args, String repoName) throws ABTException
   {
      //
      // set the repository name and then reconnect to the desired repository.
      // reconnecting may involve releasing the current repository session.
      //
      setRepositoryName(repoName);
      ABTRepository repo = getRepository();
      if (repo == null)
      {
         if (open(space, usersession, args) != null)
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "reconnect",
                                                 errorMessages.ERR_UNABLE_TO_CONNECT,
                                                 "Unable to open repository '" + getRepositoryName() + "'"));
      }
      else
      {
         repo.release();
         setRepository(null);
         if (open(space, usersession, args) != null)
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "reconnect",
                                                 errorMessages.ERR_UNABLE_TO_CONNECT,
                                                 "Unable to open repository '" + getRepositoryName() + "'"));
      }
   }

   private void checkNewResources(ABTObject obj) throws ABTException
   {
      ABTCursor cursor = getResourceCursor();
      //
      // Loop through all of the team objects so that we can get at the resource objects.
      // For any resource object that is not present in the repository, i.e., it is a "new"
      // resource, add the resource object to an object set of resources.  At the end, if
      // at least one new resource was found, throw an ABTException, passing the object set
      // so that the invoking application can process them.
      //
      try
      {
         ABTArray newResources = null;
         ABTUserSession sess = getUserSession();
         ABTObjectSet trOset = getTeamResources(obj);
         int size = trOset.size(sess);
         for (int i = 0; i < size; i++)
         {
            ABTObject teamObj = (ABTObject) trOset.at(sess, i);
            ABTObject resourceObj = getResource(teamObj);
            if (isNewResource(resourceObj, cursor))
            {
               if (newResources == null)
                  newResources = new ABTArray();
               newResources.add(resourceObj);
            }
         }

         if (newResources != null)
         {
            ABTError err = new ABTError(COMP_PMREPODRIVER,
                                        MOD_SAVE,
                                        errorMessages.ERR_NEW_RESOURCES,
                                        newResources);
            throw new ABTException(err);
         }
      }
      finally
      {
         if (cursor != null) cursor.release();
      }
   }

   private void checkSaveType(ABTHashtable args) throws ABTException
   {
      String type = getStringValue(args, KEY_TYPE);
      if (type == null || !type.equalsIgnoreCase(TYPE_PROJECT) )
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "checkSaveType",
                                              errorMessages.ERR_BAD_TYPE,
                                              null) );
   }

   private void checkVersionNumber(ABTObject obj, ABTCursor cursor) throws ABTException
   {
      if ( projectExistsInRepo(cursor) )
      {
         int   spaceVersion = getVersionNumber(obj);
         ABTValue repoVersion = cursor.getField(FLD_VERSION);
         if ( spaceVersion <= repoVersion.intValue() )
            throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                                 "checkVersionNumber",
                                                 errorMessages.ERR_BAD_VERSIONS,
                                                 null) );
      }
   }

   private void checkRequiredParms(ABTObjectSpace space, ABTUserSession usersess, ABTHashtable args) throws ABTException
   {
      if (space == null)
         throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                             "checkRequiredParms",
                                             errorMessages.ERR_OBJECT_SPACE_MISSING,
                                             null));
      if (usersess == null)
         throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                             "checkRequiredParms",
                                             errorMessages.ERR_USER_SESSION_MISSING,
                                             null));
      if (args == null || args.size() == 0)
      if (usersess == null)
         throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                             "checkRequiredParms",
                                             errorMessages.ERR_ARGS_MISSING,
                                             null));
      String type = getStringValue(args, KEY_TYPE);

      //
      // The input arguments are present, but is the 'Type' argument present?
      //
      if (type == null)
         throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                             "checkRequiredParms",
                                             errorMessages.ERR_TYPE_MISSING,
                                             null));
   }

   private void checkRepoConnection() throws ABTException
   {
      if (getSession() == null || getRepository() == null)
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "checkRepoConnection",
                                              errorMessages.ERR_NO_REPO_SESSION,
                                              null) );
   }

    /**
    *    Gets the value associated with the PROGRESS key in the input ABTHashtable.
    *    @return an IABTInternallProgressListener, or null
    */
   private IABTInternalProgressListener getProgressParm(ABTHashtable args)
   {
      return (IABTInternalProgressListener) args.getItemByString(KEY_PROGRESS);
   }

    /**
    *    Gets the value associated with the TYPE key in the input ABTHashtable.
    *    Converts the value to an integer so that the caller can use it in a switch
    *    statement.
    *    @return an integer value corresponding to the TYPE/SUBTYPE combination
    */
   private int getPopulateCommand(ABTHashtable args)
   {
      int ret = PM_UNKNOWN;
      String type = getStringValue(args, KEY_TYPE);

      if (type.equalsIgnoreCase(TYPE_PROJECT))
      {
         String subtype = getStringValue(args, KEY_SUBTYPE);
         if ( subtype == null || subtype.equalsIgnoreCase(SUBTYPE_FULL) )  ret = PM_GETPROJECTFULL;
         else if (subtype.equals(SUBTYPE_PROJECTONLY) )                    ret = PM_PROJECTONLY;
         else if (subtype.equals(SUBTYPE_PROJECTANDTASKSONLY) )            ret = PM_PROJECTANDTASKSONLY;
         else if (subtype.equals(SUBTYPE_PROJECTANDCUSTFIELDSONLY) )       ret = PM_PROJECTANDCUSTFIELDSONLY;
      }

      return ret;
   }

   private boolean projectExistsInRepo(String extID)
   {
      boolean ret = false; //assume it doesn't exist

      //
      // To see if the project exists in the currently-connected repository, use the
      // same SQL query that is used to determine lock status.
      //
      ABTCursor cursor = getRepository().select(LOCK_SELECT + getRepository().sqlString( extID ) );
      if (cursor.moveFirst())
         ret = true;
      cursor.release();
      return ret;
   }

   private boolean projectExistsInRepo(ABTCursor cursor)
   {
      boolean ret = false; //assume it doesn't exist

      if (cursor.moveFirst())
         ret = true;

      return ret;
   }

   private boolean projectExistsInSpace(String extID)
   {
      boolean ret = false;    // assume project does not exist in the object space

      ABTValue val = getSpace().findObject( getUserSession(), OBJ_PROJECT,
                                            OFD_EXTERNALID, new ABTString(extID ) );

      //
      // If findObject() did not return an error and did not return null, a project with
      // external ID, extID, was found in the space.  Return true to the caller.
      //
      if (!ABTError.isError( val ) && !ABTValue.isNull( val ) )
         ret =  true;

      return ret;
   }

   private boolean userHasLock(String extID)
   {
      ABTCursor cursor = getRepository().select(LOCK_SELECT + getRepository().sqlString( extID ) );
      boolean ret = userHasLock(cursor);
      cursor.release();
      return ret;
   }

   private boolean userHasLock(ABTCursor cursor)
   {
      boolean ret = false;    // assume user does not have the import/export lock for the project
      if ( cursor.moveFirst() )
      {
         if ( cursor.checkLock(LCK_IMPORTEXPORT, false) == getRepository().getSession().getUserID() )
            ret = true;
      }

      return ret;
   }

   /**
    *    Unlocks a project that has been previously locked.
    *    @param obj the project object (ABTObject) whose lock will be released
    */
   private void unlockProject(ABTObject obj)
   {
      ABTValue extID = obj.getValue(getUserSession(), OFD_EXTERNALID);
      if (ABTError.isError(extID) ||
          extID == null)
         return;
      releaseLock(extID.stringValue());
   }

   private ABTError notImplemented(String method)
   {
      return new ABTError(COMP_PMREPODRIVER,
                          method,
                          errorMessages.ERR_NOT_IMPLEMENTED,
                          null);
   }

   private RepoConnection getRepoConnection(ABTHashtable args, String methodName) throws ABTException
   {
      RepoConnection ret  = null;
      String repoName     = getRepoParm(args, KEY_REPONAME);
      ABTRepository repo  = null;
      boolean releaseRepo = false;

      //
      // If the repository name came in with the arguments, check to see if we are
      // already connected to the desired repository.  If so, use that repo connection.
      // Otherwise, attempt to establish a new connection to the desired repository.
      //
      if (repoName != null)
      {
         if ( repoName.equalsIgnoreCase( getRepositoryName() ) )
         {
            repo = getRepository();
            if ( repo == null )
               repo = getSession().connect(repoName);
            else
               releaseRepo = false;
         }
         else
            repo = getSession().connect(repoName);
      }
      else
      {
         //
         // The repository name did NOT come in with this request.  We have
         // to use the existing repository connection, if it's there.  If we end up
         // using the existing repository connection, we don't want to release it
         // when we are done.
         //
         repo = getRepository();
         if (repo != null)
            releaseRepo = false;
      }

      if (repo != null)
         ret = new RepoConnection(repo, releaseRepo);

      //
      // If we're still not connected to the desired repository, bag this request.
      //
      if (ret == null)
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              methodName,
                                              errorMessages.ERR_UNABLE_TO_CONNECT,
                                              null) );

      return ret;
   }

   private void connectToOriginalRepo(ABTObject projObj) throws ABTException /* #656 */
   {
      //
      // Get the original repository name from the input project object.  If it's not
      // there, throw an exception.
      //
      String repoName = getRepoName(projObj);
      if (repoName.length() == 0)
         throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                             "connectToOriginalRepo",
                                             errorMessages.ERR_ORIG_REPONAME_NULL,
                                             null) );

      //
      // If the repository names are equal, assume we are already connected to the original
      // repository of the input project object.
      //
      if ( repoName.equals( getRepositoryName() ) )
         return;

      //
      // Oops.  We're not connected to the original repository for this project.
      // Reconnect to it now.
      //
      reconnect(getSpace(), getUserSession(), new ABTHashtable(), repoName);
   }
}