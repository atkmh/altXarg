package  com.abtcorp.objectModel.abt.fr;

/*
 * CalendarBaseCalendar.java 08/21/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author         Description
 * 09-23-98       SOB         Initial Design
 *
 */

import   java.util.Enumeration;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.*;

/**
 * Field rule for the base calendar in a calendar object.
 *
 * @version	$Revsion$
 * @author  S. Bursch
 */

public class CalendarBaseCalendar extends SiteFieldRule
{

   /**
    * Validate the value that is being set into the parent object container.
    * Return an ABTError if the value is invalid.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      // return if new value is the same as old
      if( !ABTValue.isNull(newValue) && newValue.equals( myValue ) )
         return myValue;

      // first make sure there isn't any circular reference in the base calendar chain
      ABTValue v = newValue;
      while (!ABTValue.isNull(v))
      {
         // get base calendar
         v = ((ABTObject)v).getValue(session, OFD_BASECALENDAR, parameters);
         if ( ABTError.isError( v ) )
            return v;
         // if base calendar points back to myself, return error
         if (v.equals(parent))
            return new ABTError( "CalendarBaseCalendar",
                                 "onSet",
                                 errorMessages.ERR_CIRCULAR_REFERENCE,
                                 "Circular reference found in the base calendar chain of calendar '" + parent.getValue(session, OFD_NAME, parameters) + "'");
      }

      // things look OK. now get the calendar blob and wire the parent up.
      v = parent.getValue(session, OFD_VALUE, parameters);
      if ( ABTError.isError( v ) )
         return v;
      if ( v == null || (v instanceof ABTEmpty) )
         return new ABTError( "CalendarBaseCalendar", 
                              "onSet",
                              errorMessages.ERR_BASE_CALENDAR,
                              "Calendar value is null or empty" );

      ABTCalendar calendarVal = (ABTCalendar) v;

      if (ABTValue.isNull( newValue ))
      {
         // if the new base calendar is null, set parent to null
         calendarVal.setParent( null );
      }
      else
      {
         // if the new base calendar is not null, set calendar blob's parent
         // to the base calendar's blob
         v = ((ABTObject) newValue).getValue(session, OFD_VALUE, parameters);
         if ( ABTError.isError( v ) )
            return v;
         if ( v == null || (v instanceof ABTEmpty) )
            return new ABTError( "CalendarBaseCalendar",
                                 "onSet",
                                 errorMessages.ERR_BASE_CALENDAR,
                                 "Base calendar value is null or empty" );

         ABTCalendar baseVal = (ABTCalendar) v;
         calendarVal.setParent( baseVal );
      }

      // reset the calendar blob after wiring up the parent
      v = parent.setValue(session, OFD_VALUE, calendarVal, parameters);
      if ( ABTError.isError( v ) )
         return v;

      // write the new value
      return write( session, parent, property, myValue, newValue, false );
   }
}
