package com.abtcorp.objectModel.abt;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_ACCESS_DENIED.getCode(),"Access Denied"},
{ERR_INVALID_TYPE.getCode(),"Invalid type"},
{ERR_OPERATION_DENIED.getCode(),"Operation Denied"},
{ERR_ADD_FAILED.getCode(),"Add failed"},
{ERR_VALUE_HAS_BEEN_SET.getCode(),"Value has been previously set"},
{ERR_NULL_VALUE.getCode(),"Attempt to set to a null value"},
{ERR_INTEGRITY_ERROR.getCode(),"Integrity Error"},
{ERR_MISSING_REQ_PARM.getCode(),"Missing required parameter"},
{ERR_INVALID_PROPERTY.getCode(),"Invalid property"},
{ERR_OBJECT_ALREADY_EXISTS.getCode(),"Object already exists "},

 };
}