package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.idl.IABTActiveProgressListener;
import com.abtcorp.hub.IABTInternalActiveProgressListener;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTProgressReport;

public class ABTActiveProgressListenerLocal extends ABTProgressListenerLocal implements IABTInternalActiveProgressListener
   {
   protected IABTActiveProgressListener L_;
   public ABTActiveProgressListenerLocal(IABTActiveProgressListener L)
      { super(L); }

    /* called if there is an oportunity for synchronous user interaction */
    /* return null to stay out of it and get default behavior */
    /* or ABTValue to specify a choice */
    /* THIS CALL IS SYNCHRONOUS, THE CALLER WAITS FOR AN ANSWER */
    public synchronized ABTValue OnUserInputRequired(ABTProgressReport specifics)
       {
       specifics.setSynchronous(false);
       return L_.OnUserInputRequired((ABTProgressReport)ValueMunger.MarshalOut(this, specifics));
       }

   }

