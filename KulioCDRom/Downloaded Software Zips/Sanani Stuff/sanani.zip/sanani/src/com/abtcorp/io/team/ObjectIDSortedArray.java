package com.abtcorp.io.team;

import com.abtcorp.core.ABTSortedArray;
import com.abtcorp.core.ABTComparator;

public class ObjectIDSortedArray extends ABTSortedArray
{
   public ObjectIDSortedArray()                         {super();}
   public ObjectIDSortedArray(ABTComparator comparator) {super(comparator);}
   public ObjectIDSortedArray(ABTSortedArray array)     {super(array);}

   public synchronized int indexOf(Object object)
   {
      int index = search(object);

      if (index < size() && comparator_.compare(at(index), object) == 0) return index;

      return -1;
   }


}