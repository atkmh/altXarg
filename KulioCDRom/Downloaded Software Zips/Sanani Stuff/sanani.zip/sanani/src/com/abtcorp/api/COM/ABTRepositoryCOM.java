/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

//
//
// ABTRepositoryCOM
//
//

public class ABTRepositoryCOM implements IABTRepositoryCOM
{
   public ABTRepositoryCOM(ABTRepository r) {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(r);
      /**/
     }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   public IABTSessionCOM getSession() 
      {return new ABTSessionCOM(((ABTRepository)getObject()).getSession());}
   public int    getID()
      {return ((ABTRepository)getObject()).getID();}
   public String getName()
      {return ((ABTRepository)getObject()).getName();}
   public String sqlString(String string)
      {return ((ABTRepository)getObject()).sqlString(string);}
   public int    counter(String name)
      {return ((ABTRepository)getObject()).counter(name);}
   public int    execute(String sql)
      {return ((ABTRepository)getObject()).execute(sql);}
   public IABTCursorCOM select(String sql)
      { return new ABTCursorCOM(((ABTRepository)getObject()).select(sql)); }
}

