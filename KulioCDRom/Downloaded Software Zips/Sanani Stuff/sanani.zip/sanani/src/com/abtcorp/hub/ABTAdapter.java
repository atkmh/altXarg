
package com.abtcorp.hub;

/*
 * ABTAdapter.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
import java.util.Enumeration;
import java.util.Hashtable;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *                             
  *
  * TO DO:
  *
  * 1   protected void removeListener(IABTListener Listener, ABTObject target, int parameterindex_)
  * 2   protected void removeListeners()
  * 3   public void removeListenedTo(ABTObject target)

  */



/**
 * Controller allows managing the listener functionallity
 * Carries a list of listerns and a list of listenedTo objects
 * <p>
 * @see com.abtcorp.hub.IABTReferenceAdapter
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTAdapter implements com.abtcorp.idl.IABTListenerActions
{  
   Hashtable listeners;
   Hashtable listenedTo;
   ABTObjectSpace parent;

   /**
   *  default constructor
   */
   protected ABTAdapter(ABTObjectSpace parent_)
   {
      parent = parent_;  
      listeners = new Hashtable();
      listenedTo = new Hashtable();
   }

   /**
   * call the list of references and notify them of the proposed change
   * @param object Caller
   * @param property property which changed
   * @param originalValue - value before change
   * @param newValue - new value
   */
   protected void notifyListeners (ABTRow object, ABTProperty property, ABTValue originalValue, ABTValue newValue)
   {
        // walk through list of listeners and tell them about the change
   }

   
   /**
   * add a listener
   * @param Listener - caller
   * @param action - action the listener is interested in 
   * @param target - listen to
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   protected ABTError addListener(ABTUserSession session, IABTListener Listener, int action, ABTValue target, int parameterindex_)
   {
        if (target instanceof ABTObject) 
            return addListener(session,Listener, action, (ABTObject)target,parameterindex_);
        else
            if (target instanceof ABTObjectSet) 
                return addListener(session, Listener,action, (ABTObjectSet)target);
            else return 
                    new ABTErrorHub("ABTAdapter->addListener",errorMessages.ERR_0,target);         
   }        
  
   /**
   * add a listener to an ABTObjectSet
   * supported actions are:
   * listen to anything that can happen
   *    final static int ACT_ANYTHING = 0; 
   * add an existing object to an objectset
   *    final static int ACT_ADD = 1; 
   * add a new object to an objectset and intialize
   *    final static int ACT_ADDNEW = 2; 
   * remove an object from an objectset
   *    final static int ACT_REMOVE = 3; 
   * clear an objectset
   *    final static int ACT_CLEAR = 4; 
   *
   * @param Listener - caller
   * @param action - action the listener is interested in 
   * @param target - listened to ABTObjectSet
   */
   protected ABTError addListener(ABTUserSession session, IABTListener Listener, int action, ABTObjectSet target)
   {
      if (action < 0)
          return new ABTErrorHub("ABTAdapter->addListener",errorMessages.ERR_1,new ABTInteger(action));         
      ListenerReference lr = new ListenerReference(session,Listener);  
      //uses a dual-list to cary info
      ABTSortedArray ar = (ABTSortedArray)listeners.get(lr);
      if (ar == null)
        ar = new ABTSortedArray();
      TargetReference tr = new TargetReference(target,action,0);  
      ar.add(tr);
      listeners.put(lr,ar);
      ar = (ABTSortedArray)listenedTo.get(tr);
      if (ar == null)
        ar = new ABTSortedArray();
      ar.add(lr);
      listeners.put(tr,ar);
      return null;
   } 
   /**
   * add a listener to an ABTObject
   * supported actions are:
   * delete an ABTObject     
   *    final static int ACT_DELETE = -2; 
   * set a value in an object
   *    final static int ACT_SETVALUE = -1; 
   * listen to anything that can happen
   *    final static int ACT_ANYTHING = 0; 
   *
   * @param Listener - caller
   * @param action - action the listener is interested in 
   * @param target - listen to
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   protected ABTError addListener(ABTUserSession session, IABTListener Listener, int action, ABTObject target, int parameterindex_)
   {
      // actions supported:
      if (action > 0)
        return new ABTErrorHub("ABTAdapter->addListener",errorMessages.ERR_2,new ABTInteger(action));         
      ListenerReference lr = new ListenerReference(session,Listener);  
      //uses a dual-list to cary info
      ABTSortedArray ar = (ABTSortedArray)listeners.get(lr);
      if (ar == null)
        ar = new ABTSortedArray();
      TargetReference tr = new TargetReference(target,action,parameterindex_);  
      ar.add(tr);
      listeners.put(lr,ar);
      ar = (ABTSortedArray)listenedTo.get(tr);
      if (ar == null)
        ar = new ABTSortedArray();
      ar.add(lr);
      listeners.put(tr,ar);
      return null;
   }

   /**
   * remove a listener
   * @param Listener - caller
   * @param target - listen to
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   protected void removeListener(ABTUserSession session, IABTListener Listener, ABTObject target, int parameterindex_)
   {
// to be implemented
   }

   protected void removeListeners()
   {
// to be implemented
   }

   /**
   * remove a particular target from the listener list
   * @param target - object to be removed
   */
   public void removeListenedTo(ABTObject target)
   {
// to be implemented
   }

   class ListenerReference extends ABTValue
   {    ABTUserSession session;
        IABTListener Listener;
        
        ListenerReference(ABTUserSession session_, IABTListener Listener_)
        {
            session = session_;
            Listener = Listener_;
        }
        public boolean equals(Object object)
        {
            if (this == object) return true;
            return object != null && object instanceof ListenerReference && compareTo(object) == 0;
        }
        
        public int compareTo(Object object)
        {
            if (object == null) return 1;     
            if (!(object instanceof ListenerReference))
                return -1;
            int comp = session.compareTo(((ListenerReference)object).session);
            if (comp == 0)
            {
                return Listener.compareTo(((ListenerReference)object).Listener);
            }
            else
                return comp;
        }
        
   }
   class TargetReference extends ABTValue
   {
        ABTValue target;
        int action;
        int parameterIndex;
        
        TargetReference( ABTValue target_,int action_,int parameterIndex_)
        {
            target = target_;
            action = action_;
            parameterIndex = parameterIndex_;
        }

        public boolean equals(Object object)
        {
            if (this == object) return true;
            return object != null && object instanceof TargetReference && compareTo(object) == 0;
        }
        
        public int compareTo(Object object)
        {
            if (!(object instanceof TargetReference))
                return -1;
            if (action == ((TargetReference)object).action)
            {
                if (parameterIndex == ((TargetReference)object).parameterIndex)
                {
                    return target.compareTo(((TargetReference)object).target);
                }
                else
                    return parameterIndex < ((TargetReference)object).parameterIndex ? -1 : +1;
            }
            else
                return action < ((TargetReference)object).action ? -1 : +1;
        }
   }
 
}

