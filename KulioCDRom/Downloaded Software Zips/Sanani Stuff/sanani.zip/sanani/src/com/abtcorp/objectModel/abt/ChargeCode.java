package com.abtcorp.objectModel.abt;

/*
 * Calendar.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date          Author       Description
  * 09-18-98      SOB          Initial implementation.
  *
  */

import  com.abtcorp.objectModel.*;
import  com.abtcorp.core.*;
import  com.abtcorp.hub.*;
import  com.abtcorp.idl.*;

/**
 * ChargeCode is the object rule class that handles the ChargeCode object business rules.
 *
 *
 * @version	   $Revsion$
 * @author     S. Bursch
 */

public class ChargeCode extends SiteRule
{

  /**
   * Default Constructor
   */
   public ChargeCode()
   {
      super();
   }

      /**
    * Initializes the calendar object.
    *
    *
    * @param session             - The current user session handle
    * @param object              - The new object
    * @param requiredParameters  - List of required parameters
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTHashtable parameters )
   {
      ABTValue v;

      //
      // Check required parameters.
      //
      v = setReqParm( session, object, parameters, OFD_SITE, OFD_CHARGECODES, "abt.ChargeCode->onInitialize" );
      if ( v instanceof ABTErrorRules )
         return v;

      //
      // Set the external id to a default value
      //
      v = object.setValue( session, OFD_EXTERNALID, new ABTString( object.getID().getUniqueId() ), parameters );
      if( ABTError.isError( v ) )
         return v;

      return null;
   }

  /**
   * Sets default properties for the site object.
   */
   protected void setDefaultProperties()
   {
      //
      // Relationship Properties
      //
      addProperty( OFD_SITE, OFD_SITE_CAP, PROP_OBJECT, false, true, true, false, OBJ_SITE, null, null );


      //
      // Field Properties
      //
      addProperty( OFD_ISOPEN, OFD_ISOPEN_CAP, PROP_BOOLEAN, false, true, true, false, null, null, null );
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );


      ABTProperty prop;

      addProperty( OFD_EXTERNALID, OFD_EXTERNALID_CAP, PROP_STRING, false, true, true, false, null, FR_UNIQUEINOBJECTSPACE, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(16));
      makeIndex(prop);

      addProperty( OFD_NAME, OFD_NAME_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(32));

  }

   /**
    * Add a new object to an object set by calling the SiteRule method
    *    <code>addToSet(String type, ABTUserSession,ABTValue,boolean)</code>.
    *
    * @param session    - The session object for transaction support
    * @param parent     - The <code>ABTObjectSet</code> that the new element is being added to.
    * @param newValue   - The new <code>ABTObject</code> being added to the list
    * @param existing   - true if <code>newValue</code> has been created by the caller
    *                     , false if it has been initialized with default values
    *
    * @return ABTValue  - ABTValue if successful, ABTError if not
    */
   protected ABTValue onAdd( ABTUserSession session, ABTObjectSet parent, ABTValue newValue, boolean existing )
   {
      return parent.addToSet( session, newValue, existing );
   }

  /**
   * Deletes a chargecode object.
   * @param parent - the object to be removed
   * @return ABTValue - check for ABTError....
   */
   protected ABTValue onDelete(ABTUserSession session, ABTObject parent)
   {
      //
      // For the time being, prohibit deletion of charge code objects.
      //
      return new ABTError( "ChargeCode",
                           "onDelete",
                           errorMessages.ERR_ACCESS_DENIED,
                           "Cannot delete ChargeCode objects" );
   }

}
