package com.abtcorp.io.client.mppfile;
import com.abtcorp.core.ABTRemoteID;

public class ABTClientMppDependencyRemoteID extends ABTRemoteID
{
	private String fileName_;
	private int successorUniqueID_;
	private int	predecessorUniqueID_;

	public ABTClientMppDependencyRemoteID()
	{
		fileName_             = null;
		successorUniqueID_    = 0;
		predecessorUniqueID_  = 0;
	}

	public ABTClientMppDependencyRemoteID ( String  fileName,
                                          int     successorUniqueID ,
                                          int     predecessorUniqueID
                                         )
	{
		fileName_             = fileName;
		successorUniqueID_    = successorUniqueID;
		predecessorUniqueID_  = predecessorUniqueID;
	}

	public String getFileName() { return fileName_; }

	public void setFileName( String fileName ) { fileName_ = fileName;}

	public int getSuccessorUniqueID() { return successorUniqueID_; }

	public void setSuccessorUniqueID( int uniqueID ) { successorUniqueID_ = uniqueID; }

	public int getPredecessorUniqueID() { return predecessorUniqueID_; }

	public void setPredecessorUniqueID( int predecessorUniqueID ) {predecessorUniqueID_ = predecessorUniqueID; }

	public int compareTo( Object object )
	{
		if (!( object instanceof ABTClientMppDependencyRemoteID ))
			return -1;

		String fileName   = ((ABTClientMppDependencyRemoteID) object).getFileName();
		int successorUniqueID   = ((ABTClientMppDependencyRemoteID) object).getSuccessorUniqueID();
		int predecessorUniqueID = ((ABTClientMppDependencyRemoteID) object).getPredecessorUniqueID();

		if ( fileName_.equals(fileName )&&
         successorUniqueID_   == successorUniqueID&&
         predecessorUniqueID_ == predecessorUniqueID
       ) return 0;

		if ( fileName_.compareTo(fileName) < 0 )
			return -1;
		else if ( fileName_.compareTo(fileName) > 0 )
			return +1;

		if (successorUniqueID < successorUniqueID_) return -1;
		else if (successorUniqueID > successorUniqueID_)
      return +1;

		return predecessorUniqueID  < predecessorUniqueID_  ? -1 : +1;
	}

	/**
	*  - required routine to allow storing in sorted sets
	*    @param object - to compare against
	*    @return boolean true for equal
	*/
	public boolean equals ( Object object )
	{
		return compareTo( object ) == 0 ? true : false;
	}

	/**
	*    required routine to allow unique access in sets
	*    @return int - hashcode
	*/

	public int hashCode()
	{
		return successorUniqueID_^ predecessorUniqueID_;
	}

}