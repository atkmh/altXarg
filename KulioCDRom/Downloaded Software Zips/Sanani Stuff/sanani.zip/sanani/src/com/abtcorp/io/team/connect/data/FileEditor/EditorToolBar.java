package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.component.util.*;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.JToolBar;
import javax.swing.JButton;

public class EditorToolBar extends JToolBar
{
    private static String ICON_DIR = "/com/abtcorp/io/team/connect/data/FileEditor/icons/";
    private static int BUTTON_HEIGHT = 60;
    private static int BUTTON_WIDTH = 120;
    private JButton openButton;
    private JButton exitButton;
    private JButton expandButton;
    private JButton helpButton;
    private JButton searchButton;


    public EditorToolBar(Frame ancilate)
    {
        super();

        openButton = new JButton(ABTIconFactory.getIconFactory().getIcon(ICON_DIR + "open.gif"));
	    this.add(openButton);
	    openButton.setToolTipText("Open Table");
	    openButton.setMargin(new Insets(2,2,2,2));
	    openButton.addActionListener((ActionListener)ancilate);
	    openButton.setActionCommand("Open");
        
        helpButton = new JButton(ABTIconFactory.getIconFactory().getIcon(ICON_DIR + "help.gif"));
        this.add(helpButton);
        helpButton.setToolTipText("Help");
        helpButton.setMargin(new Insets(2,2,2,2));
        helpButton.addActionListener((ActionListener)ancilate);
        helpButton.setActionCommand("Usage");
        
        searchButton = new JButton(ABTIconFactory.getIconFactory().getIcon(ICON_DIR + "search.gif"));
        this.add(searchButton);
        searchButton.setToolTipText("Serach for Key");
        searchButton.setMargin(new Insets(2,2,2,2));
        searchButton.addActionListener((ActionListener)ancilate);
        searchButton.setActionCommand("Find");
       
	    expandButton = new JButton(ABTIconFactory.getIconFactory().getIcon(ICON_DIR + "expand.gif"));
	    this.add(expandButton);
	    expandButton.setToolTipText("Jump Into");
	    expandButton.setMargin(new Insets(2,2,2,2));
         expandButton.addActionListener((ActionListener)ancilate);
    	    expandButton.setActionCommand("Expand");
    	    expandButton.setEnabled(false);
    	    
    	    this.addSeparator();
    	    exitButton = new JButton(ABTIconFactory.getIconFactory().getIcon(ICON_DIR + "exit.gif"));
        this.add(exitButton);
        exitButton.setToolTipText("Exit File Viewer");
        exitButton.setMargin(new Insets(2,2,2,2));
        exitButton.addActionListener((ActionListener)ancilate);
        exitButton.setActionCommand("Exit");
    }

    public void setExpandButton(boolean enabled) { expandButton.setEnabled(enabled); }



}