package com.abtcorp.repository;

public class ABTNative
{
   static {System.loadLibrary("prjava");}

   protected int     handle_;
   protected boolean finalized_ = false;

   protected ABTNative(int handle) {handle_ = handle;}

   protected void finalize() {if (! finalized_) release(true);}

   public void release() {release(true);}

   public native void addref();
   public native void release(boolean finalize);
   public native int  refcnt();

   public native boolean checkRight(String name);
}