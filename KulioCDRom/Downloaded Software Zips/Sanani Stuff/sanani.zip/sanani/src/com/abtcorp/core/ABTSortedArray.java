/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTSortedArray.java, 13, 12/8/98 9:43:46 AM, Benoit Menendez$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import java.io.Serializable;
import com.objectspace.jgl.ForwardIterator;

public class ABTSortedArray extends ABTArray implements Serializable
{
   // NOTE: The JGL package does not allow us access the Object array
   //       directly, we may decide to use the JDK 1.2 collection once
   //       they make available the JDK 1.1 compatibility. This should
   //       speed up a lot.
   // NOTE: We should be using the alogorithms for binary search and
   //       sort, but unfortunately they do not work with our int
   //       comparators.

   private static final long serialVersionUID = 2456208468899165189L;
   protected ABTComparator comparator_;

   public ABTSortedArray()                         {this(new ABTDefaultComparator());}
   public ABTSortedArray(ABTComparator comparator) {comparator_ = comparator;}
   public ABTSortedArray(ABTSortedArray array)     {super(array); comparator_ = array.comparator_;}

   protected final int search(Object object)
   {
	   int lower = 0;
	   int upper = size();

      if (upper <= lower) return lower;

      if (comparator_.compare(at(upper-1), object) < 0) return upper;
      if (comparator_.compare(at(lower),   object) > 0) return lower;

	   while (lower < upper) {
		   int index = (lower + upper) >> 1;

		   if (comparator_.compare(at(index), object) < 0) lower = index + 1;
		   else                                            upper = index;
	   }

	   return lower;
   }

   public synchronized int indexOf(Object object)
   {
      int index = search(object);

      while (index < size() && comparator_.compare(at(index), object) == 0)
      {
         if (at(index).equals(object)) return index;
         index++;
      }

      return -1;
   }

   public synchronized Object add(Object object)
   {
      int index = search(object);

      insert(index, object);

      return null;
   }

   private final void swap(int left, int right)
   {
      Object tmp = at(left);

      put(left, at(right));

      put(right, tmp);
   }


   public synchronized int remove(Object object)
   {
      int index = indexOf(object);
      if (index >= 0)
      {
          if (remove(index) != null)
            return 1;
          else
            return 0;
      }
      else return 0;
   }


   private final void sort(int lo, int hi)
   {
      if (hi < lo + 1) return;

      if (hi < lo + 8) {
         while (hi > lo) {
            int max = lo;

            for (int p = lo + 1; p <= hi; p++)
               if (comparator_.compare(at(p), at(max)) > 0) max = p;

            swap(max, hi--);
         }
      } else {
         int mid = (lo + hi) >> 1;

         swap(mid, lo);

         int loguy = lo, higuy = hi + 1;

         while (true) {
            do loguy++; while (loguy <= hi && comparator_.compare(at(loguy), at(lo)) <= 0);
            do higuy--; while (higuy >  lo && comparator_.compare(at(higuy), at(lo)) >= 0);

            if (higuy < loguy) break;

            swap(loguy, higuy);
         }

         swap(lo, higuy);

         if (higuy - lo > hi - loguy) {
            if (hi > loguy)      sort(loguy, hi);
            if (higuy > lo + 1)  sort(lo, higuy - 1);
         } else {
            if (higuy > lo + 1)  sort(lo, higuy - 1);
            if (hi > loguy)      sort(loguy, hi);
         }
      }
   }

   public final synchronized void sort()
   {
      if (size() < 2) return;

      sort(0, size() - 1);
   }

   public final synchronized void sort(ABTComparator comparator)
   {
      comparator_ = comparator;

      sort();
   }


   public synchronized void merge(ABTSortedArray array)
   {
     if (array.size() == 0)
        return ;
     ForwardIterator start = array.start();
     ForwardIterator finish = array.finish();

     if ((size() == 0) || (((ABTComparable)back()).compareTo(array.front())== -1))
     {
        insert( size(),start, finish );
        return;
     }
     else
        if (((ABTComparable)front()).compareTo(array.back())== 1)
            insert( 0,start, finish );
        else
        //merge
        {
            try
            {
                while (true)
                {
                    add(start.get());
                    start.advance();
                }
            }
            catch (Exception e)
            {
                // done
            }
        }
   }

   public synchronized int remove(ABTSortedArray array)
   {
     if (array.size() == 0)
        return 0;
     ForwardIterator start = array.start();
     ForwardIterator finish = array.finish();

     if ((size() == 0) || (((ABTComparable)back()).compareTo(array.front())== -1))
     {
        return 0;
     }
     else
        if (((ABTComparable)front()).compareTo(array.back())== 1)
            return 0;
        else
        //remove
        {
            int i = 0;
            try
            {
                while (true)
                {
                    i = i + remove(start.get());
                    start.advance();
                }
            }
            catch (Exception e)
            {
                // done
            }
            return i;
        }
    }


}