package com.abtcorp.io;

import java.util.Hashtable;
import java.util.Vector;

import com.abtcorp.repository.*;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTInteger;

public class ABTRepoDataDictionary implements ABTNames, ABTEnum
{
   /**
    * repoDataDictionary_ is a Java Hashtable whose entries are keyed by the String representation
    * of an ABT Data Repository table name.  The entries themselves are Java Vectors of
    * ABTRepoDataDictionary objects.  Each Vector contains a complete specification of an
    * ABT Data Repository table.
    */

   private static Hashtable repoDataDictionary_ = null;   // temporary until it finds a proper home
   private static boolean valid_ = false;                 // temporary until it finds a proper home

   private static final int REPO_PREFIX_LEN = 2;         // all repository field names have a 2-character prefix, usually "pr" or "mr"
   private static final String PR_PREFIX = "pr".intern();

   //
   // PM_PREFIX defines the "project management" prefix for all
   // project management object property names.
   //
   private static final String PM_PREFIX = "pm".intern();

   // prefix for all methodology management names
   private static final String MR_PREFIX = "mr".intern();  // table name
   private static final String MM_PREFIX = "mm".intern();  // property name

	// prefix for global/site property names
   private static final String ABT_PREFIX = "abt".intern();

   //
   // The following constants are from PRAPI.H.
   //

   private static final int PR_STRING      = 1;
   private static final int PR_SHORT       = 5;
   private static final int PR_LONG        = 4;
   private static final int PR_DOUBLE      = 8;
   private static final int PR_TIMESTAMP   = 11;
   private static final int PR_BINARY      = -2;

   private String prCaption_;
   private long   prID_;
   private long   prLength_;
   private String prEnumCaption_;
   private String prName_;
   private String prEnumName_;
   private short  prExtType_;
   private short  prType_;
   private long   prFlags_;

   //
   // The following variable holds the converted string found in prName_.  This will be the
   // name of the corresponding property in the Sanani object space.  For example, if
   // prName contains the string "prExternalID", then convertedName_ contains a string
   // with the letters "pr" in the prefix converted to something else, e.g., "pmExternalID".
   //
   private String propertyName_;

   //
   // The following variable holds the converted data type found in prType_. The value will
   // conform to those types allowed for properties of objects in the object space.
   //
   private ABTInteger propertyDataType_;

   public ABTRepoDataDictionary() {}

   //
   // Define getter methods.
   //

   public String getCaption() {return prCaption_;}
   public long getID() {return prID_;}
   public long getLength() {return prLength_;}
   public String getEnumCaption() {return prEnumCaption_;}
   public String getName() {return prName_;}
   public String getEnumName() {return prEnumName_;}
   public short getExtType() {return prExtType_;}
   public short getType() {return prType_;}
   public long getFlags() {return prFlags_;}
   public String getPropertyName() {return propertyName_;}
   public ABTInteger getPropertyDataType() {return propertyDataType_;}

   public Hashtable getDataDictionary() {return repoDataDictionary_;}

   //
   // Define setter methods.
   //

   public void setCaption(String caption) {prCaption_ = caption;}
   public void setID(long id) {prID_ = id;}
   public void setLength(long length) {prLength_ = length;}
   public void setEnumCaption(String ecaption) {prEnumCaption_ = ecaption;}
   public void setName(String name) {prName_ = name;}
   public void setEnumName(String ename) {prEnumName_ = ename;}
   public void setExtType(short etype) {prExtType_ = etype;}
   public void setType(short type) {prType_ = type;}
   public void setFlags(long flags) {prFlags_ = flags;}
   public void setPropertyName(String pname) {propertyName_ = pname;}
   public void setPropertyDataType(ABTInteger type) {propertyDataType_ = type;}

   //
   // Misc. methods.
   //

   public boolean isValid() {return valid_;}

   public synchronized void createRepoDataDictionary(ABTSession sess)
   {
		if (isValid()) return;
		if (sess == null) return;

		//
		// Get a handle to the ABT system repository.
		//

		ABTRepository systemRepository = sess.getSystem();

		//
		// Select all of the columns from the prField table in the system repository.
		// The PRField table is the data dictionary for the ABT repository.
		//

   	ABTCursor cursor = systemRepository.select("select * from PRField order by prTableName, prName");

   	//
   	// Position to the first tuple in the result set.  If we can't get there,
   	// close down and return.
   	//

   	if (!cursor.moveNext())
   	{
   	   cursor.release();
   	   systemRepository.release();
   	   return;
   	}

   	repoDataDictionary_ = new Hashtable();

   	//
   	// Initialize the current table name and the previous table name variables.  The
   	// table name, which will be the Hashtable key object, is converted to lower case
   	// so that a subsequent query into the Hashtable can be case insensitive.
   	//
   	String currentTblName = cursor.getFieldString(FLD_TABLENAME).toLowerCase();
   	String previousTblName = currentTblName;
   	Vector rddVector = null;

      while (true)
      {
         //
         // If the table name field from the current tuple in the result set is
         // equal to the table name field from the previous tuple, build a Vector
         // of the tuple's values and add that Vector object to the hash table.
         //
         if (currentTblName.equals(previousTblName))
         {
            //
            // Populate data dictionary object.
            //
            ABTRepoDataDictionary rdd = setDictionaryValues(cursor, currentTblName);

            //
            // If a vector has not been created for the current table, create one now.
            //

            if (rddVector == null)
               rddVector = new Vector();

            //
            // Add the current ABTRepoDataDictionary object to the rddVector.
            //

            rddVector.addElement(rdd);

            //
            // Get the next result set tuple.  If no more tuples, cause the
            // current vector to be added to the data dictionary hashtable.
            //

            if (cursor.moveNext())
               currentTblName = cursor.getFieldString(FLD_TABLENAME).toLowerCase();
            else
            {
               //
               // Add current vector object to data dictionary hash table and exit.
               //

               repoDataDictionary_.put(currentTblName, rddVector);
               break;               // break out of while (true) loop
            }                       // end if (cursor.moveNext())

         }
         else
         {
            //
            // The table names have changed.  Add the current vector to the
            // data dictionary hashtable using the previous table name as the
            // key.
            //
               repoDataDictionary_.put(previousTblName, rddVector);

            //
            // Set the previous table name equal to the current table name and
            // continue the loop through the prField table result set.  Set the
            // vector variable to null so that a new vector will be created for
            // the next table.
            //

            previousTblName = currentTblName;
            rddVector = null;
         }                             // end if (currentTblName.equals(previousTblName))
      }                                // end while (true)

		if (cursor != null)
		   cursor.release();

      if (systemRepository	!= null)
         systemRepository.release();

      valid_ = true;       // set dictionary as valid
   }

   private ABTRepoDataDictionary setDictionaryValues(ABTCursor cursor, String tblName)
   {
      ABTRepoDataDictionary rdd = new ABTRepoDataDictionary();

      //
      // Set all of the fields which cannot be null in the source.
      //
      // Note that FLD_NAME value is stored in the dictionary as a case-sensitive
      // string object; it is not converted to all uppercase, nor all lowercase.
      //

      rdd.setID(cursor.getFieldInt(FLD_ID));
      rdd.setName((cursor.getFieldString(FLD_NAME)));
      rdd.setType(cursor.getFieldShort(FLD_TYPE));
      rdd.setFlags(cursor.getFieldInt(FLD_FLAGS));
      rdd.setExtType(cursor.getFieldShort(FLD_EXTTYPE));

      //
      // Set the fields which can be null in the source.
      //

      rdd.setCaption(cursor.isFieldNull(FLD_CAPTION)? null : cursor.getFieldString(FLD_CAPTION));
      rdd.setLength(cursor.isFieldNull(FLD_LENGTH)? 0 : cursor.getFieldInt(FLD_LENGTH));
      rdd.setEnumCaption(cursor.isFieldNull(FLD_ENUMCAPTION)? null: cursor.getFieldString(FLD_ENUMCAPTION));
      rdd.setEnumName(cursor.isFieldNull(FLD_ENUMNAME)? null: cursor.getFieldString(FLD_ENUMNAME));

      //
      // Set the converted name.
      //
      String name = makePropertyName( rdd.getName() );
      rdd.setPropertyName(name);

      //
      // Convert the column's data type to a property data type known by objects in the
      // object space.
      //
      rdd.setPropertyDataType(makePropertyType(rdd.getType(), rdd.getExtType()));

      return rdd;
   }

   private ABTInteger  makePropertyType(short prapiType, short prapiExtType)
   {
      //
      // Make an object space property type based on an input PRAPI data type.
      //
      ABTInteger pType;
      switch (prapiType)
      {
         case PR_STRING:
            pType = new ABTInteger(ABTProperty.PROP_STRING);
            break;

         case PR_SHORT:
            pType = (prapiExtType == PR_EXTTYPE_BOOLEAN ? new ABTInteger(ABTProperty.PROP_BOOLEAN) :
                                                  new ABTInteger(ABTProperty.PROP_SHORT) );
            break;

         case PR_LONG:
            pType = new ABTInteger(ABTProperty.PROP_LONG);
            break;

         case PR_DOUBLE:
            pType = new ABTInteger(ABTProperty.PROP_DOUBLE);
            break;

         case PR_TIMESTAMP:
            pType = new ABTInteger(ABTProperty.PROP_TIMESTAMP);
            break;

         case PR_BINARY:
            pType = new ABTInteger(ABTProperty.PROP_BLOB);
            break;

         default:
            pType = new ABTInteger(ABTProperty.PROP_UNKNOWN);
      }                 // end switch (prapiType)

      return pType;
   }

   private String makePropertyName(String colName)
   {
      //
      // Return a substring of the repository column (field) name.  The index is
      // zero-based and is inclusive.  So, if REPO_PREFIX_LEN is 2, a new string
      // will be created and returned such that the first character of that new
      // string will be the 3rd character of the input column name.  For example,
      // if colName = "prName", then the string "Name" will be returned.
      //
      return colName.substring(REPO_PREFIX_LEN);
   }
   
   private String makePropertyName(String colName, String tblName)
   {
      // DEFUNCT DEFUNCT DEFUNCT
      //
      // Convert an input PRAPI database column name to a property name that conforms to the
      // object space property naming conventions.
      // If the input table name starts with "pr" and the column name starts "pr", then return
      // a new column name that starts with the preferred project management prefix ("pm").
      // If the input table name starts with "mr" and the column name starts "pr", then return
      // a new column name that starts with the preferred methodology management prefix ("mm").
      // Otherwise, just return the input name itself.
      //
      if ((tblName.equalsIgnoreCase("prsite") || tblName.equalsIgnoreCase("prfield")) && colName.startsWith(PR_PREFIX))
         return (ABT_PREFIX + colName.substring(PR_PREFIX.length(), colName.length()));
      else if (tblName.startsWith(PR_PREFIX) && colName.startsWith(PR_PREFIX))
         return (PM_PREFIX + colName.substring(PR_PREFIX.length(), colName.length()));
      else if (tblName.startsWith(MR_PREFIX) && colName.startsWith(PR_PREFIX))
         return (MM_PREFIX + colName.substring(PR_PREFIX.length(), colName.length()));
      else
         return (colName);
   }

   public Vector getPropertiesFromDataModel(String prTableName)
   {
      //
      // Right now, we only get the data model from the repository.  In the future, we
      // should also check for the presence of a data model from a file on the local
      // file system.
      //

		if (!isValid()) return null;
		if (prTableName == null) return null;

      //
      // Get the data dictionary vector indicated by the caller. Convert the table name,
      // which is the key to the Hashtable, to lower case before asking the dictionary for
      // the Vector object of properties.  This conversion will allow a case-insensitive
      // search.
      //

      return (Vector) repoDataDictionary_.get(prTableName.toLowerCase());
   }                       // end setPropertiesFromDataModel()

}