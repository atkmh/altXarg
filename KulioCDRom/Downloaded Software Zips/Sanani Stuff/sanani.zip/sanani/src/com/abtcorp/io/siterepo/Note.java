package com.abtcorp.io.siterepo;

/*
 * Note.java 08/11/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-11-98    LZX         Initial Implementation
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  Note is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTSiteRepoDriver object.
 *
 *  <pre>
 *       Note rt = new Note(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTSiteRepoDriver
 */

public class Note extends ABTSiteRepoHelper
{
//   private long recID_ = 0;
   private ABTObjectSet notes_ = null;

/**
 *    Note constructor.
 *    @param   driver: the reference to the driver.
 */
   Note(ABTRepositoryDriver driver, ABTObject parent) throws ABTException
   {
      super(driver, parent, TBL_NOTE, OBJ_NOTE);
      
      matchField_ = null;

      // retrieve parent's note collection reference so we can add to it later
      // (the rule does not take care of that since note object is free floating)
      ABTValue val = getValue(parent, OFD_NOTES);
      if (val instanceof ABTObjectSet)
         notes_ = (ABTObjectSet) val;
   }


/**
 *  Set property values.
 *  @param       ps: the property hash.
 *  @param       cur: the cursor.
 *  @param       obj: the object.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps, ABTCursor cur, ABTObject object) throws ABTException
   {
      // first set property values from the note cursor
      setPropertyValues(ps, cur, object);
      
      // add this note object to the parent's note collection
      if (notes_ != null)
         add(notes_, object);      
   }

}