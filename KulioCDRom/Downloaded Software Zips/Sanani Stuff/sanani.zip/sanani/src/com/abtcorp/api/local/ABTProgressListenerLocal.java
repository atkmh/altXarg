package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.idl.IABTProgressListener;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.hub.IABTInternalProgressListener;
import com.abtcorp.core.ABTProgressReport;


public class ABTProgressListenerLocal extends ABTSessionObject implements IABTInternalProgressListener
   {
      protected boolean Continue;

      class AsyncStatusCall implements Runnable {
         private IABTProgressListener myListener;
         private ABTProgressReport myStatus;
        	AsyncStatusCall(IABTProgressListener listener, ABTProgressReport specifics) {
            myListener = listener;
            myStatus = (ABTProgressReport)ValueMunger.MarshalOut(null, specifics);
        	   }

        	public void run() {
            Continue = myListener.OnStatus(myStatus);
          	}
       }


   protected IABTProgressListener L_;
   public ABTProgressListenerLocal(IABTProgressListener L) {
      super((ABTSessionObject)null,L);
      Continue = true;
      L_ = L;
      }

    /* called to report ongoing status */
    /* return false to request that the operation be aborted (if possible)*/
    /* THIS CALL IS ASYNCHRONOUS, THE CALLER DOES NOT WAIT        */
    /* Any requested abort will only be noticed when or if        */
    /* the calling process gets around to looking for it, and if  */
    /* it still makes sense at that time.  A driver populate call */
    /* is a good example.                                         */
    /* If the receiver gets a call with unrecognized specifics,   */
    /* return true to shrug it off and continue.                  */
    public synchronized boolean OnStatus( ABTProgressReport specifics)
       {
       specifics.setSynchronous(false);
       specifics.setInfo( ValueMunger.MarshalOut(this, specifics.getInfo()) );
       AsyncStatusCall  asc = new AsyncStatusCall(L_,specifics);
       new Thread(asc).start();
       return Continue; // that's the return value from the previous OnStatus call!!!
       }
   }

