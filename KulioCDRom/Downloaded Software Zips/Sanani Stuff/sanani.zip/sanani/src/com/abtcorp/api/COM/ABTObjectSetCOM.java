/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.idl.*;

import com.abtcorp.core.*;

import com.ms.com.IEnumVariant;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class ABTObjectSetCOM implements IABTObjectSetCOM
{
  public ABTObjectSetCOM(IABTObjectSet obj)
     {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(obj);
      /**/
     }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.toString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   private IABTObjectSet _OSet;
   private IABTObjectSet OSet() {
      if (_OSet == null) _OSet = (IABTObjectSet)getObject();
      return _OSet;
      }
 
   public IABTObjectSpaceCOM getObjectSpace(){
      IABTObjectSpace os = OSet().getObjectSpace();
      IABTObjectSpaceCOM retVal = new ABTObjectSpaceCOM(os);
      return retVal;
      }

   public IUnknown get_NewEnum()
      { return new ObjectEnumerator( OSet(),false,null); }
   public IABTEnumeratorCOM getElements()
      { return new ObjectEnumerator(OSet(),false,null); }
   public IABTEnumeratorCOM getSortedElements(IABTSortOrderDefinitionCOM def)
      { return new ObjectEnumerator(OSet(),true, def ); }

   public IABTArrayCOM getDeletedData() {
      IABTArray ar = OSet().getDeletedData();
      if (ar == null) return null;
      return new ABTArrayCOM(ar);
      }


  public int getCount()  { return size(); }
  public int size()  { return OSet().size(); }

  public Variant getItem(int index) {  return at(index); }
  public Variant at(int index) { return VariantMunger.ValueToVariant(OSet().at(index)); }

  public Variant getBack()
      { return VariantMunger.ValueToVariant(OSet().getBack()); }

  public Variant getFront()
      { return VariantMunger.ValueToVariant(OSet().getFront()); }

  public void clear()
      { OSet().clear(); }


  public IABTSortOrderDefinitionCOM getSortOrder()
     {
     return new SortOrder(OSet().getSortOrder());
     }

  /**
   * Remove the element at a particular index.
   * @param index The index of the element to remove.
   * @return The object removed.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
   public Variant removeAt( int index )
      { return VariantMunger.ValueToVariant(OSet().removeAt(index)); }

  /**
   * Remove the element pointed to by object and return the removed object
   * @param object The object to remove.
   * @return ABTObject removed or ABTError
   */
   public Variant remove( IABTObjectCOM object )
      { return VariantMunger.ValueToVariant(OSet().remove((IABTObject)(object.getObject()))); }

  /**
   * Add an object after my last element or in sorted order.  
   * @param object The object to add.
   * @return added object or ABTError
   */
   public Variant add( IABTObjectCOM object )
      { return VariantMunger.ValueToVariant(
            OSet().add((IABTObject)(object.getObject()))
            );
      }


  /**
   * Add a new object 
   * @return added object or ABTError
   */
   public Variant addNew()
      { return VariantMunger.ValueToVariant(OSet().addNew()); }

  
   /**
   * check whether a given index is valid
   * @param index to be checked
   * @return boolean true for valid, false otherwise
   */
   public boolean checkIndex(int index)
      { return OSet().checkIndex(index); }

   
   /**
   * Return true if I contain a particular object.
   * @param object The object in question.
   */
   public boolean contains( IABTObjectCOM object )
      { return OSet().contains((IABTObject)object.getObject()); }

   
   /**
   *  return the set of properties for this class
    */
   public IABTPropertySetCOM getProperties()
      { return new ABTPropertySetCOM(OSet().getProperties()); }


   public boolean isEmpty()
      { return OSet().isEmpty(); }


   /**
   * Return an objectset containing all elements 
   * where the provided criteria computes to true
   * @param criteria String with SQL-like sysntax
   * @return newly created Objectset with same rule set or ABTError
   */
   public Variant select( String criteria)
      { return VariantMunger.ValueToVariant(OSet().select(criteria)); }

   public String getObjectType()
   {
      return OSet().getObjectType();
   }

   public Variant setValues(IABTHashTableCOM pairs) {
      IABTHashTable ht = (IABTHashTable)((ABTHashTableCOM)pairs).getObject();
      ABTValue v = OSet().setValues(ht);
      return VariantMunger.ValueToVariant(v);
      }


private class SortOrder implements IABTSortOrderDefinitionCOM
   {
   private IABTSortOrderDefinition _sod;
   public SortOrder(IABTSortOrderDefinition sod)
      {_sod = sod; }

   public IABTSortOrderDefinition getSortOrder()
      { return _sod; }

   public void addSort(String byWhat, boolean ascending)
      { _sod.add(byWhat,ascending); }
   }
private class ObjectEnumerator implements IEnumVariant,IABTEnumeratorCOM
     {
      IABTEnumerator _en;
      IABTObjectSet _os;
      IABTSortOrderDefinitionCOM _sortby;
      boolean _sorted;

      public ObjectEnumerator(IABTObjectSet os, boolean bSort, IABTSortOrderDefinitionCOM sortby)
         {
         _os = os;
         _sorted = bSort;
         _sortby = sortby;
         if (_sorted)
            _en = _os.getSortedElements(((SortOrder)_sortby).getSortOrder());
         else
            _en = _os.getElements();
         }

      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }
      public Variant nextElement()
         { return VariantMunger.ValueToVariant((ABTValue)_en.nextElement());  }

      public void Skip(int n) {
         while (n-- > 0 && _en.hasMoreElements()) {
            _en.nextElement(); }
         }
      public void Reset()
         {
         if (_sorted)
            _en = _os.getSortedElements(((SortOrder)_sortby).getSortOrder());
         else
            _en = _os.getElements();
         }
      public IEnumVariant Clone()
         { return new ObjectEnumerator( _os,_sorted,_sortby); }

      public void Next(int n, Variant[]v, int[]pfetched) {
         pfetched[0] = 0;
         try {
            while (n-- > 0 && _en.hasMoreElements()){
               v[(pfetched[0])++] = VariantMunger.ValueToVariant((ABTValue)_en.nextElement());
               }
            }
         catch (Exception e){throw new com.ms.com.ComFailException(e.getMessage()); }
         }
     }

}
