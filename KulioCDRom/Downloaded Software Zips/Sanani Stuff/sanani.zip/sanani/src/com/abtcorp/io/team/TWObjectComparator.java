package com.abtcorp.io.team;

import com.abtcorp.core.*;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.objectModel.team.TWRule;
import com.abtcorp.objectModel.team.IABTTWRuleConstants;

public class TWObjectComparator implements ABTComparator, IABTTWRuleConstants
{

   ABTUserSession session_;

	public TWObjectComparator(ABTUserSession session)
	{
		super();
		session_ = session;
	}
   
  
	
	/**
   * Return -1 for smaller, 0 for equal or 1 for greater
   * @param object The object to compare myself against.
   */
   public int compare(Object object1, Object object2)
   {
      
/*   	if ((object1 instanceof ABTObject) && (object2 instanceof ABTObject)) {
   		int value1 = ( (ABTObject) object1).getValue(session_,FLD_TW_ID,null).intValue();
   		int value2 = ( (ABTObject) object2).getValue(session_,FLD_TW_ID,null).intValue();
   		
   		if (value1 < value2) return -1;
   		if (value1 == value2) return 0;
   		if (value1 > value2) return -1;
   	}*/
   	
      if (object1 == null && object2 == null) return 0;
      if (object1 == null)                    return -1;
      if (object2 == null)                    return +1;

  		int value1 = 0;
   	int value2 = 0;

   	if (object1 instanceof ABTObject) {
   		value1 = ((ABTObject)object1).getValue(session_,FLD_TW_ID,null).intValue();
   	} else if (object1 instanceof ABTValue) {
   		value1 = ((ABTValue)object1).intValue();
   	} else if (object1 instanceof Integer) {
   		value1 = ((Integer)object1).intValue();
   	} else System.out.println("don't know what object1 is");

   	if (object2 instanceof ABTObject) {
   		value2 = ((ABTObject)object2).getValue(session_,FLD_TW_ID,null).intValue();
   	} else if (object2 instanceof ABTValue) {
   		value2 = ((ABTValue)object2).intValue();
   	} else if (object2 instanceof Integer) {
   		value2 = ((Integer)object2).intValue();
   	} else System.out.println("don't know what object2 is");

  		if (value1 < value2) return -1;
  		if (value1 > value2) return  1;
   		
		return  0;
   }

}