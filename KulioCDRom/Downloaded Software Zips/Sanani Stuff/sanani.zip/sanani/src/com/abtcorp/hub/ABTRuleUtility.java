
package com.abtcorp.hub;

/*
 * ABTRule.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import  java.net.URL;
import com.abtcorp.core.*;
import java.util.Enumeration;
import com.abtcorp.idl.IABTPropertyType;
/**
 * ABTRule is the base class allowing common handling of all business rules
 * See "public getter/setters/validation routines to be overwritten by derived rule implementations"
 * for functions to be overwritten by rule implementations
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */

public class ABTRuleUtility implements com.abtcorp.idl.IABTPropertyType,Serializable,Cloneable
{
    //==========================================================================================
// internal service routines
//==========================================================================================
    ABTBoolean hasChanged = ABTBoolean.True();

//getRuleSet

/**
* get the property object for a given property in an object
* @param session current session handle
* @param object reference to ABTObject
* @param property - the property
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTProperty getProperty(ABTUserSession session,ABTObject object,int index)
{
 	return object.getProperty(session, index);
}

/**
* get the property object for a given property in an object
* @param session current session handle
* @param object reference to ABTObject
* @param property - the property
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTProperty getProperty(ABTUserSession session,ABTObject object,String name)
{
 	return object.getProperty(session,name);
}

/**
* write is the final writing to the object in question including notification
* @param object reference to ABTObject
* @param property - the property
* @param value new value
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue write(ABTUserSession session,ABTObject object,ABTProperty property,ABTValue oldValue,ABTValue newValue,boolean dirty)
{
 	object.setRowValue(session, object.getRule().getChangedProperty(),null,hasChanged,true);
 	return object.setRowValue(session, property,oldValue,newValue,dirty);
}


/**
* write is the final writing to the object in question including notification
* @param object reference to ABTObject
* @param property - the property
* @param value new value
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue write(ABTUserSession session,ABTObject object,ABTProperty property,ABTValue oldValue,ABTValue newValue)
{
 	return write(session, object, property,oldValue,newValue,false);
}

/**
* read is the final writing to the object in question including notification
* @param object reference to ABTObject
* @param property - the property
* @param value new value
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue read(ABTUserSession session,ABTObject object,ABTProperty property)
{
 	return object.getRowValue(session, property);
}


/**
* dirty read allows reading of current element in row with bypassing of
* rule
* note that virtual fields will always return null here !
* @param object reference to ABTObject
* @param parameterName_ name of parameter
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue dirtyRead(ABTUserSession session,ABTObject object,String parameterName_)
{
 	return read(session, object, getProperty(session,object,parameterName_));
}

/**
* dirty read allows reading of current element in row with bypassing of
* rule
* note that virtual fields will always return null here !
* @param object reference to ABTObject
* @param parameterIndex_ index of parameter
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue dirtyRead(ABTUserSession session,ABTObject object,int parameterIndex_)
{
 	return read(session, object, getProperty(session,object,parameterIndex_));
}

/**
* dirty write allows writing of current element in row with bypassing of
* rule
* note that virtual fields will always fail here !
* @param object reference to ABTObject
* @param parameterName_ name of parameter
* @param value new value
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue dirtyWrite(ABTUserSession session,ABTObject object,String parameterName_,ABTValue newValue)
{
   ABTProperty property    = getProperty(session,object,parameterName_ );
   if (property == null)
    return new ABTErrorHub("ABTFieldRule->drityWrite",errorMessages.ERR_33,new ABTString(parameterName_));

   ABTValue ret = write(session,object, property,read(session,object,property),newValue,true);
   return ret;
}

/**
* dirty write allows writing of current element in row with bypassing of
* rule
* note that virtual fields will always fail here !
* @param object reference to ABTObject
* @param parameterIndex_ index of parameter
* @param value new value
* @return ABTValue value stored in row (incl. null) or ABTError
*/

protected final ABTValue dirtyWrite(ABTUserSession session,ABTObject object,int parameterIndex_,ABTValue newValue)
{
   ABTProperty property    = getProperty(session,object,parameterIndex_ );
   if (property == null)
    return new ABTErrorHub("ABTFieldRule->drityWrite",errorMessages.ERR_33,new ABTInteger(parameterIndex_));

   ABTValue ret = write(session,object, property,read(session,object,property),newValue,true);
   return ret;
}

  /**
   * Create the object set if needed and set it within the parent
   * @param session - the current user session handle
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param objectSetName - the name of the object set property in the parent
   * @param objectSetTypeName - the type of each element of the object set
   * @param myValue - the current value of the object set property
   * @return the current value is everything is ok, or ABTError if not
   */
   protected ABTValue checkObjectSet( ABTUserSession session, ABTObject parent, String objectSetName, String objectSetTypeName, ABTValue myValue )
   {
      if( ( myValue == null ) || ( ABTValue.isEmpty( myValue ) ) )
      {
         ABTObjectSet os =
            (ABTObjectSet)
            ( parent.getRule().getObjectSpace().createObjectSet( session, objectSetTypeName ) );
         if( ABTError.isError( os ) )
            return os;

         ABTValue val = dirtyWrite( session, parent, objectSetName, os );
         if (ABTError.isError(val))
            return val;
         os.addReference(session,  parent, parent.getRule().getProperty( session,objectSetName ), null );
         return os;
      }

      return myValue;
   }

  /**
   * Make sure the type is correct, return an error if not.
   * @param type - string representation of the type to compare the object to
   * @param object - the ABTObject that is being type checked
   * @param component - the component name of the caller for error reporting, i.e. "RULES"
   * @param myValue - the module of the caller for error reporting, i.e. "FRAllTasks->onSet"
   * @return the current value is everything is ok, or ABTError if not
   */
   protected ABTValue typeCheck( String type, ABTObject object, String component, String module )
   {
      String newType = object.getObjectType();
      if( !newType.equals( type ) )
         return new ABTError( component, module, errorMessages.ERR_34,
            "The bad type is " + newType );

      return (ABTValue)object;
   }

  /**
   * Make sure the object does not already contain a value
   * @param existingValue - the value of the property being accessed
   * @param component - the component name of the caller for error reporting, i.e. "RULES"
   * @param myValue - the module of the caller for error reporting, i.e. "FRAllTasks->onSet"
   * @return the current value is everything is ok, or ABTError if not
   */
   protected ABTValue overwriteCheck( ABTValue existingValue, String component, String module )
   {
      if( ! (ABTValue.isEmpty( existingValue ) ))
         return new ABTError( component, module, errorMessages.ERR_35,
            "Attempt to overwrite an existing value is disallowed" );

      return existingValue;
   }

  /**
   * Check that the value is not being set to null or ABTEmpty
   * @param newValue - the value of the new property
   * @param existingValue - the value of the property being accessed
   * @param component - the component name of the caller for error reporting, i.e. "RULES"
   * @param myValue - the module of the caller for error reporting, i.e. "FRAllTasks->onSet"
   * @return the current value is everything is ok, or ABTError if not
   */
   protected ABTValue nullSetCheck( ABTValue newValue, String component, String module )
   {
      if( newValue == null || ABTValue.isEmpty( newValue ) )
         return new ABTError( component, module, errorMessages.ERR_36,
            "Attempt to set a null or empty value is denied" );

      return newValue;
   }

  /**
   * Perform a type, overwrite and nullSet check for the set operation
   * @param type - string representation of the type to compare the object to
   * @param newValue - the value of the new property
   * @param existingValue - the value of the property being accessed
   * @param component - the component name of the caller for error reporting, i.e. "RULES"
   * @param myValue - the module of the caller for error reporting, i.e. "FRAllTasks->onSet"
   * @return the current value is everything is ok, or ABTError if not
   */
   protected ABTValue setOperationCheck( String type, ABTValue newValue, ABTValue existingValue, String component, String module )
   {
      ABTValue v = typeCheck( type, (ABTObject)newValue, component, module );
      if( ABTError.isError( v ) )
         return v;

      v = overwriteCheck( existingValue, component, module );
      if( ABTError.isError( v ) )
         return v;

      v = nullSetCheck( newValue, component, module );
      if( ABTError.isError( v ) )
         return v;

      return newValue;
   }


         /**
    * build a URL from my guidelines
    *
    * <UL>
    * <LI> get the guidelines - property
    * <LI> get the parent or alternate guideline-url
    * <LI> create new URL
    * </UL>
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue getGuidelineURL(  String procedure,
                              ABTUserSession session,
                              ABTObject caller,
                              String guidelines,
                              String parentReference,
                              String alternateParentReference,
                              String parentURL,
                              ABTHashtable parameters)
   {
      ABTObject parentObj = null;
      ABTString base = null;
      ABTString myID = null;
      ABTArray errorlist = new ABTArray();

      ABTValue val = caller.getValue(session,guidelines,parameters);
      if (ABTError.isError(val))
      {
         return new ABTErrorHub(procedure + "->getGuidelineURL",errorMessages.ERR_6,val);
      }
      if ((!(ABTValue.isNull(val))) && (val instanceof ABTString) && (val.stringValue().length() > 0))
            myID = (ABTString)val;
      // get the parent url
      val = caller.getValue(session,parentReference,parameters);
      if ( (ABTValue.isNull(val)) && (alternateParentReference != null))
         val = caller.getValue(session,alternateParentReference,parameters);
      if (ABTError.isError(val))
         return new ABTErrorHub(procedure + "->getGuidelineURL",errorMessages.ERR_6,val);
      if (!(ABTValue.isNull(val)))
      {
         parentObj = (ABTObject)val;
         val = parentObj.getValue(session,parentURL,parameters);
         if ((!(ABTValue.isNull(val))) && (val instanceof ABTString) && (val.stringValue().length() > 0))
            base = (ABTString)val;
         else
            if ((!(ABTValue.isNull(val))) && (val instanceof ABTError))
               errorlist.add ( new ABTErrorHub(procedure + "->getGuidelineURL - parentURL ",errorMessages.ERR_6,val));
      }

      URL baseUrl = null;
      URL url = null;

      if (base != null)
      {
         try
         {
            baseUrl = new URL (base.stringValue());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTErrorHub(procedure + "->getGuidelineURL - parent (" + base.stringValue() + ")" ,errorMessages.ERR_6,e));
            base = null;
         }
      }



      if (myID == null)
      {

         // if the base is null, return an error
         if (base == null)
                     return new ABTString("");
//                     return new ABTErrorHub(procedure + "->getGuidelineURL base and id null ",111,errorlist);
         // else return the baseURL
         return new ABTString(baseUrl.toExternalForm());
      }
      // if the base is null try to generate a  url
      if (base == null)
      {
         try
         {
            url = new URL (myID.stringValue());
            return new ABTString(url.toExternalForm());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTErrorHub(procedure + "->getGuidelineURL - this (" + myID.stringValue() + ")" ,errorMessages.ERR_6,e));
            return new ABTErrorHub(procedure + "->getGuidelineURL not enough info ",errorMessages.ERR_6,errorlist);
         }
      }
      // check for tag label
      if ( (myID.stringValue().charAt(0) == '#') ||
           (myID.stringValue().charAt(0) == '?'))
      {
         String temp =  base.stringValue();
         if (myID.stringValue().charAt(0) == '#')
         {
            int i = temp.indexOf('#');
            if (i > 0)
              temp = temp.substring(0,i);
         }
         if (myID.stringValue().charAt(0) == '?')
         {
            int i = temp.indexOf('?');
            if (i > 0)
              temp = temp.substring(0,i);
         }

         String newBase = temp + myID.stringValue();
         try
         {

            baseUrl = new URL (newBase);
            return new ABTString(baseUrl.toExternalForm());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTErrorHub(procedure + "->getGuidelineURL - base and this (" + newBase + ")" ,errorMessages.ERR_6,e));
            return new ABTErrorHub(procedure + "->getGuidelineURL not enough info ",errorMessages.ERR_6,errorlist);
         }
      }
      else
      {
         try
         {

            url = new URL (baseUrl,myID.stringValue());
            return new ABTString(url.toExternalForm());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTErrorHub(procedure + "->getGuidelineURL - with base and  (" + myID.stringValue() + ")" ,errorMessages.ERR_6,e));
            return new ABTErrorHub(procedure + "->getGuidelineURL not enough info ",errorMessages.ERR_6,errorlist);
         }
      }
   }


   protected final void makeIndex(ABTProperty property)
   {
      property.makeIndex();
   }
}
