package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class TaskPopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   protected ABTObject 				project_;
   protected ABTCursor 				noteCursor_;
   protected ABTCursor 				assignmentCursor_;
	protected NotePopulator 		notePopulator_;
	protected AssignmentPopulator	assignmentPopulator_;

   public TaskPopulator() {}

   public TaskPopulator(ABTRepositoryDriver driver, ABTObject project)
   {
      this(driver,project,null,null);
   }

   public TaskPopulator(ABTRepositoryDriver driver, ABTObject project, ABTObjectSpace space, ABTUserSession session)
   {
      super();
      setDriver(driver,space,session);
      project_ = project;
      notePopulator_ = new NotePopulator(getDriver(),OBJ_TW_TASK, getSpace(), getSession());
      assignmentPopulator_ = new AssignmentPopulator(getDriver(), getSpace(), getSession());
   }

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet tasks = getObjectSet(OBJ_TW_TASK);

      if (cursor_ == null || tasks == null) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      ABTValue task = null;
   	if (noteCursor_ != null) noteCursor_.moveFirst();
   	if (assignmentCursor_ != null) assignmentCursor_.moveFirst();
   	while(cursor_.moveNext()) {
         task = addObject(tasks);
   		if (!ABTError.isError(task) && !ABTValue.isEmpty(task) && task != null) {
   			addNotes((ABTObject)task);
   			addAssignments((ABTObject)task);
   		}
      }

      closePopulatorCursor();

   	if (noteCursor_ != null) noteCursor_.release();
      noteCursor_ = null;

      return tasks;
   }

   protected ABTValue addObject(ABTObjectSet tasks)
   {
      ABTObject task = (ABTObject)tasks.addNew(session_);
      task.setValue(session_,FLD_TW_PROJECT,project_);
      task.setValue(session_,FLD_TW_START,cursor_.getField(FLD_START));
      task.setValue(session_,FLD_TW_FINISH,cursor_.getField(FLD_FINISH));
      task.setValue(session_,FLD_TW_LEVEL,cursor_.getField(FLD_WBSLEVEL));
      task.setValue(session_,FLD_TW_SEQUENCE,cursor_.getField(FLD_WBSSEQUENCE));
      task.setValue(session_,FLD_TW_ISTASK,cursor_.getField(FLD_ISTASK));
      task.setValue(session_,FLD_TW_ISMILESTONE,cursor_.getField(FLD_ISMILESTONE));
      task.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
      task.setValue(session_,FLD_TW_EXTERNALID,cursor_.getField(FLD_EXTERNALID));
      task.setValue(session_,FLD_TW_PROJECTID,project_.getValue(session_,FLD_TW_INTERNALID));
      task.setValue(session_,FLD_TW_NAME,cursor_.getField(FLD_NAME));
      task.setValue(session_,FLD_TW_ISUNPLANNED,cursor_.getField(FLD_ISUNPLANNED));
      task.setValue(session_,FLD_TW_STATUS,cursor_.getField(FLD_STATUS));
      task.setValue(session_,FLD_TW_PCTCOMPLETE,cursor_.getField(FLD_PCTCOMPLETE));
      task.setValue(session_,FLD_TW_GUIDELINES,cursor_.getField(FLD_GUIDELINES));
      project_.setValue(session_,FLD_TW_LAST,task);
      RemoteID.setRemoteID(task,session_);
      return task;
   }
	
	public void setNoteCursor(String query)
	{
		noteCursor_ = getDriver().getRepository().select(query);
	}
	
	public void setAssignmentCursor(String query)
	{
		assignmentCursor_ = getDriver().getRepository().select(query);
	}
	
	protected void addNotes(ABTObject task)
	{
		if (noteCursor_ != null) {

			while (noteCursor_.isValid() && (noteCursor_.getField(FLD_WBSSEQUENCE).intValue() <= task.getValue(session_, FLD_TW_SEQUENCE).intValue())) {

		      if (task.getValue(session_, FLD_TW_ID).intValue() == noteCursor_.getField(FLD_RECORDID).intValue()) {
		      	notePopulator_.addObject(task, noteCursor_);
		      }
				noteCursor_.moveNext();
			}
		}
		return;
	}

	protected void addAssignments(ABTObject task)
	{
		if (assignmentCursor_ != null) {

			while (assignmentCursor_.isValid() && (assignmentCursor_.getField(FLD_WBSSEQUENCE).intValue() <= task.getValue(session_, FLD_TW_SEQUENCE).intValue())) {

		      if (task.getValue(session_, FLD_TW_ID).intValue() == assignmentCursor_.getField(FLD_TASKID).intValue()) {
		      	ABTObject assign = assignmentPopulator_.addObject(task, assignmentCursor_);
		      }
				assignmentCursor_.moveNext();
			}
		}
		return;
	}
}