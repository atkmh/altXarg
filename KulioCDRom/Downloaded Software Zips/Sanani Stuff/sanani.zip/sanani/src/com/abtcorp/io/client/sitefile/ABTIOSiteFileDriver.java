package com.abtcorp.io.client.sitefile;

/*
 * ABTIOSiteFileDriver.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
* 10-1-98     MXA         Initial Implementation.
*/

import java.io.File;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.EOFException;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTLocalID;

import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTTime;

import com.abtcorp.io.client.ABTFileDriver;

/**
 *  ABTIOSiteFileDriver is the ABT local file driver for the global/site object.
 *  It is instantiated by the applications.
 *
 *  <pre>
 *       ABTIOSiteFileDriver driver = new ABTIOSiteFileDriver();
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 M. Abadian
 * @see         ABTDriver, ABTFileDriver
 */

public class ABTIOSiteFileDriver extends ABTFileDriver  implements IABTRuleConstants
{
   private   IABTHashTable    intermediateTable_ = null;
   private   IABTHashTable    lookupTable_       = null;
   private   IABTLocalID      siteId_            = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTIOSiteFileDriver default constructor.
 */
   public ABTIOSiteFileDriver(){super();}

//====================================================================================
// Populate
//====================================================================================

/**
 * Populates the object space with site objects from a Local file.
 * It catches any exception and returns as an error.
 * @param space: the space to which the site will be populated.
 * @param args: the hash table of optional, application specific, parameters.
 * @return ABTValue if no exception occurs and an ABTError otherwise
 */
  public ABTValue populate(IABTObjectSpace space, IABTHashTable args)
  {
      boolean transactionStarted = false;
      ABTValue    ret     = null;
      IABTObject  site    = null;
      int         command = POPULATE;
      String      mode    = MODE_EXTERNAL;
      ABTValue    value   = null;
      String      fileName = null;

      try
      {
        checkParms(space, args);
        mode = getStringValue(args, KEY_MODE);

        // default mode to "external" if it's not specified.
        if ((mode == null) || (mode.length() == 0))
            mode = MODE_EXTERNAL;

        // If the driver has to populate the objects in the object space to a hash table.
        if (mode.equalsIgnoreCase(MODE_INTERNAL))
        {
            //SET UP IN CASE OF A HASH TABLE
            value = null;
            value = getInitialSiteId(args);
            if (value instanceof IABTLocalID)
                siteId_ = (IABTLocalID)value;
            else
                return ( new ABTError(getClass(),
                                      "save", 
                                      errorMessages.ERR_EXPECTED_IABTLocalID, 
                                      value) );
                                      
            value = null;
            value = getIntermediateTable(args);
           // checkHashTable(value);
            if (value instanceof IABTHashTable)
                intermediateTable_ = (IABTHashTable)value;
            else
                return ( new ABTError(getClass(),
                                      "save", 
                                      errorMessages.ERR_EXPECTED_IABTHashTable, 
                                      value) );

            value = null;
            value  = getLookupTable(args);
           // checkHashtable(value);
            if (value instanceof IABTHashTable)
                lookupTable_ = (IABTHashTable)value;
            else
                return ( new ABTError(getClass(),
                                      "save", 
                                      errorMessages.ERR_EXPECTED_IABTHashTable, 
                                      value) );
        }

        //If the driver has to populate the objects int the object space from a file
        else
        {
            //SETUP IN CASE OF A FILE
            fileName = getSourceFileName(args);                    ;
            intermediateTable_ = (getSpace()).newABTHashTable();
            lookupTable_       = (getSpace()).newABTHashTable();

        }
        //
        // Start a transaction.  Any changes made to the space during popukate() will be
        // rolled back if an error occurs.
        //

        space.startTransaction();
        transactionStarted = true;

        //In case of populating from a file
        if (mode.equalsIgnoreCase(MODE_EXTERNAL))
            setFile(fileName);


         // get object type from hash table
         String type = getStringValue(args, KEY_TYPE);

         // default type to "all" if it's not specified.
         if ((type == null) || (type.length() == 0))
            type = TYPE_ALL;

        // get subtype from hash table, set refresh flag if it's specified (default is false)
        String subtype = getStringValue(args, KEY_SUBTYPE);
        if ((subtype == null) || (subtype.length() == 0))
            command = POPULATE;
        else if (subtype.equalsIgnoreCase(SUBTYPE_REFRESH))
            command = REFRESH;


        //In case of populating from a file
        if (mode.equalsIgnoreCase(MODE_EXTERNAL))
        {
            populateHashTableFromLocalFile();
        }


         // populate all the global objects that are applied (i.e., only MM globals.)
         if (type.equalsIgnoreCase(TYPE_ALL))
            ret = processAllGlobals(command, site, args);

         // populate all the site objects
         else if (type.equalsIgnoreCase(TYPE_SITE))
            ret = processSite(command, args);

         // populate all the calendar objects
         else if (type.equalsIgnoreCase(TYPE_CALENDAR))
            ret = processCalendar(command, site, args);

         // populate resource objects only
         else if (type.equalsIgnoreCase(TYPE_RESOURCE))
            ret = processResource(command, site, args);

         // populate custom field objects only
         else if (type.equalsIgnoreCase(TYPE_CUSTOMFIELD))
            ret = processCustomField(command, site, args);

         // populate est model objects only
         else if (type.equalsIgnoreCase(TYPE_ESTMODEL))
            ret = processEstModel(command, site, args);

         // populate adjustment rule objects only
         else if (type.equalsIgnoreCase(TYPE_ADJRULE))
            ret = processAdjRule(command, site, args);

         // populate PMW site objects only
         else if (type.equalsIgnoreCase(TYPE_PMW))
            ret = processPmw(command, site, args);

         // other types are not supported for populate
         else
            return new ABTError(getClass(),
                                "populate",
                                errorMessages.ERR_INVALID_TYPE,
                                "The input type '" + type + "' is not supported for populate.");

        //Commmit the transaction
        space.commitTransaction();

      }
      catch (ABTException e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "populate", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      catch (Exception e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "populate", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      finally
      {

        //In case of populating from a file
        //Clean up the work Space
        if (mode.equalsIgnoreCase(MODE_EXTERNAL))
        {
            intermediateTable_ = null;
            lookupTable_      = null;
            siteId_ = null;
            cleanupFile();
        }
        // Return an ABTValue here
        return ret;
      }

  }

/**
 * Populates the intermediate hash table from a local file
 * @exception ABTException if an unrecoverable error ocurs.
 */
   public void populateHashTableFromLocalFile() throws ABTException
   {
     System.out.println("This is populateHashTableFromLocalFile.");
      try{
         FileInputStream fin  =  new FileInputStream(getFile());
         ObjectInputStream in =  new ObjectInputStream(fin);
         siteId_              = (IABTLocalID) in.readObject();
         intermediateTable_ = (getSpace()).newABTHashTable(in);
         in.close();
      } catch (EOFException e) {
         throw new ABTException(e.getMessage());
      }catch(ClassNotFoundException e) {
         throw new ABTException(e.getMessage());
      }catch (IOException e) {
         throw new ABTException(e.getMessage());
      }

   }

//====================================================================================
// Save
//====================================================================================

/**
 * Saves  site objects into a Local file.
 * It catches any exception and returns as an error.
 * @param space: the space from which the site will be saved.
 * @param args: the hash table of optional, application specific, parameters.
 * @return ABTValue if no exception occurs and an ABTError otherwise
 */
  public ABTValue save(IABTObjectSpace space, IABTHashTable args)
  {
      boolean transactionStarted = false;
      ABTValue   ret     = null;
      IABTObject site    = null;
      String     mode    = MODE_EXTERNAL;
      ABTValue  value    = null;
      String    fileName = null;
      try
      {
        checkParms(space, args);
        checkSiteObject();

        mode = getStringValue(args, KEY_MODE);

        // default mode to "external" if it's not specified.
        if ((mode == null) || (mode.length() == 0))
            mode = MODE_EXTERNAL;

        // If the driver has to save the objects in the object space to a hash table.
        if (mode.equalsIgnoreCase(MODE_INTERNAL))
        {
            //SET UP IN CASE OF A HASH TABLE
            value = null;
            value = getIntermediateTable(args);
           // checkHashTable(value);
            if (value instanceof IABTHashTable)
                intermediateTable_ = (IABTHashTable)value;
            else
                return ( new ABTError(getClass(), 
                                      "save", 
                                      errorMessages.ERR_EXPECTED_IABTHashTable, 
                                      value) );

            value = null;
            value  = getLookupTable(args);
           // checkHashtable(value);
            if (value instanceof IABTHashTable)
                lookupTable_ = (IABTHashTable)value;
            else
                return ( new ABTError(getClass(), 
                                      "save", 
                                      errorMessages.ERR_EXPECTED_IABTHashTable, 
                                      value) );
        }
        //If the driver has to save the objects int the object space to a file
        else
        {
            //SETUP IN CASE OF A FILE
            fileName = getDestinationFileName(args);                    ;
            intermediateTable_ = (getSpace()).newABTHashTable();
            lookupTable_       = (getSpace()).newABTHashTable();

        }

        // Set the site
        ABTValue source1 = getSource(args);
        checkSourceParm(source1);
        if (source1 instanceof IABTObject)
            site = (IABTObject)source1;
        else
            new ABTError(getClass(), 
                         "save", 
                         errorMessages.ERR_EXPECTED_IABTObject, 
                         source1);

        //
        // Start a transaction.  Any changes made to the space during save() will be
        // rolled back if an error occurs.
        //

        space.startTransaction();
        transactionStarted = true;

        //In case of saving to a file
        if (mode.equalsIgnoreCase(MODE_EXTERNAL))
            setFile(fileName);



         // get object type from hash table
         String type = getStringValue(args, KEY_TYPE);

         // default type to "all" if it's not specified.
         if ((type == null) || (type.length() == 0))
            type = TYPE_ALL;

         // save all the global objects that are applied (i.e., only MM globals.)
         if (type.equalsIgnoreCase(TYPE_ALL))
            ret = processAllGlobals(SAVE, site, args);

         // save all the site objects
         else if (type.equalsIgnoreCase(TYPE_SITE))
            ret = processSite(SAVE, args);

         // save all the calendar objects
         else if (type.equalsIgnoreCase(TYPE_CALENDAR))
            ret = processCalendar(SAVE, site, args);

         // save resource objects only
         else if (type.equalsIgnoreCase(TYPE_RESOURCE))
            ret = processResource(SAVE, site, args);

         // save custom field objects only
         else if (type.equalsIgnoreCase(TYPE_CUSTOMFIELD))
            ret = processCustomField(SAVE, site, args);

         // save est model objects only
         else if (type.equalsIgnoreCase(TYPE_ESTMODEL))
            ret = processEstModel(SAVE, site, args);

         // save adjustment rule objects only
         else if (type.equalsIgnoreCase(TYPE_ADJRULE))
            ret = processAdjRule(SAVE, site, args);

        // save PMW global objects only
         else if (type.equalsIgnoreCase(TYPE_PMW))
            ret = processPmw(SAVE, site, args);

         // other types are not supported for save
         else
            return new ABTError(getClass(),
                                "save",
                                errorMessages.ERR_INVALID_TYPE,
                                "The input type '" + type + "' is not supported for save.");


        //In case of saving to a file
        if (mode.equalsIgnoreCase(MODE_EXTERNAL))
            saveHashTableToLocalFile();

        if (mode.equalsIgnoreCase(MODE_INTERNAL))
            setInitialSiteId(args);


        //Commmit the transaction
        space.commitTransaction();

      }
      catch (ABTException e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "save", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      catch (Exception e)
      {
         // Trap the exception and don't let it pass upward to the application.
         System.out.println(e);
         ret = new ABTError(getClass(), 
                            "save", 
                            errorMessages.ERR_EXCEPTION_OCCURED, 
                            e);
         if (transactionStarted)
            space.rollbackTransaction();
      }
      finally
      {


        //In case of saving to a file
        //Clean up the work Space
        if (mode.equalsIgnoreCase(MODE_EXTERNAL))
        {
            intermediateTable_ = null;
            lookupTable_      = null;
            cleanupFile();
        }

        // Return an ABTValue here
        return ret;
      }

  }

/**
 * Saves a HashTable  to a local file
 * @exception ABTException if an unrecoverable error ocurs.
 */
   public void saveHashTableToLocalFile() throws ABTException {
      try{
         FileOutputStream fout  = new FileOutputStream(getFile());
         ObjectOutputStream out = new ObjectOutputStream(fout);
         out.writeObject(siteId_);
         out.writeObject(intermediateTable_);
         out.flush();
         out.close();
      } catch (IOException e) {
         throw new ABTException(e.getMessage());
      }
   }

//====================================================================================
// miscellaneous utilities
//====================================================================================
/**
  * return ABTLocalID- the site ID
  */
  public IABTLocalID getSiteId()
  {
    return siteId_;
  }
/**
  * return void set the project ID
  */
  public void setSiteId(IABTLocalID id)
  {
    siteId_ = id;
  }


/**
  *  intermediateTableGet
  *  Get the Object associated with the key in the intermediate hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object

  */

  public Object intermediateTableGet(Object key) throws ABTException
  {
    if (key instanceof ABTValue)
        return (intermediateTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("intermediateTableGet() wrong cast");
  }

/**
  *  intermediateTablePut
  *  Put the Object associated with the key in the intermediate hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object intermediateTablePut(Object key, Object elem) throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (intermediateTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("intermediateTablePut() wrong cast");
  }

/**
  *  isIntermediateTableNull
  *  return boolean
  */

  public boolean isIntermediateTableNull()
  {
    boolean ret = false;
    if (intermediateTable_==null)
        ret = true;
    return ret;
  }



/**
  *  lookupTableGet
  *  Get the Object associated with the key in the lookup hash table
  *  @parms Object key
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public Object lookupTableGet(Object key)throws ABTException
  {
    if (key instanceof ABTValue)
        return (lookupTable_.getItemByKey((ABTValue)key));
    else
        throw new ABTException("lookupTableGet() wrong cast");
  }

/**
  *  lookupTablePut
  *  Put the Object associated with the key in the lookup hash table
  *  @parms Object key, Object elem
  *  @exception ABTException if an unrecoverable error ocurs.
  *  return Object
  */

  public synchronized Object lookupTablePut(Object key, Object elem)throws ABTException
  {
    if ( (key instanceof ABTValue) && (elem instanceof ABTValue) )
        return (lookupTable_.putItemByKey((ABTValue)key, (ABTValue)elem));
    else
        throw new ABTException("lookupTablePutt() wrong cast");
  }



//====================================================================================
// private methods
//====================================================================================

   private void checkParms(IABTObjectSpace space, IABTHashTable args) throws ABTException
   {
      // make sure the space is set.
      if (space != null)
         setSpace(space);
      else
         throw new ABTException( EXC_OBJECTSPACE_NOT_SET +
                                 "Object space needs to be specified.");

      // make sure the hashtable is not null
      if ((args == null) || args.isEmpty())
         throw new ABTException( EXC_INVALID_HASH +
                                 "Hashtable must be populated.");

   }

   private void checkSourceParm(ABTValue source) throws ABTException
   {
        if (source == null || (source instanceof ABTEmpty ))
            throw new ABTException(EXC_EMPTY_SOURCE);
        if (ABTError.isError(source))
            throw new ABTException(EXC_SOURCE_ERROR);
   }

   private String getSourceFileName(IABTHashTable args) throws ABTException
   {
        String fileName = getStringValue(args, KEY_SOURCENAME);
        if (fileName == null)
            throw new ABTException(EXC_FILENAME_NOT_SET);
        return fileName;
   }

    private String getDestinationFileName(IABTHashTable args) throws ABTException
   {
        String fileName = getStringValue(args, KEY_DESTINATIONNAME);
        if (fileName == null)
            throw new ABTException(EXC_FILENAME_NOT_SET);
        return fileName;
   }

   private ABTValue getSource(IABTHashTable args) throws ABTException
   {
    try
    {
        ABTValue source = args.getItemByString(KEY_SOURCE);
        if (source == null)
            return null;
        else
            return source;
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private void checkSiteObject() throws ABTException
   {
      ABTValue site = getSite();
      if ( ABTError.isError( site ) )
         throw new ABTException((ABTError) site);
   }

   private ABTValue getInitialSiteId(IABTHashTable args) throws ABTException
   {
    try
    {
        ABTValue siteId = args.getItemByString(KEY_SITE_ID);
        if (siteId == null)
            return null;
        else
            return siteId;
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private void setInitialSiteId(IABTHashTable args) throws ABTException
   {
    try
    {
        if (siteId_!=null)
            args.putItemByString(KEY_SITE_ID,(ABTValue)siteId_);
        else
            throw new ABTException("Error in setInitialSiteId.");
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private ABTValue getIntermediateTable(IABTHashTable args) throws ABTException
   {
    try
    {
        ABTValue intermediateTable = args.getItemByString(KEY_INTERMEDIATE_TABLE);
        if (intermediateTable == null)
            return null;
        else
            return intermediateTable;
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private ABTValue getLookupTable(IABTHashTable args) throws ABTException
   {
    try
    {
        ABTValue lookupTable = args.getItemByString(KEY_LOOKUP_TABLE);
        if (lookupTable == null)
            return null;
        else
            return lookupTable;
    }
    catch(Exception e)
    {
        throw new ABTException(e.getMessage());
    }
   }

   private void checkIntermediateTable(ABTValue intermediateTable) throws ABTException
   {
        if (intermediateTable == null || (intermediateTable instanceof ABTEmpty ))
            throw new ABTException(EXC_EMPTY_INTERMEDIATE_TABLE);
        if (ABTError.isError(intermediateTable))
            throw new ABTException(EXC_INTERMEDIATE_TABLE_ERROR);
   }


   private void checkLookupTable(ABTValue lookupTable) throws ABTException
   {
        if (lookupTable == null || (lookupTable instanceof ABTEmpty ))
            throw new ABTException(EXC_EMPTY_LOOKUPTABLE);
        if (ABTError.isError(lookupTable))
            throw new ABTException(EXC_LOOKUPTABLE_ERROR);
   }


/**
 *	populate or refresh site object along with type codes and charge codes from local file.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
 private ABTValue processSite(int command, IABTHashTable args) throws ABTException
 {
      IABTObject site = null;
      ABTValue   val  = null;

      // Instantiate a site helper object and invoke its populate() or refresh()
      // method depending on the input command.
      ABTIOSiteFileSite siteHelper = new ABTIOSiteFileSite(this);

      switch (command)
      {
         case POPULATE:
            val = siteHelper.populate();
            break;
         case SAVE:
            ABTValue source1 = getSource(args);
            checkSourceParm(source1);
            if (source1 instanceof IABTObject)
                site = (IABTObject)source1;
            else
                new ABTError(getClass(), 
                             "processSite", 
                             errorMessages.ERR_EXPECTED_IABTObject, 
                             source1);

            val = siteHelper.save(site);
            break;
         default:
      }

      if ((val instanceof IABTObjectSet) && (((IABTObjectSet)val).size() > 0))
      {
         // there should be only one site object
         site = (IABTObject) ((IABTObjectSet)val).at(0);

         ABTIOSiteFileTypeCode tcHelper = new ABTIOSiteFileTypeCode(this, site);
         switch (command)
         {
            case POPULATE:
               val = tcHelper.populate();
               break;
            case SAVE:
               val = tcHelper.save(site,OFD_TYPECODES);
               break;
            default:
         }

         ABTIOSiteFileChargeCode ccHelper = new ABTIOSiteFileChargeCode(this, site);
         switch (command)
         {
            case POPULATE:
               val = ccHelper.populate();
               break;
            case SAVE:
                val = ccHelper.save(site, OFD_CHARGECODES);
                break;
            default:
         }

      }
      else
      {
         processError(SEVERITY_ONE,
                  "processSite",
                  EXC_RECORD_NOT_FOUND,
                  "Site data is not found." );
      }

      return (ABTValue) site;

   }


/**
 *	populate all the global objects from the repository.
 * @param refresh whether or not to refresh the objects
 * @param args    the input parameter hashtable
 *	@return the site object if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processAllGlobals(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
         ABTValue val = processSite(command, args);

         if (val instanceof IABTObject)
            site = (IABTObject) val;
         else
         {
            processError(SEVERITY_ONE,
                     "processAllGlobals",
                     EXC_RECORD_NOT_FOUND,
                     "Site data is not found in the repository." );
            return null;
         }

      // process resources (including base calendars and notes)
      processResource(command, site, args);

      // process custom fields (including custom enums and aggregate fields)
      processCustomField(command, site, args);

      // process estimating models
      processEstModel(command, site, args);

      // process adjustment rules
      processAdjRule(command, site, args);

      // process time periods
      processTimePeriod(command, site, args);

      return (ABTValue)site;
   }


/**
 *	populate, save or refresh resource objects from the repository.
 *  @param command what to do
 *  @param site    the site object
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processResource(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
      ABTValue val = null;

      // first make sure the base calendars are populated or saved
      processCalendar(command, site, args);

   	// then process the resources
      ABTIOSiteFileResource helper = new ABTIOSiteFileResource(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(site, OFD_RESOURCES);
            break;

         default:
            // error
      }

      return val;

   }

/**
 *	populate or refresh base calendar objects from the repository.
 *  @param command what to do
 *  @param site    the site object
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
  private ABTValue processCalendar(int command, IABTObject site, IABTHashTable args) throws ABTException
  {
      ABTValue val = null;

      ABTIOSiteFileCalendar helper = new ABTIOSiteFileCalendar(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;
         case SAVE:
            val = helper.save(site, OFD_CALENDARS);
         default:
      }

      return val;
   }


/**
 *	populate, save or refresh custom field objects along with aggregate fields
 *  and custom enums from the local file.
 *  @param command what to do
 *  @param site    the site object
 *  @param args    the input parameter hashtable
 *	@return the custom field object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
private ABTValue processCustomField(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
      ABTValue val = null;

      ABTIOSiteFileCustomField helper = new ABTIOSiteFileCustomField(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;

         case SAVE:
            val = helper.save(site, OFD_CUSTOMFIELDS);
            break;

         default:
            // error
      }
      return val;  // return the custom field object set
   }

/**
 *	populate, save or refresh estimating model objects from the repository.
 *  @param command what to do
 *  @param site    the site object
 *  @param args    the input parameter hashtable
 *	@return the estimating model object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processEstModel(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
      ABTValue val = null;

   	// process estimating models.
     ABTIOSiteFileEstModel helper = new ABTIOSiteFileEstModel(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;

         case SAVE:
            val = helper.save(site, OFD_ESTMODELS);
            break;

         default:
            // error
      }

      return val;
   }


/**
 *	populate, save or refresh adjustment rule objects from the local file.
 *  @param command what to do
 *  @param site    the site object
 *  @param args    the input parameter hashtable
 *	@return the adjustment rule object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processAdjRule(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
      ABTValue val = null;

   	// process estimating models.
      ABTIOSiteFileAdjRule helper = new ABTIOSiteFileAdjRule(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;

         case SAVE:
            val = helper.save(site, OFD_ADJRULES);
            break;

         default:
            // error
      }

      return val;
   }
/**
 *	populate or refresh time period objects from the local file.
 *  @param command what to do
 *  @param site    the site object
 *  @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
private ABTValue processTimePeriod(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
      ABTValue val = null;

      ABTIOSiteFileTimePeriod helper = new ABTIOSiteFileTimePeriod(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate();
            break;

         case SAVE:
            val = helper.save(site, OFD_TIMEPERIODS);
            break;

         default:
      }

      return val;
   }

/**
 *	populate all the PMW global objects from the repository.
 *  @param refresh whether or not to refresh the objects
 *  @param args    the input parameter hashtable
 *	@return the site object if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processPmw(int command, IABTObject site, IABTHashTable args) throws ABTException
   {
         ABTValue val = processSite(command, args);

         if (val instanceof IABTObject)
            site = (IABTObject) val;
         else
         {
            processError(SEVERITY_ONE,
                     "processAllGlobals",
                     EXC_RECORD_NOT_FOUND,
                     "Site data is not found in the repository." );
            return null;
         }

      // process resources (including base calendars and notes)
      processResource(command, site, args);

      return (ABTValue)site;
   }



}