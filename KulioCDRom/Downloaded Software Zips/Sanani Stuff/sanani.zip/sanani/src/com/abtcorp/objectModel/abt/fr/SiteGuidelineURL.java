package  com.abtcorp.objectModel.abt.fr;

/*
 * SiteGuidelineURL.java 08/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 10-21-98       HJB           Initial Design
 *
 */

import   java.util.*;
import   java.net.URL;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule returns the guideline URL generated for Sites
 * - either from the guidelines or from the provided parameter
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class SiteGuidelineURL extends SiteFieldRule
{
   private ABTInteger docbase =  new ABTInteger(kDocumentBase);

   /**
    * build a URL from the guidelines
    * <UL>
    * <LI> if the parameter kDocumentBase is passed the file portion of the guidelineid is extracted
    * and a new url is formed
    * <LI> if no parameter is passed a url is built from the guidelineID
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onGet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue,  ABTHashtable parameters )
   {
      ABTString base = null;
      ABTString myID = null;
      ABTArray errorlist = new ABTArray();
      if (parameters != null)
         try
         {
            base = (ABTString)parameters.get(docbase);
         }
         catch (Exception e)
         {
            return new ABTError("SiteGuildelineURL",
               "onGet",
               errorMessages.ERR_INVALID_VALUE,
               docbase);
         }

      ABTValue val = parent.getValue(session,OFD_GUIDELINES,parameters);
      if (ABTError.isError(val))
         return val;
      if ((!(ABTValue.isNull(val))) && (val instanceof ABTString))
         myID = (ABTString)val;


             URL baseUrl = null;
      URL url = null;

      if (base != null)
      {
         try
         {
            baseUrl = new URL (base.stringValue());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTError("SiteGuildelineURL",
               "onGet",
               errorMessages.ERR_DUPLICATE_DETECTED,
               e));
            base = null;
         }
      }



      if (myID == null)
      {
         // if the base is null, return an empty string
         if (base == null)
                     return new ABTString("");
         // else return the baseURL
         else
            return new ABTString(baseUrl.toExternalForm());
      }
      // if the base is null try to generate a  url
      if (base == null)
      {
         try
         {
            url = new URL (myID.stringValue());
            return new ABTString(url.toExternalForm());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTError("SiteGuildelineURL",
               "onGet",errorMessages.ERR_DUPLICATE_DETECTED,e));
            return new ABTError("SiteGuildelineURL", 
               "onGet", errorMessages.ERR_GUIDELINE, errorlist);
         }
      }
      // check for tag label
      if ( (myID.stringValue().charAt(0) == '#') ||
           (myID.stringValue().charAt(0) == '?'))
      {
         String temp =  base.stringValue();
         if (myID.stringValue().charAt(0) == '#')
         {
            int i = temp.indexOf('#');
            if (i > 0)
              temp = temp.substring(0,i);
         }
         if (myID.stringValue().charAt(0) == '?')
         {
            int i = temp.indexOf('?');
            if (i > 0)
              temp = temp.substring(0,i);
         }

         String newBase = temp + myID.stringValue();
         try
         {

            baseUrl = new URL (newBase);
            return new ABTString(baseUrl.toExternalForm());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTError("SiteGuildelineURL",
               "onGet", errorMessages.ERR_DUPLICATE_DETECTED, e));
            return new ABTError("SiteGuildelineURL",
               "onGet", errorMessages.ERR_GUIDELINE,errorlist);
         }
      }
      else
      {
         try
         {

            url = new URL (baseUrl,myID.stringValue());
            return new ABTString(url.toExternalForm());
         }
         catch (Exception e)
         {
            errorlist.add ( new ABTError("SiteGuildelineURL",
               "onGet",errorMessages.ERR_DUPLICATE_DETECTED,e));
            return new ABTError("SiteGuildelineURL",
               "onGet",errorMessages.ERR_GUIDELINE,errorlist);
         }
      }
   }
}
