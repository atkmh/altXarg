package com.abtcorp.io.client.pmwfile;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;

public class errorMessages extends ListResourceBundle
{
public Object[][] getContents() {
			return contents; 
}


public static final String Package = "com.abtcorp.io.client.pmwfile".intern();
public static final ABTErrorCode ERR_PROJ_ID_NULL = new ABTErrorCode(Package, "100");
public static final ABTErrorCode ERR_EXCEPTION = new ABTErrorCode(Package, "101");
public static final ABTErrorCode ERR_FAILED_LINK = new ABTErrorCode(Package, "102");
public static final ABTErrorCode ERR_NOT_IN_LIST = new ABTErrorCode(Package, "103");
public static final ABTErrorCode ERR_INVALID_FUNC = new ABTErrorCode(Package, "104");
public static final ABTErrorCode ERR_OBJ_INACCESSIBLE = new ABTErrorCode(Package, "105");
public static final ABTErrorCode ERR_6 = new ABTErrorCode(Package, "106");
public static final ABTErrorCode ERR_7 = new ABTErrorCode(Package, "107");
public static final ABTErrorCode ERR_8 = new ABTErrorCode(Package, "108");
public static final ABTErrorCode ERR_EXPECTED_IABTOBJECT = new ABTErrorCode(Package, "109");
public static final ABTErrorCode ERR_SUBTASK_ID_NULL = new ABTErrorCode(Package, "110");



static final Object[][] contents = {
{ERR_PROJ_ID_NULL.getCode(),"the project ID is null"},
{ERR_EXCEPTION.getCode(),"An exception has occured."},
{ERR_FAILED_LINK.getCode(),"Failed to link object for "},
{ERR_NOT_IN_LIST.getCode(),"object not in instance list"},
{ERR_INVALID_FUNC.getCode(),"Invalid Functioncall"},
{ERR_OBJ_INACCESSIBLE.getCode(),"Object Inaccessible"},
{ERR_6.getCode(),"Invalid property"},
{ERR_7.getCode(),"Unknown Property"},
{ERR_8.getCode(),"Invalid Value for Property"},
{ERR_EXPECTED_IABTOBJECT.getCode(),"Invalid type (expected IABTObject)"},
{ERR_SUBTASK_ID_NULL.getCode(),"the subtask ID is null"},

 };
}