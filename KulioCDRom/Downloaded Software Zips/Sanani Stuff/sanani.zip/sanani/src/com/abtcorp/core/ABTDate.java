/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTDate.java, 22, 12/7/98 10:19:06 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.io.*;
import java.util.*;
import java.text.*;

public class ABTDate extends ABTImmutableValue
{
   private static final long serialVersionUID = 2784895434156605738L;

   // NOTE: These constants are different from the repository.
   //       They are identical to the java.util.Calendar constants.

   public final static int SUNDAY    = 1;
   public final static int MONDAY    = 2;
   public final static int TUESDAY   = 3;
   public final static int WEDNESDAY = 4;
   public final static int THURSDAY  = 5;
   public final static int FRIDAY    = 6;
   public final static int SATURDAY  = 7;

   protected int julian_;
   
   public void fromByte(byte[] input){};
   public byte[] fromByte(){ return null;};

   public ABTDate(int julian)                    {julian_ = julian;}
   public ABTDate(int year, int month, int day)  {julian_ = julian(year, month, day);}
   public ABTDate(ABTTime time, boolean pm)      {julian_ = time.getJulian(pm);}
   public ABTDate(Calendar calendar, boolean pm) {julian_ = julian(calendar, pm);}
   public ABTDate(Date date, boolean pm)         {julian_ = julian(date, pm);}
   public ABTDate(ABTValue value, boolean pm)    {this(value.dateValue(pm));}
   public ABTDate(ABTDate date)                  {julian_ = date.julian_;}

   public final int getJulian() {return julian_;}

   public int hashCode() {return julian_;}

   public int compareTo(Object object) 
   {
    if (object == null) return 1;     
    return compareTo(((ABTValue)object).dateValue(false));
   }

   public final int compareTo(ABTDate date)
   {
      if (date == null) return +1;
      
      if (julian_ == date.julian_) return 0;
      
      return julian_ < date.julian_ ? -1 : +1;
   }
   
   public static ABTDate min(ABTDate date1, ABTDate date2)
   {
      if (date1 == null) return date2;
      if (date2 == null) return date1;
      
      return date1.compareTo(date2) < 0 ? date1 : date2;
   }

   public static ABTDate max(ABTDate date1, ABTDate date2)
   {
      if (date1 == null) return date2;
      if (date2 == null) return date1;

      return date1.compareTo(date2) < 0 ? date2 : date1;
   }

   public static int diff(ABTDate date1, ABTDate date2) {return date2.julian_ - date1.julian_;}
   
   public static ABTDate today() {return new ABTDate(Calendar.getInstance(), false);}
   
   public final int getDayOfWeek() {return ((julian_ + 6) % 7) + 1;}

   public final ABTDate add(int days)
	{
		if (days == 0) return this;
		if (days <  0) return sub(-days);
		
		return new ABTDate(julian_ + days);
	}
	
   public final ABTDate sub(int days)
	{
		if (days == 0) return this;
		if (days <  0) return add(-days);

		return new ABTDate(julian_ - days);
	}
	
   public final ABTDate next() {return add(1);}
   public final ABTDate prev() {return sub(1);}

   public Calendar toCalendar(int timeofday) {return toCalendar(julian_, timeofday);}
   public Date     toDate(int timeofday)     {return toDate(julian_, timeofday);}

   public static Calendar toCalendar(int julian, int timeofday)
   {
      int year, month, day;

      int x;
	   int j = julian + 693900;

   	year = ((j << 2) - 1) / 146097;  j = (j << 2) - 1 - 146097 * year;
	   x = (j >> 2);							j = ((x << 2) + 3) / 1461;
	   x = (x << 2) + 3 - 1461 * j;
	   x = (x + 4) >> 2;
	   month = (5 * x - 3) / 153;
	   x = 5 * x - 3 - 153 * month;
	   day = (x + 5) / 5;
	   year = 100 * year + j;

	   if (month < 10) month += 3;
	   else {month -= 9; year++;}

      int hour   = timeofday / 3600;
      int minute = timeofday % 3600 / 60;
      int second = timeofday % 60;

      Calendar calendar = Calendar.getInstance();

      calendar.set(year, month - 1, day, hour, minute, second);
      calendar.set(Calendar.MILLISECOND, 0);

      calendar.setTime(calendar.getTime());

	   return calendar;
   }

   public static Date toDate(int julian, int timeofday)
   {
      Calendar calendar = toCalendar(julian, timeofday);
      
	   return calendar.getTime();
   }

   public static int julian(int year, int month, int day)
   {
   	if (year == 0 && month == 0 && day == 0) return 0;

   	if 	  (year < 82)  year += 2000;
   	else if (year < 100) year += 1900;

      if  (month > 2) month -= 3;
      else {month += 9; year--;}

      int c = year / 100;
      int ya = year - 100 * c;
      
      return ((146097 * c) >>> 2) + ((1461 * ya) >>> 2) + (153 * month + 2) / 5 + day - 693900;
   }

   public static int julian(Calendar calendar, boolean pm)
   {
      if (calendar == null) return 0;

      int day    = calendar.get(Calendar.DATE);
      int month  = calendar.get(Calendar.MONTH) + 1;
      int year   = calendar.get(Calendar.YEAR);
      int hour   = calendar.get(Calendar.HOUR_OF_DAY);
      int minute = calendar.get(Calendar.MINUTE);
      int second = calendar.get(Calendar.SECOND);

      int julian = julian(year, month, day);
      
      if (pm && hour == 0 && minute == 0 && second == 0) julian--;

      return julian;
   }

   public static int julian(Date date, boolean pm)
   {
      if (date == null) return 0;

      Calendar calendar = Calendar.getInstance();

      calendar.setTime(date);
      
      return julian(calendar, pm);
   }

   public String  stringValue()           {return DateFormat.getDateInstance(DateFormat.SHORT).format(toDate(0));}
   public ABTDate dateValue(boolean pm)   {return this;}
   public ABTTime timeValue()             {return new ABTTime(this, 0);}

   public static ABTDate valueOf(String string) {return new ABTDate(new ABTString(string), false);}
   
   public String toSQL()    {return "{d '" + new java.sql.Date(toDate(0).getTime()) + "'}";}

   // This optimizes the serialization

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeInt(julian_);
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      julian_ = stream.readInt();
   }
}