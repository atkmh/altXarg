package com.abtcorp.io.team.connect.data;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;

public class DeletedData extends SimpleData
{
   public DeletedData(ABTObject object, ABTUserSession session)
   {
      super(object,session);
   }
}
