/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;

import com.abtcorp.blob.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

/** @com.register(clsid=61C18EE2-7052-11d2-AE1A-00E02921FB8A,
                typelib=A2FAB780-BDD1-11D1-ADE6-00E029143BC6,
                progid="com.abtcorp.api.com.ABTDateUtil.1",
                version="1.0.0")*/

public class ABTDateUtilCOM implements IABTDateUtil
{
   public ABTDateUtilCOM() {}

   public int getDayOfWeek(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return Adate.getDayOfWeek();
      }

   public Variant next(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(Adate.next());
      }

   public Variant prev(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return VariantMunger.ValueToVariant(Adate.prev());
      }

   public String  stringValue(Variant date) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date), false);
      return Adate.stringValue();
      }

   public Variant earlier(Variant date1, Variant date2){
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date1), false);
      ABTDate Bdate = new ABTDate(VariantMunger.VariantToValue(date2), false);
      return VariantMunger.ValueToVariant(ABTDate.min(Adate,Bdate));
      }

   public Variant later(Variant date1, Variant date2){
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date1), false);
      ABTDate Bdate = new ABTDate(VariantMunger.VariantToValue(date2), false);
      return VariantMunger.ValueToVariant(ABTDate.max(Adate,Bdate));
      }

   public int diff(Variant date1, Variant date2) {
      ABTDate Adate = new ABTDate(VariantMunger.VariantToValue(date1), false);
      ABTDate Bdate = new ABTDate(VariantMunger.VariantToValue(date2), false);
      return ABTDate.diff(Adate,Bdate);
      }

   public Variant today() {
      return VariantMunger.ValueToVariant(ABTDate.today());
      }

   public int julian(int year, int month, int day){
      return ABTDate.julian(year,month,day);
      }
  
   public Variant fromString(String string) {
      return VariantMunger.ValueToVariant(ABTDate.valueOf(string));
      }
}