package com.abtcorp.io.client.mppfile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import com.abtcorp.core.*;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.objectspace.jgl.adapters.CharBuffer;

//amount always in hours
//type determines how it was imported as and how it is to be exported

public class MppTimeQuantity implements IABTClientMppDriverConstants
{
  private int     type_;
  private double  amountInHours_; //always in hours

  public MppTimeQuantity()
  {
    type_            = 0;
    amountInHours_   = 0;
  }
  public MppTimeQuantity(int type, double amount)
  {
    //if () validate type
    type_            = type;
    amountInHours_   = amount;
  }
  public void     setType(int type){type_ = type;} // private in order to force validation
  public int      getType(){return type_;}
  public void     setAmount(double amount){amountInHours_ = amount;} // private in order to force validation
  public double   getAmount(){return amountInHours_;}

}
