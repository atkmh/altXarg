package  com.abtcorp.objectModel.abt.fr;

/*
 * SiteCalendar.java 11/18/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author         Description
 * 11-18-98    LZX            Initial Design
 *
 */

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.*;

/**
 * Field rule for the site calendar blob. 
 */

public class SiteCalendar extends SiteFieldRule
{
   /**
    * retrieves the calendar value from the standard (site) calendar object.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The current value of the property
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue (ABTCalendar object) if successful, ABTError if not
    */
   protected ABTValue onGet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters )
   {
      // Get the site calendar object
      ABTValue v = parent.getValue(session, OFD_STDCALENDAR, parameters);
      if ( ABTError.isError( v ) )
         return v;
      
      if (!ABTValue.isNull(v))
      {
         // get the calendar blob from the site calendar object
         ABTObject calObj = (ABTObject) v;
         return calObj.getValue(session, OFD_VALUE, parameters);
      }
      else
         return null;
   }
}
