package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoEstimatingModel.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-22-98    SOB            Initial Implementation
 * 07-09-98    SOB            transaction support
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-20-98    SOB            Mods to support the new data model for estimating model objects
 * 07-21-98    SOB            Mods to support required parameters
 * 07-23-98    SOB            Mods to support save()
 * 08-07-98    SOB            Mods to support Widgeon data model changes
 * 10-09-98    SOB            Beginnings of progress reporting
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoEstimatingModel is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTEstimatingModel object in the object space, or to save an ABTEstimatingModel
 *  back to the repository.
 *  <pre>
 *    ABTIOPMWRepoEstimatingModel rem = new ABTIOPMWRepoEstimatingModel(ABTObjectSpace space,
 *                                                                   ABTRepositoryDriver driver,
 *                                                                   ABTObject projObj,
 *                                                                   long projID);
 *
 *    - or -
 *
 *    ABTIOPMWRepoEstimatingModel rem = new ABTIOPMWRepoEstimatingModel(ABTObjectSpace space,
 *                                                                   ABTRepositoryDriver driver,
 *                                                                   ABTObject project,
 *                                                                   boolean forceAddNew);
 *
 *  </pre>
 *
 * @version	    $Revision: 24$
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 * @see         ABTProjectSaver
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTID;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoEstimatingModel extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private ABTObjectSet esos_;

   public ABTIOPMWRepoEstimatingModel() {/* implicit call to super() here */}
   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoEstimatingModel(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_ESTMODEL, OBJ_ESTIMATINGMODEL, progress);
      projObj_ = projObj;
      projectID_ = projID;
   }

   /**
    *    Constructs a helper object used to save Estimating Model objects to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepositoryDriver reference
    *    @param project a Project object reference
    *    @param forceAddNew true if addNew() operations to the repository are being forced; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoEstimatingModel(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_ESTMODEL, OBJ_ESTIMATINGMODEL, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates the object space with estimating model objects
    *    @param parms (not currently used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;

      try
      {
         getCursor();

         esos_ = getObjectSet(projObj_, OFD_ESTMODELS);

         //
         // For each estimating model tuple in the result set, make sure one exists in the
         // object space.
         //
         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this estimating model object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the estimating model object already exists in the object space.
            //
            object = find(OBJ_ESTIMATINGMODEL, id_);

            //
            // If the object found is an ABTObject, then the est. model object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new est. model object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }
         }              // end while (cursor_.moveNext())
      }                 // end try block
      finally
      {
         closeCursor();
      }

      return null;
   }

   /**
    *    Creates a new estimating model object
    *    @param parms (not currently used)
    *    @return the newly-created object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Ask the object space to create a new estimating model object. A project object
      // reference is required to create the new object.
      //
      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_PROJECT, projObj_);
      ABTObject object = createObject(OBJ_ESTIMATINGMODEL, id_, reqparms);

      //
      // Initialize some collection properties.
      //
   	initValues((ABTObject) object);

      //
      // Initialize repository properties of the new estimating model object.
      //
      setValues((ABTObject) object);
      return object;
   }

   /**
    *    Updates an existing estimating model object
    *    @param parms the estimating model object to be updated
    *    @return updated object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
   	//
   	// Set values from the repository cursor.
   	//
   	setPropertyValues(ps_, cursor_, obj);

   }

   /**
    *    Creates a Hashtable of estimating model objects
    *    @return Hashtable of estimating model objects
    *    @exception ABTException if an unrecoverable error occurs
    */
   public Hashtable getEstModelHashtable() throws ABTException
   {
      ABTObjectSet emos = getObjectSet(projObj_, OFD_ESTMODELS);
      int   size = emos.size(driver_.getUserSession());
      Hashtable ht = new Hashtable();

      //
      // For each est. model object in the set of all est. model objects for the current
      // project, create a Hashtable entry.  The hash table can be used for quick look-up of
      // estimating model objects later in the populate process.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject obj = (ABTObject) emos.at(driver_.getUserSession(), i);
         ABTValue val = obj.getValue(driver_.getUserSession(), OFD_ID);
         if (ABTError.isError(val)) continue;
   	   ht.put(new Long(val.intValue()), obj);
      }

      return ht;
   }

   private void initValues(ABTObject obj) throws ABTException
   {
   }

   private void getCursor()
   {
      //
      // If the cursor is open, close it now.
      //
      closeCursor();

      //
      // Select the estimating model(s) for the project.
      //
      cursor_ = repo_.select(QRY_PROJECTESTMODEL);
      cursor_.andFilter(TBL_ESTMODEL + "." + FLD_PROJECTID + "=" + projectID_);
   }

   /**
    *    Saves all estimating model objects to the repository
    *    @param parms (not currently used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get a cursor and order the result set by prID.
      //
      getCursor();
      cursor_.setSort(TBL_ESTMODEL + "." + FLD_ID);

      //
      // Get the set of estimating model objects from the owning project object.
      //
      ABTObjectSet estModels = getObjectSet(projObj_, OFD_ESTMODELS);

      setSomeProperties(estModels);

      //
      // Save all estimating models by calling the parent's save() method, which is the
      // generic save() method.
      //
      save(estModels);

      closeCursor();
   }

   private void setSomeProperties(ABTObjectSet estModels) throws ABTException
   {
      int size = size(estModels);

      //
      //  Get the project's ID as an ABTValue object.
      //
      ABTValue projID = new ABTInteger(getValue(projObj_, OFD_ID));

      //
      // For each estimating model object, make sure that the project ID column is
      // correct before saving back to the repository.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject estModel = at(estModels, i);
         setValue(estModel, OFD_PROJECTID, projID);
      }
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: a boolean value which indicates whether the data being added is new to the repository, i.e., the
    *             operation is an add.
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         if (super.isSaveException(prapiName, obj, prapiFlags, isNew)) return  true;

         boolean  ret = false;            // assume no exception

         if (!isNew)
         {
            if (prapiName.equals(FLD_PROJECTID))
               ret = true;
         }

         return ret;
   }



}