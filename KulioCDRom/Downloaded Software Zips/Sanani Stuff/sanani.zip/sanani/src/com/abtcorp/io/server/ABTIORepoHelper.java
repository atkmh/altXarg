package com.abtcorp.io.server;
/*
 * ABTIORepoHelper.java 07/14/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date       Author         Description
  * 07-14-98   SOB            Initial Implementation
  * 07-15-98   SOB            Initial cut at setCursorValues()
  * 07-16-98   LZX            Remove cursor update from setCursorValues(). Add closeCursor().
  * 07-17-98   SOB            Added checking for virtual fields in isException() method.
  * 07-20-98   SOB            isException() can throw and ABTException
  * 09-02-98   SOB            Added support for maximum length restrictions for properties of type PROP_STRING
  * 10-01-98   SOB            Added logic in setPropertyValues() to check PROP_KUPDATABLE property on error conditions
  * 10-09-98   SOB            Added beginnings of progress reporting
  * 11-20-98   SOB            Added getLockingUserName()
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.*;
import com.abtcorp.idl.*;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTSession;

/**
 *  ABTIORepoHelper is an abstract class that contains useful, common methods.
 *
 *  <pre>
 *			This class is not meant to be instantiated directly, but to be extended by various
 *          classes that a driver will instantiate to assist it in populating the object space.
 *
 *			public class ABTIOPMWRepoProject extends ABTIORepoHelper
 *			{
 *				... override find(), create(), update(), etc., methods for PMW-specific requirements ...
 *			}
 *
 *  </pre>
 *
 * @version	1.0
 * @author  S. Bursch
 * @see     ABTDriver
 */

public abstract class ABTIORepoHelper extends ABTServerHelper implements ABTNames,
                                                                         ABTEnum,
                                                                         IABTDriverConstants,
                                                                         IABTPropertyType
{
   /**
   *  propertyTable_ is a Java hash table which contains PropertyIndex objects.
   */
   private Hashtable propertyTable_ = null;

   protected String table_ = null;            // the reposiotry table name
   protected String type_ = null;             // the object type
   protected ABTRepoDataDictionary dataDictionary_; // reference to the data dictionary to be used
   protected Vector ps_;
   protected IABTInternalProgressListener progress_ = null;

   public static final int FLAG_SKIP_READ_ON_NULL = 1;
   public static final int FLAG_SKIP_READ = 2;
   
   private static final String SPECIAL_PROPERTY = "DynamicPropertiesAddedByDriver".intern();

/**
 *		Creates an ABTIORepoHelper that is not associated with an ABTObjectSpace or ABTDriver.
 *    Associating an object space with this class will be deferred until later.
 */
   public   ABTIORepoHelper() { /* implicit call to super() here */ }

/**
 *		Creates an ABTIORepoHelper that is associated with an ABTObjectSpace and an ABTUserSession.
 *
 */
   public   ABTIORepoHelper(ABTObjectSpace space, ABTUserSession session)
   {
    super(space, session);
   }

/**
 *		Creates an ABTIORepoHelper that is associated with a driver, a table name
 *    and an object type. A data dictionary is created in this constructor so that
 *    those helper classes that extend this helper class can set special property
 *    flags in the property index object if needed.
 */
   public   ABTIORepoHelper(ABTRepositoryDriver driver, String table, String type)
   {
      super(driver.getSpace(), driver.getUserSession());
      table_ = table;
      type_ = type;

      dataDictionary_ = new ABTRepoDataDictionary();
     	if (!dataDictionary_.isValid())
     	   dataDictionary_.createRepoDataDictionary(driver.getSession());

      ps_ = dataDictionary_.getPropertiesFromDataModel(table_);

	   // add properties to the object type just in case there are some
	   // user-defined fields.  Only add the properties if they have not
	   // been added previously.
	   //
      if (!specialPropertyIsAdded(type_))
         addProperties(type_, ps_);

   }

/**
 *		Creates an ABTIORepoHelper that is associated with a driver, a table name,
 *    object type, and progress object.
 */
   public   ABTIORepoHelper(ABTRepositoryDriver driver,
                            String table,
                            String type,
                            IABTInternalProgressListener progress)
   {
      this(driver, table, type);
      progress_ = progress;
   }

/**
 *		Create a utility member class that associates a property's name with its index.
 *		Instances of this member class will be used to populate objects in the object
 *    space.  The propertyIndex_ member of the class will be used in the object's setValue()
 *    method, while the propertyName_ member will be used in the ABTCursor object's getField()
 *    method.  The purpose is to avoid usage of the setValue() version which looks up
 *    a property by its name.
 */

   public class PropertyIndex
   {
      public int propertyIndex_;
      public String propertyName_;
      public long propertyFlags_;
      public String prapiName_;
      public long prapiFlags_;
   }

/**
 *		Adds properties dynamically for an ABTObject object type.  The properties to be added
 *    are (usually) created by a call into getPropertiesFromDataModel() of the
 *    ABTRepoDataDictionary class, but can be any set of properties conforming to the
 *    output of that method.  This method can be used to add more properties than those which
 *    are added by default when an ABTObject is first instantiated.  It supports the adding of
 *    repository properties which may have been added to the data model at a customer's site.
 *    @param objectType the type of ABTObject for which properties are to be added
 *    @param properties a Java Vector containing the set of ABTDataDictionary objects
 *                         appropriate to objectType.  There is one Vector element for
 *                         each field (property) in objectType.
 */

   public void addProperties(String objectType, Vector properties)
   {
      addSpecialProperty(objectType);
      
      //
      // For each property in the data dictionary add that property to its corresponding
      // object type.
      //
      int size = properties.size();
      for (int i = 0; i < size; i++)
      {
         ABTRepoDataDictionary rdd = (ABTRepoDataDictionary) properties.elementAt(i);
         String propertyName = rdd.getPropertyName();

         ABTError testError = space_.addProperty
                           (  objectType,
                              propertyName,
                              propertyName,
                              rdd.getPropertyDataType().intValue(),
                              false,
                              true,
                              true,
                              false, //transient
                              null,
                              null,
                              null
                           );

         //
         // Most of the time, the above addProperty() invocation will fail because the property
         // was already added in the object type's setDefaultProperties() method.  On certain rare
         // occasions, e.g., when a customer adds its own fields to the repository data model, the
         // addProperty() will succeed.  In that case, we need to inspect the property and add
         // extended properties, as appropriate.  If the above addProperty() succeeded, the return
         // error object will be null.
         //
         if (testError != null) continue;

         short extType = rdd.getExtType();
         long  flags   = rdd.getFlags();

         //
         // Find the property object just added.
         //
         ABTPropertySet pSet = space_.getProperties(objectType);
         ABTProperty prop = getProperty(pSet, propertyName);

         if (prop == null) continue;      // Oops! property not found; should not occur; continue loop

         //
         // Set any extended properties that may be applicable for this property.
         // Note that date properties may have two extended properties added for them:
         // one to indicate that the property is a date, and one (optionally) to indicate
         // that the date is a PM date.
         //
         if (extType != 0)          // any extended property for this just-added property?
         {
            switch (extType)
            {
               case PR_EXTTYPE_MONEY:
                  prop.setPropertyKey(PROP_EXTTYPE_MONEY, new ABTBoolean(true));
                  break;

               case PR_EXTTYPE_DATE:
                  prop.setPropertyKey( PROP_EXTTYPE_DATE, new ABTBoolean(true) );
                  if ( (flags & PR_FIELD_ISPMDATE) == PR_FIELD_ISPMDATE)
                     prop.setPropertyKey( PROP_EXTTYPE_PM, new ABTBoolean(true) );
                  break;

               case PR_EXTTYPE_PERCENT:
                  prop.setPropertyKey( PROP_EXTTYPE_PERCENT, new ABTBoolean(true) );
                  break;

               case PR_EXTTYPE_MEMO:
                  prop.setPropertyKey( PROP_EXTTYPE_MEMO, new ABTBoolean(true) );
                  break;

               default:
                  break;
            }              // end switch (extType)
         }                    // end if (extType != 0)

         //
         // If the property just-added is of type PROP_STRING, and if a maximum length specification
         // came in from the data dictionary for the property, set the maximum length extended
         // property.
         //
         long maxlen = rdd.getLength();
         if (maxlen > 0 && prop.getType() == PROP_STRING)
            prop.setPropertyKey( PROP_KMAXLEN, new ABTInteger((int) maxlen));
      }                       // end for (int i = 0; i < size; i++)

   }

   private ABTProperty getProperty(ABTPropertySet pSet, String propName)
   {
      ABTProperty prop = null;

      //
      // Loop through all of the properties.  Break out of the loop when
      // the right property is found.  This loop could be expensive, but it
      // will only be invoked upon a successful property add opertion in method
      // addProperties(), above.  Most of the time, addProperties() will fail
      // because the property has already been added by the object type's
      // setDefaultProperties() method.
      //
      int size = pSet.size();
      for (int i = 0; i < size; i++)
      {
         prop = (ABTProperty) pSet.at(i);
         if ( propName.equals(prop.getName()) )
            break;
      }

      return prop;
   }

/**
 *		Sets a list of property values into an ABTObject from a tuple
 *    addressed by an ABTCursor.  Set the properties by index, not by name, to
 *    improve performance.  This method has package scope, so it cannot be invoked by
 *    any method outside the package.
 *    @param   ps: the set of properties (for object obj) which will be retrieved from cur. This set was
 *             created from the repository data model
 *    @param   cur: the cursor reference from which values will be read
 *    @param   obj: the object into which values will be set using the properties in ps and values from cursor
 *		@return  void
 *		@exception ABTException Thrown if an unrecoverable error occurs.
 */

   public void setPropertyValues(Vector ps, ABTCursor cur, ABTObject obj) throws ABTException
   {
      PropertyIndex pi = null;
      ABTValue val = null;
      Vector piv = getPropertyIndexVector(ps);
      ABTUserSession sess = getUserSession();

      //System.out.println("Processing a " + type_ + " object");
      //
      // Loop through all of the properties and retrieve the corresponding data values
      // from the cursor.  Set the values into the destination object.  Remember that
      // repository virtual fields will NOT be retrieved and set here.  Those must be
      // retrieved and set specifically by the caller as needed.
      //
      int size = piv.size();
      for (int i = 0; i < size; i++)
      {
         pi = (PropertyIndex) piv.elementAt(i);

         if (pi.propertyIndex_ == -1)  // error
         {
            ABTError err = new ABTError (COMP_SERVERREPODRIVER,
                                         "ABTIORepoHelper->setPropertyValues()",
                                         errorMessages.SERVER_ERR_INVALID_PROPERTY,
                                         "index not found for property name '" + pi.propertyName_ + "'.");
            
            throw new ABTException(err);
         }

         val = cur.getField(pi.prapiName_);

         // Check to see if the property is an exception. If not, set the
         // property value in the object.

         if (!isPopulateException(obj, val, pi))
         {
         	//System.out.println("setPropertyValues: before setValue(): property = " + pi.propertyName_);
            //setValue(obj, pi.propertyIndex_, val);  // old code
         	//System.out.println("setPropertyValues: after cursorSetField: property = " + pi.propertyName_);
            //
            ABTValue v = null;
            try
            {
               v = obj.setValue(sess, pi.propertyIndex_, val);
            }
                catch (Exception e)
               {
                  System.out.println("Hajo - whoops");
               }

            if ( ABTError.isError( v ) )
            {
               //
               // An error occurred during the setting of an object's property.  If the object
               // reports that the property is truly "updateable," then the error that occurred
               // should not have happened and we need to throw an exception.  If the property
               // is not updateable (from the perspective of the owning object), then the error that
               // occurred is not really an error and should be ignored.  The obj.getPropertyKey(...)
               // invocation, below, should return an ABTBoolean true if the property is updateable, false
               // otherwise.
               //
                ABTValue u=null;
                try
               {

                  u = obj.getPropertyKey(sess, pi.propertyIndex_, PROP_KUPDATABLE);
               }
               catch (Exception e)
               {
                  System.out.println("Hajo - whoops");
               }
               if (ABTValue.isNull( u ) || u.booleanValue() == true )
               {
                  throw new ABTException( (ABTError) v );
               }
            }     // end if (ABTError.isError(v))
         }        // end if (!isPopulateException(..)
      }           // end for loop
   }

/**
 *		Creates a list of property names and their associated indexes into a Vector object.
 *    Adds the Vector object to a Hashtable (keyed by ABTObject type).  Only those properties
 *    which will be retrieved by the method(s) of an ABTCursor object will be in the list.  The
 *    purpose is to improve performance of setting values into an ABTObject.  Values will be set
 *    by index rather than by property name.
 *    @param   ph: the set of properties (for object obj) which will be retrieved from an
 *                ABTCursor object; this will be a subset of the total properties belonging to
 *                object obj
 *    @param   obj: the object which has the properties identified in ph
 *		@return  void
 */

	private void setPropertyIndexes(Vector ph)
	{
	   PropertyIndex pi = null;
      ABTPropertySet ps = space_.getProperties(type_);

	   //
	   // Create a new Vector object to hold each PropertyIndex instance.
	   //
	   Vector vp = new Vector();


	   Enumeration e = ph.elements();
	   while (e.hasMoreElements())
	   {
	      //
	      // Retrieve the dictionary vector element.
	      //
	      ABTRepoDataDictionary rdd = (ABTRepoDataDictionary) e.nextElement();

	      //
	      // Create a new PropertyIndex object.
	      //
         pi = new PropertyIndex();

         //
         // Populate the new PropertyIndex object.
         //
         pi.propertyName_ = rdd.getPropertyName();
         pi.propertyIndex_ = ps.indexForName(pi.propertyName_);
         pi.propertyFlags_ = 0;              // set flags initially to zero
         pi.prapiName_ = rdd.getName();
         pi.prapiFlags_ = rdd.getFlags();    // these flags are from PRField table
         vp.addElement(pi);
	   }

	   //
	   // Finally, save the vector into a local Hashtable object for retrieval later by the
	   // setPropertyValues() method. The key to the Hashtable is the object type.
	   //
	   propertyTable_.put(type_, vp);
	}

/**
 *		Sets a list of repository values from an ABTObject to a tuple
 *    addressed by an ABTCursor.  Get the properties by index, not by name, to
 *    improve performance.
 *    @param   ps: the set of properties (for object obj) which will be retrieved from obj and set into the repository
 *    @param   cur: the cursor reference to which values will be set
 *    @param   obj: the object from which values will be gotten
 *    @param   helper: the helper object which has checkExeption() method that will be called to handle
 *             exception-based writing to the repository
 *    @param   isNew: a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *             operation is an add
 *		@return  void
 *		@exception ABTException Thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
      PropertyIndex pi = null;
		ABTValue val = null;
      Vector piv = getPropertyIndexVector(ps);

      //
      // Loop through the set of eligible properties and set the corresponding data values
      // into the cursor. Prior to setting the repository data, check to see if the particular
      // field is an exception, i.e., is should NOT be written to the repository.
      //
      int size = piv.size();
      for (int i = 0; i < size; i++)
      {
         pi = (PropertyIndex) piv.elementAt(i);

         //
         // Call the isSaveException() method to verify that it is okay to write this
         // column back to the repository.  If the method returns true, then it is okay to
         // write to the repository, otherwise it's not okay.
         //
         //System.out.println("Before handling PRAPI field " + table_ + "." + pi.prapiName_ + " with object property name " + pi.propertyName_);
         if (!isSaveException(pi.prapiName_, obj, pi.prapiFlags_, isNew))
         {
         	// get value of the property
         	val = getValue(obj, pi.propertyIndex_);

         	/*
         	if (pi.propertyName_.equals("ProjectExtID"))
         	{
         	   int x = 0;
         	}
         	*/
         	
         	// if the property is null or empty, set the column to null, otherwise
         	// set it to the value of the property.
			   if (ABTValue.isNull(val) || ABTValue.isEmpty(val))
               cursorSetFieldNull(cur, pi.prapiName_);
            else
               cursorSetField(cur, pi.prapiName_, val);
         }
         //System.out.println("After handling PRAPI field " + table_ + "." + pi.prapiName_ + " with object property name " + pi.propertyName_);
      }           // end for loop

}

   /**
    *    Checks for exceptions in setting properties in an object.  This method supports
    *    exception-based populate.  This method is entered for every PRAPI field that is
    *    a candidate for being set in the object.
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @return  true if there is an exception to the property being checked and it should NOT be written;
    *             false if the property should be set in the object
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isPopulateException(ABTObject obj, ABTValue val, PropertyIndex pi) throws ABTException
   {
      boolean  ret = false;            // assume no exception

      // virtual fields are not set in the object
      if ((pi.prapiFlags_ & PR_FIELD_ISVIRTUAL) == PR_FIELD_ISVIRTUAL)
         ret = true;

      // skip a property if the SKIP_READ flag is set
      else if ((pi.propertyFlags_ & FLAG_SKIP_READ) == FLAG_SKIP_READ)
         ret = true;

      // if the object property being set is not updateable, skip reading the corresponding field from the repository
      else
      {
         ABTProperty prop = obj.getProperty(getUserSession(), pi.propertyIndex_);
         if ( !prop.isUpdatable() )
            ret = true;
      }
      return ret;
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: a boolean value which indicates whether the data being added is new to the repository, i.e., the
    *             operation is an add.
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         boolean  ret = false;            // assume no exception

         //
         // PRAPI virtual fields are never written to the repository
         //
         boolean virtual = ((prapiFlags & PR_FIELD_ISVIRTUAL) == PR_FIELD_ISVIRTUAL);
         if (virtual)
            ret = true;
         else
         {
            if (prapiName.equals(FLD_ID))    // the prID is never written
               ret = true;

            //
            // Add more exception checking logic here...
            //
         }
         return ret;
   }

   public Vector getPropertyIndexVector(Vector ps)
   {
      if (propertyTable_ == null) propertyTable_ = new Hashtable();

      //
      // Retrieve a vector of the set of properties (and their indexes) that are appropriate
      // for the type of input object.  If we haven't seen this object type before, there
      // won't be a vector present in propertyTable_.
      //
      Vector piv = (Vector) propertyTable_.get(type_);

      //
      // If we don't have a property table vector for the input object's type, create one
      // now.
      //
      if (piv == null)
      {
         setPropertyIndexes(ps);
         piv = (Vector) propertyTable_.get(type_);
      }

      return piv;
   }

/**
 * add a new row to cursor and check return code.
 * @param cur  the cursor to be add new row to
 * @exception  ABTException if error occurred
 */
protected void cursorAddNew(ABTCursor cur) throws ABTException
{
   int ret = cur.addNew();
   if (ret < 0)
   {
      ABTError err = new ABTError(COMP_SERVERREPODRIVER,
               "ABTIORepoHelper->cursorAddNew()",
               errorMessages.SERVER_ERR_CURSOR_ADDNEW,
               "cursor addNew failed when trying to save back to repository. table = " + cur.getTableName());
      throw new ABTException(err);
   }
}

/**
 * edit a cursor and check return code.
 * @param cur  the cursor to be edited
 * @exception  ABTException if error occurred
 */
protected void cursorEdit(ABTCursor cur) throws ABTException
{
   int ret = cur.edit();
   if (ret < 0)
   {
      ABTError err = new ABTError(COMP_SERVERREPODRIVER,
               "ABTIORepoHelper->cursorEdit()",
               errorMessages.SERVER_ERR_CURSOR_EDIT,
               "cursor edit failed when trying to save back to repository. table = " + cur.getTableName());
      throw new ABTException(err);
   }
}

/**
 * update a cursor and check return code.
 * @param cur  the cursor to be updated
 * @exception  ABTException if error occurred
 */
protected void cursorUpdate(ABTCursor cur) throws ABTException
{
   int ret = cur.update();
   if (ret < 0)
   {
      ABTError err = new ABTError(COMP_SERVERREPODRIVER,
               "ABTIORepoHelper->cursorUpdate()",
               errorMessages.SERVER_ERR_CURSOR_UPDATE,
               "cursor update failed when trying to save back to repository. table = " + cur.getTableName());
      throw new ABTException(err);
   }
}

/**
 * sets a field in cursor and check return code.
 * @param cur  the cursor to be set
 * @exception  ABTException if error occurred
 */
protected void cursorSetField(ABTCursor cur, String fieldName, ABTValue val) throws ABTException
{
   int ret = cur.setField(fieldName, val);
   if (ret < 0)
   {
      ABTError err = new ABTError(COMP_SERVERREPODRIVER,
               "ABTIORepoHelper->cursorSetField()",
               errorMessages.SERVER_ERR_CURSOR_SETFIELD,
               "cursor setField failed.  table = " + cur.getTableName() +
               ", field = " + fieldName + ", value = " + val.stringValue());
      throw new ABTException(err);
   }
}

/**
 * sets a field in cursor to null and check return code.
 * @param cur  the cursor to be set
 * @exception  ABTException if error occurred
 */
protected void cursorSetFieldNull(ABTCursor cur, String fieldName) throws ABTException
{
   int ret = cur.setFieldNull(fieldName);
   if (ret < 0)
   {
      ABTError err = new ABTError(COMP_SERVERREPODRIVER,
               "ABTIORepoHelper->cursorSetFieldNull()",
               errorMessages.SERVER_ERR_CURSOR_SETFIELD,
               "cursor setFieldNull failed.  table = " + cur.getTableName() + ", field = " + fieldName);
      throw new ABTException(err);
   }
}

/**
 * Releases the cursor.
 *	@param cursor: the cursor to be released.
 */
   protected void closeCursor(ABTCursor cursor)
   {
      if (cursor != null)
      {
         cursor.release();
         cursor = null;
      }
   }

/**
 * gets remote id from an object and retrievs the repository id from it.
 * @param obj the object to retrieve repo id from.
 * @return    the repository id or -1 if the object does not have a
 *            repository remote id.
 * @exception  ABTException if error occurred
 */
   protected long getRepoID(ABTObject obj) throws ABTException
   {
      ABTValue rmtID = obj.getID().getRemote( getUserSession() );
      checkError(rmtID);

      if (!ABTValue.isNull(rmtID) && (rmtID instanceof ABTRemoteIDRepository))
         return ((ABTRemoteIDRepository) rmtID).getRepositoryID();

      return -1;
   }
   
   private void addSpecialProperty(String objectType)
   {
      ABTError testError = space_.addProperty
                        (  objectType,
                           SPECIAL_PROPERTY,
                           SPECIAL_PROPERTY,
                           PROP_BOOLEAN,
                           false,
                           true,
                           true,
                           false, //transient
                           null,
                           null,
                           ABTBoolean.True()
                        );

      //
      // Find the special property object just added.
      //
      ABTPropertySet pSet = space_.getProperties(objectType);
      ABTProperty prop = getProperty(pSet, SPECIAL_PROPERTY);

      if (prop != null)
      {
         prop.setPropertyKey(PROP_KEDITABLE, ABTBoolean.False());
         prop.setPropertyKey(PROP_KHIDDEN,   ABTBoolean.True());
      }

   }
   
   private boolean specialPropertyIsAdded(String objectType)
   {
      ABTPropertySet pSet = space_.getProperties(objectType);
      return (pSet.indexForName(SPECIAL_PROPERTY) < 0 ?  false : true);
   }
}