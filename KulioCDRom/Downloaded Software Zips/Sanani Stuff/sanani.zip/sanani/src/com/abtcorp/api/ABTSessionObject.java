package com.abtcorp.api;

/*
 * ABTSessionObject.java 05/26/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
*                         Initial Implementation.
* 08-05-98    MXA         Added Serializable and writeObject() and  readObject()
*
*/

import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.core.*;
import java.io.Serializable;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

public class ABTSessionObject extends ABTValue implements Serializable
{
    private com.abtcorp.hub.ABTObjectSpace _os;
    private Object _wrappedObj;
    private ABTUserSession _session;
    private IABTAPIMonitor _monitor;

   public ABTSessionObject(ABTSessionObject session, Object wrapped) {
      _wrappedObj = wrapped;
      if (session != null){
         _session = (ABTUserSession)session.getUserSession();
         _os = session.getHubObjectSpace();
         _monitor = session.getMonitor();
         }
      else _session = null;
      }

   public ABTSessionObject(com.abtcorp.hub.ABTObjectSpace hubObjSpace){
      _wrappedObj = hubObjSpace;
      _os = hubObjSpace;
      _session = null;
      }

   private ABTValue wrappedABTValue() {
      if (_wrappedObj instanceof ABTValue)
         return (ABTValue) _wrappedObj;
      return null;
      }

   public void setMonitor(IABTAPIMonitor monitor){
      _monitor = monitor;
      }
         
   public IABTAPIMonitor getMonitor(){
      return _monitor;
      }
      
   private void writeObject(ObjectOutputStream out ) throws IOException{
      try{
      out.writeObject(_wrappedObj);
      }catch(IOException e){
       throw (e);
      }
   }

   private void readObject(ObjectInputStream in ) throws IOException, ClassNotFoundException
   {
      try{
      _wrappedObj = in.readObject();
      } catch (IOException e){
       throw (e);
      } catch (ClassNotFoundException e){
       throw (e);
      }
   }

    public ABTUserSession getUserSession(){
      if (_session == null)
         System.out.println("********** error in API layer.  Null User Session. *****");
      return _session;
    }

    protected void setUserSession(ABTUserSession s) {
      if (_session != null)
         return;
      _session = (ABTUserSession)s;
      if (_session == null)
         System.out.println("********** error in API layer.  Null User Session. *****");
    }

    public void setUserSession(ABTSessionObject s) {
      if (_session != null)
         return;
      _session = (ABTUserSession)s.getUserSession();
      _os = s.getHubObjectSpace();
    }

    public Object getUserSessionObject() {
      return _session;
    }

    public com.abtcorp.hub.ABTObjectSpace getHubObjectSpace() {
      return _os;
    }

    protected void setHubObjectSpace(com.abtcorp.hub.ABTObjectSpace os) {
      _os = os;
    }

    public boolean hasSession(){ return _session != null;  }

    public Object getObject()
      {return _wrappedObj; }

    public void setObject(Object wrapped)
      { _wrappedObj = wrapped; }


   // ABTValue methods
   public int hashCode()               {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.hashCode();
      return super.hashCode();
      }
   public String toString()            {  return _wrappedObj.toString();    }
   public boolean booleanValue()       {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.booleanValue();
      return super.booleanValue();
      }
   public short   shortValue()         {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.shortValue();
      return super.shortValue();
      }
   public int     intValue()           {
      ABTValue obj = wrappedABTValue();
      if (obj != null)   return obj.intValue();
      return super.intValue();
      }
   public double  doubleValue()        {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.doubleValue();
      return super.doubleValue();
      }
   public String  stringValue()        {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.stringValue();
      return super.stringValue();
      }
   public ABTDate dateValue(boolean pm){
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.dateValue(pm);
      return super.dateValue(pm);
      }
   public ABTTime timeValue()          {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.timeValue();
      return super.timeValue();
      }

   public ABTValue eval() {return this;}
   public Object clone()  {return null;}// ??

   public boolean equals(Object other){
      if (other instanceof ABTSessionObject)
         return _wrappedObj.equals(((ABTSessionObject)other).getObject());
      return _wrappedObj.equals(other);
      }
   public int compareTo(Object other)
   {
      if (other == null) return 1;
      ABTValue obj = wrappedABTValue();
      if (other instanceof ABTSessionObject)
         return obj.compareTo(((ABTSessionObject)other).getObject());
      return obj.compareTo(other);
      }

   public String dump(int indent, int level) {
      ABTValue obj = wrappedABTValue();
      if (obj != null)  return obj.dump(indent, level);
      return null;
      }
}