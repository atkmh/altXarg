/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTString.java, 21, 12/11/98 11:16:54 AM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.io.*;
import java.text.*;

public class ABTString extends ABTImmutableValue
{
   // We cannot extend from String since it is final

   private static final long serialVersionUID = -6849794470754667710L;

   protected String value_;

    public void fromByte(byte[] input){};
    public byte[] fromByte(){ return null;};

   public ABTString(String value)   {value_ = value; }
   public ABTString(ABTValue value) {value_ = value.stringValue();}

   // TODO: booleanValue should be localized

   public boolean booleanValue() {return Boolean.valueOf(value_).booleanValue();}

   public short shortValue()
   {
      try {
         return NumberFormat.getInstance().parse(value_).shortValue();
      } catch (ParseException exception) {
         return 0;
      }
   }

   public int intValue()
   {
      try {
         return NumberFormat.getInstance().parse(value_).intValue();
      } catch (ParseException exception) {
         return 0;
      }
   }

   public double doubleValue()
   {
      try {
         return NumberFormat.getInstance().parse(value_).doubleValue();
      } catch (ParseException exception) {
         return 0;
      }
   }

   public ABTDate dateValue(boolean pm)
   {
      try {
         return new ABTDate(DateFormat.getDateInstance(DateFormat.SHORT).parse(value_), false);
      } catch (ParseException exception) {
         return null;
      }
   }

   public String stringValue() {return value_;}

   public ABTTime timeValue()
   {
      try {
         return new ABTTime(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).parse(value_));
      } catch (ParseException exception) {
         return null;
      }
   }

    /**
     * Returns a hashcode for this string.
     *
     * @return  a hash code value for this object. 
     */
    protected int myHashCode;
    protected boolean doneHashCode = false;
    public int hashCode() {
        if (doneHashCode) return myHashCode;
	    int h = 0;
	    int off = 0;
	    String val = value_;
	    int len = value_.length();

	    if (len < 16) {
 	        for (int i = len ; i > 0; i--) {
 		    h = (h * 37) + Character.toUpperCase(val.charAt(off++));
 	        }
 	    } else {
 	        // only sample some characters
 	        int skip = len / 8;
 	        for (int i = len ; i > 0; i -= skip, off += skip) {
 		    h = (h * 39) + Character.toUpperCase(val.charAt(off));
 	        }
 	    }
        doneHashCode = true;
        myHashCode = h;
	    return myHashCode;
    }

   // Warning: This is a loose compare since we will convert the argument
   //          using formating

   public int compareTo(Object object) 
   {
    if (object == null) return 1;     
    return compareTo(((ABTValue)object).stringValue());
   }

   public final int compareTo(String string)
   {
      if ( string == null )
        return +1;  // something is greater than nothing
      
      if (value_ == string) return 0;   // they're the SAME string

      int mylen = value_.length();
      int itlen = string.length();
      int minlen = Math.min(mylen,itlen);
      // go through the strings and compare letter by letter
      for (int i = 0; i < minlen; ++i){
        char myByte = value_.charAt(i);
        char itByte = string.charAt(i);
        if (myByte == itByte) continue; // exact match
        
        char mybyte = Character.toUpperCase(myByte);
        char itbyte = Character.toUpperCase(itByte);
        if (mybyte == itbyte) continue; // case match
        
        // the characters just don't match
        if (mybyte > itbyte) return +1;
        return -1;
        }
      
      if (mylen == itlen) return 0; // same length, all characters match, they're equal
      // strings are different lengths, but first part matches
      if (mylen < itlen) return -1; // I'm shorter, and therefore less
      return 1;                     // I'm longer
   }

   public final int compareToReal(ABTValue string)
   {
      if (string == null) return +1;
      return value_.compareTo(string.stringValue());
   }

   public boolean equals(Object object)
   {
      if (this == object) return true;  // The easy one
      if (object == null) return false; // Still pretty easy
      if (object instanceof ABTString){
        ABTString str = (ABTString)object;
        return (value_.equalsIgnoreCase(str.stringValue()));
        }
      return (value_.equalsIgnoreCase(object.toString()));
   }

   // This optimizes the serialization

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeUTF(value_);
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      value_ = stream.readUTF();
   }


   /**
    *    Normalizes a string that may have single quote marks in it.  For every
    *    single quote mark found in the string, inserts another quote mark at the
    *    same spot, effectively doubling the number of single quotes in the string.
    *    After the input string is normalized, the entire string is enclosed in single
    *    quote marks. The resultant string is suitable for use by the Sanani string parser.
    *    This method is similar in behavior to the PRAPI Repository.sqlString() method.
    *    @param s is a String that may or may not contain single quote characters
    *    @return a String object with all single quotes normalized (escaped).  The entire
    *    string is enclosed in single quote marks.
    */
   public static String normalizeQuotes(String s)
   {
      StringBuffer sb = new StringBuffer(s);
      int offset = s.length() - 1;     // compute initial offset value to use
      
      //
      // For each single quote found in the input string, insert another single
      // quote at the same spot in a StringBuffer copy of the input string.  If
      // there are no single quote marks in the input string, bypass doing any
      // insertions.
      //
      // The input string is scanned right-to-left.
      //
      while ( (offset >= 0) && (offset = s.lastIndexOf( '\'', offset)) >= 0 )
      {
         sb.insert(offset, '\'');
         offset--;
      }
      
      //
      // Insert a leading quote mark.  Append a trailing quote mark.
      //
      sb.insert(0, '\'');
      sb.append('\'');
      
      return sb.toString();
   }

   /**
    *    Normalizes a string that may have single quote marks in it.  For every
    *    single quote mark found in the string, inserts another quote mark at the
    *    same spot, effectively doubling the number of single quotes in the string.
    *    The resultant string is suitable for use by the Sanani string parser.
    *    @param s is an ABTString that may or may not contain single quote characters
    *    @return a String object with all single quotes normalized (escaped)
    */
   public static String normalizeQuotes(ABTString s)
   {
      return normalizeQuotes( s.stringValue() );
   }
   
   
}