/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

/** @com.register(clsid=A2FAB783-BDD1-11D1-ADE6-00E029143BC6,
                typelib=A2FAB780-BDD1-11D1-ADE6-00E029143BC6,
                progid="com.abtcorp.api.com.ABTObjectSpaceCOM.1",
                version="1.9.2")*/

public class ABTObjectSpaceCOM implements IABTObjectSpaceCOM
{
   public ABTObjectSpaceCOM()
      { this(new ABTObjectSpaceLocal()); }

   public ABTObjectSpaceCOM(IABTObjectSpace osp)
      {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(osp);
      /**/
      }
   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   private IABTObjectSpace _space;
   private IABTObjectSpace space() {
      if (_space == null) _space = (IABTObjectSpace)getObject();
      return _space;
      }

   /**
   * add a listener
   * @param Listener - caller
   * @param target - listen to
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   public void  addListener(IABTListenerCOM Listener, IABTObjectCOM target, int parameterindex_)
      {
//      ListenerProxy pxy = new ListenerProxy(Listener);
//      space().addListener(pxy,(ABTObjectProxy)target.getObject(),parameterindex_);
      }

   /**
   * remove a particular listener 
   * @param Listener - caller
   * @param target - listen to or null for all
   * @parameterindex_ - fieldindex to listen to or -1 for all
   */
   public void removeListener(IABTListenerCOM Listener, IABTObjectCOM target, int parameterindex_)
      {
//      space().removeListener((ListenerProxy)Listener.getProxy(),(ABTObject)target.getObject(),parameterindex_);
      }

   /**
   * remove a particular target from the listener list
   * @param target - object to be removed
   */
   public void removeListenedTo(IABTObjectCOM target)
      {
//      space().removeListenedTo((ABTObjectProxy)target.getObject());
      }

 /**
 * Get the propertySet for a given ObjectSet
 * @param object - ABTObjectSet to inspect
 * @return ABTPropertySet - properties for this object or null for error
 */
 public IABTPropertySetCOM getProperties(String type)
 {
   return new ABTPropertySetCOM( space().getProperties(type));
 }

 /**
 * Get the propertySet for a given ObjectType
 * @param type  - name of type
 * @return ABTPropertySet - properties for this object or null for error
 */
 public IABTPropertySetCOM getTypeProperties(String type)
 {
   return new ABTPropertySetCOM( space().getProperties(type));
 }

 /**
 * Get the current classpath for rule objects (e.g. ABTTask)
  * @return String - current path to rule objects
  */
 public String getRulebase()
 {
   return space().getRulebase();
 }


 /**
 *  loads a rule if necessary and attempts to add the property 
 *  to it
 *  @param rule name of rule to load (e.g. 'ABTTask')
 *  @param name_ - name of property
 *  @param caption_ - caption of property
 *  @param type_  valid type of property
 *  @param virtual_ true if property does not occupy physical storage
 *  @param visible_ true if this property can be retrieved
 *  @param updatable_ true if this property is updatable
 *  @param transient_ true if this property is transient
 *  @param referenceType_ name of Rule if this property is an objectSet/Object
 *  @param propertyRule_ name of property-rule file or null if no specific rules
 *  @return ABTError - or null if none
 * ToDo:  
 */
   public IABTErrorCOM addProperty(  String rule_,
                                 String name_,
                                 String caption_,
                                 int type_,
                                 boolean virtual_,
                                 boolean visible_,
                                 boolean updatable_,
                                 boolean transient_,
                                 String referenceType,
                                 String propertyRule,
                                 Variant defaultValue
                                 )
   {

   String rType;
   String pRule;
   if (referenceType != null && referenceType.length() == 0)
      rType = null;
   else
      rType = referenceType;

   if (propertyRule != null && propertyRule.length() == 0)
      pRule = null;
   else
      pRule = propertyRule;

   ABTError ap = space().addProperty(rule_,
                            name_,
                            caption_,
                            type_,
                            virtual_,
                            visible_,
                            updatable_,
                            transient_,
                            rType,
                            pRule,
                            VariantMunger.VariantToValue(defaultValue));
   if (ap == null) return null;
   return new ABTErrorCOM(ap);
   }

 /**
 *  Create a new ABTObject based on a given type with the new name with the subset of properties
 *  @param baseType - base type name
 *  @param id - remote id of target object
 *  @return ABTValue - newly instantiated ABTObject or ABTError for error
 * ToDo:  
 *   1 - through appropriate exception for classnotfound or invalid classname
 *   2-  optimize the class loading (i.e. allow UDCs through byte-loading...)
 */
 public Variant createNewObject(String type, IABTHashTableCOM requiredParameters)
 {
   IABTHashTable iht = null;
   if (requiredParameters != null) iht = (IABTHashTable)requiredParameters.getObject();
   return VariantMunger.ValueToVariant(space().createNewObject(type,iht));
 }

 public Variant createObject(String type, IABTRemoteIDCOM remoteID, IABTHashTableCOM requiredParameters)
 {
   // NOTE:  THERE IS NO WAY FOR A CLIENT TO ACTUALLY GET A REMOTEIDCOM
   IABTHashTable iht = null;
   ABTRemoteID rid = null;
   if (requiredParameters != null) iht = (IABTHashTable)requiredParameters.getObject();
   if (remoteID != null) rid = (ABTRemoteID)remoteID.getObject();
   return VariantMunger.ValueToVariant(space().createObject(type,rid,iht));
 }
 
public Variant createNewObjectSet( String type)
   {
   return VariantMunger.ValueToVariant(space().createNewObjectSet(type));
   }

 public Variant findObject(  String subType, String expression) {
   return VariantMunger.ValueToVariant(space().findObject(subType, expression));
   }

 public Variant findObjectByID( String subType, IABTLocalIDCOM id) {
   IABTLocalID lid = (IABTLocalID)id.getObject();
   return VariantMunger.ValueToVariant(space().findObjectByID(subType, lid));
   }

 public Variant findObjectByRemoteID( String subType, IABTRemoteIDCOM id){
   ABTRemoteID rid = (ABTRemoteID)id.getObject();
   return VariantMunger.ValueToVariant(space().findObjectByRemoteID(subType,rid));
   }

 public IABTErrorCOM startSession(IABTHashTableCOM sessionIdentifiers) {
   IABTHashTable iht = null;
   if (sessionIdentifiers != null) iht =(IABTHashTable)(sessionIdentifiers.getObject());
   space().startSession(iht);
   return null;
   }

 public IABTErrorCOM endSession() {
   space().endSession();
   return null;
   }

 public IABTErrorCOM startTransaction() { 
   ABTError er = space().startTransaction();
   if (er == null) return null;
   return new ABTErrorCOM(er);
   }

 public IABTErrorCOM commitTransaction(){
   ABTError er = space().commitTransaction();
   if (er == null) return null;
   return new ABTErrorCOM(er);
   }

   public IABTErrorCOM rollbackTransaction(){
   ABTError er = space().rollbackTransaction();
   if (er == null) return null;
   return new ABTErrorCOM(er);
   }

   public void doGarbageCollection(){
      System.gc();
      }


   // API layer helper methods
   public IABTArrayCOM       newABTArray(){
      return new ABTArrayCOM(space().newABTArray());
      }

   public IABTSortedArrayCOM newABTSortedArray(){
      return new ABTSortedArrayCOM(space().newABTSortedArray());
      }

   // This one isn't useful, because COM clients don't have ABTComparators
   public IABTSortedArrayCOM newABTSortedArray(ABTComparator comp){
      return new ABTSortedArrayCOM(space().newABTSortedArray(comp));
      }

   public IABTHashTableCOM   newABTHashTable(){
      return new ABTHashTableCOM(space().newABTHashTable());
      }

   public IABTDriverCOM      newABTDriver(String className, IABTHashTableCOM args){
      IABTHashTable largs;
      if (args == null)
         largs = null;
      else{
         try{
            largs = (IABTHashTable)args.getObject();
            }
         catch (Exception e){
            return null;
            }
         }
      return new ABTDriverCOM(space().newABTDriver(className, largs));
      }

}
