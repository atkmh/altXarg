package com.abtcorp.io.siterepo;

/*
 * ABTSiteRepoDriver.java 07/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
* HISTORY:
*
* Date        Author      Description
* 07-16-98    LZX         Initial Implementation.
* 08-04-98    SOB         Mods to support importing of com.abtcorp.io.server.*;
*
*/

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTExtendedPropertyList;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.objectModel.abt.*;
import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTSiteRepoDriver is the ABT Repository driver for the global/site object.
 *  It is instantiated by the applications.
 *
 *  <pre>
 *       ABTSiteRepoDriver driver = new ABTSiteRepoDriver();
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTDriver, ABTRepositoryDriver
 */

public class ABTSiteRepoDriver extends ABTRepositoryDriver implements IABTSiteRepoConstants, com.abtcorp.idl.IABTRuleConstants
{
   private static String component_ = "ABTSiteRepoDriver";
	private Hashtable resHash_ = null;
	private Hashtable estHash_ = null;
	private Hashtable custFieldHash_ = null;
	private Hashtable adjHash_ = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 * ABTSiteRepoDriver default constructor.
 */
   public ABTSiteRepoDriver()
   {
   	super();
   }

/**
 *	Create an ABTRepositoryDriver that is associated with an ABTObjectSpace.
 *	@param space: The ABTObjectSpace object with which this ABTRepositoryDriver is associated.
 * @param session: the reference to the user session.
 */
   public ABTSiteRepoDriver(ABTObjectSpace space, ABTUserSession session)
   {
      super(space, session);
   }


//====================================================================================
// public methods (populate, save, etc.)
//====================================================================================

/**
 *		Opens a connection to a specific ABT Repository.  This version of open() overrides
 *    the parent class's version of open() because we want to retry login processing if
 *    loginAs fails.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return  true  open succeeded; false: open failed
 */
	public ABTValue open(ABTObjectSpace space, ABTUserSession usersession, ABTHashtable args)
	{
   	ABTValue val = null;    // assume success

      try
      {
         setSpace(space);
         setUserSession(usersession);        // object space session
         String repoName = null;
         String userID = null;
         String password = null;
         String product = null;

         ABTSession session = getSession();  // repository session

         // first see if there are any login arguments in the hashtable
         if (args != null && args.size() > 0)
         {
            repoName = getStringValue(args, KEY_REPONAME);
            userID = getStringValue(args, KEY_USERNAME);
            password = getStringValue(args, KEY_PASSWORD);
            product = getStringValue(args, KEY_PRODUCT);
         }

      	//
      	// If there is no repository session, perform some type of login.  Which type
      	// of login processing will be performed depends upon whether a user ID and
      	// password are present.
      	//
      	if (session == null)
      	{
      		if (userID == null && password == null)
      		   session = ABTSession.login();
      		else
      		{
      		   session = ABTSession.loginAs(userID, password);

      		   // pop up a login dialog box is loginAs fails.
      		   //
      		   // NOTE: This functionality is a request from the client app developers.
      		   // If the driver runs remotely, the client will not see the login prompt.
      		   //
      		   if (session == null)
      		      session = ABTSession.login();
      		}

      	   //
      	   // If we still don't have a valid repository session, we can't proceed.
      	   // Return false to the caller.
      	   //
      	   if (session == null)
      	   {
               return new ABTError(component_,
                  MOD_OPEN,
                  errorMessages.ERR_UNABLE_TO_CONNECT,
                  "Unable to connect to repository " + getRepositoryName() + " with user " + getUser());
      	   }
      		setSession(session);
         }

         //
         // Perform the parent's open() processing to pick up licensing, etc.
         // The parent's open() will also establish a connection to the desired repository, if
         // that is required.
         //
         val = super.open(space, usersession, args);
      }  // end try

      catch (Exception e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_OPEN, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Error e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_OPEN, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      finally
      {
      }

      return val;
   }


/**
 *		Populates the ABTObjectSpace with site object from the ABT Repository.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.  If an error occurs, an ABTError is returned.
 */
   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
   	ABTValue val = null;
   	ABTObject site = null;
      boolean transactionStarted = false;

      val = checkParms(space, session, args, MOD_POPULATE);
      if (ABTError.isError(val))
         return val;

      // get populate type from hash table
      String type = getStringValue(args, KEY_TYPE);

      // default type to "all" if it's not specified.
      if ((type == null) || (type.length() == 0))
         type = TYPE_ALL;

      try
      {
         // start the transaction now
         session.startTransaction();
         transactionStarted = true;

         // populate all the global objects
         if (type.equalsIgnoreCase(TYPE_ALL))
            val = processAllGlobals(POPULATE, null, args);

         // populate site object (including site calendar, type codes
         // and charge codes)
         else if (type.equalsIgnoreCase(TYPE_SITE))
            val = processSite(POPULATE, args);

         // populate other types of global objects
         else
         {
            val = getSite();
            if (val instanceof ABTObject)
            {
               site = (ABTObject)val;

               if (type.equalsIgnoreCase(TYPE_RESOURCE))
                  val = processResource(POPULATE, site, args);

               else if (type.equalsIgnoreCase(TYPE_CUSTOMFIELD))
                  val = processCustomField(POPULATE, site, args);

               else if (type.equalsIgnoreCase(TYPE_ESTMODEL))
                  val = processEstModel(POPULATE, site, args);

               else if (type.equalsIgnoreCase(TYPE_ADJRULE))
                  val = processAdjRule(POPULATE, site, args);

               else if (type.equalsIgnoreCase(TYPE_CALENDAR))
                  val = processCalendar(POPULATE, site, args);

               else if (type.equalsIgnoreCase(TYPE_TIMEPERIOD))
                  val = processTimePeriod(POPULATE, site, args);

               else
                  val = new ABTError(component_,
                     MOD_POPULATE,
                     errorMessages.ERR_INVALID_TYPE,
                     "The input type '" + type + "' is not supported for populate.");
            }  // if val
            else
               val = new ABTError(component_,
                  MOD_POPULATE,
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  "Site object must be populated first. It is not found in the object space.");
         }
      }  // end try-block

      catch (ABTException e)
      {
         // turn exception into error
         val = e.getError();
         if (val == null)
            val = new ABTError(component_, MOD_POPULATE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Exception e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_POPULATE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Error e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_POPULATE, errorMessages.ERR_ERROR_OCCURRED, e);
      }

      // If an error occurred, roll back the transaction.
      if (transactionStarted)
      {
         if (ABTError.isError(val))
            session.rollbackTransaction();
         else
            session.commitTransaction();
         transactionStarted = false;
      }

      if ((val instanceof ABTError)
         || (type.equalsIgnoreCase(TYPE_ALL))
         || (type.equalsIgnoreCase(TYPE_SITE)))
         return val;
      else
         return site;
   }


/**
 *		Saves object or objectset identified in the hashtable back to the repository.
 *		User must have "prMethodologyAuthor" right in order to write data to the repository.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *    @return ABTValue ABTError if an error occurred; null, otherwise.
 */

   public ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue val = null;
      ABTObject site = null;

      // check space, user session, repository, etc.
      val = checkParms(space, session, args, MOD_SAVE);
      if (ABTError.isError(val))
         return val;

      // Verify the rights of this user. Must be method author.
      if (!getRepository().checkRight("prMethodAuthor"))
         return new ABTError(component_,
                  MOD_SAVE,
                  errorMessages.ERR_INSUFFICIENT_RIGHT,
                  "user " + getUser() + " does not have prMethodAuthor right");

      try
      {
         // site is a required input parameter
         val = (ABTValue) args.getItemByString(KEY_SOURCE);

         // make sure site is not empty and is of correct object type.
         if (ABTValue.isNull(val)
            || !(val instanceof ABTObject)
            || (((ABTObject)val).getObjectType() != OBJ_SITE ))
            return new ABTError(component_,
               MOD_SAVE,
               errorMessages.ERR_OBJECT_NOT_FOUND,
               "Source (site object) must be provided. The input source is null, empty or not a site object.");
         else
            site = (ABTObject)val;

         // get object type from hash table
         String type = getStringValue(args, KEY_TYPE);

         // default type to "all" if it's not specified.
         if ((type == null) || (type.length() == 0))
            type = TYPE_ALL;

         // save all the global objects that are applied (i.e., only MM globals.)
         if (type.equalsIgnoreCase(TYPE_ALL))
            val = processAllGlobals(SAVE, site, args);

         // save resource objects only
         else if (type.equalsIgnoreCase(TYPE_RESOURCE))
            val = processResource(SAVE, site, args);

         // save custom field objects only
         else if (type.equalsIgnoreCase(TYPE_CUSTOMFIELD))
            val = processCustomField(SAVE, site, args);

         // save est model objects only
         else if (type.equalsIgnoreCase(TYPE_ESTMODEL))
            val = processEstModel(SAVE, site, args);

         // save adjustment rule objects only
         else if (type.equalsIgnoreCase(TYPE_ADJRULE))
            val = processAdjRule(SAVE, site, args);

         // other types are not supported for save
         else
            return new ABTError(component_,
               MOD_SAVE,
               errorMessages.ERR_INVALID_TYPE,
               "The input type '" + type + "' is not supported for save.");

      }                    // end try block

      catch (ABTException e)
      {
         // turn exception into error.
         val = e.getError();
         if (val == null)
            val = new ABTError(component_, MOD_SAVE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Exception e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_SAVE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Error e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_SAVE, errorMessages.ERR_ERROR_OCCURRED, e);
      }

      finally
      {
      }

      return val;
   }


/**
 *		executes special commands issued by the user.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.  If an error occurs, an ABTError is returned.
 */
   public ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      boolean lock = false;
      ABTValue val = null;

      val = checkParms(space, session, args, MOD_EXECUTE);
      if (ABTError.isError(val))
         return val;

      try
      {
         // get command from the hash table
         String cmd = getStringValue(args, KEY_COMMAND);

         // get type from hash table
         String type = getStringValue(args, KEY_TYPE);

         if (cmd.equalsIgnoreCase(CMD_LIST))
         {
            // get list of resources from repository
            if (type.equalsIgnoreCase(TYPE_RESOURCE))
               val = getResCats();

            else
               // call the super execute to deal with other types (repository, etc.)
               val = super.execute(space, session, args);
         }
         else
            // input command is invalid
            val = new ABTError(component_,
                     MOD_EXECUTE,
                     errorMessages.ERR_INVALID_COMMAND,
                     "Command " + cmd +  " is not supported." );

      }                    // end try block

      catch (Exception e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_EXECUTE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      catch (Error e)
      {
         // turn exception into error.
         val = new ABTError(component_, MOD_EXECUTE, errorMessages.ERR_ERROR_OCCURRED, e);
      }
      finally
      {
      }

      return val;
   }

//====================================================================================
// private methods
//====================================================================================

/**
 *	populate all the global objects from the repository.
 * @param refresh whether or not to refresh the objects
 * @param args    the input parameter hashtable
 *	@return the site object if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processAllGlobals(int command, ABTObject site, ABTHashtable args) throws ABTException
   {

      // for populate or refresh, get site data from repository
      if (command != SAVE)
      {
         ABTValue val = processSite(command, args);

         if (val instanceof ABTObject)
            site = (ABTObject) val;
         else
         {
            processError(component_,
                     "processAllGlobals",
                     errorMessages.ERR_RECORD_NOT_FOUND,
                     "Site data is not found in the repository." );
            return null;
         }
      }

      // process time periods
      processTimePeriod(command, site, args);

      // process resources (including base calendars and notes)
      processResource(command, site, args);

      // process estimating models
      processEstModel(command, site, args);

      // process adjustment rules
      processAdjRule(command, site, args);

      // process custom fields (including custom enums and aggregate fields)
      processCustomField(command, site, args);

      return site;
   }


/**
 *	populate or refresh site object along with type codes and charge codes from the repository.
 * @param refresh whether or not to refresh the objects
 * @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
private ABTValue processSite(int command, ABTHashtable args) throws ABTException
   {
      ABTObject site = null;
      ABTValue val = null;

      // Instantiate a site helper object and invoke its populate() or refresh()
      // method depending on the input command.

      Site siteHelper = new Site(this);

      switch (command)
      {
         case POPULATE:
            // populate the site object (overrides the populate() from super class)
            val = siteHelper.populate();
            break;

         case SAVE:  // no save for site
         default:
      }

      return val;
   }


/**
 *	populate, save or refresh resource objects from the repository.
 * @param command what to do
 * @param site    the site object
 * @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processResource(int command, ABTObject site, ABTHashtable args) throws ABTException
   {
      ABTValue val = null;
      String query = null;

   	// process the resources
      Resource helper = new Resource(this, site);

      switch (command)
      {
         case POPULATE:
            // check if resource category is specified
            String cat = getStringValue(args, KEY_CATEGORY);

            if (cat != null)
            {
               // category is specified
               if (cat.length() > 0)
                  query = QRY_RESOURCEBYCAT + getRepository().sqlString(cat);
               else
                  // category is specified as an empty string
                  query = QRY_RESOURCEBYNULLCAT;

               // select resource by category and populate using the cursor
               // (NTOE: this populate method will skip the populateFirstPass() where
               // the objects in the space may be deleted if they are not found in the
               // cursor which will cause problems here since the resources selected by
               // category may not contain the resource roles or other categories
               // populated previously.)
               ABTCursor resCur = helper.getCursor(query, TBL_RESOURCE + "." + FLD_ID);
               val = helper.populate(resCur, true);
               helper.closeCursor(resCur);
            }
            else
            {
               // all the resource roles
               query = QRY_RESOURCEROLES;
               val = helper.populate(OFD_RESOURCES, query);
            }
            break;

         case SAVE:
            // use the query that selects all resources instead of only resource
            // roles because we want to make sure that the new resouce roles
            // beings saved are unique in the repository.
            val = helper.save(site, OFD_RESOURCES, QRY_RESOURCES);
            break;

         default:
            // error
      }

      return val;
   }

/**
 *	populate, save or refresh estimating model objects from the repository.
 * @param command what to do
 * @param site    the site object
 * @param args    the input parameter hashtable
 *	@return the estimating model object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processEstModel(int command, ABTObject site, ABTHashtable args) throws ABTException
   {
      ABTValue val = null;

   	// process estimating models.
      EstModel helper = new EstModel(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate(OFD_ESTMODELS, QRY_ESTMODELS);
            break;

         case SAVE:
            val = helper.save(site, OFD_ESTMODELS, QRY_ESTMODELS);
            break;

         default:
            // error
      }

      return val;
   }


/**
 *	populate, save or refresh custom field objects along with aggregate fields
 * and custom enums from the repository.
 * @param command what to do
 * @param site    the site object
 * @param args    the input parameter hashtable
 *	@return the custom field object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
private ABTValue processCustomField(int command, ABTObject site, ABTHashtable args) throws ABTException
   {
      ABTValue val = null;

      CustomField helper = new CustomField(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate(OFD_CUSTOMFIELDS, QRY_CUSTOMFIELDS);
            break;

         case SAVE:
            val = helper.save(site, OFD_CUSTOMFIELDS, QRY_CUSTOMFIELDS);
            break;

         default:
            // error
      }
      return val;  // return the custom field object set
 }


/**
 *	populate, save or refresh adjustment rule objects from the repository.
 * @param command what to do
 * @param site    the site object
 * @param args    the input parameter hashtable
 *	@return the adjustment rule object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
   private ABTValue processAdjRule(int command, ABTObject site, ABTHashtable args) throws ABTException
   {
      ABTValue val = null;

   	// process estimating models.
      AdjRule helper = new AdjRule(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate(OFD_ADJRULES, QRY_ADJRULES);
            break;

         case SAVE:
            val = helper.save(site, OFD_ADJRULES, QRY_ADJRULES);
            break;

         default:
            // error
      }

      return val;
   }

/**
 *	populate or refresh base calendar objects from the repository.
 * @param command what to do
 * @param site    the site object
 * @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */

private ABTValue processCalendar(int command, ABTObject site, ABTHashtable args) throws ABTException
   {
      ABTValue val = null;

      Calendar helper = new Calendar(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate(OFD_CALENDARS, QRY_BASECALENDARS);
            break;

         case SAVE:  // no save for calendar
         default:
      }

      return val;
   }

/**
 *	populate or refresh time period objects from the repository.
 * @param command what to do
 * @param site    the site object
 * @param args    the input parameter hashtable
 *	@return the resource object set if succeed, or ABTError.
 *	@exception ABTException Thrown if an unrecoverable error occurs.
 */
private ABTValue processTimePeriod(int command, ABTObject site, ABTHashtable args) throws ABTException
   {
      ABTValue val = null;

      TimePeriod helper = new TimePeriod(this, site);

      switch (command)
      {
         case POPULATE:
            val = helper.populate(null, QRY_TIMEPERIODS);
            break;

         case SAVE:  // no save for time period
         default:
      }

      return val;
   }


 /**
 *		Get a list of all the resource categories.
 *		@return  An ABTArray of resource categories.
 */
   private ABTValue getResCats() throws ABTException
   {
      // select resource categories from the repository
      ABTCursor cursor = getRepository().select(QRY_RESCAT);
      if (cursor == null)
         processError(component_,
                     "getResourceCategories",
                     errorMessages.ERR_SELECT_ERROR,
                     "query = " + QRY_RESCAT);

      // For each tuple in the resource category cursor, read the prCategory field
      // and put it in the array.
      ABTArray ar = new ABTArray();
      while(cursor.moveNext())
      {
         ABTString cat = new ABTString(cursor.getFieldString(FLD_CATEGORY));
         ar.add(cat);
      }

      cursor.release();				// release the ABTCursor
      return ar;
   }

}