/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTException.java, 12, 12/15/98 10:51:38 AM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

public class ABTException extends Exception
{
   public static final int  SUCCESS  = 0;
   public static final int  ERROR    = -1;

   ABTError code_;
   
   
   public ABTException(String message) 
   {
      super(message); 
      code_ = new ABTErrorCore("ABTException","UnKnown",message,this);
   }

   public ABTException (ABTError err)
   {
      super(err.getMessage().toString());
      code_ = err;
   }
   public ABTErrorCode getErrorCode() 
   {
      return code_.getErrorCode();
   }

   public String getMessage()
   {
      return code_.getMessage();
   }

   public ABTError getError()
   {
      return code_;
   }
}