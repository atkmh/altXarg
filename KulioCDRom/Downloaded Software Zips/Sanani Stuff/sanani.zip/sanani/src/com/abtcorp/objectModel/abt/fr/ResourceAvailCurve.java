package  com.abtcorp.objectModel.abt.fr;

/*
 * ResourceAvailCurve.java 10/22/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 10-22-98       SOB           Initial Design
 *
 */

import   java.util.*;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.ABTCurve;

/**
 * This field rule makes sure that a Resource's AvailCurve property will be set correctly.
 *
 * @version	1.0
 * @author  S. Bursch
 */

public class ResourceAvailCurve extends SiteFieldRule
{

   /**
    * Validates the OFD_AVAILCURVE value that is being set into the parent object container.
    * Returns an ABTError if the value is null or is the wrong type of curve.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      // if new value is null or empty, return an error.
      if( ABTValue.isNull( newValue ) )
         return new ABTError( "ResourceAvailCurve",
                              "onSet", 
                              errorMessages.ERR_OPERATION_DENIED,
                              "AvailCurve cannot be set to null" );
      
      //
      // if new value is not an ABTCurve, disallow the set
      //
      if ( !(newValue instanceof ABTCurve) )
         return new ABTError( "ResourceAvailCurve",
                              "onSet", 
                              errorMessages.ERR_INVALID_VALUE,
                              "AvailCurve must be an ABTCurve" );
      
      
      //
      // new value is an ABTCurve, but if it is not a RATECURVE type, disallow the set
      //
      int curveType = ((ABTCurve)newValue).getType();
      if ( curveType != ABTCurve.RATECURVE )
         return new ABTError( "ResourceAvailCurve",
                              "onSet", 
                              errorMessages.ERR_INVALID_VALUE,
                              "AvailCurve must be of type RATECURVE" );

       ABTHashtable parms = parameters;
      if ( parms == null )
         parms = new ABTHashtable();
     ABTValue v  = setUnitOfMeasure( session,
                               parent,
                               newValue,
                               parent,
                               parms);
      if (ABTError.isError(v))
         return v;
      if (v != null)
         return write( session, parent, property, myValue, v, false );
      else
         return new ABTError("ResourceAvailCurve",
            "onSet",
            errorMessages.ERR_DATA_CONVERSION,
            newValue);
   }

   /**
    * return the availcurve converted...
    *
    * @param session    session object for transaction support
    * @param parent     the container object for this field property
    * @param property   the property object
    * @param myValue    the current value of the property
    * @param parameters list of parameters and (field/app specific)
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    */
   protected ABTValue onGet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue newValue, ABTHashtable parameters )
   {
      ABTHashtable param = parameters;
      if (param == null)
         param = new ABTHashtable();
        return getUnitOfMeasure( session,
                                     parent,
                                     newValue,
                                     parent,
                                     param);
   }


}
