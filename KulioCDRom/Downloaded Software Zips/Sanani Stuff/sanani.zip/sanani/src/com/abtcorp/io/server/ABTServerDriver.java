package com.abtcorp.io.server;

/*
 * ABTServerDriver.java 03/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98      SA          Initial Implementation
  * 03-27-98		SOB			Initial Documentor
  * 03-31-98      SOB         Add default constructor & setSpace() method
  * 04-16-98      SOB         Changed ABTObjectSelector to String in populate() method
  * 04-30-98      SOB         open() returns boolean instead of void
  * 05-05-98      SOB         change addProperties() to support property names in ABTRepoDataDictionary form
  * 06-19-98      LZX         change addProperties() from package default to public.
  * 07-14-98      SOB         remove addProperties() and move it to ABTIOPreoHelper
  * 07-23-98      LZX         add getRulebase() and setRulebase().
  * 08-03-98      SOB         changed to com.abtcorp.io.server package
  * 08-05-98      SOB         mods such that this class does not extend ABTDriver in the io package
  * 08-11-98      SOB         Mods to support new public API
  * 08-12-98      LZX         Changed processError() to throw ABTException with ABTError.
  * 09-23-98      SOB         Added getSite() to find and return the Site object in the object space
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import java.util.Enumeration;
import java.util.Vector;

import com.abtcorp.io.IABTServerDriver;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.ABTDouble;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.idl.IABTDriverConstants;

/**
 *  ABTServerDriver is the base abstract class for all server drivers which will access persistent data.  Server drivers
 *  are drivers which reside in the same Java VM as the object space and which communicate with the object space directly
 *  by using the object space API.
 *
 *			This class is not meant to be instantiated directly, but to be extended by
 *       special-purpose drivers which access persistent data in an application-specific
 *       way, e.g.,
 *
 *  <pre>
 *       public class ABTRepositoryDriver extends ABTServerDriver
 *       {
 *        ... add/override methods for repository-specific requirements ...
 *       }
 *
 *  </pre>
 *
 * @version     $Revision: 26$
 * @author      S. Asire
 * @author		 S. Bursch
 */

public abstract class ABTServerDriver implements IABTServerDriver, IABTDriverConstants
{
   private ABTObjectSpace space_ = null;
/**
 *    userSession_ is a reference to the current user session being used by this helper.
 */
   private ABTUserSession userSession_ = null;


/**
 *		Create an ABTDriver that has no associated ABTObjectSpace.  If this
 *    constructor is used, the setSpace() method must be used subsequently
 *    to associate the driver with an ABTObjectSpace object.
 */
   public ABTServerDriver() {}

/**
 *		Create an ABTDriver that is associated with an ABTObjectSpace.
 *		@param space  The ABTObjectSpace object with which this ABTDriver is
 *		associated.
 */
   public ABTServerDriver(ABTObjectSpace space, ABTUserSession session)
   {
    space_ = space;
    userSession_ = session;
   }


/**
 *		Opens a connection to a specific data source.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return ABTValue indicating success/failure of the open() request.  If open()
 *             was unsuccessful, then this method returns an ABTError with an
 *             explanatory message.  Otherwise, null;
 */
   public abstract ABTValue open(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Populates the ABTObjectSpace with objects from the data source. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *		@return An ABTValue object, which is really an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.
 */
   public abstract ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Saves the ABTObjects identified in the ABTObjectSet object back to the data source.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 *    @return ABTValue indicating success/failure of the save operation.  If a failure occurred, an ABTError;
 *             null, otherwise.
 */
   public abstract ABTValue save(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Closes a connection to a specific data source.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public abstract ABTValue close(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);


/**
 *		Executes a driver-specific command.  Commands which are relevant to all server drivers
 *    should be placed here.  If there are no commands relevant to all drivers, then this method
 *    will return an ABTError.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public abstract ABTValue execute(ABTObjectSpace space, ABTUserSession session, ABTHashtable args);

/**
 *		Gets the ABTObjectSpace object and return it to the caller.
 */

   public ABTObjectSpace getSpace() {return space_;}

/**
 *		Sets an ABTObjectSpace object for this driver.
 */

   public void setSpace(ABTObjectSpace space) {space_ = space;}

/**
 *		Sets the user session reference
 *    @param session is a reference to the user session
 *
 */
   public   void setUserSession(ABTUserSession session) {userSession_ = session;}

/**
 *		Gets the current session handle
 *
 *
 */

   public   ABTUserSession getUserSession() {return userSession_;}



/**
 *	Gets the object space rule base.
 * @return the rule base string value.
 */
   public String getRulebase ()
   {
      return(space_.getRulebase());
   }


   /**
    *    Gets a String value from an ABTHashtable.
    *    @param args the ABTHashtable from which a value will be extracted
    *    @param key the String object that is the associated key for the value to be extracted
    *    @return String object
    */
   protected String getStringValue(ABTHashtable args, String key)
   {
      Object obj = args.getItemByString(key);
      String value = (obj instanceof ABTString) ? ((ABTString)obj).stringValue() : (String) obj;
      return value;
   }

   /**
    *    Gets a boolean value from an ABTHashtable.  If the value is not present, supplies a 
    *    default value to the caller.
    *    @param args the ABTHashtable from which a boolean value will be extracted
    *    @param key the String object that is the associated key for the boolean value to be extracted
    *    @param defaultValue the default boolean value if the key cannot be found or is otherwise invalid
    *    @return a boolean value
    */
   protected boolean getBooleanValue(ABTHashtable args, String key, boolean defaultValue)
   {
      boolean boolValue = defaultValue;
      Object obj = args.getItemByString(key);
      if (obj instanceof ABTBoolean)
         boolValue = ((ABTBoolean)obj).booleanValue();
      return boolValue;   
   }

   /**
    *    Gets an ABTDouble object from an ABTHashtable.  If the value is not present, or is not an
    *    ABTValue, returns the default value to the caller.
    *    @param args the ABTHashtable from which a double value will be extracted
    *    @param key the String object that is the associated key for the double value to be extracted
    *    @return a double
    */
   protected double getDoubleValue(ABTHashtable args, String key, double defaultValue)
   {
      double doubleValue = defaultValue;
      Object obj = args.getItemByString(key);
      if (obj instanceof ABTDouble)
         doubleValue = ((ABTDouble)obj).doubleValue();
      return doubleValue;   
   }
   
   /**
    *    Gets an ABTValue object from an ABTHashtable.  If the value is not present, or is not an
    *    ABTValue, returns the null value to the caller.
    *    @param args the ABTHashtable from which a boolean value will be extracted
    *    @param key the String object that is the associated key for the boolean value to be extracted
    *    @return an ABTValue object or null
    */
   protected ABTValue getABTValue(ABTHashtable args, String key)
   {
      Object obj = args.getItemByString(key);
      ABTValue val = (obj instanceof ABTValue) ? (ABTValue) obj : null;
      return val;
   }

   /**
    *    Gets the site object for the object space and returns it to the caller.  The
    *    site object can be found by querying the object space for objects of type OBJ_SITE.
    *    There should only be one such object.  The method is made public so that helper classes
    *    not extended from this driver can access the Site object.  It is not intended to be
    *    exposed to client applications.
    *    @return an ABTValue.  If no errors occur, the site object; otherwise,
    *       an ABTError.
    */
   public ABTValue getSite()
   {
      ABTValue ret;
      ABTError err = new ABTError(COMP_SERVERDRIVER, 
                                  "getSite", 
                                  errorMessages.SERVER_ERR_NO_SITE,
                                  null); 
      String siteType = com.abtcorp.idl.IABTRuleConstants.OBJ_SITE;
      
      if (space_ == null ||
          userSession_ == null)
         return err;          
      
      ABTValue val = space_.getObjects(userSession_, siteType);
      if ( ABTError.isError( val ) || ABTValue.isNull( val ) )
         return err;
         
      ABTObjectSet os = (ABTObjectSet) val;
      if ( os.size(userSession_) == 0 )
         return err;
         
      //
      // The following code assumes that there is only one Site object in the
      // set returned by the space.
      //
      val = os.at(userSession_, 0);
      if ( !(val instanceof ABTObject) )
         return err;

      //
      // We've got an ABTObject.  Make sure it's exactly the right type.
      //
      if ( !((ABTObject) val).getObjectType().equals(siteType) )
         return err;
      
      //
      // We've got the Site object for sure.  Return a reference to it
      // to the caller.
      //
      
      return val;
   }
}