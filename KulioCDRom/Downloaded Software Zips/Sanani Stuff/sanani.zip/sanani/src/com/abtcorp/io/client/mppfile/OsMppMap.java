package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.core.ABTRemoteID;


public class OsMppMap extends MatchVectors implements IABTPMRuleConstants//since multiple inheritance not allowed
{

   protected IABTObject    osProject_;
   protected Hashtable     osTasksHashMap_;
   protected Hashtable     osResourcesHashMap_;
   protected Hashtable     osAssignmentsHashMap_;
   protected Hashtable     osDependenciesHashMap_;

   public OsMppMap()
   {
      osTasksHashMap_         = new Hashtable();
      osResourcesHashMap_     = new Hashtable();
      osAssignmentsHashMap_   = new Hashtable();
      osDependenciesHashMap_  = new Hashtable();
   }

   public boolean hasBeenUpdated(ABTRemoteID id, IABTObject obj)
   {

      String typeString = obj.getObjectType();

      if (typeString.equals("pm.Task"))
         if (osTasksHashMap_.get(id)          != null) return true;
      if (typeString.equals("pm.Resource"))
         if (osResourcesHashMap_.get(id)      != null) return true;
      if (typeString.equals("pm.Assignment"))
         if (osAssignmentsHashMap_.get(id)    != null) return true;
      if (typeString.equals("pm.Dependency"))
         if (osDependenciesHashMap_.get(id)   != null) return true;

      return false;

   }

   public OsMppMap(IABTObject osProject)
   {
      osProject_              = osProject;
      osTasksHashMap_         = new Hashtable();
      osResourcesHashMap_     = new Hashtable();
      osAssignmentsHashMap_   = new Hashtable();
      osDependenciesHashMap_  = new Hashtable();
   }

   public void setOsProject(IABTObject osProject)
   {
      osProject_ = osProject;
   }

   public void osAdd(MppOsMatch match)
   {

      IABTObject osObject = match.getOsObject();
      String typeString = osObject.getObjectType();

      if (typeString.equals("pm.Task")) {

         super.add(match);
         osTasksHashMap_.put(match.getOsKeyAbtValue(), match);

      } else if (typeString.equals("abt.Resource")) {

         super.add(match);
         osResourcesHashMap_.put(match.getOsKeyAbtValue(), match);

      } else if (typeString.equals("pm.Assignment")) {

         super.add(match);
         osAssignmentsHashMap_.put(match.getOsKeyAbtValue(), match);

      }

   }

   public void osAdd(MppOsDependencyMatch match)
   {
      super.add(match);
      osDependenciesHashMap_.put(match.getOsKey(), match);
   }

   //the complete functions assume half of the match is there
   //and the other half is beeing filled

   public void complete(MppOsMatch match, IABTObject iAbtObject, ABTValue key)throws ABTException
   {
      match.complete(iAbtObject, key);
      if (iAbtObject.getObjectType().equals(OBJ_TASK))
         osTasksHashMap_.put(match.getOsKeyAbtValue(), match);
      else if (iAbtObject.getObjectType().equals("abt.Resource"))
         osResourcesHashMap_.put(match.getOsKeyAbtValue(), match);
      else if (iAbtObject.getObjectType().equals("pm.Assignment"))
         osAssignmentsHashMap_.put(match.getOsKeyAbtValue(), match);
   }

   public ABTRemoteID getRemoteId(IABTObject obj)
   {

      ABTClientMppRemoteID remoteID = null;

      ABTValue id = obj.getValue("ABTRemoteID");

      if ((id instanceof ABTRemoteID))
         return (ABTRemoteID)id;
      return null;
   }

   public Resource getCorespondingResourceObject(IABTObject resourceObject)
   {
      ABTRemoteID remoteId = getRemoteId(resourceObject);
      MppOsMatch match = (MppOsMatch) osResourcesHashMap_.get(remoteId);
      return (Resource) match.getMppObject();
   }

   public Task getCorespondingTaskObject(IABTObject taskObject)
   {
      ABTRemoteID remoteId = getRemoteId(taskObject);
      MppOsMatch match = (MppOsMatch) osTasksHashMap_.get((ABTValue)remoteId);
      return (Task) match.getMppObject();
   }

   public MppOsMatch getTaskMatch(IABTObject obj)
   {
      ABTRemoteID remoteId = getRemoteId(obj);
      return (MppOsMatch) osTasksHashMap_.get((ABTValue)remoteId);
   }

   public MppOsMatch getResourceMatch(IABTObject obj)
   {
      ABTRemoteID remoteId = getRemoteId(obj);
      return (MppOsMatch) osResourcesHashMap_.get((ABTValue)remoteId);
   }


   public Resource getMppResource(int resourceUniqueId)
   {

      MppOsMatch  match = getResourceMatch(resourceUniqueId);

      return (Resource)match.getMppObject();

    }

   public MppOsMatch getResourceMatch(int resourceUniqueId)
   {
      return (MppOsMatch) osResourcesHashMap_.get(new ABTInteger(resourceUniqueId));
   }
/*
   public void addResourceToMap(Resource resource, IABTObject resourceObject, int uniqueId)
   {
      osAdd(new MppOsMatch(resource, resourceObject, new ABTInteger(uniqueId)));
   }
*/
   public MppOsMatch getTaskMatch(ABTRemoteID remoteId)
   {
      return (MppOsMatch) osTasksHashMap_.get(remoteId);

   }

   public MppOsMatch getResourceMatch(ABTRemoteID remoteId)
   {
      return (MppOsMatch) osResourcesHashMap_.get(remoteId);

   }
/*
   public MppOsMatch getResourceMatch(IABTObject resObj)
   {
      ABTValue key = resObj.getValue("remoteID");
      return (MppOsMatch) mppResourcesHashMap_.get(key);

   }
*/


}





