package com.abtcorp.io.client.methfile;

/*
 * ABTIOMethFileTaskEstimate.java 10/21/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-21-98    MXA         Initial Implementation
 *
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTMMRuleConstants;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTPropertySet;


import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;



/**
 *  ABTIOMethFileTaskEstimate is a helper class for the ABT Site File driver .
 *  It is instantiated by the ABTIOMethFileDriver.
 *
 *  <pre>
 *       ABTIOMethFileTaskEstimate fr = new ABTIOMethFileTaskEstimate(driver, parent);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOMethFileDriver
 */

public class ABTIOMethFileTaskEstimate extends ABTIOMethFileHelper implements IABTRuleConstants, IABTMMRuleConstants
{

//====================================================================================
// Constructors
//====================================================================================
/**
 * ABTIOMethFileTaskEstimate constructor.
 * @param   driver: the reference to the driver.
 * @param   parent: the site object that owns the resource
*/
   ABTIOMethFileTaskEstimate(ABTIOMethFileDriver driver, IABTObject parent)
   {
      super(driver, parent, OBJ_MM_TASKESTIMATE);
      method_ = parent;
   }

/**
 *  Saves the task estimate objects back to the local file. This method overrides
 *  the save() method in super class because saving methods requires special
 *  treatment (saving notes)
 *	@param oSet   the resource object set to be saved back to the loal file
 *  @return       the objects set that got saved.
 *  @exception    ABTException Thrown if an unrecoverable error occurs.
 */
   public ABTValue save(IABTObjectSet oSet) throws ABTException
   {
    try
    {
        super.save(oSet);

    }
    catch (Exception e)
    {
        throw new ABTException(e.getMessage());
    }
    finally
    {
       return (ABTValue)oSet;
    }


   }


/**
 * Populate the Task Estimate object.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
        ABTValue     val       = null;
	    ABTValue     ret       = null;       
        IABTLocalID  id        = null;
        Object       obj       = null;
        ABTObjectSetIDList taskEstimateIds = null;        
        
        
        id = driver_.getMethodId();
        val = getIDs(id,OBJ_MM_METHOD, OFD_ALLTASKESTIMATES);        
	                                 
        if (val instanceof ABTObjectSetIDList) 
            taskEstimateIds  = (ABTObjectSetIDList)val;
         else 
            throw new ABTException("Wrong Cast");
            
        Enumeration itID = taskEstimateIds.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
           obj = null;
           obj = itID.nextElement();
           if ( (obj instanceof IABTLocalID) ||(obj == null) )
            id_ = (IABTLocalID)obj;           
           else
            throw new ABTException("Wrong Cast");
            ret = super.populate();         
        }
        return ret;	    
        
	}



/**
 * Create a new object in the object space and initialize its properties.
 * @param type: the type of the object to be created.
 * @param id: the remote id to be used to create the object.
 * @return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
    ABTValue        val            = null;
    IABTLocalID     methId         = null;
    IABTArray       taskEstArr     = null;   
    IABTPropertySet taskEstPropSet = null;   
    IABTObject      taskObj        = null;
    IABTLocalID     taskID         = null;
    IABTObject      estModelObj    = null;
    IABTLocalID     estModelID     = null;
    Object          obj            = null;


    taskEstPropSet = getProperties(OBJ_MM_TASKESTIMATE);
   
    obj = driver_.intermediateTableGet(id_);

    if (!(obj instanceof IABTArray))
        throw new ABTException(" Wrong type cast Objec Array");
    else
        taskEstArr = (IABTArray)obj;
      
    val = null;
    val = getHashValue(taskEstArr, taskEstPropSet, OFD_TASK);
    if ( val instanceof IABTLocalID )
        taskID = (IABTLocalID)val;
    else
        throw new ABTException(" Wrong type cast");
            
    obj = null;
    obj = driver_.lookupTableGet(taskID);
    if ((obj !=null) && (obj instanceof IABTObject))
        taskObj = (IABTObject)obj;
    else
        new ABTException("Wrong Cast.");
        
    val = null;
    val = getHashValue(taskEstArr, taskEstPropSet, OFD_ESTMODEL);
    if ( val instanceof IABTLocalID )
        estModelID = (IABTLocalID)val;
    else
        throw new ABTException(" Wrong type cast");
            
    obj = null;
    obj = driver_.lookupTableGet(estModelID);
    if ((obj !=null) && (obj instanceof IABTObject))
        estModelObj = (IABTObject)obj;
    else
        new ABTException("Wrong Cast.");
    
      reqParams_.putItemByString(OFD_METHOD,   (ABTValue)method_);
      reqParams_.putItemByString(OFD_TASK,     (ABTValue)taskObj);
      reqParams_.putItemByString(OFD_ESTMODEL, (ABTValue)estModelObj);
      return (super.create(type, id, reqParams_));
   }




}