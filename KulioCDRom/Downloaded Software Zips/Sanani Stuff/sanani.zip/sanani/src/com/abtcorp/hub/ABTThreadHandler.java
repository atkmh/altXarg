package com.abtcorp.hub;

// import the Java packages we use
import java.net.*;
import java.util.*;
import java.io.*;

import com.abtcorp.core.*;




/**
 * Copyright (c) 1996 DECISIS Coporation
 * All Rights Reserved.
 *
 * @version     1.00, 09/01/96
 * @author      Hajo Birthelmer
 */

public class ABTThreadHandler
implements Runnable
{


    /**
    *   message to return to client
    */

    private Vector files = null;

    /**
    * My thread - started in the initialization application
    */
    protected Thread me_;
    protected boolean me_running = false;
    protected boolean keep_going = true;
    protected boolean noMessage = true;

    /**
    * This is the private message loop for the user
    */
    private Vector message_loop = null;

    /**
    * This is the private message loop indicator
    */
    private boolean message_arrived = false;

    /**
    * current owner
    */
    ABTObjectSpace parent;

    /**
    * current fucntion to be executed against elements
    */
    IABTFunction function = null;

	public ABTThreadHandler(ABTObjectSpace parent_, IABTFunction function_)
	{
	    parent = parent_;
        message_loop = new Vector();
        function = function_;
	}


	public IABTFunction getFunction()
	{
	    return function;
	}

    /**
    * Return the current id for this user
    */
    public ABTObjectSpace getParent()
    {
        return parent;
    }


    /**
    * This routine is the thread necessary to allow the threading of User instances
    */
    synchronized public void  run() 
    {
        // first check whether this is really me we are talking about
//        if (Thread.currentThread() != me_) return;
        // now loop keep_going
        me_running = true;

        while(keep_going)

        {
            while (!message_arrived)
            {
                try
                {
                    wait();
                }
                catch (Exception e)
                {
//                    handleException("receivemsg-wait thread","dflt",(Exception)e);
                }
            }
            receiveMessage();
        }
        me_running = false;
    }






    /**
    * The put_message routine allows another thread to send a message to this instance
    * and add it to the local message_loop
    * @see MESSAGE for a more detailed description of a message object
    *@param message - Message object
    */

    synchronized ABTError put_message(ABTFunctionParameter message)
    {
        message_loop.addElement(message);
        if (me_ == null)
        {
            try
            {
                // ok, now start my thread
                me_ = new Thread(this);
//                // make sure this trhead gets terminated if the main thread dies
                me_.setDaemon(true);
                // now start my message loop
                me_.start();
            }
            catch (Exception e)
            {
               return new ABTErrorHub("ABTThreadHandler->put->message",errorMessages.ERR_39,e);
            }

        }
        message_arrived = true;
        notifyAll();
        return null;
    }


    synchronized void stop()
    {
//        setLog("stop",SUCCESS,"Message received");
        message_arrived = false;
        keep_going = false;
    	if ((me_ != null) && (me_running))
  	    {
            message_arrived = true;
            notifyAll();
        }

        return;
    }




    /**
    * The get_message routine allows this routine to retrieve messages from the loop
    * @see MESSAGE for a more detailed description of a message object
    *@return message - object
    */

    synchronized ABTFunctionParameter  get_message()
    {
        if (message_loop.isEmpty())
        {
            message_arrived = false;
            return null;
        }
        // retrieve element in 0 position
        ABTFunctionParameter message =  (ABTFunctionParameter) message_loop.firstElement();
        // remove 0est element
        message_loop.removeElementAt(0);
        // are there more messages in the queue?
        if (message_loop.isEmpty())
        {
            message_arrived = false;
        }
        return message;
    }


    /**
    * remove all messages from the message stack and
    * call the message handling routine
    */

    public void receiveMessage()
    {
        ABTFunctionParameter msg;
        while ( (msg = get_message()) != null)
        {
        //ystem.out.println("User receiveMessage ");

            function.execute(msg);
        }
        noMessage = false;
    }

}


