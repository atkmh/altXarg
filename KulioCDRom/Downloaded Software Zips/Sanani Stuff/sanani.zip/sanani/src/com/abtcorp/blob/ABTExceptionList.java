package com.abtcorp.blob;

import com.abtcorp.core.*;

public final class ABTExceptionList extends ABTSortedArray
{
   private static final long serialVersionUID = -2044879818101794502L;
	
	public ABTExceptionList() {}

   public ABTException getException(int index) {return (ABTException)at(index);}

   public final void resetShifts(ABTDate start, ABTDate finish)
   {
   	for (int index = 0; index < size(); index++) {
   	   ABTException exception = getException(index);

   	   if (start  != null && exception.getFinish().compareTo(start)  < 0) continue;
   	   if (finish != null && exception.getStart().compareTo(finish)  > 0) break;
   		if (finish != null && exception.getFinish().compareTo(finish) > 0) insert(index+1, new ABTException(finish.next(), exception.getFinish(), exception.getShifts()));
   		if (start  != null && exception.getStart().compareTo(start)   < 0) put(index, new ABTException(exception.getStart(), start.prev(), exception.getShifts()));
   		else                     		                                     remove(index--);
   	}
   }

   public final void setShifts(ABTDate start, ABTDate finish, ABTShiftList shifts)
   {
   	setException(new ABTException(start, finish, shifts));
   }

   public final void setException(ABTException exception)
   {
      resetShifts(exception.getStart(), exception.getFinish());

   	add(exception);
   }

   public final void setExceptions(ABTExceptionList shifts)
   {
   	for (int index = 0; index < shifts.size(); index++) setException(shifts.getException(index));
   }

   public final void optimize()
   {
   	for (int index = 0; index < size(); index++) getException(index).optimize();

      if (size() < 2) return;

  	   ABTException prev = getException(0);

   	for (int index = 1; index < size(); index++) {
   	   ABTException exception = getException(index);

   		if (prev.getFinish().next().equals(exception.getStart()) &&
   		    prev.getShifts().equals(exception.getShifts())) {
   		   put(index-1, exception = new ABTException(prev.getStart(), exception.getFinish(), prev.getShifts()));
   			remove(index--);
   		}

   		prev = exception;
   	}
   }

   public final ABTShiftList getShifts(ABTDate date)
   {
   	for (int index = 0; index < size(); index++) {
   	   ABTException exception = getException(index);

   	   if (exception.getFinish().compareTo(date) < 0) continue;
   	   if (exception.getStart().compareTo(date)  > 0) break;

   	   return exception.getShifts();
   	}

      return null;
   }

   public final ABTExceptionList getExceptions(ABTDate start, ABTDate finish)
   {
      ABTExceptionList result = new ABTExceptionList();

   	for (int index = 0; index < size(); index++) {
   	   ABTException exception = getException(index);

   	   if (start  != null && exception.getFinish().compareTo(start) < 0) continue;
   	   if (finish != null && exception.getStart().compareTo(finish) > 0) break;

   	   result.pushBack(new ABTException(ABTDate.max(start, exception.getStart()), ABTDate.min(finish, exception.getFinish()), exception.getShifts()));
   	}

      return result;
   }

   public String toString()
   {
	   StringBuffer buffer = new StringBuffer();

   	for (int index = 0; index < size(); index++) {
     		if (index > 0) buffer.append(", ");

         buffer.append(getException(index));
      }

   	return buffer.toString();
	}
}