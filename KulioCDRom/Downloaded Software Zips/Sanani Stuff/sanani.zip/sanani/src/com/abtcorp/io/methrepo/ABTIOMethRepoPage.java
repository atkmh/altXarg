package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoPage.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-16-98    LZX         Initial Implementation
 * 07-10-98    LZX         Support transactions
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTIOMethRepoPage is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTIOMethRepoMethod object.
 *
 *  <pre>
 *       ABTIOMethRepoPage rt = new ABTIOMethRepoPage(driver, method);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTIOMethRepoMethod
 */

public class ABTIOMethRepoPage extends ABTIOMethRepoHelper 
{
   private Hashtable pageHash_ = null;	// page has table
   private ABTObject method_ = null;


/**
 *    ABTIOMethRepoPage constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the method object that owns the pages.
 */
   ABTIOMethRepoPage(ABTMMRepoDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_MRPAGE, OBJ_MM_PAGE);
      method_ = parent;
     	pageHash_ = new Hashtable();     // get a new Hashtable for these task objects
      component_ = "ABTIOMethRepoPage";
      reqParams_.putItemByString(OFD_METHOD, method_);
   }

/**
 *  Set page values.
 *  @param       ps: the page property hash.
 *  @param       cur: the page cursor.
 *  @param       obj: the page object.
 *  @return      the page object or error
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps, ABTCursor cur, ABTObject pageObject) throws ABTException
   {
      setPropertyValues(ps, cur, pageObject);

      // add to package hashtable
      long fldID = cur.getFieldInt(FLD_ID);   
		pageHash_.put(new Long(fldID), pageObject); 
   }


/**
 *  Retrieves the page hash table.
 *  @return the page hash table
 *  @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public Hashtable getHash() throws ABTException
   {
      return pageHash_;
   }
   
/**
 * Sets cursor values and updates the repository.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// first set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);
		
		// for new records, get method id from the method object and set it.
		if (isNew)
   	   cursorSetField(cur, FLD_METHODID, getValue(method_, OFD_ID));
   }
   

/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         // prMethodID can not be modified after add-new
         if (!isNew && prapiName.equals(FLD_METHODID))    
            return true;
            
         return super.isSaveException(prapiName, obj, prapiFlags, isNew);            
   }

/**
 * Select cursor from the repository for populate.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForPopulate() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODPAGES + id ));
   }

/**
 * Select cursor from the repository for save.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForSave() throws ABTException
   {     
     	long id = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODPAGES + id));
   }
}