/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;

import com.abtcorp.blob.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

/** @com.register(clsid=61C18EE3-7052-11d2-AE1A-00E02921FB8A,
                typelib=A2FAB780-BDD1-11D1-ADE6-00E029143BC6,
                progid="com.abtcorp.api.com.ABTTimeUtil.1",
                version="1.0.0")*/

public class ABTTimeUtilCOM implements IABTTimeUtil
{
   public ABTTimeUtilCOM() {}

   public int getJulian(Variant time, boolean pm) {
      ABTTime t  = (ABTTime)VariantMunger.VariantToValue(time);
      return t.getJulian(pm);
      }

   public Variant earlier(Variant time1, Variant time2) {
      ABTTime t1  = (ABTTime)VariantMunger.VariantToValue(time1);
      ABTTime t2  = (ABTTime)VariantMunger.VariantToValue(time2);
      return VariantMunger.ValueToVariant(ABTTime.min(t1,t2));
      }

   public Variant later(Variant time1, Variant time2){
      ABTTime t1  = (ABTTime)VariantMunger.VariantToValue(time1);
      ABTTime t2  = (ABTTime)VariantMunger.VariantToValue(time2);
      return VariantMunger.ValueToVariant(ABTTime.max(t1,t2));
      }

   public int diff(Variant time1, Variant time2) {
      ABTTime t1  = (ABTTime)VariantMunger.VariantToValue(time1);
      ABTTime t2  = (ABTTime)VariantMunger.VariantToValue(time2);
      return ABTTime.diff(t1,t2);
      }

   public Variant now() {
      return VariantMunger.ValueToVariant(ABTTime.now());
      }

   public Variant fromString(String string) {
      return VariantMunger.ValueToVariant(ABTTime.valueOf(string));
      }
}