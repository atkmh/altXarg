package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileSubProject.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTDriver;


import  com.abtcorp.api.local.ABTHashTable;
import com.abtcorp.io.client.ABTObjectSetIDList;

import com.abtcorp.core.ABTString;

import java.util.Hashtable;
import java.io.File;

//DEBUG
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.io.client.ABTFileHelper;

/**
 *  ABTIOPMWFileSubProject is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileSubProject ft = new ABTIOPMWFileSubProject(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileSubProject extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector   subProjectVector_ = null;
     
/**
 *    ABTIOPMWFileSubProject constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileSubProject(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_        = OBJ_SUBPROJECTLINK;
      subProjectVector_  = new Vector();
   }

//====================================================================================
// Populate  SubProject from the Intermediate Hash Table
//====================================================================================

/**
 * Populate SubProject object from the Intermediate Hash Table to the space
 * @param Hashtable parms,
 * @return an ABTValue the team object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue populate(Hashtable parms) throws ABTException
   {
    ABTObjectSetIDList subProjectLinkIDs = null;
    Object             object            = null;

    try
    {
        //Get the SubProject Link IDs
        object = parms.get(OFD_SUBPROJECTLINKS);
        if (object instanceof ABTObjectSetIDList)
            subProjectLinkIDs  = (ABTObjectSetIDList)object;

        Enumeration itID = subProjectLinkIDs.getActiveIDs();
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            Object obj = itID.nextElement();
            if (obj instanceof IABTLocalID)
                reqparms.put(SUBPROJECTLINK_ID,(IABTLocalID)obj);
            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }
   }

/**
 * Create a new object in the object space and initialize it with  appropriate values
 * @param Hashtable parms
 * @return ABTValue the newly created SubProjectLink Object
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {
      IABTLocalID subProjectLinkID = null;
      IABTObject  project          = null;
      IABTObject  targetObj        = null;
      Object      object           = null;
      IABTObject  subProjectLinkObj= null;
      ABTValue    val              = null;


      //Get the SubProject Link ID
      object = null;
      object = parms.get(SUBPROJECTLINK_ID);
      if (object instanceof IABTLocalID)
         subProjectLinkID  = (IABTLocalID)object;

      //Check if SubProject Link has already been created
      object = null;
      object = driver_.lookupTableGet(subProjectLinkID);
      if ( object!= null && object instanceof IABTObject)
      {
         // TO DO UPDATE
           ;
      }
      else
      {
          // Get the array of value associated with SubProject Link
          IABTArray  subProjectLinkArr  = null;
          object = null;

          object = driver_.intermediateTableGet(subProjectLinkID);
          if (object instanceof IABTArray)
            subProjectLinkArr = (IABTArray)object;

          //Get the property set associated with the SubProject Link
          IABTPropertySet propSet = null;
          propSet = getProperties(type_);

          //Get Associated SubProject to the SubProjectLink
          val = null;
          IABTLocalID subProjectID  = null;
          IABTObject  subProjectObj = null;
          object = null;

          //Populate the subProject's project
          val = getHashValue(subProjectLinkArr, propSet, OFD_SUBPROJECT);
          if (val instanceof IABTLocalID)
          {
            subProjectID  = (IABTLocalID)val;
            object = driver_.lookupTableGet(subProjectID);
            if ((object != null) && (object instanceof IABTObject) )
                subProjectObj = (IABTObject)object;
            else
            {
               subProjectObj = (IABTObject)driver_.populateProject(subProjectID);
               
               IABTDriver     newDriver    = null;
               IABTHashTable  argsp        = null;
               ABTString      srcFileName = null;
               ABTValue       fromFile     = null;
               File           newFile     = null;

                newDriver = (driver_.getSpace()).newABTDriver("com.abtcorp.io.client.pmwfile.ABTIOPMWFileDriver", null);
	            fromFile = getValue(subProjectObj, OFD_FROMFILE);

	            if ( (fromFile!= null)
	                 && !(fromFile instanceof ABTEmpty)
	                 && !(ABTError.isError(fromFile)) )
	            {
	                 newFile = new File (fromFile.stringValue());
	                 //if (!(newFile.exists()))
                        srcFileName = (ABTString)fromFile;
                }
                
                argsp = (driver_.getSpace()).newABTHashTable();	        
	            argsp.putItemByString(KEY_SOURCENAME,srcFileName);
	            argsp.putItemByString(KEY_TYPE ,new ABTString("Project"));
                ABTValue value2 = newDriver.populate(argsp);
                if ((value2 != null) && !(value2 instanceof ABTEmpty) && (value2 instanceof IABTObject))                {
                    subProjectObj = (IABTObject)value2;    
            }
          }
          }
          
          
          //Populate the subTask's project
          IABTLocalID      subTaskID      = null;
          IABTLocalID      subTaskProjID  = null;
          IABTObject       subTaskProjObj = null;
          IABTObject       subTaskObj     = null;
          IABTPropertySet  taskPropSet    = null;
          IABTArray        subTaskArr     = null;

          val = null;
          val = getHashValue(subProjectLinkArr, propSet, OFD_SUBTASK);
          if (val instanceof IABTLocalID)
          {
            subTaskID  = (IABTLocalID)val;
            if ( subTaskID != null)
                subTaskArr = (IABTArray)driver_.intermediateTableGet(subTaskID);
            else
                 throw new ABTException("The SubtaskId in SubProject create is Null");



            val = null;
            taskPropSet = getProperties(OBJ_TASK);
            val = getHashValue(subTaskArr, taskPropSet, OFD_PROJECT);
            if (val instanceof IABTLocalID)
            {
                subTaskProjID = (IABTLocalID) val;

                object = driver_.lookupTableGet(subTaskProjID);
                if ((object != null) && (object instanceof IABTObject) )
                    subTaskProjObj = (IABTObject)object;
                else
                    subTaskProjObj = (IABTObject)driver_.populateProject(subTaskProjID);

               object = null;
               object = driver_.lookupTableGet(subTaskID);
               if ((object != null) && (object instanceof IABTObject) )
                    subTaskObj = (IABTObject)object;
                else
                     throw new ABTException("The subTaskObj is not instance of IABTObject");

            }
          }

         // Get the associated proxy task object reference for this subproject link object
         val = null;
         IABTLocalID proxyTaskID = null;
         IABTObject  proxyTask   = null;
         val = getHashValue(subProjectLinkArr, propSet, OFD_TASK);
         if ((val != null ) && (val instanceof IABTLocalID))
         {
            proxyTaskID = (IABTLocalID)val;
            object = driver_.lookupTableGet(proxyTaskID);
            if ((object != null) && (object instanceof IABTObject) )
                proxyTask = (IABTObject)object;
            else
                throw new ABTException("The Task Proxy in populating subproject id not right");
         }

         val = null;
         ABTBoolean isIPD = null;
         val = getHashValue(subProjectLinkArr, propSet, OFD_ISIPD);
         if ((val!= null) && ( val instanceof ABTBoolean))
            isIPD = (ABTBoolean)val;


         // Get the required parameter to create SubProjectLink Object
          IABTHashTable  reqparms       = (getSpace()).newABTHashTable();
          reqparms.putItemByString(OFD_TASK, (ABTValue)proxyTask);
          reqparms.putItemByString(OFD_ISIPD,(ABTValue)isIPD);

          //Get SubProjectLink's Remote ID
          val = null;

          val = getHashValue(subProjectLinkArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            subProjectLinkObj = createObject(type_,(ABTRemoteID)val, reqparms);
          else if (ABTValue.isNull(val))
            subProjectLinkObj = createObject(type_,(ABTRemoteID)null, reqparms);
          else
            throw new ABTException(" WRONG TYPE CAST");

          //Set SubProjectLink's scalar values.
          setScalarValues(propSet, subProjectLinkArr, subProjectLinkObj);
          //setReferences(subProjectLinkObj);


          //Set References
          setValue(subProjectLinkObj, OFD_SUBPROJECT, null);
          setValue(subProjectLinkObj, OFD_SUBTASK, null);
          setValue(subProjectLinkObj, OFD_SUBPROJECTTYPE, new ABTInteger(UNKNOWN_TYPE));

          ABTValue v = null;
          if ( (!ABTError.isError(subProjectObj)) && (subProjectObj != null))
          {
            v = getValue(subProjectLinkObj, OFD_ISREADONLY);
            boolean ro = (ABTValue.isNull( v )) ? false : v.booleanValue();
            setValue((IABTObject)subProjectObj, OFD_READONLY, new ABTBoolean( ro ));
            setValue(subProjectLinkObj, OFD_SUBPROJECT, (ABTValue)subProjectObj);
            setValue(subProjectLinkObj, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));
          }
          else if (!ABTError.isError(subTaskObj))
          {
            if (subTaskObj instanceof IABTObject)
            {  v = null;
               v = getValue(subProjectLinkObj, OFD_ISREADONLY);
               boolean ro = (ABTValue.isNull( v )) ? false : v.booleanValue();
               setValue((IABTObject)subTaskProjObj, OFD_READONLY, new ABTBoolean( ro ));
               setValue(subProjectLinkObj, OFD_SUBTASK, (ABTValue)subTaskObj);
               setValue(subProjectLinkObj, OFD_SUBPROJECTTYPE, new ABTInteger(TASK_TYPE));
            }
               //setValue(projObj_, OFD_RESOLVEIPD, subTaskProjObj);
          }


    }
    driver_.lookupTablePut(subProjectLinkID, subProjectLinkObj);
    return (ABTValue)subProjectLinkObj;
   }


/**
 * Saves subProject objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException 
 {   
   int  counter = 0;
   try
   {
        IABTObject      project = null;
        ABTValue val = null;
        java.text.NumberFormat format = java.text.NumberFormat.getInstance();
        format.setMinimumIntegerDigits(4);
        format.setGroupingUsed(false);

        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        //Get the property set associated with the Subproject
        IABTPropertySet propSet = null;
        propSet = getProperties(type_);
        IABTObjectSet subProjectOs = getObjectSet(project, OFD_SUBPROJECTLINKS);

        for (int i =0; i < size(subProjectOs); i++)
        {
            IABTObject  subProjectLinkObj     = (IABTObject)at(subProjectOs, i);

            // Make sure the object is of type subProject
            if (!subProjectLinkObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the subProject in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(subProjectLinkObj);
            if (arr==null)
                throw new ABTException("The arr of subProject values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID subProjectLinkID = subProjectLinkObj.getID();
            if (subProjectLinkID == null)
                throw new ABTException("subProject ID is null.");

            if (( driver_.intermediateTablePut(subProjectLinkID, arr)) != null)
                throw new ABTException("The subProject ID already exist.");

            val = null;
            
            IABTObject subProject = getObject(subProjectLinkObj, OFD_SUBPROJECT);
            if ((subProject!= null) && !(subProject instanceof ABTEmpty) && !(ABTError.isError(subProject)))
            {
                driver_.saveProject((IABTObject)subProject);

                IABTDriver     newDriver    = null;
                IABTHashTable  argss        = null;
                ABTString      destFileName = null;
                ABTValue       fromFile     = null;
                File           newFile     = null;

                newDriver = (driver_.getSpace()).newABTDriver("com.abtcorp.io.client.pmwfile.ABTIOPMWFileDriver", null);

	            fromFile = getValue(subProject, OFD_FROMFILE);


	            if ( (fromFile!= null)
	                 && !(fromFile instanceof ABTEmpty)
	                 && !(ABTError.isError(fromFile)) )
	            {
	                 newFile = new File (fromFile.stringValue());
	                 //if (!(newFile.exists()))
                        destFileName = (ABTString)fromFile;
                }
                else
                {
                   String     driverPath  = null;
                   File       driverFile  = null;
                   ABTValue   extId       = null;

                   driverFile = driver_.getFile();
                   driverPath = driverFile.getParent();
                   counter = 0;
                  
                   do
                   {
                    extId = getValue(subProject,OFD_EXTERNALID);
                    if( (extId != null) && !(extId instanceof ABTEmpty) && (extId instanceof ABTString) )
                        newFile = new File (driverPath , new String( ((ABTString)extId).stringValue() + "." + format.format(counter++) +  ".rmp") );
                    else
                        throw new ABTException("The External Id in subproject Save is not valid");
                   }while(newFile.exists());

                   destFileName =  new ABTString(newFile.getAbsolutePath());
                }


                setValue(subProject, OFD_FROMFILE, destFileName);
                argss = driver_.getSpace().newABTHashTable();

	            argss.putItemByString(KEY_DESTINATIONNAME,destFileName);
	            argss.putItemByString(KEY_TYPE ,new ABTString("Project"));
	            argss.putItemByString(KEY_SOURCE ,(ABTValue)subProject);

	            newDriver.save(argss);

            }

            val = null;
            IABTObject subTask = getObject(subProjectLinkObj, OFD_SUBTASK);
            if ((subTask!= null) && !(subTask instanceof ABTEmpty) && !(ABTError.isError(subTask)))
            {
                //Get the property set associated with the Task
                propSet = null;
                propSet = getProperties(OBJ_TASK);
                IABTObject subTaskProj = getObject(subTask, OFD_PROJECT);
                
                if ((subTaskProj!= null) && !(subTaskProj instanceof ABTEmpty) && !(ABTError.isError(subTaskProj)))
                {
                    driver_.saveProject((IABTObject)subTaskProj);
                    
                    IABTDriver     newDriver    = null;
                    IABTHashTable  argss        = null;
                    ABTString      destFileName = null;
                    ABTValue       fromFile     = null;
                    File           newFile      = null;

                    newDriver = (driver_.getSpace()).newABTDriver("com.abtcorp.io.client.pmwfile.ABTIOPMWFileDriver", null);

	                fromFile = getValue(subTaskProj, OFD_FROMFILE);


	                if ( (fromFile!= null)
	                      && !(fromFile instanceof ABTEmpty)
	                      && !(ABTError.isError(fromFile)) )
	                {
	                    newFile = new File (fromFile.stringValue());
	                   // if (!(newFile.exists()))
                            destFileName = (ABTString)fromFile;
                     }
                    else
                    {
                        String     driverPath  = null;
                        File       driverFile  = null;
                        ABTValue   extId       = null;

                        driverFile = driver_.getFile();
                        driverPath = driverFile.getParent();
                        counter = 0;
                  
                        do
                        {
                            extId = getValue(subTaskProj,OFD_EXTERNALID);
                            if( (extId != null) && !(extId instanceof ABTEmpty) && (extId instanceof ABTString) )
                                newFile = new File (driverPath , new String( ((ABTString)extId).stringValue() + "." + format.format(counter++) +  ".rmp") );
                            else
                                throw new ABTException("The External Id in subproject Save is not valid");
                        }while(newFile.exists());

                        destFileName =  new ABTString(newFile.getAbsolutePath());
                    }


                    setValue(subTaskProj, OFD_FROMFILE, destFileName);
                    argss = driver_.getSpace().newABTHashTable();

	                argss.putItemByString(KEY_DESTINATIONNAME,destFileName);
	                argss.putItemByString(KEY_TYPE ,new ABTString("Project"));
	                argss.putItemByString(KEY_SOURCE ,(ABTValue)subTaskProj);

	                newDriver.save(argss);
                }
                else
                    throw new ABTException("The subTaskProj is wrong.");
            }

            //DEBUG
            subProjectVector_.addElement(subProjectLinkID);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


}