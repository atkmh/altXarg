package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTValue;

import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

public class TimeEntryData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public TimeEntryData(ABTObject object, ABTUserSession session)
   {
      super(object,session);
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();

         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {
            if (property.getName().equals(FLD_TW_TIMESHEET) || property.getName().equals(FLD_TW_TYPECODE) || property.getName().equals(FLD_TW_CHARGECODE) || property.getName().equals(FLD_TW_ADJUSTEDENTRY)) {
               ABTValue code = object_.getValue(session_,property.getName());

               if (code == null || ABTError.isError(code) || ABTEmpty.isEmpty(code)) continue;

               ABTValue id = ((ABTObject)code).getValue(session_,FLD_TW_INTERNALID);
               table.put(property.getName(),id);
            } else if (property.getName().equals(FLD_TW_ASSIGNMENT)) {
               try {
                  ABTValue assignment = object_.getValue(session_,FLD_TW_ASSIGNMENT);

                  if (assignment == null || ABTError.isError(assignment) || ABTEmpty.isEmpty(assignment)) continue;

                  table.put(FLD_TW_ASSIGNMENT,((ABTObject)assignment).getValue(session_,FLD_TW_INTERNALID));
               } catch (Exception exception) {
                  exception.printStackTrace();
               }
            } else table.put(property.getName(),value);
         }
      }
      return table;
   }
}
