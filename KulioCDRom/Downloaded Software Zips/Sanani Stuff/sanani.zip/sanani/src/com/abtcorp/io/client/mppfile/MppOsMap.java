package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;
import com.abtcorp.core.ABTRemoteID;

public class MppOsMap extends OsMppMap
{

   private Project       mppProject_;
   private Hashtable     mppTasksHashMap_;
   private Hashtable     mppResourcesHashMap_;
   private Hashtable     mppAssignmentsHashMap_;
   private Hashtable     mppDependenciesHashMap_;

   public MppOsMap(Project mppProject)
   {
      mppProject_              = mppProject;
      mppTasksHashMap_         = new Hashtable();
      mppResourcesHashMap_     = new Hashtable();
      mppAssignmentsHashMap_   = new Hashtable();
      mppDependenciesHashMap_  = new Hashtable();
   }

   public boolean hasBeenUpdated(ABTValue id, ABTValue mppAbtValue)
   {

      if (mppAbtValue instanceof Task)
         if (mppTasksHashMap_.get(id)          != null) return true;
      if (mppAbtValue instanceof Resource)
         if (mppResourcesHashMap_.get(id)      != null) return true;
      if (mppAbtValue instanceof Assignment)
         if (mppAssignmentsHashMap_.get(id)    != null) return true;
//      if (mppAbtValue instanceof )
//         if (mppDependenciesHashMap_.get(id)   != null) return true;

      return false;

   }

   public void mppAdd(MppOsMatch match)
   {

      ABTValue mppAbtValue = match.getMppObject();

      if (mppAbtValue instanceof Task) {

         super.add(match);
         mppTasksHashMap_.put(match.getMppKeyAbtValue(), match);

      } else if (mppAbtValue instanceof Resource) {

         super.add(match);
         mppResourcesHashMap_.put(match.getMppKeyAbtValue(), match);

      } else if (mppAbtValue instanceof Assignment) {

         super.add(match);
         mppAssignmentsHashMap_.put(match.getMppKeyAbtValue(), match);

      }

   }

   //add dependency
   public void mppAdd(MppOsDependencyMatch match)
   {
      super.add(match);
      mppDependenciesHashMap_.put(match.getKey(), match);
   }

   public void delete(MppOsMatch match)
   {

      if (match != null) {

         ABTValue mppAbtValue = match.getMppObject();

         if (mppAbtValue instanceof Task) {

            if (match.getMppObject() != null)
               mppTasksHashMap_.remove(match.getMppKeyAbtValue());
            if (match.getOsObject() != null)
               osTasksHashMap_.remove(match.getOsKeyAbtValue());

            toBeDeleted(match);

         } else if (mppAbtValue instanceof Resource) {

            if (match.getMppObject() != null)
               mppResourcesHashMap_.remove(match.getMppKeyAbtValue());
            if (match.getOsObject() != null)
               osResourcesHashMap_.remove(match.getOsKeyAbtValue());

            toBeDeleted(match);

         } else if (mppAbtValue instanceof Assignment) {

            if (match.getMppObject() != null)
               mppAssignmentsHashMap_.remove(match.getMppKeyAbtValue());
            if (match.getOsObject() != null)
               osAssignmentsHashMap_.remove(match.getOsKeyAbtValue());

            toBeDeleted(match);

         }

         match.delete();

      }

   }

   public void remove(MppOsDependencyMatch match)
   {

      if (match != null) {

         if (match.getKey() != null)
            mppDependenciesHashMap_.remove(match.getKey());
         if (match.getOsKey() != null)
            osDependenciesHashMap_.remove(match.getOsKey());

//         super.remove(match);

      }
   }

   public Enumeration getMppTasksEnumeration(Project mppProject, boolean reload)
   {
      if (!reload) return getTasksEnumerator(); //if already filled

      //if want to refill
      if (tasksVector_. size() > 0) {
         tasksVector_.removeAllElements();
         mppResourcesHashMap_.clear();
      }

      if ( mppProject instanceof Project ){

         Tasks tasks = mppProject.getTasks();

         if ( tasks != null ) {

            for ( int i = 1; i <= tasks.getCount(); i++ ) {
               Task task = tasks.getItem(new ABTInteger(i));
               if (task != null)
         	   	if (task instanceof Task)
                     mppAdd(new MppOsMatch(task, new ABTInteger(task.getUniqueID())));
            }
         }

         tasks.release();
      }

      return getTasksEnumerator();
   }

   public Enumeration getMppResourcesEnumeration(Project mppProject, boolean reload)
   {

      if (!reload) return getResourcesEnumerator(); //if already filled

      //if want to refill
      if (resourcesVector_.size() > 0) {
         resourcesVector_.removeAllElements();
         mppResourcesHashMap_.clear();
      }

      if ( mppProject instanceof Project ){

         Resources resources = mppProject.getResources();

         if ( resources != null ) {

            for ( int i = 1; i <= resources.getCount(); i++ ) {
               Resource resource = resources.getItem(new ABTInteger(i));
               if (resource != null)
         	   	if (resource instanceof Resource)
                     mppAdd(new MppOsMatch(resource, new ABTInteger(resource.getUniqueID())));
            }
         }

         resources.release();
      }

      return getResourcesEnumerator();
    }

   public IABTObject getCorespondingTaskObject(Task mppTask)
   {
      int         taskUniqueId   = mppTask.getUniqueID();

      MppOsMatch  match          = (MppOsMatch) mppTasksHashMap_.get(
                                       new ABTInteger(taskUniqueId)
                                   );

      IABTObject  taskObject     = (IABTObject)match.getOsObject();

      return      taskObject;
    }

   public IABTObject getCorespondingTaskObject(int taskUniqueId)
   {

      MppOsMatch  match = getTaskMatch(taskUniqueId);

      return (IABTObject)match.getOsObject();

    }

   public Task getMppTask(int taskUniqueId)
   {

      MppOsMatch  match = getTaskMatch(taskUniqueId);

      return (Task)match.getMppObject();

    }

   public MppOsMatch getTaskMatch(int taskUniqueId)
   {
      return (MppOsMatch) mppTasksHashMap_.get(new ABTInteger(taskUniqueId));

   }

   public Resource getMppResource(int resourceUniqueId)
   {

      MppOsMatch  match = getResourceMatch(resourceUniqueId);

      return (Resource)match.getMppObject();

    }

   public MppOsMatch getResourceMatch(int resourceUniqueId)
   {
      return (MppOsMatch) mppResourcesHashMap_.get(new ABTInteger(resourceUniqueId));
   }

   public IABTObject getCorespondingResourceObject(Resource mppResource)
   {
      int         resourceUniqueId   = mppResource.getUniqueID();

      MppOsMatch  match          = (MppOsMatch) mppResourcesHashMap_.get(
                                       new ABTInteger(resourceUniqueId)
                                   );

      IABTObject  resourceObject     = (IABTObject)match.getOsObject();

      return      resourceObject;
   }

   public IABTObject getCorespondingResourceObject(int resourceUniqueId)
   {

      MppOsMatch  match = getResourceMatch(resourceUniqueId);

      return (IABTObject)match.getOsObject();

    }

   public void addResourceToMap(Resource resource, IABTObject resourceObject, int uniqueId)
   {
      MppOsMatch match = new MppOsMatch(resource, resourceObject, new ABTInteger(uniqueId));
      mppAdd(match);
      match.setOsKeyAbtValue((ABTValue)getRemoteId(resourceObject));
      osAdd(match);
   }

   public Enumeration getAssignmentsEnumeration(
                                 Project mppProject,
                                 boolean reload
                                               ) throws ABTException
	{

      if (!reload) return getAssignmentEnumerator();

      Enumeration tasksEnumerator = getMppTasksEnumeration(mppProject_, false);

      Resources resources = mppProject_.getResources();

      while (tasksEnumerator.hasMoreElements()) {

         MppOsMatch taskMatch = (MppOsMatch) tasksEnumerator.nextElement();

         Task mppTask = (Task) taskMatch.getMppObject();

         Assignments mppAssignments = mppTask.getAssignments();

         int assignmentCount = 0;

         if (mppAssignments != null)
            assignmentCount = mppAssignments.getCount();

 			for (int mppAssignmentIndex = 0; mppAssignmentIndex < assignmentCount ; mppAssignmentIndex++) {

            Assignment mppAssignment = mppAssignments.getItem(new ABTInteger(mppAssignmentIndex + 1));

            int resourceUniqueId = mppAssignment.getResourceUniqueID();

            Resource mppResource = resources.getItem(new ABTInteger(resourceUniqueId));

            MppOsMatch resourceMatch = getResourceMatch(resourceUniqueId);

            IABTObject resourceObject = resourceMatch.getOsObject();

            IABTObject taskObject = taskMatch.getOsObject();

            if  (resourceObject != null && taskObject != null) {

               if (mppAssignment != null) {

         	   	if (mppAssignment instanceof Assignment) {

                     MppOsAssignmentMatch assignmentMatch = new MppOsAssignmentMatch
                                       (
                                          mppAssignment,
                                          taskMatch,
                                          resourceMatch
                                       );

                     mppAdd(assignmentMatch);
                  }
               }
            }
         }
		}

      return getAssignmentEnumerator();
   }

   public void complete(ABTValue mppAbtValue, ABTValue key, UpdateIndicator upd)throws ABTException
   {

//      if (upd instanceof MppOsDependencyMatch)

      if (upd instanceof MppOsMatch) {

         MppOsMatch match = (MppOsMatch) upd;

         match.complete(mppAbtValue, key);

         if(mppAbtValue instanceof Task)

            mppTasksHashMap_.put(match.getMppKeyAbtValue(), match);

         else if  (mppAbtValue instanceof Resource)

            mppResourcesHashMap_.put(match.getMppKeyAbtValue(), match);

         else if  (mppAbtValue instanceof Assignment)

            mppAssignmentsHashMap_.put(match.getMppKeyAbtValue(), match);

      }
   }

   public Task getCorespondingMppTaskViaUniqueIdInRemoteId(IABTObject taskObject)
   {

      ABTRemoteID remoteId = getRemoteId(taskObject);

      int mppTaskUniqueId = ((ABTClientMppRemoteID)remoteId).getUniqueID();

      Tasks tasks = mppProject_.getTasks();

      return tasks.getUniqueID(mppTaskUniqueId);

   }

/*
   public Enumeration getMppDependenciesEnumeration(Project mppProject)
   {

      Enumeration mppTasksEnumerator = getMppTasksEnumeration(mppProject, false);

      while (mppTasksEnumerator.hasMoreElements()) {

         MppOsMatch taskMatch = (MppOsMatch) mppTasksEnumerator.nextElement();

         Task mppTask = (Task) taskMatch.getMppObject();

         createAndAddMppDependenciesToVector(taskMatch);
      }

     return getDependenciesEnumerator();

   }
*/
/*
   private void createAndAddMppDependenciesToVector(MppOsMatch taskMatch)
   {

      Task mppTask = (Task) taskMatch.getMppObject();

 	   if (mppTask.getUniqueIDPredecessors().length() > 0) {

         String uniqueIdPredecessors = mppTask.getUniqueIDPredecessors();

         Vector uniqueIDPredecessorList = fillUniqueIDPredecessorsListFromString(uniqueIdPredecessors);

  		   for (int j = 0; j < uniqueIDPredecessorList.size(); j++) {

            MppPredecessor mppPredecessor = convertStringToMppPredecessor((String)uniqueIDPredecessorList.elementAt(j));

		      if (mppPredecessor != null && mppPredecessor.predecessorUniqueId_ != -1) {

               MppDependency mppDependency = new MppDependency(mppTask, mppPredecessor);
               MppOsDependencyMatch match =  new MppOsDependencyMatch(taskMatch, mppDependency);

               getPredecessorTaskObject(match);

               addBoth(match);

            }
		   }
  	   }
   }

*/

}





