package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.io.team.connect.data.DataRow;
import com.abtcorp.io.team.connect.data.DataSet;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

public class FVDataRow implements Expandable{

   private Hashtable data_;
   private ABTValue key_;
   private int nHeaders_ = 0;

   FVDataRow(DataRow row){
      data_ = row.getValues();
      key_ = row.getKey();
   }
	
   public String toString()         { return new String("DataRow{}"); }

   public Hashtable expand()
   {       
	    Hashtable data = new Hashtable();
	    
   	    for(Enumeration e = data_.keys(); e.hasMoreElements();)
	    {
	   	   Object key = e.nextElement();
            Object value = data_.get(key);
	    	
            Vector dataColumn = new Vector(1);
            if(value instanceof ABTArray)
                dataColumn.addElement(new FVArray((ABTArray)value));
            else if(value instanceof DataSet)
                dataColumn.addElement(new FVDataSet((DataSet)value));
            else if(value instanceof Hashtable)
                dataColumn.addElement(new FVHashtable((Hashtable)value));    
            else 
                dataColumn.addElement(value.toString());

            data.put(key.toString(), dataColumn);
	    }
   	
	    return data;
   }
   
}