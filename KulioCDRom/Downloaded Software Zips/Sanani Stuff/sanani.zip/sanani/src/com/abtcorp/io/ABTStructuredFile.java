package com.abtcorp.io;

import java.io.*;
import java.util.*;

class ABTDirectoryEntry implements Serializable
{
   long  position_;
   int   length_;

   ABTDirectoryEntry(long position, int length) {position_ = position; length_ = length;}

   public String toString() {return length_ + "bytes@0x" + Long.toHexString(position_);}

   public int getLength() {return length_;}
}

class ABTDirectory extends Hashtable
{
   ABTDirectory() {}

   public synchronized Object put(Object key, Object value)
   {
      ABTDirectoryEntry entry = (ABTDirectoryEntry)super.put(key, value);

      free(entry);

      return entry;
   }

   public synchronized Object remove(Object key)
   {
      ABTDirectoryEntry entry = (ABTDirectoryEntry)super.remove(key);

      free(entry);

      return entry;
   }

   void free(ABTDirectoryEntry entry)
   {
      // TODO: save/merge entry in free list sorted by position
   }

   synchronized long allocate(int length)
   {
      // TODO: rover search free list for first fit

      return 0;
   }

   public String toString() {return size() + "keys " + super.toString();}
}

public class ABTStructuredFile extends RandomAccessFile
{
   ABTDirectory directory_;

   class ABTOutputStream extends ByteArrayOutputStream
   {
      Object key_;

      ABTOutputStream(Object key) throws IOException {super(1024); key_ = key;}

      public void close() throws IOException {writeBytes(key_, buf, 0, count);}
   }

   public ABTStructuredFile(String name) throws IOException {super(name, "rw"); readDirectory();}
   public ABTStructuredFile(File file)   throws IOException {this(file.getPath());}

   public void close() throws IOException {writeDirectory(); super.close();}

   public Enumeration keys()
   {
      // TODO: we should return the keys ordered by position

      return directory_.keys();
   }

   public int size()
   {
      return directory_.size();
   }

   ABTDirectoryEntry getEntry(Object key)
   {
      if (key != null) return (ABTDirectoryEntry)directory_.get(key);

      try {
         seek(0);

         long position = readLong();
         int  length   = readInt();

         return new ABTDirectoryEntry(position, length);
      } catch (IOException exception) {
      }

      return null;
   }

   void putEntry(Object key, long position, int length)
   {
      if (key != null) directory_.put(key, new ABTDirectoryEntry(position, length));
      else
         try {
            seek(0);

            writeLong(position);
            writeInt(length);
         } catch (IOException exception) {
         }
   }

   public synchronized byte[] readBytes(Object key) throws IOException
   {
      ABTDirectoryEntry entry = getEntry(key); if (entry == null) return null;

      byte[] array = new byte[entry.length_];

      seek(entry.position_);

      read(array);

      return array;
   }

   synchronized void writeBytes(Object key, byte[] array, int offset, int length) throws IOException
   {
      long position = directory_.allocate(length); if (position == 0) position = length();

      seek(position);

      write(array, offset, length);

      putEntry(key, position, length);
   }

   public int getEntryLength(Object key) throws IOException
   {
      if (key == null) return -1;

      ABTDirectoryEntry entry = getEntry(key);
      if (entry == null) return -1; // No entry found.
      return entry.getLength();
   }

   public void writeBytes(Object key, byte[] array) throws IOException
   {
      if (array == null) remove(key);
      else               writeBytes(key, array, 0, array.length);
   }

   public InputStream getInputStream(Object key) throws IOException
   {
      byte[] array = readBytes(key); if (array == null) return null;

      return new ByteArrayInputStream(array);
   }

   public OutputStream getOutputStream(Object key) throws IOException
   {
      return new ABTOutputStream(key);
   }

   public Object readObject(Object key) throws IOException, ClassNotFoundException
   {
      InputStream input = getInputStream(key); if (input == null) return null;

      ObjectInputStream stream = new ObjectInputStream(input);

      Object object = stream.readObject();

      stream.close();

      return object;
   }

   public void writeObject(Object key, Object object) throws IOException
   {
      if (object == null) remove(key);
      else {
         ObjectOutputStream stream = new ObjectOutputStream(getOutputStream(key));

         stream.writeObject(object);

         stream.close();
      }
   }

   public void remove(Object key) {directory_.remove(key);}

   public String toString() {return super.toString() + " " + directory_.toString();}

   void readDirectory() throws IOException
   {
      try {
         directory_ = (ABTDirectory)readObject(null);

         directory_.free(getEntry(null));   // reclaim directory
      } catch (Exception exception) {
      }

      if (directory_ == null) {
         seek(0);       // new file or bad directory
         writeLong(0);  // write position to reserve space
         writeInt(0);   // write length to reserve space

         directory_ = new ABTDirectory();

         long position = getFilePointer();
         int  length   = (int)(length() - position);

         directory_.free(new ABTDirectoryEntry(position, length));   // reclaim rest of file
      }
   }

   void writeDirectory() throws IOException {writeObject(null, directory_);}
}