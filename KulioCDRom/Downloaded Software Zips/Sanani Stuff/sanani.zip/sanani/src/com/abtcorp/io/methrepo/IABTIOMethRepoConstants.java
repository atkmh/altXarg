package com.abtcorp.io.methrepo;

/*
 * IABTIOMethRepoConstants.java 06/11/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date          Author      Description
  * 06-11-98      LZX         Initial Implementation
  * 06-19-98      LZX         Fixed the MRDependency query.
  * 06-22-98      LZX         Added queries for site object population (temporarily).
  * 06-24-98      LZX         Added constants for exception messages.
  * 07-10-98      LZX         Added constants for repository read/write access.
  * 08-05-98      LZX         Took out queries for PRField and PREnum.
  *
  */

/**
 *  IABTIOMethRepoConstants is a Java interface for specifying constants for the Sanani
 *  methodology drivers.
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTDriver
 */


public interface IABTIOMethRepoConstants
{
 	//
 	// Rule base string when invoking createObject() or createObjectSet() in
 	// the object space.
 	//

 	public static final String RULE_BASE = "com.abtcorp.objectModel".intern();

 	//
 	// Table names not found in ABTNames.
 	//

   public static final String TBL_MRPREDTASK = "MRPredTask".intern();
   public static final String TBL_MRSUCCTASK = "MRSuccTask".intern();

   //
   // SOL queries used to populate method related objects.
   //
   public static final String QRY_ALLMETHODS = "select * from MRMethod";

   public static final String QRY_METHOD = "select * from MRMethod where prExternalID = ";

   public static final String QRY_METHODTASKS = "select * from MRTask where prMethodID = ";

   public static final String QRY_METHODTASKASSIGNMENTS = "SELECT MRAssignment.* " +
                              "FROM MRAssignment, MRTask, MRMethod " +
                              "WHERE MRTask.prID=MRAssignment.prTaskID AND " +
                              "MRTask.prMethodID = MRMethod.prID AND " +
                              "MRMethod.prID = ";

//   public static final String QRY_METHODTASKDELIVERABLES = "SELECT * from MRDeliverable where prMethodID = ";

   public static final String QRY_METHODTASKESTIMATES = "SELECT MRTaskEstimate.* " +
                              "FROM MRTaskEstimate, MRTask, MRMethod " +
                              "WHERE MRTaskEstimate.prTaskID = MRTask.prID AND " +
                              "MRTask.prMethodID = MRMethod.prID AND " +
                              "MRMethod.prID = ";

   // need to add "distinct" to avoid getting duplicate records
   public static final String QRY_METHODDEPENDENCIES	= "SELECT DISTINCT MRDependency.* " +
                              "FROM MRDependency, MRTask, MRMethod " +
                              "WHERE (MRTask.prID=MRDependency.prPredTaskID OR " +
                              "MRTask.prID = MRDependency.prSuccTaskID) AND " +
                              "MRTask.prIsTask <> 0 AND " +
                              "MRTask.prMethodID = MRMethod.prID AND " +
                              "MRMethod.prID = ";

   public static final String QRY_METHODDELIVERABLES = "select * from MRDeliverable where prMethodID = ";

   public static final String QRY_METHODDELIVERABLETASKS = "SELECT MRTask.* " +
                              "FROM MRTask, MRDeliverable, MRTaskDelivLink " +
                              "WHERE MRTaskDelivLink.prTaskID = MRTask.prID AND " +
                              "MRTaskDelivLink.prDeliverableID = MRDeliverable.prID ";

   public static final String QRY_METHODTASKDELIVLINK = "SELECT * FROM MRTaskDelivLink " +
                              "WHERE MRTaskDelivLink.prDeliverableID = ";

   public static final String QRY_METHODPACKAGES = "select * from MRPackage where prMethodID = ";

   public static final String QRY_METHODPACKAGEMEMBERS = "SELECT MRPackageContent.* " +
                              "FROM MRPackageContent, MRPackage, MRMethod " +
                              "WHERE MRPackageContent.prPackageID = MRPackage.prID AND " +
                              "MRPackage.prMethodID = MRMethod.prID AND " +
                              "MRMethod.prID = ";

   public static final String QRY_METHODPAGES = "select * from MRPage where prMethodID = ";

   public static final String QRY_METHODPAGEMEMBERS = "SELECT MRPageContent.* " +
                              "FROM MRPageContent, MRPage, MRMethod " +
                              "WHERE MRPageContent.prPageID = MRPage.prID AND " +
                              "MRPage.prMethodID = MRMethod.prID AND " +
                              "MRMethod.prID = ";

   public static final String ORDERBY_WBSSEQUENCE = " order by prWBSSequence";

   public static final String ORDERBY_ID = " order by prID";

}
