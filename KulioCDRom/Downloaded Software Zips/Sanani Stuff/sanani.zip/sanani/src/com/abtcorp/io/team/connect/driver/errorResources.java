package com.abtcorp.io.team.connect.driver;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public class errorResources extends ListResourceBundle implements errorMessages
{
public Object[][] getContents() {
			return contents; 
}

static final Object[][] contents = {
{ERR_0.getCode(),"Unable to create an output stream to servlet"},
{ERR_1.getCode(),"Failed to make connection to URL"},
{ERR_2.getCode(),"Must open a URL prior to calling populate."},
{ERR_3.getCode(),"Error encountered in ABT Connect URL Driver."},
{ERR_4.getCode(),"Error encountered in ABT Connect File Driver."},
{ERR_5.getCode(),"Unable to access data on server."},

 };
}