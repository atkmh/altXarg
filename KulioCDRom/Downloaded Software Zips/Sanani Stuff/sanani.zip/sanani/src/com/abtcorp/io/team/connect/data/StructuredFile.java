package com.abtcorp.io.team.connect.data;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import com.abtcorp.io.ABTStructuredFile;

public class StructuredFile extends ABTStructuredFile
{
   String path_;

   public StructuredFile(String name) throws IOException
   {
      super(name);
      path_ = name;
   }

   public StructuredFile(File file) throws IOException
   {
      super(file.getPath());
      path_ = file.getPath();
   }

   public String getPath() {return path_;}

   public InputStream getObjectInputStream(Object key) throws IOException
   {
      InputStream input = getInputStream(key);

      if (input == null) return null;

      TWInputStream stream = new TWInputStream(input);

      return stream;
   }

   public OutputStream getObjectOutputStream(Object key, Object object) throws IOException
   {
      if (object == null) {
         remove(key);
         return null;
      } else {
         TWOutputStream stream = new TWOutputStream(getOutputStream(key));
         return stream;
      }
   }

   private static File changeExtension(File path, String extension)
   {
      String result = path.getPath();

      int name   = result.lastIndexOf(File.separator);
      int period = result.lastIndexOf('.');

      if (period > name) result = result.substring(0, period);

      return new File(result + "." + extension);
   }

   public static StructuredFile compact(StructuredFile file) throws IOException
   {
      File temporary = changeExtension(new File(file.getPath()), "tmp");

      temporary.delete();

      StructuredFile tmp = new StructuredFile(temporary);

      for (Enumeration enumeration = file.keys(); enumeration.hasMoreElements(); ) {
         Object key = enumeration.nextElement();

         tmp.writeBytes(key, file.readBytes(key));
      }

      tmp.close();

      file.close();

      File f = new File(file.getPath());
      //f.delete(); // Remove old ABTStructuredFile

      if( !f.delete() ){
        temporary.delete(); 
        return new StructuredFile(file.getPath());
      }
      
      temporary.renameTo(f);
      
      return new StructuredFile(f);
   }
}
