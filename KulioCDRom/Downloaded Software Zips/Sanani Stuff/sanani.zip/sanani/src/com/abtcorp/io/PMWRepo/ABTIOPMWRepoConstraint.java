package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoConstraint.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-22-98    SOB            Initial Implementation
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support required params on create.
 * 07-27-98    SOB            Mods to support save() processing.
 * 10-09-98    SOB            Beginnings of progress reporting
 
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoConstraint is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTConstraint object in the object space.
 *  <pre>
 *       ABTIOPMWRepoConstraint rd = new ABTIOPMWRepoDependency(ABTSession sess,
 *                                                          ABTRepository repo);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoConstraint extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private Hashtable ht_;
   
   public ABTIOPMWRepoConstraint() {/* implicit call to super() here */}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoConstraint(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable ht,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_CONSTRAINT, OBJ_CONSTRAINT, progress);
      projObj_ = projObj;
      projectID_ = projID;
      ht_ = ht;
   }
   
   /**
    *    Constructor used by the save process.
    *    @param space: an object space reference
    *    @param driver: a driver reference
    *    @param project: a project object reference
    *    @param forceAddNew: if true, all objects to be saved are forced to be "new"; otherwise, 
    *           new objects are only determined by the presence of a non-null remote ID
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoConstraint(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_CONSTRAINT, OBJ_CONSTRAINT, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with objects appropriate to this helper class.
    *    @param parms: an ABTArray of parameters meaningful to the populate process
    *    @return an ABTValue indicating the success/failure of the populate process
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;
      
      try
      {
         getCursor();
      
         //
         // For each constraint tuple in the result set, make sure one exists in the object
         // space.
         //
         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this constraint object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the constraint object already exists in the object space.
            //
            object = find(OBJ_CONSTRAINT, id_);

            //
            // If the object found is an ABTObject, then the constraint object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new constraint object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }

         }              // end while (cursor_.moveNext())
      }
      finally
      {
         closeCursor();
      }

      return (ABTValue) null;
   }
   
   /**
    *    Creates a new object appropriate to this helper class.
    *    @param parms: an ABTArray of parameters meaningful to the create process
    *    @return the ABTObject created
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Ask the object space to create a new constraint object.
      //
      // 
      // Lookup the associated task in the task hash table.
      // Set the associated task object as a required param for constraint object creation.
      //
      Long associatedTaskID = new Long(cursor_.getFieldInt(FLD_TASKID));
      ABTObject associatedTask = (ABTObject) ht_.get(associatedTaskID);
      if (associatedTask == null) 
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "RepoConstraint->create",
                                              errorMessages.ERR_NO_TASK_FOR_CONSTRAINT,
                                              null) );
      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_TASK, associatedTask);
      
      //
      // Ask the object space to create a new constraint object.  Check for errors
      // locally (here, in this method).  If an error occurred creating the 
      // constraint object, skip the constraint by returning null to the caller.
      //
      ABTValue v = createObject(OBJ_CONSTRAINT, id_, reqparms, false);
      if (ABTError.isError( v )) 
         return null;
      
      //
      // Initialize repository properties of the new dependency object.
      //
      setValues((ABTObject) v);

      return v;
   }
   
   /**
    *    Updates an existing object appropriate to this helper class.
    *    @param parms: an ABTArray of parameters meaningful to the update process
    *    @return the ABTObject updated
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }
   
   private void setValues(ABTObject obj) throws ABTException
   {
   	setPropertyValues(ps_, cursor_, obj);
   }
   
   private void getCursor()
   {
      closeCursor();
      
      //
      // Select all the constraints for the desired project.  
      //
      cursor_ = repo_.select(QRY_PROJECTCONSTRAINTS);
      cursor_.andFilter(TBL_TASK + "." + FLD_PROJECTID + "=" + projectID_);
   }

   /**
    *    Saves objects appropriate to this helper object back to the ABT Repository.
    *    @param parms: an ABTArray containing parameters for the save process (currently none)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get a constraint cursor and order the result set by prID.
      //
      getCursor();
      cursor_.setSort(TBL_CONSTRAINT + "." + FLD_ID);
      
      //
      // Loop through all of the project's task objects and inspect the constraint
      // object set.  If the constraint object set contains at least one constraint
      // object, save each constraint to the repository.
      //
      ABTObjectSet tasks = getObjectSet(projObj_, OFD_ALLTASKS);
      int size = size(tasks);
      for (int i = 0; i < size; i++)
      {
         ABTObject task = at(tasks, i);
         ABTObjectSet constraints = getObjectSet(task, OFD_CONSTRAINTS);
         if (size(constraints) > 0)
         {
            setSomeProperties(constraints);
            save(constraints);
         }
      }
      
      closeCursor();
   }

   private void setSomeProperties(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);
      
      //
      // For each constraint in the object set, make sure its owning task's
      // prID is set into the task ID property of the constraint.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject constraint = at(oSet, i);
         ABTObject owningTask = getObject(constraint, OFD_TASK);
         setValue(constraint, OFD_TASKID, getValue(owningTask, OFD_ID));
      }
   }
}