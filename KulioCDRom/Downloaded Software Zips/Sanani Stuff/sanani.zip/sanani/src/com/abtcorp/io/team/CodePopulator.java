package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTSortedArray;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class CodePopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   private String type_;

   public CodePopulator() {}

   public CodePopulator(ABTRepositoryDriver driver,String type)
   {
      super(driver);
      type_ = type;
   }

   public void setType(String type) {type_ = type;}

   protected ABTValue addObject(ABTObjectSet codes)
   {
      ABTObject code = (ABTObject)codes.addNew(session_);
      code.setValue(session_,FLD_TW_ID,cursor_.getField(FLD_ID));
      code.setValue(session_,FLD_TW_EXTERNALID,cursor_.getField(FLD_EXTERNALID));
      code.setValue(session_,FLD_TW_NAME,cursor_.getField(FLD_NAME));
      RemoteID.setRemoteID(code,session_);
      return code;
   }

   public ABTValue populate() throws ABTException
   {
      ABTObjectSet codes = (ABTObjectSet)getObjectSet(type_);

      if (codes == null || cursor_ == null) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

      if (type_.equals(OBJ_TW_TYPECODE)) {
	   	typeCodes_ = new ObjectIDSortedArray(new TWObjectComparator(session_));
	   	typeCodes_.setSize(cursor_.getRecordCount());
      } else if (type_.equals(OBJ_TW_CHARGECODE)) {
	   	chargeCodes_ = new ObjectIDSortedArray(new TWObjectComparator(session_));
	   	chargeCodes_.setSize(cursor_.getRecordCount());
      }
   	
      while(cursor_.moveNext()) {
         ABTObject code = (ABTObject)addObject(codes);
	      if (type_.equals(OBJ_TW_TYPECODE)) {
		   	typeCodes_.add(code);
	      } else if (type_.equals(OBJ_TW_CHARGECODE)) {
		   	chargeCodes_.add(code);
	      }
         updateStatus(code);
      }

      closePopulatorCursor();
      total_ = 0;
      count_ = 0;
      
      return codes;
   }
}