package  com.abtcorp.io.siterepo;

/*
 * ABTSiteError.java 10/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 10-9-98	    LZX		        Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */



/**
 * This class provides basic functionality for Error Handling for
 * the site repo driver.
 * <p>
 *
 *
 * @version	1.0
 * @author      L. Xiao
 * @see         <path to another class> %%%%% cross reference
 */

public class ABTSiteError extends ABTError
{
   private static String defaultPackage_ = "com.abtcorp.io.siterepo";
   
   /**
   *  default constructor
   *  @param method_ name of routine creating it
   *  @param code_ ErrorCode
   */
   public ABTSiteError(
            String component,
            String method,
            int code,
            Object info)
   {  super(defaultPackage_, component, method, code, info);  }
   
   /**
   *  default constructor
   *  @param method_ name of routine creating it
   *  @param code_ ErrorCode
   */
   public ABTSiteError(
            String component,
            String method,
            String code,
            Object info)
   {  super(defaultPackage_, component, method, code, info);  }
   
}