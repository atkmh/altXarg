/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTErrorCode.java, 5, 12/17/98 11:21:53 AM, Steve Pierson$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
 
package com.abtcorp.core;

import java.io.Serializable;

/**
 * ABTErrorCode class - utility class to allow constant definitions of
 * package-specific error messages
 * <p>
 *
 *
 * @version	1.0
 * @author      Steve Pierson
 */

public class ABTErrorCode implements IABTErrorPriorities, Serializable
{
    private static final long serialVersionUID = -3825448622959186263L;
	 private String Package;
    private String Code;
    private int Priority;
    
   /**
   *  constructor
   *  @param package_ package of the error message resource
   *  @param code_ textual representation of resource key int
   */
    public ABTErrorCode(String package_, String code_, int priority_){
        Package = package_;
        Code = code_;
        Priority = priority_;
        }
   /**
   *  constructor
   *  @param package_ package of the error message resource
   *  @param code_ textual representation of resource key int
   */
    public ABTErrorCode(String package_, String code_){
        Package = package_;
        Code = code_;
        Priority = UNRECOVERABLE_ERROR;
        }
 
    public boolean equalTo(ABTErrorCode other){
        if (Package.equals(other.Package) && Code.equals(other.Code))
            return true;
        return false;
        }
        
    public String toString()   {return Package+":"+Code;}
    public String getPackage() {return Package; }
    public String getCode()    {return Code;    }
    public int    getPriority(){return Priority;}
    
}