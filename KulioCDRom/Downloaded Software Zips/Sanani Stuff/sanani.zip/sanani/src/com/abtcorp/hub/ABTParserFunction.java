package com.abtcorp.hub;

/*
 * ABTParserFunction.java 05/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author        Description
  * 05-07-98	 JSE           Initial Design
  *
  */


/**
 * Basic ABTParserFunction class - base class for handling parser functions
 *
 * @version	1.0
 * @author      Scott Ellis
 */



import java.util.*;
import com.abtcorp.core.*;
import com.abtcorp.parser.*;

public class ABTParserFunction extends ABTValue implements IABTLogicalOperation
{
   protected ABTArray instances;
   protected String   field;     // field in parent object containing some object references (i.e. an objectset)
   protected String   subfield;  // field in child object for value-operation evaluation
   protected ABTValue value;
   protected int      operation;
   protected ABTUserSession mySession; 

   /**
   * class constructor for parser function
   * e.g. : <Function Name>( Childtasks.PRNAME like 'SANANI' )
   */
   public ABTParserFunction( ABTUserSession session,ABTArray instances_, String field_ , String subfield_, int operation_, ABTValue value_ )
   {
      super();
      mySession = session;
      instances = instances_;
      field = field_;
      subfield = subfield_;
      operation = operation_;
      value = value_;
   }

   /**
   *  return the ABTObject currently in the instances
   *  @return ABTObject
   */
   public ABTValue lookup()
   {
        ABTObject o = (ABTObject)instances.at( 0 );
        if( o != null )
            return o.getValue( mySession,field,null );

        return new ABTErrorCore( "ParserFunction","lookup",
            "122", "" );
   }

   protected boolean evaluatePos( ABTValue leftOperand, ABTValue rightOperand )
   {
      switch( operation )
      {
         case ABT_EXPR_GREATER:
            return ( leftOperand.compareTo( rightOperand ) > 0 );
         case ABT_EXPR_GREATEREQUAL:
            return ( leftOperand.compareTo( rightOperand ) >= 0 );
         case ABT_EXPR_SMALLER :
            return ( leftOperand.compareTo( rightOperand ) < 0 );
         case ABT_EXPR_SMALLEREQUAL:
            return ( leftOperand.compareTo( rightOperand ) <= 0 );
         case ABT_EXPR_LIKE:
            return elementLike( leftOperand, rightOperand );
         case ABT_EXPR_NOTLIKE:
            return !elementLike( leftOperand, rightOperand );
         case ABT_EXPR_EQUAL:
            return ( leftOperand.compareTo( rightOperand ) == 0 );
         case ABT_EXPR_NOTEQUAL:
            return ( leftOperand.compareTo( rightOperand ) != 0 );
         default:
            return leftOperand.booleanValue();
      }
   }

   protected boolean elementLike( ABTValue leftOperand, ABTValue rightOperand )
   {
      /* Find the percent sign
      */
      String left  = leftOperand.stringValue();
      String right = rightOperand.stringValue();

      int charpos = right.indexOf( '%' );

      if( charpos == -1 )
      {
         /* If no percent sign, then do a straight compare
         */
         return ( leftOperand.compareTo( rightOperand ) == 0 );
      }
      else
      if( charpos == 0 )
      {
         /* If the percent is the first character, then make sure that the
            right sequence of characters beyond the percent sign terminates
            the left string
         */
         String rightsub = right.substring( 1 );
         int rightindex = left.indexOf( rightsub );
         return ( rightindex != -1 && rightindex + rightsub.length() ==
                  left.length() );
      }
      else
      if( charpos == right.length() - 1 )
      {
         /* If the percent is the last character, then make sure that every
            character before the percent exists as the first part of the left
            operand.
         */
         String rightsub = right.substring( 0, right.length() - 1 );
         return ( left.indexOf( rightsub ) == 0 );
      }
      else
      {
         /* The percent is somewhere in the middle of the string.
            Determine that the string left of the percent is the first part
            of matching string, and that the string to the right of the 
            percent is the last.
         */
         String leftsub  = right.substring( 0, charpos );
         String rightsub = right.substring( charpos + 1 );
         int leftindex   = left.indexOf( leftsub );
         int rightindex  = left.indexOf( rightsub );

         return ( leftindex == 0 && rightindex != -1 &&
                  rightindex == left.length() - rightsub.length() );
      }
   }

   /**
   *  evaluate the expression
   *  @return boolean
   */
   public boolean booleanValue()
   {

      ABTValue val = lookup();
      if (val == null)
         return false; //?whoops

      if (!(val instanceof ABTObjectSet))
         return false; //?whoops

      Enumeration e = ((ABTObjectSet)val).elements(mySession);
      while (e.hasMoreElements())
      {
         // abolute index-access better be in correct bounds - otherwise
         // there will be an array-out-of-bounds exception
         ABTValue v1 = (ABTValue) e.nextElement();
         if (ABTError.isError(v1))
         {
            // whoops
         }
         else
         {
             ABTObject o = (ABTObject)v1;
             if( evaluatePos( o.getValue(mySession, subfield,null ), value ) )
                return true;
         }
         
      }

      return false;
   }

   /**
   *  by default return the error code
   *  @return short
   */
   public short shortValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.shortValue();
      return super.shortValue();
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int intValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.intValue();
      return super.intValue();
   }

   /**
   *  by default return the error code
   *  @return double
   */
   public double doubleValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.doubleValue();
      return super.doubleValue();
   }

   /**
   *  by default return null
   *  @return Date
   */
   public ABTDate dateValue(boolean pm)
   {
      ABTValue val = lookup();
      if (val != null)
        return val.dateValue(pm);
      return super.dateValue(pm);
   }

   /**
   *  by default return the true/false
   *  @return String
   */
   public String stringValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.stringValue();
      return super.stringValue();
   }

   /**
   *  by default return the time this thing was created
   *  @return ABTTime
   */
   public ABTTime timeValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.timeValue();
      return super.timeValue();
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int hashCode()
   {
      ABTValue val = lookup();
      if (val != null)
         return val.hashCode();
      return super.hashCode();
   }

   /**
   *  compare to ABTParserFunctions: first use the errorcode and (if not available)
   *  use the error message
   *  @param object - to compare me to
   *  @return int (0=equal, -1/+1 as usual)
   */
   public int compareTo( Object object )
   {
      if (object == null) return 1;     
      ABTValue val = lookup();
      if( val != null )
         return val.compareTo(object);
      else
         return ( object == null ? 0 : 1 );
   }
}

