package com.abtcorp.io.team.connect;

import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.team.ProjectPopulator;
import com.abtcorp.io.team.TWPopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.UserRight;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTDate;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.idl.IABTPropertyType;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ConnectProjectPopulator extends ProjectPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants, IABTPropertyType
{
   private String server_;
   private String[] servers_;
   private int[] ids_;
   private int sessionid_;
   private int start_;
   private int finish_;

   public ConnectProjectPopulator() {}

   public ConnectProjectPopulator(ABTRepositoryDriver driver)
   {
      super(driver);
      checkProperties(OBJ_TW_PROJECT,FLD_TW_LOADED,PROP_BOOLEAN);
   }

   protected void setServerName(String server) {server_ = server;}
   protected String getServerName()         {return server_;}

   public ABTValue populate() throws ABTException
   {
      // get the object set of projects - we will add to this set
      ABTObjectSet projects = getObjectSet(OBJ_TW_PROJECT);

      if (projects == null || cursor_ == null || cursor_.getRecordCount() == 0) {
         if (cursor_ != null) closePopulatorCursor();
         return null;
      }

   	ABTObjectSet users = null;
   	
      ABTValue value = getDriver().getSpace().getObjects(getSession(),OBJ_TW_USER);
   	if (!ABTValue.isEmpty(value) && !ABTError.isError(value)) users = (ABTObjectSet)value;
     

      if (teamCursor_ != null) teamCursor_.moveFirst();
      if (noteCursor_ != null) noteCursor_.moveFirst();
      if (notePopulator_ == null) notePopulator_ = new ConnectNotePopulator(getDriver(),OBJ_TW_PROJECT, getSpace(), getSession());

      // move through the project cursor adding each project to the object space
      while(cursor_.moveNext()) {

         // if the project is already in the object space, continue
         ABTValue temp = projects.select(getSession(), FLD_TW_ID + " = " + cursor_.getField(FLD_ID));
         if (!ABTError.isError(temp) && !ABTValue.isEmpty(temp)) {
            if (((ABTObjectSet)temp).size(getSession()) > 0) continue;
         }

         // add the project to the object space
         ABTObject project = (ABTObject)addObject(projects);

         // add the tasks for this project to the object space
         addTasksForProject(project);

         // link project to resources that are team members
         createProjectTeams(project);

         // check if user has edit project plan rights over this project
         checkProjectRight(CAN_EDITPROJECTPLAN, project, FLD_TW_EPP_PROJECTS, cursor_);

         // check if user has project manager rights over this project
         checkProjectRight(IS_PROJECTMANAGER, project, FLD_TW_MGR_PROJECTS, cursor_);

         // add the notes for this project to the object space
         addNotesForProject(project);

         updateStatus(project);
      }

      closePopulatorCursor();

      if (noteCursor_ != null) noteCursor_.release();
      noteCursor_ = null;

      if (teamCursor_ != null) teamCursor_.release();
      teamCursor_ = null;

      return projects;
   }


   public void addProperties()
   {
      checkProperties(OBJ_TW_PROJECT,FLD_TW_LOADED,PROP_BOOLEAN);
   }

   public void release()
   {
      ABTCursor cursor = getDriver().getRepository().select("select * from PRTemporary where prName = 'Project for " + server_ + "' and prSessionID = " + sessionid_);
      cursor.deleteAll();
      cursor.update();
      cursor.release();
   }
	
   protected void checkProjectRight(String right, ABTObject project, String fieldName, ABTCursor cursor)
   {
   	for (int i = 0;i < userRights_.size();i++) {
   		UserRight u = (UserRight)userRights_.at(i);
   		if (u.hasRight(right,cursor,cursor.getTableName(),cursor.getField(FLD_ID).intValue())) {
   			ABTObject user = u.getUser();   			
            ABTValue set = user.getValue(getSession(),fieldName,null);
            if (!ABTValue.isEmpty(set) && !ABTError.isError(set)) {
               // Maintain uniqueness of the set.
               if (((ABTObjectSet)set).contains(getSession(),project)) return;
               ((ABTObjectSet)set).add(getSession(),project);
            }
         }
   	}
   }

	protected void addTasksForProject(ABTObject project)
   {
      ConnectTaskPopulator taskPopulator = new ConnectTaskPopulator(getDriver(), project, getSpace(), getSession(), server_);
   
      try {
         taskPopulator.setNoteCursor(getTaskNoteQuery(project));
         taskPopulator.setAssignmentCursor(getTaskAssignmentQuery(project));
      	taskPopulator.setServerName(server_);
         taskPopulator.setPopulatorCursor("select * from PRTask where prProjectID=" + project.getValue(getSession(),FLD_TW_ID,null).intValue() + " order by prWBSSequence", false);
         taskPopulator.populate();
      } catch (Exception e) {
      }
      
   }

	public void setAssignmentPeriod(int daysBefore, int daysAfter) throws ABTException
   {      
      boolean manual = (daysBefore >= 0 && daysAfter >= 0) ? true : false;

      ABTCursor cursor = getCurrentTimePeriod();

      if (manual) {
         start_ = getCurrentTimePeriodStart(cursor) - daysBefore;
         finish_ = getCurrentTimePeriodStart(cursor) + daysAfter;
      } else {
         int start = getCurrentTimePeriodStart(cursor);
         int finish = getCurrentTimePeriodFinish(cursor);
         ABTTime end = new ABTTime(ABTDate.toDate(finish+1,0));
         ABTTime begin = new ABTTime(ABTDate.toDate(start,0));

         // Find the active assignment pool start. We will look for the most recent closed time period
         // and use it's finish date as the start of the assignment pool. If we don't find any closed time periods
         // we will use the oldest open time period's start date as the start date for the assignment pool.
         ABTCursor temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen=0 and prFinish <= " + begin.toSQL() + " order by PRTimePeriod.prStart");

         if (temp.moveLast()) start_ = temp.getFieldDate(FLD_FINISH, false).getJulian();
         else {
            temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen <> 0 and prFinish <= " + begin.toSQL() + " order by prStart");
            if (temp.moveFirst()) start_ = temp.getFieldDate(FLD_START, false).getJulian();
         }

         // Find the active assignment pool finish. We will look for the closed time period in the future closest to the finish of
         // the current time period and use that as our finish date for the assignment pool. If there are no closed time periods closed
         // in the future we will use the open time period farthest in the future for our finish date.
         temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen=0 and prStart >= " + end.toSQL() + " order by PRTimePeriod.prStart");

         if (temp.moveFirst()) finish_ = temp.getFieldDate(FLD_START,false).getJulian();
         else {
            temp = getDriver().getRepository().select("select * from PRTimePeriod where prIsOpen <> 0 and prStart >= " + end.toSQL() + " order by PRTimePeriod.prStart");
            if (temp.moveLast()) finish_ = temp.getFieldDate(FLD_FINISH, false).getJulian();
         }
         temp.release();
      }

      cursor.release();
   }

   public int getAssignmentPeriodStart()      {return start_;}
   public int getAssignmentPeriodFinish()     {return finish_;}

	public String getActiveAssignmentQuery(boolean strict, int start, int finish)
   {
      ABTTime end = new ABTTime(ABTDate.toDate(finish+1,0));
      ABTTime begin = new ABTTime(ABTDate.toDate(start,0));

      if (strict) {
         return new String("select PRAssignment.*, PRTask.prProjectID, PRTask.prID, PRTask.prWBSSequence from PRAssignment, PRTask, PRProject, PRResource, PRTeam where " +
                           "PRAssignment.prTaskID=PRTask.prID and " +
                           "PRAssignment.prResourceID=PRResource.prID and " +
                           "PRTask.prProjectID=PRProject.prID and " +
                           "PRTeam.prProjectID=PRProject.prID and " +
                           "PRTeam.prResourceID=PRResource.prID and " +
                           "PRAssignment.prStart<" + end.toSQL() + " and " +
                           "PRAssignment.prFinish>" + begin.toSQL() + " and " +
                           "PRTask.prStatus<>2 and " +
                           "(PRProject.prIsOpen<>0 and PRProject.prTrackMode=2) and " +
                           "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0 and PRResource.prServerName = '" + server_ + "') and " +
                           "PRTeam.prIsOpen<>0 " +
                           "order by PRTask.prWBSSequence");
      } else
         return new String("select PRAssignment.*, PRTask.prProjectID, PRTask.prID, PRTask.prWBSSequence from PRAssignment, PRTask, PRProject, PRResource, PRTeam where " +
                           "PRAssignment.prTaskID=PRTask.prID and " +
                           "PRAssignment.prResourceID=PRResource.prID and " +
                           "PRTask.prProjectID=PRProject.prID and " +
                           "PRTeam.prProjectID=PRProject.prID and " +
                           "PRTeam.prResourceID=PRResource.prID and " +
                           "PRTask.prStart<" + end.toSQL() + " and " +
                           "PRTask.prFinish>" + begin.toSQL() + " and " +
                           "PRTask.prStatus<>2 and " +
                           "(PRProject.prIsOpen<>0 and PRProject.prTrackMode=2) and " +
                           "(PRResource.prIsOpen<>0 and PRResource.prTrackMode=2 and PRResource.prIsRole=0 and PRResource.prServerName = '" + server_ + "') and " +
                           "PRTeam.prIsOpen<>0 " +
                           "order by PRTask.prWBSSequence");
   }

	private final ABTCursor getCurrentTimePeriod() throws ABTException
   {
      ABTTime today = new ABTTime(new Date());

      return getDriver().getRepository().select("select * from PRTimePeriod where prStart<=" + today.toSQL() + " and prFinish>" + today.toSQL());
   }

   private final int getCurrentTimePeriodStart(ABTCursor cursor)
   {
      try {
         if(cursor.moveFirst()) {
            return cursor.getFieldDate(FLD_START, false).getJulian();
         }
      } catch (Exception e) {
      }
      return ABTDate.today().getJulian();
   }

   private final int getCurrentTimePeriodFinish(ABTCursor cursor)
   {
      try {
         if(cursor.moveFirst()) {
            return cursor.getFieldDate(FLD_FINISH, true).getJulian();
         }
      } catch (Exception e) {
      }
      return ABTDate.today().getJulian();
   }
}