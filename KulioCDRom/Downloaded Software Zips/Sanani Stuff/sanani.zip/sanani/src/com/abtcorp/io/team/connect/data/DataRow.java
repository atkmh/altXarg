package com.abtcorp.io.team.connect.data;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Date;
 
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTComparable;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.io.team.RemoteID;

public class DataRow implements Serializable, IABTTWRuleConstants, ABTComparable, ManagerKey, errorMessages
{
   private static final long serialVersionUID = 6372953536344555808L;
   private ABTValue key_;
   private Hashtable values_;
   private ABTRemoteID id_;
   private int type_;

   private transient Object fileManagerKey_;

   public DataRow(ObjectData data, int type)
   {
      type_ = type;

      if (data == null) return;

      key_ = data.getID();
      values_ = data.getValues();
      id_ = data.getRemoteID();
   }

   public ABTValue getKey()            {return key_;}
   public void setKey(ABTValue key)    {key_ = key;}
   public Hashtable getValues()        {return values_;}
   public ABTRemoteID getID()          {return id_;}
   public void setID(ABTRemoteID id)   {id_ = id;}
   public int getType()                {return type_;}
   public void setType(int type)       {type_ = type;}
   public void setFileManagerKey(Object key) {fileManagerKey_ = key;}
   public Object getManagerKey()       {return fileManagerKey_;}

   protected DataRow match()
   {
      if (type_ == FileManager.DELETED_OBJECT || type_ == FileManager.NOTE) return this; // No match for deleted object types; notes are merged when the parent object is read.

      DataRow row = FileManager.getManager(fileManagerKey_).getDataRow(type_,getKey(),false);
   	try {
      	
         if (row == null && type_ == FileManager.getManager(fileManagerKey_).PLANNED) row = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.UNPLANNED,getKey(),false);

      } catch (Exception e) {
         row = null;
      }

      if (row == null) return this;

      return row;
   }

   protected Object resolve(ManagerKey mKey)
   {
      fileManagerKey_ = mKey.getManagerKey();

      DataRow row = match();
      if (row != this && row.checkTimeStamp(this)) {
         row.merge(this);
         RemoteID id = (RemoteID)row.getID();
         id.setTimeStamp(((RemoteID)id_).getTimeStamp());
      }
      return row;
   }

   protected void merge(DataRow newRow)
   {
      switch(type_) {
         case FileManager.CC:
         case FileManager.TC:
         case FileManager.PERIOD:
         case FileManager.USER:
         case FileManager.NOTE:
         case FileManager.CATEGORY:
            completeMerge(newRow,true);
            break;
         case FileManager.RESOURCE:
            mergeResource(newRow);
            break;
         case FileManager.PROJECT:
            mergeProject(newRow);
            break;
         case FileManager.PLANNED:
         case FileManager.UNPLANNED:
            mergeTask(newRow,true);
            break;
         case FileManager.TIMESHEET:
            mergeTimeSheet(newRow,true);
            break;
      }
   }


   private void completeMerge(DataRow newRow, boolean mergenotes)
   {
   	boolean didNotes = false;
      // Remove all previous values except notes from the existing row.
      for (Enumeration keys = getValues().keys();keys.hasMoreElements();) {
         Object key = keys.nextElement();
         if (key instanceof String && key.equals(FLD_TW_NOTES)) continue;
         values_.remove(key);
      }

      // Merge the values from the new row into this row.
      for (Enumeration keys = newRow.getValues().keys();keys.hasMoreElements();) {
         Object key = keys.nextElement();
         if (key instanceof String && key.equals(FLD_TW_NOTES) && mergenotes) {
         	mergeNotes(newRow);
         	didNotes = true;
         } else values_.put(key,newRow.getValues().get(key));
      }
   	
   	if (!didNotes && mergenotes) mergeNotes(newRow); // No notes on the incoming timesheet. 
   }

   public void mergeNotes(DataRow newRow)
   {
   	try {
         DataArray newNotes = (DataArray)newRow.values_.get(FLD_TW_NOTES);
            
         DataArray oldNotes = (DataArray)values_.get(FLD_TW_NOTES);
         if (newNotes != null && oldNotes == null) {
            oldNotes = new DataArray();
            values_.put(FLD_TW_NOTES,oldNotes);
         }
   		
         if (oldNotes != null) {
            // Mark all notes created on Connect client as deleteEligible. When new notes are merged
            // we will unmark the delete eligible notes as needed. Those notes marked as deleted
            // when we're done will be removed.
            int count = oldNotes.size();
            for(int i = 0;i < count;i++) {
               DataRow row = (DataRow)oldNotes.at(i);
   
               ABTValue id = (ABTValue)row.getValues().get(FLD_TW_ID);
               if (id == null || ABTEmpty.isEmpty(id) || ABTError.isError(id)) row.getValues().put(FLD_TW_DELETED,new ABTBoolean(true));
               else if (id.intValue() == 0) row.getValues().put(FLD_TW_DELETED,new ABTBoolean(true));
            }
   
            if (newNotes != null) {
               // Merge in the new notes
               count = newNotes.size();
               for (int i = 0;i < count;i++) {
                  DataRow note = (DataRow)newNotes.at(i);
                  DataRow result = (DataRow)oldNotes.match(note);
                  if (result != note && result.checkTimeStamp(note)) {
                     result.merge(note);
                     RemoteID rid = (RemoteID)note.getID();
                     ((RemoteID)result.id_).setTimeStamp(rid.getTimeStamp());
   
                     result.getValues().put(FLD_TW_DELETED,new ABTBoolean(false));
                  } else if (!result.checkTimeStamp(note)) {
                     result.getValues().put(FLD_TW_DELETED,new ABTBoolean(false));
                  }
               }
            } 
         	
         	if (newNotes == null || (newNotes != null && newNotes.size() == 0)) { // No new notes, remove all non id = 0 notes.
               count = oldNotes.size();
               for (int i = 0;i < count;i++) {
                  DataRow note = (DataRow)oldNotes.at(i);
                  ABTValue id = (ABTValue)note.getValues().get(FLD_TW_ID);
                  if (id.intValue() > 0) oldNotes.remove(note);
               }
            }
         }
         
         if (oldNotes != null) {
            // Now remove deleted ABT Connect Client created notes.
            for(int i = 0;i < oldNotes.size();i++) {
               DataRow note = (DataRow)oldNotes.at(i);
   
               ABTValue id = (ABTValue)note.getValues().get(FLD_TW_ID);
   
               if (id == null || ABTEmpty.isEmpty(id) || ABTError.isError(id)) oldNotes.remove(note);
               else if (id.intValue() == 0) {
                  ABTValue deleted = (ABTValue)note.getValues().get(FLD_TW_DELETED);
                  if (isGoodValue(deleted)) {
                     if (deleted.booleanValue()) oldNotes.remove(note);
                  }
               }
            }
         }
         
   	} catch (Exception e) {
   		e.printStackTrace();
   	}   	
   }

   public void mergeTimeSheet(DataRow newRow, boolean mergenotes)
   {
      completeMerge(newRow,mergenotes);
      // Validate the time entries
      DataArray deleteEligible = new DataArray();
      DataArray entries = (DataArray)values_.get(FLD_TW_ENTRIES);
      for (int i = 0;i < entries.size();i++) {
         Hashtable values = (Hashtable)entries.at(i);
         ABTValue assignmentid = (ABTValue)values.get(FLD_TW_ASSIGNMENT);
         if (assignmentid == null || ABTError.isError(assignmentid) || ABTEmpty.isEmpty(assignmentid)) continue; // Indirect entry??
         else {
            // Get the assignment data row from the resource and verify the task and project are still good.
            DataRow resource = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.RESOURCE,(ABTValue)values_.get(FLD_TW_RESOURCE),true);
            if (resource != null) {
               Hashtable assignments = (Hashtable)resource.values_.get(FLD_TW_ASSIGNMENTS);
               Hashtable assignmentValues =(Hashtable)assignments.get(assignmentid);

               if (assignmentValues == null) deleteEligible.add(entries.at(i));
               else {
                  DataRow task = getTask((ABTValue)assignmentValues.get(FLD_TW_TASK));
                  if (task == null) deleteEligible.add(entries.at(i));
                  else {
                     ABTValue projectid = (ABTValue)task.values_.get(FLD_TW_PROJECT);
                     if (projectid == null || ABTError.isError(projectid) || ABTEmpty.isEmpty(projectid)) deleteEligible.add(entries.at(i));
                     else {
                        DataRow project = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,projectid,false);
                        if (project == null) deleteEligible.add(entries.at(i));
                     }
                  }
               }
            }
         }
      } // for

      // Remove the entries that were found to be invalid.
      for (int i = 0;i < deleteEligible.size();i++) {
         entries.remove(deleteEligible.at(i));
      }
   }

   private void mergeResource(DataRow newRow)
   {
      for (Enumeration keys = values_.keys();keys.hasMoreElements();) {
         Object key = keys.nextElement();
         if (key instanceof String && key.equals(FLD_TW_ASSIGNMENTS)) continue;
         values_.remove(key);
      }

      for (Enumeration keys = newRow.getValues().keys();keys.hasMoreElements();) {
         Object key = keys.nextElement();
         if (key instanceof String && key.equals(FLD_TW_ASSIGNMENTS)) mergeResourceAssignments(newRow,false);
         else values_.put(key,newRow.getValues().get(key));
      }
   }

   public void mergeResourceAssignments(DataRow newRow, boolean checkTimeStamp)
   {
      // Merge the assignment hashtables.
      Hashtable newAssignments = (Hashtable)newRow.values_.get(FLD_TW_ASSIGNMENTS);
      Hashtable existingAssignments = (Hashtable)values_.get(FLD_TW_ASSIGNMENTS);
      if (existingAssignments != null) {
         // Remove old assignments except those added by Connect clients (FLD_TW_ID = 0);
         // Also remove assignments where we can't find the tasks to them.
         for (Enumeration e = existingAssignments.keys();e.hasMoreElements();) {
            Object key = e.nextElement();
            Hashtable values = (Hashtable)existingAssignments.get(key);
            ABTValue id = (ABTValue)values.get(FLD_TW_ID);

            // If this row's timestamp > than the new row then we don't want to remove the existing assignments.
            // This is a case where the client is saving back a modified resource after the agent has updated the
            // data on the web server. A rare case, but we have to handle it.
            if (checkTimeStamp) {
               if (newRow.checkTimeStamp(this)) {
                  if (id == null || ABTEmpty.isEmpty(id) || ABTError.isError(id)) existingAssignments.remove(key);
                  else if (id.intValue() != 0) existingAssignments.remove(key);
               }
            } else {
               if (id.intValue() != 0) existingAssignments.remove(key);
            }

            ABTValue taskid = (ABTValue)values.get(FLD_TW_TASK);
            if (taskid == null || ABTEmpty.isEmpty(taskid) || ABTError.isError(taskid)) existingAssignments.remove(key);

            // Verify that the task the assignment references is still in the files. Check the
            // planned task file, then check the unplanned file if it's not in the planned task file.
            DataRow taskRow = getTask(taskid);
            if (taskRow != null) continue;
            // Didn't find the task, remove the assignment.
            existingAssignments.remove(key);
         }
      } else {
         existingAssignments = new Hashtable(20,(float)1.0);
         values_.put(FLD_TW_ASSIGNMENTS,existingAssignments);
      }
      // Add the new assignments to the existing assignments.
      // If the new row has a time stamp < than this row, then the client is
      // trying to modify the resource after the agent has sent new data. Only
      // save Connect modified assignments in that case.
      for (Enumeration e = newAssignments.keys();e.hasMoreElements();) {
         Object key = e.nextElement();
         Hashtable values = (Hashtable)newAssignments.get(key);
         ABTValue id = (ABTValue)values.get(FLD_TW_ID);

         if (id == null || ABTEmpty.isEmpty(id)) id = new ABTInteger(0);

         if (isGoodValue(id)) {
            if (checkTimeStamp) {
               if (id.intValue() == 0 || newRow.checkTimeStamp(this)) existingAssignments.put(key,newAssignments.get(key));
            } else existingAssignments.put(key,newAssignments.get(key));
         }
      }
   }

   public ABTValue mergeResourceTimeSheets(DataRow newRow, boolean checkTimeStamp)
   {
      ABTValue retVal = null;

      if (newRow == null) return null;

      DataArray oldTimeSheets = (DataArray)getValues().get(FLD_TW_TIMESHEETS);
      DataArray newTimeSheets = (DataArray)newRow.getValues().get(FLD_TW_TIMESHEETS);
      if (newTimeSheets == null) {
         if (oldTimeSheets == null) return null; // No new timesheets, no old ones either...nothing to do.
         if ((checkTimeStamp && newRow.checkTimeStamp(this)) || (checkTimeStamp == false)) values_.remove(FLD_TW_TIMESHEETS);
         else retVal = new ABTError(getClass(),"mergeResourceTimeSheets",ERR_0,null);
      } else {
         if ((checkTimeStamp && newRow.checkTimeStamp(this)) || (checkTimeStamp == false)) {
            values_.remove(FLD_TW_TIMESHEETS);
            values_.put(FLD_TW_TIMESHEETS,newTimeSheets);
         } else retVal = new ABTError(getClass(),"mergeResourceTimeSheets",ERR_0,null);
      }

      return retVal;
   }

   private void mergeProject(DataRow newRow)
   {
      for (Enumeration keys = values_.keys();keys.hasMoreElements();) {
         Object key = keys.nextElement();
//         if (key instanceof String && key.equals("ProjectTasks")) continue;
         if (key instanceof String && key.equals(FLD_TW_NOTES)) continue;
         values_.remove(key);
      }

      for (Enumeration keys = newRow.getValues().keys();keys.hasMoreElements();) {
         Object key = keys.nextElement();
  //       if (key instanceof String && key.equals("ProjectTasks")) mergeProjectTasks(newRow);
         if (key instanceof String && key.equals(FLD_TW_NOTES)) mergeNotes(newRow);
         else values_.put(key,newRow.getValues().get(key));
      }

      ABTValue first = (ABTValue)values_.get(FLD_TW_FIRST);
      DataRow taskRow = null;
      if (isGoodValue(first)) {
         taskRow = getTask(first);
         updateTask(taskRow,(ABTValue)values_.get(FLD_TW_INTERNALID));
      }
   }

   private void mergeProjectTasks(DataRow newRow)
   {
/*      if (type_ != FileManager.PROJECT || newRow.getType() != FileManager.PROJECT) return;

      DataSet savedTasks = new DataSet(type_);
      // Save off all tasks with id = 0 that are in the "ProjectTasks" data array.
      // Then re-add them after overlaying the existing projects "ProjectTasks" field
      // with the one from the new row.
      try {
         DataSet oldTasks = (DataSet)values_.get("ProjectTasks");
         if (oldTasks != null) {
            for (int i = 0;i < oldTasks.size();i++) {
               DataRow task = (DataRow)oldTasks.at(i);
               ABTValue id = (ABTValue)task.getValues().get(FLD_TW_ID);
               if (id != null && !ABTEmpty.isEmpty(id) && !ABTError.isError(id)) {
                  if (id.intValue() == 0) savedTasks.add(task);
               }
            }
         }

         DataSet newTasks = (DataSet)newRow.getValues().get("ProjectTasks");
         if (newTasks == null) newTasks = new DataSet(newRow.getType());

         for (int i = 0;i < savedTasks.size();i++) {
            newTasks.add((DataRow)savedTasks.at(i));
         }

         values_.put("ProjectTasks",newTasks); // Save new "merged" tasks into existing project row.
      } catch (Exception e) {
         e.printStackTrace();
      }*/
      DataSet tasks = (DataSet)newRow.values_.get("ProjectTasks");
   }
   public void mergeTask(DataRow newRow, boolean mergenotes)
   {
      // Tasks that were created on the web client, but are now known in the repository are removed from the unplanned task file.
      ABTValue id = (ABTValue)newRow.values_.get(FLD_TW_ID);
      if (isGoodValue(id)) {
         if (id.intValue() > 0) {
            ABTValue projectid = (ABTValue)newRow.values_.get(FLD_TW_PROJECT);
            ABTValue externalid = (ABTValue)newRow.values_.get(FLD_TW_EXTERNALID);
            if (isGoodValue(projectid) && isGoodValue(externalid)) {
               ABTString key = new ABTString("" + projectid.intValue() + " " + externalid.stringValue());
               DataRow taskRow = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.UNPLANNED,key,false);
               // Remove the unplanned task from the unplanned task file and from the
               // project "ProjectTasks" field.
               try {
                  if (taskRow != null) {
                     FileManager.getManager(fileManagerKey_).getFile(FileManager.UNPLANNED,false).writeObject(key,null);
                     DataRow project = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,projectid,false);
                     if (project != null) {
                        DataArray tasks = (DataArray)project.getValues().get("ProjectTasks");

                        if (tasks != null) {
                           tasks.remove(taskRow);
                           FileManager.getManager(fileManagerKey_).getFile(FileManager.PROJECT,false).writeObject(projectid,project);
                        }

                     }
                  }
               } catch (Exception e) {
                  e.printStackTrace();
               }
            }
         }
      }
      completeMerge(newRow,mergenotes);
   }

   public boolean checkTimeStamp(DataRow newRow)
   {
      RemoteID newId = (RemoteID)newRow.getID();
      RemoteID oldId = (RemoteID)getID();

      if (newRow.getType() != FileManager.TIMESHEET) return newId.getTimeStamp() >= oldId.getTimeStamp();
      else {
         ABTValue saved = (ABTValue)values_.get(FLD_TW_SAVED);
         ABTValue compare = (ABTValue)newRow.values_.get(FLD_TW_SAVED);
         if (saved instanceof ABTBoolean && compare instanceof ABTBoolean) {
            if (saved.booleanValue() && !compare.booleanValue()) return false;
         }

         return newId.getTimeStamp() >= oldId.getTimeStamp();
      }
   }

   public boolean equals(Object object)
   {
      if (object instanceof DataRow) {
         int compare = compareTo(object);
         return compare == 0;
      }
      return false;
   }

   public int compareTo(Object object)
   {
      if (object instanceof DataRow) {
         if ((type_ == FileManager.UNPLANNED || type_ == FileManager.PLANNED) && (((DataRow)object).getType() == FileManager.UNPLANNED || ((DataRow)object).getType() == FileManager.PLANNED)) {
            // Comparison of two unplanned task data rows has special processing
            ABTValue isUnplanned1 = (ABTValue)values_.get(FLD_TW_ISUNPLANNED);
            ABTValue isUnplanned2 = (ABTValue)((DataRow)object).values_.get(FLD_TW_ISUNPLANNED);
            if (isGoodValue(isUnplanned1) && isGoodValue(isUnplanned2) && isUnplanned1.booleanValue() && isUnplanned2.booleanValue()) {
               ABTValue projectid = (ABTValue)values_.get(FLD_TW_PROJECT);
               ABTValue projectid2 = (ABTValue)((DataRow)object).values_.get(FLD_TW_PROJECT);
               if (isGoodValue(projectid) && isGoodValue(projectid2)) {
                  // Compare the projects.
                  DataRow project = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,projectid,false);
                  DataRow project2 = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,projectid2,false);
                  int compare = project.compareTo(project2);

                  if (compare != 0) return compare;

                  // Projects are the same, compare the external ids.
                  ABTValue id = (ABTValue)values_.get(FLD_TW_ID);
                  ABTValue id2 = (ABTValue)((DataRow)object).values_.get(FLD_TW_ID);
                  if (isGoodValue(id) && isGoodValue(id2)) {
                     if (id.intValue() == 0 || id2.intValue() == 0) {
                        ABTValue externalid = (ABTValue)values_.get(FLD_TW_EXTERNALID);
                        ABTValue externalid2 = (ABTValue)((DataRow)object).values_.get(FLD_TW_EXTERNALID);
                        if (isGoodValue(externalid) && isGoodValue(externalid2)) {
                           String left = externalid.stringValue();
                           String right = externalid2.stringValue();
                           if (left == null && right == null) return 0;
                           if (left == null) return -1;
                           if (right == null) return +1;

                           return left.compareTo(right);
                        }
                     }
                  }
               }
            }
         }
         if (type_ == FileManager.NOTE && ((DataRow)object).getType() == FileManager.NOTE) {
            // First check remote ids.
            RemoteID id = (RemoteID)((DataRow)object).getID();
            if (id_.compareTo(id) == 0) return 0;
            // If one of the id's is 0, check the createdtime and createdby.
            if (id.getID() == 0 || ((RemoteID)id_).getID() == 0) {
               ABTValue createTime = (ABTValue)values_.get(FLD_TW_CREATEDTIME);
               ABTValue createby = (ABTValue)values_.get(FLD_TW_CREATEDBY);

               ABTValue val1 = (ABTValue)((DataRow)object).getValues().get(FLD_TW_CREATEDTIME);
               ABTValue val2 = (ABTValue)((DataRow)object).getValues().get(FLD_TW_CREATEDBY);

               int compare = 0;

               // First check if the created times match.
               if (createTime == null && val1 == null) compare = 0;
               else {
                  if (createTime == null) compare = -1;
                  else if (val1 == null) compare = +1;
                  else compare = createTime.compareTo(val1);
               }

               // If times are the same, check the created by.
               if (compare == 0) {
                  if (createby == null && val2 == null) return compare;
                  else {
                     if (createby == null) return -1;
                     else if (val2 == null) return +1;
                     else return createby.compareTo(val2);
                  }
               } else return compare;
            }
         }
         // Compare the remote ids.
         RemoteID id = (RemoteID)((DataRow)object).getID();
         return id_.compareTo(id);
      }
      return -1;
   }

   protected DataRow getTask(ABTValue key)
   {
      if (key == null || ABTEmpty.isEmpty(key) || ABTError.isError(key)) return null;

      // Search for the task in the planned task file and if not found search for it
      // in the unplanned task file.
      DataRow taskRow = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PLANNED,key,false);
      if (taskRow == null) taskRow = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.UNPLANNED,key,false);
      return taskRow;
   }

   public void timeStamp()
   {
      RemoteID id = (RemoteID)getID();
      id.timeStamp();
   }

   protected void updateTask(DataRow task, ABTValue projectid)
   {
      if (task == null) return;

      if (type_ != FileManager.PLANNED || type_ != FileManager.UNPLANNED) return; // Only works if the DataRow is a task data row.

      task.values_.put(FLD_TW_PROJECT,projectid);

      DataRow first = getTask((ABTValue)task.values_.get(FLD_TW_FIRST));
      DataRow next = getTask((ABTValue)task.values_.get(FLD_TW_NEXT));

      if (first != null) updateTask(first,projectid);
      if (next != null) updateTask(next,projectid);
   }

   public String toString()
   {
      StringBuffer buffer = new StringBuffer();
      buffer.append("values = {");
      for(Enumeration e = values_.keys();e.hasMoreElements();) {
         Object key = e.nextElement();
         buffer.append("{key = " + key + ", value = " + values_.get(key) + "},");
      }
      return new String(buffer);
   }

   public boolean validate(DataRow unplannedtask, DataRow newTask)
   {
      if (unplannedtask == null || newTask == null) return false;
      if (unplannedtask.getType() != FileManager.UNPLANNED) return false;

      if (getType() == FileManager.RESOURCE) {

         ABTValue oldid = (ABTValue)unplannedtask.getValues().get(FLD_TW_INTERNALID);
         if (isGoodValue(oldid)) {
            // Find the assignment that points to this task - if any.
            Hashtable assignments = (Hashtable)values_.get(FLD_TW_ASSIGNMENTS);
            if (assignments != null) {
               for (Enumeration e = assignments.elements();e.hasMoreElements();) {
                  Hashtable assignment = (Hashtable)e.nextElement();
                  ABTValue taskid = (ABTValue)assignment.get(FLD_TW_TASK);

                  if (isGoodValue(taskid)) {
                     if (!taskid.equals(oldid)) continue;

                     DataRow project = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,(ABTValue)newTask.getValues().get(FLD_TW_PROJECT),false);
                     if (project != null) {
                        // Set the assignment's task to reference the new task. Create the new internal id for the assignment and set the assignment's
                        // task id to be the new internal id of the task.
                        assignment.put(FLD_TW_TASK,newTask.getValues().get(FLD_TW_INTERNALID));
                        assignment.put(FLD_TW_TASKID,newTask.getValues().get(FLD_TW_INTERNALID));
                        ABTString newKey = new ABTString(values_.get(FLD_TW_INTERNALID) + "0" + newTask.getValues().get(FLD_TW_INTERNALID) + "00" + newTask.getValues().get(FLD_TW_PROJECT) + "0" + assignment.get(FLD_TW_ID));
                        ABTString oldKey = (ABTString)assignment.get(FLD_TW_INTERNALID);
                        assignment.put(FLD_TW_INTERNALID,newKey);
                        // Remove the task from the unplanned file; it is now planned.
                        FileManager.getManager(fileManagerKey_).writeRow(FileManager.UNPLANNED,unplannedtask,true);
                        relinkAssignments((DataArray)values_.get(FLD_TW_TIMESHEETS),oldKey,newKey);
                     }

                     break; // Only one assignment for this task per resource.
                  }
               }
            } // for
         }
      }
      return true;
   }

   public boolean validate()
   {
      if (getType() == FileManager.TIMESHEET) {
         ABTValue periodid = (ABTValue)values_.get(FLD_TW_TIMEPERIOD);
         if (isGoodValue(periodid)) {
            DataRow period = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PERIOD,periodid,false);
            if (period == null) return false;
            else validateEntries();
         } else return false;
      } else if (getType() == FileManager.RESOURCE) {
         Hashtable assignments = (Hashtable)values_.get(FLD_TW_ASSIGNMENTS);
         if (assignments != null) {
            ABTArray removedAssignments = new ABTArray();
            Hashtable existingAssignments = new Hashtable(50,(float)1.0);
            for (Enumeration e = assignments.elements();e.hasMoreElements();) {
               Hashtable assignment = (Hashtable)e.nextElement();
               // Save the assignments in a separate hashtable that we can manipulate while iterating through the true hashtable.
               existingAssignments.put(assignment.get(FLD_TW_INTERNALID),assignment);

               ABTValue taskid = (ABTValue)assignment.get(FLD_TW_TASK);

               if (taskid == null || ABTEmpty.isEmpty(taskid) || ABTError.isError(taskid)) removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
               else {
                  // Remove assignment if the resource can't enter time against the project.
                  DataRow task = getTask(taskid);
                  if (task == null) removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
                  else {
                     ABTValue projectid = (ABTValue)task.getValues().get(FLD_TW_PROJECT);
                     if (projectid == null || ABTEmpty.isEmpty(projectid) || ABTError.isError(projectid)) removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
                     else {
                        if (!hasProject(projectid)) removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
                        else {
                           // If task is unplanned check if it exists in the planned task file
                           // by external ID. If so, remove it from the unplanned task file and
                           // point the assignment to the new planned task.
                           ABTValue isUnplanned = (ABTValue)task.getValues().get(FLD_TW_ISUNPLANNED);
                           if (isGoodValue(isUnplanned)) {
                              ABTValue id = (ABTValue)task.getValues().get(FLD_TW_ID);
                              if (isGoodValue(id)) {
                                 if (id.intValue() == 0 && isUnplanned.booleanValue()) {
                                    DataRow project = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,projectid,false);
                                    if (project == null) removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
                                    else {
                                       DataSet tasks = (DataSet)project.getValues().get("ProjectTasks");
                                       if (tasks == null) removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
                                       else {
                                          tasks.setFileManagerKey(fileManagerKey_);
                                          DataRow temp = (DataRow)tasks.find(task);
                                          if (temp != null) {
                                             // Set the assignment's task to reference the new task. Create the new internal id for the assignment and set the assignment's
                                             // task id to be the new internal id of the task.
                                             assignment.put(FLD_TW_TASK,temp.getValues().get(FLD_TW_INTERNALID));
                                             assignment.put(FLD_TW_TASKID,temp.getValues().get(FLD_TW_INTERNALID));
                                             ABTString newKey = new ABTString(values_.get(FLD_TW_INTERNALID) + "0" + temp.getValues().get(FLD_TW_INTERNALID) + "00" + projectid + "0" + assignment.get(FLD_TW_ID));
                                             ABTString oldKey = (ABTString)assignment.get(FLD_TW_INTERNALID);
                                             existingAssignments.remove(assignment.get(FLD_TW_INTERNALID));
                                             assignment.put(FLD_TW_INTERNALID,newKey);
                                             existingAssignments.put(newKey,assignment);
                                             // Remove the task from the unplanned file; it is now planned.
                                             FileManager.getManager(fileManagerKey_).writeRow(FileManager.UNPLANNED,task,true);
                                             relinkAssignments((DataArray)values_.get(FLD_TW_TIMESHEETS),oldKey,newKey);
                                          } else {
                                             try {
                                                // Add the task into the project again to make sure others can see it.
                                                FileManager.getManager(fileManagerKey_).linkRowTask(task);
                                             } catch (Exception exception) {
                                                exception.printStackTrace();
                                                removedAssignments.add(assignment.get(FLD_TW_INTERNALID));
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            } // for
            // Remove invalid assignments.
            for (int i = 0;i < removedAssignments.size();i++) {
               existingAssignments.remove(removedAssignments.at(i));
            }
            values_.put(FLD_TW_ASSIGNMENTS,existingAssignments); // Reset the assignment hashtable.
         }
      }
      return true;
   }

   public void validateEntries()
   {
      ABTValue resourceid = (ABTValue)values_.get(FLD_TW_RESOURCE);
      if (isGoodValue(resourceid)) {
         DataRow resource = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.RESOURCE,resourceid,true); // Have to get the resource from the temp file as we are currently getting new resources.
         if (resource != null) {
            Hashtable assignments = (Hashtable)resource.getValues().get(FLD_TW_ASSIGNMENTS);

            ABTArray deleteEligibleEntries = new ABTArray();
            DataArray entries = (DataArray)values_.get(FLD_TW_ENTRIES);
            if (entries != null) {
               for (int i = 0;i < entries.size();i++) {
                  Hashtable entry = (Hashtable)entries.at(i);
                  if (entry != null) {
                     ABTValue assignmentid = (ABTValue)entry.get(FLD_TW_ASSIGNMENT);
                     if (assignmentid == null) continue; // Indirect time entry.
                     if (assignments == null) deleteEligibleEntries.add(entry);
                     else {
                        Hashtable assignment = (Hashtable)assignments.get(assignmentid);
                        if (assignment == null) deleteEligibleEntries.add(entry);
                        else {
                           ABTValue taskid = (ABTValue)assignment.get(FLD_TW_TASK);
                           if (taskid == null || ABTEmpty.isEmpty(taskid) || ABTError.isError(taskid)) deleteEligibleEntries.add(entry);
                           else {
                              DataRow task = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PLANNED,taskid,false);
                              if (task == null) task = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.UNPLANNED,taskid,false);
                              if (task == null) deleteEligibleEntries.add(entry);
                              else {
                                 ABTValue projectid = (ABTValue)task.getValues().get(FLD_TW_PROJECT);
                                 if (projectid == null || ABTEmpty.isEmpty(projectid) || ABTError.isEmpty(projectid)) deleteEligibleEntries.add(entry);
                                 else {
                                    DataRow project = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.PROJECT,projectid,false);
                                    if (project == null) deleteEligibleEntries.add(entry);
                                    else {
                                       if (!resource.hasProject(projectid)) deleteEligibleEntries.add(entry);
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               } // for
            }
            for (int i = 0;i < deleteEligibleEntries.size();i++) {
               entries.remove(deleteEligibleEntries.at(i));
            }
         }
      }
   }

   public boolean hasProject(ABTValue id)
   {
      if (id == null) return false;
      if (type_ != FileManager.RESOURCE) return false;

      DataArray ids = (DataArray)values_.get(FLD_TW_PROJECTS);
      if (ids == null) return false;

      for (int i = 0;i < ids.size();i++) if (ids.at(i).equals(id)) return true;
      return false;
   }

   private boolean isGoodValue(ABTValue value)
   {
      boolean good = true;

      if (value == null || ABTEmpty.isEmpty(value) || ABTError.isError(value)) good = false;
      return good;
   }

   private void relinkAssignments(DataArray timesheetids, ABTString oldAssignmentID, ABTString newAssignmentID)
   {
      if (timesheetids == null) return;

      for (int i = 0;i < timesheetids.size();i++) {
         DataRow timesheet = FileManager.getManager(fileManagerKey_).getDataRow(FileManager.TIMESHEET,(ABTValue)timesheetids.at(i),false);
         if (timesheet != null) {
            DataArray entries = (DataArray)timesheet.getValues().get(FLD_TW_ENTRIES);
            if (entries != null) {
               for (int j = 0;j < entries.size();j++) {
                  Hashtable entry = (Hashtable)entries.at(j);
                  if (entry.containsKey(FLD_TW_ASSIGNMENT) && ((ABTValue)entry.get(FLD_TW_ASSIGNMENT)).equals(oldAssignmentID)) {
                     entry.put(FLD_TW_ASSIGNMENT,newAssignmentID);
                  }
               }
            }
            FileManager.getManager(fileManagerKey_).writeRow(FileManager.TIMESHEET,timesheet,false);
         }
      }
   }
}