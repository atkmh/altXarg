/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.abtcorp.api.local;
import com.abtcorp.api.*;
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
//import com.abtcorp.hub.*;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;


class ABTObjectLocal extends ABTSessionObject implements IABTObject
{
   protected ABTObjectLocal(ABTSessionObject s,ABTObject obj) {
      super(s,obj);
      }

   private ABTObject _obj;
   private ABTObject obj() {
      if (_obj == null) _obj = (ABTObject)getObject();
      return _obj;
      }

   public IABTObjectSpace getObjectSpace() {
      return new ABTObjectSpaceLocal(this);
    }

  public synchronized ABTValue setValue(String fieldName, ABTValue newValue) {
      /* the user session better not be null! */
      ABTUserSession session = getUserSession();
      if (session == null)
         return new ABTError(getClass(),"setValue",errorMessages.ERR_INVALID_OBJSPACE,null);

      session.startTransaction();
      ABTValue retVal = null;
      try {
         ABTHashtable Args = null;
         retVal = obj().setValue(session,fieldName, (ABTValue)ValueMunger.MarshalIn(this, newValue),Args);
         }
      catch (Exception e)
         {
         session.rollbackTransaction();
         return new ABTError(getClass(), "setValue", errorMessages.ERR_EXCEPTION, e);
         }
      catch (Throwable t)
         {
         session.rollbackTransaction();
         return new ABTError(getClass(), "setValue", errorMessages.ERR_EXCEPTION, t);
         }
      if (retVal instanceof ABTError)
         session.rollbackTransaction();
      else
         session.commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }

  public synchronized ABTValue getValue(String fieldName) {
      /* the user session better not be null! */
      ABTUserSession session = getUserSession();
      if (session == null)
         return new ABTError(getClass(),"setValue",errorMessages.ERR_INVALID_OBJSPACE,null);

     session.startTransaction();
      ABTValue retVal = null;
      try {
         ABTHashtable Args = null;
         retVal = ValueMunger.MarshalOut(this,obj().getValue((ABTUserSession)getUserSession(),fieldName,Args));
         }
      catch (Exception e)
         {
         session.rollbackTransaction();
         return new ABTError(getClass(), "getValue", errorMessages.ERR_EXCEPTION, e);
         }
      catch (Throwable t)
         {
         session.rollbackTransaction();
         return new ABTError(getClass(), "setValue", errorMessages.ERR_EXCEPTION, t);
         }
      if (retVal instanceof ABTError)
         session.rollbackTransaction();
      else
         session.commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }

  public synchronized IABTProperty getProperty(String fieldName) {
      ABTProperty p = obj().getProperty((ABTUserSession)getUserSession(),fieldName);
      if (p != null)
         return new ABTPropertyLocal(this,p);
      else
         return null;
      }

   public synchronized IABTPropertySet getProperties()  {
      return new ABTPropertySetLocal(this,obj().getProperties());
      }

   public synchronized String getObjectType()  {
      return obj().getObjectType();
      }

    /**
   * return the object dependant value for property-field by key
   */
   public synchronized ABTValue getPropertyKey(String property, int key) {
	    return ValueMunger.MarshalOut(this,obj().getPropertyKey((ABTUserSession)getUserSession(),property, key));
   }

   /**
   * return whether the current value physically stored in the 
   * property is empty (i.e. has never been set
   * @param property - name of property
   * @return ABTValue - ABTBoolean true (if empty) or false
   */
   public synchronized ABTValue isEmpty(String property){
	    return ValueMunger.MarshalOut(this,obj().isEmpty((ABTUserSession)getUserSession(),property));
      }

   public synchronized ABTValue setValues(IABTHashTable pairs) {
      getUserSession().startTransaction();
      ABTValue retVal = null;
      try {
         ABTHashTable hT = (ABTHashTable)pairs;
         ABTHashtable ht = (ABTHashtable)hT.getObject();
         retVal = obj().setValues((ABTUserSession)getUserSession(),ht);
         }
      catch (Exception e)
         {
         getUserSession().rollbackTransaction();
         return new ABTError(getClass(), "setValues", errorMessages.ERR_EXCEPTION, e);
         }
      if (retVal instanceof ABTError)
         getUserSession().rollbackTransaction();
      else
         getUserSession().commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }

	public synchronized ABTValue getValues(IABTArray properties) {
      getUserSession().startTransaction();
      ABTValue retVal = null;
      try {
         ABTArrayLocal aR = (ABTArrayLocal)properties;
         ABTArray ar = (ABTArray)aR.getObject();
         retVal = obj().getValues(getUserSession(),ar);
         }
      catch (Exception e)
         {
         getUserSession().rollbackTransaction();
         return new ABTError(getClass(), "getValues", errorMessages.ERR_EXCEPTION, e);
         }
      if (retVal instanceof ABTError)
         getUserSession().rollbackTransaction();
      else
         getUserSession().commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }


   public synchronized ABTValue setWithParameters(String fieldName, ABTValue newValue, IABTHashTable params) {
      getUserSession().startTransaction();
      ABTValue retVal = null;
      try {
         ABTHashTable hT = (ABTHashTable)params;
         ABTHashtable ht = (ABTHashtable)hT.getObject();
         retVal = obj().setValue((ABTUserSession)getUserSession(),
                                 fieldName,
                                 (ABTValue)ValueMunger.MarshalIn(this,newValue),
                                 ht);
         }
      catch (Exception e)
         {
         getUserSession().rollbackTransaction();
         return new ABTError(getClass(), "setWithParameters", errorMessages.ERR_EXCEPTION, e);
         }
      if (retVal instanceof ABTError)
         getUserSession().rollbackTransaction();
      else
         getUserSession().commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }

   public synchronized ABTValue getWithParameters(String fieldName, IABTHashTable params) {
      getUserSession().startTransaction();
      ABTValue retVal = null;
      try {
         ABTHashTable hT = (ABTHashTable)params;
         ABTHashtable ht = (ABTHashtable)hT.getObject();
         retVal = obj().getValue((ABTUserSession)getUserSession(),fieldName, ht);
         }
      catch (Exception e)
         {
         getUserSession().rollbackTransaction();
         return new ABTError(getClass(), "getWithParameters", errorMessages.ERR_EXCEPTION, e);
         }
      if (retVal instanceof ABTError)
         getUserSession().rollbackTransaction();
      else
         getUserSession().commitTransaction();
      return ValueMunger.MarshalOut(this, retVal);
      }

   public synchronized boolean booleanValue()   { return obj().booleanValue();}
   public synchronized short  shortValue()      { return obj().shortValue();  }
   public synchronized int intValue()           { return obj().intValue();    }
   public synchronized double doubleValue()     { return obj().doubleValue(); }
   public synchronized String stringValue()     { return obj().stringValue(); }
   public synchronized ABTValue evaluate()      { return obj().eval();        }
   public synchronized int compareTo(Object obj)
   {
    if (obj == null) return 1;
    return obj().compareTo(obj);
   }

   public synchronized ABTValue delete() {
      getUserSession().startTransaction();
      ABTValue retVal;
      try{
         retVal = ValueMunger.MarshalOut(this,obj().delete(getUserSession()));
         }
      catch (Throwable e){
         getUserSession().rollbackTransaction();
         return new ABTError(getClass(), "delete", errorMessages.ERR_EXCEPTION, e);
         }
      if (retVal instanceof ABTError)
         getUserSession().rollbackTransaction();
      else
         getUserSession().commitTransaction();
      return retVal;
      }

   public synchronized ABTValue toValue() {
      return this;
      }

   public synchronized IABTLocalID getID() {
      return new ABTLocalID(this,obj().getID());
      }

   public synchronized boolean isDeleted() {
      return obj().isDeleted(getUserSession());
      }

   /**
   * Add a specific listener to the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param propertyName name of property or null all
   */
   public synchronized void addListener(int action, IABTListener listener,String propertyName){
      }


  /**
   * Remove a specific listener from the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param propertyName name of property or null all
   */
   public synchronized void removeListener(IABTListener listener,String propertyName){
      }

  /**
   * Remove a all listenedTo for the caller
   * @param listener caller who wants to be removed from the the listenerlist
   */
   public synchronized void removeListeners(IABTListener listener){
      }

   private class MyListener extends ABTSessionObject implements IABTListener
      {
      private IABTListener l_;
      private IABTProperty prop_;

      public MyListener(ABTSessionObject s, IABTListener l, IABTProperty prop){
         super(s,l);
         l_ = l;
         prop_ = prop;
         }

      /**
      * get notified !after! a rowchange took place
      * @param object - ABTObject or ABTObjectSet that has changed
      * @param action - see list of constants above
      * @param property - the property which has changed (if applicable)
      * @param newValue - value of field after the change or ABTObject added/removed
      * @param oldValue - original value (if applicable)
      */
      public void hasChanged( ABTValue object,  int action, IABTProperty property, ABTValue newValue, ABTValue oldValue)
         {
         }

     }
}
