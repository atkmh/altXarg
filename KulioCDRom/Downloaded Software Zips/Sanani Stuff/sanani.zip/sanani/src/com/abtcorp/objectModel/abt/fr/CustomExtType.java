package  com.abtcorp.objectModel.abt.fr;

/*
 * CustomExtType.java 08/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 08-13-98       LZX           Initial Design
 *
 */

import   java.util.*;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule will check if the new value to be set to is valid.
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class CustomExtType extends SiteFieldRule
{

   /**
    * Validate the value that is being set into the parent object container.
    * Return an ABTError if the value is invalid.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      // if the new value is null, set it.
      if (ABTValue.isNull(newValue))
         return write( session, parent, property, myValue, newValue, false );

      // if the new value is one of the valid enum values, set it. Otherwise
      // return an error.
      short val = newValue.shortValue();
      if ((val == CUST_MONEY) ||
          (val == CUST_DATE) ||
          (val == CUST_TIME) ||
          (val == CUST_BOOLEAN) ||
          (val == CUST_PERCENT) ||
          (val == CUST_ENUM) ||
          (val == CUST_REFERENCE) ||
          (val == CUST_MEMO) ||
          (val == CUST_AGGREGATE))
         return write( session, parent, property, myValue, newValue, false );

      else
         return new ABTError( "CustomExtType",
            "onSet",
            errorMessages.ERR_INVALID_VALUE,
            "mmCustom.mmExtType must be " + CUST_MONEY + ", " + CUST_DATE + ", " + CUST_TIME + ", "
                  + CUST_BOOLEAN + ", " + CUST_PERCENT + ", " + CUST_ENUM + ", "
                   + CUST_REFERENCE + ", "   + CUST_MEMO + ", or " + CUST_AGGREGATE
                   + ". bad value = " + val );
   }
}
