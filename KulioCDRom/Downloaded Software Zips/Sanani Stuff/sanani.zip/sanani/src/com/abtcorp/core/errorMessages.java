package com.abtcorp.core;

public interface errorMessages extends  IABTErrorPriorities
   {
 	// This section defines error constants
 	public static final String Package = "com.abtcorp.core".intern();
    public static final ABTErrorCode CORE_ERR_INVALID_TYPE = new ABTErrorCode(Package, "CORE_ERR_INVALID_TYPE", UNRECOVERABLE_ERROR);
    public static final ABTErrorCode CORE_ERR_INVALID_MOVE = new ABTErrorCode(Package, "CORE_ERR_INVALID_MOVE", UNRECOVERABLE_ERROR);
   }