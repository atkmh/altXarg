package com.abtcorp.api.com;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.repository.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

import java.util.Locale;

public class ABTErrorCOM implements IABTErrorCOM
{
   public ABTErrorCOM(ABTError er)
      {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(er);
      /**/
      }
   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private ABTError _er;
   private ABTError er() {
      if (_er == null) _er = (ABTError)getObject(); 
      return _er;
      }

   /**
   *  return the errorcode
   *  @return String - current Errorcode
   */
   public String getCode() 
   {
      return er().getErrorCode().toString();
   }


   /**
   *  return the package of the component who created this thing
   *  @return String  name of creator
   */
   public String getPackage()
   {
      return er().getPackage();
   }

   /**
   *  return the component who created this thing
   *  @return String  name of creator
   */
   public String getComponent()
   {
      return er().getComponent();
   }
      /**
   *  return the module (if any) which generated this error
   *  @return String  name of module
   */
   public String getMethod()
   {
      return er().getMethod();
   }
   /**
   *  return the date and time this error message was created
   *  @return Date
   */
   public Variant getDate()
   {
      return new Variant(er().getDate());
   }
   
   /**
   *  return the message
   *  @return String textual representation of error
   */
   public String getMessage()
   {
      return er().getMessage();
   }

   /**
   *  return the message localized for a particular locale
   *  @return String textual representation of error
   */
   public String getLocalizedMessage(int LCID)
   {
      com.ms.wfc.app.Locale crazyMSLocale = new com.ms.wfc.app.Locale(LCID);
      Locale javaLocale = new Locale(crazyMSLocale.getLanguage(), crazyMSLocale.getCountry());
      return er().getLocalizedMessage(javaLocale);
   }

   public Variant getInfo()
   {
      Object info = er().getInfo();
      if (info == null) return new Variant(null);
      if (info instanceof ABTValue) 
         return VariantMunger.ValueToVariant((ABTValue)info);
      return new Variant(info.toString());
   }
}
