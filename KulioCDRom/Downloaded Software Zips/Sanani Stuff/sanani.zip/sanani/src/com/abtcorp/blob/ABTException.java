package com.abtcorp.blob;

import java.io.Serializable;

import com.abtcorp.core.*;

public final class ABTException implements ABTComparable, Serializable
{
   private static final long serialVersionUID = -6929541927820488155L;
	
	private ABTDate      start_;
   private ABTDate      finish_;
   private ABTShiftList shifts_;

   public ABTException(ABTDate start, ABTDate finish, ABTShiftList shifts) {start_ = start; finish_ = finish; shifts_ = shifts;}

   public final ABTDate      getStart()  {return start_;}
   public final ABTDate      getFinish() {return finish_;}
   public final ABTShiftList getShifts() {return shifts_;}

   public final void optimize() {shifts_.optimize();}

   public boolean equals(Object object)
   {
      if (this == object) return true;

      if (object == null || ! (object instanceof ABTException)) return false;

      ABTException exception = (ABTException)object;

      return compareTo(exception) == 0 && shifts_.equals(exception.shifts_);
   }

   public int compareTo(Object object)
   {
    if (object == null) return 1;
    return compareTo((ABTException)object);
   }

   public final int compareTo(ABTException exception)
   {
      int result;

      result = start_.compareTo(exception.start_);   if (result != 0) return result;
      result = finish_.compareTo(exception.finish_); if (result != 0) return result;

      return 0;   // equivalent
   }

   public String toString()
   {
      if (start_.equals(finish_)) return start_ + ":" + shifts_;

      return start_ + "-" + finish_ + ":" + shifts_;
   }
}