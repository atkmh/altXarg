
package com.abtcorp.hub;

/*
 * IABTReferenceSource.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 05-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

/**
 * IABTReferenceSource interface for referenced objects
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */


public interface IABTReferenceSource
{
   void addReference(ABTUserSession session, IABTReferenceListener listener,ABTProperty listenerProperty, ABTProperty myProperty);
   void removeReference(ABTUserSession session, IABTReferenceListener listener, ABTProperty myProperty);
   void removeReference(ABTUserSession session, IABTReferenceListener reference);
}
