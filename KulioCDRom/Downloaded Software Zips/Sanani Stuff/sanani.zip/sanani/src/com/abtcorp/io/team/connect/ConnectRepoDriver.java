package com.abtcorp.io.team.connect;

import java.util.Hashtable;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.ABTNotImplementedException;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTValue;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.TWPopulator;
import com.abtcorp.io.team.CodePopulator;
import com.abtcorp.io.team.TWRepoDriver;
import com.abtcorp.io.team.StatusMonitor;
import com.abtcorp.io.team.errorMessages;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;

public class ConnectRepoDriver extends TWRepoDriver implements IABTTWRuleConstants, TWRepoDriverConstants, errorMessages
{
   private Hashtable populators_ = new Hashtable(10,(float)1.0);

   public ConnectRepoDriver() {} // Default constructor used by client API.

   public ConnectRepoDriver(ABTObjectSpace space, ABTUserSession session, String repository, String user, String password)
   {
      super(space,session);

      setRepositoryName(repository);
      setUser(user);
      setPassword(password);
   }

   public ConnectRepoDriver(ABTObjectSpace space, ABTUserSession session)
   {
      super(space,session);
   }
	
	public ABTValue close(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      TWPopulator.close();
   	return super.close(space,session,args);
   }

   public ABTValue populate(ABTObjectSpace space, ABTUserSession session, ABTHashtable args)
   {
      ABTValue value = null;

      if (args != null) {
         
         ABTValue className = (ABTValue)args.get(POPULATOR);
         if (className == null || ABTEmpty.isEmpty(className) || ABTError.isError(className)) return new ABTError(getClass(),"populate",ERR_14,null);

         TWPopulator populator = super.createPopulator(className.stringValue(),space,session);

         if (populator == null) return new ABTError(getClass(),"populate",ERR_13,className.stringValue());

         populator.setMonitor((StatusMonitor)args.get(MONITOR));
         
         if (populator instanceof CodePopulator) {
            ABTValue type = (ABTValue)args.get(TYPE);
            if (type == null || ABTEmpty.isEmpty(type) || ABTError.isError(type)) return new ABTError(getClass(),"populate",ERR_12,null);
            ((CodePopulator)populator).setType(type.stringValue());
         }

         if (populator instanceof ConnectUserPopulator) {
            ABTValue server = (ABTValue)args.get(SERVER_NAME);
            if (server instanceof ABTString) ((ConnectUserPopulator)populator).setServerName(server.stringValue());
         }

         if (populator instanceof ConnectProjectPopulator) {
            ABTValue server = (ABTValue)args.get(SERVER_NAME);

            if (server instanceof ABTString) {
               ((ConnectProjectPopulator)populator).setServerName(server.stringValue());

               ABTValue teamQuery = (ABTValue)args.get(PROJ_TEAM_QUERY);
               if (teamQuery != null && !ABTEmpty.isEmpty(teamQuery) && !ABTError.isError(teamQuery)) {
                  ((ConnectProjectPopulator)populator).setTeamCursor(teamQuery.stringValue());
               }

               ABTValue noteQuery = (ABTValue)args.get(PROJ_NOTE_QUERY);
               if (noteQuery != null && !ABTEmpty.isEmpty(noteQuery) && !ABTError.isError(noteQuery)) {
                  ((ConnectProjectPopulator)populator).setNoteCursor(noteQuery.stringValue());
               }

            	ABTValue start = (ABTValue)args.get(START);
               if (start == null || ABTEmpty.isEmpty(start) || ABTError.isError(start)) start = new ABTInteger(-1);

               ABTValue finish = (ABTValue)args.get(FINISH);
               if (finish == null || ABTEmpty.isEmpty(finish) || ABTError.isError(finish)) finish = new ABTInteger(-1);

               ABTValue strict = (ABTValue)args.get(STRICT);
               if (strict == null || ABTEmpty.isEmpty(strict) || ABTError.isError(strict)) strict = new ABTBoolean(false);

            	try {
                  ((ConnectProjectPopulator)populator).setAssignmentPeriod(start.intValue(),finish.intValue());
                  ((ConnectProjectPopulator)populator).setTaskAssignmentQuery(((ConnectProjectPopulator)populator).getActiveAssignmentQuery(strict.booleanValue(),((ConnectProjectPopulator)populator).getAssignmentPeriodStart(),((ConnectProjectPopulator)populator).getAssignmentPeriodFinish()));
            	} catch (Exception e) {
            	   e.printStackTrace();
            	}

            	ABTValue query = (ABTValue)args.get(QUERY);
               if (query instanceof ABTString) {
                  if (query.stringValue().equals(SERVER_PROJECT_QUERY)) {
                     String[] servers = new String[1];
                     servers[0] = server.stringValue();
                     String temp = TWPopulator.substitute(servers,query.stringValue());

                     int[] ids = new int[1];
                     ids[0] = getSession().getID();

                     temp = TWPopulator.substitute(ids,temp);
                     args.putItemByKey(QUERY,new ABTString(temp));
                  }
               }
            }
         }

         if (populator instanceof ConnectResourcePopulator) {
            ABTValue server = (ABTValue)args.get(SERVER_NAME);

            if (server != null && !ABTEmpty.isEmpty(server) && !ABTError.isError(server)) ((ConnectResourcePopulator)populator).setServerName(server.stringValue());
         }


         if (populator instanceof ConnectTimeSheetPopulator) {
            ABTValue sumQuery = (ABTValue)args.get(SUM_QUERY);
            if (!ABTEmpty.isEmpty(sumQuery) && !ABTError.isError(sumQuery) && sumQuery != null) {
               ABTValue TSSearchKey = (ABTValue)args.get(TS_SEARCH_KEY);
               if (!ABTEmpty.isEmpty(TSSearchKey) && !ABTError.isError(TSSearchKey) && TSSearchKey != null) {
                  ABTValue sumFieldName = (ABTValue)args.get(SUM_FIELD_NAME);
                  if (!ABTEmpty.isEmpty(sumFieldName) && !ABTError.isError(sumFieldName) && sumFieldName != null) {
                     ((ConnectTimeSheetPopulator)populator).setSumQuery(sumQuery.stringValue(), TSSearchKey.stringValue(), sumFieldName.stringValue());
                  }
               }
            }

            ABTValue noteQuery = (ABTValue)args.get(TIMESHEET_NOTE_QUERY);
            if (noteQuery != null && !ABTEmpty.isEmpty(noteQuery) && !ABTError.isError(noteQuery)) {
               ((ConnectTimeSheetPopulator)populator).setNoteCursor(noteQuery.stringValue());
            }
         }

      	ABTValue query = (ABTValue)args.get(QUERY);
         if (query == null || ABTEmpty.isEmpty(query) || ABTError.isError(query)) return new ABTError(getClass(),"populate",ERR_11,null);

         ABTValue useSystem = (ABTValue)args.get(USE_SYSTEM);
         if (useSystem == null || ABTEmpty.isEmpty(useSystem) || ABTError.isError(useSystem)) useSystem = new ABTBoolean(false);

         try {
            populator.setPopulatorCursor(query.stringValue(),((ABTBoolean)useSystem).booleanValue());
         } catch (Exception e) {
            return new ABTError(getClass(),"populate",ERR_10,e.getMessage());
         }

         session.startTransaction();

         try {
            value = populator.populate();

         } catch (Exception e) {
            e.printStackTrace();
         }

         session.commitTransaction();

      } else value = new ABTError(getClass(),"populate",ERR_9,null);

      return value;
   }
}