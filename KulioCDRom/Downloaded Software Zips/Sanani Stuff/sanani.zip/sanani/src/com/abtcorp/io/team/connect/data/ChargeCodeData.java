package com.abtcorp.io.team.connect.data;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;

public class ChargeCodeData extends SimpleData
{
   public ChargeCodeData(ABTObject object, ABTUserSession session)
   {
      super(object,session);
   }
}
