/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTCollatorComparator.java, 8, 12/8/98 9:48:19 AM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.text.*;
import java.io.Serializable;

/**
 * ABTCollatorComparator is an implementation of the ABTComparator interface. It will order
 * ABTValues using a given Collator. This comparator should only be used to compare objects
 * of type ABTValue.
 *
 * @version    $Revision: 8$, $Date: 12/8/98 9:48:19 AM$
 * @author     $Author: Benoit Menendez$
 *
 * @see        com.abtcorp.core.ABTComparator
 * @see        com.abtcorp.core.ABTValue
 *
 */

public class ABTCollatorComparator implements ABTComparator, Serializable
{
   private static final long serialVersionUID = -3874894691025802119L;   
/**
 * the Collator used in the comparison.
 */
 
   Collator collator_;

/**
 * Default (empty) constructor. This will use the default Collator for the Locale.
 */
 
   public ABTCollatorComparator() {this(Collator.getInstance());}
   
/**
 * This constructs an ABTCollatorComparator with a specific Collator.
 *
 * @param collator the collator to be used in the comparison.
 */
 
   public ABTCollatorComparator(Collator collator) {collator_ = collator;}

/**
 * This method compares two ABTValues using a Collator.
 *
 * Like all ABTComparator implementations, this method will also ensure that null elements
 * are always before non null elements in the order.
 *
 * @return  a negative integer, zero, or a positive integer as the
 * 	      first argument is less than, equal to, or greater than the
 *	         second. 
 */
 
   public int compare(Object object1, Object object2)
   {
      if (object1 == null && object2 == null) return 0;
      if (object1 == null)                    return -1;
      if (object2 == null)                    return +1;

      return collator_.compare(((ABTValue)object1).stringValue(), ((ABTValue)object2).stringValue());
   }
}