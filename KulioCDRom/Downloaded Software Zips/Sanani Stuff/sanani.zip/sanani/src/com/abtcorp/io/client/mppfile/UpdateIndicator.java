package com.abtcorp.io.client.mppfile;

//this is used to tagging if update
//or add occurs so that deleted
//items can be identified.

public class UpdateIndicator
{

   private boolean  updated_;

   public UpdateIndicator()
   {
      updated_  = false;
   }

   public void tagAsUpdated()
   {
      updated_  = true;
   }

   public boolean hasItBeenUpdated()
   {
      return updated_;
   }

}
