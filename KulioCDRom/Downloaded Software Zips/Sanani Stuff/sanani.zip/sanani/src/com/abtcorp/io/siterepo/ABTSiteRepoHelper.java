package com.abtcorp.io.siterepo;

/*
 * ABTSiteRepoHelper.java 06/24/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 07-16-98    LZX         Initial Implementation
 * 08-04-98    SOB         Mods to support importing of com.abtcorp.io.server.*;
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;
import com.abtcorp.idl.*;

/**
 * ABTSiteRepoHelper is an abstract class for the ABT site repo driver.
 * It is extended by the other site repo helper classes.
 *
 *  <pre>
 *       ABTIOSiteRepoHelper ra = new ABTIOSiteRepoHelper(ABTRepositoryDriver driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 */

public abstract class ABTSiteRepoHelper extends ABTIORepoHelper implements IABTSiteRepoConstants, IABTRuleConstants
{

   protected ABTRepository repo_;           // the repository connected to
   protected ABTRepositoryDriver driver_;   // the driver that uses this helper
   protected ABTCursor cursor_;             // the cursor selected from the repository
   protected ABTHashtable reqParams_;       // the required parameters when creating the object
   protected ABTObject parent_;             // the parent that owns the objects to be populated/saved
   protected ABTObject site_;               // the site object (parent of all other global objects)
   protected String component_;             // the name of the helper class
   protected String matchField_;            // the name of the field to do match-update with

/**
 * ABTSiteRepoHelper constructor.
 * @param driver: the reference to the driver.
 */
   ABTSiteRepoHelper(ABTRepositoryDriver driver,  ABTObject parent, String table, String type)
   {
      super(driver, table, type);
      driver_ = driver;
      userSession_ = driver.getUserSession();
      space_ = driver.getSpace();
	   repo_ = driver_.getRepository();
	   cursor_ = null;
	   parent_ = parent;
      reqParams_ = new ABTHashtable();

      // get rid of the "abt." in front of the object type to make the component name
      // for the helper class (for error messages).
      component_ = type.substring(4);
   }


/**
 * Populate the object space with data selected from the repository.
 * @param list       if not null, it is the name of the objet set to be retrieved
 *                   from the parent object in the 1st pass of populate. the process
 *                   will iterate thru the object set to find objects that came
 *                   from the same repository and do update or delete on them.
 * @param query      the query string used to select from the repository
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate(String list, String query) throws ABTException
	{
	   ABTValue val = null;

      cursor_ = getCursor(query, table_ + "." + FLD_ID);

      try
      {
         // First, iterate through the object set specified by the "list" name
         // and perform update (match by prID) or delete for the objects
         // that came from the same repository.

         val = populateFirstPass(cursor_, list);

         // Second, go through the remaining rows in the cursor and perform update
         // (match by external id or name field) or add new.
         val = populateSecondPass(cursor_, true, true);
         
         // last, populate/set other object refereces (do nothing by default)
         populateOthers(cursor_);
      }
      finally
      {
         closeCursor(cursor_);
      }

  	   return val;
	}


/**
 * Populate the object space with data selected from the repository. This method
 * is used when the caller has already selected a cursor for the obejcts to be 
 * populated and does not need to go through the populateFirstPass() where the 
 * objects already in the space will be updated or deleted based on the cursor.
 * It is assummed that the caller is responsible for managing the cursor (open and close).
 * @param cur     the cursor used to populate.
 * @param loadAll true = process all the rows in cursor, false = process only the current row
 * @return ABTValue: the populated object or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	public ABTValue populate(ABTCursor cur, boolean loadAll) throws ABTException
	{
      // make sure the cursor is not null
      if (cur == null)
         processError("populate",
                   errorMessages.ERR_CURSOR_ERROR,
                   "Input cursor is null.");

      // populate from the cursor, do not override what's already in the space.
      ABTValue val = populateSecondPass(cur, false, loadAll);
      
      // populate/set other object refereces (do nothing by default)
      populateOthers(cur);
      
      return val;
	}


/**
 * Populate based on the object set in the space.
 * Iterate through the object set specified by the "list" field.
 * For those objects that came from the same repository originally, find
 * matching prID in the cursor. If found, update the object using the
 * cursor values and drop current row from the cursor. If not found
 * (meaning someone deleted the record from the repository), delete the
 * object from the object space.
 * @param cur     the cursor to populate from.
 * @param list    the name of the object set to process. if null, skip this pass.
 * @return ABTValue: the last populated object or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   protected ABTValue populateFirstPass(ABTCursor cur, String list) throws ABTException
   {
	   ABTValue val = null;

      // if the input list name is null, simply return.
      if (list == null)
         return null;

      val = getValue(parent_, list);
      if (val instanceof ABTObjectSet)
      {
         ABTObjectSet os = (ABTObjectSet)val;
         Enumeration e = os.elements( userSession_ );

         // get the current repo id
         long curRepoID = repo_.getID();

         // set the cursor's sort order to prID for the search.
         //cur.setSort(table_ + "." + FLD_ID);

         // go through the object set
         while( e.hasMoreElements() )
         {
            ABTObject obj = (ABTObject)e.nextElement();

            // process only those object that came from the same repository
            if (getRepoID(obj) == curRepoID)
            {
               if (bSearchCursor(obj, cur, OFD_ID))
               {
                  // if prID is found in the cursor, update the object in the space.
                  val = update(cur, obj, null, true);

                  // drop current row from the cursor so that the remaining
                  // rows can be processed in the 2nd pass later.
         			cur.drop();
               }
               else
                  // If prID is not found, it means the record has been deleted
                  // from the repository by some other users.
                  // Go ahead delete the object from the object space however
                  // it may be rejected by the rules if the object is currently
                  // referenced by other objects. Move on in either case.
                  // NOTE: the reason why we don't use the delete(ABTObject) method
                  // from the ABTServerHelper class here is that we don't want to
                  // throw an exception when the delete fails!!!
                  val = obj.delete(userSession_);
            }
         }
      }
      return val;
   }


/**
 * Populate based on the cursor. use the external id or name (determined
 * by the matchField string) to search the object space.
 * If found and update is required, update the object and the remote id. 
 * If not found, add a new object into the object space.
 * @param cur           the cursor used to populate.
 * @param updateSpace   true = update the object in space if found, 
 *                      false = do not touch the object in space
 * @param loadAll       true = process all the rows in cursor, 
 *                      false = process only the current row
 * @return ABTValue: the last populated object or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   protected ABTValue populateSecondPass(ABTCursor cur, boolean updateSpace, boolean loadAll) throws ABTException
   {
	   ABTValue val = null;
	   String searchStr = null;

      int count = cur.getRecordCount();
      if (count == 0)
         return null;   // return if the cursor is empty

      // position the cursor if it's not positioned yet. (if the 1st pass was called,
      // the cursor would have been positioned and we don't need to do this.)
      if (!cur.isValid())
         cur.moveFirst();

      do    // cursor has been positioned
      {
   	   val = null;

         // construct a remote id for later use
         long prID = cur.getFieldInt(FLD_ID);
         ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID);

         // For those objects that need to match-update, use the external id or name
         // (the unique string field) to search in the object space.
         // The rest (without a unique ext id or name field) will always fall into the
         // create logic (that is, create a fresh new set. don't mix old and new.)
         if (matchField_ != null)
         {
            // get match-update field from the repository (prepend "pr" to the property
            // name to make up the repository field name)
            String prPrefix = "pr";
            searchStr = cur.getFieldString(prPrefix.concat(matchField_));

            // See if there is an object already in the object space that matches
            // the field.
            val = find(type_, matchField_, searchStr);
         }

         if ((val instanceof ABTObjectSet) && (size((ABTObjectSet)val) > 0))
         {
            if (size((ABTObjectSet)val) == 1)
               // If object found AND the caller requested updating the object, 
               // do update. otherwise use the object found.
               val = update(cur, at((ABTObjectSet)val, 0), id, updateSpace); 
            else
               // there should be only one found in the set
               processError("populate",
                            errorMessages.ERR_DUPLICATE_DETECTED,
                            "More than one " + searchStr + " found in the objecet space.");
         }
         else
         {
            // if not found, create an object and set its property values.
            val = create(cur, type_, id, reqParams_);
         }

         // get out of the loop if caller requests loading only the current row
         if (!loadAll)
            break;

      }  while (cur.moveNext()); // end do-while()

   	return val;
   }


/**
 * Populate subordinate objects, set references, etc.. Do nothing by default.
 * @param cur  the cursor used to populate.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
   protected void populateOthers(ABTCursor cur) throws ABTException
   {      
   }
   

/**
 * Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(ABTCursor cur, String type, ABTRemoteIDRepository id, ABTHashtable params) throws ABTException
   {
		ABTObject object = createObject(type, id, params);
		setValues(ps_, cur, object);
      return object;
   }

   
/**
 * Update an existing object in the object space with properties from the repository.
 *	@param object: the object to be updated.
 *	@return ABTValue: a reference to the object updated or an ABTError.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue update(ABTCursor cur, ABTObject object, ABTRemoteIDRepository id, boolean updateSpace) throws ABTException
   {
      if (updateSpace)
      {
         // set the properties from the repository cursor.
   		setValues(ps_, cur, object);

         // update the remote id if the input value is not null.
         if (id != null)
            setValue(object, IABTPropertyType.PROP_REMOTEID, id);
      }
      
      return object;
   }

/**
 * Set property values in an object.
 * @param ps: the property list.
 * @param cur: the cursor.
 * @param obj: the object.
 * @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector aps, ABTCursor cur, ABTObject obj) throws ABTException
   {
      setPropertyValues(aps, cur, obj);
   }


/**
 * Save objects from the object space back to the repository
 * @param parent     the object that contains the object set to be saved
 * @param list       the name of the object set to save
 * @param matchField the name of the field to do match-update on (e.g., OFD_EXTERNALID)
 * @return ABTValue of the object set that's saved
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue save(ABTObject parent, String list, String query) throws ABTException
   {
      // get object set from the parent object
   	ABTValue val = getValue(parent, list);
   	if (!(val instanceof ABTObjectSet) || ABTValue.isNull(val))
   	{
         processError(MOD_SAVE,
                     errorMessages.ERR_OBJECTSET_NOT_FOUND,
                     list + " object set is not found in " + parent_.getObjectType() + ". id = '" + getValue(parent_, OFD_ID));
         return null;
      }

      return save((ABTObjectSet)val, query);
   }


/**
 * Save objects from the object space back to the repository
 * @param oSet       the object set to be saved
 * @param matchField the name of the field to do match-update on (e.g., OFD_EXTERNALID)
 * @return ABTValue of the object set that's saved
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue save(ABTObjectSet oSet, String query) throws ABTException
   {
      ABTValue val = null;

      // return if there is nothing in the set
      if (size(oSet) == 0)
         return null;

      // make sure the object set is of the right type
      if (!oSet.getObjectSetType().equals(type_))
      {
         processError(MOD_SAVE,
                     errorMessages.ERR_INVALID_TYPE,
                     "expected object set type = " + type_ + ", bad type = " + oSet.getObjectSetType());
         return null;
      }

      // a cursor is selected for the entire object set to be saved (all the
      // records that belong to the parent) sorted by prID.
      cursor_ = getCursor(query, table_ + "." + FLD_ID);

      try
      {
         // first, save the objects in oSet into the repository
         val = saveObjects(oSet, cursor_);

         // then go through the deleted objects in oSet and remove them from
         // the repository.
         val = deleteObjects(oSet, cursor_);
      }
      finally
      {
         closeCursor(cursor_);
      }

      return val;
   }

   private ABTValue saveObjects(ABTObjectSet oSet, ABTCursor cur) throws ABTException
   {
      // get the current repo id
      long curRepoID = repo_.getID();

      // iterate through the object set
      Enumeration e = oSet.elements( userSession_ );
      while( e.hasMoreElements() )
      {
         // get the next object
         ABTObject obj = (ABTObject)e.nextElement();

         // check to see if we need to save this object. if not, skip to the next one.
         // (e.g., currently we don't save non-role resources.)
         if (!saveThisObject(obj))
            continue;

         boolean found = false;

         // for the objects that came from the same repository, match on prID first.
         if ((getRepoID(obj) == curRepoID) && (bSearchCursor(obj, cur, OFD_ID)))
            found = true;

         // then match on external id or name
         if (!found && (matchField_ != null))
            found = lSearchCursor(obj, cur, matchField_);

         // add or edit cursor depending on whether this object was found in cursor
			if (found)
			{
        		// edit the cursor for pre-existing record
           	cursorEdit(cur);
         }
         else
         {
         	// add a new row to the end of the cursor so that the order of the cursor won't
         	// get messed up (the cursor is ordered by prID for faster binary search and the prID of
         	// the new row will be guranteed greater than the prID of the last row in the cursor).
         	cur.moveEOF();
            cursorAddNew(cur);
	      }

         // set fields and update the cursor.
			setCursorValues(ps_, cursor_, obj, this, !found);
         cursorUpdate(cursor_);

         // reset the prID and remote id back in the object in case this is a new
         // record OR this record was matched by externalID/name
         ABTValue prID = cursor_.getField(FLD_ID);
         setValue(obj, OFD_ID, prID);

         ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID.intValue() );
         obj.getID().setRemote(userSession_, id);

         // drop the row afterwards (so next round we'll have less to search)
			cursor_.drop();

      }  // end while()

      return oSet;
   }

   private ABTValue deleteObjects(ABTObjectSet oSet, ABTCursor cur) throws ABTException
   {
      // Now process the deleted objects associated with the input object set.  The
      // remote ID's of these deleted objects are presented in an ABTArray.
      ABTArray da = oSet.getDeletedData(userSession_);
      Enumeration rmtIDEnum = da.elements();

      // get current repository id
      long curRepoID = repo_.getID();

      // For each deleted object in the object set, see if a corresponding tuple exists in the cursor's
      // result set.  If it exists, delete it.  If it doesn't exist, skip the object and get the next
      // one; the tuple has already been deleted.  If the ABTArray contains an object which is not of type
      // ABTRemoteIDRepository, skip it and get the next object.
      while ( rmtIDEnum.hasMoreElements() )
      {
         Object rmtID = rmtIDEnum.nextElement();

         // if not a repository remote id, skip to the next
         if ( !(rmtID instanceof ABTRemoteIDRepository) )
            continue;

         // if didn't come from the same repository, skip to the next
         long repoID = (int) ((ABTRemoteIDRepository)rmtID).getRepositoryID();
         if (repoID != curRepoID)
            continue;

         // search by prID. if found, delete from cursor.
         int id = (int) ((ABTRemoteIDRepository)rmtID).getPrID();
         if ( cur.bsearchFirst(FLD_ID, new ABTInteger(id)) )
            cur.delete();
      }
      return oSet;
   }

/**
 *    Populate an object space with an object (or objects) as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      processError("populate",
                   errorMessages.ERR_NOT_IMPLEMENTED,
                   "populate(ABTArray) is not implemented.");
   	return null;
   }

/**
 * populate method without any input params.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	protected ABTValue populate() throws ABTException
	{
      processError("populate",
                   errorMessages.ERR_NOT_IMPLEMENTED,
                   "populate() is not implemented.");
	   return null;
   }


/**
 * Create a new object in the object space and initialize it with values appropriate to the
 * driver being used.
 *	@param ABTArray parms, the elements of which are meaningful as parameters to the particular
 * helper
 *	@return an ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue create(ABTArray parms) throws ABTException
   {
      processError("create",
                   errorMessages.ERR_NOT_IMPLEMENTED,
                   "create(ABTArray) is not implemented.");
   	return null;
   }

/**
 *    Update an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param ABTArray parms, the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object updated in the
 *    object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue update(ABTArray parms) throws ABTException
   {
      processError("update",
                   errorMessages.ERR_NOT_IMPLEMENTED,
                   "update(ABTArray) is not implemented.");
   	return null;
   }


/**
 *    Save an object (or objects) from the object space as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return void
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public void save(ABTArray parms) throws ABTException
   {
      processError("save",
                   errorMessages.ERR_NOT_IMPLEMENTED,
                   "save(ABTArray) is not implemented.");                 
   }


/**
 * Release the cursor.
 *	@param cursor: the cursor to be released.
 */
   protected void closeCursor(ABTCursor cursor)
   {
      if (cursor != null)
      {
         cursor.release();
         cursor = null;
      }
   }


/**
 *    Processes an error situation raised by the caller by calling ABTMMRepoDriver's processError().
 *    @param method: the method in which error occured.
 *    @param code: the error code
 *    @param info: further information describing the error condition
 *    @return some kind of value (for now the severity level).
 *    @exception ABTException if the severity level is 1 (the highest severity)
 */
 public int processError(String method, ABTErrorCode code, Object info) throws ABTException
 {
   return driver_.processError(component_, method, code, info);
 }


/**
 *    Get id from cursor and retrieve the object associated with the id from a hash table.
 *    @param cur:          the cursor that contains the id
 *    @param idFieldName:  the column name of the id (e.g., prTaskID)
 *    @param hash:         the hash table that contains the id-object pairs
 *    @param objType:      the type of the requested object
 *    @return the requested object.
 *    @exception ABTException if error occurred
 */
 public ABTObject getObjectFromHash(ABTCursor cur, String idFieldName, Hashtable hash, String objType) throws ABTException
 {
   ABTObject obj = null;

   // get id from cursor
   Long id = new Long(cur.getFieldInt(idFieldName));

   // make sure the id is not null
   if (id == null)
      processError("getObjectFromHash",
                  errorMessages.ERR_INVALID_ID,
                  idFieldName + " = " + id);

   // make sure the hash table is not null
   if ((hash == null) || hash.isEmpty())
      processError("getObjectFromHash",
                  errorMessages.ERR_INVALID_HASH,
                  "Empty hash table for object " + objType);

   // get object associated with the id from hash table
   obj = (ABTObject) hash.get(id);

   // make sure the object is not null and of correct type
   if (obj == null)
      processError("getObjectFromHash",
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  "object type = " + objType + ", " + idFieldName + " = " + id);

   else if (obj.getObjectType() != objType)
   {
      processError("getObjectFromHash",
                  errorMessages.ERR_INVALID_TYPE,
                  "expected object type = " + objType + ", bad type = " + obj.getObjectType());
      obj = null;
   }

   // finally, return the object itself.
   return obj;
}


/**
 *    binary-search a cursor.
 *    @param obj     the object to get search string from
 *    @param cur     the cursor to be searched (should be sorted by the search field)
 *    @param field   the field to search on
 *    @return     true if found, false otherwise.
 *    @exception  ABTException if error occurred
 */
protected boolean bSearchCursor (ABTObject obj, ABTCursor cur, String field) throws ABTException
{
   // retrieve the field to be searched
   ABTValue val = getValue(obj, field);

   // prepend "pr" to the field name to make a repository field
   String prPrefix = "pr";

   // search this field in the cursor
	if (cur.bsearchFirst(prPrefix.concat(field), val))
	   return true;
   else
	   return false;
}

/**
 *    linear-search a cursor.
 *    @param obj     the object to get search string from
 *    @param cur     the cursor to be searched
 *    @param field   the field to search on
 *    @return     true if found, false otherwise.
 *    @exception  ABTException if error occurred
 */
protected boolean lSearchCursor (ABTObject obj, ABTCursor cur, String field) throws ABTException
{
   // retrieve the field to be searched
   ABTValue val = getValue(obj, field);

   // prepend "pr" to the field name to make a repository field
   String prPrefix = "pr";

   // search the cursor
	if (cur.lsearchFirst(prPrefix.concat(field), val))
	   return true;
   else
	   return false;
}


/**
 *    finds object in the object space. first match by remote id. if not found,
 *    match by external id or name.
 *    @param type       the type of object to find
 *    @param matchField the name of the field to match on (i.e., prExternaID or prName)
 *                      if remote id is not found.
 *    @param id         the prID value of the object
 *    @param cur        the cursor used to get external id (or name) based on prID
 *    @return     the object found or null if not found.
 *    @exception  ABTException if error occurred or object not found
 */
protected ABTValue findObject(String type, String matchField, int id, ABTCursor cur) throws ABTException
{
   // find object in the object space. first match by remote id.
   int repoID = repo_.getID();
   ABTRemoteIDRepository rmtID = new ABTRemoteIDRepository(repoID, id);
   ABTValue val = find(type, rmtID);

   if (val instanceof ABTObject)
      // return the object found
      return val;
   else
   {
      // if not found, match by external id
      // get external id from the cursor
      if (cur.bsearchFirstInt(FLD_ID, id))
      {
         String searchStr = cur.getField(matchField).stringValue();
         val = find(type, matchField.substring(2), searchStr);
         if ((val instanceof ABTObjectSet) && (size((ABTObjectSet)val) > 0))
            return at((ABTObjectSet)val, 0);
      }
      else
         processError("findObject",
                errorMessages.ERR_RECORD_NOT_FOUND,
                "prID '" + id + "' is not found in " + cur.getTableName());
   }
   return null;
}


/**
 *    finds object in the object space. first match by remote id. if not found,
 *    match by external id or name.
 *    @param type       the type of object to find
 *    @param id         the prID value of the object
 *    @param searchStr  the external id (or name) of the object
 *    @return     the object found or null if not found.
 *    @exception  ABTException if error occurred or object not found
 */
protected ABTValue findObject(String type, String matchField, int id, String searchStr) throws ABTException
{
   // find object in the object space. first match by remote id.
   int repoID = repo_.getID();
   ABTRemoteIDRepository rmtID = new ABTRemoteIDRepository(repoID, id);
   ABTValue val = find(type, rmtID);

   if (val instanceof ABTObject)
      // return the object found
      return val;
   else
   {
      // if not found, match by external id or name
         val = find(type, matchField, searchStr);
         if ((val instanceof ABTObjectSet) && (size((ABTObjectSet)val) > 0))
            return at((ABTObjectSet)val, 0);
   }
   return null;
}


/**
 *    determines if an object should be saved back to the repository.
 *    @param obj  the object in question
 *    @return     true if yes, false if no.
 *    @exception  ABTException if error occurred
 */
protected boolean saveThisObject (ABTObject obj) throws ABTException
{
   return true;
}

/**
 * retrieves the ID field from an object and sets it to the correspondent field in
 * a cursor. The reason to do this is that when a new object is saved back to
 * the repository, the prID is assigned by PVision. Therefore we need to set this
 * prID back to the object and whenver it is referenced by other objects, we need
 * to retried the ID from the object itself.
 *
 * @param cur        the cursor to set ID to
 * @param obj        the object being saved
 * @param refObjName the name of the referenced object to retrieve ID from
 * @param idName     the ID field name in cursor
 * @return     true if new, false if not.
 * @exception  ABTException if error occurred
 */
protected void setIDFromObject (ABTCursor cur, ABTObject obj, String refObjName, String idName) throws ABTException
{
   // retrieve the object that contains the ID
	ABTValue val = getValue(obj, refObjName);
   if ((val instanceof ABTObject) && !ABTValue.isNull(val))
      // set the correspondent ID field in cursor using the ID value from the object
      cursorSetField(cur, idName, getValue((ABTObject)val, OFD_ID));
   else
      processError("setIDFromObject",
                  errorMessages.ERR_OBJECT_NOT_FOUND,
                  refObjName + " not found for " + obj.getObjectType());
}


   /**
    * Deletes an object set that belongs to an object.
    * @param parent      the object that contains the object set to be deleted.
    * @param listName    the name of the object set to be deleted.
    * @return void
    * @exception  ABTException if error occurred
    */
   protected void deleteList( ABTObject parent, String listName) throws ABTException
   {
      // get object set reference
      ABTValue val = getValue(parent, listName);

      if (val instanceof ABTObjectSet)
      {
         ABTObjectSet os = (ABTObjectSet)val;
         Enumeration e = os.elements( userSession_ );
         while( e.hasMoreElements() )
         {
            ABTObject object = (ABTObject)e.nextElement();
            delete( object );
         }
      }
      else
         processError("deleteList",
                  errorMessages.ERR_OBJECTSET_NOT_FOUND,
                  listName + " is not an ABTObjectSet in " + parent.getObjectType());

   }

/**
 * selects a cursor from repository and sort it to the specified order.
 * @param query      the select statement.
 * @param sortField  if provided, set cursor to the order of this field.
 * @return    the cursor
 * @exception  ABTException if error occurred
 */
   protected ABTCursor getCursor(String query, String sortField) throws ABTException
   {
      // select cursor from the repository
      ABTCursor cur = repo_.select(query);
      if (cur == null)
         processError("getCursor",
                      errorMessages.ERR_SELECT_ERROR,
                      "Query = '" + query + "'");

      // set sort order if needed
      if (sortField != null)
         cur.setSort(sortField);

      return cur;
  }

}