
package com.abtcorp.hub;

/*
 * ABTObjectSet.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.*;
import com.abtcorp.parser.*;
import java.util.Enumeration;

import java.lang.Math;

/**
 * ObjectSet contains the functionallity needed to manage a
 * list of BOs and implements ABTValue
 * <p>
 * @see com.abtcorp.hub.ABTValue
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTObjectSet extends ABTValue implements IABTReferenceListener,IABTReferenceSource,IABTTransactionInstance
{

//051198-HJB-COM-access requires public members for inner class-access

   /**
   * reference to my rule object
   */
//   private ABTRule my_Rule;
   public ABTRule my_Rule;

   protected ABTTransactionContainer data;

   /**
   * reference to sortorder-definition
   */
//   private ABTSortOrderDefinition sortOrderDef;
   public ABTSortOrderDefinition sortOrderDef;

    /**
    * referenceAdapter
    */
    private ABTReferenceAdapter refAdapter;



   public ABTArray getDeletedData(ABTUserSession session)
   {
      ABTOSet os = getActive(session,false);
      return os.getDeletedData();
   }

   public void clearDeletedIDs(ABTUserSession session)
   {
      if (! lock(session)) return;
      ABTOSet os = getActive(session,true);
      os.clearDeletedData();
      return;
   }


   public ABTObjectSetIDs getIDSet( ABTUserSession session )
   {
      return new ABTObjectSetIDs( session, this );
   }

   public ABTUserSession getLockHolder()
   {
        return data.getLockHolder();
   }



   public synchronized boolean lock(ABTUserSession requestor)
   {
         return data.lock(requestor);
   }

   public synchronized void removeOnelock(ABTUserSession requestor)
   {
    data.removeOnelock(requestor);
   }

    private ABTOSet getActive(ABTUserSession session,boolean create)
    {
      return (ABTOSet)data.getActive(session,create);
    }

   public synchronized boolean unLock(ABTUserSession requestor)
   {
    return data.unLock(requestor);
   }

   public void rollback(ABTUserSession session)
   {
    data.rollback(session);
   }

   protected void commitAll(ABTUserSession session,boolean recall)
   {
    data.commitAll(session,recall);

   }
   public void commit(ABTUserSession session)
   {
    data.commit(session);
   }

//=============================================================================
// Constructor/Deconstructor
//=============================================================================

   /**
   * dumping
	* level 0 : just data;
	* level 1 : my class & data & deletedData;
	* level 2 : level 1 + data
	* level 3 : level 2 + deletedData
	* level 4 : level 3 + rules

   */
   public String dump(int indent, int level)
   {
        return new String("not implemented");
   }

   private String dumpAdapter(int indent,int level)
   {
      if (refAdapter == null)
         return "no references";
      return refAdapter.dump(indent+1,level)         ;
   }

   private String dumpArray(ABTArray ar, int indent,int level)
   {
      StringBuffer sb = new StringBuffer();
      if (ar != null)
      {
         for (int i = 0; i < ar.size(); i++)
         {
            sb.append(((ABTObject)ar.at(i)).dump(indent+1,level));
         }
      }
      return sb.toString();;
   }

  /**
   * Default constructor
   * @exception java.lang.IllegalArgumentException If size is negative.
   */
   protected ABTObjectSet()
   {
      super();
      my_Rule = null;
      data = null;
   }


  /**
   * called after default class constructor to actually set the appropriate
   * connections
   * @param RULE_ correct rule for this 'thing'
   * @param data_ existing ABTRowSet or null if new
   * @exception java.lang.IllegalArgumentException If size is negative.
   */
   protected void instantiate (ABTUserSession session,ABTRule Rule_,ABTRowSet rowdata_)
   {

      my_Rule = Rule_;
      sortOrderDef = new ABTSortOrderDefinition(session, my_Rule);

      if (rowdata_ != null)
        data = new ABTTransactionContainer(this,ABTTransactionContainer.SINGLE,new ABTOSet(rowdata_.getObjectData(session)));
      else
        data = new ABTTransactionContainer(this,ABTTransactionContainer.SINGLE,new ABTOSet());
   }



  /**
   * Construct myself to be a shallow copy of an existing ABTObjectSet.
   * @param objectSet The ABTObjectSet to copy.
   */
   protected ABTObjectSet(ABTUserSession session,ABTObjectSet oldset)
   {
      this();
      my_Rule = oldset.getRule();
      sortOrderDef = new ABTSortOrderDefinition(session,my_Rule);
      data = new ABTTransactionContainer(this,ABTTransactionContainer.SINGLE, new ABTOSet(oldset.getData()));

   }

   /**
   * remove all pending references
   */
	protected final void destroy()
	{
	   my_Rule = null;
	   data = null;
	}

   /**
   * remove all pending references
   */
   public void finalize()
   {
      destroy();
   }


//=============================================================================
// ABTValue - related
//=============================================================================


   /*
   * return this
   * @see cvom.abtcorp.core.ABTValue
   * @return
   */
   public ABTValue eval()
   {
    return this;
   }

   public ABTOSet getData()
   {
      return getActive(null,false);
   }


  /**
   * Return true if I'm equal to another object.
   * @param object The object to compare myself against.
   */
   public boolean equals( Object object )
   {
      return (

         (object instanceof ABTObjectSet)
            &&
         (equals( (ABTObjectSet)object ))
         );

   }

  /**
   * Return true if I contain the same items in the same order as
   * another ObjectSet. Use equals() to compare the individual elements.
   * @param objectSet The Objectset to compare myself against.
   */
   public synchronized boolean equals( ABTObjectSet objectSet )
   {
      return getData().equals(objectSet.getData());
   }


  /**
   * Return my hash code for support of hashing containers
   */
   public synchronized int hashCode()
   {
      return getData().hashCode();
   }






   /*
   * return my rule
   * @return
   */
   public ABTRule getRule()
   {
      return my_Rule;
   }


   /**
   * return the name of the rule (i.e. the type) of this object
   */
   public String getObjectSetType()
   {
      return getRule().getName();
   }

   /*
   * return a sortorder-defintition
   * @return
   */
   public ABTSortOrderDefinition getSortOrder(ABTUserSession session)
   {
      return (ABTSortOrderDefinition) sortOrderDef.clone(session);
   }


//================================================================================
// setting valuess in ALL instances
//================================================================================
  /**
   * Set all the properties in the given list to their corresponding values
   * if successfull the passed in hashtable will reflect the set values....
   * @param propertyValuePairs pairs of properties and values in hashtable
   * @return ABTError - error in one of them or null if successfull
   */
	public ABTValue setValues(ABTUserSession session,ABTHashtable propertyValuePairs)
	{
	    int numberOfProperties = propertyValuePairs.size();
	    int[] properties = new int[numberOfProperties];
	    ABTArray values     = new ABTArray();

	    int i = 0;
	    int p_index = -1;

        Enumeration e = propertyValuePairs.keys();
        while (e.hasMoreElements())
        {
            ABTValue o = (ABTValue)e.nextElement();
            if (o instanceof ABTString)
                p_index = my_Rule.indexForName(((ABTString)o).stringValue());
            else
                if (o instanceof ABTProperty)
                    p_index = ((ABTProperty)o).getRowIndex();
                else
                    p_index = -1;
            if (p_index != -1)
            {
                // try to get the value associated with this property
                try
                {
                    ABTValue value = (ABTValue)propertyValuePairs.get(o);
                    values.add(value);
                }
                catch (Exception e1)
                {
                    ABTError er1 = new ABTErrorHub("ABTObjectSet->setValues",errorMessages.ERR_8,o);
                    values.add(er1);
                    p_index = -1;
                }
            }
            else
            {
                ABTError er2 = new ABTErrorHub("ABTObjectSet->setValues",errorMessages.ERR_7,o);
                values.add(er2);
            }
            properties[i] = p_index;
            i++;
        }

        // walk through items
        Enumeration iterator = elements(session);
        ABTArray result = new ABTArray();
        result.add(values);
        while (iterator.hasMoreElements())
        {
            session.startTransaction();
            ABTObject object = (ABTObject)(iterator.nextElement());
            boolean ok = true;
            for (int index = 0; index < numberOfProperties;index++)
            {
                if (properties[index] != -1)
                {
                    ABTValue val = (ABTValue)values.at(index);
                    if (ABTValue.isEmpty(val))
                        val = null;
                    ABTValue v1 = object.setValue(session,properties[index],val);
                    if (ABTError.isError(v1))
                    {
                        ABTArray tmp = new ABTArray();
                        tmp.add(object);
                        tmp.add(v1);
                        tmp.add(new ABTInteger(index));
                        result.add(new ABTErrorHub("ABTObjectSpace->setValuesobject",errorMessages.ERR_9,tmp));
                        ok = false;
                        index = 99999;
                    }
                }
            }
            if (ok)
            {
                result.add(object);
                session.commitTransaction();
            }
            else
                session.rollbackTransaction();

        }
        return result;
    }
//================================================================================
// adding / removeing elements
//================================================================================
   /**
   * Remove all of my elements.
   */
   public synchronized ABTValue clear(ABTUserSession session)
   {
        if (! lock(session))
            return new ABTErrorHub("ABTObjectSet->remove",errorMessages.ERR_10,this);
      return my_Rule.clear(session,this);
   }


  /**
   * Remove the element at a particular index.
   * @param index The index of the element to remove.
   * @return The object removed.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
   public synchronized ABTValue remove( ABTUserSession session, int index )
   {
        if (! lock(session))
            return new ABTErrorHub("ABTObjectSet->remove",errorMessages.ERR_10,this);

      ABTOSet os = getActive(session,false);
      ABTObject v = null;
      try
      {
          v = (ABTObject)(os.at(true,index));
      }
      catch (Exception e)
      {
        return new ABTErrorHub("ABTObjectSet->remove",errorMessages.ERR_11,e);
      }
      // v can only be reference, error or null
      if (v == null)
        return new ABTErrorHub("ABTObjectSet->remove",errorMessages.ERR_12,"Index : " + index);
      else
        return my_Rule.remove(session,this,v,index);
   }


   /**
    * Remove the element pointed to by object and return the removed object
    * @param object The object to remove.
    * @return ABTObject removed or ABTError
    */
   public synchronized ABTValue remove(ABTUserSession session, ABTObject object )
   {
      if (! lock(session))
            return new ABTErrorHub("ABTObjectSet->remove",errorMessages.ERR_10,this);

      ABTOSet os = getActive(session,false);
      int index = os.indexOf(object);
      if (index < 0)
         return new ABTErrorHub("ABTObject->remove",errorMessages.ERR_13,object);
      return my_Rule.remove(session,this,object,index);
   }


  /**
   * Add an object after my last element or in sorted order.
   * @param object The object to add.
   * @return added object or ABTError
   */
   public synchronized ABTValue add( ABTUserSession session, ABTObject object )
   {
    if (! lock(session))
        return new ABTErrorHub("ABTObjectSet->add",errorMessages.ERR_10,this);

      return my_Rule.add(session,this,object,true);
   }

  /**
   * Add a new object
   * @return added object or ABTError
   */
   public synchronized ABTValue addNew(ABTUserSession session)
   {
    if (! lock(session))
        return new ABTErrorHub("ABTObjectSet->addNew",errorMessages.ERR_10,this);


  // create a new ID
    // instantiate will look through the rowset (based on the remote ID) and will either create a new row or
    // set the internal pointer to an existing row
       ABTID aid_ = my_Rule.getObjectSpace().createNewABTID();
       ABTValue v = my_Rule.getInstance(session,aid_,null); // create an instance of the object
       if (ABTError.isError(v))
           return v;

       ABTValue v2 =  my_Rule.add(session,this,(ABTObject)v,false);
       if (ABTError.isError(v2))
           return v2;
       aid_.setParent((ABTObject)v);
       return v2;
   }







//================================================================================
// General Info
//================================================================================


  /**
   * Return true if I contain no entries.
   */
   public boolean isEmpty(ABTUserSession session)
   {
      ABTOSet os = getActive(session,false);
      return os.isEmpty(true);
   }

  /**
   * Return the number of entries that I contain.
   */
   public int size(ABTUserSession session)
   {
      ABTOSet os = getActive(session,false);
      return os.size(true);
   }





  /**
   * Return the deleted flag for the object at index
   * @param index The index.
   * @return boolean true if deleted or element doesn't exist
   */
   public synchronized boolean isDeleted( ABTUserSession session, int index )
   {
      if (checkIndex(session,index))
      try
      {
            ABTOSet os = getActive(session,false);
            return ((ABTObject)(os.at(true,index))).isDeleted(session);
      }
      catch (Exception e)
      {
             return true;
      }
      return true;
   }

   /**
   * check whether a given index is valid
   * @param index to be checked
   * @return boolean true for valid, false otherwise
   */
   public boolean checkIndex(ABTUserSession session, int index)
   {
    if ((index >= 0) && (index < size(session)))
        return true;
    else
        return false;
   }

  /**
   * Return an Enumeration of my unsorted components.
   */
   public synchronized ABTObjectSetSortedEnumerator elements(ABTUserSession session)
   {
      return new ABTObjectSetSortedEnumerator(session,this,null);
   }


   /**
   * get an enumerator on the current sortorder
   */
   public synchronized ABTObjectSetSortedEnumerator sortedElements(ABTUserSession session,ABTSortOrderDefinition sortOrder)
   {
      return new ABTObjectSetSortedEnumerator(session,this,sortOrder);

   }


   /**
   * get an enumerator on the current sortorder
   */
   private synchronized ABTObjectSetSortedEnumerator sortedAllElements(ABTUserSession session,ABTSortOrderDefinition sortOrder)
   {
      return new ABTObjectSetSortedEnumerator(session,this,sortOrder,ABTOSet.DATA_ALL);

   }

   /**
   * get an enumerator on the current sortorder
   */
   private synchronized ABTObjectSetSortedEnumerator sortedDeletedElements(ABTUserSession session,ABTSortOrderDefinition sortOrder)
   {
      return new ABTObjectSetSortedEnumerator(session,this,sortOrder,ABTOSet.DATA_DELETED);

   }

   /**
   * Return true if I contain a particular object.
   * @param object The object in question.
   */
   public boolean contains( ABTUserSession session, ABTObject object )
   {
      ABTOSet os = getActive(session,false);
      return (os.indexOf(object) >= 0);
   }


   /**
   *  return the set of properties for this class
    */
   public ABTPropertySet getProperties()
   {
       return my_Rule.getProperties();
   }


//================================================================================
// Getters
//================================================================================
  /**
   * Return my last item.
   */
   public synchronized ABTValue back(ABTUserSession session)
   {
      return at(session,size(session)-1);
   }

  /**
   * Return my first item.
   * @return ABTValue existing value or ABTError
   */
   public synchronized ABTValue front(ABTUserSession session)
   {
      return at(session,0);
   }

  /**
   * Return the element at the specified index.
   * @param index The index.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
   public synchronized ABTValue at( ABTUserSession session, int index )
   {
      if (checkIndex(session,index))
         return my_Rule.getValue(session, this,index,false,null);
      else
        return new ABTErrorHub( "ABTObjectSet->at",
        errorMessages.ERR_14,"index : " + index + " - valid : 0.." + size(session));

   }


  /**
   * Add an object after my last element.
   * This function is a synonym for pushBack().
   * @param object The object to add.
   */
   public synchronized ABTValue addToSet(ABTUserSession session, ABTValue val,boolean existing)
   {
        return addToSet(session,val,existing, false);
   }

  /**
   * Add an object after my last element.
   * This function is a synonym for pushBack().
   * @param object The object to add.
   */
   public synchronized ABTValue addToSet(ABTUserSession session, ABTValue val,boolean existing, boolean dirty)
   {
    if (! lock(session))
        return new ABTErrorHub("ABTObjectSet->addToSet",errorMessages.ERR_10,this);
      // before anything else we check
      if (refAdapter != null)
      {
         ABTError er = refAdapter.notifyReferenceAdd(session, val,existing,dirty);
         if (er != null)
            return er;
      }
      ABTOSet os = getActive(session,true);
      os.add((ABTObject)(val));
      return val;
   }


  /**
   * reset the deleted remoteids
   */
   protected synchronized void setDeletedIDs(ABTUserSession session, ABTArray array)
   {
    if (! lock(session)) return;
      ABTOSet os = getActive(session,true);
      os.setDeletedIDs(array);
      return ;
   }


  /**
   * Remove  an object from my set
   * @param value The object to remove.
   * @param index the index to remove
   * @return the removed object
   */
   public synchronized ABTValue removeFromSet(ABTUserSession session,ABTValue value, int index)
   {
        return removeFromSet(session,value,index,false);
   }

  /**
   * Remove  an object from my set
   * @param value The object to remove.
   * @param index the index to remove
   * @return the removed object
   */
   public synchronized ABTValue removeFromSet(ABTUserSession session,ABTValue value, int index, boolean dirty)
   {
    if (! lock(session))
        return new ABTErrorHub("ABTObjectSet->addToSet",errorMessages.ERR_10,this);
      // before anything else we check
      if (refAdapter != null)
      {
         ABTError er = refAdapter.notifyReferenceRemove(session,value,dirty);
         if (er != null)
            return er;
      }
      ABTOSet os = getActive(session,true);
      try
      {
          os.remove ((ABTObject)value,((ABTObject)value).getRemoteID(session));
      }
      catch (Exception e)
      {
        return new ABTErrorHub("ABTObjectSet->removeFromSet",errorMessages.ERR_15,e);
      }
      return value;
   }

  /**
   * Clear the set
   * @return ABTBoolean(true)
   */
   public ABTValue clearSet(ABTUserSession session)
   {
        return clearSet(session,false);
   }
  /**
   * Clear the set
   * @return ABTBoolean(true)
   */
   public ABTValue clearSet(ABTUserSession session,boolean dirty)
   {
    if (! lock(session))
        return new ABTErrorHub("ABTObjectSet->clearSet",errorMessages.ERR_10,this);
      // before anything else we check
      if (refAdapter != null)
      {
         ABTError er = refAdapter.notifyReferenceClear(session, dirty);
         if (er != null)
            return er;
      }
      ABTOSet os = getActive(session,true);
      os.clear ();
      return ABTBoolean.True();
   }




  /**
   * Add an object after my last element.
   * This function is a synonym for pushBack().
   * @param object The object to add.
   */
   public synchronized ABTValue dirtyAdd(ABTUserSession session, ABTValue val,boolean existing)
   {
     return addToSet(session,val,existing,true);
   }

  /**
   * Remove  an object from my set
   * @param value The object to remove.
   * @param index the index to remove
   * @return the removed object
   */
   public synchronized ABTValue dirtyRemove(ABTUserSession session,ABTValue value, int index)
   {
      return removeFromSet(session,value,index,true);
   }

  /**
   * Clear the set
   * @return ABTBoolean(true)
   */
   public ABTValue dirtyClear(ABTUserSession session)
   {
      return clearSet(session,true);
   }


//================================================================================
// Internals
//================================================================================

  /**
   * Return the element at the specified index.
   * @param index The index.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
   protected ABTValue get(ABTUserSession session, int index )
   {
      ABTOSet os = getActive(session,false);
      return (ABTValue)os.at(true,index);
   }



   /*
   * return ABTArray-clone of my data
   * @return
   */
   protected ABTArray cloneData(ABTUserSession session,int type)
   {
      ABTOSet os = getActive(session,false);
      return os.cloneData(type);
   }



  /**
   * Not used in objectsets
   */
   public ABTError notifyReferenceAdd (ABTUserSession session, ABTProperty property, IABTReferenceSource child,  ABTValue newValue,boolean existing, boolean dirty)
   {
      return null;
   }



  /**
   * Not used in objectsets
   */
   public    ABTError notifyReferenceRemove (ABTUserSession session, ABTProperty property, IABTReferenceSource child,  ABTValue removedValue, boolean dirty)
   {
      return null;
   }



  /**
   * Not used in objectsets
   */
   public    ABTError  notifyReferenceClear (ABTUserSession session, ABTProperty property, IABTReferenceSource child, boolean dirty)
   {
      return null;
   }



  /**
   * Not used in objectsets
   */
   public    ABTError  notifyReferenceChildSet (ABTUserSession session, ABTProperty property, IABTReferenceSource childSet,  ABTObject child, ABTProperty childProperty, ABTValue oldValue, ABTValue newValue , boolean dirty)
   {
      return null;
   }


  /**
   * Notification of a set operation in one of the objects stored in this set
   * Invokes the rule.notifyReferenceSet method in my rule
   * @param child - the object currently referenced in this property
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
   public    ABTError  notifyReferenceSet (ABTUserSession session, ABTProperty property, IABTReferenceSource child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue, boolean dirty )
   {
      return my_Rule.notifyReferenceSet
      (  session,
         this, //ABTObjectSet parent,
         child,
         childProperty,
         oldValue,
         newValue ,
         dirty);
   }




  /**
   * Notification of a delete operation on an object referenced in this property
   * @param property - my property on which I am listening
   * @param child - the object currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   public ABTError notifyReferenceDelete (ABTUserSession session, ABTProperty property, IABTReferenceSource child, boolean dirty)
   {
      return my_Rule.notifyReferenceDelete
      (  session,
         this, //ABTObjectSet parent,
         child,
         dirty);
   }





   public void addReference(ABTUserSession session, IABTReferenceListener listener,ABTProperty listenerProperty,ABTProperty myProperty)
   {
      if (refAdapter == null)
         refAdapter = new ABTReferenceAdapter(this);
      refAdapter.addReference(session, listener, listenerProperty,myProperty);
   }

   public void removeReference(ABTUserSession session, IABTReferenceListener listener,ABTProperty myProperty)
   {
      if (refAdapter == null) return;
      refAdapter.removeReference(session, listener,myProperty);
      if (refAdapter.countListeners() == 0)
         refAdapter = null;

   }
   public void removeReference(ABTUserSession session, IABTReferenceListener listener)
   {
      if (refAdapter == null) return;
      refAdapter.removeReference(session, listener);
      if (refAdapter.countListeners() == 0)
         refAdapter = null;
   }

   public static ABTValue getSubset(ABTUserSession session,ABTObjectSet originalSet,String criteria)
   {
      ABTArray placeholders = new ABTArray();
      VisitorExpression treeBuilder = new VisitorExpression( session,placeholders );
      ABTValue parsedTree;
      try
      {
        parsedTree = treeBuilder.parse( criteria );
      }
      catch( Exception e )
      {
        return new ABTErrorHub( "ABTObjectSet->select",
        errorMessages.ERR_16,e);
      }

      ABTObjectSet resultSet = new ABTObjectSet();
      resultSet.instantiate(session, originalSet.getRule(),null);
      Enumeration originalIterator = originalSet.elements(session);
      return ABTObjectSet.testSubset(session, originalIterator,resultSet,placeholders,parsedTree);
   }

   public static ABTValue testSubset(ABTUserSession session, Enumeration originalIterator, ABTObjectSet resultSet,ABTArray placeholders,ABTValue parsedTree)
   {
      while( originalIterator.hasMoreElements() )
      {
         ABTValue value = (ABTValue)originalIterator.nextElement();
         if( !ABTError.isError( value ) )
         {
            //set the placeholder

            if (placeholders.size() > 0)
                placeholders.put( 0,(ABTObject)value );
            else
                placeholders.add( (ABTObject)value );

            //test against parseTree
            if (parsedTree.booleanValue())
               // Changed from add to dirty add ( JSE 8/3/98 ) because onAdd can
               // prohibit adding of an element to ANY objectSet ( oops! )
               resultSet.dirtyAdd(session,(ABTObject)value,true);

         }
      }
      return resultSet;

   }
      /**
   * Return an objectset containing all elements
   * where the provided criteria computes to true
   * @param criteria String with SQL-like sysntax
   * @return newly created Objectset with same rule set or ABTError
   */
   public ABTValue select( ABTUserSession session,String criteria)
   {
      return ABTObjectSet.getSubset(session,this,criteria);
   }









}