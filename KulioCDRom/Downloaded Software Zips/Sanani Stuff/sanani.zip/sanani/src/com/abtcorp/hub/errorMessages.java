package com.abtcorp.hub;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;

public class errorMessages extends ListResourceBundle
{
public Object[][] getContents() {
			return contents; 
}


public static final String Package = "com.abtcorp.hub".intern();
public static final ABTErrorCode ERR_0 = new ABTErrorCode(Package, "100");
public static final ABTErrorCode ERR_1 = new ABTErrorCode(Package, "101");
public static final ABTErrorCode ERR_2 = new ABTErrorCode(Package, "102");
public static final ABTErrorCode ERR_3 = new ABTErrorCode(Package, "103");
public static final ABTErrorCode ERR_4 = new ABTErrorCode(Package, "104");
public static final ABTErrorCode ERR_5 = new ABTErrorCode(Package, "105");
public static final ABTErrorCode ERR_6 = new ABTErrorCode(Package, "106");
public static final ABTErrorCode ERR_7 = new ABTErrorCode(Package, "107");
public static final ABTErrorCode ERR_8 = new ABTErrorCode(Package, "108");
public static final ABTErrorCode ERR_9 = new ABTErrorCode(Package, "109");
public static final ABTErrorCode ERR_10 = new ABTErrorCode(Package, "110");
public static final ABTErrorCode ERR_11 = new ABTErrorCode(Package, "111");
public static final ABTErrorCode ERR_12 = new ABTErrorCode(Package, "112");
public static final ABTErrorCode ERR_13 = new ABTErrorCode(Package, "113");
public static final ABTErrorCode ERR_14 = new ABTErrorCode(Package, "114");
public static final ABTErrorCode ERR_15 = new ABTErrorCode(Package, "115");
public static final ABTErrorCode ERR_16 = new ABTErrorCode(Package, "116");
public static final ABTErrorCode ERR_17 = new ABTErrorCode(Package, "117");
public static final ABTErrorCode ERR_18 = new ABTErrorCode(Package, "118");
public static final ABTErrorCode ERR_19 = new ABTErrorCode(Package, "119");
public static final ABTErrorCode ERR_20 = new ABTErrorCode(Package, "120");
public static final ABTErrorCode ERR_21 = new ABTErrorCode(Package, "121");
public static final ABTErrorCode ERR_22 = new ABTErrorCode(Package, "122");
public static final ABTErrorCode ERR_23 = new ABTErrorCode(Package, "123");
public static final ABTErrorCode ERR_24 = new ABTErrorCode(Package, "124");
public static final ABTErrorCode ERR_25 = new ABTErrorCode(Package, "125");
public static final ABTErrorCode ERR_26 = new ABTErrorCode(Package, "126");
public static final ABTErrorCode ERR_27 = new ABTErrorCode(Package, "127");
public static final ABTErrorCode ERR_28 = new ABTErrorCode(Package, "128");
public static final ABTErrorCode ERR_29 = new ABTErrorCode(Package, "129");
public static final ABTErrorCode ERR_30 = new ABTErrorCode(Package, "130");
public static final ABTErrorCode ERR_31 = new ABTErrorCode(Package, "131");
public static final ABTErrorCode ERR_32 = new ABTErrorCode(Package, "132");
public static final ABTErrorCode ERR_33 = new ABTErrorCode(Package, "133");
public static final ABTErrorCode ERR_34 = new ABTErrorCode(Package, "134");
public static final ABTErrorCode ERR_35 = new ABTErrorCode(Package, "135");
public static final ABTErrorCode ERR_36 = new ABTErrorCode(Package, "136");
public static final ABTErrorCode ERR_37 = new ABTErrorCode(Package, "137");
public static final ABTErrorCode ERR_38 = new ABTErrorCode(Package, "138");
public static final ABTErrorCode ERR_39 = new ABTErrorCode(Package, "139");
public static final ABTErrorCode ERR_40 = new ABTErrorCode(Package, "140");
public static final ABTErrorCode ERR_41 = new ABTErrorCode(Package, "141");
public static final ABTErrorCode ERR_42 = new ABTErrorCode(Package, "142");
public static final ABTErrorCode ERR_43 = new ABTErrorCode(Package, "143");
public static final ABTErrorCode ERR_44 = new ABTErrorCode(Package, "144");
public static final ABTErrorCode ERR_45 = new ABTErrorCode(Package, "145");
public static final ABTErrorCode ERR_46 = new ABTErrorCode(Package, "146");
public static final ABTErrorCode ERR_47 = new ABTErrorCode(Package, "147");
public static final ABTErrorCode ERR_48 = new ABTErrorCode(Package, "148");
public static final ABTErrorCode ERR_49 = new ABTErrorCode(Package, "149");
public static final ABTErrorCode ERR_METHOD_NOT_SUPPORTED = new ABTErrorCode(Package, "150");



static final Object[][] contents = {
{ERR_0.getCode(),"Unsupported Object"},
{ERR_1.getCode(),"Unsupported Action for ABTObjectSet"},
{ERR_2.getCode(),"Unsupported Action for ABTObject"},
{ERR_3.getCode(),"object not in instance list"},
{ERR_4.getCode(),"Invalid Functioncall"},
{ERR_5.getCode(),"Object Inaccessible"},
{ERR_6.getCode(),"Invalid property"},
{ERR_7.getCode(),"Unknown Property"},
{ERR_8.getCode(),"Invalid Value for Property"},
{ERR_9.getCode(),"set values failed"},
{ERR_10.getCode(),"Record locked"},
{ERR_11.getCode(),"Index not found"},
{ERR_12.getCode(),"Invalid element"},
{ERR_13.getCode(),"Object not found"},
{ERR_14.getCode(),"Index out of bounds"},
{ERR_15.getCode(),"Invalid Value passed"},
{ERR_16.getCode(),"Parsing failed"},
{ERR_17.getCode(),"No such element"},
{ERR_18.getCode(),"invalid argument"},
{ERR_19.getCode(),"unexpected null return"},
{ERR_20.getCode(),"unexpected object type"},
{ERR_21.getCode(),"class not found"},
{ERR_22.getCode(),"object not in instance list"},
{ERR_23.getCode(),"Key not found"},
{ERR_24.getCode(),"Property already exists"},
{ERR_25.getCode(),"Existing properties"},
{ERR_26.getCode(),"parameterIndex_ out of bounds"},
{ERR_27.getCode(),"Invalid Property Type"},
{ERR_28.getCode(),"Invalid Reference Type"},
{ERR_29.getCode(),"Invalid property Rule"},
{ERR_30.getCode(),"Unable to instatiate row"},
{ERR_31.getCode(),"Unable to instatiate object"},
{ERR_32.getCode(),"Invalid index or property name "},
{ERR_33.getCode(),"Property not found"},
{ERR_34.getCode(),"Invalid type"},
{ERR_35.getCode(),"Overwrite detected"},
{ERR_36.getCode(),"Set Disallowed"},
{ERR_37.getCode(),"object not in instance list"},
{ERR_38.getCode(),"initial field is not an object reference"},
{ERR_39.getCode(),"Error creating new Thread"},
{ERR_40.getCode(),"Too many pending transactions"},
{ERR_41.getCode(),"Property not visible"},
{ERR_42.getCode(),"Property not updateable"},
{ERR_43.getCode(),"Illegal Property Value Null"},
{ERR_44.getCode(),"No pending transactions"},
{ERR_45.getCode(),"Unable to convert data type"},
{ERR_46.getCode(),"Unable to load property"},
{ERR_47.getCode(),"Unable to load rule"},
{ERR_48.getCode(),"Object already exists in Objectset"},
{ERR_49.getCode(),"Unexpected Exception"},
{ERR_METHOD_NOT_SUPPORTED.getCode(),"Method not supported"},

 };
}