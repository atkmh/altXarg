package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileConstraint.java 08/11/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-11-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTPMRuleConstants;


import  com.abtcorp.api.local.ABTHashTable;

import java.util.Hashtable;

//DEBUG
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTObjectSetIDList;
import com.abtcorp.io.client.ABTFileHelper;

/**
 *  ABTIOPMWFileConstraint is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileConstraint fc = new ABTIOPMWFileConstraint(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileConstraint extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       constraintVector_ = null;
     
//====================================================================================
// Constructors
//====================================================================================
               
/**
 *    ABTIOPMWFileConstraint constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileConstraint(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_              = OBJ_CONSTRAINT;
      constraintVector_  = new Vector();
   }

   
//====================================================================================
// Populate  Constraint from the Intermediate Hash Table
//====================================================================================

/**
 * Populate  Constraint object from the Intermediate Hash Table to the sapce
 * @param Hashtable parms,
 * @return an ABTValue the team object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(Hashtable parms) throws ABTException 
   {
    ABTObjectSetIDList constraintIDs   = null;    
    IABTObject         project   = null;
    IABTObject         targetObj = null;
    Object             object    = null;
        
    try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
            
        //Get the Target object which this constraint belongs to   
        object = parms.get(TARGET_OBJ);
        if (object instanceof IABTObject) 
            targetObj  = (IABTObject)object;
                     
        //Get the Constraint IDs 
        object = parms.get(CONSTRAINT_ID);
        if (object instanceof ABTObjectSetIDList) 
            constraintIDs  = (ABTObjectSetIDList)object;
            
        Enumeration itID = constraintIDs.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);
            reqparms.put(TARGET_OBJ, targetObj);
            reqparms.put(CONSTRAINT_ID,(IABTLocalID)itID.nextElement());
            
            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }      
    
   }
/**
 * Create a new object in the object space and initialize it with  appropriate values 
 * @param Hashtable parms 
 * @return ABTValue the newly created note
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {
   
      IABTLocalID constraintID   = null;      
      IABTObject project         = null;
      IABTObject targetObj       = null;
      Object     object          = null;
      IABTObject constraintObj   = null;
      
      //Get the Constraint ID 
      object = null;
      object = parms.get(CONSTRAINT_ID);
      if (object instanceof IABTLocalID) 
         constraintID  = (IABTLocalID)object;
            
      //Check if constraint has already been created
        object = null;
        object = driver_.lookupTableGet(constraintID);
        if ( object!= null && object instanceof IABTObject)
        {
         // TO DO UPDATE
           ;
        }
        else
        {
          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object; 
          
          //Get the Target object which this constraint belongs to 
          object = null;
          object = parms.get(TARGET_OBJ);
          if (object instanceof IABTObject) 
             targetObj  = (IABTObject)object;
                       
          // Get the array of value associated with constraint
          IABTArray   constraintArr  = null;
          object = null;
          
          object = driver_.intermediateTableGet(constraintID);
          if (object instanceof IABTArray)
            constraintArr = (IABTArray) object;
          
          //Get the property set associated with the constraint
          IABTPropertySet propSet = null;
          propSet = getProperties(type_); 
          
          // Get the required parameter to create constraint Object
          IABTHashTable  reqparms       = (getSpace()).newABTHashTable(); 
          reqparms.putItemByString(OFD_TASK, (ABTValue)targetObj);      

          //Get constraint's Remote ID
          ABTValue  val = null;      
                    
          val = getHashValue(constraintArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            constraintObj = createObject(type_,(ABTRemoteID)val, reqparms);    
          else if (ABTValue.isNull(val))
            constraintObj = createObject(type_,(ABTRemoteID)null, reqparms);   
          else
            new ABTException(" WRONG TYPE CAST");

          //Set constraint's scalar values.  
          setScalarValues(propSet, constraintArr, constraintObj);
          
         
    }
    driver_.lookupTablePut(constraintID, constraintObj);   
    return (ABTValue)constraintObj;


   }      



//====================================================================================
// Save Constraint to an Intermediate Hash Table
//====================================================================================

/**
 * Saves constraint objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
      IABTObject project = null;
        
        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
    
        if (project == null)
            throw new ABTException("The current project is null.");

        IABTObjectSet taskOs = getObjectSet(project, OFD_ALLTASKS);

        for (int j =0; j < size(taskOs); j++)
        {
            IABTObject     taskObj       = (IABTObject)at(taskOs, j);
            IABTObjectSet  constraintOs  =  getObjectSet(taskObj, OFD_CONSTRAINTS);
            
            for (int i = 0; i < size(constraintOs); i++)
            {       
                IABTObject constraintObj = (IABTObject)at(constraintOs, i);
                // Make sure the object is of type constraint
                if (!constraintObj.getObjectType().equals(type_))
                 processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

                // Load the values of the properties associated with the constraint in an array
                IABTArray arr = null;
                arr = loadObjectPropertyValues(constraintObj);
                if (arr==null)
                    throw new ABTException("The arr of constraint values is null.");

                //Get the Intermediate Hash Table
                if (driver_.isIntermediateTableNull())
                    throw new ABTException("The Intermediate Hash Table is null.");

                IABTLocalID constraintId = constraintObj.getID();
                if (constraintId == null)
                    throw new ABTException("constraint ID is null.");

                
                if (( driver_.intermediateTablePut(constraintId, arr)) != null)
                    throw new ABTException("The constraint ID already exist.");

                //DEBUG
                constraintVector_.addElement(constraintId);
            }
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


}