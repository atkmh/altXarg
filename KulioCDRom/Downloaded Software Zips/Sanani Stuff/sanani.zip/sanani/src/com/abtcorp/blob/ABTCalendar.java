package com.abtcorp.blob;

import com.abtcorp.core.*;
import java.text.*;

public final class ABTCalendar extends ABTValue
{
   private static final long serialVersionUID = 6415232765465150317L;
	
	// TODO: We should read this from a properties file

	static final ABTShiftList default_[] = {
	   ABTShiftList.HOLIDAY,   // SUNDAY
	   ABTShiftList.WORK,      // MONDAY
	   ABTShiftList.WORK,      // TUESDAY
	   ABTShiftList.WORK,      // WEDNESDAY
	   ABTShiftList.WORK,      // THURSDAY
	   ABTShiftList.WORK,      // FRIDAY
	   ABTShiftList.HOLIDAY    // SATURDAY
   };

   private ABTCalendar      parent_     = null;
	private ABTShiftList     workweek_[] = new ABTShiftList[7];
	private ABTExceptionList exceptions_ = new ABTExceptionList();

	public ABTCalendar() {}

   public final ABTCalendar      getParent()                   {return parent_;}
	public final void	            setParent(ABTCalendar parent) {parent_ = parent;}
	public final ABTExceptionList	getExceptions()               {return exceptions_;}

	public final int getWorkweek()
	{
   	int result = 0;

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++)
   		if (isWorkday(day)) result |= (1 << (day-1));

   	return result;
	}

	public final void	setWorkweek(int workweek, ABTShiftList shifts)
	{
   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++)
   		workweek_[day-1] = (workweek & (1 << (day-1))) != 0 ? shifts : ABTShiftList.HOLIDAY;
	}

	public final void	setWorkweek(int workweek) {setWorkweek(workweek, ABTShiftList.WORK);}

	final ABTShiftList getException(ABTDate date, boolean composite)
	{
   	if (date == null) return null;

   	ABTShiftList shifts = exceptions_.getShifts(date);

   	if (shifts != null) return shifts;

   	if (! composite || parent_ == null) return null;

   	return parent_.getException(date, composite);
	}

	final ABTExceptionList getExceptions(ABTDate start, ABTDate finish, boolean composite)
	{
   	ABTExceptionList result = new ABTExceptionList();

   	if (composite && parent_ != null) result.setExceptions(parent_.getExceptions(start, finish, composite));

   	result.setExceptions(exceptions_.getExceptions(start, finish));

   	return result;
	}

	public final ABTShiftList getShifts(int day, boolean composite)
	{
   	if (! composite || workweek_[day-1] != null) return workweek_[day-1];

   	if (parent_ == null) return default_[day-1];

   	return parent_.getShifts(day, composite);
	}

	public final ABTShiftList getShifts(ABTDate date, boolean composite)
	{
   	ABTShiftList result = getException(date, composite); if (result != null) return result;

   	return getShifts(date.getDayOfWeek(), composite);
	}

	public final void	resetShifts(int day)                    {workweek_[day-1] = null;}
	public final void	setShifts(int day, ABTShiftList shifts) {workweek_[day-1] = shifts;}

	public final void	resetShifts(ABTDate start, ABTDate finish)						  {exceptions_.resetShifts(start, finish);}
	public final void	setShifts(ABTDate start, ABTDate finish, ABTShiftList shifts) {exceptions_.setShifts(start, finish, shifts);}

	public final void	resetShifts(ABTDate date)						   {resetShifts(date, date);}
	public final void	setShifts(ABTDate date, ABTShiftList shifts) {setShifts(date, date, shifts);}

	public final boolean	isException(int day)                         {return workweek_[day-1]              != null;}
	public final boolean	isException(ABTDate date, boolean composite)	{return getException(date, composite) != null;}

	public final boolean isWorkday(int day)      {return getShifts(day,  true).isWorkday();}
	public final boolean isWorkday(ABTDate date) {return getShifts(date, true).isWorkday();}

	public final ABTDate nextWorkday(ABTDate date)
	{
   	if (date == null) return date;

   	while (! isWorkday(date)) date = date.next();

   	return date;
	}

	public final ABTDate prevWorkday(ABTDate date)
	{
   	if (date == null) return date;

   	while (! isWorkday(date)) date = date.prev();

   	return date;
	}

	public final ABTDate nextHoliday(ABTDate date)
	{
   	if (date == null) return date;

   	while (isWorkday(date)) date = date.next();

   	return date;
	}

	public final ABTDate prevHoliday(ABTDate date)
	{
   	if (date == null) return date;

   	while (isWorkday(date)) date = date.prev();

   	return date;
	}

	public final ABTDate addWorkday(ABTDate date, int days)
	{
   	if (date == null) return date;

   	for (int i = 0; i < days; i++) date = nextWorkday(date).next();

   	return date;
	}

	public final ABTDate subWorkday(ABTDate date, int days)
	{
   	if (date == null) return date;

   	for (int i = 0; i < days; i++) date = prevWorkday(date).prev();

   	return date;
	}

	public final int diffWorkday(ABTDate start, ABTDate finish)
	{
   	if (start == null || finish == null) return 0;

   	int result = 0;

   	for (ABTDate date = start; date.compareTo(finish) <= 0; date = date.next()) if (isWorkday(date)) result++;

   	return result;
	}

	public final boolean isWorktime(ABTTime time)
	{
   	if (time == null) return false;

   	ABTDate date = new ABTDate(time, false);

   	int timeofday = ABTTime.diff(date, time);

   	return getShifts(date, true).isWorktime(timeofday);
	}

	public final ABTTime	nextWorktime(ABTTime time)
	{
   	if (time == null) return time;

   	ABTDate date = new ABTDate(time, false);

   	int timeofday = ABTTime.diff(date, time);

   	while (true) {
   		ABTShiftList shifts = getShifts(date, true);

   		timeofday = shifts.nextWorktime(timeofday);

   		if (timeofday < ABTTime.SecondsPerDay) break;

   		date = date.next(); timeofday = 0;
   	}

   	return new ABTTime(date, timeofday);
	}

	public final ABTTime	prevWorktime(ABTTime time)
	{
   	if (time == null) return time;

   	ABTDate date = new ABTDate(time, true);

   	int timeofday = ABTTime.diff(date, time);

   	while (true) {
   		ABTShiftList shifts = getShifts(date, true);

   		timeofday = shifts.prevWorktime(timeofday);

   		if (timeofday > 0) break;

   		date = date.prev(); timeofday = ABTTime.SecondsPerDay;
   	}

   	return new ABTTime(date, timeofday);
	}

	public final ABTTime	nextHolitime(ABTTime time)
	{
   	if (time == null) return time;

   	ABTDate date = new ABTDate(time, false);

   	int timeofday = ABTTime.diff(date, time);

   	while (true) {
   		ABTShiftList shifts = getShifts(date, true);

   		timeofday = shifts.nextHolitime(timeofday);

   		if (timeofday < ABTTime.SecondsPerDay) break;

   		date = date.next(); timeofday = 0;
   	}

   	return new ABTTime(date, timeofday);
	}

	public final ABTTime	prevHolitime(ABTTime time)
	{
   	if (time == null) return time;

   	ABTDate date = new ABTDate(time, true);

   	int timeofday = ABTTime.diff(date, time);

   	while (true) {
   		ABTShiftList shifts = getShifts(date, true);

   		timeofday = shifts.prevHolitime(timeofday);

   		if (timeofday > 0) break;

   		date = date.prev(); timeofday = ABTTime.SecondsPerDay;
   	}

   	return new ABTTime(date, timeofday);
	}

	public final ABTTime	addWorktime(ABTTime time, int seconds)
	{
   	if (time == null) return time;

   	ABTDate date = new ABTDate(time, false);

   	int timeofday = ABTTime.diff(date, time);

   	int parameter[] = {seconds};

   	while (true) {
   		ABTShiftList shifts = getShifts(date, true);

   		timeofday = shifts.addWorktime(timeofday, parameter);

   		if (parameter[0] == 0 && timeofday < ABTTime.SecondsPerDay) break;

   		date = date.next(); timeofday = 0;
   	}

   	return new ABTTime(date, timeofday);
	}

	public final ABTTime	subWorktime(ABTTime time, int seconds)
	{
   	if (time == null) return time;

   	ABTDate date = new ABTDate(time, true);

   	int timeofday = ABTTime.diff(date, time);

   	int parameter[] = {seconds};

   	while (true) {
   		ABTShiftList shifts = getShifts(date, true);

   		timeofday = shifts.subWorktime(timeofday, parameter);

   		if (parameter[0] == 0 && timeofday > 0) break;

   		date = date.prev(); timeofday = ABTTime.SecondsPerDay;
   	}

   	return new ABTTime(date, timeofday);
	}

	public final int diffWorktime(ABTTime time1, ABTTime time2)
	{
   	if (time1 == null || time2 == null || time1.compareTo(time2) >= 0) return 0;

   	int result = 0;

   	ABTDate date1 = new ABTDate(time1, false); int timeofday1 = ABTTime.diff(date1, time1);
   	ABTDate date2 = new ABTDate(time2, true);  int timeofday2 = ABTTime.diff(date2, time2);

   	for (ABTDate date = date1; date.compareTo(date2) <= 0; date = date.next()) {
   		ABTShiftList shifts = getShifts(date, true);

   		int start  = 0;				          if (date.equals(date1)) start  = timeofday1;
   		int finish = ABTTime.SecondsPerDay;  if (date.equals(date2)) finish = timeofday2;

   		result += shifts.diffWorktime(start, finish);
   	}

   	return result;
	}

	public final ABTTime	startWorktime(ABTDate date)
	{
   	if (date == null) return null;

      int timeofday = getShifts(date, true).nextWorktime(0);

   	if (timeofday < ABTTime.SecondsPerDay) return new ABTTime(date, timeofday);

   	return null;
	}

	public final ABTTime	finishWorktime(ABTDate date)
	{
   	if (date == null) return null;

   	int timeofday = getShifts(date, true).prevWorktime(ABTTime.SecondsPerDay);

   	if (timeofday > 0) return new ABTTime(date, timeofday);

   	return null;
	}

	final ABTCalendar flat(ABTDate start, ABTDate finish)
	{
   	ABTCalendar result = new ABTCalendar();

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++)
   		result.workweek_[day-1] = getShifts(day, true);

   	result.exceptions_ = getExceptions(start, finish, true);

   	return result;
	}

	final ABTCalendar flat() {return flat(null, null);}

	final boolean merge(ABTCalendar calendar, ABTDate start, ABTDate finish)
	{
   	if (this == calendar) return true;

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++)
   		if (! getShifts(day, true).equals(calendar.getShifts(day, true))) return false;

   	resetShifts(start, finish);

   	exceptions_.setExceptions(calendar.getExceptions(start, finish, true));

   	return true;
	}

	public final boolean	equals(ABTCalendar calendar, ABTDate start, ABTDate finish)
	{
   	if (this == calendar) return true;

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++)
   		if (! getShifts(day, true).equals(calendar.getShifts(day, true))) return false;

   	return getExceptions(start, finish, true).equals(calendar.getExceptions(start, finish, true));
	}

	public final boolean	equals(ABTCalendar calendar) {return equals(calendar, null, null);}

   public final void optimize()
   {
  	   if (parent_ != null) parent_.optimize();

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++) {
       	ABTShiftList shifts = workweek_[day-1];

       	if (shifts != null) shifts.optimize();
  	   }

  	   exceptions_.optimize();
   }

	public final double getHoursPerDay()
	{
   	int max = 0;

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++) {
   		int duration = getShifts(day, true).getDuration();

   		if (duration > max) max = duration;
   	}

   	return (double)max / 3600;
	}

	public final double getHoursPerWeek()
	{
   	int sum = 0;

   	for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++)
   		sum += getShifts(day, true).getDuration();

   	return (double)sum / 3600;
	}

	public final double getHoursPerMonth()
	{
   	return getHoursPerYear() / 12;
   }

	public final double getHoursPerYear()
	{
   	return 365.25 / 7 * getHoursPerWeek();
   }

   public String toString()
   {
	   StringBuffer buffer = new StringBuffer();

      buffer.append("ABTCalendar{");

	   if (parent_ != null) buffer.append("parent:" + parent_ + ", ");

	   String weekdays[] = (new DateFormatSymbols()).getWeekdays();
	   
	   boolean first = true;

      for (int day = ABTDate.SUNDAY; day <= ABTDate.SATURDAY; day++) {
         ABTShiftList shifts = workweek_[day-1]; if (shifts == null) continue;

         if (! first) buffer.append(", ");

         buffer.append(weekdays[day] + ":" + shifts);

         first = false;
      }

      if (first) buffer.append("default");

      if (exceptions_.size() > 0) buffer.append(", " + exceptions_);

      buffer.append("}");

   	return buffer.toString();
	}
   public ABTValue eval() {return (ABTValue)clone();}
}