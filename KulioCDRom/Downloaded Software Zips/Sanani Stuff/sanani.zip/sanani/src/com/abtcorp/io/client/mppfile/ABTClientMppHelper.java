package com.abtcorp.io.client.mppfile;


/**
 * ABTClientMppHelper.java 08/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 08-27-98    ATW             Initial Implementation
  * 09-18-98    ATW             Commented.
  *
  */

/**
 *  ABTClientMppHelper is the base class for all the helper classes that populate from and
 *  save data to MPP files.
 *
 *
 * @version		1.0
 * @author		A. Waller
 * @see			ABTClientDriver
 */

import com.abtcorp.io.client.ABTClientHelper;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;


public abstract class ABTClientMppHelper extends ABTClientHelper implements IABTPMRuleConstants
{
    protected boolean               forceAddNew_;
    protected ABTClientMppDriver    driver_;

/**
 *  Create an ABTClientMppHelper that is not associated with an IABTObjectSpace or ABTDriver.
 *  Associating an object space with this class will be deferred until later.
 *
 */
    public ABTClientMppHelper() { /* implicit call to super() here */ }

/**
 *  Create an ABTClientMppHelper that is associated with an IABTObjectSpace.
 *
 */
    public ABTClientMppHelper( IABTObjectSpace space )
    {
        super( space );
    }

/**
 *  Create an ABTClientMppHelper that is associated with an IABTObjectSpace.
 *  and an ABTClientMppDriver.
 *
 */
    public ABTClientMppHelper( IABTObjectSpace space, ABTClientMppDriver driver )
    {
        super( space );
        driver_ = driver;
    }

 /**
 *  Populate an object space with an object (or objects) as appropriate to the
 *  particular helper
 *  @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *  helper
 *  @return an ABTValue which, if successful is a reference to the object created or updated
 *  in the object space.  Otherwise, an ABTError.
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public ABTValue populate( ABTArray parms ) throws ABTException { return null; }

/**
 *  Populate an object space with an object (or objects) as appropriate to the
 *  particular helper
 *  @return an ABTValue which, if successful is a reference to the object created or updated
 *  in the object space.  Otherwise, an ABTError.
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    protected ABTValue populate() throws ABTException { return null; }

/**
 *  Save an object (or objects) from the object space as appropriate to the
 *  particular helper
 *  @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *  helper
 *  @return void
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void save( ABTArray parms ) throws ABTException { };

/**
 *  Set the object space reference.
 *  @param space is a reference to the object space
 *
 */
    public void setSpace(IABTObjectSpace space) { super.setSpace( space ); }

/**
 *  Get the object space reference.
 *
 */
    public IABTObjectSpace getSpace() { return super.getSpace(); }

/**
 *  Check for errors after an object space get/setValue(), object set operation, etc.
 *  @param value is the ABTValue returned from the invocation of an object space
 *  or ABTObject method.
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void checkError( ABTValue value ) throws ABTException
    {
        super.checkError( value );
    }

/**
 *  Check for errors after an object space get/setValue(), object set operation,
 *  etc.
 *  @param value is the ABTValue returned from the invocation of an object space
 *   or ABTObject method.
 *  @param propname is the property name being get/set
 *  @param settingvalue is the value being get/set
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void checkError( ABTValue value, String propname, ABTValue settingvalue ) throws ABTException
    {
        super.checkError( value, propname, settingvalue );
    }

/**
 *  Check for errors after an object space get/setValue(), object set operation,
 *  etc.
 *  @param value is the ABTValue returned from the invocation of an object space
 *  or ABTObject method.
 *  @param propindex is the property index of the property being get/set
 *  @param settingvalue is the value being get/set
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void checkError( ABTValue value, int propindex, ABTValue settingvalue ) throws ABTException
    {
        super.checkError( value, propindex, settingvalue );
    }

/**
 *  Set a property value into an ABTObject.
 *  @param object the IABTObject whose property is being set
 *  @param propname the String property name being set
 *  @param value the ABTValue being set
 *  @return an ABTValue which is null if successful, an ABTError if not
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public ABTValue setValue( IABTObject object, String propname, ABTValue value ) throws ABTException
    {
        return super.setValue( object, propname, value );
    }


/**
 *  Get a property value from an IABTObject.
 *  @param object the IABTObject whose property is being gotten
 *  @param propname the String property name whose value is being gotten
 *  @return an ABTValue which is the property's value
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public ABTValue getValue( IABTObject object, String propname ) throws ABTException
    {
        return super.getValue( object, propname );
    }

/**
 *  Add an existing IABTObject to an object set.
 *  @param set the IABTObjectSet to which an IABTObject will be added
 *  @param object the IABTObject which will be added to the indicated object set
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void addListMember( IABTObjectSet set, IABTObject object ) throws ABTException
    {
        super.addListMember( set, object );
    }

/**
 *  Add a new IABTObject to an object set.  The IABTObject is created first, and
 *  then added to the object set.  The type of the IABTObject to be created will
 *  be the same type as that of the object set.  The IABTObject is created without
 *  an ABTRemoteID, so if the object needs an ABTRemoteID, it will need to be added
 *  later.
 *  @param set the IABTObjectSet to which an IABTObject will be added after that IABTObject
 *  has been created
 *  @return the IABTObject which was created and then added to the object set
 *  @exception an ABTException if an unrecoverable error occurs.
 *
 */
    public IABTObject addNew( IABTObjectSet set ) throws ABTException
    {
        return super.addNew( set );
    }

/**
 *  Remove an existing IABTObject from an object set.  The IABTObject is not deleted.
 *  @param set the IABTObjectSet from which an IABTObject will be removed
 *  @param object the IABTObject to be removed from the object set
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void removeListMember( IABTObjectSet set, IABTObject object ) throws ABTException
    {
        super.removeListMember( set, object );
    }

/**
 *   Create a new IABTObject.  The new IABTObject will be created without an
 *  ABTRemoteID.
 *  @param type a String representing the object which will be created
 *  @param params an IABTHashtable of parameters which may be used by rules
 *  processing in the creation of the object and in the placement of the object
 *  into an object model hierarcy.
 *  @return the IABTObject which was newly created
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public IABTObject createObject( String type, IABTHashTable params ) throws ABTException
    {
        return super.createObject( type, params );
    }

/**
 *  Create a new IABTObject.
 *  @param type a String representing the IABTObject which will be created
 *  @param id the ABTRemoteID to be assigned to the new object
 *  @param params an IABTHashtable of parameters which may be used by rules
 *  processing in the creation of the object and in the placement of the object
 *  into an object model hierarcy.
 *  @return the IABTObject which was newly created
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public IABTObject createObject( String type, ABTRemoteID id, IABTHashTable params ) throws ABTException
    {
        return super.createObject( type, id, params );
    }

/**
 *  Get an object set from an IABTObject.
 *  @param object the IABTObject from which the object set will be gotten
 *  @param objectSetName the String property name of the object set to be gotten from the object
 *  @return the requested IABTObjectSet
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public IABTObjectSet getObjectSet( IABTObject object, String objectSetName ) throws ABTException
    {
        return super.getObjectSet( object, objectSetName );
    }

/**
 *  Get an IABTObject from another IABTObject.
 *  @param object the IABTObject from which the object will be gotten
 *  @param objectName the String property name of the object to be gotten
 *  @return the requested IABTObject
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public IABTObject getObject( IABTObject object, String objectName ) throws ABTException
    {
        return super.getObject( object, objectName );
    }

/**
 *  Add object to an object set.  The semantics of this method are similar to addListMember().
 *  @param oSet the IABTObjectSet to add to.
 *  @param object the IABTObject to be added to the object set.
 *  @return ABTValue the value of the new object set.
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public void add(IABTObjectSet oSet, IABTObject object) throws ABTException
    {
        super.add( oSet, object );
    }

/**
 *  Retrieve an object in the specified position within an object set.
 *  @param oSet the IABTObjectSet that contains the object.
 *  @param index the int position of the object to be retrieved.
 *  @return the ABTValue of the retrieved object.
 *  @exception ABTException if an unrecoverable error occurs.
 */
    public IABTObject at(IABTObjectSet oSet, int index) throws ABTException
    {
        return super.at( oSet, index );
    }

/**
 *  Return the size of an object set.
 *  @param oSet: the IABTObjectSet to get the size of
 *  @return an int which is the size of the object set.
 *  @exception ABTException if an unrecoverable error occurs.
 *
 */
    public int size(IABTObjectSet oSet) throws ABTException
    {
        return super.size( oSet );
    }

 /**
 *  Formats errors returned by the public methods of this helper class.
 *  @param cls the Class where the error occurred
 *  @param module a String representing the module where this error occurred
 *  @param errMsg a String description of the error
 *  @return ABTError an ABTError error object
 *
 */
    protected ABTError createErrorObject( Class cls, String module, String errMsg )
    {
        return new ABTError( cls, module, errMsg, null );
    }

 /**
 *  Formats errors returned by the public methods of this helper class.
 *  @param cls the Class where the error occurred
 *  @param module a String representing the module where this error occurred
 *  @param errMsg an int error code corresponding to a text message
 *  @return ABTError an ABTError error object
 *
 */
    protected ABTError createErrorObject( Class cls, String module, int errCode )
    {
        return new ABTError( cls, module, errCode, null );
    }
}

