/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTSortedArrayEnumeration.java, 6, 12/8/98 9:55:50 AM, Benoit Menendez$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import java.util.*;


public class ABTSortedArrayEnumeration extends ABTArrayEnumeration 
{
   protected ABTComparator  comparator_;
   protected int            index_[];

   public ABTSortedArrayEnumeration(ABTArray array, ABTComparator comparator) {super(array); refresh(comparator);}

   protected Object at(int index) {return index < index_.length ? super.at(index_[index]) : null;}

   private final void swap(int left, int right)
   {
      int tmp = index_[left];

      index_[left] = index_[right];

      index_[right] = tmp;
   }

   private final int compare(int left, int right) {return comparator_.compare(at(left), at(right));}

   private final void sort(int lo, int hi)
   {
      if (hi < lo + 1) return;

      if (hi < lo + 8) {
         while (hi > lo) {
            int max = lo;

            for (int p = lo + 1; p <= hi; p++)
               if (compare(p, max) > 0) max = p;

            swap(max, hi--);
         }
      } else {
         int mid = (lo + hi) >> 1;

         swap(mid, lo);

         int loguy = lo, higuy = hi + 1;

         while (true) {
            do loguy++; while (loguy <= hi && compare(loguy, lo) <= 0);
            do higuy--; while (higuy >  lo && compare(higuy, lo) >= 0);

            if (higuy < loguy) break;

            swap(loguy, higuy);
         }

         swap(lo, higuy);

         if (higuy - lo > hi - loguy) {
            if (hi > loguy)      sort(loguy, hi);
            if (higuy > lo + 1)  sort(lo, higuy - 1);
         } else {
            if (higuy > lo + 1)  sort(lo, higuy - 1);
            if (hi > loguy)      sort(loguy, hi);
         }
      }
   }

   private final synchronized void sort()
   {
      if (index_.length < 2) return;

      sort(0, index_.length - 1);
   }
   
   private final void refresh(ABTComparator comparator)
   {
      comparator_ = comparator;
      
      synchronized (array_) {
         index_ = new int[array_.size()];
         
         for (int i = 0; i < array_.size(); i++) index_[i] = i;
         
         sort();
      }

      count_ = 0;
   }
}