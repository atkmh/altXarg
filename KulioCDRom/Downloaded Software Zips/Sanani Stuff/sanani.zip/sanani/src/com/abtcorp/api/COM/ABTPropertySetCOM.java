/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.com;

import com.abtcorp.core.*;
import com.abtcorp.idl.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class ABTPropertySetCOM  implements IABTPropertySetCOM
{
   public ABTPropertySetCOM(IABTPropertySet ar)
      {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base   = new ABTBaseJavaCOM(ar);
      /**/
      }

   //aggregated ABTArrayCOM access wrapper
   /**/
   protected ABTBaseJavaCOM _base;      // aggregated base array object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()      { return _base.getObject(); }
   public String toString()       { return _base.toString();};
   public String ToString()       { return _base.ToString();};
   public int  getHashCode()      { return _base.hashCode();}
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo()   { return _base.getClassInfo();}
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/

   private IABTPropertySet _ps;
   private IABTPropertySet ps() {
      if (_ps == null) _ps = (IABTPropertySet)getObject(); 
      return _ps;
      }

   public int indexForName(String p1)
     { return ps().indexForName(p1); }

   public String nameForIndex(int p1)
     { return ps().nameForIndex(p1); }


   public class ArrayEnumerator implements IEnumVariant,IABTEnumeratorCOM
     {
      protected IABTEnumerator _en;
      public ArrayEnumerator() { _en = ps().getElements(); }
      public void Reset() { _en = ps().getElements(); }
      public IEnumVariant Clone(){ return new ArrayEnumerator();  }
      public void Skip(int n) {
         while (n-- > 0 && _en.hasMoreElements()) {  _en.nextElement();  }
         }
      public boolean hasMoreElements()
         { return _en.hasMoreElements();  }

      public Variant nextElement() {
         IABTProperty p = (IABTProperty)_en.nextElement();
         IABTPropertyCOM pc = new ABTPropertyCOM(p);
         return new Variant(Variant.VariantDispatch,pc);
         }

      public void Next(int n, Variant[]v, int[]pfetched) {
         pfetched[0] = 0;
         while (n-- > 0 && _en.hasMoreElements())
            { v[(pfetched[0])++] = nextElement(); }
         }
     }

   public IUnknown get_NewEnum() { return new ArrayEnumerator(); }

   public IABTEnumeratorCOM getElements()
      { return new ArrayEnumerator(); }

   public int countProperties()   { return ps().countProperties(); }

   public int countNonVirtualProperties()   { return ps().countNonVirtualProperties(); }

   public IABTPropertyCOM getPropertybyIndex(int Index)  {
         return new ABTPropertyCOM((IABTProperty)ps().getPropertybyIndex(Index));
      }

   public IABTPropertyCOM getPropertybyName(String name)  {
		 IABTProperty iProp = ps().getPropertybyName(name);
		 if (iProp == null)
				return null;
         return new ABTPropertyCOM(iProp);
      }

}
