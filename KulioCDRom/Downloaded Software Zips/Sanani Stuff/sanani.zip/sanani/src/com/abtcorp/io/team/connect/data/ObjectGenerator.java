package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.objectModel.team.IABTTWRuleConstants;
import com.abtcorp.io.team.RemoteID;

public class ObjectGenerator implements IABTTWRuleConstants, IABTPropertyType
{
   private static ObjectGenerator manager_ = null;

   protected ObjectGenerator()
   {
      if (manager_ == null) {
         synchronized(this) {
            if (manager_ == null) {
               manager_ = this;
            }
         }
      }
   }

   public static ObjectGenerator getGenerator()
   {
      if (manager_ == null) new ObjectGenerator();
      return manager_;
   }

   public ABTValue createObjectFromRow(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      ABTValue object = null;
      switch (row.getType()) {
         case FileManager.CC:
         case FileManager.TC:
         case FileManager.PERIOD:
         case FileManager.CATEGORY:
         case FileManager.DELETED_TASK:
         case FileManager.DELETED_NOTE:
         case FileManager.DELETED_TIMESHEET:
         case FileManager.DELETED_OBJECT:
            object = makeObject(space,session,row);
            break;
         case FileManager.NOTE:
            object = makeNoteObject(space,session,row);
            break;
         case FileManager.PROJECT:
            object = makeProjectObject(space,session,row);
            break;
         case FileManager.USER:
            object = makeUserObject(space,session,row);
            break;
         case FileManager.RESOURCE:
            object = makeResourceObject(space,session,row);
            break;
         case FileManager.PLANNED:
         case FileManager.UNPLANNED:
            object = makeTaskObject(space,session,row);
            break;
         case FileManager.TIMESHEET:
            object = makeTimeSheetObject(space,session,row);
            break;
      }
      return object;
   }

   private ABTValue makeNoteObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      String objectType = FileManager.mapRowTypeToObjectType(row.getType());
      ABTHashtable args = new ABTHashtable(2,(float)1.0);
      ABTValue parenttype = (ABTValue)row.getValues().get(FLD_TW_PARENTTYPE);
      ABTValue parentid = (ABTValue)row.getValues().get(FLD_TW_PARENTID);
      args.put(new ABTString(PARENT_TYPE),parenttype);
      args.put(new ABTString(PARENT_ID),parentid);
      ABTValue object = space.createObject(session,objectType,(ABTRemoteID)row.getID(),args);

      if (object instanceof ABTObject) {

         for(Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();

            if (key.equals(FLD_TW_INTERNALID)) continue;

            ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   private ABTValue makeObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      String objectType = FileManager.mapRowTypeToObjectType(row.getType());
      ABTValue object = space.createObject(session,objectType,(ABTRemoteID)row.getID(),null);

      if (object instanceof ABTObject) {

         for(Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();
            if (key.equals(FLD_TW_INTERNALID)) continue;
            ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   private void setRemoteID(DataRow row, ABTObject target, ABTUserSession session)
   {
      target.getID().setRemote(session,(ABTRemoteID)row.getID());
   }

   private ABTValue makeUserObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      ABTValue object = space.createObject(session,OBJ_TW_USER,(ABTRemoteID)row.getID(),null);

      if (object instanceof ABTObject) {
         for (Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();

            if (key.equals(FLD_TW_INTERNALID)) continue;

            if (key.equals(FLD_TW_RESOURCES) || key.equals(FLD_TW_EPP_PROJECTS) || key.equals(FLD_TW_RESOURCE_APPROVAL) || key.equals(FLD_TW_MGR_PROJECTS)) {

               ABTValue set = null;

               if (key.equals(FLD_TW_RESOURCES) || key.equals(FLD_TW_RESOURCE_APPROVAL)) set = space.createObjectSet(session,OBJ_TW_RESOURCE);
               else set = space.createObjectSet(session,OBJ_TW_PROJECT);

               if (set instanceof ABTObjectSet) {

                  DataArray array = (DataArray)row.getValues().get(key);
                  for (int i = 0;i < array.size();i++) {
                     ABTObject obj = locateObject(space,session,key,(ABTValue)array.at(i));
                     if (obj != null) ((ABTObjectSet)set).add(session,obj);
                  }
                  // Store the objectset into the user object.
                  ((ABTObject)object).setValue(session,key,set,null);
               }
            } else ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   private ABTValue makeProjectObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      ABTValue object = space.createObject(session,OBJ_TW_PROJECT,(ABTRemoteID)row.getID(),null);

      if (object instanceof ABTObject) {
         for (Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();

            if (key.equals(FLD_TW_INTERNALID)) continue;

            if (key.equals("ProjectTasks")) {
               DataSet tasks = (DataSet)row.getValues().get(key);
               DataArray rows = tasks.getDataRows();
               for (int i = 0;i < rows.size();i++) {
                  ObjectGenerator.getGenerator().createObjectFromRow(space,session,(DataRow)rows.at(i));
               }
            } else if (key.equals(FLD_TW_NOTES)) {
               makeNoteObjects(space,session,row,object);
            } else if (key.equals(FLD_TW_SITE)) {
               ABTValue set = space.getObjects(session,OBJ_TW_SITE);
               
               // Only one site object needed. The first project to pull it in will provide the site object for all.
               if (set instanceof ABTObjectSet && ((ABTObjectSet)set).size(session) == 0) {
                  ABTValue siteObject = space.createObject(session,OBJ_TW_SITE,null,null);
                  if (siteObject instanceof ABTObject) {
                     Hashtable siteValues = (Hashtable)row.getValues().get(key);
                     if (siteValues != null) {
                        for (Enumeration siteKeys = siteValues.keys();siteKeys.hasMoreElements();) {
                           Object siteKey = siteKeys.nextElement();
                           ((ABTObject)siteObject).setValue(session,siteKey.toString(),(ABTValue)siteValues.get(siteKey),null);
                        }
                        ((ABTObject)object).setValue(session,key,siteObject,null);
                     }
                  }
               } else ((ABTObject)object).setValue(session,key,(ABTValue)((ABTObjectSet)set).at(session,0),null);                            
            } else ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   protected void checkProperties(ABTObjectSpace space, String object, String field, int type)
   {
      boolean found = false;
      // Add the saved field to the object if it hasn't already been added.
      Enumeration e = space.getProperties(object).elements();
      while (e.hasMoreElements()) {
         ABTProperty property = (ABTProperty)e.nextElement();
         if (property.getName().equals(field)) {
            found = true;
            break;
         }
      }
      // Add the new property.
      if (!found) space.addProperty(object,field,field,type,false,true,true,false,null,null,null);
   }

   private ABTValue makeTimeSheetObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      checkProperties(space,OBJ_TW_TIMESHEET,FLD_TW_SAVED,PROP_BOOLEAN);
      // DataRows have the internal id in place of the object for time periods and resources.
      ABTValue resourceid = (ABTValue)row.getValues().get(FLD_TW_RESOURCE);
      ABTValue timeperiodid = (ABTValue)row.getValues().get(FLD_TW_TIMEPERIOD);

      ABTValue resource = null;
      ABTValue timeperiod = null;
      ABTHashtable args = null;

      if (resourceid instanceof ABTString && timeperiodid instanceof ABTString) {
         args = new ABTHashtable(2,(float)1.0);

         resource = space.findObject(session,OBJ_TW_RESOURCE,new String(FLD_TW_INTERNALID + " = " + resourceid.stringValue()));
         if (resource instanceof ABTObjectSet) args.put(new ABTString(FLD_TW_RESOURCE),((ABTObjectSet)resource).at(session,0));

         timeperiod = space.findObject(session,OBJ_TW_TIMEPERIOD,new String(FLD_TW_INTERNALID + " = " + timeperiodid.stringValue()));
         if (timeperiod instanceof ABTObjectSet) args.put(new ABTString(FLD_TW_TIMEPERIOD),((ABTObjectSet)timeperiod).at(session,0));
      }
      ABTValue object = space.createObject(session,OBJ_TW_TIMESHEET,(ABTRemoteID)row.getID(),args);

      if (object instanceof ABTObject) {
         for (Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();

            if (key.equals(FLD_TW_INTERNALID)) continue;

            if (key.equals(FLD_TW_ENTRIES)) {
               // Create the time entry objects for the virtual field rules that return them.
               DataArray entries = (DataArray)row.getValues().get(key);
               for (int i = 0;i < entries.size();i++) {
                  Hashtable values = (Hashtable)entries.at(i);
                  ABTHashtable parameters = new ABTHashtable(2,(float)1.0);
                  ABTValue assignmentid = (ABTValue)values.get(FLD_TW_ASSIGNMENT);
                  if (assignmentid != null) parameters.putItemByKey(new ABTString(ASSIGNMENTID),assignmentid);
                  ABTValue entry = space.createObject(session,OBJ_TW_TIMEENTRY,null,parameters);
                  if (entry instanceof ABTObject) {
                     for (Enumeration keys = values.keys();keys.hasMoreElements();) {
                        String valueKey = (String)keys.nextElement();
                        if (valueKey.equals(FLD_TW_INTERNALID)) continue;

                        if (valueKey.equals(FLD_TW_TIMESHEET)) ((ABTObject)entry).setValue(session,valueKey,object,null);
                        else ((ABTObject)entry).setValue(session,valueKey,(ABTValue)values.get(valueKey),null);
                     	
                     	// Link up the assignment 
                     	ABTValue assignment = null;
                     	if (valueKey.equals(FLD_TW_ASSIGNMENT)) assignment = ((ABTObject)entry).getValue(session,valueKey,null);
                     }
                  }
               }
            } else if (key.equals(FLD_TW_NOTES)) {
               makeNoteObjects(space,session,row,object);
            } else ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   private ABTValue makeTaskObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      ABTValue object = space.createObject(session,OBJ_TW_TASK,(ABTRemoteID)row.getID(),null);

      if (object instanceof ABTObject) {
         for (Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();

            if (key.equals(FLD_TW_INTERNALID)) continue;

            if (key.equals(FLD_TW_PARENT)) {
               Hashtable table = (Hashtable)row.getValues().get(key);
               if (((String)table.get("Type")).equals(OBJ_TW_PROJECT)) {
                  ((ABTObject)object).setValue(session,FLD_TW_PARENT,locateObject(space,session,key,(ABTValue)table.get(FLD_TW_ID)));
               } else if (((String)table.get("Type")).equals(OBJ_TW_TASK)) {
                  ((ABTObject)object).setValue(session,FLD_TW_PARENT,(ABTValue)table.get(FLD_TW_ID));
               }
            } else if (key.equals(FLD_TW_NOTES)) {
               makeNoteObjects(space,session,row,object);
            } else ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   private ABTValue makeResourceObject(ABTObjectSpace space, ABTUserSession session, DataRow row)
   {
      ABTValue object = space.createObject(session,OBJ_TW_RESOURCE,(ABTRemoteID)row.getID(),null);

      if (object instanceof ABTObject) {

         // Make sure the resource's prID is set first.
         ((ABTObject)object).setValue(session,FLD_TW_ID,new ABTInteger(((RemoteID)row.getID()).getID()),null);

         for (Enumeration e = row.getValues().keys();e.hasMoreElements();) {
            String key = (String)e.nextElement();

            if (key.equals(FLD_TW_INTERNALID)) continue;

            if (key.equals(FLD_TW_PROJECTS)) {

               ABTValue set = space.createObjectSet(session,OBJ_TW_PROJECT);

               if (set instanceof ABTObjectSet) {

                  DataArray array = (DataArray)row.getValues().get(key);
                  for (int i = 0;i < array.size();i++) {
                     ABTObject obj = locateObject(space,session,key,(ABTValue)array.at(i));
                     if (obj != null) ((ABTObjectSet)set).add(session,obj);
                  }
                  ((ABTObject)object).setValue(session,FLD_TW_PROJECTS,set,null);
               }
            } else if (key.equals(FLD_TW_ASSIGNMENTS)) {
               // Create the assignments so the virtual field rule ResourceAssignments can return them.
               Hashtable assignments = (Hashtable)row.getValues().get(key);
               for (Enumeration e2 = assignments.keys();e2.hasMoreElements();) {

                  ABTValue assignmentKey = (ABTValue)e2.nextElement();
                  Hashtable values = (Hashtable)assignments.get(assignmentKey);

                  ABTValue assignment = space.createObject(session,OBJ_TW_ASSIGNMENT,null,null);
                  if (assignment instanceof ABTObject) {
                     for (Enumeration keys = values.keys();keys.hasMoreElements();) {
                        String valueKey = (String)keys.nextElement();

                        if (valueKey.equals(FLD_TW_INTERNALID)) continue;
                        ((ABTObject)assignment).setValue(session,valueKey,(ABTValue)values.get(valueKey),null);
                        // Store the assignment's remote id from the data row.
                        if (valueKey.equals(PROP_REMOTEID)) ((ABTObject)assignment).getID().setRemote(session,(ABTRemoteID)values.get(valueKey));
                     }
                  }
               }
            } else if (key.equals(FLD_TW_TIMESHEETS)) continue;
            else ((ABTObject)object).setValue(session,key,(ABTValue)row.getValues().get(key),null);
         }
      }
      return object;
   }

   private ABTObject locateObject(ABTObjectSpace space, ABTUserSession session, String field, ABTValue id)
   {
      ABTObject object = null;
      String selection = FLD_TW_INTERNALID + " = " + id.stringValue();
      String type = null;

      if (field.equals(FLD_TW_RESOURCES) || field.equals(FLD_TW_RESOURCE_APPROVAL)) {
         type = OBJ_TW_RESOURCE;
      } else if (field.equals(FLD_TW_EPP_PROJECTS) || field.equals(FLD_TW_PROJECTS)) {
         type = OBJ_TW_PROJECT;
      } else if (field.equals(FLD_TW_PARENT)) {
         type = OBJ_TW_PROJECT;
      }

      ABTValue set = space.findObject(session,type,selection);

      if (set instanceof ABTObjectSet) {

         if (((ABTObjectSet)set).size(session) > 0) {
            ABTValue value = ((ABTObjectSet)set).at(session,0);
            if (value instanceof ABTObject) object = (ABTObject)value;
         } else {
            ABTValue value = space.createObject(session,type,null,null);
            if (value instanceof ABTObject) object = (ABTObject)value;
         }
      }
      return object;
   }

   private void makeNoteObjects(ABTObjectSpace space, ABTUserSession session, DataRow row, ABTValue object)
   {
      DataArray notes = (DataArray)row.getValues().get(FLD_TW_NOTES);

      if (notes == null || notes.size() == 0) return;

      ABTValue set = ((ABTObject)object).getValue(session,FLD_TW_NOTES);

      if (set instanceof ABTObjectSet) {

         if (((ABTObjectSet)set).size(session) == 0) ((ABTObject)object).setValue(session,FLD_TW_NOTES,set);

         for (int i = 0;i < notes.size();i++) {
            ABTValue note = ObjectGenerator.getGenerator().createObjectFromRow(space,session,(DataRow)notes.at(i));
            if (note instanceof ABTObject) ((ABTObjectSet)set).add(session,(ABTObject)note);
         }
      }
   }
}