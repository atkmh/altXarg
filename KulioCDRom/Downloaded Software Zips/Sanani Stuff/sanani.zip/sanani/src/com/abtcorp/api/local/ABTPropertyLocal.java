/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.local;
import com.abtcorp.api.*;
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.hub.ABTUserSession;


class ABTPropertyLocal extends ABTSessionObject implements IABTProperty
{
//   protected ABTPropertyLocal()  { this((ABTSessionObject)null,null); }
   protected ABTPropertyLocal(ABTSessionObject s,com.abtcorp.hub.ABTProperty p) {
      super(s,p);
      }

//   protected ABTPropertyLocal(ABTUserSession s, com.abtcorp.hub.ABTProperty p) {
//      super(s,p);
//      }

   private com.abtcorp.hub.ABTProperty _prop;
   private com.abtcorp.hub.ABTProperty prop() {
      if (_prop == null) _prop = (com.abtcorp.hub.ABTProperty)getObject();
      return _prop;
      }

   /**
   * return the extendedProperties as a hashtable
   */
   public IABTHashTable getExtendedProperties(){
      ABTExtendedPropertyListLocal ht =
         new ABTExtendedPropertyListLocal(this,prop().getExtendedProperties());
      return ht;
      }


   /**
   * return the name of the associated ABTRule
   * @return String - the parent
   */
   public String getRuleName() {
      String rulename = prop().getRuleSet().getClass().getName();
      // now trim the com.abtcorp.objectModel. prefix
      if (rulename.startsWith("com.abtcorp.objectModel."))
         rulename = rulename.substring(24);
      return rulename;
      }

   /**
   * return the associated field validation routine
   * @return String ABTFieldRule
   */
   public String getFieldRuleName() {
      String rulename = prop().getFieldRule().getClass().getName();
      // now trim the com.abtcorp.objectModel. prefix
      if (rulename.startsWith("com.abtcorp.objectModel."))
         rulename = rulename.substring(24);
      return rulename;
      }

   /**
   *  get the referenced type of the property
   * @return String type or null if not reference
   */
   public String getReferenceType() {
      String rulename = prop().getReferenceType().getClass().getName();
      // now trim the com.abtcorp.objectModel. prefix
      if (rulename.startsWith("com.abtcorp.objectModel."))
         rulename = rulename.substring(24);
      return rulename;
      }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isUpdatable() {
      return prop().isUpdatable() ;
      }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isVisible() {
      return prop().isVisible() ;
      }

   /**
   * return whether this property is transient
   * @return boolean true for transient properties
   */
   public boolean isTransient() {
      return prop().isTransient() ;
      }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isVirtual() {
      return prop().isVirtual() ;
      }

   /**
   * return the name of this property
   * @return String name
   */
   public String getName() {
      return prop().getName() ;
      }

   /**
   * return the caption of this property
   * @return String caption
   */
   public String getCaption() {
      return prop().getCaption() ;
      }

   /**
   *  return the type of this property
   * @return int type
   */
   public int getType() {
      return prop().getType() ;
      }


   /**
   *  get the default value for this field
   * @return ABTValue
   */
   public ABTValue  getDefaultValue() {
      return prop(). getDefaultValue() ;
      }

   public int getIndex() {
      return prop().getIndex() ;
      }

   public void setPropertyKeyByKey(ABTValue key,ABTValue value){
      prop().setPropertyKey(key,(ABTValue)ValueMunger.MarshalIn(this, value));
      }
   public void setPropertyKeyByInt(int key,ABTValue value){
      prop().setPropertyKey(key,(ABTValue)ValueMunger.MarshalIn(this,value));
      }
   public void setPropertyKeyByString(String key,ABTValue value){
      prop().setPropertyKey(key,(ABTValue)ValueMunger.MarshalIn(this,value));
      }

   public ABTValue getPropertyKeyByKey(ABTValue key){
      return ValueMunger.MarshalOut(this,prop().getPropertyKey(key));
      }
   public ABTValue getPropertyKeyByInt(int key){
      return ValueMunger.MarshalOut(this,prop().getPropertyKey(key));
      }
   public ABTValue getPropertyKeyByString(String key){
         return ValueMunger.MarshalOut(this,prop().getPropertyKey(key));
      }
}
