package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoTaskEstimate.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-22-98    SOB            Initial Implementation
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support new required params functionality on create
 * 07-23-98    SOB            Mods to support save()
 * 10-09-98    SOB            Beginnings of progress reporting
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoTaskEstimate is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTTaskEstimate object in the object space.
 *  <pre>
 *       ABTIOPMWRepoTaskEstimate rd = new ABTIOPMWRepoDependency(ABTSession sess,
 *                                                          ABTRepository repo);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoTaskEstimate extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private Hashtable emh_ = null;
   private Hashtable th_ = null;
   
   public ABTIOPMWRepoTaskEstimate() {/* implicit call to super() here */}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoTaskEstimate(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable emh,
                       Hashtable th,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_TASKESTIMATE, OBJ_TASKESTIMATE, progress);
      projObj_ = projObj;
      projectID_ = projID;
      emh_ = emh;
      th_ = th;
   }

   /**
    *    Constructs a helper object to save task objects to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepository reference
    *    @param a Project object reference
    *    @forceAddNew true if an addNew() operation is being forced to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoTaskEstimate(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_TASKESTIMATE, OBJ_TASKESTIMATE, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with task estimate objects for a given project
    *    @param parms (not currently used)
    *    @return null
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;
      
      try
      {
         getCursor();
      
         //
         // For each task estimate tuple in the result set, make sure one exists in the 
         // object space.
         //
         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this task estimate object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the task estimate object already exists in the object space.
            //
            object = find(OBJ_TASKESTIMATE, id_);

            //
            // If the object found is an ABTObject, then the task est. object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new task estimate object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }
         }              // end while (cursor_.moveNext())
      }                 // end try block
      finally
      {
         closeCursor();
      }

      return (ABTValue) null;
   }
   
   /**
    *    Creates a new task estimate object. 
    *    @param parms (currently not used)
    *    @return the newly-created task estimate object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Get a reference to the associated estimating model object.
      //
      Long associatedEstModelID = new Long(cursor_.getFieldInt(FLD_ESTMODELID));
      ABTObject associatedEstModel = (ABTObject) emh_.get(associatedEstModelID);
      if (associatedEstModel == null) 
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "TaskEstimate->create",
                                              errorMessages.ERR_NO_EST_MODEL,
                                              null) );
      
      //
      // Get a reference to the associated task object.
      //
      Long associatedTaskID = new Long(cursor_.getFieldInt(FLD_TASKID));
      ABTObject associatedTask = (ABTObject) th_.get(associatedTaskID);
      if (associatedTask == null) 
         throw new ABTException( new ABTError(COMP_PMREPODRIVER,
                                              "TaskEstimate->create",
                                              errorMessages.ERR_NO_TASK_FOR_TASK_EST,
                                              null) );
      
      //
      // Create the required params Hashtable and place into the required parms for object creation.  These
      // will be a task reference and an estimating model reference.
      //
      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_TASK, associatedTask);
      reqparms.putItemByString(OFD_ESTMODEL, associatedEstModel);
      
      //
      // Create the task estimate object...
      //
      ABTObject object = createObject(OBJ_TASKESTIMATE, id_, reqparms);
      
      //
      // Initialize repository properties of the new task estimate object.
      //
      setValues(object);
      
      return object;
   }
   
   /**
    *    Updates an existing task estimate object.
    *    @param parms the existing task object to be updated
    *    @return the updated task estimate object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
      setPropertyValues(ps_, cursor_, obj);
   }
   
   private void getCursor()
   {
      //
      // Select the task estimates.  
      //
      cursor_ = repo_.select(QRY_TASKESTIMATES);
      
      //
      // The following andFilter causes only those task estimate tuples to be selected which
      // belong to the current project.
      //
      cursor_.andFilter(TBL_TASK + "." + FLD_PROJECTID + "=" + projectID_);
   }
   
   /**
    *    Saves task estimate objects to the repository
    *    @param parms: (not currently used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get a cursor and order the result set by prID
      //
      getCursor();
      cursor_.setSort(TBL_TASKESTIMATE + "." + FLD_ID);
      
      //
      // Get the collection of all task estimates from the project.
      //
      
      ABTObjectSet taskEstimates = getObjectSet(projObj_, OFD_ALLTASKESTIMATES);
      
      //
      // Set some properties prior to writing the objects back to the repository.
      //
      setSomeProperties(taskEstimates);
      
      //
      // save all task estimates to the repository
      //
      save(taskEstimates);
      
      closeCursor();
   }
   
   public void setSomeProperties(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);
      
      //
      // For each task estimate, make sure the task ID and the estimating model id
      // is set correctly.  This needs to be done because either (or both) the task object
      // or the estimating model object could be new objects and their corresponding prID
      // fields not known until they were physically added to the repository.
      //
      for (int i = 0; i < size; i++)
      {
         ABTObject taskEstimate = at(oSet, i);
         ABTObject task = getObject(taskEstimate, OFD_TASK);
         ABTObject estModel = getObject(taskEstimate, OFD_ESTMODEL);
         
         setValue(taskEstimate, OFD_TASKID, getValue(task, OFD_ID));
         setValue(taskEstimate, OFD_ESTMODELID, getValue(estModel, OFD_ID));
      }
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName the PRAPI column name that is about to be written to the repository
    *    @param   obj the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew a boolean value which indicates whether the data being added is new to the repository, i.e., the
    *             operation is an add.
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         if (super.isSaveException(prapiName, obj, prapiFlags, isNew))
            return true;
         
         boolean  ret = false;            // assume no exception

         //
         // For task estimates, PVision does not allow updates to prEstModelID & prTaskID fields
         // of existing tuples.  New tuples can set these fields.
         //
         if (!isNew)
         {
            if (prapiName.equals(FLD_ESTMODELID) ||
                prapiName.equals(FLD_TASKID) )
               ret = true;
         }
         
         return ret;
   }


}