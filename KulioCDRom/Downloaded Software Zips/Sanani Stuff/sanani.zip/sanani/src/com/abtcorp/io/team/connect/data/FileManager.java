package com.abtcorp.io.team.connect.data;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.lang.ArrayIndexOutOfBoundsException;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.idl.IABTPropertyType;

public class FileManager implements IABTTWRuleConstants, IABTPropertyType
{
   public static final int DELETED_OBJECT = -1;
   public static final int DELETED_TASK   = -2;
   public static final int DELETED_NOTE   = -3;
   public static final int DELETED_TIMESHEET = -4;

   // These next four indices must match the temp indices below.
   public static final int PROJECT    = 0;
   public static final int RESOURCE   = 1;
   public static final int TIMESHEET  = 2;
   public static final int PLANNED    = 3;
   public static final int CC         = 4;
   public static final int TC         = 5;
   public static final int CATEGORY   = 6;
   public static final int UNPLANNED  = 7;
   public static final int PERIOD     = 8;
   public static final int USER       = 9;
   public static final int OUTGOING   = 10;
   public static final int CONFIG     = 11;
   // WARNING: Notes aren't saved in a separate file. This index doesn't correspond
   // to a file in the files_ array.
   public static final int NOTE       = 12;

   public static final int PROJECT_TEMP     = 0;
   public static final int RESOURCE_TEMP    = 1;
   public static final int TIMESHEET_TEMP   = 2;
   public static final int PLANNED_TEMP     = 3;

   private static final int MAX_FILES     = 12; // Doesn't include the NOTE type.
   private static final int MAX_TEMPFILES = 4;

   // The files we manage.
   private StructuredFile[] files_;
   private StructuredFile[] tempFiles_;

   private static Hashtable managers_ = new Hashtable(10,(float)1.0);

   protected FileManager(Object key)
   {
      if (key == null) return;
      files_ = new StructuredFile[MAX_FILES];
      tempFiles_ = new StructuredFile[MAX_TEMPFILES];
      if (managers_ != null && managers_.get(key) == null) managers_.put(key,this);
   }

   public static FileManager getManager(Object key)
   {
      if (managers_ == null) managers_ = new Hashtable(10,(float)1.0);
      if (key == null) return null;

      if (managers_.get(key) == null) new FileManager(key);

      return (FileManager)managers_.get(key);
   }

   public StructuredFile getFile(int type, boolean useTempFile)
   {
      if (useTempFile) {
         if (type < CC && tempFiles_[type] != null) return tempFiles_[type];
      }

      if (files_ != null) return files_[type];
      else return null;
   }

   public void openTempFile(String directory, int type) throws IOException
   {
      switch (type) {
         case PROJECT_TEMP:
            tempFiles_[PROJECT_TEMP] = new StructuredFile(directory + File.separator + "project.tmp");
            break;
         case RESOURCE_TEMP:
            tempFiles_[RESOURCE_TEMP] = new StructuredFile(directory + File.separator + "resource.tmp");
            break;
         case PLANNED_TEMP:
            tempFiles_[PLANNED_TEMP] = new StructuredFile(directory + File.separator + "planned.tmp");
            break;
         case TIMESHEET_TEMP:
            tempFiles_[TIMESHEET_TEMP] = new StructuredFile(directory + File.separator + "timesheet.tmp");
            break;
      }
   }

   public void openFiles(String directory) throws IOException
   {
      files_[CC] = new StructuredFile(directory + File.separator + "cc.dat");
      files_[TC] = new StructuredFile(directory + File.separator + "tc.dat");
      files_[PROJECT] = new StructuredFile(directory + File.separator + "project.dat");
      files_[RESOURCE] = new StructuredFile(directory + File.separator + "resource.dat");
      files_[CATEGORY] = new StructuredFile(directory + File.separator + "category.dat");
      files_[PLANNED] = new StructuredFile(directory + File.separator + "planned.dat");
      files_[UNPLANNED] = new StructuredFile(directory + File.separator + "unplanned.dat");
      files_[TIMESHEET] = new StructuredFile(directory + File.separator + "timesheet.dat");
      files_[USER] = new StructuredFile(directory + File.separator + "user.dat");
      files_[PERIOD] = new StructuredFile(directory + File.separator + "period.dat");
      files_[OUTGOING] = new StructuredFile(directory + File.separator + "outgoing.dat");
      files_[CONFIG] = new StructuredFile(directory + File.separator + "config.dat");

      compactFiles();
   }

   public void closeFiles() throws IOException
   {
      for (int i = 0;i < MAX_FILES;i++) {
         StructuredFile file = files_[i];
         files_[i].close();
      }
   }

   public StructuredFile getTempFile(int type)
   {
      return tempFiles_[type];
   }

   public void setFile(StructuredFile file, int type)
   {
      if (type < CC && tempFiles_[type] != null) tempFiles_[type] = file;
      else files_[type] = file;
   }

   public void rename(int type) throws IOException, ArrayIndexOutOfBoundsException
   {
      if (type < 0 || type > PLANNED_TEMP) throw new ArrayIndexOutOfBoundsException(type);

      if (tempFiles_[type] != null && files_[type] != null) {
         files_[type] = rename(tempFiles_[type],files_[type]);
         setFile(null,type);
      }
   }

   protected StructuredFile rename(StructuredFile src, StructuredFile dest) throws IOException
   {
      src.close();
      dest.close();

      File temp = new File(src.getPath());
      File file = new File(dest.getPath());
      file.delete();

      temp.renameTo(file);

      return new StructuredFile(file);
   }

   public void rewrite(DataSet set) throws IOException
   {
      StructuredFile file = getFile(set.getType(),false);

      file.close();

      File temp = new File(file.getPath());
      temp.delete(); // Blow away old data - new ones coming from agent.

      files_[set.getType()] = new StructuredFile(file.getPath());

      save(set);
   }

   public void save(DataRow data, int type) throws IOException
   {

      getFile(type,true).writeObject(data.getKey(),data);
   }

   public void save(DataSet set) throws IOException
   {

      ABTArray array = set.getDataRows();
      if (array == null) return;

      for (int i = 0;i < array.size();i++) {
         save((DataRow)set.at(i),set.getType());
      }
   }

   public void compactFiles() throws IOException
   {
      try {
         for (int i = 0;i < FileManager.MAX_FILES;i++) {
            StructuredFile file = StructuredFile.compact(files_[i]);
            if (file != null) setFile(file,i);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
   }


   public void writeOutGoingRow(DataRow row, boolean erase)
   {
      writeRow(FileManager.OUTGOING,new ABTString(FileManager.rowHashKey(row.getType(),row.getKey())), row, erase);
   }


   public static String mapRowTypeToObjectType(int rowType)
   {
      switch (rowType) {
         case FileManager.CC:         return OBJ_TW_CHARGECODE;
         case FileManager.TC:         return OBJ_TW_TYPECODE;
         case FileManager.PERIOD:     return OBJ_TW_TIMEPERIOD;
         case FileManager.USER:       return OBJ_TW_USER;
         case FileManager.NOTE:       return OBJ_TW_NOTE;
         case FileManager.CATEGORY:   return OBJ_TW_CATEGORYSTRING;
         case FileManager.RESOURCE:   return OBJ_TW_RESOURCE;
         case FileManager.PROJECT:    return OBJ_TW_PROJECT;
         case FileManager.PLANNED:    return OBJ_TW_TASK;
         case FileManager.UNPLANNED:  return OBJ_TW_TASK;
         case FileManager.TIMESHEET:  return OBJ_TW_TIMESHEET;
         case FileManager.DELETED_OBJECT: return OBJ_TW_DELETEDOBJECT;
         case FileManager.DELETED_TASK: return OBJ_TW_DELETEDTASK;
         case FileManager.DELETED_NOTE: return OBJ_TW_DELETEDNOTE;
         case FileManager.DELETED_TIMESHEET: return OBJ_TW_DELETEDTIMESHEET;
      }
      return null;
   }

   public static int mapType(String type)
   {
      if (type.equals(OBJ_TW_CHARGECODE))          return CC;
      else if (type.equals(OBJ_TW_TYPECODE))       return TC;
      else if (type.equals(OBJ_TW_TIMESHEET))      return TIMESHEET;
      else if (type.equals(OBJ_TW_PROJECT))        return PROJECT;
      else if (type.equals(OBJ_TW_TASK))           return PLANNED;
      else if (type.equals(OBJ_TW_RESOURCE))       return RESOURCE;
      else if (type.equals(OBJ_TW_TIMEPERIOD))     return PERIOD;
      else if (type.equals(OBJ_TW_USER))           return USER;
      else if (type.equals(OBJ_TW_CATEGORYSTRING)) return CATEGORY;
      else if (type.equals(OBJ_TW_DELETEDOBJECT))  return DELETED_OBJECT;
      else if (type.equals(OBJ_TW_DELETEDTASK))    return DELETED_TASK;
      else if (type.equals(OBJ_TW_DELETEDNOTE))    return DELETED_NOTE;
      else if (type.equals(OBJ_TW_DELETEDTIMESHEET)) return DELETED_TIMESHEET;
      else if (type.equals(OBJ_TW_NOTE))           return NOTE;
      // The following types are used by the FileViewer application.
      else if (type.equals("team.Unplanned"))      return UNPLANNED;

      return -100;
   }

   public DataRow getDataRow(int type, ABTValue key, boolean useTempFile)
   {
      StructuredFile file = getFile(type,useTempFile);
      DataRow row = null;

      try {
         row = (DataRow)file.readObject(key);
      } catch (Exception e) {
         e.printStackTrace();
      }

      if (row != null && managers_ != null) {
         for (Enumeration e = managers_.keys();e.hasMoreElements();) {
            Object managerKey = e.nextElement();
            if (managers_.get(managerKey) == this) {
               row.setFileManagerKey(managerKey);
               break;
            }
         }
      }

      return row;
   }

   public DataRow readRow(int type, Object key, Hashtable readObjects)
   {
      String hashkey = rowHashKey(type,key);

      if (readObjects != null && readObjects.get(hashkey) != null) return null;

      try {
         DataRow row = getDataRow(type,(ABTValue)key,false);
         if (row != null && readObjects != null) readObjects.put(hashkey,row);

         return row;
      } catch (Exception exception) {
         exception.printStackTrace();
      }
      return null;
   }

   private void writeRow(int type, ABTValue key, DataRow row, boolean erase)
   {
      if (row == null) return;
      try {
         StructuredFile file = getFile(type,false);
         if (file != null) {
            if (erase) file.writeObject(key,null);
            else file.writeObject(key,row);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public void writeRow(int type, DataRow row, boolean erase)
   {
      writeRow(type,row.getKey(),row,erase);
   }

   public static String rowHashKey(int type, Object key)
   {
      return FileManager.mapRowTypeToObjectType(type) + key;
   }

   public void replaceUnplannedTask(DataRow newTask) throws IOException
   {
      if (newTask == null) return;

      ABTValue projectid = (ABTValue)newTask.getValues().get(FLD_TW_PROJECT);
      DataSet tasks = null;
      DataRow project = null;
      if (projectid != null && !ABTEmpty.isEmpty(projectid) && !ABTError.isError(projectid)) {
         project = getDataRow(FileManager.PROJECT,projectid,false);
         if (project != null) {
            tasks = (DataSet)project.getValues().get("ProjectTasks");
            if (tasks == null) tasks = new DataSet(FileManager.PLANNED); // This is wrong!
         }
      }

      if (project == null || tasks == null) return; // Something bad happened if the tasks haven't been created.

      tasks.setFileManagerKey(newTask.getManagerKey());

      // Find task in project's task list
      DataRow oldTask = (DataRow)tasks.find(newTask);
      if (oldTask != null) {
         ABTValue prev = (ABTValue)oldTask.getValues().get(FLD_TW_PREVIOUS);
         ABTValue next = (ABTValue)oldTask.getValues().get(FLD_TW_NEXT);

         oldTask.setType(FileManager.PLANNED);
         oldTask.getValues().put(FLD_TW_INTERNALID,newTask.getValues().get(FLD_TW_INTERNALID));
         oldTask.getValues().put(FLD_TW_ID, newTask.getValues().get(FLD_TW_ID));
         oldTask.getValues().put(PROP_REMOTEID, newTask.getValues().get(PROP_REMOTEID));
         oldTask.setKey(newTask.getKey());

         writeRow(oldTask.getType(),oldTask,false);

         // Set the parent to point to the new task if necessary
         Hashtable table = (Hashtable)oldTask.getValues().get(FLD_TW_PARENT);
         if (table != null) {
            ABTValue parentid = (ABTValue)table.get(FLD_TW_ID);
            if (table.get("Type").equals(OBJ_TW_TASK)) {
               DataRow parent = getDataRow(FileManager.PLANNED,parentid,false);
               if (parent == null) parent = getDataRow(FileManager.UNPLANNED,parentid,false);
               if (parent != null) {
                  DataRow temp = (DataRow)tasks.find(parent);
                  if (temp != null) parent = temp;
                 // Check the first field of the parent.
                  ABTValue first = (ABTValue)parent.getValues().get(FLD_TW_FIRST);
                  if (first != null) {
                     DataRow firstTask = getDataRow(FileManager.PLANNED,first,false);
                     if (firstTask == null) getDataRow(FileManager.UNPLANNED,first,false);
                     if (firstTask != null && firstTask.equals(oldTask)) {
                        parent.getValues().put(FLD_TW_FIRST,newTask.getValues().get(FLD_TW_INTERNALID));
                     }
                  }
                 // Check the last field of the parent.
                  ABTValue last = (ABTValue)parent.getValues().get(FLD_TW_LAST);
                  if (last != null) {
                     DataRow lastTask = getDataRow(FileManager.PLANNED,last,false);
                     if (lastTask == null) lastTask = getDataRow(FileManager.UNPLANNED,last,false);
                     if (lastTask != null && lastTask.equals(oldTask)) {
                        parent.getValues().put(FLD_TW_LAST,newTask.getValues().get(FLD_TW_INTERNALID));
                     }
                  }
                  writeRow(parent.getType(),parent,false);
               }
            }
         }
         // Set the previous key to point to the new task
         if (prev != null) {
            DataRow previousTask = getDataRow(FileManager.PLANNED,prev,false);
            if (previousTask == null) previousTask = getDataRow(FileManager.UNPLANNED,prev,false);

            if (previousTask != null) {
               previousTask.setFileManagerKey(newTask.getManagerKey());
               DataRow temp = (DataRow)tasks.find(previousTask);
               if (temp != null) previousTask = temp;
            }

            if (previousTask != null) {
               ABTValue nextid = (ABTValue)previousTask.getValues().get(FLD_TW_NEXT);
               if (nextid != null && !ABTError.isError(nextid) && !ABTEmpty.isEmpty(nextid)) {
                  previousTask.getValues().put(FLD_TW_NEXT,newTask.getValues().get(FLD_TW_INTERNALID));
                  writeRow(previousTask.getType(),previousTask,false);
               }
            }
         }

         // Set the next key to point to the new task.
         if (next != null) {
            DataRow nextTask = getDataRow(FileManager.PLANNED,next,false);
            if (nextTask == null) nextTask = getDataRow(FileManager.UNPLANNED,next,false);

            if (nextTask != null) {
               nextTask.setFileManagerKey(newTask.getManagerKey());
               DataRow temp = (DataRow)tasks.find(nextTask);
               if (temp != null) nextTask = temp;
            }

            if (nextTask != null) {
               ABTValue previd = (ABTValue)nextTask.getValues().get(FLD_TW_PREVIOUS);
               if (previd != null && !ABTError.isError(previd) && !ABTEmpty.isEmpty(previd)) {
                  nextTask.getValues().put(FLD_TW_PREVIOUS,newTask.getValues().get(FLD_TW_INTERNALID));
                  writeRow(nextTask.getType(),nextTask,false);
               }
            }
         }
         save(project,project.getType());
      }
   }

   public void linkRowTask(DataRow task) throws IOException
   {
      if (task == null) return;

      // Unplanned tasks must be added to the unplanned task file and
      // added to the project.
      ABTValue projectid = (ABTValue)task.getValues().get(FLD_TW_PROJECT);
      DataSet tasks = null;
      DataRow project = null;
      if (projectid != null && !ABTEmpty.isEmpty(projectid) && !ABTError.isError(projectid)) {
         project = getDataRow(FileManager.PROJECT,projectid,false);
         if (project != null) {
            tasks = (DataSet)project.getValues().get("ProjectTasks");
            if (tasks == null) tasks = new DataSet(FileManager.PLANNED); // This is wrong!
            tasks.add(task);
         }
      }

      if (project == null || tasks == null) return; // Something bad happened if the tasks haven't been created.

      tasks.setFileManagerKey(task.getManagerKey());
      // Link the unplanned task's parent's last pointer to the unplanned task.
      Hashtable table = (Hashtable)task.getValues().get(FLD_TW_PARENT);
      DataRow parent = null;
      if (table != null) {
         // See if the parent is a task or a project
         ABTValue parentid = (ABTValue)table.get(FLD_TW_ID);

         if (table.get("Type").equals(OBJ_TW_PROJECT)) {
            parent = project;
            if (parentid.equals(project.getValues().get(FLD_TW_INTERNALID))) project.getValues().put(FLD_TW_LAST,task.getValues().get(FLD_TW_INTERNALID));
         } else { // Parent is a task. Find it in the project's set of tasks.
            int type = FileManager.PLANNED;
            parent = getDataRow(type,parentid,false);
            if (parent == null) {
               type = FileManager.UNPLANNED;
               parent = getDataRow(type,parentid,false);
            }

            if (parent != null) {
               parent.setFileManagerKey(task.getManagerKey());
               DataRow temp = (DataRow)tasks.find(parent);
               parent = temp;
            }
         }

         // Link the parent's first pointer to the new task if the first pointer hasn't been set yet.
         if (parent != null) {
            parent.getValues().put(FLD_TW_LAST,task.getValues().get(FLD_TW_INTERNALID));
            ABTValue first = (ABTValue)parent.getValues().get(FLD_TW_FIRST);
            if (first == null || ABTEmpty.isEmpty(first) || ABTError.isError(first)) {
               parent.getValues().put(FLD_TW_FIRST,task.getValues().get(FLD_TW_INTERNALID));
            }
            save(parent,parent.getType());
         }
      }

      // Link the unplanned task's previous next's pointer to the unplanned task. This secures it in the link.
      ABTValue previousid = (ABTValue)task.getValues().get(FLD_TW_PREVIOUS);
      DataRow previous = null;
      if (previousid != null && !ABTEmpty.isEmpty(previousid) && !ABTError.isError(previousid)) {
         previous = getDataRow(FileManager.PLANNED,previousid,false);

         if (previous == null) previous = getDataRow(FileManager.UNPLANNED,previousid,false);

         if (previous != null) {
            previous.setFileManagerKey(task.getManagerKey());
            DataRow temp = (DataRow)tasks.find(previous);
            previous = temp;
         }
      }

      if (previous != null) {
         previous.getValues().put(FLD_TW_NEXT,task.getValues().get(FLD_TW_INTERNALID));
         save(previous,previous.getType());
      }

      save(project,project.getType()); // rewrite the project with the new task.
      save(task,task.getType()); // Save the unplanned task in the unplanned task file.
   }

   public void unlinkRowTask(DataRow task) throws IOException
   {
      DataRow parent = null;
      DataRow parentFirst = null;
      DataRow parentLast = null;
      boolean parentIsProject = false;
      boolean linkParentFirst = false;
      boolean linkParentLast = false;

      ABTValue projectid = (ABTValue)task.getValues().get(FLD_TW_PROJECT);
      DataSet tasks = null;
      DataRow project = null;
      if (projectid != null && !ABTEmpty.isEmpty(projectid) && !ABTError.isError(projectid)) {
         project = getDataRow(FileManager.PROJECT,projectid,false);
         if (project != null) {
            tasks = (DataSet)project.getValues().get("ProjectTasks");
            if (tasks.size() > 0) tasks.setFileManagerKey(task.getManagerKey());
         }
      }
      // Find this task's parent data row first.
      Hashtable parentInfo = (Hashtable)task.getValues().get(FLD_TW_PARENT);
      if (parentInfo != null && parentInfo.get("Type") != null && parentInfo.get("Type").equals(OBJ_TW_TASK)) {
         parent = getDataRow(FileManager.UNPLANNED,(ABTValue)parentInfo.get(FLD_TW_ID),false);
         if (parent == null) {
            parent = getDataRow(FileManager.PLANNED,(ABTValue)parentInfo.get(FLD_TW_ID),false);
         }
      } else if (parentInfo != null && parentInfo.get("Type") != null && parentInfo.get("Type").equals(OBJ_TW_PROJECT)) {
         parent = getDataRow(FileManager.PROJECT,(ABTValue)parentInfo.get(FLD_TW_ID),false);
         parentIsProject = true;
      }

      if (parent instanceof DataRow) {
         // Check if the parent's first pointer is this task.
         Object firstid = parent.getValues().get(FLD_TW_FIRST);
         if (firstid instanceof ABTValue) {
            if (!parentIsProject) {
               parentFirst = getDataRow(FileManager.PLANNED,(ABTValue)firstid,false);
               if (parentFirst == null) parentFirst = getDataRow(FileManager.UNPLANNED,(ABTValue)firstid,false);
            }

            if (parentFirst instanceof DataRow && parentFirst.equals(task)) linkParentFirst = true;
         }

         // Check if the parent's last pointer is this task.
         Object lastid = parent.getValues().get(FLD_TW_LAST);
         if (lastid instanceof ABTValue) {
            parentLast = getDataRow(FileManager.PLANNED,(ABTValue)lastid,false);
            if (parentLast == null) parentLast = getDataRow(FileManager.UNPLANNED,(ABTValue)lastid,false);

            if (parentLast instanceof DataRow && parentLast.equals(task)) linkParentLast = true;
         }
      }

      // Get the previous and next pointers for this task so we can unlink properly.
      ABTValue prev = (ABTValue)task.getValues().get(FLD_TW_PREVIOUS);
      ABTValue next = (ABTValue)task.getValues().get(FLD_TW_NEXT);
      DataRow previousTask = null;
      DataRow nextTask = null;

      if (prev != null) {
         previousTask = getDataRow(FileManager.PLANNED,prev,false);
         if (previousTask == null) previousTask = getDataRow(FileManager.UNPLANNED,prev,false);
      }

      if (next != null) {
         nextTask = getDataRow(FileManager.PLANNED,next,false);
         if (nextTask == null) nextTask = getDataRow(FileManager.UNPLANNED,next,false);
      }

      if (nextTask != null) {
         if (prev == null) nextTask.getValues().remove(FLD_TW_PREVIOUS);
         else nextTask.getValues().put(FLD_TW_PREVIOUS,prev);
         if (nextTask.getValues().get(FLD_TW_ID) != null && ((ABTValue)nextTask.getValues().get(FLD_TW_ID)).intValue() == 0) {
            writeRow(FileManager.UNPLANNED,nextTask,false);
         } else {
            writeRow(FileManager.PLANNED,nextTask,false);
         }

         // Make sure the tasks array in the project file is updated.
         if (tasks != null) {
            DataRow row = (DataRow)tasks.find(nextTask);
            if (row != null) {
               if (prev == null) row.getValues().remove(FLD_TW_PREVIOUS);
               else row.getValues().put(FLD_TW_PREVIOUS,prev);
            }
         }
      }
      if (previousTask != null) {
         if (next == null) previousTask.getValues().remove(FLD_TW_NEXT);
         else previousTask.getValues().put(FLD_TW_NEXT,next);

         if (previousTask.getValues().get(FLD_TW_ID) != null && ((ABTValue)previousTask.getValues().get(FLD_TW_ID)).intValue() == 0) {
            writeRow(FileManager.UNPLANNED,previousTask,false);
         } else {
            writeRow(FileManager.PLANNED,previousTask,false);
         }
         // Make sure the tasks array in the project file is updated.
         if (tasks != null) {
            DataRow row = (DataRow)tasks.find(previousTask);
            if (row != null) {
               if (next != null) row.getValues().put(FLD_TW_NEXT,next);
               else row.getValues().remove(FLD_TW_NEXT);
            }
         }
      }
      if (linkParentFirst) {
         parent.getValues().put(FLD_TW_FIRST,next);
         if (parentIsProject && project != null) {
            project.getValues().put(FLD_TW_FIRST,next);
         } else {
            DataRow parentTask = (DataRow)tasks.find(parent);
            if (parentTask != null) parentTask.getValues().put(FLD_TW_FIRST,next);
         }
      }

      if (linkParentLast) {
         parent.getValues().put(FLD_TW_LAST,prev);
         if (parentIsProject && project != null) {
            project.getValues().put(FLD_TW_LAST,prev);
         } else {
            DataRow parentTask = (DataRow)tasks.find(parent);
            if (parentTask != null) parentTask.getValues().put(FLD_TW_LAST,prev);
         }
      }

      if (parentIsProject) {
         writeRow(FileManager.PROJECT,parent,false);
      } else {
         if (parent != null && ((ABTValue)parent.getValues().get(FLD_TW_ID)).intValue() == 0) {
            writeRow(FileManager.UNPLANNED,parent,false);
         } else {
            writeRow(FileManager.PLANNED,parent,false);
         }
      }

      // Remove the task from the projects "ProjectTasks" field
      if (tasks != null) {
         int index = tasks.indexOf(task);
         if (index != -1) {
            tasks.remove(index);
            writeRow(FileManager.PROJECT,project,false);
         }
      }
   }
}