package com.abtcorp.io.team.connect.data;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.Hashtable;

public class TWDataOutputStream extends DataOutputStream
{
   URLConnection connection_;

   private static URLConnection getURLConnection(URL url) throws IOException
   {
      URLConnection connection = url.openConnection();

      connection.setDoOutput(true);
      connection.setUseCaches(false);

      return connection;
   }

   public TWDataOutputStream(OutputStream stream) throws IOException
   {
      super(stream);
   }

   public TWDataOutputStream(String path) throws IOException
   {
      this(new FileOutputStream(path));
   }

   public TWDataOutputStream(URLConnection connection) throws IOException
   {
      this(connection.getOutputStream());

      connection_ = connection;
   }

   public TWDataOutputStream(URL url) throws IOException
   {
      this(getURLConnection(url));
   }

   public TWDataOutputStream(URL url, String path) throws IOException
   {
      this(new URL(url, path));
   }

   public InputStream closeStream() throws IOException
   {
      super.close();

      if (connection_ != null) {
         InputStream stream = connection_.getInputStream();

         return stream;
      }

      return null;
   }

   public void close() throws IOException
   {
      super.close();

      if (connection_ != null) {
         InputStream stream = connection_.getInputStream();

         stream.close();
      }
   }
}