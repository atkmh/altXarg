package com.abtcorp.api.local;

/*
 * ABTDriverLocal.java 03/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 *
 */

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.io.*;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import com.abtcorp.api.*;

import com.abtcorp.core.ABTException;


public class ABTDriverLocal implements IABTDriver
{
   protected boolean _isRemote;
   ABTObjectSpaceLocal _mySpace;

   protected ABTDriverLocal(ABTObjectSpaceLocal space){
      _mySpace = space;
      _rdriver = null;
      _isRemote = false;
      _cdriver = null;
      }

   private IABTServerDriver _rdriver;
   private IABTServerDriver rdriver(){
      return _rdriver;
      }

   private IABTClientDriver _cdriver;
   private IABTClientDriver cdriver(){
      return _cdriver;
      }

   protected ABTValue initialize(String className, IABTHashTable args){
      // First, see if we can fire up an instance of the driver class
      try {
         Class driverClass = Class.forName(className);
         Object oDriver = driverClass.newInstance();
         if (oDriver instanceof IABTClientDriver){
            // it's an instance of a client-api driver
            _cdriver = (IABTClientDriver)oDriver;
            _isRemote = false;
            }
         else if (oDriver instanceof IABTServerDriver){
            // It's an instance of a server-api driver
            _rdriver = (IABTServerDriver)oDriver;
            _isRemote = true;
            }
         }
      catch (ClassNotFoundException e){ return new ABTError(getClass(), "Initialize", errorMessages.ERR_CLASS_NOTFOUND, e); }
      catch (InstantiationException e){ return new ABTError(getClass(), "Initialize", errorMessages.ERR_CANT_INSTANTIATE, e); }
      catch (IllegalAccessException e){ return new ABTError(getClass(), "Initialize", errorMessages.ERR_ILLEGAL_ACCESS, e); }
      return null;
      }

/**
 *		Open a connection to a specific data source.
 *		@return An ABTValue, which will be an ABTError if the call failed.
 */
   public ABTValue open(IABTHashTable args)
     {
      ABTUserSession session = _mySpace.getUserSession();
     if ( (_isRemote && rdriver() == null) || (!_isRemote && cdriver() == null))
        return new ABTError(getClass(), "open", errorMessages.ERR_INVALID_DRIVER,null);


      if (_isRemote) {
         ABTObjectSpace ros = (ABTObjectSpace)_mySpace.getObject(); 
         ABTHashtable rht = null;
         ABTHashTable lht = null;
         if (args != null){
            lht = (ABTHashTable)args;
            rht = (com.abtcorp.core.ABTHashtable)lht.getObject();
            }
         return ValueMunger.MarshalOut(_mySpace,rdriver().open(ros, session, rht));
        }
     else {
         return cdriver().open(_mySpace, args);
        }
     }


/**
 *		Populate the ABTObjectSpace with objects from the data source. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *		@param selector  A String object which completely identifies the
 *		object(s) to be created and the criteria that will be used to select the associated
 *		data components from the data source.
 *		@return An ABTValue object, which is really an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.
 *		@return An ABTValue, which will be an ABTError if the call failed.
 */

   public ABTValue populate(IABTHashTable args)
      {
      ABTUserSession session = _mySpace.getUserSession();

     if ( (_isRemote && rdriver() == null) || (!_isRemote && cdriver() == null))
        return new ABTError(getClass(), "populate", errorMessages.ERR_INVALID_DRIVER,null);

      ABTValue retVal = null;

      if (_isRemote) {
         ABTObjectSpace ros = (ABTObjectSpace)_mySpace.getObject();

         ABTHashtable rht = null;
         ABTHashTable lht = null;
         if (args != null){
            lht = (ABTHashTable)args;
            rht = (com.abtcorp.core.ABTHashtable)lht.getObject();
            }
         retVal = ValueMunger.MarshalOut(_mySpace,rdriver().populate(ros, session, rht));
         }
     else {
         retVal = cdriver().populate(_mySpace, args);
        }
      
      /* if there's a debug monitor, tell it that a populate just finished */
      try{
         IABTAPIMonitor mon = _mySpace.getMonitor();
         if (mon != null && (retVal instanceof ABTValue)){
            mon.OnDriverPopulate(retVal);
            }
         }
      catch (Throwable e)// The debug monitor threw an exception.  Stop trusting it
         { _mySpace.setMonitor(null); }

      return  retVal;
      }

/**
 *		Save the ABTObjects identified in the ABTObjectSet object back to the data source.
 *		@param os  An ABTObjectSet object (an ABTValue implementation) which identifies the
 *    object(s) to be saved.  This can be the same object which was returned from the
 *    populate() method, but it need not be.
 *    @param criteria The target destination for the object set.
 *    Target is driver dependent and varies according to driver type. For example, a repository
 *    driver may specify which repository to save the object set to whereas a file driver may specify what
 *    file to save the objectset to.
 *		@return An ABTValue, which will be an ABTError if the call failed.
 */

   public ABTValue save(IABTHashTable args)
      {
      ABTUserSession session = _mySpace.getUserSession();

     if ( (_isRemote && rdriver() == null) || (!_isRemote && cdriver() == null))
        return new ABTError(getClass(), "save", errorMessages.ERR_INVALID_DRIVER,null);

      if (_isRemote) {
         ABTObjectSpace ros = (ABTObjectSpace)_mySpace.getObject();

         ABTHashtable rht = null;
         ABTHashTable lht = null;
         if (args != null){
            lht = (ABTHashTable)args;
            rht = (com.abtcorp.core.ABTHashtable)lht.getObject();
            }
         return ValueMunger.MarshalOut(_mySpace,rdriver().save(ros, session, rht));
        }
     else {
         return cdriver().save(_mySpace, args);
        }
      }

/**
 *    Perform miscellaneous, driver-specific operations
 *		@return An ABTValue object, which is really an ABTObjectSet.  The ABTObjectSet consists of
 *		of one or more ABTObjects, all of which were added to the ABTObjectSpace by this
 *		method.  The ABTObjectSet is returned to the caller so that it knows what ABTObjects
 *		were affected.
 *		@return An ABTValue, which will be an ABTError if the call failed.
 */

   public ABTValue execute(IABTHashTable args)
      {
      ABTUserSession session = _mySpace.getUserSession();
     if ( (_isRemote && rdriver() == null) || (!_isRemote && cdriver() == null))
        return new ABTError(getClass(), "execute", errorMessages.ERR_INVALID_DRIVER,null);

      if (_isRemote) {
         ABTObjectSpace ros = (ABTObjectSpace)_mySpace.getObject();

         ABTHashtable rht = null;
         ABTHashTable lht = null;
         if (args != null){
            lht = (ABTHashTable)args;
            rht = (com.abtcorp.core.ABTHashtable)lht.getObject();
            }
         return ValueMunger.MarshalOut(_mySpace,rdriver().execute(ros, session, rht));
        }
     else {
         return cdriver().execute(_mySpace, args);
        }
      }

/**
 *		Close a connection to a specific data source.
 *		@return An ABTValue, which will be an ABTError if the call failed.
 */

   public ABTValue close(IABTHashTable args)
      {
      ABTUserSession session = ((ABTObjectSpaceLocal)_mySpace).getUserSession();
     if ( (_isRemote && rdriver() == null) || (!_isRemote && cdriver() == null))
        return new ABTError(getClass(), "close", errorMessages.ERR_INVALID_DRIVER,null);

      if (_isRemote) {
         ABTObjectSpace ros = (ABTObjectSpace)_mySpace.getObject();

         ABTHashtable rht = null;
         ABTHashTable lht = null;
         if (args != null){
            lht = (ABTHashTable)args;
            rht = (com.abtcorp.core.ABTHashtable)lht.getObject();
            }
         return ValueMunger.MarshalOut(_mySpace,rdriver().close(ros, session, rht));
        }
     else {
         return cdriver().close(_mySpace, args);
        }
      }

}