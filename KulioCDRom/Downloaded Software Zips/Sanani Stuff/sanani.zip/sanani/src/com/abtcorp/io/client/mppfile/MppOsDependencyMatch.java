package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;

public class MppOsDependencyMatch extends UpdateIndicator
{

   private MppOsMatch      successorMatch_;
   private MppOsMatch      predecessorMatch_;
   private ABTValue        key_;
   private ABTValue        osKey_;
   private MppDependency   mppDependency_;

   MppOsDependencyMatch(MppOsMatch match, MppDependency  mppDependency)
   {

      successorMatch_ = match;
      key_ = new ABTInteger(mppDependency.successorMppTask_.getUniqueID()
                            ^mppDependency.getPredecessorUniqueId());

      mppDependency_       = mppDependency;
      predecessorMatch_    = null;
   }

   //get functions
   public MppOsMatch getSuccessorMatch()     {return successorMatch_;}
   public MppOsMatch getPredecessorMatch()   {return predecessorMatch_;}

   public Task          getMppSuccessor()    {return (Task)successorMatch_.getMppObject();}
   public Task          getMppPredecessor()  {return (Task)predecessorMatch_.getMppObject();}

   public IABTObject    getOsSuccessor()     {return successorMatch_.getOsObject();}
   public IABTObject    getOsPredecessor()   {return predecessorMatch_.getOsObject();}

   public MppDependency getMppDependency()   {return mppDependency_;}

   public ABTValue getKey()   {return     key_;}
   public ABTValue getOsKey() {return     osKey_;}

   //set functions
   public void     setSuccessorMatch(MppOsMatch inp)  {successorMatch_  = inp;}
   public void     setPredecessorMatch(MppOsMatch inp){predecessorMatch_= inp;}

   public void     setMppSuccessor(Task inp)          {successorMatch_.setMppObject(inp);}
   public void     setMppPredecessor(Task inp)        {predecessorMatch_.setMppObject(inp);}

   public void     setOsSuccessor(IABTObject inp)     {successorMatch_.setOsObject(inp);}
   public void     setOsPredecessor(IABTObject inp)
   {
      //*** has to be dealt with
      if(predecessorMatch_ != null) {predecessorMatch_.setOsObject(inp);}
   }

   public void     setMppDependency(MppDependency inp){mppDependency_   = inp;}

   public void setKey(ABTValue inp) {key_ = inp;}
}
