package com.abtcorp.hub;
/*
 * ABTTableRefClause.java 04/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 04-05-98	   HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  optimize with field-index access
  * 2-
  */



/**
 * Basic ABTTableRefClause class - base class for handling
 * dynamic (complex) values
 * An ABTTableRefClause has three parts, the key of the element,
 * the field to be accessed and the array of possible instances
 * <p>
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.core.ABTValue
 */



import java.util.*;
import com.abtcorp.core.*;

public class ABTTableRefClause extends ABTValue
{
   ABTArray instances;
   String   key;
   String   field;
   String reference;
   ABTUserSession  mySession = null;
   /**
   * class constructor for dynamic value
   * @param instances_ - operand
   * @param right - right operand
   * @param oper - operation to be performed
   */
   public ABTTableRefClause(ABTUserSession session,ABTArray instances_, String key_, String field_)
   {
      setInstances(instances_);
      setKey(key_);
      // SEPERATE FIELD AND REFERENCE
      int i = field_.indexOf('.');
      try
      {
        setField(field_.substring(0,i));
        setReference(field_.substring(i+1,field_.length()));
      }
      catch (Exception e)
      {
        setField("Unknown");
        setReference("Unknown");
      }          
      mySession = session;
   }

  /**
   * reset the instances reference
   * @param instances_ - operand
   */
   public void setInstances(ABTArray instances_)
   {
      instances = instances_;
   }

  /**
   * reset the key
   * @param key_ new key    
   */
   public void setKey(String key_)
   {
      key = key_;
   }

  /**
   * reset the field
   * @param field_ new field
   */
   public void setField(String field_)
   {
      field = field_;
   }
  /**
   * reset the reference
   * @param reference_ new reference
   */
   public void setReference(String reference_)
   {
      reference = reference_;
   }

  /**
   * get the instances reference
   * @return ABTArray -  instances_
   */
   public ABTArray getInstances()
   {
      return instances;
   }

  /**
   * get the key
   * @return String - key_
   */
   public String getKey()
   {
      return key;
   }
  /**
   * get the field
   * @return String -  field_
   */
   public String getField()
   {
      return field;
   }

   /**
   *  return the ABTObject currently in the instances
   *  @return ABTObject
   */
   public ABTValue lookup()
   {
        ABTObject o = (ABTObject)instances.at(0);
        if (o == null)
        return new ABTErrorCore( "ABTTableRefClause","lookup",
            "137",new ABTString(key));
        ABTValue val=  o.getValue(mySession,field,null);
        if (val == null) return ABTEmpty.getEmpty();
        if (ABTError.isError(val)) return val;
        if (!( val instanceof ABTObject))
            return new ABTErrorCore( "ABTTableRefClause","lookup",
            "138",new ABTString(key));
  
        ABTValue val1=  ((ABTObject)val).getValue(mySession,reference,null);
        if (val1 == null) return ABTEmpty.getEmpty();
        return val1;
   }


   /**
   *  evaluate the expression
   *  @return boolean
   */
   public boolean booleanValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.booleanValue();
      return super.booleanValue();
   }

   /**
   *  by default return the error code
   *  @return short
   */
   public short shortValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.shortValue();
      return super.shortValue();
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int intValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.intValue();
      return super.intValue();
   }

   /**
   *  by default return the error code
   *  @return double
   */
   public double doubleValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.doubleValue();
      return super.doubleValue();
   }

   /**
   *  by default return null
   *  @return Date
   */
   public ABTDate dateValue(boolean pm)
   {
      ABTValue val = lookup();
      if (val != null)
        return val.dateValue(pm);
      return super.dateValue(pm);
   }

   /**
   *  by default return the true/false
   *  @return String
   */
   public String stringValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.stringValue();
      return super.stringValue();
   }

   /**
   *  by default return the time this thing was created
   *  @return ABTTime
   */
   public ABTTime timeValue()
   {
      ABTValue val = lookup();
      if (val != null)
        return val.timeValue();
      return super.timeValue();
   }

   /**
   *  by default return the error code
   *  @return int
   */
   public int hashCode()
   {
      ABTValue val = lookup();
      if (val != null)
         return val.hashCode();
      return super.hashCode();
   }

   /**
   *  compare to ABTTableRefClauses: first use the errorcode and (if not available)
   *  use the error message
   *  @param object - to compare me to
   *  @return int (0=equal, -1/+1 as usual)
   */
   public int compareTo(Object object)
   {
      if (object == null) return 1;     
      ABTValue val = lookup();
      if (val != null)
          return val.compareTo(object);
      else
          if (object == null)
             return 0;
          else
             return 1;
   }
}
