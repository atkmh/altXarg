/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.com;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;

import com.ms.com.Variant;

public class ABTObjectCOM implements IABTObjectCOM
{
   public ABTObjectCOM(IABTObject obj) {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(obj);
      /**/
     }
   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return super.toString();};
   public String ToString()    { return super.toString();};
   public int  getHashCode()   { return super.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   private IABTObject _obj;
   private IABTObject obj() {
      if (_obj == null) _obj = (IABTObject)getObject();
      return _obj;
      }

   public IABTObjectSpaceCOM getObjectSpace(){
      IABTObjectSpace os = obj().getObjectSpace();
      IABTObjectSpaceCOM retVal = new ABTObjectSpaceCOM(os);
      return retVal;
      }

   public Variant setWithParameters(String fieldName, IABTHashTableCOM parameters, Variant newValue){
      IABTHashTable params = (IABTHashTable)parameters.getObject();
      ABTValue v = obj().setWithParameters(fieldName, VariantMunger.VariantToValue(newValue), params );
      return VariantMunger.ValueToVariant(v);
      }

   public Variant getWithParameters(String fieldName, IABTHashTableCOM parameters){
      IABTHashTable params = (IABTHashTable)parameters.getObject();
      ABTValue val = obj().getWithParameters(fieldName, params );
      return VariantMunger.ValueToVariant(val);
      }

   public Variant Delete(){
      return VariantMunger.ValueToVariant(obj().delete());
      }

  public Variant setValue(String fieldName, Variant newValue) {
      ABTValue v = obj().setValue(fieldName, VariantMunger.VariantToValue(newValue));
      return VariantMunger.ValueToVariant(v);
      }

  public Variant getValue(String fieldName) {
      return VariantMunger.ValueToVariant(obj().getValue(fieldName));
      }

  public IABTPropertyCOM getProperty(String fieldName) {
      IABTProperty p = obj().getProperty(fieldName);
      if (p != null)
         return new ABTPropertyCOM(p);
      else
         return null;
      }

   public IABTPropertySetCOM getProperties()  {
      return new ABTPropertySetCOM(obj().getProperties());
      }

   public String getObjectType()  {
      return obj().getObjectType();
      }

    /**
   * return the object dependant value for property-field by key
   */
   public Variant getPropertyKey(String property, int key) {
	    return VariantMunger.ValueToVariant(obj().getPropertyKey(property, key));
      }

   public Variant isEmpty(String property){
	    return VariantMunger.ValueToVariant(obj().isEmpty(property));
      }

   public Variant setValues(IABTHashTableCOM pairs) {
      IABTHashTable ht = (IABTHashTable)((ABTHashTableCOM)pairs).getObject();
      ABTValue v = obj().setValues(ht);
      return VariantMunger.ValueToVariant(v);
      }

   public IABTArrayCOM getValues(IABTArrayCOM properties){
      IABTArray ar = (IABTArray)((ABTArrayCOM)properties).getObject();
      ABTValue x  = obj().getValues(ar);
      if (x instanceof ABTError) return null;
      return new ABTArrayCOM((IABTArray)x);
      }

   public IABTLocalIDCOM getID() {
      return new ABTLocalIDCOM(obj().getID());
      }

   public boolean isDeleted() {
      return obj().isDeleted();
      }

   /**
   * Add a specific listener to the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param property name of property or null all
   */
   public void addListener(int action, IABTListenerCOM listener,String propertyName){
      }

  /**
   * Remove a specific listener from the row referenced by this object
   * @param listener implementation of the IABTListener-interface
   * @param propertyIndex index of property of -1 for all
   */
   public void removeListener(IABTListenerCOM listener,String propertyName){
      }

  /**
   * Remove a all listenedTo for the caller
   * @param listener caller who wants to be removed from the the listenerlist
   */
   public void removeListeners(IABTListenerCOM listener){
      }
}
