package com.abtcorp.io.team;

import java.io.Serializable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.URL;

import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTObject;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTID;

import com.abtcorp.core.ABTComparable;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

public class RemoteID extends ABTRemoteID implements Serializable, ABTComparable, IABTTWRuleConstants
{
   private static final long serialVersionUID = 3058334354046639824L;
   protected InetAddress  host_;
   protected long         time_;
   protected int          id_;
   protected long         timestamp_; // Used for modification comparisons. Not used during equality or object comparisons.

   private static InetAddress       local_     = null;
   private static long              startTime_ = System.currentTimeMillis();
   private static int               lastID_    = 0;
   private static Object            mutex_     = new Object();

   private void generate()
   {
      synchronized(mutex_) {
         host_ = local_;
         time_ = startTime_;
      	id_   = lastID_++;
      }
   }

   public static void setHostAddress(InetAddress address)
   {
      local_ = address;
   }

   public static InetAddress getHostAddress() {return local_;}

   public RemoteID() {generate();}

   public int getKnownID()
   {
      if (host_ == null) return id_;
      else               return 0;
   }

   public RemoteID(int id)
   {
      if (id == 0) generate();
      else {host_ = null; time_ = 0; id_ = id;}
   }

   public int hashCode() {return (int)time_ + id_;}

   public boolean equals(Object object)
   {
	   if (object != null && object instanceof RemoteID) {
         RemoteID uid = (RemoteID)object;

         if (host_ == null && uid.host_ == null) return id_ == uid.id_;
         if (host_ == null || uid.host_ == null) return false;

         return host_.equals(uid.host_) && time_ == uid.time_ && id_ == uid.id_;
      } else return false;
   }

   public int compareTo(Object object)
   {
      RemoteID uid = (RemoteID)object;

      if (host_ != null || uid.host_ != null) {
         // KIDs (known ids) before UIDs

         if (host_     == null) return -1;
         if (uid.host_ == null) return +1;

         // order by InetAddress first

         if (! host_.equals(uid.host_)) return host_.hashCode() - uid.host_.hashCode();

         // then by time

         if (time_ < uid.time_) return -1;
         if (time_ > uid.time_) return +1;

         // fall thru if (same host and time)
      }

      // order by id

      return id_ - uid.id_;
   }

   public String toString()
   {
      if (host_ == null) return String.valueOf(id_);

      return host_.getHostName() + ":" + hashCode();
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      host_ = (InetAddress)stream.readObject();

      if (host_ != null) {
         if (host_.equals(local_)) host_ = local_;

         time_ = stream.readLong();
      }

      id_ = stream.readInt();
      timestamp_ = stream.readLong();
   }

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeObject(host_);

      if (host_ != null) stream.writeLong(time_);

      stream.writeInt(id_);
      stream.writeLong(timestamp_);
   }

   public InetAddress getHost() {return host_;}

   public int getID() {return id_;}

   protected void mergeId(RemoteID uid)
   {
      host_ = uid.host_;
      id_   = uid.id_;
   }

   public void setHost(InetAddress host) {host_ = host;}
   public void setId(int id)             {id_ = id;}

   public long getTimeStamp()            {return timestamp_;}
   public void setTimeStamp(long timestamp) {timestamp_ = timestamp;}
   public void timeStamp()
   {
      timestamp_ = BaseTime.getBaseTime() + BaseTime.getElapsedTime();
   }
   
   public static void setRemoteID(ABTObject object, ABTUserSession session)
   {
      ABTID id = object.getID();
      RemoteID remoteid = new RemoteID(object.getValue(session,FLD_TW_ID).intValue());
      remoteid.timeStamp();
      id.setRemote(session,remoteid);
   }
 
   public static void timeStamp(IABTObject object)
   {
      if (object == null) return;
      
      IABTLocalID id = object.getID();
      try {
         RemoteID remote = (RemoteID)id.getRemote();
         remote.timeStamp();
      } catch (ClassCastException e) {
      }
   }

   public static void setRemoteID(IABTObject object)
   {
      if (object == null) return;
      
      IABTLocalID id = object.getID();
      RemoteID remoteid = new RemoteID(object.getValue(FLD_TW_ID).intValue());
      remoteid.timeStamp();
      id.setRemote(remoteid);
   }

   public static String formatID(int taskid)
   {
      String str = null;
      try {
         if (local_ == null) RemoteID.setHostAddress(InetAddress.getLocalHost());

         int hash = local_.hashCode();
         str = new String(Integer.toHexString(hash) + taskid);
      } catch (Exception e) {
         str = " ";
      }
      return str;
   }
}