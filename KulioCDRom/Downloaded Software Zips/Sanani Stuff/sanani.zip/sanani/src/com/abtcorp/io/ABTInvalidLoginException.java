package com.abtcorp.io;

import com.abtcorp.core.ABTException;

public class ABTInvalidLoginException extends ABTException
{
   public ABTInvalidLoginException(String s) {super(s);}
   // TODO: Localization issue with the exception message!
   public ABTInvalidLoginException() {super("Invalid repository login");}
}
