/*
 * AggregateField.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date          Author       Description
  * 06-05-98      LZX          Initial implementation.
  *
  */

package com.abtcorp.objectModel.abt;

import  com.abtcorp.objectModel.*;
import  com.abtcorp.core.*;
import  com.abtcorp.hub.*;

/**
 * AggregateField is the object rule class that handles the methodology aggregate field business rules.
 *
 *
 * @version	1.0
 * @author      L. Xiao
 */

public class AggregateField extends SiteRule
{

  /**
   * Default Constructor
   */
   public AggregateField()
   {
      super();
   }

   /**
   * sets default properties for the methodology aggregate field object.
   */
   protected void setDefaultProperties()
   {
      //
      // Relationship Properties
      //
      addProperty( OFD_SOURCEFIELD, OFD_SOURCEFIELD_CAP, PROP_OBJECT, false, true, true, false,  OBJ_CUSTOMFIELD, FR_DISALLOWRESET, null );
      addProperty( OFD_TARGETFIELD, OFD_TARGETFIELD_CAP, PROP_OBJECT, false, true, true, false,  OBJ_CUSTOMFIELD, FR_DISALLOWRESET, null );

      //
      // Field Properties
      //
      addProperty( OFD_SOURCEFIELDID, OFD_SOURCEFIELDID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_TARGETFIELDID, OFD_TARGETFIELDID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_WEIGHT, OFD_WEIGHT_CAP, PROP_SHORT, false, true, true, false, null, null, new ABTShort((short)1) ); // default to 1
   }

   /**
    * Rules to invoke when an aggregate field object is created.
    *<ul>
    *<li>Enforces that the following parameters have been included in requiredParameters:
    *<ul>       OFD_SOURCEFIELD     (reference to the source custom field)</ul>
    *<ul>       OFD_TARGETFIELD     (reference to the target custom field)</ul>
    *<li>Set the OFD_SOURCEFIELD reference and add to its OFD_AGGREGATEFIELDS list this aggregate field
    *<li>Set the OFD_TARGETFIELD reference and add to its OFD_AGGREGATEFIELDS list this aggregate field
    *</ul>
    *
    * @param session             the session object for transaction support
    * @param object              the new object being created
    * @param requiredParameters  hash table containing the required parameters
    *
    * @return ABTValue returns any <code>ABTError</code> that may have been encountered
    *                    while accessing or setting properties.
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTHashtable requiredParameters )
   {
      String caller = "abt.AggregateField->onInitialize";
      // set required parameter source custom field reference and add this aggregate field object to the aggregate field
      // list of the referenced source custom field.
      ABTValue v = super.setReqParm( session, object, requiredParameters, OFD_SOURCEFIELD, OFD_AGGREGATEFIELDS, caller );
      if( ABTError.isError( v ) )
         return v;

      // set required parameter target custom field reference and add this aggregate field object to the aggregate field
      // list of the referenced target custom field.
      return super.setReqParm( session, object, requiredParameters, OFD_TARGETFIELD, OFD_AGGREGATEFIELDS, caller );

   }

   /**
    * Rules to invoke when an aggregate field object is deleted.
    *<ul>
    *<li>Remove it from the OFD_AGGREGATEFIELDS list of the referenced OFD_SOURCEFIELD.
    *<li>Remove it from the OFD_AGGREGATEFIELDS list of the referenced OFD_TARGETFIELD.
    *</ul>
    * @param session    the session object for transaction support
    * @param parent     the object to be removed
    * @return ABTValue  check for ABTError....
    */
   protected ABTValue onDelete( ABTUserSession session, ABTObject parent )
   {
      String caller = "abt.AggregateField->onDelete";
      // Get the source custom field and remove from it's aggregate field list this aggregate field
      ABTValue v = removeFromList( session, parent, OFD_SOURCEFIELD, OFD_AGGREGATEFIELDS, caller );
      if( ABTError.isError( v ) )
         return v;

      // Get the target custom field and remove from it's aggregate field list this aggregate field
      v = removeFromList( session, parent, OFD_TARGETFIELD, OFD_AGGREGATEFIELDS, caller );
      if( ABTError.isError( v ) )
         return v;

      // delete the aggregate field object itself
      return deleteObject( session, parent );
   }
}
