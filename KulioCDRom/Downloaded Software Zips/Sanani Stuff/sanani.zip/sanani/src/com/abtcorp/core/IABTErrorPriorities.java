package com.abtcorp.core;

public interface IABTErrorPriorities{
    // static priority levels
    public static final int ADVISORY_ONLY = 0;
    public static final int RECOVERABLE_ERROR = 1;
    public static final int UNRECOVERABLE_ERROR = 2;
}
