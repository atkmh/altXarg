package com.abtcorp.hub;

/*
 * ABTOSet.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.*;
import com.abtcorp.parser.*;
import java.util.Enumeration;
import java.lang.Math;

/**
 * ObjectSet contains the functionallity needed to manage a
 * list of BOs and implements ABTValue
 * <p>
 * @see com.abtcorp.hub.ABTValue
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         <path to another class> %%%%% cross reference
 */
class ABTOSet implements IABTTransactionData
{
   public final static int DATA_ACTIVE = 0;
   public final static int DATA_ALL = 1;
   public final static int DATA_DELETED = 2;
   protected int level = -1;
    //   private ABTArray data;
   protected ABTArray data;
//   private ABTArray data;
   protected ABTArray deletedData;

   protected ABTArray getData()
   {
    return data;
   }
   protected ABTArray getDeletedData()
   {
    return deletedData;
   }
   protected void clearDeletedData()
   {
      deletedData = new ABTArray();
   }
   protected void setDeletedIDs(ABTArray deletedElements)
   {
      deletedData = new ABTArray();
   }
   protected void setLevel(int newLevel)
   {
    level = newLevel;
   }
   protected int getLevel()
   {
    return level;
   }

   protected ABTOSet(ABTArray data_)
   {
      data = data_;
      deletedData = new ABTArray();
   }

   protected ABTOSet()
   {
      data = new ABTArray();
      deletedData = new ABTArray();
   }

   protected ABTOSet(ABTOSet oldSet)
   {
      if (oldSet.data != null)
         data = new ABTArray(oldSet.data);
      else
         data = new ABTArray();
      if (oldSet.deletedData != null)
         deletedData = new ABTArray(oldSet.deletedData);
      else
         deletedData = new ABTArray();;
   }
   protected void add (ABTObject object)
   {
      data.add(object);
   }
   protected int indexOf( ABTObject object)
   {
      return data.indexOf(object);
   }

   protected ABTValue remove(ABTObject object,ABTRemoteID remoteID)
   {
       data.remove(object);

       if (remoteID != null)
           deletedData.add(remoteID);
       return object;
   }

/*   protected synchronized void commit(ABTUserSession session )
   {
    for (int i = 0; i < deletedData.size();i++)
    {
        if (deletedData.at(i) instanceof ABTObject)
           if ( ((ABTObject) deletedData.at(i)).getRemoteID(session) != null)
              deletedData.put(i,((ABTObject) deletedData.at(i)).getRemoteID(session));
    }
   }
*/
  protected boolean isEmpty(boolean active)
    {
        if (active)
        {
           return data.isEmpty();
        }
        else
        {
           return deletedData.isEmpty();
        }
    }
    protected int size(boolean active)
    {
        if (active)
        {
           return data.size();
        }
        else
        {
           return deletedData.size();
        }
    }

   protected ABTValue at(boolean active, int index)
   {
    if (active)
    {
       return (ABTObject)data.at(index);
    }
    else
    {
       return (ABTRemoteID)deletedData.at(index);
    }
   }
   
   protected void clear()
   {
    data.clear();
    deletedData.clear();
   }
/**
   * Return true if I contain the same items in the same order as
   * another ObjectSet. Use equals() to compare the individual elements.
   * @param objectSet The Objectset to compare myself against.
   */
   public synchronized boolean equals( ABTOSet objectSet )
   {
      return data.equals(objectSet.data);
   }

   protected void copy(ABTOSet orgData)
   {
        data.copy(orgData.data);
        deletedData.copy(orgData.deletedData);
   }

   /*
   * return ABTArray-clone of my data
   * @return
   */
   protected ABTArray cloneData(int type)
   {
      switch (type)
      {
         case DATA_ACTIVE:
            return new ABTArray(data);
         case DATA_ALL: // all data including deleted
            ABTArray ar = (ABTArray)data.clone();
            ar.addArray(deletedData);
            return ar;
         case DATA_DELETED:
            return  new ABTArray(deletedData);
         default:
            return new ABTArray(data);
      }
   }

      public IABTTransactionData rollUp(IABTTransactionData target)
      {
        return this;
      }

      public IABTTransactionData copyData()
      {

         return new ABTOSet(this);
     }

}



