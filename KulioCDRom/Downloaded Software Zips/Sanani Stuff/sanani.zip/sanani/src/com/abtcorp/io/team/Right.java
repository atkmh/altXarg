package com.abtcorp.io.team;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;

public class Right implements ABTNames, ABTComparable
{
	private String name_;
	private String table_;
	private int userid_;
	private int record_;
	private int repository_;
	
	public Right(String name, String table, int userid, int record, int repository) 
	{
		name_ = name;
		table_ = table;
		userid_ = userid;
		record_ = record;
		repository_ = repository;
   }
   
   public String getName() {return name_;}
   public String getTable() {return table_;}
   public int getUserID() {return userid_;}
   public int getRecord() {return record_;}
	public int getRepository() {return repository_;}
   
   // Sort by the name of the right.
   public int compareTo(Object object)
   {
   	int compare = 0;
   	if (object instanceof Right) {
   		if (name_ == null) compare = -1;
   		if (((Right)object).name_ == null) compare = 1;
   		compare = name_.compareTo(((Right)object).name_);
   	} else compare = -1;
   	return compare;
   	
   }
	
	public boolean equals(Object object)
   {
   	if (object instanceof Right) {
   	   Right r = (Right)object;
   		if (name_.equals(IS_SUPERUSER)) {
   			if (name_.equals(r.getName()) && userid_ == r.getUserID()) return true;
   		}
   	   
   		if (table_ == null) {
      		if (name_.equals(r.getName()) && userid_ == r.getUserID() && repository_ == r.getRepository() && r.getTable() == null) return true;
   		} else {
   			if (name_.equals(r.getName()) && userid_ == r.getUserID() && repository_ == r.getRepository() && table_.equals(r.getTable())) return true;
   		}
   	}
   	return false;
   }
	
	public String toString()
   {
   	return new String("Right: " + name_ + " " + table_ + " " + userid_ + " " + record_ + " " + repository_);
   }
}