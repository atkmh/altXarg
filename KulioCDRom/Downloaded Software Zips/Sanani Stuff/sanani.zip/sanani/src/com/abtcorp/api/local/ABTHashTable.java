/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.local;

import com.abtcorp.api.ABTSessionObject;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObjectSpace;

public class ABTHashTable extends ABTSessionObject implements IABTHashTable
{
   protected ABTHashTable(){
      this((ABTSessionObject)null, new ABTHashtable());
      }

   // Constructs a new hashtable with a given initial capacity
   protected ABTHashTable(int initialCapacity, float loadFactor) {
      this((ABTSessionObject)null, initialCapacity, loadFactor);
      }

   // Constructs a new hashtable given an object space
   protected ABTHashTable(ABTSessionObject s) { this(s, new ABTHashtable());  }

   // Constructs a new hashtable given an object space with a given initial capacity
   protected ABTHashTable(ABTSessionObject s,int initialCapacity, float loadFactor) {
      this(s, new ABTHashtable(initialCapacity, loadFactor));
      }


   // Wrap an internal com.abtcorp.core.ABTHashtable for presentation to clients
   protected ABTHashTable(ABTSessionObject s, com.abtcorp.core.ABTHashtable ht) {
      super(s,ht);
      _ht = ht;
      }

   protected ABTValue setObjectSpace(ABTObjectSpaceLocal os){
      setUserSession(os.getUserSession());
      setHubObjectSpace((ABTObjectSpace)os.getObject());
      return null;
      }

   private com.abtcorp.core.ABTHashtable _ht;
   private com.abtcorp.core.ABTHashtable ht() {
      return _ht;
      }

   public IABTObjectSpace getObjectSpace(){
      return new ABTObjectSpaceLocal(this);
      }

   public boolean containsKey(ABTValue key)  {
      return ht().containsKey(key);
      }

   public boolean containsValue(ABTValue key)  {
      return ht().contains(key);
      }

   public boolean isEmpty() {
      return ht().isEmpty();
      }

   public int size() {
      return ht().size();
      }

   public void clear() {
      ht().clear();
      }

   public ABTValue remove(ABTValue obj) {
      return (ABTValue)ht().remove(obj);
      }

   public IABTEnumerator getElements()  {
      return new enumer(this,ht().elements());
      }

   public IABTEnumerator getKeys() {
      return new enumer(this, ht().keys());
      }

   public ABTValue getItemByKey(ABTValue key)  {
      try {
         ABTValue _key = (ABTValue)ValueMunger.MarshalIn(this, key);
         ABTValue V1 = (ABTValue)ht().get(_key);
         return ValueMunger.MarshalOut(this,V1);
         }
      catch (Exception e){
         return new ABTError(getClass(), "getItemByKey", errorMessages.ERR_EXCEPTION, e);
         }
      }

   public ABTValue getItemByInt(int key)  {
      try {
         return ValueMunger.MarshalOut(this,(ABTValue)ht().getItemByInt(key));
         }
      catch (Exception e){
         return new ABTError(getClass(), "getItemByInt", errorMessages.ERR_EXCEPTION, e);
         }
      }

   public ABTValue getItemByString(String key) {
      try {
        return ValueMunger.MarshalOut(this,(ABTValue)ht().getItemByString(key));
         }
      catch (Exception e){
         return new ABTError(getClass(), "getItemByString", errorMessages.ERR_EXCEPTION, e);
         }
     }

   public ABTValue putItemByKey(ABTValue key, ABTValue value)  {
      try {
         if (!hasSession())  TrySessionValue(value);
         ABTValue _key = (ABTValue)ValueMunger.MarshalIn(this, key);
         ABTValue _val = (ABTValue)ValueMunger.MarshalIn(this, value);
         ABTValue V1 = (ABTValue)ht().put(_key, _val);
         return ValueMunger.MarshalOut(this,V1);
         }
      catch (Exception e){
         return new ABTError(getClass(), "putItemByKey", errorMessages.ERR_EXCEPTION, e);
         }
      }

   public ABTValue putItemByInt(int key, ABTValue value)  {
      try {
         if (!hasSession())  TrySessionValue(value);
         ABTValue _val = (ABTValue)ValueMunger.MarshalIn(this, value);
         ABTValue V1 = (ABTValue)ht().putItemByInt(key, _val);
         return ValueMunger.MarshalOut(this,V1);
         }
      catch (Exception e){
         return new ABTError(getClass(), "putItemByInt", errorMessages.ERR_EXCEPTION, e);
         }
      }

   public ABTValue putItemByString(String key, ABTValue value) {
      try {
         if (!hasSession())  TrySessionValue(value);
         ABTValue _val = (ABTValue)ValueMunger.MarshalIn(this, value);
         ABTValue V1 = (ABTValue)ht().putItemByString(key, _val);
         return ValueMunger.MarshalOut(this,V1);
         }
      catch (Exception e){
         return new ABTError(getClass(), "putItemByString", errorMessages.ERR_EXCEPTION, e);
         }
     }


   // This will try to 'steal' the session context from an ABTValue
   // It is useful when a client creates a new hashtable without a session,
   // and then adds a session-wrapped object to it.
   private boolean TrySessionValue(ABTValue val){
      if (val instanceof ABTSessionObject){
         ABTSessionObject Sval = (ABTSessionObject)val;
         setUserSession(Sval);
         return true;
         }
      return false;
      }

   private class enumer implements com.abtcorp.idl.IABTEnumerator
      {
      java.util.Enumeration _enumer;
      ABTSessionObject _so;
      public enumer(ABTSessionObject so,java.util.Enumeration en) {
         _so = so;
         _enumer = en;
         }
      public boolean hasMoreElements() { return _enumer.hasMoreElements(); }
      public ABTValue nextValue() {
         Object ne = _enumer.nextElement();
         if ( !(ne instanceof ABTValue) )
            return new ABTError(getClass(), "nextValue", errorMessages.ERR_INVALID_VALUE, ne);
         return (ABTValue)ne;
         }
      public Object nextElement() {
         Object it = _enumer.nextElement();
         if (it instanceof ABTValue)
            return ValueMunger.MarshalOut(_so,(ABTValue)it);
         return it;
         }
      }

}