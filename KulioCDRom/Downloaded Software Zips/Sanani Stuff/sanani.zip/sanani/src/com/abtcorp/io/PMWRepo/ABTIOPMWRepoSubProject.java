package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoSubProject.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-12-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-08-98    SOB            Changed OFD_PROJECT to OFD_SUBPROJECT and OFD_TASK to OFD_SUBTASK
 * 07-09-98    SOB            transaction support
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support required params for object creation
 * 07-22-98    SOB            Mods to support save() processing
 * 08-31-98    SOB            Mods to support thinly populated projects
 * 09-28-98    SOB            Mods to support new RMS 5.0 subproject data model
 * 10-09-98    SOB            Beginnings of progress reporting
 * 11-03-98    SOB            Mods to support new interproject dependency logic
 * 12-14-98    SOB            #667
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoSubProject is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTSubProject object in the object space.
 *  <pre>
 *       ABTIOPMWRepoSubProject rd = new ABTIOPMWRepoSubProject(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoSubProject extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private ABTObjectSet splos_;
   private Hashtable th_ = null;
   private boolean parentLockAcquired_ = false;
   private boolean relaxSubprojectLocking_ = false;
   private static final String FLD_PROJECTEXTID = "ProjectExtID".intern();


   public ABTIOPMWRepoSubProject() {/*implicit call to super() here*/}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoSubProject(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable th,
                       boolean parentLockAcquired,       /* #667 */
                       boolean relaxSubprojectLocking,   /* #667 */
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_SUBPROJECT, OBJ_SUBPROJECTLINK, progress);
      projObj_ = projObj;
      projectID_ = projID;
      th_ = th;
      parentLockAcquired_ = parentLockAcquired;           /* #667 */
      relaxSubprojectLocking_ = relaxSubprojectLocking;   /* #667 */

      //
      // Now obtain the propert index vector for subproject link objects.  We need to update
      // the property flags of the subproject link to bypass reading the ISIPD (is-interproject-dependency)
      // field.  That field is marked non-updateable in subproject link objects. Later, in the
      // isPopulateException() method, the flag will be tested.
      //
      Vector piv = getPropertyIndexVector(ps_);
      int size = piv.size();
      for (int i = 0; i < size; i++)
      {
         PropertyIndex pi = (PropertyIndex) piv.elementAt(i);
         if (pi.prapiName_.equals(FLD_ISIPD))
         {
            pi.propertyFlags_ += FLAG_SKIP_READ;
         }
      }
   }

   /**
    *    Constructs a helper object to save subproject link objects to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepository reference
    *    @param a Project object reference
    *    @forceAddNew true if an addNew() operation is being forced to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoSubProject(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_SUBPROJECT, OBJ_SUBPROJECTLINK, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates an object space with subproject link objects for a given project
    *    @param parms (not currently used)
    *    @return null
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object;

      try
      {
         getCursor();

      	while (cursor_.moveNext())		// for every subproject entry in the result set...
      	{
            //
            // Create a remote ID for this subproject object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the subproject link object already exists in the object space.
            //
            object = find(OBJ_SUBPROJECTLINK, id_);

            //
            // If the object found is an ABTObject, then the subproject link object was found
            // in the object space.  Update (merge) its properties with those from the
            // repository.
            //
            // Otherwise, create a new subproject link object in the object space and
            // initialize its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray prms = new ABTArray();
               prms.add(object);      // identify the subproject link object for update()
               object = update(prms);
            }
            else
            {
               object = create(null);
            }
      	}           // end while (cursor_.moveNext())
      }              // end try
      finally
      {
         closeCursor();
      }

      return null;
   }

   /**
    *    Creates a new subproject link object.  The setReferences() method invocation
    *    causes the subproject to be read in from the repository (if it does not already
    *    exist in the space).
    *    @param parms (currently not used)
    *    @return the newly-created subproject link object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Get the associated proxy task object reference for this subproject link object.
      // Lookup the associated project task in the task hash table.
      //
      Long proxyTaskID = new Long(cursor_.getFieldInt(FLD_TASKID));
      ABTObject proxyTask = (ABTObject) th_.get(proxyTaskID);

      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_TASK, proxyTask);
      boolean isIPD = cursor_.getFieldBoolean(FLD_ISIPD);
      reqparms.putItemByString(OFD_ISIPD, new ABTBoolean(isIPD) );

      //
      // Ask the object space to create a new subproject link object.
      //
      ABTObject object = createObject(OBJ_SUBPROJECTLINK, id_, reqparms);

      //
      // Initialize repository properties of the new subproject link object.
      //
      setValues((ABTObject) object);
      setReferences((ABTObject) object);

      return object;
   }

   /**
    *    Updates an existing subproject link object.  The setReferences() method invocation
    *    causes the subproject to be read in from the repository (if it does not already
    *    exist in the space).
    *    @param parms the existing subproject link object
    *    @return the updated subproject link object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(object);

      //Also set the subproject references.
      //
      setReferences(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
      //
      // Set the property values from the repository subproject table tuple into the
      // subproject link object.
      //
      setPropertyValues(ps_, cursor_, obj);

   }

   private void setReferences(ABTObject obj) throws ABTException
   {
      //
      // Set the OFD_SUBPROJECT and OFD_SUBTASK properties initially to null.  If the subproject
      // link is valid (i.e., not broken), then one of the properties will be set appropriately
      // and OFD_SUBPROJECTTYPE will contain an indication  of which property is valid.
      // If the link turns out to be broken, then the properties will remain null and the
      // OFD_SUBPROJECTTYPE will indicate UNKNOWN_TYPE.
      //
      setValue(obj, OFD_SUBPROJECT, null);
      setValue(obj, OFD_SUBTASK, null);
      setValue(obj, OFD_SUBPROJECTTYPE, new ABTInteger(UNKNOWN_TYPE));

      //
      // Get the link ID of the subproject.  If we can't get the link ID, then the link is
      // broken and all we can do is return.
      //
      long  linkID = getLinkID(obj);
      if (linkID < 0) return;

      //
      // If the OFD_TASKEXTID property of the subproject link object is zero or null, then the value
      // in the linkID variable represents a project level reference.  Otherwise, the subproject
      // object represents a task reference and linkID represents the project prID of that task.
      //
      // TO DO:  For better performance, only load that portion of the subproject which is
      //         actually required.  That may be only one task object for the project.
      //
      // For now, populate the entire subproject if the reference is project-level.  If the
      // subproject is a reference to a task, then find that task using an SQL query into the
      // repository.  Fully populate the subproject, but only if the referenced task is found
      // in the repository and is a task of the subproject.  Mark the subproject as readonly or
      // read/write as indicated by the OFD_ISREADONLY property.
      // Do not acquire the import/export lock.
      //
      String taskExtID = "";
      ABTValue v = getValue(obj, OFD_TASKEXTID);
      if (!ABTValue.isNull( v ) )
         taskExtID = ((ABTString)v).stringValue().trim();  // get rid of leading/trailing blanks

      //
      // If the parent (master) project was NOT acquired with a lock, then this subproject need
      // not have a lock acquired for it, either.  If the parent project WAS acquired with a lock,
      // then the OFD_ISREADONLY property of the subprojectlink object identifies whether or not
      // to attempt lock acquisition for the subproject.
      // If the subprojectlink object indicates that it only needs the subproject to be populated
      // as READONLY, then indicate that to the project populator object.  The project may already
      // be populated as READ/WRITE, which is okay.
      //
      boolean getLock;
      if ( !parentLockAcquired_ )   /* #667 */
         getLock = false;
      else
      {
         v = getValue(obj, OFD_ISREADONLY);
         getLock = (ABTValue.isNull( v )) ? false : v.booleanValue() ? false : true;
      }
      ABTValue proj;
      if (taskExtID.length() == 0)
      {
         ABTProjectPopulator pp = new ABTProjectPopulator(driver_,
                                                          new ABTInteger((int)linkID),
                                                          PM_GETPROJECTFULL,
                                                          getLock,                     /* #667 */
                                                          relaxSubprojectLocking_,     /* #667 */
                                                          progress_);
         proj = pp.populate();
         if (!ABTError.isError(proj))
         {
            setValue(obj, OFD_SUBPROJECT, proj);
            setValue(obj, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));
         }
      }
      else
      {
         //
         // Get the prID of the subproject's task object because this subproject is a task
         // reference.
         //
         long taskID = getTaskID(taskExtID, linkID);
         if (taskID < 0) return;    // oops! broken link

         //
         // Now populate the subproject.
         //
         ABTProjectPopulator pp = new ABTProjectPopulator(driver_,
                                                          new ABTInteger((int)linkID),
                                                          PM_GETPROJECTFULL,
                                                          getLock,                    /* #667 */
                                                          relaxSubprojectLocking_,    /* #667 */
                                                          progress_);
         proj = pp.populate();

         //
         // If no populate errors occurred, find the task and set its reference in the subproject
         // link object.
         //
         if (!ABTError.isError(proj))
         {
            ABTRemoteIDRepository id = new ABTRemoteIDRepository(driver_.getRepository().getID(),
                                                                 taskID);
            ABTValue task = driver_.getSpace().findObject(driver_.getUserSession(), OBJ_TASK, id);
            if (task instanceof ABTObject)
            {
               setValue(obj, OFD_SUBTASK, task);
               setValue(obj, OFD_SUBPROJECTTYPE, new ABTInteger(TASK_TYPE));
               setValue(projObj_, OFD_RESOLVEIPD, proj);
            }
         }     // end if (!ABTError.isError(proj))
      }        // end if (taskExtID.length() == 0)

   }

   private void getCursor()
   {
      closeCursor();

      //
      // Select the project's subprojects.  The following SQL query and associated andFilter
      // were lifted from the PVision C++ code for export/import.
      //
      cursor_ = repo_.select(QRY_PROJECTSUBPROJECTS);
      cursor_.andFilter(TBL_TASK + "." + FLD_PROJECTID + " = " + projectID_);
   }

   private long getLinkID(ABTObject obj) throws ABTException
   {
      //
      // If the OFD_PROJECTEXTID property of the input subproject link object is not null,
      // that value is the external ID of the project that is needed.  Get the ID of the project
      // by doing an SQL lookup of the project.  Otherwise, return -1, which signifies that the
      // link is broken.
      //
      ABTValue v = getValue(obj, OFD_PROJECTEXTID);
      if (ABTValue.isNull( v ) )
         return -1;
      String extID = ((ABTString)v).stringValue().trim();  // get rid of leading/trailing blanks
      if (extID.length() == 0)
         return -1;

      ABTRepository repo = driver_.getRepository();
      ABTCursor spCursor = repo.select(TBL_PROJECT);
      spCursor.andFilter(TBL_PROJECT + "." + FLD_EXTERNALID + " = " + repo_.sqlString( extID ) );

      ABTValue linkID = null;
      try
      {
         if (spCursor.moveFirst())
         {
            linkID = spCursor.getField(FLD_ID);
         }
      }
      finally
      {
         if (spCursor != null) spCursor.release();
      }

      return ((linkID == null) ? -1 : linkID.intValue());
   }

   private long getTaskID(String taskExtID, long projID) throws ABTException
   {
      ABTValue taskID = null;

      //
      // Build up a query whose purpose is to return a task's prID value.  There may
      // be more than one tuple in the result set.  If so, pick the first one.
      //
      ABTCursor sptCursor = repo_.select(QRY_SUBPROJECTTASK);
      sptCursor.andFilter(TBL_TASK + "." + FLD_PROJECTID  + " = " + projID);
      sptCursor.andFilter(TBL_TASK + "." + FLD_EXTERNALID + " = " + repo_.sqlString( taskExtID ) );

      try
      {
         if (sptCursor.moveFirst())
         {
            taskID = sptCursor.getField(FLD_ID);
         }
      }
      finally
      {
         if (sptCursor != null) sptCursor.release();
      }
      return ((taskID == null) ? -1 : taskID.intValue());
   }

   /**
    *    Saves subproject link objects back to the repository.
    *    @param parms: (currently not used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get a cursor and set the desired sort sequence.
      //
      getCursor();
      cursor_.setSort(TBL_SUBPROJECT + "." + FLD_ID);

      //
      // Get the collection of subproject link objects from the project object.
      // Set some properties before writing them out.
      //
      ABTObjectSet subLinks = getObjectSet(projObj_, OFD_SUBPROJECTLINKS);
      setSomeProperties(subLinks);

      //
      // Now save the subproject link objects.
      //
      save(subLinks);

      //
      // Delete any remaining subproject tuples in the cursor's result set.
      // Any such tuples would have been added after the project was checked out
      // of the repostiory and would therefore be invalid.
      //
      cursor_.deleteAll();

      closeCursor();
   }

   private void setSomeProperties(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);

      for (int i = 0; i < size; i++)
      {
         ABTObject subproj = at(oSet, i);

         //
         // Make sure the proxy task ID is set in the subproject link object.
         // It could be referring to a new task.
         //
         ABTObject proxyTask = getObject(subproj, OFD_TASK);
         setValue(subproj, OFD_TASKID, getValue(proxyTask, OFD_ID));

         //
         // TO DO:
         //
         // If any properties, based on the type of subproject we are processing,
         // need special attention, set those now.
         //
         ABTValue sptype = getValue(subproj, OFD_SUBPROJECTTYPE);
         switch (sptype.intValue())
         {
            case PROJECT_TYPE:
               break;

            case TASK_TYPE:
               break;

            case UNKNOWN_TYPE:
               break;
         }
      }
   }

}