package com.abtcorp.api.com;

import java.util.ListResourceBundle;
import com.abtcorp.core.ABTErrorCode;

public class errorMessages extends ListResourceBundle
{
public Object[][] getContents() {
			return contents; 
}


public static final String Package = "com.abtcorp.api.com".intern();
public static final ABTErrorCode ERR_INVALID_OBJSPACE = new ABTErrorCode(Package, "100");



static final Object[][] contents = {
{ERR_INVALID_OBJSPACE.getCode(),"Must provide a valid IABTObjectSpaceCOM"},

 };
}