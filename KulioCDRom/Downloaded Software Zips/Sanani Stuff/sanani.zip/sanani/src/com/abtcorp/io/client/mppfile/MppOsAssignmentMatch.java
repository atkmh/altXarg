package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;

public class MppOsAssignmentMatch extends MppOsMatch
{

   private MppOsMatch taskMatch_;
   private MppOsMatch resourceMatch_;

   MppOsAssignmentMatch(
                        Assignment     mppAssignment,
                        IABTObject     osAssignment,
                        MppOsMatch     taskMatch,
                        MppOsMatch     resourceMatch
                       )
   {

      super(mppAssignment, osAssignment, new ABTInteger(mppAssignment.getUniqueID()));

      taskMatch_     = taskMatch;
      resourceMatch_ = resourceMatch;

   }

   MppOsAssignmentMatch(

                        Assignment     mppAssignment,
                        MppOsMatch     taskMatch,
                        MppOsMatch     resourceMatch
                       )
   {

      super(mppAssignment, null, new ABTInteger(mppAssignment.getUniqueID()));

      taskMatch_     = taskMatch;
      resourceMatch_ = resourceMatch;

   }

   MppOsAssignmentMatch(

                        IABTObject     osAssignment,
                        MppOsMatch     taskMatch,
                        MppOsMatch     resourceMatch
                       )
   {

      super(null, osAssignment, null);

      taskMatch_     = taskMatch;
      resourceMatch_ = resourceMatch;

      setOsKeyAbtValue((ABTValue)getRemoteId(osAssignment));

   }



      public Assignment getMppAssignment()   {return (Assignment)getMppObject();}
      public IABTObject getOsAssignment()    {return (IABTObject)getOsObject();}

      public Task       getMppTask()         {return (Task)taskMatch_.getMppObject();}
      public Resource   getMppResource()     {return (Resource)resourceMatch_.getMppObject();}

      public IABTObject getOsTask()          {return (IABTObject)taskMatch_.getOsObject();}
      public IABTObject getOsResource()      {return (IABTObject)resourceMatch_.getOsObject();}

      public int                  getMppUniqueId() {return getMppKeyAbtValue().intValue();}
      public ABTClientMppRemoteID getRemoteId()    {return (ABTClientMppRemoteID)getOsKeyAbtValue();}

      public void setMppAssignment(Assignment   inp) {setMppObject(inp);}
      public void setOsAssignment (IABTObject   inp) {setOsObject (inp);}

      public void setMppTask(Task               inp) {taskMatch_.setMppObject(inp);}
      public void setMppResource(Resource       inp) {resourceMatch_.setMppObject(inp);}

      public void setOsTask(IABTObject          inp) {taskMatch_.setOsObject(inp);}
      public void setOsResource(IABTObject      inp) {resourceMatch_.setOsObject(inp);}

}
