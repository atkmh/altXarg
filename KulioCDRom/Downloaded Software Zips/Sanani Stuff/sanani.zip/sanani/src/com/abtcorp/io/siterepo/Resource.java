package com.abtcorp.io.siterepo;

/*
 * Resource.java 06/22/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 07-17-98    LZX         Initial Implementation
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.blob.ABTCalendar;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  Resource is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTSiteRepoDriver.
 *
 *  <pre>
 *       Resource rt = new Resource(driver, site);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTSiteRepoDriver
 */

public class Resource extends ABTSiteRepoHelper
{
   private ABTCursor calCursor_ = null;     // the calendar cursor
   private ABTCursor tcCursor_ = null;      // the type code cursor

/**
 *    Resource constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the site object that owns the resources.
*/
   public Resource(ABTRepositoryDriver driver, ABTObject parent)
   {
      super(driver, parent, TBL_RESOURCE, OBJ_RESOURCE);
      site_ = parent;
      reqParams_.putItemByString(OFD_SITE, site_);
      matchField_ = OFD_EXTERNALID;
   }

/**
 * Populate the object space with data selected from the repository.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	public ABTValue populate(String list, String query) throws ABTException
   {
      // make sure the base calendars and type codes are populated
      calCursor_ = getCursor(QRY_BASECALENDARS, TBL_CALENDAR + "." + FLD_ID);
      tcCursor_ = getCursor(QRY_TYPECODES, TBL_TYPECODE + "." + FLD_ID);

      Calendar calHelper = new Calendar(driver_, site_);
      calHelper.populate(calCursor_, true);

      TypeCode tcHelper = new TypeCode(driver_, site_);
      tcHelper.populate(tcCursor_, true);

      // close the base calendar cursor and select all the calendars 
      // in case we need to locate resource calendars
	   closeCursor(calCursor_);
      calCursor_ = getCursor(QRY_CALENDARS, TBL_CALENDAR + "." + FLD_ID);

      // populate the resources
	   ABTValue val = super.populate(list, query);

	   // close the calendar and type code cursors when resource populate is done.
	   closeCursor(calCursor_);
	   closeCursor(tcCursor_);

	   return val;
   }


/**
 * Populate the object space with cursor selected from the repository.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
	public ABTValue populate(ABTCursor cur, boolean loadAll) throws ABTException
	{
      // make sure the base calendars and type codes are populated
      calCursor_ = getCursor(QRY_BASECALENDARS, TBL_CALENDAR + "." + FLD_ID);
      tcCursor_ = getCursor(QRY_TYPECODES, TBL_TYPECODE + "." + FLD_ID);

      Calendar calHelper = new Calendar(driver_, site_);
      calHelper.populate(calCursor_, true);

      TypeCode tcHelper = new TypeCode(driver_, site_);
      tcHelper.populate(tcCursor_, true);

      // close the base calendar cursor and select all the calendars 
      // in case we need to locate resource calendars
	   closeCursor(calCursor_);
      calCursor_ = getCursor(QRY_CALENDARS, TBL_CALENDAR + "." + FLD_ID);

      // populate resources
	   ABTValue val = super.populate(cur, loadAll);

	   // close the calendar and type code cursors when resource populate is done.
	   closeCursor(calCursor_);
	   closeCursor(tcCursor_);

	   return val;
   }

/**
 * Update an existing object in the object space with properties from the repository.
 *	@param object: the object to be updated.
 *	@return ABTValue: a reference to the object updated or an ABTError.
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue update(ABTCursor cur, ABTObject object, ABTRemoteIDRepository id, boolean updateSpace) throws ABTException
   {
      if (updateSpace)
      {
         // remove the old notes before updating the resource scalar properties, etc.
         ABTValue val = getValue(object, OFD_NOTES);
               
         if (val instanceof ABTObjectSet)
         {
            ABTObjectSet os = (ABTObjectSet)val;
            Enumeration e = os.elements( userSession_ );

            while( e.hasMoreElements() )
            {
               ABTObject o = (ABTObject)e.nextElement();
               removeListMember(os, o);
            }
         }
      }
      
      return (super.update(cur, object, id, updateSpace));
   }


/**
 *  Set property values.
 *  @param       ps: the property hash.
 *  @param       cur: the cursor.
 *  @param       obj: the object.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps, ABTCursor cur, ABTObject object) throws ABTException
   {
      setPropertyValues(ps, cur, object);
      setNotes(cur, object);
      setTypeCode(cur, object);
      setCalendar(cur, object);
      setRoleSets(cur, object);
   }
   
   private void setNotes(ABTCursor cur, ABTObject object) throws ABTException
   {
      int id = cur.getFieldInt(FLD_ID);

      // populate resource notes if there is any
      Note helper = new Note(driver_, object);
      ABTValue val = helper.populate(null, QRY_RESOURCENOTES + id);

   }
   
   private void setTypeCode(ABTCursor cur, ABTObject object) throws ABTException
   {
      // set type code object reference if prTypeCodeID exists
      int id = cur.getFieldInt(FLD_TYPECODEID);
      if (id > 0)
      {
         // find type code in the space (it should have been populated earlier)
         ABTValue val = findObject(OBJ_TYPECODE, FLD_EXTERNALID, id, tcCursor_);

         if (val instanceof ABTObject)
            setValue(object, OFD_TYPECODE, val);
         else
            processError("setTypeCode",
                   errorMessages.ERR_OBJECT_NOT_FOUND,
                   "Type code not found for resource " + getValue(object, OFD_EXTERNALID).toString());
      }
   }
   
   private void setCalendar(ABTCursor cur, ABTObject object) throws ABTException
   {
      ABTValue val = null;
      int resID = 0;
      ABTCalendar cal = null;
      
      // step 1: set resource's OFD_CALENDAR (blob) value
      
      // get calendar id from the resource cursor
      int calID = cur.getFieldInt(FLD_CALENDARID);
      
      if (calID > 0)
      {
         // get resource id from the calendar cursor
         if (calCursor_.bsearchFirstInt(FLD_ID, calID))
            resID = calCursor_.getFieldInt(FLD_RESOURCEID);
         else
            processError("setCalendar",
                   errorMessages.ERR_RECORD_NOT_FOUND,
                   "PRResource.prCalendarID '" + calID + "' not found in PRCalendar table.");
      }

      if (resID > 0)
      {
         // if resource id exists, i.e., the calendar is a resource calendar

         // get the base calendar id for later use
         calID = calCursor_.getFieldInt(FLD_BASECALENDARID);
         
         // get calendar's FLD_CALENDAR (blob) value
         val = calCursor_.getField(FLD_VALUE);
         if (val instanceof ABTCalendar)
            cal = (ABTCalendar) val;
         else
            processError("setCalendar",
                   errorMessages.ERR_RECORD_NOT_FOUND,
                   "PRCalendar.prValue is not an instance of ABTCalendar. prID = " + calID);
      }
      else
         // if the calendar is not a resource calendar, create a blank calendar blob.
         cal = new ABTCalendar();
         
      // set the resource's OFD_CALENDAR to the calendar blob we just got
      setValue(object, OFD_CALENDAR, cal);
      
      // step 2: set resource's OFD_BASECALENDAR object reference
      // (Note: For resource calendar, base calendar is what PRCalendar.prBaseCalendarID
      // references to. For non-resource calendar, base calendar is what
      // to PRResource.prCalendarID references to. We have obtained the appropriate
      // calendar ID by now and will use the remote id and name to search the space.)

      if (calID == 0)
         // if base calendar id is null, use the site calendar.
         val = getValue(site_, OFD_STDCALENDAR);
      else
         // search the object space for the calendar that matches the remote id
         // or the name of the base calendar. (it should have been populated earlier)
         val = findObject(OBJ_CALENDAR, FLD_NAME, calID, calCursor_);

      if (val instanceof ABTObject)
         // set the base calendar reference.
         setValue(object, OFD_BASECALENDAR, val);
      else
         processError("setCalendar",
                errorMessages.ERR_OBJECT_NOT_FOUND,
                "Base calendar not found for resource " + getValue(object, OFD_EXTERNALID).toString());
   }


   private void setRoleSets(ABTCursor cur, ABTObject object) throws ABTException
   {
      // populate the associated role sets for non-role resource
      boolean isRole = cur.getFieldBoolean(FLD_ISROLE);
      if (!isRole)
      {
         int id = cur.getFieldInt(FLD_ID);

         // instantiate a roleset helper
         RoleSet helper = new RoleSet(driver_, object);
         
         // populate roleset (since the rolesets don't need to be replaced as
         // a whole during update, we pass in the OFD_ROLESETS list name
         // to cause the helper to do the 2-pass populate that updates
         // the rolesets based on both the object set in the space and the
         // cursor from the repository)
         helper.populate(OFD_ROLESETS, QRY_ROLESETS + id);
      }
   }
   
/**
 * Sets cursor values.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);

      // for now, we don't need to worry about setting the calendar and type code ids
      // since the apps don't create resources with calendar/type code references YET.      
      // in future release, we may need to find the correct calendar and type code ids
      // and wire them up.      
   }

/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      // do not write calendar id field
      if (prapiName.equals(FLD_CALENDARID) || prapiName.equals(FLD_TYPECODEID))
         return true;

      return super.isSaveException(prapiName, obj, prapiFlags, isNew);
   }


   /**
    *    determines if an object should be saved back to the repository.
    *    @param obj  the object in question
    *    @return     true if yes, false if no.
    *    @exception  ABTException if error occurred
    */
   protected boolean saveThisObject (ABTObject obj) throws ABTException
   {
      // currently, for resource objects, save only those that are roles.
      ABTValue val = getValue(obj, OFD_ISROLE);
      if (val.booleanValue())
         return true;
      else
         return false;
   }

}