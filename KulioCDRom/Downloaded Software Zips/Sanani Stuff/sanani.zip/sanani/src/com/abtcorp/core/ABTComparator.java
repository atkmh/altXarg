/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTComparator.java, 5, 9/28/98 4:34:38 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

/**
 * ABTComparator is an interface used by ABTSortedArray to control the order or the elements
 * in the array.
 *
 * @version    $Revision: 5$, $Date: 9/28/98 4:34:38 PM$
 * @author     $Author: Benoit Menendez$
 *
 * @see        com.abtcorp.core.ABTSortedArray
 *
 */

public interface ABTComparator
{
   
/**
 * This method compares two objects for order.
 *
 * @return  a negative integer, zero, or a positive integer as the
 * 	      first argument is less than, equal to, or greater than the
 *	         second. 
 */
 
   public int compare(Object object1, Object object2);
}