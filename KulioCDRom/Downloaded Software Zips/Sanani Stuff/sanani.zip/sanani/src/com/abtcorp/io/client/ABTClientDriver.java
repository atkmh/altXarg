package com.abtcorp.io.client;

/*
 * ABTClientDriver.java 03/27/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98      SA          Initial Implementation
  * 03-27-98      SOB	      Initial Documentor
  * 03-31-98      SOB         Add default constructor & setSpace() method
  * 04-16-98      SOB         Changed ABTObjectSelector to String in populate() method
  * 04-30-98      SOB         open() returns boolean instead of void
  * 05-05-98      SOB         change addProperties() to support property names in ABTRepoDataDictionary form
  * 06-19-98      LZX         change addProperties() from package default to public.
  * 07-14-98      SOB         remove addProperties() and move it to ABTIOPreoHelper
  * 07-23-98      LZX         add getRulebase() and setRulebase().
  * 07-29-98      SDP         Stripped-out references to ABTObjectSpace and ABTUserSession
  * 08-04-98      MXA         Add checkSpace().
  * 08-11-98      SOB         Mods to support new public API.
  * 08-11-98      SOB         Remove being extended from ABTDriver; now it's the top-level class for client drivers
  * 08-18-98      SOB         added execute()
  * 09-28-98      ATW         added getSite() to return site object from current objectspace
  * 10-02-98      SOB         Mods to remove javadoc warnings
  * 11-02-98      MXA         Add getHashtableValue().
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import java.util.Enumeration;
import java.util.Vector;

import com.abtcorp.io.IABTClientDriver;

import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;

import com.abtcorp.idl.IABTDriverConstants;

/**
 *  ABTDriver is the base abstract class for all drivers which will access persistent data.
 *
 *			This class is not meant to be instantiated directly, but to be extended by
 *       special-purpose drivers which access persistent data in an application-specific
 *       way, e.g.,
 *
 *  <pre>
 *       public class ABTFileDriver extends ABTClientDriver
 *       {
 *         ... add/override methods for repository-specific requirements ...
 *       }
 *
 *  </pre>
 *
 * @version	    $Revision: 19$
 * @author      S. Asire
 * @author		 S. Bursch
 */

public abstract class ABTClientDriver implements IABTClientDriver, IABTDriverConstants
{
   private IABTObjectSpace space_;

/**
 *		Create an ABTDriver that has no associated ABTObjectSpace.  If this
 *    constructor is used, the setSpace() method must be used subsequently
 *    to associate the driver with an ABTObjectSpace object.
 */

   public ABTClientDriver() {}

/**
 *		Create an ABTDriver that is associated with an ABTObjectSpace.
 *		@param space  The ABTObjectSpace object with which this ABTDriver is
 *		associated.
 */

   public ABTClientDriver(IABTObjectSpace space)
   {
    space_ = space;
   }

/**
 *		Get the ABTObjectSpace object and return it to the caller.
 */

   public IABTObjectSpace getSpace() {return space_;}

/**
 *		Set an ABTObjectSpace object for this driver.
 */

   public void setSpace(IABTObjectSpace space) {space_ = space;}

/**
 *		Checks if ABTObjectSpace exists for this driver.
 *    @exception ABTException if no object space has been specified for this driver
 */
   public void checkSpace() throws ABTException
   {
      if (getSpace() == null)
         throw new ABTException("The object space has not been set!");
   }
/**
 *		Opens a connection to a specific data source.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public abstract ABTValue open(IABTObjectSpace space, IABTHashTable args);

/**
 *		Populates the ABTObjectSpace with objects from the data source. This method
 *		MUST be overridden by the application-specific class that extends this class.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public abstract ABTValue populate(IABTObjectSpace space, IABTHashTable args);

/**
 *		Saves the ABTObjects identified in the ABTObjectSet object back to the data source.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public abstract ABTValue save(IABTObjectSpace space, IABTHashTable args);

/**
 *		Close a connection to a specific data source.
 *    @param space IABTObjectSpace reference to the object space which this driver will use
 *    @param args ABTHashtable of input arguments
 *		@return ABTValue ABTError if an error occurs; otherwise null.
 */

   public abstract ABTValue close(IABTObjectSpace space, IABTHashTable args);

/**
 *		Executes a driver-specific command.  Commands which are relevant to all client drivers
 *    should be placed here.  If there are no commands relevant to all drivers, then this method
 *    will return an ABTError.
 *    @param space object space this driver instance will use
 *    @param session user session this driver instance will use
 *    @param args hash table of optional, application-specific, parameters
 */
   public ABTValue execute(IABTObjectSpace space, IABTHashTable args)
   {
      return new ABTError("com.abtcorp.io.client",COMP_CLIENTDRIVER, MOD_EXECUTE, EXC_NOTIMPLEMENTED, null);
   }


/**
 *    Processes an error situation raised by the caller.  If the severity level is 1, an
 *    exception is thrown.  For all other levels, a return to the caller is effected.
 *    @param severityLevel: the level of severity of the error; low numbers are more severe
 *    @param objType: the type of Sanani object in trouble
 *    @param exceptionName: an exception identifier string
 *    @param errorMessage: further text describing the error condition
 *    @return some sort of value (for now the severity level)
 *    @exception ABTException if the severity level is 1 (the highest severity)
 */
 public int processError(int severityLevel, String objType, String exceptionName, String errorMessage) throws ABTException
 {
   //
   // Construct a simple error message.
   //
   String s = ERR_OBJECTTYPE + objType + ", " + ERR_EXCEPTIONNAME + ", " + ERR_TEXT + errorMessage;

   //
   // Process this error.
   //
   // For severity 1 errors, throw an ABTException.
   // For other severity errors, decide what to do, perhaps writing to a log.
   //
   switch (severityLevel)
   {
      case SEVERITY_ONE:
         throw new ABTException(s);

      case SEVERITY_TWO:
      case SEVERITY_THREE:
      default:
         break;
   }

   return severityLevel;
 }

  /**
    *    Gets a String value from an ABTHashtable.
    *    @param args the ABTHashtable from which a value will be extracted
    *    @param key the String object that is the associated key for the value to be extracted
    *    @return String object
    */
   protected String getStringValue(IABTHashTable args, String key)
   {
      Object obj = args.getItemByString(key);
      String value = (obj instanceof ABTString) ? ((ABTString)obj).stringValue() : (String) obj;
      return value;
   }
   
   
    /**
    *    Gets a Hashtable value from an ABTHashtable.
    *    @param args the ABTHashtable from which a value will be extracted
    *    @param key the String object that is the associated key for the value to be extracted
    *    @return String object
    */
   protected IABTHashTable getHashtableValue(IABTHashTable args, String key)
   {
      Object    obj    = args.getItemByString(key);
      IABTHashTable value  = null;
      if (obj instanceof IABTHashTable)
        value = (IABTHashTable) obj;
      return value;
   }


   /**
    *    Gets the site object for the object space and returns it to the caller.  The
    *    site object can be found by querying the object space for objects of type OBJ_SITE.
    *    There should only be one such object.  The method is made public so that helper classes
    *    not extended from this driver can access the Site object.  It is not intended to be
    *    exposed to client applications.
    *    @return an ABTValue.  If no errors occur, the site object; otherwise,
    *       an ABTError.
    */
   public ABTValue getSite( IABTObjectSpace space )
   {
      ABTValue ret;
      ABTError err = new ABTError("com.abtcorp.io.client",COMP_CLIENTDRIVER,
                                  "getSite",
                                  "102",
                                  null);
      String siteType = com.abtcorp.idl.IABTRuleConstants.OBJ_SITE;

      if ( space == null )
         return err;

      ABTValue val = space.getObjects( siteType );
      if ( ABTError.isError( val ) || ABTValue.isNull( val ) )
         return err;

      IABTObjectSet os = (IABTObjectSet) val;
      if ( os.size() == 0 )
         return err;

      //
      // The following code assumes that there is only one Site object in the
      // set returned by the space.
      //
      val = os.at( 0 );
      if ( !(val instanceof IABTObject) )
         return err;

      //
      // We've got an ABTObject.  Make sure it's exactly the right type.
      //
      if ( !((IABTObject) val).getObjectType().equals(siteType) )
         return err;

      //
      // We've got the Site object for sure.  Return a reference to it
      // to the caller.
      //

      return val;
   }

/**
    *    Gets the site object for the object space and returns it to the caller.  The
    *    site object can be found by querying the object space for objects of type OBJ_SITE.
    *    There should only be one such object.  The method is made public so that helper classes
    *    not extended from this driver can access the Site object.  It is not intended to be
    *    exposed to client applications.
    *    @return an ABTValue.  If no errors occur, the site object; otherwise,
    *       an ABTError.
    */
   public ABTValue getSite()
   {
      ABTValue ret;
      ABTError err = new ABTError("com.abtcorp.io.client",COMP_CLIENTDRIVER,
                                  "getSite",
                                  "102",
                                  null);
      String siteType = com.abtcorp.idl.IABTRuleConstants.OBJ_SITE;

      if ( space_ == null )
         return err;

      ABTValue val = space_.getObjects( siteType );
      if ( ABTError.isError( val ) || ABTValue.isNull( val ) )
         return err;

      IABTObjectSet os = (IABTObjectSet) val;
      if ( os.size() == 0 )
         return err;

      //
      // The following code assumes that there is only one Site object in the
      // set returned by the space.
      //
      val = os.at( 0 );
      if ( !(val instanceof IABTObject) )
         return err;

      //
      // We've got an ABTObject.  Make sure it's exactly the right type.
      //
      if ( !((IABTObject) val).getObjectType().equals(siteType) )
         return err;

      //
      // We've got the Site object for sure.  Return a reference to it
      // to the caller.
      //

      return val;
   }


}