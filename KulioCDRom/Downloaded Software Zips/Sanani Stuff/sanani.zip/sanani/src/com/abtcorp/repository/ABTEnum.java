package com.abtcorp.repository;

public interface ABTEnum
{
   // NOTE: These constants are different from the ABTDate.

   public static final int PR_SUNDAY	 		   = 0;
   public static final int PR_MONDAY			   = 1;
   public static final int PR_TUESDAY			   = 2;
   public static final int PR_WEDNESDAY 		   = 3;
   public static final int PR_THURSDAY	 		   = 4;
   public static final int PR_FRIDAY		 	   = 5;
   public static final int PR_SATURDAY		 	   = 6;

// Time-tracking scales (PRSite.TrackScale)
   public static final int PR_DAILY_SCALE       =  1;
   public static final int PR_WEEKLY_SCALE      =  2;
   public static final int PR_BIWEEKLY_SCALE    =  3;
   public static final int PR_MONTHLY_SCALE     =  4;
   public static final int PR_QUARTERLY_SCALE   =	5;
   public static final int PR_SEMIANNUAL_SCALE  = 	6;
   public static final int PR_ANNUAL_SCALE      =  7;

   // Types of CPM (PRProject.CPMType)
   public static final int PR_CPM_CURRENT 		   = 0;
   public static final int PR_CPM_BASELINE 	      = 1;

   // Units of measure (PRResource.Unit)
   public static final int PR_DAYS		 	         = 0;
   public static final int PR_HOURS		 	         = 1;
   public static final int PR_COST		 	         = 2;
   public static final int PR_QUANTITY		         = 3;

   // Units of availability (PRResource.AvailUnit)
   public static final int PR_DAILY_AVA				= 0;
   public static final int PR_WEEKLY_AVA			   = 1;
   public static final int PR_PERCENT_AVA			   = 2;

   // Types of resources (PRResource.Type)
   public static final int PR_EMPLOYEE		         = 0;
   public static final int PR_CONTRACTOR	         = 1;

   // Values of timeSheet (PRResource.TrackMode)
   public static final int	PR_NO_TIMESHEET		   = 0;
   public static final int	PR_OTHER_TIMESHEET	   = 1;
   public static final int	PR_TEAMWORKBENCH		   = 2;

   // Status of task (PRTask.Status)
   public static final int PR_NOT_STARTED 			= 0;
   public static final int PR_STARTED				   = 1;
   public static final int PR_COMPLETED				= 2;

   // Levels of WBS (PRTask.WBSLevel)
   public static final int PR_PROJECT_WBS 			= 0;
   public static final int PR_PHASE_WBS				= 1;
   public static final int PR_ACTIVITY_WBS			= 2;
   public static final int PR_TASK_WBS				   = 3;

   // Types of dependencies (PRDepend.Type)
   public static final int PR_FIN_START_DEP 		   = 0;
   public static final int PR_START_START_DEP		= 1;
   public static final int PR_FIN_FIN_DEP 			= 2;
   public static final int PR_START_FIN_DEP 		   = 3;

   // Types of dependency amount units (PRDepend.AmountType)
   public static final int PR_DAILY_DEPENDENCY 		= 0;
   public static final int PR_PERCENT_DEPENDENCY	= 1;

   // Types of loading patterns (PRAssign.EstPtrn, PRAssign.ArchPtrn)
   public static final int PR_UNIFORM 		         = 0;
   public static final int PR_FIXED 			      = 1;
   public static final int PR_CONTOUR 		         = 2;
   public static final int PR_FRONT		 	         = 3;
   public static final int PR_BACK 			         = 4;

   // Status values for time sheets (PRTSheet.Status)
   public static final int PR_UNSUBMITTED_TSHEET	= 0;
   public static final int PR_SUBMITTED_TSHEET 	   = 1;
   public static final int PR_REJECTED_TSHEET 	   = 2;
   public static final int PR_APPROVED_TSHEET		= 3;
   public static final int PR_POSTED_TSHEET 		   = 4;
   public static final int PR_ADJUSTED_TSHEET 		= 5;

   // Format values for PRProject.Format
   public static final int PR_FORMAT_UNKNOWN			= 0;
   public static final int PR_FORMAT_FIX				= 6;
   public static final int PR_FORMAT_ACA				= 7;
   public static final int PR_FORMAT_GRP				= 8;
   public static final int PR_FORMAT_MPP				= 11;

   // value for PRTable.prFlags
   public static final int PR_TABLE_ISSYSTEM		   = 1;

   // value for PRField.prFlags
   public static final int PR_FIELD_ISVIRTUAL		= 1;
   public static final int PR_FIELD_ISPRIVATE		= 2;
   public static final int PR_FIELD_ISEDITABLE	   = 4;
   public static final int PR_FIELD_ISNULLABLE	   = 8;
   public static final int PR_FIELD_ISPMDATE		   = 16;

   // value for PRField.prExtType
   public static final int PR_EXTTYPE_MONEY        = 120;
   public static final int PR_EXTTYPE_DATE			= 121;
   public static final int PR_EXTTYPE_TIME			= 122;
   public static final int PR_EXTTYPE_BOOLEAN		= 123;
   public static final int PR_EXTTYPE_PERCENT		= 124;
   public static final int PR_EXTTYPE_ENUM			= 125;
   public static final int PR_EXTTYPE_REFERENCE	   = 126;
   public static final int PR_EXTTYPE_MEMO			= 127;

   // value for PRConstraint.prType
   public static final int PR_NO_CONSTRAINTS			= 0;
   public static final int PR_AS_LATE_AS_POSSIBLE  = 1;
   public static final int PR_AS_SOON_AS_POSSIBLE  = 2;
   public static final int PR_FINISH_NO_EARLIER_THAN	= 3;
   public static final int PR_FINISH_NO_LATER_THAN	= 4;
   public static final int PR_MUST_FINISH_ON       = 5;
   public static final int PR_MUST_START_ON        = 6;
   public static final int PR_START_NO_EARLIER_THAN = 7;
   public static final int PR_START_NO_LATER_THAN  = 8;

   // value for PRListMember.prFlags
   public static final int PR_NORMAL					= 0;
   public static final int PR_NEW						= 1;
   public static final int PR_MODIFIED					= 2;
   public static final int PR_REMOVED					= 3;

   // value for MSPField.prType
   public static final int	PR_UNKNOWN					= 0;
   public static final int	PR_PROJECT					= 1;
   public static final int	PR_RESOURCE					= 2;
   public static final int	PR_TASK						= 3;
   public static final int	PR_ASSIGNMENT				= 4;
   public static final int	PR_TEAM						= 5;

   // value for MSPField.prFlags
   public static final int	PR_IMPORT					= 1;
   public static final int	PR_EXPORT					= 2;

}