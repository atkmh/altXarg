package com.abtcorp.io.methrepo;

/*
 * ABTIOMethRepoDeliverable.java 06/16/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 06-16-98    LZX         Initial Implementation
 * 07-10-98    LZX         Support transactions
 * 08-05-98    LZX         Use new business rules, io.server package, etc.
 *
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTEnum;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTArray;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

/**
 *  ABTIOMethRepoDeliverable is a helper class for the ABT Repository driver for the Widgeon application.
 *  It is instantiated by the ABTIOMethRepoMethod object.
 *
 *  <pre>
 *       ABTIOMethRepoDeliverable rt = new ABTIOMethRepoDeliverable(driver, method);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 L. Xiao
 * @see         ABTIOMethRepoMethod
 */

public class ABTIOMethRepoDeliverable extends ABTIOMethRepoHelper
{
   private Hashtable taskHash_;
   private Hashtable delivHash_;
   private long methodID_;
   private ABTObject method_ = null;

/**
 *    ABTIOMethRepoDeliverable constructor.
 *    @param   driver: the reference to the driver.
 *    @param   parent: the method object that owns the deliverables.
 *    @param   taskHash: the task hash table.
 */
   ABTIOMethRepoDeliverable(ABTMMRepoDriver driver, ABTObject parent, Hashtable taskHash)
   {
      super(driver, parent, TBL_MRDELIVERABLE, OBJ_MM_DELIVERABLE);
      method_ = parent;
      taskHash_ = taskHash;
      delivHash_ = new Hashtable();     // get a new Hashtable for these deliverable objects
      methodID_ = 0;
      component_ = "ABTIOMethRepoDeliverable";
      reqParams_.putItemByString(OFD_METHOD, method_);
   }



/**
 *  Set deliverable values.
 *  @param       ps: the deliverable property list.
 *  @param       dlvCursor: the deliverable cursor.
 *  @param       obj: the deliverable object.
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   protected void setValues(Vector ps,
                            ABTCursor dlvCursor,
                            ABTObject obj) throws ABTException
   {
      //
      // Set the property values from the repository deliverable tuple into the deliverable
      // object.
      //
      setPropertyValues(ps, dlvCursor, obj);

      ABTValue delivID = dlvCursor.getField(FLD_ID);

      // save for quickly locating deliverable objects
      delivHash_.put(new Long(delivID.intValue()), obj);

      //
      // Select the task deliverable links for this method.  These tuples identify
      // associated tasks that have deliverables. Order the result set by the prDeliverableID
      // column; this will allow for ordered searches of the result set later.
      //
      ABTCursor tdlCursor = repo_.select(QRY_METHODTASKDELIVLINK + delivID.intValue());
   	tdlCursor.setSort(TBL_MRTASKDELIVLINK + "." + FLD_DELIVERABLEID);

//      String s = dlvCursor.getFilter();

      //
      // Create a collection object for this deliverable to hold the set of associated
      // task objects.
      //
   	ABTObjectSet taskos = createObjectSet(OBJ_MM_TASK);

      // Position into the task deliverable link result set using the prDeliverableID.
      // Go to the first task deliverable link (if any) that matches on prDeliverableID.
      // There may be many such entries.  The positioning assumes that the result set is
      // ordered by prDeliverableID.
      //
      boolean found = tdlCursor.lsearchFirst(FLD_DELIVERABLEID, delivID);
      if (found)
      {
         do
         {
            //
            // Locate the task object identified by the task deliverable link's prDeliverableID
            // column.  If the task cannot be found, continue the loop.
            //
            Long associatedTaskID = new Long(tdlCursor.getFieldInt(FLD_TASKID));
            ABTObject associatedTask = (ABTObject) taskHash_.get(associatedTaskID);
            if (associatedTask == null) continue;

            //
            // Add this deliverable object to the associated task's collection of deliverables.
            //
            ABTObjectSet delivos = (ABTObjectSet) getValue(associatedTask, OFD_DELIVERABLES);
            add(delivos, obj);

            // Add the associated task object to this deliverable object's collection of
            // task objects.
            //
            add(taskos, associatedTask);
         }
         while (tdlCursor.lsearchNext(FLD_DELIVERABLEID, delivID));
      }           // end if (found)

      // set the collection of tasks property into the deliverable object.
      setValue(obj, OFD_TASKS, taskos);

      // release the task deliv link cursor
      closeCursor(tdlCursor);
   }

/**
 *  Gets the deliverable hash table.
 *  @return      the deliverable hash table
 *  @exception   ABTException Thrown if an unrecoverable error occurs.
 */
   public Hashtable getHash() throws ABTException
   {
      return delivHash_;
   }


/**
 * Save objects from the object space back to the repository
 * (This method overrides the helper since we need to also save the task deliv links.
 * @param oSet the object set to be saved
 * @return ABTValue of the object set that's saved
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue save(ABTObjectSet oSet, boolean saveAs) throws ABTException
   {
      boolean isNew = false;

   	// get property set from the dictionary
	   ps_ = dataDictionary_.getPropertiesFromDataModel(table_);

      // make sure the property set is not null
      if ((ps_ == null) || ps_.isEmpty())
      {
         processError(MOD_SAVE,
                     errorMessages.ERR_INVALID_PROPERTYSET,
                     "Null property set for table " + table_);
         return null;
      }

      // a cursor is selected for the entire object set to be saved (all the
      // records that belong to the parent) sorted by prID.
      cursor_ = getCursorForSave();
      cursor_.setSort(table_ + "." + FLD_ID);

      try
      {
         // iterate through all the objects in the object set
         for (int i = 0; i < size(oSet); i++)
         {
            ABTObject obj = (ABTObject)at(oSet, i);

            // make sure the object is of the right type
            if (!obj.getObjectType().equals(type_))
            {
               processError(MOD_SAVE,
                           errorMessages.ERR_INVALID_TYPE,
                           "expected object type = " + type_ + ", bad type = " + obj.getObjectType());
               return null;
            }

            // check if this is a new object. force add new if save-as.
            if (saveAs)
               isNew = true;
            else
               isNew = isNewObject(obj, cursor_);

            // add or edit cursor depending on whether this is a new object
				if (isNew)
            {
            	// add a new row to the end of the cursor so that the order of the cursor won't
            	// get messed up (the cursor is ordered by prID for faster acess and the prID of
            	// the new row will be guranteed greater than the prID of the last row in the cursor).
            	cursor_.moveEOF();
               cursorAddNew(cursor_);
		      }
            else
				{
           		// edit the cursor for pre-existing record
              	cursorEdit(cursor_);
            }

            // set fields and update the cursor
				setCursorValues(ps_, cursor_, obj, this, isNew);
            cursorUpdate(cursor_);

            // Set the prID and remote ID for new object after successful update
            if (isNew)
            {
               ABTValue prID = cursor_.getField(FLD_ID);
               setValue(obj, OFD_ID, prID);
               ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), prID.intValue() );
               obj.getID().setRemote(userSession_, id);
            }
            
            //
            // Drop the current row from the cursor's result set.  Doing this
            // will facilitate deleting remaining rows in the result set after all
            // add/update/delete processing has taken place.  However, this method
            // will not delete remaining rows in the result set.  That operation is
            // up to the caller.
            //
   			cursor_.drop();

            // save task deliv links after the deliverable has been saved.
         	updateTaskDelivLink(obj);

         }	// end for

         //
         // Now process the deleted objects associated with the input object set.  The
         // remote ID's of these deleted objects are presented in an ABTArray.
         //
         ABTArray da = oSet.getDeletedData(userSession_);
         Enumeration rmtIDEnum = da.elements();

         //
         // For each deleted object in the object set, see if a corresponding tuple exists in the cursor's
         // result set.  If it exists, delete it.  If it doesn't exist, skip the object and get the next
         // one; the tuple has already been deleted.  If the ABTArray contains an object which is not of type
         // ABTRemoteIDRepository, skip it and get the next object.
         //
         while ( rmtIDEnum.hasMoreElements() )
         {
            Object rmtID = rmtIDEnum.nextElement();
            if ( !(rmtID instanceof ABTRemoteIDRepository) )
               continue;
            int id = (int) ((ABTRemoteIDRepository)rmtID).getPrID();
            if ( cursor_.bsearchFirst(FLD_ID, new ABTInteger(id)) )
               cursor_.delete();
         }

      }
      finally
      {
         closeCursor(cursor_);
      }

      return oSet;
   }



/**
 * Sets cursor values and updates the repository.
 * @param ps      the set of properties (for object obj) which will be retrieved from obj and set into the repository
 * @param cur     the cursor reference to which values will be set
 * @param obj     the object from which values will be gotten
 * @param helper  the helper object which has checkExeption() method that will be called to handle
 *                exception-based writing to the repository
 * @param isNew   a boolean value which indicates whether the data being added is new to the repository, i.e., the
 *                operation is an add
 *	@return  void
 *	@exception ABTException thrown if an unrecoverable error occurs.
 */
   public void setCursorValues(Vector ps, ABTCursor cur, ABTObject obj, ABTIORepoHelper helper, boolean isNew) throws ABTException
   {
		// first set the scalar property values
		super.setCursorValues(ps_, cur, obj, this, isNew);

		// for new records, get method id from the method object and set it.
		if (isNew)
   	   cursorSetField(cur, FLD_METHODID, getValue(method_, OFD_ID));

   }

   private void updateTaskDelivLink(ABTObject obj) throws ABTException
   {
      // get deliverable id and external id
     	ABTValue delivID = getValue(obj, OFD_ID);
      ABTValue delivExtID = getValue(obj, OFD_EXTERNALID);

      // get tasks list for this deliverable
      ABTValue val = getValue(obj, OFD_TASKS);
   	if (!(val instanceof ABTObjectSet))
   	{
         processError("updateTaskDelivLink",
                     errorMessages.ERR_OBJECTSET_NOT_FOUND,
                     "mmTasks object set is not found in deliverable " + delivExtID.toString());
         return;
      }

      // a cursor is selected for the tasks that are linked to this deliverable
      // sorted by prTaskID.
      ABTCursor tdlCursor = repo_.select(QRY_METHODTASKDELIVLINK + delivID.intValue());
      tdlCursor.setSort(TBL_MRTASKDELIVLINK + "." + FLD_TASKID);

      ABTObjectSet tasks = (ABTObjectSet) val;

      // iterate through the task object set
   	if (!ABTValue.isNull(val) && size(tasks) > 0)
   	{
         for (int i = 0; i < size(tasks); i++)
         {
            ABTObject task = (ABTObject)at(tasks, i);

            // add a new task deliverable link record if this task link is new
            boolean isNew = isNewLink(task, tdlCursor);
				if (isNew)
            {
            	// add a new row to the end of the cursor so that the order of the cursor won't
            	// get messed up (the cursor is ordered by prID for faster acess and the prID of
            	// the new row will be guranteed greater than the prID of the last row in the cursor).
            	tdlCursor.moveEOF();
               cursorAddNew(tdlCursor);

               // set fields and update the cursor
    				cursorSetField(tdlCursor, FLD_DELIVERABLEID, delivID);
     				cursorSetField(tdlCursor, FLD_TASKID, getValue(task, OFD_ID));
               cursorUpdate(tdlCursor);
		      }
		      /* can't edit existing link records since task id and deliv id are immutable
            else
				{
           		// edit the cursor for pre-existing record
              	tdlCursor.edit();
            }
            */


            // Drop the current row from the cursor's result set.  Doing this
            // will facilitate deleting remaining rows in the result set after all
            // add/update/delete processing has taken place.
   			tdlCursor.drop();

         }	// end for
      }

      // delete the remaining rows in the cursor
      tdlCursor.deleteAll();

      // release the task deliv link cursor
      closeCursor(tdlCursor);
   }


/**
 *    determines if a task deliverable link is new
 *    @param obj  the task object
 *    @param cur  the task deliv link cursor
 *    @return     true if new, false if not.
 *    @exception  ABTException if error occurred
 */
protected boolean isNewLink (ABTObject obj, ABTCursor cur) throws ABTException
{
   // if the ID field of the task object can be found in the task deliv link
   // cursor, then this is a pre-existing link, otherwise is a new link.
   ABTValue id = getValue(obj, OFD_ID);
	if ( cur.bsearchFirst(FLD_TASKID, id) )
	   return false;  // found
   else
      return true;   // not found
}


/**
 * Performs exception checking for setting cursor values.
 * @param prapiName  the name of the column to be updated.
 * @param obj        the reference to the object to be saved back to the repository
 * @param prapiFlags is this a virtual field, etc.
 * @param isNew      is this a new row
 * @return true (is exception) or false (is not exception).
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      // prMethodID can not be modified after add-new
      if (!isNew && prapiName.equals(FLD_METHODID))
         return true;

      return super.isSaveException(prapiName, obj, prapiFlags, isNew);
   }


/**
 * Select cursor from the repository for populate.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForPopulate() throws ABTException
   {
     	long methodID_ = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODDELIVERABLES + methodID_ ));
   }

/**
 * Select cursor from the repository for save.
 * @return the ABTCursor containing the selected rows.
 * @exception ABTException Thrown if an unrecoverable error occurs.
 */
   protected ABTCursor getCursorForSave() throws ABTException
   {
     	long methodID_ = getValue(method_, OFD_ID).intValue();
      return (repo_.select(QRY_METHODDELIVERABLES + methodID_));
   }

}