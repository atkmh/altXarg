package  com.abtcorp.objectModel.abt.fr;

/*
 * DisallowReset.java 08/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 08-05-98       LZX           Initial Design
 *
 */

import   java.util.*;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule will prohibit a field from being reset.
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class DisallowReset extends SiteFieldRule
{

   /**
    * Validate the value that is being set into the parent object container.
    * Return an ABTError if the value has already been set.
    * Otherwise make sure the new value is not null or ABTEmpty, and the new value
    * is of the correct type before setting the value (for the first time).
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      // if it has already been set, return an error.
      if( !ABTValue.isNull( myValue ) )
         return new ABTError("DisallowReset",
            "onSet", 
            errorMessages.ERR_OPERATION_DENIED,
            property.getName() + " can not be overwritten once it is set" );

      // otherwise this is the first (and the only)time the property get set.
      // make sure the new value to set to is not null or empty.
      if( ABTValue.isNull( newValue ) )
         return new ABTError( "DisallowReset",
            "onSet", 
            errorMessages.ERR_INVALID_VALUE,
            "Attempting to set to a null or empty value to " + property.getName() );

      // make sure the new value is of the correct type if it's an ABTObject.
      if (newValue instanceof ABTObject)
      {
         String propType = property.getReferenceType().getName();
         String newType = ((ABTObject) newValue).getObjectType();
         if (!newType.equals(propType))
            return new ABTError( "DisallowReset",
               "onSet", 
               errorMessages.ERR_INVALID_TYPE,
               "The expected type is " + propType + "; The bad type is " + newType );
      }

      // every thing seems OK. set it and that's it.
      return write( session, parent, property, myValue, newValue, false );
   }
}
