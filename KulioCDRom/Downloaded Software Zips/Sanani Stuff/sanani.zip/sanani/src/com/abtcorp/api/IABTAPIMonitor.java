package com.abtcorp.api;

import com.abtcorp.core.ABTValue;
import com.abtcorp.idl.IABTObject;

public interface IABTAPIMonitor
{
    public void OnClientCreateObject(IABTObject obj);
    public void OnDriverPopulate(ABTValue driverResult);
    public void close();
}