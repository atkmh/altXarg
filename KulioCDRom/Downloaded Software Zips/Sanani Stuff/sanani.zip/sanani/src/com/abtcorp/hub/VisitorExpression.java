package com.abtcorp.hub;

import java.lang.*;
import java.io.*;
import java.util.*;

import com.abtcorp.core.*;
import com.abtcorp.parser.*;

public class VisitorExpression implements WhereParserVisitor, com.abtcorp.parser.IABTLogicalOperation
{
   ABTUserSession mySession = null;
   public static VisitorExpression create(ABTUserSession session)
   {
      return new VisitorExpression(session);
   }

   public ABTArray      my_array = null;

   public VisitorExpression(ABTUserSession session)
   { 
        super(); 
        mySession = session;
   }

   public VisitorExpression( ABTUserSession session,ABTArray array )
   {
      super();
      my_array = array;
        mySession = session;
   }

   /* Parses a string
   */
   public ABTValue parse( String str )
      throws ParseException
   {
      /* Append the end of file characters
      */
      String instr = str + "\r\n";

      byte[] b = instr.getBytes();
      ByteArrayInputStream is = new ByteArrayInputStream( b );

      return getExpression( is );
   }

   /* This is a helper main routine that accepts user input and displays
      the boolean value of the entered statement.
   */
	public static void main( String args[] ) throws ParseException
	{
      System.out.println( "Type in your where clause.  Type ^Z when finished." );

      try
      {
         VisitorExpression v = new VisitorExpression( null );
		   ABTValue l = v.getExpression( System.in );
         String s = l.stringValue();
		   System.out.println( "The expression evalutates to " + l.stringValue() );
      }
      catch( Exception e )
      {
         System.out.println( "Errors encountered." );
         System.out.println( e.getMessage() );
         e.printStackTrace();
      }
	}

   /* This interface provides the mechanism by which a node communicates
      to it's parent node the ABTValue it produces.
   */
	interface SetExpression
	{
		public void setOperand( ABTValue value );
	}

   /* A node instantiates a LeftOperand to collect the ABTValue from the
      children of it's left side
   */
	class LeftOperand implements SetExpression
	{
		ABTLogicalExpression expression;

		public LeftOperand( ABTLogicalExpression e )
		{
			expression = e;
		}

		public void setOperand( ABTValue value )
		{
			expression.setLeftOperand( value );
		}
	}

   /* A node instantiates a RightOperand to collect the ABTValue from the
      children of it's right side
   */
	class RightOperand implements SetExpression
	{
		ABTLogicalExpression expression;

		public RightOperand( ABTLogicalExpression e )
		{
			expression = e;
		}

		public void setOperand( ABTValue value )
		{
			expression.setRightOperand( value );
		}
	}

   private String stripSingleQuotes( String s )
   {
      int length = s.length();
      //
      // Is the input string sandwiched between single quote marks?
      // If so, remove the outer single quote marks and convert any inner pairs
      // of single quote marks to a single quote mark.
      //
      if( s.charAt( 0 ) == '\'' && s.charAt( length - 1 ) == '\'' )
/* #670 */ return stripExtraQuotes( s.substring( 1, length - 1 ) );
      else
         return s;
   }

   /* #670 */
   private String stripExtraQuotes(String s)
   {
      int endindex;
      //
      // If the string does not contain pairs of single quote marks,
      // merely return the input string.
      //
      if ( (endindex = s.indexOf("''")) < 0 )
         return s;
      
      //
      // The input string contains at least one pair of single quote marks.
      // Scan the string and remove one quote mark from each pair.
      //
      int startindex = 0;
      int length = s.length();
      StringBuffer sb = new StringBuffer(length);
      
      //
      // For each pair of single quote marks, build up a StringBuffer
      // of text that has one of the single quote marks removed.  The scan
      // of the input string proceeds left-to-right.
      while (startindex < length)
      {
         endindex = s.indexOf("''", startindex);
         if (endindex < 0)
            break;
         //
         // In the statement, below, the expression endindex + 1 causes 
         // the substring() method to include the first of the two single 
         // quote marks.
         //
         sb.append(s.substring(startindex, endindex + 1));
         startindex = endindex + 2;
      }
      
      // If there is any remaining text, append that now.
      //
      if (startindex < length)
         sb.append(s.substring(startindex));
      
      return sb.toString();
   }
   
   /* ListOperand will collect all ABTValues and add them to a
      Vector list.
   */
	class ListOperand implements SetExpression
	{
		public final ABTArray array = new ABTArray();

      public void setOperand( ABTValue value )
      {
         array.add( value );
      }
   }

   /* This builds the binary tree from the expression
   */
	public ABTValue getExpression( InputStream in )
		throws ParseException
	{
      WhereParser parser = new WhereParser( in );
      ASTStart n = parser.Start();

		ListOperand l = new ListOperand();
      n.jjtAccept( this, l );
      ABTValue a = (ABTValue)l.array.at( 0 );

      return a;
	}

   /* Each visit method below represents a visit by the parser for the
      varying kinds of nodes defined by the grammar.
   */
	public Object visit( SimpleNode node, Object data )
	{
		return node.childrenAccept( this, data );
	}

	public Object visit( ASTExpressionListNode node, Object data )
	{
      ListOperand l = new ListOperand();
      node.childrenAccept( this, l );

//HJB		((SetExpression)data).setOperand( new ABTArrayReference( l.array ) );

		return data;
	}

	public Object visit( ASTStart node, Object data )
	{
		ListOperand l = new ListOperand();
		node.childrenAccept( this, l );

		((SetExpression)data).setOperand( (ABTValue)l.array.at( 0 ) );

		return data;
	}

	public Object visit( ASTOrNode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression( mySession,ABT_EXPR_OR );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTAndNode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression( mySession,ABT_EXPR_AND );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTIdNode node, Object data )
	{
		SetExpression set = (SetExpression)data;
        ABTDynamicValue value = new ABTDynamicValue( mySession,my_array, "", node.name );
		set.setOperand( value );

		return data;
	}

	public Object visit( ASTPropertyOpNode node, Object data )
	{
		return data;
	}

   public Object visit( ASTExistsNode node, Object data )
   {
	   /* Get all of the children into an ABTArray
      */
      ListOperand l = new ListOperand();
      node.childrenAccept( this, l );

      /* The array contains as each element:
         0 - left property
         1 - right property
         2 - value
      */
      ABTDynamicValue d1 = (ABTDynamicValue)l.array.at( 0 );
      ABTDynamicValue d2 = (ABTDynamicValue)l.array.at( 1 );
      ABTExistsClause e = new ABTExistsClause( mySession,my_array,
         d1.getField(), d2.getField(), node.operation,
         (ABTValue)l.array.at( 2 ) );

      ((SetExpression)data).setOperand( e );

		return data;
	}

	public Object visit( ASTAllNode node, Object data )
	{
	   /* Get all of the children into an ABTArray
      */
      ListOperand l = new ListOperand();
      node.childrenAccept( this, l );

      /* The array contains as each element:
         0 - left property
         1 - right property
         2 - value
      */
      ABTDynamicValue d1 = (ABTDynamicValue)l.array.at( 0 );
      ABTDynamicValue d2 = (ABTDynamicValue)l.array.at( 1 );
      ABTAllClause e = new ABTAllClause( mySession,my_array,
         d1.getField(), d2.getField(), node.operation,
         (ABTValue)l.array.at( 2 ) );

      ((SetExpression)data).setOperand( e );

		return data;
	}

	public Object visit( ASTNoneNode node, Object data )
	{
	   /* Get all of the children into an ABTArray
      */
      ListOperand l = new ListOperand();
      node.childrenAccept( this, l );

      /* The array contains as each element:
         0 - left property
         1 - right property
         2 - value
      */
      ABTDynamicValue d1 = (ABTDynamicValue)l.array.at( 0 );
      ABTDynamicValue d2 = (ABTDynamicValue)l.array.at( 1 );
      ABTNoneClause e = new ABTNoneClause( mySession,my_array,
         d1.getField(), d2.getField(), node.operation,
         (ABTValue)l.array.at( 2 ) );

      ((SetExpression)data).setOperand( e );

		return data;
	}

	public Object visit( ASTTrueNode node, Object data )
	{
		SetExpression set = (SetExpression)data;
		ABTBoolean value = new ABTBoolean( true );
		set.setOperand( value );

		return data;
	}

	public Object visit( ASTFalseNode node, Object data )
	{
		SetExpression set = (SetExpression)data;
		ABTBoolean value = new ABTBoolean( false );
		set.setOperand( value );

		return data;
	}

	public Object visit( ASTIntegerLiteralNode node, Object data )
	{
		SetExpression set = (SetExpression)data;
		ABTInteger value = new ABTInteger( Integer.parseInt( node.toString() ) );
		set.setOperand( value );

		return data;
	}

	public Object visit( ASTFloatLiteralNode node, Object data )
	{
		double	nodedouble = 0.0;
		try
		{
			Double d = Double.valueOf( node.toString() );
			nodedouble = d.doubleValue();
		}
		catch( Exception e ) {}

		ABTDouble value = new ABTDouble( nodedouble );

		SetExpression set = (SetExpression)data;
		set.setOperand( value );

		return data;
	}

   public Object visit( ASTTableRefNode node, Object data )
   {
	   /* Get all of the children into an ABTArray
      */
      ListOperand l = new ListOperand();
      node.childrenAccept( this, l );

		SetExpression set = (SetExpression)data;
         ABTTableRefClause value = new ABTTableRefClause( mySession,my_array, "", node.name );
		set.setOperand( value );

		return data;
	}

	public Object visit( ASTNullNode node, Object data )
	{
		SetExpression set = (SetExpression)data;
		ABTValue value;

      if( node.isNegated )
         value = new ABTNotNull();
      else
         value = new ABTNull();

		set.setOperand( value );

		return data;
	}

	public Object visit( ASTIsNode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression( mySession,
         ABT_EXPR_IS );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTStringLiteralNode node, Object data )
	{
		SetExpression set = (SetExpression)data;
		ABTString value = new ABTString( stripSingleQuotes( node.toString() ) );
		set.setOperand( value );

		return data;
	}

	public Object visit( ASTLTNode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression( mySession,ABT_EXPR_SMALLER );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTGTNode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression( mySession,ABT_EXPR_GREATER );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTEQNode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression(mySession, ABT_EXPR_EQUAL );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTBetweenNode node, Object data )
	{
		ABTLogicalExpression exp =
         new ABTLogicalExpression( mySession,node.isNegated ? ABT_EXPR_NOTBETWEEN : ABT_EXPR_BETWEEN );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
      ListOperand l = new ListOperand();
		node.childrenAcceptRight( this, l );
//HJB      exp.setRightOperand( new ABTArrayReference( l.array ) );
		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTInNode node, Object data )
	{
		ABTLogicalExpression exp =
         new ABTLogicalExpression( mySession,node.isNegated ? ABT_EXPR_NOTIN : ABT_EXPR_IN );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTLENode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression(mySession, ABT_EXPR_SMALLEREQUAL );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTGENode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression(mySession, ABT_EXPR_GREATEREQUAL );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTNENode node, Object data )
	{
		ABTLogicalExpression exp = new ABTLogicalExpression(mySession, ABT_EXPR_NOTEQUAL );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}

	public Object visit( ASTLikeNode node, Object data )
	{
		ABTLogicalExpression exp =
			new ABTLogicalExpression(mySession, node.isNegated ? ABT_EXPR_NOTLIKE : ABT_EXPR_LIKE );
		node.childrenAcceptLeft( this, new LeftOperand( exp ) );
		node.childrenAcceptRight( this, new RightOperand( exp ) );

		((SetExpression)data).setOperand( exp );

		return data;
	}
}