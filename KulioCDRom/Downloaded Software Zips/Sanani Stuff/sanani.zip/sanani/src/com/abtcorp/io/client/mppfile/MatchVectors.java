package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.abtcorp.core.*;


public class MatchVectors
{

   protected Vector     tasksVector_;
   protected Vector     resourcesVector_;
   protected Vector     assignmentsVector_;
   protected Vector     dependenciesVector_;
   protected Vector     toBeDeletedVector_;

   public MatchVectors()
   {
      tasksVector_           = new Vector();
      resourcesVector_       = new Vector();
      assignmentsVector_     = new Vector();
      dependenciesVector_    = new Vector();
      toBeDeletedVector_     = new Vector();
   }

   //protected version of the functions
   protected void add(MppOsMatch match)
   {
      ABTValue mppAbtValue = match.getMppObject();

      if (mppAbtValue instanceof Task) {

         tasksVector_.addElement(match);

      } else if (mppAbtValue instanceof Resource) {

         resourcesVector_.addElement(match);

      } else if (mppAbtValue instanceof Assignment) {

            assignmentsVector_.addElement(match);

      }
      //else throw and error or something
   }

   //add dependency
   protected void add(MppOsDependencyMatch match)
   {
      dependenciesVector_.addElement(match);
   }

//   protected void add(MppOsAssignmentMatch match)
//   {
//      assignmentsVector_.addElement(match);
//   }

   void removeFromVector(MppOsMatch match)
   {

      if (match.getMppObject() != null) {

         ABTValue mppAbtValue = match.getMppObject();

         if (mppAbtValue instanceof Task) {

            tasksVector_.removeElement(match);

         } else if (mppAbtValue instanceof Resource) {

            resourcesVector_.removeElement(match);

         } else if (mppAbtValue instanceof Assignment) {

            assignmentsVector_.removeElement(match);

         }

      } else {

         IABTObject obj = match.getOsObject();

         String typeString = obj.getObjectType();

         if (typeString.equals("pm.Task"))
            tasksVector_.removeElement(match);
         else if (typeString.equals("pm.Resource"))
            resourcesVector_.removeElement(match);
         else if (typeString.equals("pm.Assignment"))
            assignmentsVector_.removeElement(match);
            //         if (typeString.equals("pm.Dependency"))
      }
   }

   protected void removeFromVector(MppOsDependencyMatch match)
   {
      dependenciesVector_.removeElement(match);
   }



   //public version of the functions
   public void addToVector(MppOsMatch match)
   {
      ABTValue mppAbtValue = match.getMppObject();

      if (mppAbtValue instanceof Task) {

         tasksVector_.addElement(match);

      } else if (mppAbtValue instanceof Resource) {

         resourcesVector_.addElement(match);

      }//else throw and error or something
   }

   //add dependency

   public void addToVector(MppOsDependencyMatch match)
   {
      dependenciesVector_.addElement(match);
   }

   public void addToVector(MppOsAssignmentMatch match)
   {
      assignmentsVector_.addElement(match);
   }

   void toBeDeleted(UpdateIndicator match)
   {
      toBeDeletedVector_.addElement(match);
   }

   void removeToBeDeleted()
   {

      Enumeration toBeDeletedEnumeration = toBeDeletedVector_.elements();

      while (toBeDeletedEnumeration.hasMoreElements()) {

         UpdateIndicator match = (UpdateIndicator) toBeDeletedEnumeration.nextElement();

         if (match instanceof MppOsDependencyMatch)
            removeFromVector ((MppOsDependencyMatch)match);

         if (match instanceof MppOsMatch)
            removeFromVector((MppOsMatch)match);
      }

      toBeDeletedVector_.removeAllElements();

   }

   protected Enumeration getTasksEnumerator()         {return tasksVector_.elements();}
   protected Enumeration getResourcesEnumerator()     {return resourcesVector_.elements();}
   protected Enumeration getAssignmentEnumerator()    {return assignmentsVector_.elements();}
   protected Enumeration getDependenciesEnumerator()  {return dependenciesVector_.elements();}

}




