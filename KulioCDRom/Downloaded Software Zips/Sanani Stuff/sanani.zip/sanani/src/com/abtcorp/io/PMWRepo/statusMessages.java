package com.abtcorp.io.PMWRepo;

import java.util.ListResourceBundle;

public class statusMessages extends ListResourceBundle
   {
 	public Object[][] getContents() {
 		return contents;
 	}
 	static final Object[][] contents = {
 	   // LOCALIZE THIS
 	   {"100","Preparing to populate project"},
 	   // END OF MATERIAL TO LOCALIZE
      };
   }