package com.abtcorp.io.team.connect;

import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;
import com.abtcorp.io.team.ProjectPopulator;
import com.abtcorp.io.team.TWPopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.UserRight;
import com.abtcorp.io.team.Right;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTSortedArray;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.idl.IABTPropertyType;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

import com.abtcorp.io.team.ResourcePopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.TWPopulator;
import com.abtcorp.io.team.UserPopulator;

public class ConnectUserPopulator extends UserPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants, IABTPropertyType
{
   private String server_;
   private String readSQL_;
   private String writeSQL_;
   private ABTCursor    readCursor_   = null;
   private ABTCursor    writeCursor_   = null;

   public ConnectUserPopulator() {}

   public ConnectUserPopulator(ABTRepositoryDriver driver)
   {
      super(driver);
   }

   public void setServerName(String server) {server_ = server;}
   public String getServerName() {return server_;}

   public ABTValue populate() throws ABTException
   {
   	readSQL_ = "SELECT * FROM PRResource" +
                     " WHERE prIsOpen <> 0" +
                     " AND prIsRole = 0" +
                     " AND prTrackMode = 2" +
                     " AND prServerName = '" + server_ + "'";
   	writeSQL_ = "SELECT * FROM PRTemporary WHERE prID = -1";
   	
   	
      ABTObjectSet users = getObjectSet(OBJ_TW_USER);

      if (users == null || cursor_ == null) return null;

      ABTCursor tempCursor = getDriver().getRepository().select("select * from PRTemporary where prID = -1");
      while(cursor_.moveNext()) {
         tempCursor.addNew();
         tempCursor.setFieldString(FLD_NAME,cursor_.getFieldString(FLD_NAME));
         tempCursor.setFieldInt(FLD_SESSIONID,getDriver().getSession().getID());
         tempCursor.setFieldInt(FLD_RECORDID1,cursor_.getFieldInt(FLD_ID));
         tempCursor.update();
      }

      tempCursor.release();

      // Get all users that are explicitly associated with resources for this server.
      tempCursor = getDriver().getRepository().select("select distinct PRTemporary.prRecordID1 from PRTemporary, PRResource where " +
                                                      "PRResource.prUserName=PRTemporary.prName and " +
                                                      "PRTemporary.prSessionID=" + getDriver().getSession().getID() + " and " +
                                                      "PRResource.prServerName='" + server_ + "' order by PRTemporary.prRecordID1");
      cursor_.moveFirst();
   	// Cache the rights information for the users we care about.
   	ABTCursor rightCursor = getDriver().getRepository().getSession().getSystem().select("Select * from PRRight order by prUserID");
   	
      do {
         ABTValue id = cursor_.getField(FLD_ID);
         
         if (userRights_ == null) userRights_ = new ABTSortedArray();
         UserRight u = new UserRight(id.intValue());
      	userRights_.add(u);
         if (rightCursor.bsearchFirst(FLD_USERID,id)) {
            Right r = createRight(rightCursor,id.intValue());
            u.addRight(r);
            while(rightCursor.bsearchNext(FLD_USERID,id)) {
               r = createRight(rightCursor,id.intValue());
               u.addRight(r);
            }
         }
      } while (cursor_.moveNext());

   	rightCursor.release();
      
   	// Cache rights for group information as well.
   	ABTCursor memberCursor = getDriver().getRepository().getSession().getSystem().select("Select * from PRMember order by prUserID");
   	rightCursor = getDriver().getRepository().getSession().getSystem().select("Select * from PRRight order by prGroupID");
   	
      while(memberCursor.moveNext()) {
         if (userRights_ == null) userRights_ = new ABTSortedArray();

      	int userid = memberCursor.getField(FLD_USERID).intValue();
         UserRight u = new UserRight(userid);
         int idx = userRights_.indexOf(u);
         if (idx == -1) userRights_.add(u);
         else u = (UserRight)userRights_.at(idx);
         
         if (rightCursor.bsearchFirst(FLD_GROUPID,memberCursor.getField(FLD_GROUPID))) {
            Right r = createRight(rightCursor,userid);
            u.addRight(r);
            while(rightCursor.bsearchNext(FLD_GROUPID,memberCursor.getField(FLD_GROUPID))) {
               r = createRight(rightCursor,userid);
               u.addRight(r);
            }
         }
      }
   	
   	rightCursor.release();
   	memberCursor.release();
   	
   	cursor_.moveFirst();
   	// Create objects for those users on resources explicitly assigned to this web server.
   	while(tempCursor.moveNext()) {
   		if (cursor_.bsearchFirst(FLD_ID,tempCursor.getField(FLD_RECORDID1))) {
   			try {
      			ABTObject user = (ABTObject)addObject(users);
      			initializeUserResourceRights(user);
   				cursor_.drop();
   			   addUserToRightList(user);
   				updateStatus(user);
   			} catch (Exception e) {
   			}
   		}
   	}
      
   	tempCursor.release();
   	
   	if (cursor_.moveFirst()) {
   		// Create objects for those users that have resource rights over resources assigned to this web server.
   	   initializeReadSQL();
         do {
   			
            readCursor_.moveFirst();
         	do {
            	if (checkRightForID(readCursor_,CAN_ENTERTIME,cursor_.getField(FLD_ID).intValue()) || checkRightForID(readCursor_,CAN_APPROVEACTUALS,cursor_.getField(FLD_ID).intValue())) {
      			   try {
         				ABTObject user = (ABTObject)addObject(users);
   		   	      initializeUserResourceRights(user);
   			      	addUserToRightList(user);
   			      	updateStatus(user);
   			      } catch (Exception e) {
   			      }
            	} 
   			} while (readCursor_.moveNext());
   		} while(cursor_.moveNext());
   	}
      
      count_ = total_;

      if (users instanceof ABTObjectSet && users.size(getSession()) > 0) updateStatus((ABTObject)users.at(getSession(),0));
      
      closePopulatorCursor();
   	
   	if (readCursor_ != null) readCursor_.release();
   	if (writeCursor_ != null) writeCursor_.release();
     
      return users;
   } 
   
	protected void initializeUserResourceRights(ABTObject user)
   {
      ABTException exception     = null;
      ABTValue     userName      = user.getValue(getSession(), FLD_TW_NAME);
      int          rightsLevel;
      int          sessionID     = getDriver().getSession().getID();

      try {
         initializeReadSQL();
      	if (readCursor_.moveFirst()) {
         	do {
               rightsLevel = 0;
               if (checkRightForUser(readCursor_,CAN_ENTERTIME,user)) rightsLevel = rightsLevel + ENTER_TIME_RIGHT;
               if (checkRightForUser(readCursor_,CAN_APPROVEACTUALS,user)) rightsLevel = rightsLevel + APPROVE_RIGHT;
               if (readCursor_.getFieldString(FLD_NAME).equals(userName.stringValue())) rightsLevel = rightsLevel + USER_RIGHT;

               if (rightsLevel > 0) {
                  writeCursor_.addNew();
                  writeCursor_.setFieldString(FLD_NAME, "ResourceRights");
                  writeCursor_.setFieldInt(FLD_SESSIONID, sessionID);
                  writeCursor_.setFieldInt(FLD_RECORDID1, readCursor_.getFieldInt(FLD_ID));
                  writeCursor_.setFieldInt(FLD_RECORDID2, user.getValue(getSession(), FLD_TW_ID).intValue());
                  writeCursor_.setFieldInt(FLD_FLAGS, rightsLevel);
                  writeCursor_.update();
               }
            } while (readCursor_.moveNext());
      	}

      } catch (Exception e) {
         if (e instanceof ABTException) exception = (ABTException)e;
         else e.printStackTrace();
      }
   	
   }
	
	protected boolean checkRightForUser(ABTCursor cursor, String right, ABTObject user)
   {
   	return checkRightForID(cursor,right,user.getValue(getSession(),FLD_TW_ID).intValue());   	
   }
	
	private boolean checkRightForID(ABTCursor cursor, String right, int userid)
   {
   	UserRight u = new UserRight(userid);
   	int idx = userRights_.indexOf(u);
   	
   	if (idx == -1) return false; // No rights cached for this userid!
   	
   	u = (UserRight)userRights_.at(idx);

   	return u.hasRight(right,cursor,cursor.getTableName(),cursor.getField(FLD_ID).intValue());
   }
	
	private void initializeReadSQL()
   {
      if (readCursor_ == null) readCursor_ = getDriver().getRepository().select(readSQL_);
      if (writeCursor_  == null) writeCursor_ = getDriver().getRepository().select(writeSQL_);
   }
	
	protected void addUserToRightList(ABTObject user)
   {
   	if (userRights_ == null || user == null) return;
   	
   	int id = user.getValue(getSession(),FLD_TW_ID).intValue();
   	
   	UserRight u = new UserRight(id);
   	
   	int idx = userRights_.indexOf(u);
   	
   	if (idx == -1) return;
   	
   	u = (UserRight)userRights_.at(idx);
   	u.setUserObject(user);
   }
}