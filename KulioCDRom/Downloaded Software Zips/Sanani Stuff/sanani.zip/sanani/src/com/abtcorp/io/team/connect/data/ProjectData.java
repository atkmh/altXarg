package com.abtcorp.io.team.connect.data;

import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.io.team.*;
import com.abtcorp.objectModel.team.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTObjectSet;

public class ProjectData extends ObjectDataAdapter implements IABTTWRuleConstants
{
   public ProjectData(ABTObject object, ABTUserSession session) throws ABTException
   {
      super(object,session);

      if (object.getObjectType() != OBJ_TW_PROJECT) throw new ABTException("Invalid object type: " + object.getObjectType());
   }

   public Hashtable getValues()
   {
      Hashtable table = super.getValues();

      ABTPropertySet properties = object_.getProperties();
      for (Enumeration e = properties.elements();e.hasMoreElements();) {
         ABTProperty property = (ABTProperty)e.nextElement();
         
         ABTValue value = object_.getValue(session_,property.getName());

         if (value != null && !ABTError.isError(value) && !ABTEmpty.isEmpty(value)) {

            // Charge codes are saved as ids to the objects themselves.
            if (property.getName().equals(FLD_TW_CHARGECODE) || property.getName().equals(FLD_TW_FIRST) || property.getName().equals(FLD_TW_LAST)) {

               ABTValue object = object_.getValue(session_,property.getName());
               if (ABTError.isError(object) || ABTEmpty.isEmpty(object)) continue;

               ABTValue id = ((ABTObject)object).getValue(session_,FLD_TW_INTERNALID);
               table.put(property.getName(),id);

            }
            else if (property.getName().equals(FLD_TW_NOTES)) table.put(property.getName(),getNotes((ABTObjectSet)value));
            else if (property.getName().equals(FLD_TW_SITE)) {
               // Save the site object as a hashtable of values with the project.
               ABTValue site = object_.getValue(session_,property.getName());
               if (site instanceof ABTObject) {
                  Hashtable siteValues = new Hashtable(5,(float)1.0);
                  ABTPropertySet siteProperties = ((ABTObject)site).getProperties();
                  if (siteProperties != null) {
                     for (Enumeration siteProps = siteProperties.elements();siteProps.hasMoreElements();) {
                        ABTProperty name = (ABTProperty)siteProps.nextElement();
                     	ABTValue siteValue = ((ABTObject)site).getValue(session_,name.getName());
                     	if (siteValue instanceof ABTError) continue;
                        siteValues.put(name.getName(),siteValue);
                     }
                     
                     table.put(property.getName(),siteValues);
                  }
               }
            }
            else table.put(property.getName(),value);
         }
      }
      return table;
   }
}