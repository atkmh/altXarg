package  com.abtcorp.objectModel.abt.fr;

/*
 * CustomType.java 08/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 08-13-98       LZX           Initial Design
 *
 */

import   java.util.*;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule will check if the new value to be set to is valid.
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class CustomType extends SiteFieldRule
{

   /**
    * Validate the value that is being set into the parent object container.
    * Return an ABTError if the value is invalid.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      // make sure the new value not null
      if (!ABTValue.isNull(newValue))
      {
         short val = newValue.shortValue();

         // if the new value is one of the valid enum values, set it. Otherwise
         // return an error.
         if ((val == CUST_STRING) ||
             (val == CUST_SHORT) ||
             (val == CUST_LONG) ||
             (val == CUST_DOUBLE) ||
             (val == CUST_TIMESTAMP) ||
             (val == CUST_BINARY))
            return write( session, parent, property, myValue, newValue, false );

         else
            return new ABTError( "CustomType",
               "onSet",
               errorMessages.ERR_INVALID_VALUE,
               "mmCustom.mmType must be " + CUST_STRING + ", " + CUST_SHORT + ", " + CUST_LONG + ", "
                     + CUST_DOUBLE + ", " + CUST_TIMESTAMP + ", or " + CUST_BINARY
                      + ". bad value = " + val );
      }

      // can't set to null, return an error.
      return new ABTError( "CustomType",
               "Set",
               errorMessages.ERR_INVALID_VALUE,
               "Attempting to set mmCustom.mmType to null. It must be " + CUST_STRING + ", " + CUST_SHORT + ", " + CUST_LONG + ", "
                     + CUST_DOUBLE + ", " + CUST_TIMESTAMP + ", or " + CUST_BINARY);
   }
}
