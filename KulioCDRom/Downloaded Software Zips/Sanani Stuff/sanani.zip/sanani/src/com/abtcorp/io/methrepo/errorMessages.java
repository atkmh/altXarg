package com.abtcorp.io.methrepo;

import com.abtcorp.core.ABTErrorCode;
import com.abtcorp.core.IABTErrorPriorities;

public interface errorMessages extends IABTErrorPriorities
{



public static final String Package = "com.abtcorp.io.methrepo".intern();
public static final ABTErrorCode ERR_ERROR_OCCURRED = new ABTErrorCode(Package, "ERR_ERROR_OCCURRED", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_CANNOT_LOCK_THINLY = new ABTErrorCode(Package, "ERR_CANNOT_LOCK_THINLY", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_ID = new ABTErrorCode(Package, "ERR_INVALID_ID", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INSUFFICIENT_RIGHT = new ABTErrorCode(Package, "ERR_INSUFFICIENT_RIGHT", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_MISSING_EXTID = new ABTErrorCode(Package, "ERR_MISSING_EXTID", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_KEY = new ABTErrorCode(Package, "ERR_INVALID_KEY", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_COMMAND = new ABTErrorCode(Package, "ERR_INVALID_COMMAND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_SOURCE = new ABTErrorCode(Package, "ERR_INVALID_SOURCE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_PROPERTYSET = new ABTErrorCode(Package, "ERR_INVALID_PROPERTYSET", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_HASH = new ABTErrorCode(Package, "ERR_INVALID_HASH", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_UNABLE_TO_CONNECT = new ABTErrorCode(Package, "ERR_UNABLE_TO_CONNECT", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_SELECT_ERROR = new ABTErrorCode(Package, "ERR_SELECT_ERROR", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_LOCK_NOT_HELD = new ABTErrorCode(Package, "ERR_LOCK_NOT_HELD", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_RECORD_NOT_FOUND = new ABTErrorCode(Package, "ERR_RECORD_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_LOCK_ERROR = new ABTErrorCode(Package, "ERR_LOCK_ERROR", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_DUPLICATE_METHOD = new ABTErrorCode(Package, "ERR_DUPLICATE_METHOD", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_GLOBAL_NOT_FOUND = new ABTErrorCode(Package, "ERR_GLOBAL_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_TABLE = new ABTErrorCode(Package, "ERR_INVALID_TABLE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_INVALID_TYPE = new ABTErrorCode(Package, "ERR_INVALID_TYPE", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_OBJECT_NOT_FOUND = new ABTErrorCode(Package, "ERR_OBJECT_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_OBJECTSET_NOT_FOUND = new ABTErrorCode(Package, "ERR_OBJECTSET_NOT_FOUND", UNRECOVERABLE_ERROR );
public static final ABTErrorCode ERR_NOT_IMPLEMENTED = new ABTErrorCode(Package, "ERR_NOT_IMPLEMENTED", UNRECOVERABLE_ERROR );

}