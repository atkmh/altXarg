package com.abtcorp.io.team;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class NotePopulator extends TWPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants
{
   protected String type_;

   public NotePopulator() {}
   public NotePopulator(ABTRepositoryDriver driver, String objectType)
   {
      this(driver,objectType,null,null);
   }

   public NotePopulator(ABTRepositoryDriver driver, String objectType, ABTObjectSpace space, ABTUserSession session)
   {
      super();
      setDriver(driver,space,session);
      type_ = objectType;
   }

	public ABTValue addObject(ABTObject object, ABTCursor noteCursor)
   {
      ABTObject note = null;

      // set required parameters for creating a note
      ABTInteger parentType = null;
   	if (object.getObjectType().equals(OBJ_TW_TIMESHEET)) parentType = new ABTInteger(TIMESHEET_NOTE);
      else if (object.getObjectType().equals(OBJ_TW_PROJECT)) parentType = new ABTInteger(PROJECT_NOTE);
      else if (object.getObjectType().equals(OBJ_TW_TASK)) parentType = new ABTInteger(TASK_NOTE);

      ABTHashtable table = new ABTHashtable();
      table.putItemByKey(new ABTString(PARENT_TYPE),parentType);
      table.putItemByKey(new ABTString(PARENT_ID),object.getValue(session_,FLD_TW_INTERNALID));

      // create the note and set its field values
      note = (ABTObject)getDriver().getSpace().createObject(session_,OBJ_TW_NOTE,null,table);
      note.setValue(session_,FLD_TW_ID,noteCursor.getField(FLD_ID));
      note.setValue(session_,FLD_TW_CATEGORY,noteCursor.getField(FLD_CATEGORY));
      note.setValue(session_,FLD_TW_TEXT,noteCursor.getField(FLD_VALUE));
      note.setValue(session_,FLD_TW_CREATEDTIME,noteCursor.getFieldTime(FLD_CREATEDTIME));
      note.setValue(session_,FLD_TW_CREATEDBY,noteCursor.getField(FLD_CREATEDBY));
      note.setValue(session_,FLD_TW_MODIFIEDTIME,noteCursor.getFieldTime(FLD_MODTIME));
      note.setValue(session_,FLD_TW_MODIFIEDBY,noteCursor.getField(FLD_MODBY));
      RemoteID.setRemoteID(note,session_);

      ABTValue check = object.getValue(session_,FLD_TW_NOTES,null);
      if (!ABTError.isError(check)) {
         ABTObjectSet set = null;

         if (!ABTEmpty.isEmpty(check)) set = (ABTObjectSet)check;

         if (set.size(session_) == 0) {
            object.setValue(session_,FLD_TW_NOTES,set);
         }

         set.add(session_,note);
      }

   	return note;
   }

   public void setObjectType(String objectType) {type_ = objectType;}

   public ABTValue populate() throws ABTException
   {
   	// This method is never called by the driver explicitly.
   	
      return null; // We don't return all notes as they are saved on their various objects.
   }
}