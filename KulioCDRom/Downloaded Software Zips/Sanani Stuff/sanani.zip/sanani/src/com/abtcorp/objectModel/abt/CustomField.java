/*
 * CustomField.java
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date          Author       Description
  * 06-05-98      LZX          Initial implementation.
  * 10-01-98      SOB          StarTeam Change Request 152
  *
  */

package com.abtcorp.objectModel.abt;

import  com.abtcorp.objectModel.*;
import  com.abtcorp.core.*;
import  com.abtcorp.hub.*;

/**
 * CustomField is the object rule class that handles the methodology custom field business rules.
 *
 *
 * @version	1.0
 * @author      L. Xiao
 */

public class CustomField extends SiteRule
{

  /**
   * Default Constructor
   */
   public CustomField()
   {
      super();
   }

   /**
   * sets default properties for the methodology custom field object.
   */
   protected void setDefaultProperties()
   {
      //
      // Relationship Properties
      //
      addProperty( OFD_SITE, OFD_SITE_CAP, PROP_OBJECT, false, true, true, false, OBJ_SITE, null, null );
      addProperty( OFD_AGGREGATEFIELDS, OFD_AGGREGATEFIELDS_CAP, PROP_OBJECTSET, false, true, true, false, OBJ_AGGREGATEFIELD, null, null );
      addProperty( OFD_CUSTOMENUMS, OFD_CUSTOMENUMS_CAP, PROP_OBJECTSET, false, true, true, false, OBJ_CUSTOMENUM, null, null );

      //
      // Lucy:  are page member objects global objects?
      //
//      addProperty( OFD_PAGEMEMBERS, OFD_PAGEMEMBERS_CAP, PROP_OBJECTSET, false, true, true, false, OBJ_PAGEMEMBER, null, null );

      //
      // Field Properties
      //
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_TYPE, OFD_TYPECF_CAP, PROP_SHORT, false, true, true, false, null, FR_CUSTOMTYPE, ABTShort.valueOf("1") );

      ABTProperty prop;



      addProperty( OFD_EXTTYPE, OFD_EXTTYPE_CAP, PROP_SHORT, false, true, true, false, null, FR_CUSTOMEXTTYPE, null );
      prop = (ABTProperty)getProperties().back();
      ABTExtendedPropertyList enumeratedValues = new ABTExtendedPropertyList();
      enumeratedValues.add( CUST_MONEY,      new ABTString( "Money" ) );
      enumeratedValues.add( CUST_DATE,       new ABTString( "Date" ) );
      enumeratedValues.add( CUST_TIME,       new ABTString( "Time" ) );
      enumeratedValues.add( CUST_BOOLEAN,    new ABTString( "Boolean" ) );
      enumeratedValues.add( CUST_PERCENT,    new ABTString( "Percent" ) );
      enumeratedValues.add( CUST_ENUM,       new ABTString( "Enum" ) );
      enumeratedValues.add( CUST_REFERENCE,  new ABTString( "Reference" ) );
      enumeratedValues.add( CUST_MEMO,       new ABTString( "Memo" ) );
      enumeratedValues.add( CUST_AGGREGATE,  new ABTString( "Aggregate" ) );
      prop.setPropertyKey( PROP_KPOSSIBLEVALUES, enumeratedValues );

      addProperty( OFD_CAPTION, OFD_CAPTION_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(254));

      addProperty( OFD_CONSTRAINT, OFD_CONSTRAINT_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(254));

      addProperty( OFD_DEFAULT, OFD_DEFAULT_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(64));

/*#295*/      addProperty( OFD_GUIDELINES, OFD_GUIDELINES_CAP, PROP_STRING,
                    false, true, true, false, null, null, null );
//      addProperty( OFD_GUIDELINEID, OFD_GUIDELINEID_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(254));

      addProperty( OFD_NAME, OFD_NAME_CAP, PROP_STRING, false, true, true, false, null, FR_UNIQUEINOBJECTSPACE, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(16));
      makeIndex(prop);

      addProperty( OFD_FIELDNAME, OFD_FIELDNAME_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(16));
      prop.setPropertyKey(PROP_KEDITABLE, ABTBoolean.False());

      addProperty( OFD_GUIDELINE_URL, OFD_GUIDELINE_URL_CAP, PROP_STRING, true, true, false, true, null,FR_CUSTOMGUIDELINE_URL , null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(254));
      prop.setPropertyKey(PROP_KEDITABLE, ABTBoolean.False());

   }

   /**
    * adds a new object to an object set by calling the ABTObjectSet method
    *    <code>addToSet(String type, ABTUserSession,ABTValue,boolean)</code>.
    *
    * @param session    the session object for transaction support
    * @param parent     the <code>ABTObjectSet</code> that the new element is being added to.
    * @param newValue   the new <code>ABTObject</code> being added to the list
    * @param existing   true if <code>newValue</code> has been created by the caller, false if it has been initialized with default values
    *
    * @return ABTValue  ABTValue if successful, ABTError if not
    */
   protected ABTValue onAdd( ABTUserSession session, ABTObjectSet parent, ABTValue newValue, boolean existing )
   {
      return parent.addToSet( session, newValue, existing );
   }

   /**
    * removes an object from an object set by calling the ABTObjectSet method
    * <code>removeFromSet(ABTUserSession,ABTValue,int)</code>.
    *
    * @param session    the session object for transaction support
    * @param parent     the <code>ABTObjectSet</code> that the element is being removed from.
    * @param myValue    the <code>ABTObject</code> being removed
    * @param myIndex    the position within this <code>ABTObjectSet</code> of <code>myValue</code>
    *
    * @return ABTValue  ABTValue if successful, ABTError if not
    */
   protected ABTValue onRemove( ABTUserSession session, ABTObjectSet parent, ABTValue myValue, int myIndex )
   {
      return parent.removeFromSet( session, myValue, myIndex );
   }

  /**
   * removes all elements from the set by calling the ABTObjectSet method
   * <code>clearSet(ABTUserSession)</code>.
   *
   * @param session     the session object for transaction support
   * @param parent      the object set to be cleared.
   * @return ABTValue   check for ABTError....
   */
  protected ABTValue onClear (ABTUserSession session,ABTObjectSet parent)
  {
      return parent.clearSet(session);
  }

   /**
    * Rules to invoke when a custom field object is created.
    *<ul>
    *<li>Create the following object set properties that belong to the custom field:
    *<ul>       OFD_AGGREGATEFIELDS</ul>
    *<ul>       OFD_CUSTOMENUMS</ul>
    *<ul>       OFD_PAGEMEMBERS</ul>
    *</ul>
    *
    * @param session             the session object for transaction support
    * @param object              the new object being created
    * @param requiredParameters  hash table containing the required parameters
    *
    * @return ABTValue  returns any <code>ABTError</code> that may have been encountered
    *                    while accessing or setting properties.
    */
   protected ABTValue onInitialize( ABTUserSession session, ABTObject object, ABTHashtable parameters )
   {
      ABTValue v;

      //
      // Check required parameters.
      //
      v = setReqParm( session, object, parameters, OFD_SITE, OFD_CUSTOMFIELDS, "abt.CustomField->onInitialize" );
      if ( v instanceof ABTErrorRules )
         return v;

      // create all the object sets that belong to this custom field object.

      v = super.createObjectSet(session, object, OBJ_AGGREGATEFIELD, OFD_AGGREGATEFIELDS, "abt.CustomField->onInitialize");
      if( ABTError.isError( v ) )
         return v;

      /*
      v = super.createObjectSet(session, object, OBJ_PAGEMEMBER, OFD_PAGEMEMBERS, "abt.CustomField->onInitialize");
      if( ABTError.isError( v ) )
         return v;
      */

      v = super.createObjectSet(session, object, OBJ_CUSTOMENUM, OFD_CUSTOMENUMS, "abt.CustomField->onInitialize");
      if( ABTError.isError( v ) )
         return v;

      // Set the name field to a default unique value
      return object.setValue( session, OFD_NAME, new ABTString( object.getID().getUniqueId() ), parameters ) ;

   }

   /**
    * Rules to invoke when a custom field object is deleted.
    *<ul>
    *<li>Delete the objects from its OFD_CUSTOMENUMS list.
    *<li>Delete the objects from its OFD_AGGREGATEFIELDS list.
    *<li>Delete the objects from its OFD_PAGEMEMBERS list.
    *<ul>
    * @param session    the session object for transaction support
    * @param parent     the object to be deleted
    * @return ABTValue check for ABTError....
    */
   protected ABTValue onDelete( ABTUserSession session, ABTObject parent )
   {
      // check if this custom field is referenced by a page member. if yes, return error.
      ABTValue v = checkReference(session, parent, OFD_CUSTOMFIELD, OFD_NAME, com.abtcorp.idl.IABTMMRuleConstants.OBJ_MM_PAGEMEMBER);
      if ( ABTError.isError( v ) )
         return v;            
      
      // delete the custom enums that belong this custom field
      v = deleteList(session, parent, OFD_CUSTOMENUMS, "abt.CustomField->onDelete");
      if( ABTError.isError( v ) )
         return v;

      // delete the aggregate fields that belong this custom field
      v = deleteList(session, parent, OFD_AGGREGATEFIELDS, "abt.CustomField->onDelete");
      if( ABTError.isError( v ) )
         return v;

      // Remove this custom field from the site object's custom field list
      v = removeFromList( session, parent, OFD_SITE, OFD_CUSTOMFIELDS, "abt.CustomField->onDelete" );
      if( ABTError.isError( v ) )
         return v;

      // delete the custom field object itself
      return deleteObject( session, parent );
   }
}
