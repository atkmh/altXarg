/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTBoolean.java, 14, 10/13/98 9:42:52 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.core;

import java.io.*;

public class ABTBoolean extends ABTImmutableValue
{
   /*
   * nice helper
   */
   private static ABTBoolean false_ = null;
   private static ABTBoolean true_ = null;
   // We cannot extend from Boolean since it is final

   private static final long serialVersionUID = -3665804199014368530L;

   protected boolean value_;

    public void fromByte(byte[] input){};
    public byte[] fromByte(){ return null;};

   public ABTBoolean(boolean  value) {value_ = value;}
   public ABTBoolean(ABTValue value) {value_ = value.booleanValue();}

   // TODO: stringValue should be localized
   
   public boolean booleanValue() {return value_;}
   public short   shortValue()   {return value_ ? (short)1  : (short)0;}
   public int     intValue()     {return value_ ? (int)1    : (int)0;}
   public double  doubleValue()  {return value_ ? (double)1 : (double)0;}
   public String  stringValue()  {return value_ ? "true" : "false";}
   
   public static ABTBoolean valueOf(String string) {return new ABTBoolean(new ABTString(string));}
   
   // Don't ask, this is what JDK does

   public int hashCode() {return value_ ? 1231 : 1237;}

   // Warning: This is a loose compare since we will convert the argument
   //          using rounding, truncation or parsing

   public int compareTo(Object object) 
   {
    if (object == null) return 1;     
    return compareTo(((ABTValue)object).booleanValue());
   }

   public final int compareTo(boolean value)
   {
      if (value_ == value) return 0;
      
      return value ? -1 : +1;
   }

   // This optimizes the serialization

   private void writeObject(ObjectOutputStream stream) throws IOException
   {
      stream.writeBoolean(value_);
   }

   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
   {
      value_ = stream.readBoolean();
   }
   
   /**
   * helper function to return static boolean false
   */
   static public ABTBoolean False()
   {
    if (false_ == null)
        false_ = new ABTBoolean(false);
    return false_;
   }
   /**
   * helper function to return static boolean true
   */
   static public ABTBoolean True()
   {
    if (true_ == null)
        true_ = new ABTBoolean(true);
    return true_;
   }
}