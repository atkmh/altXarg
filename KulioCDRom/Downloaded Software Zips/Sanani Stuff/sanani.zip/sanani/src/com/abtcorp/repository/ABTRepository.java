package com.abtcorp.repository;

public class ABTRepository extends ABTNative
{
   ABTSession session_;

   ABTRepository(int handle, ABTSession session) {super(handle); session_ = session; session_.addref();}

   public void addref()                  {super.addref(); session_.addref();}
   public void release(boolean finalize) {super.release(finalize); session_.release(false);}

   public ABTSession getSession() {return session_;}

   public native int    getID();
   public native String getName();

   public native String    sqlString(String string);
   public native int       counter(String name);
   public native int       execute(String sql);
   public native ABTCursor select(String sql);
}