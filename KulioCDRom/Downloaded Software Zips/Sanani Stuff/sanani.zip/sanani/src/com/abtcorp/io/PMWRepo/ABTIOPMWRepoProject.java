package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoProject.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-09-98    SOB            Initial Implementation
 * 06-12-98    SOB            added CHILDTASKS to project object
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-16-98    SOB            Mods to support saving of a Project object
 * 07-21-98    SOB            Mods to support required params for object creation.
 * 08-07-98    SOB            Mods to support Widgeon data model changes.
 * 08-24-98    SOB            Mods to remove reading and setting of the project calendar; it's handled by the Site Driver
 * 09-10-98    SOB            Mods to support setting of project version # and project format for saveAs processing
 * 09-10-98    SOB            Mods to support acquiring a project lock when saving a new project to the repository
 * 10-09-98    SOB            Beginnings of progress reporting
 * 10-27-97    SOB            Support for OFD_LOCKEDBY
 * 12-09-98    SOB            #656
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoProject is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTProject object in the object space, or to save a project object back
 *  to the repository.
 *  <pre>
 *      ABTIOPMWRepoProject(ABTObjectSpace space,
 *                          ABTRepositoryDriver driver,
 *                          String extID,
 *                          long projID,
 *                          boolean populateFully);
 *
 *          - or -
 *
 *      ABTIOPMWRepoProject(ABTObjectSpace space,
 *                          ABTRepositoryDriver driver,
 *                          ABTObject project,
 *                          boolean forceAddNew);
 *
 *  </pre>
 *
 * @version	    $Revision: 42$
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 * @see         ABTProjectSaver
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTShort;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTSession;

public class ABTIOPMWRepoProject extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private String extID_ = null;
   private long projectID_ = -1;
   private boolean populateFully_ = false;
   private boolean previouslyExisted_ = false;
   private ABTObject projObj_ = null;
   private ABTValue passNumber_ = null;

   /**
    *
    */
   public ABTIOPMWRepoProject() {/* implicit call to super() here */}

   /**
    *    Constructor used by the populate process.
    */
   public ABTIOPMWRepoProject(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       String extID,
                       long projID,
                       boolean populateFully,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_PROJECT, OBJ_PROJECT, progress);
      extID_ = extID;
      projectID_ = projID;
      populateFully_ = populateFully;
   }

   /**
    *    Constructs a helper object to be used to save Project objects to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepository reference
    *    @param a Project object reference
    *    @forceAddNew true if an addNew() operation is being forced to the repository; false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoProject(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_PROJECT, OBJ_PROJECT, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;

      //
      // Get the project's external ID and save it for a SQL SELECT.
      //
      extID_ = getValue(projObj_, OFD_EXTERNALID).stringValue();
   }

   /**
    *    Determines if the project object this helper class built previously existed in
    *    the object space.
    *    @return true, if the project previously existed in the space; false, otherwise
    */
   public boolean previouslyExisted() {return previouslyExisted_;}

   /**
    *    Populates an object space with a Project object
    *    @param parms (currently not used)
    *    @return the project object that was populated
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
      ABTValue object = null;    // local handle for results

      getCursor();

      // populate object space and object set with fields from the project cursor...

      try
      {
         if (cursor_.moveNext())
         {
            if ( !cursor_.checkRight(IS_PROJECTVIEWER) )
               return new ABTError(COMP_PMREPODRIVER,
                                   "ABTIOPMWRepoProject->populate",
                                   errorMessages.ERR_NO_VIEW_RIGHT,
                                   null);

            //
            // Create a remote ID for this project.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));
            //
            // If the project has already been populated, merely return it to the caller.
            //
            // TO DO: Resolve project refresh issues, i.e., when should an existing object be
            //        refreshed from the repository vs. when should we merely return the
            //        existing project to the caller?  For now, if the populateFully variable
            //        is true, always go out to the repository and refresh the project's
            //        data.  If the project did not exist before, then go to the repository
            //        to get the data.
            //

            //
            // See if the project already exists in the object space.
            //
            object = find(OBJ_PROJECT, id_);

            //
            // If the object found is an ABTObject, then the project object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new project object in the object space and initialize
            // its properties from the repository.
            //
            if (object instanceof ABTObject)
            {
               previouslyExisted_ = true;
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
               object = create(null);
         }

         return object;
      }
      finally
      {
         closeCursor();
      }
   }

   /**
    *    Creates a new project object
    *    @param parms (currently not used)
    *    @return the newly-created Project object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      //
      // Ask the object space to create a new project object.  There are no required params
      // for project object creation.
      //

      ABTObject object = createObject(OBJ_PROJECT, id_, null);

      //
      // Initialize the properties of the new project object with values from the repository.
      //
      setValues((ABTObject) object);

      return object;
   }

   /**
    *    Updates an existing Project object
    *    @param parms the existing Project object
    *    @return the updated Project object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      setMiscProperties(object);

      boolean isFullyPopulated = false;
      ABTValue v = getValue(object, OFD_ISFULLYPOPULATED);
      if (!ABTValue.isNull( v ) && v.booleanValue() )
         isFullyPopulated = true;

      if ( isFullyPopulated )
         return object;

      //
      // populateFully_ will be true for projects that are being populated via the project's external ID.
      // populateFully_ will be false for projects that are being populated via the project's prID.
      //
      // populating projects via the external ID is specifed by an application invoking the driver.
      // populating projects via the prID is specified internally by the driver when it needs to populate
      // a subproject.  When populating subprojects, the driver knows the prID of the project, not the external ID
      //
      if (!populateFully_) return object;

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //

      setValues(object);

      return object;
   }

   private void setValues(ABTObject obj) throws ABTException
   {
   	//
   	// Set the project's property values from the ABT repository project table tuple.
   	// After the values have been set, make sure the FLD_CALENDAR is set. FLD_CALENDAR
   	// is a repository virtual field and is not set by setPropertyValues();
   	//
   	// BUG FIX:  Do not read and set the project calendar, after all. Calendars are now handled
   	// via the the Site Driver (08-24-98).
   	//

   	setPropertyValues(ps_, cursor_, obj);
   	setMiscProperties(obj);
   }

   private void setMiscProperties(ABTObject obj) throws ABTException
   {
   	ABTSession sess = driver_.getSession();

   	//
   	// Now set the project's READONLYRIGHT property, along with who owns the import/export lock, and whether
   	// or not the project is a MASTER project (that is, does this project have subprojects).
   	//
   	setValue(obj, OFD_READONLYRIGHT, (cursor_.checkRight(IS_PROJECTMANAGER) ? ABTBoolean.False() : ABTBoolean.True() ) );
   	int lockingUID = cursor_.checkLock(LCK_IMPORTEXPORT, false);
      setValue(obj, OFD_LOCKEDBYME, ( lockingUID == sess.getUserID() ?
                                      ABTBoolean.True() : ABTBoolean.False() ) );
      setValue(obj, OFD_LOCKEDBY, driver_.getUserName(lockingUID) );
      setValue(obj, OFD_ISMASTER, isMaster(obj) );
      
      setValue(obj, OFD_REPONAME, new ABTString(repo_.getName()) ); /* #656 */
      setValue(obj, OFD_FROMFILE, null);                            /* #656 */
   }

   private ABTBoolean isMaster(ABTObject obj) throws ABTException
   {
      ABTCursor cur = null;
      try
      {
         long projectID = getValue(obj, OFD_ID).intValue();
         cur = repo_.select(QRY_PROJECTSUBPROJECTS);
         cur.andFilter(TBL_TASK + "." + FLD_PROJECTID + " = " + projectID);
         cur.andFilter(TBL_SUBPROJECT + "." + FLD_ISIPD + " IS NULL" +
                       " OR " +
                       TBL_SUBPROJECT + "." + FLD_ISIPD + " = 0");
         int recordCount = cur.getRecordCount();
         return (recordCount > 0 ? ABTBoolean.True() : ABTBoolean.False());
      }
      finally
      {
         if (cur != null)
            cur.release();
      }
   }

   /**
    *
    */
   private void getCursor()
   {
      closeCursor();
      cursor_ = repo_.select(TBL_PROJECT);

      //
      // Build an "andFilter" string to select the project we want to populate.  The andFilter
      // string looks different depending on how we want to locate the project.  There are
      // two ways:  by the project's external ID, or by its prID in the PRProject table.
      //
      String proj = (extID_ != null) ? (FLD_EXTERNALID + " = " + repo_.sqlString( extID_ ) ) :
                     (FLD_ID + " = " + projectID_);
      cursor_.andFilter(proj);
   }

   // -------------------------------------------------------------------------------
   // save logic begins here.
   // -------------------------------------------------------------------------------

   /**
    *    Saves a Project object to the repository
    *    @param parms contains the pass number (currently ignored)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get a project cursor.
      //
      getCursor();

      //
      // Set some project values prior to saving them back to the Repository.
      //
      setSomeProperties();

      //
      // The generalized save() support for IOHelper objects takes an objectset as a single
      // input parameter.  Create one now and place the project object into it.
      //
      ABTObjectSet oSet = createObjectSet(OBJ_PROJECT);
      add(oSet, projObj_);

      //
      // Call the general save() method to save this project object to the repository.
      //
      save(oSet);

      //
      // When saving new projects, acquire a lock on the new project.
      //
      if (forceAddNew_)
         acquireLock(extID_, 0);

      closeCursor();
   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName the PRAPI column name that is about to be written to the repository
    *    @param   obj the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew true if the data being written is new to the repository, i.e., the
    *             operation is an add; false, otherwise
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
      boolean ret = false;       // assume NO exception

      //
      // Invoke the parent's isException() method.  If it claims an exception, honor it; otherwise,
      // make our own exception checks.
      //
      // Never save these fields:
      // 1. prFileName.
      // 2. prUserName /* #614 */
      //
      if ( super.isSaveException(prapiName, obj, prapiFlags, isNew) )
         ret = true;
      else if (prapiName.equals(FLD_FILENAME) ||
               prapiName.equals(FLD_USERNAME) /* #614 */ )
         ret = true;

      return ret;
   }

   private void setSomeProperties() throws ABTException
   {
      //
      // For all new projects going out to the Repository:
      //
      // 1. set the version number to 1
      // 2. set the project format to unknown
      //
      // Note:  these could just as easily be set as default properties when a project object is created.
      //
      if (forceAddNew_)
      {
         setValue(projObj_, OFD_VERSION, new ABTShort((short)1) );
         setValue(projObj_, OFD_FORMAT,  new ABTShort((short)PR_FORMAT_UNKNOWN) );
      }
   }

}