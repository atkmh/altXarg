package com.abtcorp.hub;

/*
 * ABTRemoteIDDate.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import java.util.Date;
import com.abtcorp.core.*;

 /*
   * abtract class to be implemented by drivers....
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */


public class ABTRemoteIDDate extends ABTRemoteID
{
    Date my_date;



    public ABTRemoteIDDate (Date d)
    {
        my_date = d;
    }
    public ABTRemoteIDDate()
    {
        my_date = new Date();
    }

    public Date getDate()
    {
        return my_date;
    }
     /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return boolean true for equal
    */
    public boolean   equals (Object object)
    {
        if (!(object instanceof ABTRemoteIDDate))
            return false;
        return  my_date.equals(((ABTRemoteIDDate)object).getDate());

    }

	/**
	*  required routine to allow unique access in sets
	* @return int - hashcode
	 */
	public int hashCode()
    {
        return my_date.hashCode();
    }

    /**
    *  - required routine to allow storing in sorted sets
    * @param object - to compare against
    * @return int 0 => equal, -1 => me < object2, 1 => me > object2
    */
    public int  compareTo  (Object object)
    {
        if (!(object instanceof ABTRemoteIDDate))
            return -1;
        Date d = ((ABTRemoteIDDate)object).getDate();
        if (my_date.equals(d)) return 0;
        return my_date.before(d) ? -1 : +1;
    }


   }