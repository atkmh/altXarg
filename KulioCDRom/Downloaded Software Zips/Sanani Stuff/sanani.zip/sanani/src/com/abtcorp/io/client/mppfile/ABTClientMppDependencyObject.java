package com.abtcorp.io.client.mppfile;

public class ABTClientMppDependencyObject
{

  public	int		  id_;
  public	int		  type_;
  public	char		operator_;
  public	double	lagOrLead_;
  public	int		  percentOrAmount_;

}
