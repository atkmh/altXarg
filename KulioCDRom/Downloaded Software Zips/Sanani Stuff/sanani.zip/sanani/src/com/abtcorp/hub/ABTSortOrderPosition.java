
package com.abtcorp.hub;

/*
 * ABTRowComparator.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

import com.abtcorp.core.*;
 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *                             
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

public class ABTSortOrderPosition
{   
   private String property;
   private int index;
   private boolean asc = true;
   
   public ABTSortOrderPosition(ABTPropertySet set_,String property_, boolean asc_)
   {
      property = property_;
      asc = asc_;
      index = set_.indexForName(property);
   }

   public ABTSortOrderPosition(ABTSortOrderPosition pos)
   {
      property = pos.getProperty();
      asc = pos.ascending();
      index = pos.getIndex();
   }

   public ABTSortOrderPosition(ABTPropertySet set_,int index_, boolean asc_)
   {
      asc = asc_;
      index = index_;
      property = set_.nameForIndex(index);
   }

   public String getProperty()
   {
      return property;
   }
   public boolean ascending()
   {
      return asc;
   }
   public int getIndex()
   {
      return index;
   }
   
}

