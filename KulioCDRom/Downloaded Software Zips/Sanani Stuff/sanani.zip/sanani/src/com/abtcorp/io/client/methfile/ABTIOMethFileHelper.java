package com.abtcorp.io.client.methfile;

/*
 * ABTIOMethFileHelper.java 10/1/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 10-21-98    MXA         Initial Implementation
 *
 *
 */

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTProperty;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTMMRuleConstants;
import com.abtcorp.idl.IABTHashTable;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTEnumerator;

import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTTime;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTFileDriver;
import com.abtcorp.io.client.ABTObjectSetIDList;


/**
 * ABTIOMethFileHelper is an abstract class for the ABT Methodology local file driver.
 * It is extended by the other Methodology local file helper classes.
 *
 *  <pre>
 *       ABTIOMethFileHelper ra = new ABTIOMethFileHelper(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 M. Abadian
 */

public abstract class ABTIOMethFileHelper extends ABTFileHelper implements IABTPropertyType, IABTRuleConstants, IABTMMRuleConstants
{

   protected ABTIOMethFileDriver driver_;  // the driver that uses this helper
   protected IABTObject      parent_;      // the parent that owns the objects to be populated/saved
   protected String          type_;        // the type of the object
   protected IABTObject      method_;      // the method object (parent of all other global objects)
   protected IABTLocalID     id_;
   protected IABTPropertySet propSet_;
   protected IABTArray       objArr_;
   protected IABTHashTable   reqParams_;


/**
 * ABTIOMethFileHelper constructor.
 * @param driver: the reference to the driver.
 */
   ABTIOMethFileHelper(ABTIOMethFileDriver driver,  IABTObject parent, String type)
   {
      driver_    = driver;
      parent_    = parent;
      type_      = type;
      space_     = driver.getSpace();      
      id_        = null;
      propSet_   = null;
      objArr_    = null;
      reqParams_ = (getSpace()).newABTHashTable();

   }

   
/**
 * Populate the object sets.
 * @return ABTValue: the desired object set or an ABTError.
 * @exception ABTException thrown if an unrecoverable error occurs.
 */
 protected ABTValue populate() throws ABTException
 {
	 ABTValue      ret    = null;  // local ABTObject
   	 IABTObjectSet oSet   = null;
     Object        obj    = null;


     try
      {
         propSet_   = getProperties(type_);
         // create an object set for the root objects. (allow adding to and removing from
         // the object set).
         if (parent_ == null)
      	   oSet = createObjectSet(type_);

         obj = null;
         obj = driver_.lookupTableGet(id_);
         if ( obj != null && obj instanceof IABTObject )
         {
            // TO DO UPDATE
           return null;
         }

         obj = null;
         obj = driver_.intermediateTableGet(id_);

         if (!(obj instanceof IABTArray))
            throw new ABTException(" Wrong type cast Objec Array");
         else
            objArr_ = (IABTArray)obj;

         ABTValue    val      = null;
         ABTRemoteID remoteId = null;
         val = getHashValue(objArr_, propSet_, PROP_REMOTEID);
         
          if (val instanceof ABTRemoteID)
            remoteId  = (ABTRemoteID) val;
         else if (ABTValue.isNull(val))  
            remoteId = null;
         else
            throw new ABTException(" Wrong type cast for remote ID ");

         // if not found, create an object for this assignment in the
         // object space and set its property values.
         ret = create(type_, remoteId, reqParams_);

         // add this object to the object set if it's a root level object.
         if (parent_ == null)
            add(oSet, (IABTObject) ret);
      }
     catch ( ABTException e)
     {
        new ABTException (e.getMessage());
     }
     catch (Exception e )
     {
        new ABTException (e.getMessage());
     }
      if (parent_ == null)
        return (ABTValue)oSet;   // allow add-to-set for root objects
      else
  	    return ret;
    }

/**
 *  Create a new object in the object space and initialize its properties.
 *	@param type: the type of the object to be created.
 *	@param id: the remote id to be used to create the object.
 *	@return ABTValue: a reference to the object created or an ABTError.
 *  @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(String type, ABTRemoteID id, IABTHashTable params) throws ABTException
   {
		IABTObject object = createObject(type, id, params);
		setScalarValues(propSet_, objArr_ , object);
		if ( (driver_.lookupTablePut(id_, object)) != null)
		    throw new ABTException(" The object already exists in the lookup table");
        return (ABTValue)object;
   }

/**
 * Save objects from the object space back to the local file
 * @param parent  the parent object that contains the object set to be saved
 * @param list    the name of the object set to save
 * @return ABTValue of the object set that's saved
 *	@exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue save(IABTObject parent, String list) throws ABTException
   {
    // get object set from the parent object
   	ABTValue val = getValue(parent, list);
   	if (!(val instanceof IABTObjectSet))
   	{
         processError(SEVERITY_ONE,
                     MOD_SAVE,
                     EXC_OBJECTSET_NOT_FOUND,
                     list + " object set is not found in " + parent_.getObjectType() + ". id = '" + getValue(parent_, OFD_ID));
         return null;
      }

    // make sure the object set is not null or empty
   	if (ABTValue.isNull(val))
   	{
         processError(SEVERITY_ONE,
                     MOD_SAVE,
                     EXC_OBJECTSET_NOT_FOUND,
                     list + " object set is null or empty in " + parent_.getObjectType() + ". id = '" + getValue(parent_, OFD_ID));
         return null;
      }

      return save((IABTObjectSet) val);
   }


   protected ABTValue save(IABTObjectSet oSet) throws ABTException
   {
      try
      {
        int size = size(oSet);
         // iterate through all the objects in the object set
         for (int i = 0; i < size; i++)
         {
            IABTObject obj = (IABTObject)at(oSet, i);

            // make sure the object is of the right type
            if (!obj.getObjectType().equals(type_))
            {
               processError(SEVERITY_ONE,
                           "->save()",
                           EXC_INVALID_TYPE,
                           "expected object type = " + type_ + ", bad type = " + obj.getObjectType());
               return null;
            }

            // Load the values of the properties associated with the object.
            IABTArray arr = null;
            arr = loadObjectPropertyValues(obj);
            if (arr==null)
                processError(SEVERITY_ONE,
                           "->save()",
                           "The properties associated with the object is null.",
                           "expected  ");


            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                processError(SEVERITY_ONE,
                           "->save()",
                           "TThe Intermediate Hash Table is null.",
                           "expected  ");


            IABTLocalID objId = obj.getID();
            if (objId == null)
                processError(SEVERITY_ONE,
                           "->save()",
                           "The Object ID is null.",
                           "expected  ");           

            if (( driver_.intermediateTablePut(objId, arr)) != null)
                processError(SEVERITY_ONE,
                           "->save()",
                           "The object id already exists in Intermediate Hash Table.",
                           "expected  ");


       //Debug
       /*
       System.out.println("\nThe Object: " + obj.getObjectType());
       IABTPropertySet propset = null;
       propset = getProperties(type_);
       printProperties(propset, arr);
       System.out.println("\n");
       */
       //Debug
         }
      }
      catch(Exception e)
      {
        new ABTException(e.getMessage());
      }
      finally
      {
         ;
      }

      return (ABTValue)oSet;
   }


/**
 * Get the the Intermediate Hash table ID for a particular type
 * @return the id or list of ids associated with the paticualr type
 * @exception ABTException if an unrecoverable error occurs.
 */
public ABTValue getIDs( IABTLocalID id, String parentType, String type )throws ABTException
{
    Object     obj           = null;
    IABTArray  objArr        = null;
    ABTValue   val           = null;
    IABTPropertySet propSet = null;

    obj = driver_.intermediateTableGet(id);

    if (!(obj instanceof IABTArray))
        throw new ABTException(" Wrong type cast Objec Array");
    else
        objArr = (IABTArray)obj;

    propSet = getProperties(parentType);
    val     = getHashValue(objArr, propSet, type);

    /*if (val instanceof ABTLocalID)
        return (ABTValue)val;
    else if (val instanceof ABTObjectSetIDList)
        return (ABTValue)val;
    else
        throw new ABTException(" Wrong type cast for remote ID ");
    */

    return val;
}





/**
 *    Populate an object space with an object (or objects) as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public ABTValue populate(ABTArray parms) throws ABTException {
      return null;
   }

/**
 *    Save an object (or objects) from the object space as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return void
 *		@exception ABTException if an unrecoverable error occurs.
 */
   public void save(ABTArray parms) throws ABTException {
   }


/**
 * Create a new object in the object space and initialize it with values appropriate to the
 * driver being used.
 *	@param ABTArray parms, the elements of which are meaningful as parameters to the particular
 * helper
 *	@return an ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue create(ABTArray parms) throws ABTException {
      return null;
   }

/**
 *    Update an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param ABTArray parms, the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object updated in the
 *    object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs.
 */

   protected ABTValue update(ABTArray parms) throws ABTException {
      return null;
   }
/**
 *    Processes an error situation raised by the caller.  If the severity level is 1, an
 *    exception is thrown.  For all other levels, a return to the caller is effected.
 *    @param severityLevel: the level of severity of the error; low numbers are more severe
 *    @param objType: the type of Sanani object in trouble
 *    @param exceptionName: an exception identifier string
 *    @param errorMessage: further text describing the error condition
 *    @return some kind of value (for now the severity level).
 *    @exception ABTException if the severity level is 1 (the highest severity)
 */
 public int processError(int severityLevel, String objType, String exceptionName, String errorMessage) throws ABTException
 {
   return driver_.processError(severityLevel, objType, exceptionName, errorMessage);
 }



/**
 * printProperties -Utility to print the properties type and name from a propertySet
 * @param ABtpropertySet
 * @return void
 */
protected void printProperties(IABTPropertySet propset, IABTArray arr)
{
try{
   if ( (arr == null) ||(propset == null) )
      throw new Exception("printProperties()  arr is null");
   Enumeration    itp_  = propset.getElements();
   IABTEnumerator ita_  = arr.getElements();

   while(itp_.hasMoreElements())
   {
      IABTProperty prop = ((IABTProperty)(itp_.nextElement()));
      System.out.print(" " + prop.getName() );
      if (prop.isVirtual())
         System.out.print(" is Virtual!");
      else if (ita_.hasMoreElements())
      {
        ABTValue val = null;
        Object valObj = ita_.nextElement();
        if (valObj == null)
            System.out.print(" = THE VALUE IS null ");
        else
        {
            if (valObj instanceof ABTValue)
                val = (ABTValue)(valObj);
            else
                throw new ABTException(" Wrong casting ");

            switch(prop.getType())
            {
                case PROP_INT:
                       System.out.print(" Integer ");
                       System.out.print( " " + val.intValue() );
                       break;
                    case PROP_STRING:
                       System.out.print(" String");
                       System.out.print( " = " + val.stringValue() );
                       break;
                    case PROP_OBJECT:
                        System.out.print(" Object ");
                        if ( val instanceof IABTLocalID)
                        {
                           IABTLocalID id = (IABTLocalID) val;
                           ABTInteger abti= null;
                           abti = new ABTInteger(id.getLocal()) ;
                           System.out.print( " OBJECT " + " ID = " + abti.intValue() + " " );
                        }
                       else
                           System.out.print( " = OBJECT not instance of ID ");
                       break;
                    case PROP_OBJECTSET:
                       System.out.print( " =  OBJECTSET ");
                       if (val instanceof ABTObjectSetIDList)
                       {
                            ABTObjectSetIDList valid = (ABTObjectSetIDList)val;
                            Enumeration iti_ = valid.getActiveIDs();
                             int counter =0;
                            while(iti_.hasMoreElements())
                            {
                                counter++;
                                ABTValue value = (ABTValue) (iti_.nextElement());
                                if ( value instanceof IABTLocalID)
                                {
                                    IABTLocalID ids = (IABTLocalID) value;
                                    ABTInteger abtsi= null;
                                    abtsi = new ABTInteger(ids.getLocal()) ;
                                    System.out.print( " OBJECT " + " ID = " + abtsi.intValue() + " " );
                
                                }
                                else
                                    System.out.print( " = OBJECT not instance of ID in OBJECTSET ");

                            }

                            //System.out.print("THE COUNTER IS :" + counter);
                       }
                       break;
                    case PROP_LONG:
                       System.out.print(" Long ");
                       break;
                    case PROP_BOOLEAN:
                       System.out.print(" Boolean ");
                       System.out.print( " = " + val.booleanValue() );
                       break;
                    case PROP_DOUBLE:
                       System.out.print(" Double ");
                       System.out.print( " = " + val.doubleValue() );
                       break;
                    case PROP_DATE:
                       System.out.print(" Date ");
                       break;
                    case PROP_TIME:
                       System.out.print(" Time ");
                       System.out.print( " = " + val.timeValue() );
                       break;
                    case PROP_TIMESTAMP:
                       System.out.print(" TimeStamp ");
                       break;
                    case PROP_BLOB:
                       System.out.print(" Blob ");
                       break;
                    case PROP_SHORT:
                       System.out.print(" Short ");
                       System.out.print( " =  " + val.shortValue() );
                       break;
                    case PROP_ID:
                        System.out.print(" Remote ID ");
                        break;
                    case PROP_UNKNOWN:
                    default:
                       System.out.print(" Unknown ");
                       break;
               }
         }
      }


   }
} catch (Exception e)
{
  e.printStackTrace();
}
}



}