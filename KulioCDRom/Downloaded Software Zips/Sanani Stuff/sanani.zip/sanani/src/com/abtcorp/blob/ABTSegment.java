package com.abtcorp.blob;

import com.abtcorp.core.*;
import java.io.Serializable;

public final class ABTSegment implements ABTComparable, Serializable
{
   private static final long serialVersionUID = 4098506642911137952L;
	private ABTTime     start_;
   private ABTTime     finish_;
   private double      rate_;
   private ABTCalendar calendar_;

   public ABTSegment(ABTTime start, ABTTime finish, double rate, ABTCalendar calendar) {start_ = start; finish_ = finish; rate_ = rate; calendar_ = calendar;}

   public final ABTTime     getStart()    {return start_;}
   public final ABTTime     getFinish()   {return finish_;}
   public final double      getRate()     {return rate_;}
   public final ABTCalendar getCalendar() {return calendar_;}

	public final double getRate(ABTTime time)                 {return isWorktime(time) ? rate_ : 0;}
	public final double getSum(ABTTime start, ABTTime finish) {return rate_ * diffWorktime(start, finish);}
	public final double getSum()                              {return getSum(null, null);}

   public final ABTTime getFirst()
   {
   	if (calendar_ == null) return start_;

   	ABTTime time = calendar_.nextWorktime(start_);

   	if (time != null && time.compareTo(finish_) < 0) return time;

   	return null;
   }

   public final ABTTime getLast()
   {
   	if (calendar_ == null) return finish_;

   	ABTTime time = calendar_.prevWorktime(finish_);

   	if (time != null && time.compareTo(start_) >= 0) return time;

   	return null;
   }

	private final boolean isWorktime(ABTTime time)
	{
   	if (! map(time) || rate_ == 0) return false;

   	return calendar_ != null ? calendar_.isWorktime(time) : true;
	}

	final ABTTime addWorktime(ABTTime time, double value)
	{
   	if (time == null) time = start_;

		if (value < 0) return subWorktime(time, -value);

		int duration = rate_ != 0 ? (int)Math.round(value / rate_) : 0;

		return calendar_ != null ? calendar_.addWorktime(time, duration) : time.add(duration);
	}

	final ABTTime subWorktime(ABTTime time, double value)
	{
   	if (time == null) time = finish_;

		if (value < 0) return addWorktime(time, -value);

		int duration = rate_ != 0 ? (int)Math.round(value / rate_) : 0;

		return calendar_ != null ? calendar_.subWorktime(time, duration) : time.sub(duration);
	}

	final int diffWorktime(ABTTime start, ABTTime finish)
	{
   	if (start  == null || start.compareTo(start_)   < 0) start  = start_;
   	if (finish == null || finish.compareTo(finish_) > 0) finish = finish_;

   	if (start.compareTo(finish) >= 0 || rate_ == 0) return 0;

   	return calendar_ != null ? calendar_.diffWorktime(start, finish) : ABTTime.diff(start, finish);
	}

	final int diffWorktime() {return diffWorktime(null, null);}

   final boolean map(ABTTime time)                  {return time.compareTo(start_) >= 0 && time.compareTo(finish_) < 0;}
   final boolean map(ABTTime start, ABTTime finish) {return ((null == finish) ? true : finish.compareTo(start_) > 0) && ((null == start) ? true : start.compareTo(finish_) < 0);}

   final boolean compatible(ABTCalendar calendar)
   {
   	if (calendar_ == null || calendar_ == calendar) return true;

   	if (calendar == null || ! calendar_.equals(calendar, new ABTDate(start_, false), new ABTDate(finish_, true))) return false;

   	return true;
   }

   final int explode(ABTSegmentList segments, int index)
   {
	   ABTDate startDate  = new ABTDate(start_, false);
	   ABTDate finishDate = new ABTDate(finish_, true);

   	ABTTime time = start_;

   	for (ABTDate date = startDate; date.compareTo(finishDate) <= 0; date = date.next()) {
   		ABTShiftList shifts = calendar_.getShifts(date, true);

   		for (int i = 0; i < shifts.size(); i++) {
   		   ABTShift shift = shifts.getShift(i);

   			ABTTime time1 = new ABTTime(date, shift.getStart());	if (time1.compareTo(start_)  < 0) time1 = start_;
   			ABTTime time2 = new ABTTime(date, shift.getFinish());	if (time2.compareTo(finish_) > 0) time2 = finish_;

   			if (time1.compareTo(time2) >= 0) continue;

   			if (time.compareTo(time1) < 0) segments.insert(index++, new ABTSegment(time, time1, 0, null));

   			segments.insert(index++, new ABTSegment(time1, time = time2, rate_, null));
   		}
   	}

	   if (time.compareTo(finish_) < 0) segments.insert(index++, new ABTSegment(time, finish_, 0, null));

	   return index;
   }

   public boolean equals(Object object)
   {
      if (this == object) return true;

      if (object == null || ! (object instanceof ABTSegment)) return false;

      ABTSegment segment = (ABTSegment)object;

      return compareTo(segment) == 0 && rate_ == segment.rate_ && compatible(segment.calendar_);
   }

   public int compareTo(Object object)
   {
    if (object == null) return 1;
    return compareTo((ABTSegment)object);
   }

   public final int compareTo(ABTSegment segment)
   {
      int result;

      result = start_.compareTo(segment.start_);   if (result != 0) return result;
      result = finish_.compareTo(segment.finish_); if (result != 0) return result;

      return 0;   // equivalent
   }

   public String toString()
   {
	   StringBuffer buffer = new StringBuffer();

      buffer.append(start_ + "-" + finish_.toString() + "@" + rate_ + "(" + getSum() + ")");

      if (calendar_ != null) buffer.append(" " + calendar_);

      return buffer.toString();
   }
}