package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileTeam.java 08/12/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-12-98    MXA         Initial Implementation
 *
 */
import java.util.Enumeration;

import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;

//DEBUG
import java.util.Vector;
import java.util.Hashtable;
import com.abtcorp.idl.IABTLocalID;
//DEBUG

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTObjectSetIDList;


/**
 *  ABTIOPMWFileTeam is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileTeam ft = new ABTIOPMWFileTeam(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileTeam extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       teamVector_ = null;

//====================================================================================
// Constructors
//====================================================================================

/**
 *    ABTIOPMWFileTeam constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileTeam(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_        = OBJ_TEAM;
      teamVector_  = new Vector();
   }

//====================================================================================
// Populate Team from the Intermediate Hash Table
//====================================================================================


/**
 * Populate team objects from the Intermediate Hash Table to the spce
 * @param Hashtable parms,
 * @return an ABTValue the team object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue populate(Hashtable parms) throws ABTException
   {
    IABTObject         project = null;
    ABTObjectSetIDList teamIDs = null;
    IABTLocalID        teamID  = null;

    //Get the project object
    Object object = null;
    object = parms.get(OFD_PROJECT);
    if (object == OFD_PROJECT)
        project = null;
    if (object instanceof IABTObject)
        project = (IABTObject)object;

    //Get the team IDs
    object = parms.get(OFD_TEAMRESOURCES);
    if (object == OFD_TEAMRESOURCES)
        teamIDs = null;
    if (object instanceof ABTObjectSetIDList)
        teamIDs  = (ABTObjectSetIDList)object;

    if (teamIDs != null)
    {
        Enumeration itID = teamIDs.getActiveIDs();
        while( itID.hasMoreElements() )
        {
           object = null;
           object = itID.nextElement();
           if ((object instanceof IABTLocalID) || (object == null))
            teamID = (IABTLocalID)object;
           else
            throw new ABTException("Wrong Cast");

            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);
            reqparms.put(OFD_TEAMRESOURCES,teamID);
            create(reqparms);
        }
    }
    return null;
   }

/**
 * Create a new object in the object space and initialize it witha ppropriate values
 * @param Hashtable parms, associated team id in the intermediate hash table,the project object
 * @return ABTValue the newly created team
 * @exception ABTException if an unrecoverable error occurs.
 */
   protected ABTValue create(Hashtable parms) throws ABTException
   {

      IABTLocalID teamID   = null;
      IABTObject project = null;
      Object object = null;

      //Get the team ID
      object = parms.get(OFD_TEAMRESOURCES);
      if (object instanceof IABTLocalID)
         teamID  = (IABTLocalID)object;

       object = null;
       object = driver_.lookupTableGet(teamID);
       if ( (object != null )&& (object instanceof IABTObject) )
       {
            // TO DO UPDATE
           return (ABTValue)object;
       }

      else
      {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
         project = (IABTObject)object;


        // Get the array of value associated with team
        IABTArray   teamArr  = null;
        object = null;


        object = driver_.intermediateTableGet(teamID);
        if (object instanceof IABTArray)
            teamArr = (IABTArray) object;

         //Get the property set associated with the team
         IABTPropertySet propSet = null;
         propSet = getProperties(type_);

         //Get team's resource ID
         ABTValue  val = null;

         IABTLocalID resourceID = null;

          val = getHashValue(teamArr, propSet, OFD_RESOURCE);
          if ((val!= null) && (val instanceof IABTLocalID))
            resourceID = (IABTLocalID)val;
          else
            throw new ABTException("Team Create: The resource ID is not valid ");


         // Get the resource associated to Team
          Hashtable         resparms       = new Hashtable();
          ABTValue          resourceVal    = null;
          ABTIOPMWFileResource resourceHelper = new ABTIOPMWFileResource(driver_);

          resparms.put(OFD_PROJECT,project);
          resparms.put(OFD_RESOURCE,resourceID);
          resourceVal = resourceHelper.populate(resparms);

          //Check the validity of the resource associated with team
          if (ABTError.isError(resourceVal))
            throw new ABTException(((ABTError)resourceVal).getMessage());

          //Create team
          //TO DO CHECK IF TEAM EXISTED
          //
          IABTHashTable  reqparms       = (getSpace()).newABTHashTable();
          reqparms.putItemByString(OFD_PROJECT, (ABTValue)project);
          if (resourceVal instanceof IABTObject)
            reqparms.putItemByString(OFD_RESOURCE, resourceVal);
          else
            throw new ABTException("TEAM CREATE: WRONG TYPE CAST");

          val = null;
          IABTObject teamObj = null;
          val = getHashValue(teamArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            teamObj = createObject(OBJ_TEAM, (ABTRemoteID)val, reqparms);
          else if (ABTValue.isNull(val))
            teamObj = createObject(OBJ_TEAM, (ABTRemoteID)null, reqparms);
          else
                new ABTException(" WRONG TYPE CAST");

         //Set Team's scalar values.
         setScalarValues(propSet, teamArr, teamObj);

         if ( (driver_.lookupTablePut(teamID,teamObj)) != null)
    		    throw new ABTException(" The object already exists in the lookup table");
    	 return (ABTValue)teamObj;
      }

   }



//====================================================================================
// Save Team to an Intermediate Hash Table
//====================================================================================

/**
 * Saves team objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   {
        IABTObject project = null;

        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object;

        if (project == null)
            throw new ABTException("The current project is null.");

        IABTObjectSet teamOs = getObjectSet(project, OFD_TEAMRESOURCES);

        for (int i =0; i < size(teamOs); i++)
        {
            IABTObject  teamObj     = (IABTObject)at(teamOs, i);

            // Make sure the object is of type team
            if (!teamObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the team in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(teamObj);
            if (arr==null)
                throw new ABTException("The arr of team values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID teamId = teamObj.getID();
            if (teamId == null)
                throw new ABTException("team ID is null.");

            driver_.intermediateTablePut(teamId, arr);
           // if (( driver_.intermediateTablePut(teamId, arr)) != null)
           //     throw new ABTException("The team ID already exist.");

            //DEBUG
            teamVector_.addElement(teamId);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }

}