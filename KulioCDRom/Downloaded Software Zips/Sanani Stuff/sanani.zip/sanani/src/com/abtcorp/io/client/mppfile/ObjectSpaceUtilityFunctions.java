package com.abtcorp.io.client.mppfile;

import com.abtcorp.io.*;
import com.abtcorp.io.client.*;

import com.abtcorp.idl.*;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.api.local.*;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;

import java.util.Vector;
import java.util.Enumeration;

import java.lang.Character;
import java.lang.Double;

import com.abtcorp.core.*;
import com.abtcorp.core.ABTRemoteID;

import java.util.Hashtable;

import com.abtcorp.idl.IABTPMRuleConstants;

import com.abtcorp.blob.ABTCalendar;
import com.abtcorp.blob.ABTCurve;

public class ObjectSpaceUtilityFunctions implements IABTPMRuleConstants
{

   public void osSetString(String propertyName, String string, IABTObject obj)
   {
      if ( string != null && string.length() > 0 ) {
			obj.setValue(propertyName, new ABTString(string));
      }
   }

   public void osSetTime(String propertyName, ABTValue timeAbtValue, IABTObject obj)
   {
      if ( timeAbtValue != null) {
         String asString = timeAbtValue.stringValue();
         if (!asString.equals("NA"))
   			obj.setValue(propertyName, new ABTTime(timeAbtValue));
      }
   }

   public void osSetRemoteId(ABTRemoteID remoteId, IABTObject obj)
   {

		obj.setValue("ABTRemoteID", remoteId);

   }

   public void osSetInteger(String propertyName, ABTValue intAbtValue, IABTObject obj)
   {
      if ( intAbtValue != null) {

			obj.setValue(propertyName, new ABTInteger(intAbtValue));

      }
   }

   public void osSetInteger(String propertyName, int intValue, IABTObject obj)
   {
			obj.setValue(propertyName, new ABTInteger(intValue));
   }


   public void osSetPercent(String propertyName, ABTValue percentAbtValue, IABTObject obj)
   {
      if (percentAbtValue != null) {

			obj.setValue(propertyName, new ABTInteger(percentAbtValue.shortValue()/100));

      }
   }

   public void osSetDuration(String propertyName, ABTValue durationAbtValue, IABTObject obj)
   {
      if (durationAbtValue != null) {

			obj.setValue(propertyName, new ABTInteger(durationAbtValue.shortValue() / (60 * 8)));

      }
   }

   public void osSetBoolean(String propertyName, ABTValue booleanAbtValue, IABTObject obj)
   {
      if (booleanAbtValue != null) {

         if (booleanAbtValue.shortValue() != 0)
   			obj.setValue(propertyName, new ABTBoolean(true));
         else
   			obj.setValue(propertyName, new ABTBoolean(false));

      }
   }

   //opposite of boolean

   public void  osSetSummary  (String propertyName, ABTValue booleanAbtValue, IABTObject obj)
   {

      if (booleanAbtValue != null) {

         if (booleanAbtValue.shortValue() != 0)

   			obj.setValue(propertyName, new ABTBoolean(false));

         else

   			obj.setValue(propertyName, new ABTBoolean(true));

      }

   }

   public void osSetBoolean(String propertyName, boolean bl, IABTObject obj)
   {

		obj.setValue(propertyName, new ABTBoolean(bl));

   }

   public void osSetPriority(String propertyName, ABTValue priorityAbtValue, IABTObject obj)
   {
      if (priorityAbtValue != null) {
 			obj.setValue(propertyName, new ABTInteger(14 - priorityAbtValue.shortValue()));
      }
   }

   public void osSetDouble(String propertyName, ABTValue doubleAbtValue, IABTObject obj)
   {
      if (doubleAbtValue != null) {
 			obj.setValue(propertyName, new ABTDouble(doubleAbtValue));
      }
   }

   public IABTObject osGetObject(IABTObject obj, String ofd) throws ABTException
   {
      IABTObject  returnObject    = null;
      ABTValue    abtValue        = obj.getValue(ofd);

      if ( ABTError.isError(abtValue)) throw new ABTException( ((ABTError)abtValue).getMessage() );

      returnObject = (IABTObject) abtValue;

      return returnObject;
   }

   public ABTCurve osGetCurve(IABTObject obj, String ofd) throws ABTException
   {
      ABTCurve    returnObject    = null;
      ABTValue    abtValue        = obj.getValue(ofd);

      if ( ABTError.isError(abtValue)) throw new ABTException( ((ABTError)abtValue).getMessage() );

      if (abtValue instanceof ABTCurve)
         returnObject = (ABTCurve) abtValue;

      return returnObject;

   }

   public IABTObjectSet osGetObjectSet(IABTObject obj, String ofd) throws ABTException
   {
      IABTObjectSet  returnObject    = null;

      if (obj == null) return null;

      ABTValue       abtValue        = obj.getValue(ofd);

      if ( ABTError.isError(abtValue))
         throw new ABTException( ((ABTError)abtValue).getMessage() );

      returnObject = (IABTObjectSet) abtValue;

      return returnObject;
   }

   public int osGetTaskOrResourceUniqueID(IABTObject obj)  throws ABTException
   {
          //DOES NOT WORK
//      IABTLocalID iAbtLocalId = obj.getID();

//      ABTValue remoteIdAbtValue = iAbtLocalId.getRemote();

//      if ( ABTError.isError(remoteIdAbtValue))
//         throw new ABTException( ((ABTError)remoteIdAbtValue).getMessage() );

//      ABTClientMppRemoteID remoteID = (ABTClientMppRemoteID) remoteIdAbtValue;

      ABTClientMppRemoteID remoteID = null;

      ABTValue id = obj.getValue("ABTRemoteID");
      if ((id instanceof ABTClientMppRemoteID))
         remoteID = (ABTClientMppRemoteID)id;

      if (remoteID == null) {
         //create erroro  remote id is null
      } else if (remoteID instanceof ABTClientMppRemoteID)
         return remoteID.getUniqueID();

      return -1;
   }

   public ABTCalendar osGetCalendar(IABTObject obj, String ofd) throws ABTException
   {
      ABTValue calendarAbtValue  = obj.getValue(ofd);

      if ( ABTError.isError(calendarAbtValue))
         throw new ABTException( ((ABTError)calendarAbtValue).getMessage() );

      ABTCalendar calendar    = (ABTCalendar)   calendarAbtValue;

      return calendar;

    }

   public String osGetString(String ofd, IABTObject obj) throws ABTException
   {
      ABTValue stringAbtValue = obj.getValue(ofd);

      if (ABTError.isError(stringAbtValue))
         throw new ABTException(((ABTError)stringAbtValue).getMessage());

      return stringAbtValue.stringValue();

   }

   public boolean osGetBoolean(String ofd, IABTObject obj) throws ABTException
   {
      ABTValue booleanAbtValue = obj.getValue(ofd);

      if (ABTError.isError(booleanAbtValue))
         throw new ABTException(((ABTError)booleanAbtValue).getMessage());

      return booleanAbtValue.booleanValue();
   }

   public double osGetDouble(String ofd, IABTObject obj) throws ABTException
   {
      ABTValue doubleAbtValue = obj.getValue(ofd);

      if (ABTError.isError(doubleAbtValue))
         throw new ABTException(((ABTError)doubleAbtValue).getMessage());

      return doubleAbtValue.doubleValue();
   }

   public int osGetInteger(String ofd, IABTObject obj) throws ABTException
   {
      ABTValue integerAbtValue = obj.getValue(ofd);

      if (ABTError.isError(integerAbtValue))
         throw new ABTException(((ABTError)integerAbtValue).getMessage());

      return integerAbtValue.intValue();
   }

   public ABTTime osGetTime(String ofd, IABTObject obj) throws ABTException
   {

      ABTValue timeAbtValue = obj.getValue(ofd);

      if (ABTError.isError(timeAbtValue))
         throw new ABTException(((ABTError)timeAbtValue).getMessage());

      return timeAbtValue.timeValue();

   }

   boolean notBeenUpdated(IABTObject taskObject, Vector objectVector)
   {
      return objectVector.contains(taskObject);
   }

   public void addToHashTable(int uniqueId, ABTValue abtValue, Hashtable hash)
   {
      IABTObject abtObject = (IABTObject) abtValue;
      hash.put(new Integer(uniqueId), abtObject);
   }

   public ABTRemoteID getRemoteId(IABTObject object)
   {

      ABTValue idAbtValue = object.getValue("ABTRemoteID");

      if (idAbtValue != null)
         if (idAbtValue instanceof ABTRemoteID)
            return (ABTRemoteID) idAbtValue;
      return null;
   }

   public boolean isFound(ABTValue abtValue)
   {
      if (!(ABTError.isError(abtValue)))
         return true;
      return false;
   }

}
