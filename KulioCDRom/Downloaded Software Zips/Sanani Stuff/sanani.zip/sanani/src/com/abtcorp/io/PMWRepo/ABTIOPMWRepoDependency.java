package com.abtcorp.io.PMWRepo;

/*
 * ABTIOPMWRepoDependency.java 06/09/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 06-10-98    SOB            Initial Implementation
 * 06-22-98    SOB            getCursor() and closeCursor()
 * 07-14-98    SOB            Mods to support new IO Helper functionality
 * 07-21-98    SOB            Mods to support new required params on object creation
 * 07-22-98    SOB            Mods to support save() processing
 * 10-09-98    SOB            Beginnings of progress reporting
 * 10-30-98    SOB            Mods to support interproject dependencies
 * 12-14-98    SOB            #667 #683
 *
 *
 * TO DO:
 *
 * 1-  complete implementation
 * 2-
 */

/**
 *  ABTIOPMWRepoDependency is a helper class for the ABT Repository driver for the PMW application.
 *  Its purpose is to build an ABTDependency object in the object space.
 *  <pre>
 *       ABTIOPMWRepoDependency rd = new ABTIOPMWRepoDependency(ABTSession sess,
 *                                                          ABTRepository repo,
 *                                                          ABTValue selector);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		 S. Bursch
 * @see         ABTProjectPopulator
 */

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTBoolean;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.hub.ABTPropertySet;
import com.abtcorp.hub.IABTInternalProgressListener;

import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTCursor;

public class ABTIOPMWRepoDependency extends ABTIOPMWHelper
{
   private ABTRemoteIDRepository id_;
   private ABTObject projObj_ = null;
   private long projectID_ = -1;
   private Hashtable ht_;
   private ABTObjectSet dos_;
   private boolean parentLockAcquired_ = false;
   private boolean relaxSubprojectLocking_ = false;

   public ABTIOPMWRepoDependency() {/* implicit call to super() here */}

   public ABTIOPMWRepoDependency(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject projObj,
                       long projID,
                       Hashtable ht,
                       boolean parentLockAcquired,
                       boolean relaxSubprojectLocking,
                       IABTInternalProgressListener progress)
   {
      super(driver, TBL_DEPENDENCY, OBJ_DEPENDENCY, progress);
      projObj_ = projObj;
      projectID_ = projID;
      ht_ = ht;
      parentLockAcquired_ = parentLockAcquired;
      relaxSubprojectLocking_ = relaxSubprojectLocking;
   }

   /**
    *    Constructs a helper object to save dependency objects back to the repository
    *    @param space an ABTObjectSpace reference
    *    @param driver an ABTRepositoryDriver reference
    *    @param project a Project object reference
    *    @param forceAddNew true, if dependency objects must be added to the repository;
    *    false, otherwise
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTIOPMWRepoDependency(ABTObjectSpace space,
                       ABTRepositoryDriver driver,
                       ABTObject project,
                       boolean forceAddNew,
                       IABTInternalProgressListener progress) throws ABTException
   {
      super(driver, TBL_DEPENDENCY, OBJ_DEPENDENCY, progress);
      projObj_ = project;
      forceAddNew_ = forceAddNew;
      projectID_ = getValue(projObj_, OFD_ID).intValue();
   }

   /**
    *    Populates the object space with dependency objects
    *    @param parms (currently not used)
    *    @return an ABTValue indicating the status of the populate process
    *    @exception ABTException if an unrecoverable error occurs
    */
   public ABTValue populate(ABTArray parms) throws ABTException
   {
	   ABTValue object = null;             // local ABTObject

      try
      {
         //
         // Get a dependency repository cursor.
         //

         getCursor();

         //
         // For each dependency tuple in the result set, make sure one exists in the object
         // space.
         //
         while (cursor_.moveNext())
         {
            //
            // Create a remote ID for this dependency object.
            //

            id_ = new ABTRemoteIDRepository(repo_.getID(),
                                            cursor_.getFieldInt(FLD_ID));

            //
            // See if the dependency object already exists in the object space.
            //
            object = find(OBJ_DEPENDENCY, id_);

            //
            // If the object found is an ABTObject, then the dependency object was found in
            // the object space.  Update (merge) its properties with those from the repository.
            //
            // Otherwise, create a new dependency object in the object space and initialize
            // its properties from the repository.
            //

            if (object instanceof ABTObject)
            {
               ABTArray a = new ABTArray();
               a.add(object);
               object = update(a);
            }
            else
            {
               object = create(null);
            }

         }              // end while (cursor_.moveNext())
      }
      finally
      {
         closeCursor();
      }

      return dos_;
   }

   /**
    *    Creates a new dependency object
    *    @param parms (currently not used)
    *    @return an ABTValue which is the newly-created dependency object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue create(ABTArray parms) throws ABTException
   {
      ABTValue v;
      boolean ipd = false;

      Vector ps = dataDictionary_.getPropertiesFromDataModel(TBL_DEPENDENCY);

      //
      // Now get the predecessor and successor task object references.
      // These are required params for creation.
      //

      Long predTaskID = new Long(cursor_.getFieldInt(FLD_PREDTASKID));
      ABTObject predTask = (ABTObject) ht_.get(predTaskID);

      //
      // If the task was not found in the hash table, it's probably an
      // interproject dependent task, i.e., it belongs to another project.
      // Look for the task in the space.
      //

      if ( predTask == null )
      {
         v = findIPDTask(predTaskID);
         if ( ABTError.isError( v ) )
            throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                                "create",
                                                errorMessages.ERR_IPD_PREDTASK_NOT_FOUND,
                                                v));
         predTask = (ABTObject) v;
      }

      Long succTaskID = new Long(cursor_.getFieldInt(FLD_SUCCTASKID));
      ABTObject succTask = (ABTObject) ht_.get(succTaskID);

      //
      // If the task was not found in the hash table, it's probably an
      // interproject dependent task, i.e., it belongs to another project.
      // Look for the task in the space.
      //

      if ( succTask == null )
      {
         v = findIPDTask(succTaskID);
         if ( ABTError.isError( v ) )
            throw new ABTException(new ABTError(COMP_PMREPODRIVER,
                                                "create",
                                                errorMessages.ERR_IPD_SUCCTASK_NOT_FOUND,
                                                v));
         succTask = (ABTObject) v;
      }

      ABTHashtable reqparms = new ABTHashtable();
      reqparms.putItemByString(OFD_PREDTASK, predTask);
      reqparms.putItemByString(OFD_SUCCTASK, succTask);
      // flag to tell the rules to resolve IPD-subProjectLink relationships later
      reqparms.putItemByString(OFD_RESOLVEIPD, ABTBoolean.False());

      //
      // Ask the object space to create a new dependency object.  Check for errors
      // locally (here, in this method).  If an error occurred creating the
      // dependency object, skip the dependency by returning null to the caller.
      //
      v = createObject(OBJ_DEPENDENCY, id_, reqparms, false);
      if (ABTError.isError( v ))
         return null;

      //
      // Initialize repository properties of the new dependency object.
      //
      setValues(ps, (ABTObject) v);
      return v;
   }

   private ABTValue findIPDTask( Long taskID ) throws ABTException
   {
      ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo_.getID(), taskID.longValue());
      ABTValue v = find(OBJ_TASK, id);
      if ( ABTError.isError( v ) )
      {
         loadIPDProject( taskID );
         v = find(OBJ_TASK, id);
      }
      
      return v;
   }

   private void loadIPDProject( Long taskID ) throws ABTException
   {
      ABTRepository repo = driver_.getRepository();
      ABTCursor taskCursor = repo.select(TBL_TASK);
      taskCursor.andFilter(TBL_TASK + "." + FLD_ID + " = " + taskID.longValue() );
      try
      {
         if ( taskCursor.moveNext() )
         {
            long projectID = taskCursor.getFieldInt(FLD_PROJECTID);
            //
            // Now populate the project which owns one of the tasks of the interproject dependency.
            // That project will be populated without acquiring a lock, which means that the project
            // will be marked READONLY.  The code is in-place to change the lock-acquiring behavior
            // should anyone change their mind about how it's done.  Merely remove the two "false" 
            // parameters, below, and uncomment the adjacent variables.  That will cause the project
            // to be populated with the same lock status as the parent (original) project.
            //
            ABTProjectPopulator pp = new ABTProjectPopulator(driver_,
                                                             new ABTInteger((int)projectID),
                                                             PM_GETPROJECTFULL,
                                                             false /*parentLockAcquired_*/,       /* #667 #683 */
                                                             false /*relaxSubprojectLocking_*/,   /* #667 */
                                                             progress_);
            ABTValue v = pp.populate();
            if ( ABTError.isError( v ) )
               throw new ABTException( (ABTError) v );
            if ( !ABTValue.isNull( v ) )
            {
               setValue(projObj_, OFD_RESOLVEIPD, v);
            }
         }
      }
      finally
      {
         taskCursor.release();
      }

   }
   
   /**
    *    Updates an existing dependency object
    *    @param parms the dependency object to be updated
    *    @return an ABTValue which is the updated dependency object
    *    @exception ABTException if an unrecoverable error occurs
    */
   protected ABTValue update(ABTArray parms) throws ABTException
   {
      Enumeration e = parms.elements();
      ABTObject object = (ABTObject) e.nextElement();

      Vector ps = dataDictionary_.getPropertiesFromDataModel(TBL_DEPENDENCY);

      //
      // For now, just do the same as what create() does:  set the properties from the
      // repository cursor.
      //
      setValues(ps, object);

      return object;
   }

   private void setValues(Vector ps, ABTObject obj) throws ABTException
   {
   	setPropertyValues(ps, cursor_, obj);
   }

   private void getCursor()
   {
   	closeCursor();

   	//
   	// Select all the dependencies for the desired project.  The following SELECT
   	// invocation is modeled from the FIX export/import C++ PVISION code.
   	// (see PVDependencyTable object constructor in IMPDEP.CPP.)
   	//

   	cursor_ = repo_.select(QRY_PROJECTDEPENDENCIES);
   	cursor_.andFilter(TBL_PREDTASK + "." + FLD_PROJECTID + "=" + projectID_ +
   	                  " OR " +    // interproject dependencies require an "OR" here, not an "AND"
   	                  TBL_SUCCTASK + "." + FLD_PROJECTID + "=" + projectID_);

      //
      // The following andFilter() came from FIX export/import C++ PVISION code.  The
      // name of the C++ file is EXPDEP.CPP; the name of the method is export().
      //
      cursor_.andFilter(TBL_PREDTASK + "." + FLD_ISTASK + " <> 0 " +
                        " AND " + TBL_SUCCTASK + "." + FLD_ISTASK + " <> 0");
   }

   /**
    *    Saves dependency objects back to the repository
    *    @param parms (currently not used)
    *    @exception ABTException if an unrecoverable error occurs
    */
   public void save(ABTArray parms) throws ABTException
   {
      //
      // Get a dependency cursor and set the sort order to be by prID, ascending.
      //
      getCursor();
      cursor_.setSort(TBL_DEPENDENCY + "." + FLD_ID);

      //
      // Get the set of all dependencies collection objects from the project.
      //
      ABTObjectSet depSet = getObjectSet(projObj_, OFD_ALLDEPENDENCIES);

      //
      // Set some properties prior to writing back to the repository.
      //
      setSomeProperties(depSet);

      //
      // Now save the dependencies.
      //
      save(depSet);

      //
      // If there are any remaining dependency tuples in the result set, delete them now.
      // Any such tuples were added to the repository after this project was extracted.  In
      // essence, saving this project's dependencies wins.  Only its dependencies will be
      // present in the repository.
      //
      cursor_.deleteAll();

   }

   /**
    *    Checks for exceptions in writing some columns to the repository.  This method supports
    *    exception-based repository writing.  This method is entered for every PRAPI field that is
    *    a candidate for being written back to the Repository.
    *    @param   prapiName: the PRAPI column name that is about to be written to the repository
    *    @param   obj: the ABTObject which contains the data to be written to the repository
    *    @param   prapiFlags: a set of flags whose settings may modify the semantics of the column identified
    *             by prapiName, e.g., whether or not the column is a repository virtual field
    *    @param   isNew: true, if the data being written is new to the repository, i.e., the
    *             operation is an add; false, otherwise
    *    @return  true if there is an exception to the column being checked and it should NOT be written;
    *             false if the the column should be written to the repository
    *    @exception ABTException if an unrecoverable error occurs
    */
   public boolean isSaveException(String prapiName, ABTObject obj, long prapiFlags, boolean isNew) throws ABTException
   {
         boolean  ret = false;            // assume no exception

         //
         // Call the parent's isException() method.
         //
         // If we're updating an existing tuple, then modification of the predecessor and successor
         // task ID's is not allowed.
         //
         if (super.isSaveException(prapiName, obj, prapiFlags, isNew))
            ret = true;
         else if (!isNew)     // updating?
         {
            if (prapiName.equals(FLD_PREDTASKID) ||
                prapiName.equals(FLD_SUCCTASKID) )
               ret = true;
         }

         return ret;
   }

   private void setSomeProperties(ABTObjectSet oSet) throws ABTException
   {
      int size = size(oSet);

      for (int i = 0; i < size; i++)
      {
         ABTObject dep = at(oSet, i);
         ABTObject succTask = getObject(dep, OFD_SUCCTASK);
         ABTObject predTask = getObject(dep, OFD_PREDTASK);
         setValue(dep, OFD_SUCCTASKID, getValue(succTask, OFD_ID));
         setValue(dep, OFD_PREDTASKID, getValue(predTask, OFD_ID));
      }
   }
}