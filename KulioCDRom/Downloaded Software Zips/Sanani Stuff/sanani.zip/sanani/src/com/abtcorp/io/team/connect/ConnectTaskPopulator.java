package com.abtcorp.io.team.connect;

import java.util.Enumeration;

import com.abtcorp.io.server.ABTRepositoryDriver;

import com.abtcorp.io.team.TaskPopulator;
import com.abtcorp.io.team.TWRepoDriverConstants;
import com.abtcorp.io.team.ObjectIDSortedArray;
import com.abtcorp.io.team.TWObjectComparator;
import com.abtcorp.io.team.TWPopulator;

import com.abtcorp.objectModel.team.IABTTWRuleConstants;

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTProperty;
import com.abtcorp.idl.IABTPropertyType;

import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTNames;

public class ConnectTaskPopulator extends TaskPopulator implements IABTTWRuleConstants, ABTNames, TWRepoDriverConstants, IABTPropertyType
{
	private ObjectIDSortedArray assignments_;
	private ABTCursor entryAssignCursor_;
	private String server_;
	
   public ConnectTaskPopulator() {}
	

   public ConnectTaskPopulator(ABTRepositoryDriver driver, ABTObject project, ABTObjectSpace space, ABTUserSession session, String server)
   {
      super();
      setDriver(driver,space,session);
   	server_ = server;
   	assignments_ = new ObjectIDSortedArray(new TWObjectComparator(session));

   	// Now get assignments for all time entries we will be getting.
      entryAssignCursor_ = getEntryAssignmentCursor();
   	entryAssignCursor_.moveFirst();

      project_ = project;
      notePopulator_ = new ConnectNotePopulator(getDriver(),OBJ_TW_TASK, getSpace(), getSession());
      assignmentPopulator_ = new ConnectAssignmentPopulator(getDriver(), getSpace(), getSession());
   }
	
	public void setServerName(String server) {server_ = server;}

	protected void addAssignments(ABTObject task)
   {
      if (assignmentCursor_ != null) {      	      	
      	
         while (assignmentCursor_.isValid() && (assignmentCursor_.getField(FLD_WBSSEQUENCE).intValue() <= task.getValue(getSession(), FLD_TW_SEQUENCE).intValue())) {

            if (task.getValue(getSession(), FLD_TW_ID).intValue() == assignmentCursor_.getField(FLD_TASKID).intValue()) {
               ABTObject assign = assignmentPopulator_.addObject(task, assignmentCursor_);
            	assignments_.add(assign);
            }
            assignmentCursor_.moveNext();
         }
      	      	
      	while (entryAssignCursor_.isValid() && (entryAssignCursor_.getField(FLD_WBSSEQUENCE).intValue() <= task.getValue(getSession(), FLD_TW_SEQUENCE).intValue())) {
      		int id = entryAssignCursor_.getFieldInt(FLD_ID);
      		int idx = assignments_.indexOf(new Integer(id));
      		
      		if (idx >= 0) continue; // Already found this assignment
      		ABTObject assign = assignmentPopulator_.addObject(task, entryAssignCursor_);
      		assignments_.add(assign);
      		entryAssignCursor_.moveNext();
      	}
      }
      return;
   }
	
	protected ABTCursor getEntryAssignmentCursor()
   {
   	String[] servers = new String[1];
   	servers[0] = server_;
   	String query = TWPopulator.substitute(servers,SERVER_ASSIGNMENTENTRY_QUERY);
   	return getDriver().getRepository().select(query);
   }
}