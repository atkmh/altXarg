/*
 * Copyright (c) 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.abtcorp.api.com;

import com.abtcorp.core.*;
import com.abtcorp.idl.*;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;

public class ABTPropertyCOM implements IABTPropertyCOM
{
   public ABTPropertyCOM()  { this(null); }
   public ABTPropertyCOM(IABTProperty p) {
      /**/
      //*******************************
      //create aggregated "base" classes
      //*********************************
      _base = new ABTBaseJavaCOM(p);
      /**/
      }

   // aggregated ABTBaseJavaCOM access wrapper   
   /**/
   protected ABTBaseJavaCOM _base; // aggregated base object
   public void setObject(Object obj) { _base.setObject(obj); }
   public Object getObject()   { return _base.getObject(); }
   public String toString()    { return _base.toString();};
   public String ToString()    { return _base.ToString();};
   public int  getHashCode()   { return _base.hashCode(); }
   public boolean EqualTo(Object Parameter0) { return _base.EqualTo(Parameter0); }
   public Object getClassInfo(){ return _base.getClassInfo(); }
   public boolean isABTEmpty() { return _base.isABTEmpty(); }
   public boolean isABTError() { return _base.isABTError(); }
   /**/
   private IABTProperty _prop;
   private IABTProperty prop() {
      if (_prop == null) _prop = (IABTProperty)getObject();
      return _prop;
      }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isUpdatable()
      { return prop().isUpdatable();  }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isVisible()
      { return prop().isVisible();  }


   /**
   * return whether this property is transient
   * @return boolean true for transient properties
   */
   public boolean isTransient()
      { return prop().isTransient();  }

   /**
   * return whether this property is virtual
   * @return boolean true for virtual properties
   */
   public boolean isVirtual()
      { return prop().isVirtual();  }

   /**
   * return the name of this property
   * @return String name
   */
   public String getName() 
      {  return prop().getName();  }

   /**
   * return the caption of this property
   * @return String caption
   */
   public String getCaption() 
      { return prop().getCaption(); }
   
   /**
   *  return the type of this property
   * @return int type
   */
   public int getType()
      { return prop().getType(); }

   /**
   *  get the default value for this field
   * @return Variant
   */
   public Variant getDefaultValue()
      { return VariantMunger.ValueToVariant(prop().getDefaultValue()); }

   public IABTHashTableCOM getExtendedProperties() { 
      IABTHashTable epl = prop().getExtendedProperties();
      if (epl == null) return null;
      return new ABTHashTableCOM(epl); }


   public String getRuleName(){
      return prop().getRuleName();
      }

   public String  getFieldRuleName(){
      return prop().getFieldRuleName();
      }

   public String  getReferenceType(){
      return prop().getReferenceType();
      }

   public int getIndex() {
      return prop().getIndex() ;
      }

   public void setPropertyKeyByKey(Variant key,Variant value){
      prop().setPropertyKeyByKey(VariantMunger.VariantToValue(key),VariantMunger.VariantToValue(value));
      }
   public void setPropertyKeyByInt(int key,Variant value){
      prop().setPropertyKeyByInt(key,VariantMunger.VariantToValue(value));
      }
   public void setPropertyKeyByString(String key,Variant value){
      prop().setPropertyKeyByString(key,VariantMunger.VariantToValue(value));
      }

   public Variant getPropertyKeyByKey(Variant key){
      return VariantMunger.ValueToVariant(
         prop().getPropertyKeyByKey(VariantMunger.VariantToValue(key)));

      }
   public Variant getPropertyKeyByInt(int key){
      return VariantMunger.ValueToVariant(prop().getPropertyKeyByInt(key));
      }
   public Variant getPropertyKeyByString(String key){
      return VariantMunger.ValueToVariant(prop().getPropertyKeyByString(key));
      }

}
