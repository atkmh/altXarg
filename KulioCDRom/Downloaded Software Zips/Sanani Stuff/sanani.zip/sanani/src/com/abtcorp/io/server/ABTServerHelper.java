package com.abtcorp.io.server;
/*
 * ABTIOHelper.java 06/04/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 06-04-98    SOB             Initial Implementation
  * 06-22-98    SOB             get/setSpace(); get/setDriver()
  * 06-26-98    SOB             more helper methods
  * 07-09-98    SOB             basic transaction support
  * 07-14-98    SOB             integrate Methodology IO helper methods
  * 08-03-98    SOB             changed to com.abtcorp.io.server package
  * 08-05-98    SOB             mods such that this class does not extend ABTIOHelper in the io package
  * 08-06-98    LZX             changed checkError() to throw an ABTException with the ABTError object.
  * 09-29-98    SOB             new createObject() methods to support optional checking of errors
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTString;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.hub.ABTObjectSet;

/**
 *  ABTServerHelper is the base abstract class for all driver helper classes.  Helper
 *  classes are those which assist the drivers in accessing persistent storage and the object
 *  space.
 *
 *			This class is not meant to be instantiated directly, but to be extended by various
 *       classes that a driver will instantiate to assist it in populating the object space.
 *
 *  <pre>
 *       public class ABTIOPMWRepoProject extends ABTServerHelper
 *       {
 *        ... override find(), create(), update(), etc., methods for PMW-specific requirements ...
 *       }
 *
 *  </pre>
 *
 * @version	$Revision: 12$
 * @author  S. Bursch
 * @see     ABTServerDriver
 */

public abstract class ABTServerHelper
{
/**
 *    space_ is a reference to the object space being used by this helper.
 */
   protected  ABTObjectSpace space_;
/**
 *    userSession_ is a reference to the current user session being used by this helper.
 */
   protected ABTUserSession userSession_;
/**
 *		Creates an ABTIOHelper that is not associated with an ABTObjectSpace or ABTDriver.
 *    Associating an object space with this class will be deferred until later.
 */

   public   ABTServerHelper() { /* implicit call to super() here */ }

/**
 *		Creates an ABTIOHelper that is associated with an ABTObjectSpace.
 *
 */

   public   ABTServerHelper(ABTObjectSpace space, ABTUserSession session)
   {
    super();
    space_ = space;
    userSession_ = session;
   }

/**
 *    Populates an object space with an object (or objects) as appropriate to the
 *    particular helper
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs
 */
   public abstract   ABTValue populate(ABTArray parms) throws ABTException;

/**
 *    Populates an object space with an object (or objects) as appropriate to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs
 */
   protected abstract   ABTValue populate() throws ABTException;

/**
 *    Saves an object (or objects) from the object space to persistent storage as appropriate to the
 *    particular helper.
 *	   @param ABTArray parms, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return void
 *		@exception ABTException if an unrecoverable error occurs
 */
   public abstract   void save(ABTArray parms) throws ABTException;

/**
 *		Sets the object space reference.
 *    @param space a reference to the object space
 *
 */
   public   void setSpace(ABTObjectSpace space) {space_ = space;}

/**
 *		Gets the object space reference.
 *
 *
 */
   public   ABTObjectSpace getSpace() {return space_;}

/**
 *		Sets the user session reference
 *    @param session a reference to the user session
 *
 */
   public   void setUserSession(ABTUserSession session) {userSession_ = session;}

/**
 *		Gets the current session handle.
 *
 *
 */
   public   ABTUserSession getUserSession() {return userSession_;}

/**
 *		Checks for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value ABTValue returned from the invocation of an object space
 *             or ABTObject method
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void checkError( ABTValue value ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException((ABTError)value);
   }

/**
 *		Checks for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value ABTValue returned from the invocation of an object space
 *             or ABTObject method.
 *    @param propname property name being get/set
 *    @param settingvalue value being get/set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void checkError( ABTValue value, String propname, ABTValue settingvalue ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage() + " (" + propname + ", " + settingvalue + ")");
   }

/**
 *		Checks for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value ABTValue returned from the invocation of an object space
 *             or ABTObject method.
 *    @param propindex property index of the property being get/set
 *    @param settingvalue value being get/set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void checkError( ABTValue value, int propindex, ABTValue settingvalue ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage() + " (" + propindex + ", " + settingvalue + ")");
   }

/**
 *		Sets a property value into an ABTObject.
 *    @param object ABTObject whose property is being set
 *    @param propname property name being set
 *    @param value value being set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void setValue( ABTObject object, String propname, ABTValue value ) throws ABTException
   {
      ABTValue err = object.setValue( userSession_, propname, value );
      checkError( err );
   }

/**
 *		Sets a property value into an ABTObject.
 *    @param object ABTObject whose property is being set
 *    @param propindex property index of the property being set
 *    @param value value being set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void setValue( ABTObject object, int propindex, ABTValue value ) throws ABTException
   {
      ABTValue err = object.setValue( userSession_, propindex, value );
      checkError( err );
   }

/**
 *		Gets a property value from an ABTObject.
 *    @param object ABTObject whose property is being gotten
 *    @param propname property name whose value is being gotten
 *    @return an ABTValue which is the property's value
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTValue getValue( ABTObject object, String propname ) throws ABTException
   {
      ABTValue err = object.getValue( userSession_, propname );
      checkError( err );
      return err;
   }

/**
 *		Gets a property value from an ABTObject.
 *    @param object ABTObject whose property is being gotten
 *    @param propindex property index of the property whose value is being gotten
 *    @return ABTValue which is the property's value
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTValue getValue( ABTObject object, int propindex ) throws ABTException
   {
      ABTValue err = object.getValue( userSession_, propindex );
      checkError( err );
      return err;
   }

/**
 *		Adds an existing ABTObject to an object set.
 *    @param set object set to which an ABTObject will be added
 *    @param object ABTObject which will be added to the indicated object set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void addListMember( ABTObjectSet set, ABTObject object ) throws ABTException
   {
      ABTValue err = set.add( userSession_, object );
      checkError( err );
   }

/**
 *		Adds a new ABTObject to an object set.  The ABTObject is created first, and
 *    then added to the object set.  The type of the ABTObject to be created will
 *    be the same type as that of the object set.  The ABTObject is created without
 *    an ABTRemoteID, so if the object needs an ABTRemoteID, it will need to be added
 *    later.
 *    @param set object set to which an ABTObject will be added after that ABTObject
 *    has been created
 *    @return ABTObject which was created and then added to the object set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTObject addNew( ABTObjectSet set ) throws ABTException
   {
      ABTValue err = set.addNew(userSession_);
      checkError( err );
      return (ABTObject)err;
   }

/**
 *		Removes an existing ABTObject from an object set.  The ABTObject is not deleted.
 *    @param set object set from which an ABTObject will be removed
 *    @param object ABTObject to be removed from the object set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void removeListMember( ABTObjectSet set, ABTObject object ) throws ABTException
   {
      ABTValue err = set.remove( userSession_, object );
      checkError( err );
   }

/**
 *		Creates a new ABTObject.  The new ABTObject will be created without an
 *    ABTRemoteID.
 *    @param type type of ABTObject which will be created
 *    @param params ABTHashtable of parameters which may be used by rules processing during
 *    processing in the creation of the object and in the placement of the object
 *    into an object model hierarchy.
 *    @return ABTObject which was newly created
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTObject createObject( String type, ABTHashtable params ) throws ABTException
   {
      return createObject( type, (ABTRemoteID) null, params );
   }

/**
 *		Creates a new ABTObject.
 *    @param type type of ABTObject which will be created
 *    @param id ABTRemoteID to be assigned to the new object
 *    @param params ABTHashtable of parameters which may be used by rules
 *    processing in the creation of the object and in the placement of the object
 *    into an object model hierarchy.
 *    @return the ABTObject which was newly created
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTObject createObject( String type, ABTRemoteID id, ABTHashtable params ) throws ABTException
   {
      ABTValue v = space_.createObject( userSession_, type, id, params );
      checkError( v );
      return (ABTObject)v;
   }

/**
 *		Creates a new ABTObject.  The new ABTObject will be created without an
 *    ABTRemoteID.
 *    @param type type of ABTObject which will be created
 *    @param params ABTHashtable of parameters which may be used by rules processing during
 *    processing in the creation of the object and in the placement of the object
 *    into an object model hierarchy.
 *    @param checkForError boolean flag indicating whether or not to check for
 *          errors after creation of the object
 *    @return ABTObject which was newly created
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTValue createObject( String type, ABTHashtable params, boolean checkForError ) throws ABTException
   {
      return (checkForError ? createObject( type, (ABTRemoteID) null, params ) :
                              space_.createObject( userSession_, type, (ABTRemoteID) null, params) );
   }

/**
 *		Creates a new ABTObject.
 *    @param type type of ABTObject which will be created
 *    @param id ABTRemoteID to be assigned to the new object
 *    @param params ABTHashtable of parameters which may be used by rules
 *    processing in the creation of the object and in the placement of the object
 *    into an object model hierarchy.
 *    @param checkForError boolean flag indicating whether or not to check for
 *          errors after creation of the object
 *    @return the ABTObject which was newly created
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTValue createObject( String type, ABTRemoteID id, ABTHashtable params, boolean checkForError ) throws ABTException
   {
      return (checkForError ? createObject(type, id, params) :
                              space_.createObject( userSession_, type, id, params ) );
   }

/**
 *		Gets an object set from an ABTObject.
 *    @param object ABTObject from which the object set will be gotten
 *    @param objectSetName property name of the object set to be gotten from the object
 *    @return the requested ABTObjectSet
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTObjectSet getObjectSet( ABTObject object, String objectSetName )
      throws ABTException
   {
      ABTValue err = object.getValue( userSession_, objectSetName );
      checkError( err );
      return (ABTObjectSet)err;
   }

/**
 *		Gets an ABTObject from another ABTObject.
 *    @param object ABTObject from which the object will be gotten
 *    @param objectName property name of the object to be gotten
 *    @return the requested ABTObject
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public ABTObject getObject( ABTObject object, String objectName )
      throws ABTException
   {
      ABTValue err = object.getValue( userSession_, objectName );
      checkError( err );
      return (ABTObject)err;
   }

/**
 * Adds an object to an object set.  The semantics of this method are similar to addListMember().
 *	@param oSet object set to which the object will be added
 *	@param object object to be added to the object set
 *	@return the object added
 *	@exception ABTException if an unrecoverable error occurs
 */
   public ABTValue add(ABTObjectSet oSet, ABTObject object) throws ABTException
   {
      ABTValue val = oSet.add(userSession_, object);
      checkError( val );
      return val;
   }

/**
 * deletes an object from the object space.  
 *	@param object object to be added to the object set
 *	@return null if successful or ABTError
 *	@exception ABTException if an unrecoverable error occurs
 */
   public ABTValue delete(ABTObject object) throws ABTException
   {
      ABTValue val = object.delete(userSession_);
      checkError( val );
      return val;
   }

/**
 * Retrieves an object in the specified position within an object set.
 *	@param oSet object set that contains the object
 *	@param index position of the object to be retrieved
 *	@return ABTObject at position index within object set oSet
 *	@exception ABTException if an unrecoverable error occurs
 */
   public ABTObject at(ABTObjectSet oSet, int index) throws ABTException
   {
      return((ABTObject) oSet.at(userSession_, index));
   }

/**
 * Returns the size of an object set.
 *	@param oSet the object set
 *	@return the size of the object set
 *	@exception ABTException if an unrecoverable error occurs
 */
   public int size(ABTObjectSet oSet) throws ABTException
   {
      return(oSet.size(userSession_));
   }

/**
 * Checks if an object is contained in an object set.
 * @param oSet the object set to be searched
 * @param obj the object which may or may not be contained in oSet
 * @return true if the object is contained in oSet; false, otherwise
 * @exception ABTException if an unrecoverable error occurs
 */
   public boolean contains(ABTObjectSet oSet, ABTObject obj) throws ABTException
   {
      return oSet.contains(userSession_, obj);
   }

/**
 * Gets the remote ID of an object.
 * @param oSet the object set to be searched
 * @param obj the object which may or may not be contained in oSet
 * @return ABTValue remote ID; the caller can cast this ABTValue to the correct remote ID instance
 * @exception ABTException if an unrecoverable error occurs
 */
   public ABTValue getRemoteID(ABTObject obj) throws ABTException
   {
      ABTValue rmtID = obj.getID().getRemote(userSession_);
      checkError( rmtID );
      return rmtID;
   }

// ------------------------------------------------------------------------------
// The following methods have "protected" member visibility.
// ------------------------------------------------------------------------------

/**
 * Creates an object set in the object space.
 *	@param type type of the object set
 *	@return ABTValue of the object set created
 *	@exception ABTException if an unrecoverable error occurs
 */
   protected ABTObjectSet createObjectSet(String type) throws ABTException
   {
		ABTValue val = space_.createObjectSet(userSession_, type);
      checkError( val );
      return (ABTObjectSet) val;
   }

/**
 * Finds an object of type type and remote ID id in the object space.
 * @param type type of object to search for, e.g., "ABTProject", "ABTMethod"
 * @param id remote ID of the object to search for
 * @return an ABTValue which, if the search is successful, will be a reference to the
 *          the desired object.  Otherwise, an ABTError.
 */

   protected   ABTValue find(String type, ABTRemoteID id)
   {
      return space_.findObject(userSession_,type, id);
   }

/**
 * Finds objects of type type and criteria criteria in the object space.
 * @param type type of object to search for, e.g., "ABTProject", "ABTMethod"
 * @param criteria: search expression
 * @return an ABTValue which, if the search is successful, will be a reference to an
 *          object set which contains the desired object(s).  Otherwise, an ABTError.
 */

   protected   ABTValue find(String type, String criteria)
   {
      return space_.findObject(userSession_,type, criteria);
   }

/**
 * Finds objects of type type, property name propname, and criteria criteria in the object space.
 * @param type type of object to search for, e.g., "ABTProject", "ABTMethod"
 * @param propname property name of property against which objects will compared
 * @param criteria string search criteria, e.g., the contents of an external ID field, or of a name field
 * @return an ABTValue which, if the search is successful, will be a reference to an
 *          object set which contains the desired object(s).  Otherwise, an ABTError.
 */

   protected   ABTValue find(String type, String propname, String criteria)
   {
      String s = propname + " = " + ABTString.normalizeQuotes(criteria);
      return find(type, s);
   }

/**
 * Creates a new object in the object space and initialize it with values appropriate to the
 * driver being used.
 *	@param parms  the elements of which are meaningful as parameters to the particular
 * helper
 *	@return ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs
 */

   protected abstract ABTValue create(ABTArray parms) throws ABTException;

/**
 *    Updates an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param parms the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object updated in the
 *    object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs
 */

   protected abstract ABTValue update(ABTArray parms) throws ABTException;

}
