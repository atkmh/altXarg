package com.abtcorp.io.client.pmwfile;

/*
 * ABTIOPMWFileCustomFieldValue.java 08/13/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author      Description
 * 08-13-98    MXA         Initial Implementation
 *
 */
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTArray;
import com.abtcorp.idl.IABTPropertySet;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTHashTable;

import  com.abtcorp.api.local.ABTHashTable;

import java.util.Hashtable;
//DEBUG
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.idl.IABTLocalID;
//DEBUG
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTRemoteID;


import com.abtcorp.io.client.ABTFileHelper;
import com.abtcorp.io.client.ABTObjectSetIDList;

/**
 *  ABTIOPMWFileCustomFieldValue is a helper class for the ABT File driver for the PMW application.
 *  It is instantiated by the ABTIOPMWFileDriver.
 *
 *  <pre>
 *       ABTIOPMWFileCustomFieldValue fc = new ABTIOPMWFileCustomFieldValue(driver);
 *
 *  </pre>
 *
 * @version	1.0
 * @author		M. Abadian
 * @see         ABTIOPMWFileDriver
 */

public class ABTIOPMWFileCustomFieldValue extends ABTIOPMWFileHelper implements IABTPMRuleConstants, IABTIOPMWFileConstants
{
    //DEBUG
     static  Vector       prjCustFieldsVector_  = null;
     static  Vector       taskCustFieldsVector_ = null;
     
//====================================================================================
// Constructors
//====================================================================================
                    
/**
 *    ABTIOPMWFileCustomFieldValue constructor.
 *    @param   driver: the reference to the driver.
*/
   ABTIOPMWFileCustomFieldValue(ABTIOPMWFileDriver driver)
   {
      super(driver);
      type_        = OBJ_CUSTFIELDVALUE;
      prjCustFieldsVector_   = new Vector();
      taskCustFieldsVector_  = new Vector();
   }

//====================================================================================
// Populate  CustomFieldValue from the Intermediate Hash Table
//====================================================================================

/**
 * Populate  CustomFieldValue  object from the Intermediate Hash Table to the sapce
 * @param Hashtable parms,
 * @return an ABTValue the CustomFieldValue object which was populated
 * @exception ABTException if an unrecoverable error occurs.
 */
 
   public ABTValue populate(Hashtable parms) throws ABTException 
   {
    ABTObjectSetIDList custfieldIDs   = null;    
    IABTObject         project   = null;
    IABTObject         targetObj = null;
    Object             object    = null;
     
    try
     {
        //Get the project object
        object = null;
        object = parms.get(OFD_PROJECT);
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
            
        //Get the Target object which this custom fiels value belongs to   
        object = parms.get(TARGET_OBJ);
        if (object instanceof IABTObject) 
            targetObj  = (IABTObject)object;
                     
        //Get the custom fiels value IDs 
        object = parms.get(CUSTOMFIELD_ID);
        if (object instanceof ABTObjectSetIDList) 
            custfieldIDs  = (ABTObjectSetIDList)object;
            
        Enumeration itID = custfieldIDs.getActiveIDs();    
        while( itID.hasMoreElements() )
        {
            Hashtable reqparms = new Hashtable();
            reqparms.put(OFD_PROJECT,project);
            reqparms.put(TARGET_OBJ, targetObj);
            reqparms.put(CUSTOMFIELD_ID,(IABTLocalID)itID.nextElement());
            
            create(reqparms);
        }
     }
     catch(Exception e)
     {
        throw new ABTException(e.getMessage());
     }
     finally
     {
        return (ABTValue)null;
     }      
    
   }

   
/**
 * Create a new object in the object space and initialize it with  appropriate values 
 * @param Hashtable parms 
 * @return ABTValue the newly created custom field value
 * @exception ABTException if an unrecoverable error occurs.
 */

   public ABTValue create(Hashtable parms) throws ABTException
   {   
      IABTLocalID custfieldID    = null;      
      IABTObject project         = null;
      IABTObject targetObj       = null;
      Object     object          = null;
      IABTObject custfieldObj    = null;
     
      //Get the custom field value ID 
      object = null;
      object = parms.get(CUSTOMFIELD_ID);
      if (object instanceof IABTLocalID) 
         custfieldID  = (IABTLocalID)object;
            
      //Check if custom field value has already been created
        object = null;
        object = driver_.lookupTableGet(custfieldID);
        if ( object!= null && object instanceof IABTObject)
        {
         // TO DO UPDATE
           ;
        }
        else
        {
          //Get the project object
          object = null;
          object = parms.get(OFD_PROJECT);
          if (object instanceof IABTObject)
            project = (IABTObject)object; 
          
          //Get the Target object which this custom field belongs to 
          object = null;
          object = parms.get(TARGET_OBJ);
          if (object instanceof IABTObject) 
             targetObj  = (IABTObject)object;
                       
          // Get the array of value associated with custom field value
          IABTArray   custfieldArr  = null;
          object = null;
          
          object = driver_.intermediateTableGet(custfieldID);
          if (object instanceof IABTArray)
            custfieldArr = (IABTArray) object;
          
          //Get the property set associated with the custom field value
          IABTPropertySet propSet = null;
          propSet = getProperties(type_); 
          
         
          //Get custom field values Remote ID
          ABTValue  val = null;      
                    
          val = getHashValue(custfieldArr, propSet, PROP_REMOTEID);
          if (val instanceof ABTRemoteID)
            custfieldObj = createObject(type_,(ABTRemoteID)val, null);    
          else if (ABTValue.isNull(val)) 
            custfieldObj = createObject(type_,(ABTRemoteID)null, null);  
          else
            new ABTException(" WRONG TYPE CAST");

          //Set custom field value's scalar values.  
          setScalarValues(propSet, custfieldArr, custfieldObj);
          
          //Add the custom field value to Target Object's custom field value List
          IABTObjectSet oSet;
          if (targetObj == null) 
            throw new ABTException (" The custom field value's Target Object is null.");
          else
          {
            oSet = getObjectSet(targetObj, OFD_CUSTFIELDVALUES);
            addListMember(oSet, custfieldObj);
          }

        }
           
    driver_.lookupTablePut(custfieldID, custfieldObj);   
    
    return (ABTValue)custfieldObj;
   }

//====================================================================================
// Save Custom Field Value to an Intermediate Hash Table
//====================================================================================   
/**
 * Saves project and task Custom Fields objects from the object space back to the Intermediate Hash Table
 * @param Hashtable parms,
 * @return void
 * @exception ABTException if an unrecoverable error occurs.
 */
 public void save(Hashtable parms) throws ABTException
 {
   try
   { 
        IABTObject project = null;
        //Get the project object
        Object object = null;
        object = parms.get(OFD_PROJECT);
        if (object == OFD_PROJECT)
            project = null;
        if (object instanceof IABTObject)
            project = (IABTObject)object; 
    
        if (project == null)
            throw new ABTException("The current project is null.");
        saveProjectCustomFields(project);
        saveTaskCustomFields(project);
        
   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
 }


private void saveProjectCustomFields(IABTObject project)
{
    try
    {
        IABTObjectSet prjCustFieldsOs = getObjectSet(project, OFD_CUSTFIELDVALUES);
        if ( size(prjCustFieldsOs) == 0)
            return;
        for (int i =0; i < size(prjCustFieldsOs); i++)
        {
            IABTObject  prjCustFieldsObj     = (IABTObject)at(prjCustFieldsOs, i);

            // Make sure the object is of type prjCustFields
            if (!prjCustFieldsObj.getObjectType().equals(type_))
                processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

            // Load the values of the properties associated with the prjCustFields in an array
            IABTArray arr = null;
            arr = loadObjectPropertyValues(prjCustFieldsObj);
             if (arr==null)
                throw new ABTException("The arr of prjCustFields values is null.");

            //Get the Intermediate Hash Table
            if (driver_.isIntermediateTableNull())
                throw new ABTException("The Intermediate Hash Table is null.");

            IABTLocalID prjCustFieldsId = prjCustFieldsObj.getID();
            if (prjCustFieldsId == null)
                throw new ABTException("prjCustFields ID is null.");
          
            if (( driver_.intermediateTablePut(prjCustFieldsId, arr)) != null)
                throw new ABTException("The prjCustFields ID already exist.");

            //DEBUG
            prjCustFieldsVector_.addElement(prjCustFieldsId);
        }

   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
}


private void saveTaskCustomFields(IABTObject project)
{
   try
   {
        if (project == null)
            throw new ABTException("The current project is null.");
            
        IABTObjectSet taskOs = getObjectSet(project, OFD_ALLTASKS);
        if ( size(taskOs) == 0 )
            return;
        for (int i =0; i < size(taskOs); i++)
        {
            IABTObject     taskObj          = (IABTObject)at(taskOs, i);
            IABTObjectSet  taskCustFieldsOs = (IABTObjectSet)getObjectSet(taskObj, OFD_CUSTFIELDVALUES);
            for (int j =0; j < size(taskCustFieldsOs); j++)
            {
                IABTObject  taskCustFieldsObj = (IABTObject)at(taskCustFieldsOs, j);                
               // if (taskCustFieldsObj == (IABTObject) null)
               //     continue;
                // Make sure the object is of type resource
                if (!taskCustFieldsObj.getObjectType().equals(type_))
                    processError(SEVERITY_ONE, type_, "", EXC_INVALID_OBJ_TYPE);

                // Load the values of the properties associated with the Task Custom Fields in an array
                IABTArray arr = null;
                arr = loadObjectPropertyValues(taskCustFieldsObj);
                if (arr==null)
                    throw new ABTException("The arr of Task Custom Fields values is null.");

                //Get the Intermediate Hash Table
                if (driver_.isIntermediateTableNull())
                    throw new ABTException("The Intermediate Hash Table is null.");

                IABTLocalID TaskCustFieldsId = taskCustFieldsObj.getID();
                if (TaskCustFieldsId == null)
                    throw new ABTException("Task Custom Fields ID is null.");
               
                if (( driver_.intermediateTablePut(TaskCustFieldsId, arr)) != null)
                    throw new ABTException("The Task Custom Fields ID already exist.");

                //DEBUG
                taskCustFieldsVector_.addElement(TaskCustFieldsId);
            }
        }
     
   }  catch (ABTException e)
   {
         e.printStackTrace();
   }
   finally
   {
   }
}

}