package com.abtcorp.io.team.connect.data.FileEditor;

import com.abtcorp.io.team.*;
import com.abtcorp.io.team.connect.data.*;
import com.abtcorp.core.*;

import java.io.*;
import java.util.Hashtable;
import java.util.Vector;

public class FVArray extends ABTArray implements Expandable{

    FVArray(){
        super();  
    }
    
    FVArray(ABTArray array){
        super(array);   
    }
    
    public String toString(){ return (new String("ABTArray{}")); }

    public Hashtable expand(){
        Hashtable data = new Hashtable();
        Vector indexColumn = new Vector(this.size());
        Vector dataColumn = new Vector(this.size());
    	
        for(int i = 0; i < this.size();i++)
        {
            Object value = this.at(i);
            indexColumn.addElement(Integer.toString(i));
            
            if(value instanceof ABTArray)
                dataColumn.addElement(new FVArray((ABTArray)value));
            else if(value instanceof DataSet)
                dataColumn.addElement(new FVDataSet((DataSet)value));
            else if(value instanceof Hashtable)
                dataColumn.addElement(new FVHashtable((Hashtable)value));    
            else 
                dataColumn.addElement(value);
        }
        if(this.size() > 0){
            data.put("Key", indexColumn);
        	   data.put("Data", dataColumn);
    	   }
    	   return data;
    }
}