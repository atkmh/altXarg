
package com.abtcorp.hub;

/*
 * ABTRowSet.java 12/15/97
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTSortedArray;
import com.abtcorp.core.ABTRemoteID;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTString;

import java.util.Enumeration;

/**
 * Rowset is managed by the ObjectSpace
 * RowSet carries the physical data for the Business Objects and a reference
 * to the maximum avaliable properties
 * <p>
 * @see com.abtcorp.core.ABTArray
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 */
public class ABTRowSet implements IABTTransactionInstance
{
   private final ABTRule my_Rule;

   private ABTTransactionContainer  data;

   private ABTArray indices;

   public ABTUserSession getLockHolder()
   {
        return data.getLockHolder();
   }



   public synchronized boolean lock(ABTUserSession requestor)
   {
         return data.lock(requestor);
   }

   public synchronized void removeOnelock(ABTUserSession requestor)
   {
    data.removeOnelock(requestor);
   }

    private ABTRowSetDelta getActive(ABTUserSession session,boolean create)
    {
      return (ABTRowSetDelta)data.getActive(session,create);
    }

   public synchronized boolean unLock(ABTUserSession requestor)
   {
    return data.unLock(requestor);
   }

   public void rollback(ABTUserSession session)
   {
    data.rollback(session);
   }

   protected void commitAll(ABTUserSession session,boolean recall)
   {
    data.commitAll(session,recall);

   }
   public void commit(ABTUserSession session)
   {
    data.commit(session);
   }


   /**
   *  default constructor
    * creates the internal row-management structure
    * @param rule_ associated ruleset
    */
   public ABTRowSet(ABTRule rule_)
   {
      my_Rule = rule_;
      indices = my_Rule.getIndices();
      data = new ABTTransactionContainer(this,ABTTransactionContainer.MULTIPLE,new ABTRowSetDelta(indices));
   }

   /**
   * return number of non-virtual properties
   * @return number of Properties
   */

   public int numberOfProperties()
   {
      return my_Rule.countNonVirtualProperties();
   }

   /**
   * return my rule
   */

   protected ABTRule getRule()
   {
      return my_Rule;
   }

   /**
   *  return the available properties for this RowSet
   *  @return ABTProperty of this RowSet
    */
   public final ABTPropertySet getProperties()
      {
         return my_Rule.getProperties();;
      }

   /**
   *  return a particular property
   *  @param session - user session/security manager
   *  @param index int index in property-list
   *  @return ABTProperty or null
   */
   protected final ABTProperty getProperty(ABTUserSession session,int index)
   {
         return my_Rule.getProperty(session,index);
   }

   /**
   *  return a particular property
   *  @param index int index in property-list
   *  @return ABTProperty or null
   */
   protected ABTProperty getProperty(ABTUserSession session, String name)
   {
         return my_Rule.getProperty(session,name);
   }
   /**
   *  return a particular property
   *  @param index int index in property-list
   *  @return ABTProperty or null
   */
   protected ABTProperty getProperty(ABTUserSession session, ABTString name)
   {
         return my_Rule.getProperty(session,name.stringValue());
   }

   /**
   *  return a row with a given id
   *  @param id ABTID of row
   *  @return ABTRow if successfull or null if not found
   */
   public final ABTRow get(ABTUserSession session, int key, ABTValue id)
   {
      ABTRowSetDelta current = getActive(session,false);
      return current.get(key,id);
   }

   /**
   *  return a row with a given id
   *  @param id ABTID of row
   *  @return ABTRow if successfull or null if not found
   */
   public final ABTRow getExisting(ABTUserSession session, int key, ABTValue id)
   {
      ABTRowSetDelta current = getActive(session,false);
      return current.getExisting(key,id);
   }

   /**
   *  return a row with a given id
   *  @param id int representation of ABTID
   *  @return ABTRow if successfull or null if not found
   */
   public final ABTRow get(ABTUserSession session, int id)
   {
    return get(session,new ABTID(id));
   }
   /**
   *  return a row with a given id
   *  @param id int representation of ABTID
   *  @return ABTRow if successfull or null if not found
   */
   public final ABTRow get(ABTUserSession session, ABTID id)
   {
      ABTRowSetDelta current = getActive(session,false);
      return current.get(id);
   }

   /**
   *  return a new row
   *  @return ABTRow if successfull or null if not found
   */
   protected synchronized final ABTRow add(ABTUserSession session, ABTID id)
   {

      ABTRow row = new ABTRow(this,id);
      ABTRowSetDelta current = getActive(session,true);
      current.addRow(row);
      return row;
   }



   /**
   *  remove a row
   *  @return ABTRow if successfull or null if not found
   */
   protected synchronized final void remove(ABTUserSession session, ABTRow row)
   {
      ABTRowSetDelta current = getActive(session,true);
      current.removeRow(row);

      if (indices != null)
      {
         int j = indices.size();
         for (int i = 0; i < j; i++)
         {
            ABTProperty prop = (ABTProperty)(indices.at(i));
            try
            {
               ABTValue val = row.getValue (session, prop.getRowIndex());
               if (!(ABTValue.isNull(val)))
                 current.removeIndex(row,i,val);
            }
            catch (Exception e)
            {
            }
         }
      }
      return;

   }

   /**
   *  remove a row
   *  @return ABTRow if successfull or null if not found
   */
   protected synchronized final void undelete(ABTUserSession session, ABTRow row, ABTValue remoteID)
   {

      ABTRowSetDelta current = getActive(session,true);
      current.addRow(row);
      if (indices != null)
      {
         int j = indices.size();
         for (int i = 0; i < j; i++)
         {
            ABTProperty prop = (ABTProperty)(indices.at(i));
            try
            {
               ABTValue val = row.getValue (session, prop.getRowIndex());
               if (!(ABTValue.isNull(val)))
                 current.addIndex(row,i,val);
            }
            catch (Exception e)
            {
            }
         }
      }
      return;
   }


 	/**
	*  return a row with a specific ID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
   protected synchronized ABTValue setIndex (ABTUserSession session,ABTRow row, ABTString index, ABTValue oldID, ABTValue newID)
	{
      try
      {
         return setIndexValue (session,row,getProperty(session,index).getLookupIndex(),oldID,newID);
      }
      catch (Exception e)
      {
         return null;
      }
	}

 	/**
	*  return a row with a specific ID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
   protected synchronized ABTValue setIndex (ABTUserSession session,ABTRow row, String index, ABTValue oldID, ABTValue newID)
	{
      try
      {
         return setIndexValue (session,row,getProperty(session,index).getLookupIndex(),oldID,newID);
      }
      catch (Exception e)
      {
         return null;
      }
	}

 	/**
	*  return a row with a specific ID
	*  @param id - ABTID to be searched
	* @return ABTRow - row with id (remote or local) or null for not found
	 */
   protected synchronized ABTValue setIndex (ABTUserSession session,ABTRow row, int index,int lookupIndex_ ,ABTValue oldID, ABTValue newID)
   {
//         return setIndexValue (session,row,getProperty(session,index).getLookupIndex(),oldID,newID);
         return setIndexValue (session,row,lookupIndex_,oldID,newID);

	}


   /**
   * Set the value for a the remoteID
   * @param row to be set
   * @param oldID old RemoteID
   * @param newID new RemoteID
   * @return ABTValue - sets the value and returns the new one
   */
   protected synchronized ABTValue setIndexValue (ABTUserSession session,ABTRow row, int index, ABTValue oldID, ABTValue newID)
   {
      if (index < 0) return null;
      boolean removeOld = (!(ABTValue.isNull(oldID)));
      boolean addNew =  (!(ABTValue.isNull(newID)));

      ABTRowSetDelta current = getActive(session,true);
      if (removeOld)
          current.removeIndex(row,index,oldID);
      if (addNew)
            current.addIndex(row,index,newID);
      return newID;
   }


    protected ABTArray getData(ABTUserSession session)
    {
        ABTRowSetDelta current = getActive(session,true);
        return current.getArray();
    }

    protected ABTArray getObjectData(ABTUserSession session)
    {
          ABTArray objects = null;
          ABTArray ar = getData(session);
          if (ar != null)
          {
            objects = new ABTArray();
            Enumeration e = ar.elements();
            while (e.hasMoreElements())
              objects.add( ((ABTRow)(e.nextElement())).getObject());
          }
        return objects;
    }


}

