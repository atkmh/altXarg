/*
 * $Header: d:\sanani\src\com\abtcorp\core\ABTArray.java, 18, 12/7/98 5:19:23 PM, Benoit Menendez$
 *
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 *
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.abtcorp.core;

import com.objectspace.jgl.*;
import java.util.Enumeration;
import java.io.Serializable;
import java.lang.StringBuffer;
import com.objectspace.jgl.Array;

public class ABTArray extends ABTValue implements Serializable
{
   private static final long serialVersionUID = -5426020395180338815L;
   private Array _array;

   protected int level = 0;
   public ABTArray()                { _array = new Array(); }
   public ABTArray(ABTArray array)  { _array = new Array(array._array);}

   public int getLevel()
   {
    return level;
   }
   public void setLevel(int newlevel)
   {
    level = newlevel;
   }

   public void addArray(ABTArray array)
   {
      if (array == null)
         return;
      Enumeration e = array.elements();
      while (e.hasMoreElements())
         add(e.nextElement());
   }

   public synchronized Object clone()
   {
      ABTArray result = (ABTArray)super.clone();

      result._array = (Array)_array.clone();

      return result;
   }

   public final synchronized Enumeration elements()                         {return new ABTArrayEnumeration(this);}
   public final synchronized Enumeration elements(ABTComparator comparator) {return new ABTSortedArrayEnumeration(this, comparator);}

   public String dump(int indent, int level)
   {
      StringBuffer sb = new StringBuffer();


      if (level > 0)
         sb.append(ABTUtil.newLine(indent) + this.getClass() + ":");
      int i = 0;
      Enumeration e = elements();
      while (e.hasMoreElements())
      {
         Object o = e.nextElement();
         if (o instanceof ABTValue)
            sb.append(ABTUtil.newLine(indent+1) + i + " : " + ((ABTValue)o).dump(indent + 1,level));
         else
            if (o != null)
               sb.append(ABTUtil.newLine(indent+ 1)+ i + " : "  + o.toString());
            else
               sb.append(ABTUtil.newLine(indent+1) + i + " : - null");
         i++;
      }
      return sb.toString();

   }


  /**
   * Return true if I'm equal to another object.
   * @param object The object to compare myself against.
   */
  public boolean equals( Object object ) {
    return _array.equals(object );
    }

  /**
   * Return true if I contain the same items in the same order as
   * another Array. Use equals() to compare the individual elements.
   * @param array The Array to compare myself against.
   */
  public synchronized boolean equals( ABTArray array ) {
    return _array.equals(array._array);
    }

  /**
   * Return my hash code for support of hashing containers
   */
  public synchronized int hashCode() {
    return _array.hashCode( );
    }


  /**
   * Return a string that describes me.
   */
  public synchronized String toString() {
    return _array.toString( );
    }

  /**
   * Become a shallow copy of an existing Array.
   * @param array The Array that I shall become a shallow copy of.
   */
  public synchronized void copy( ABTArray array ) {
    _array.copy(array._array );
    }

  /**
   * Copy my elements into the specified array.
   * The number of items that are copied is equal to the smaller of my
   * length and the size of the specified array.
   * @param array The array that I shall copy my elements into.
   */
  public synchronized void copyTo( Object[] array ) {
    _array.copyTo( array);
    }

  /**
   * Return true if I contain no entries.
   */
  public boolean isEmpty() {
    return _array.isEmpty( );
    }

  /**
   * Return the number of entries that I contain.
   */
  public int size() {
    return _array.size( );
    }

  /**
   * Return the maximum number of entries that I can contain.
   */
  public int maxSize() {
    return _array.maxSize( );
    }

  /**
   * Return the number of elements that I contain without allocating more
   * internal storage.
   */
  public int capacity() {
    return _array.capacity( );
    }

  /**
   * Return my last item.
   * @exception com.objectspace.jgl.InvalidOperationException If the Array is empty.
   */
  public synchronized Object back() {
    return _array.back( );
    }

  /**
   * Return my first item.
   * @exception com.objectspace.jgl.InvalidOperationException If the Array is empty.
   */
  public synchronized Object front() {
    return _array.front( );
    }

  /**
   * Return the element at the specified index.
   * @param index The index.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
  public synchronized Object at( int index ) {
    return _array.at( index );
    }

  /**
   * Set the element at the specified index to a particular object.
   * @param index The index.
   * @param object The object.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
  public synchronized void put( int index, Object object ) {
    _array.put( index, object);
    }

  /**
   * Remove all of my elements.
   */
  public synchronized void clear() {
    _array.clear( );
    }

  /**
   * Remove the element at a particular position.
   * @param pos An enumeration positioned at the element to remove.
   * @exception IllegalArgumentException is the Enumeration isn't an
   * ArrayIterator for this Array object.
   */
  public Object remove( Enumeration pos ) {
    return _array.remove( pos);
    }

  /**
   * Remove the element at a particular index.
   * @param index The index of the element to remove.
   * @return The object removed.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
  public synchronized Object remove( int index ) {
    return _array.remove(index );
    }

  /**
   * Remove the elements in the specified range.
   * @param first An Enumeration positioned at the first element to remove.
   * @param last An Enumeration positioned immediately after the last element to remove.
   * @return The number of elements removed.
   * @exception IllegalArgumentException is the Enumeration isn't an
   * ArrayIterator for this Array object.
   */
  public int remove( Enumeration first, Enumeration last ) {
    return _array.remove( first, last);
    }

  /**
   * Remove the elements within a range of indices.
   * @param first The index of the first element to remove.
   * @param last The index of the last element to remove.
   * @return The number of elements removed.
   * @exception java.lang.IndexOutOfBoundsException If either index is invalid.
   */
  public synchronized int remove( int first, int last ) {
    return _array.remove( first, last);
    }

  /**
   * Remove and return my last element.
   * @exception com.objectspace.jgl.InvalidOperationException If the Array is empty.
   */
  public synchronized Object popBack() {
    return _array.popBack( );
    }

  /**
   * Add an object after my last element.  Returns null.
   * This function is a synonym for pushBack().
   * @param object The object to add.
   */
  public synchronized Object add( Object object ) {
    return _array.add(object );
    }

  /**
   * Add an object after my last element.
   * @param The object to add.
   */
  public void pushBack( Object object ) {
    _array.pushBack( object);
    }

  /**
   * Insert an object at a particular position and return an iterator
   * positioned at the new element.
   * @param pos An iterator positioned at the element that the object will be inserted immediately before.
   * @param object The object to insert.
   */
  public ArrayIterator insert( ArrayIterator pos, Object object ) {
    return _array.insert(pos,object );
    }

  /**
   * Insert an object at a particular index.
   * @param index The index of the element that the object will be inserted immediately before.
   * @param object The object to insert.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   */
  public synchronized void insert( int index, Object object ) {
    _array.insert( index, object);
    }

  /**
   * Insert multiple objects at a particular position.
   * @param pos An iterator positioned at the element that the objects will be inserted immediately before.
   * @param n The number of objects to insert.
   * @param object The object to insert.
   */
  public void insert( ArrayIterator pos, int n, Object object ) {
    _array.insert( pos, n, object);
    }

  /**
   * Insert multiple objects at a particular index.
   * @param index The index of the element that the objects will be inserted immediately before.
   * @param object The object to insert.
   * @exception java.lang.IndexOutOfBoundsException If the index is invalid.
   * @exception java.lang.IllegalArgumentException If the number of objects is negative.
   */
  public synchronized void insert( int index, int n, Object object ) {
    _array.insert( index, n, object );
    }

  /**
   * Insert a sequence of objects at a particular location.
   * @param pos The location of the element that the objects will be inserted immediately before.
   * @param first An iterator positioned at the first element to insert.
   * @param last An iterator positioned immediately after the last element to insert.
   */
  public void insert( ArrayIterator pos, ForwardIterator first, ForwardIterator last ) {
    _array.insert( pos, first, last);
    }

  /**
   * Insert a sequence of objects at a particular index.
   * @param index The index of the element that the objects will be inserted immediately before.
   * @param first An iterator positioned at the first element to insert.
   * @param last An iterator positioned immediately after the last element to insert.
   */
  public synchronized void insert( int index, ForwardIterator first, ForwardIterator last ) {
    _array.insert( index, first, last);
    }

  /**
   * Swap my contents with another Array.
   * @param array The Array that I will swap my contents with.
   */
  public synchronized void swap( ABTArray array ) {
    _array.swap( array._array);
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public ForwardIterator start() {
    return _array.start( );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public ForwardIterator finish() {
    return _array.finish( );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public synchronized ArrayIterator begin() {
    return _array.begin( );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public synchronized ArrayIterator end() {
    return _array.end( );
    }

  /**
   * If my storage space is currently larger than my total number of elements,
   * reallocate the elements into a storage space that is exactly the right size.
   */
  public synchronized void trimToSize() {
    _array.trimToSize( );
    }

  /**
   * Pre-allocate enough space to hold a specified number of elements.
   * This operation does not change the value returned by size().
   * @param n The amount of space to pre-allocate.
   * @exception java.lang.IllegalArgumentException If the specified size is negative.
   */
  public synchronized void ensureCapacity( int n ) {
    _array.ensureCapacity( n);
    }

  /**
   * Remove and return my first element.
   * @exception com.objectspace.jgl.InvalidOperationException If the Array is empty.
   */
  public synchronized Object popFront() {
    return _array.popFront( );
    }

  /**
   * Insert an object in front of my first element.
   * @param object The object to insert.
   */
  public void pushFront( Object object ) {
    _array.pushFront( object );
    }

  /**
   * Remove all elements that match a particular object and return the number of
   * objects that were removed.
   * @param object The object to remove.
   */
  public int remove( Object object ) {
    return _array.remove( object);
    }

  /**
   * Remove at most a given number of elements that match a particular
   * object and return the number of
   * objects that were removed.
   * @param object The object to remove.
   * @param count The maximum number of objects to remove.
   */
  public synchronized int remove( Object object, int count ) {
    return _array.remove( object, count);
    }

  /**
   * Remove all elements within a range of indices that match a particular object
   * and return the number of objects that were removed.
   * @param first The index of the first object to consider.
   * @param last The index of the last object to consider.
   * @param object The object to remove.
   * @exception java.lang.IndexOutOfBoundsException If either index is invalid.
   */
  public synchronized int remove( int first, int last, Object object ) {
    return _array.remove( first, last, object);
    }

  /**
   * Replace all elements that match a particular object with a new value and return
   * the number of objects that were replaced.
   * @param oldValue The object to be replaced.
   * @param newValue The value to substitute.
   */
  public synchronized int replace( Object oldValue, Object newValue ) {
    return _array.replace(oldValue, newValue );
    }

  /**
   * Replace all elements within a range of indices that match a particular object
   * with a new value and return the number of objects that were replaced.
   * @param first The index of the first object to be considered.
   * @param last The index of the last object to be considered.
   * @param oldValue The object to be replaced.
   * @param newValue The value to substitute.
   * @exception java.lang.IndexOutOfBoundsException If either index is invalid.
   */
  public synchronized int replace( int first, int last, Object oldValue, Object newValue ) {
    return _array.replace( first, last, oldValue, newValue);
    }

  /**
   * Return the number of objects that match a particular value.
   * @param object The object to count.
   */
  public int count( Object object ) {
    return _array.count( object);
    }

  /**
   * Return the number of objects within a particular range of indices that match a
   * particular value.
   * @param first The index of the first object to consider.
   * @param last The index of the last object to consider.
   * @exception java.lang.IndexOutOfBoundsException If either index is invalid.
   */
  public synchronized int count( int first, int last, Object object ) {
    return _array.count( first, last, object);
    }

  /**
   * Return the index of the first object that matches a particular value, or -1
   * if the object is not found.
   * @param object The object to find.
   */
  public int indexOf( Object object ) {
    return _array.indexOf( object);
    }

  /**
   * Return the index of the first object within a range of indices that match a
   * particular object, or -1 if the object is not found.
   * @param first The index of the first object to consider.
   * @param last The index of the last object to consider.
   * @param object The object to find.
   * @exception java.lang.IndexOutOfBoundsException If either index is invalid.
   */
  public synchronized int indexOf( int first, int last, Object object ) {
    return _array.indexOf( first, last, object);
    }

  /**
   * Sets the size of the Array. if the size shrinks, the extra elements (at
   * the end of the array) are lost; if the size increases, the new elements
   * are set to null.
   * @param newSize The new size of the Array.
   */
  public synchronized void setSize( int newSize ) {
    _array.setSize( newSize);
    }

  /**
   * Return true if I contain a particular object.
   * @param object The object in question.
   */
  public boolean contains( Object object ) {
    return _array.contains(object );
    }
}