
package com.abtcorp.hub;

/*
 * ABTListenener.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 03-09-98	HJB		Initial Design
  * 04-09-98	HJB		getInstanceCount, getObjectType
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;

/**
 *  IABTListener is the base class allowing common handling of notification of rowchanges
 *  By implementing this interface an object can 'listen' to
 *  any rowchanges
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see com.abtcorp.idl.IABTListenerActions
 */

public interface  IABTListener extends com.abtcorp.idl.IABTListenerActions

{

    /**
    * get notified !after! a rowchange took place
    * @param object - ABTObject or ABTObjectSet that has changed
    * @param action - see list of constants above
    * @param property - the property which has changed (if applicable)
    * @param newValue - value of field after the change or ABTObject added/removed
    * @param oldValue - original value (if applicable)
    */
   public void hasChanged( ABTUserSession session,
                           ABTValue object,
                           int action,
                           ABTProperty property,
                           ABTValue newValue,
                           ABTValue oldValue);


   public int compareTo(Object object); 
   }