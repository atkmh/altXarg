package com.abtcorp.io;
/*
 * ABTIOHelper.java 06/04/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 06-04-98    SOB             Initial Implementation
  * 06-22-98    SOB             get/setSpace(); get/setDriver()
  * 06-26-98    SOB             more helper methods
  * 07-09-98    SOB             basic transaction support
  * 07-14-98    SOB             integrate Methodology IO helper methods
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;

import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTException;
//import com.abtcorp.core.ABTHashtable;

/**
 *  ABTIOHelper is the base abstract class for all driver helper classes.  Helper
 *  classes are those which assist the drivers in accessing persistent storage and the object
 *  space.
 *
 *			This class is not meant to be instantiated directly, but to be extended by various
 *          classes that a driver will instantiate to assist it in populating the object space.
 *
 *  <pre>
 *       public class ABTIOPMWRepoProject extends ABTIOHelper
 *       {
 *          ... override find(), create(), update(), etc., methods for PMW-specific requirements ...
 *       }
 *
 *  </pre>
 *
 * @version	$Revision: 18$
 * @author  S. Bursch
 * @see     ABTDriver
 */

public abstract class ABTIOHelper implements com.abtcorp.idl.IABTDriverConstants
{
/**
 *		Creates an ABTIOHelper that is not associated with an ABTObjectSpace or ABTDriver.
 *    Associating an object space with this class will be deferred until later.
 */
   public   ABTIOHelper() { /* implicit call to super() here */ }

/**
 *    Populates an object space with an object (or objects) as appropriate to the
 *    particular helper.
 *	   @param parms ABTArray, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs
 */
   public abstract   ABTValue populate(ABTArray parms) throws ABTException;

/**
 *    Populates an object space with an object (or objects) as appropriate to the
 *    particular helper
 *		@return an ABTValue which, if successful is a reference to the object created or updated
 *    in the object space.  Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs
 */
   protected abstract   ABTValue populate() throws ABTException;

/**
 *    Saves an object (or objects) from the object space as appropriate to the
 *    particular helper.
 *	   @param parms ABTArray, the elements of which are meaningful as parameters to the particular
 *    helper
 *		@exception ABTException if an unrecoverable error occurs
 */
   public abstract   void save(ABTArray parms) throws ABTException;


/**
 *		Checks for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value  ABTValue returned from the invocation of an object space
 *             or ABTObject method
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void checkError( ABTValue value ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage());
   }

/**
 *		Checks for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value ABTValue returned from the invocation of an object space
 *             or ABTObject method
 *    @param propname property name being get/set
 *    @param settingvalue value being get/set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void checkError( ABTValue value, String propname, ABTValue settingvalue ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage() + " (" + propname + ", " + settingvalue + ")");
   }

/**
 *		Checks for errors after an object space get/setValue(), object set operation,
 *    etc.
 *    @param value ABTValue returned from the invocation of an object space
 *             or ABTObject method
 *    @param propindex property index of the property being get/set
 *    @param settingvalue value being get/set
 *		@exception ABTException if an unrecoverable error occurs
 *
 */
   public void checkError( ABTValue value, int propindex, ABTValue settingvalue ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException(((ABTError)value).getMessage() + " (" + propindex + ", " + settingvalue + ")");
   }


/**
 * Creates a new object in the object space and initializes it with values appropriate to the
 * driver being used.
 *	@param parms ABTArry, the elements of which are meaningful as parameters to the particular
 * helper
 *	@return an ABTValue which, if successful, is a reference to the object added to the object
 * space.  Otherwise, an ABTError.
 * @exception ABTException if an unrecoverable error occurs
 */

   protected abstract ABTValue create(ABTArray parms) throws ABTException;

/**
 *    Updates an existing object in the object space with values appropriate to the driver being
 *    used.
 *		@param parms ABTArray, the elements of which are meaningful as parameters to the
 *    particular helper
 *		@return an ABTValue which, if the create operation was successful, is a reference to the object updated in the
 *    object space. Otherwise, an ABTError.
 *		@exception ABTException if an unrecoverable error occurs
 */

   protected abstract ABTValue update(ABTArray parms) throws ABTException;

}
