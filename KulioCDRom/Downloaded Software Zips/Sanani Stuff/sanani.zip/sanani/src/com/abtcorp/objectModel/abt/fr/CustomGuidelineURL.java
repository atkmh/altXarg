package  com.abtcorp.objectModel.abt.fr;

/*
 * CustomGuidelineURL.java 08/31/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date        Author          Description
 * 08-31-98       JSE          Initial Design
 *
 */

import   com.abtcorp.objectModel.abt.*;
import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;
import   com.abtcorp.blob.*;

/**
 * Virtual field rule.  Returns a boolean, true if the property pmBasestart is
 * not null.
 *
 * @version	1.0
 * @author  Scott Ellis
 */

public class CustomGuidelineURL extends SiteFieldRule
{
   /**
    * return the GuidelineURL made from guidlineID
    *
    * @param session    session object for transaction support
    * @param parent     the container object for this field property
    * @param property   the property object
    * @param oldValue    the current value of the property
    * @param newValue    the new value of the property
    * @param parameters list of parameters and (field/app specific)
    *
    * @return ABTValue. Returns ABTValue if successful, ABTError if not.
    */
   protected ABTValue onGet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters )
   {
         return getGuidelineURL(  parent.getObjectType(),//   String procedure,
                              session, //ABTUserSession session,
                              parent, //ABTObject caller,
                              OFD_GUIDELINES, //String guidelines,
                              OFD_SITE, //String parentReference,
                              null, //String alternateParentReference,
                              OFD_GUIDELINE_URL, //String parentURL,
                              parameters); //ABTHashtable parameters)
    }


}
