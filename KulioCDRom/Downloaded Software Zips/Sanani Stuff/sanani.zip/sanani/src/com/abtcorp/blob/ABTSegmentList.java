package com.abtcorp.blob;

import com.abtcorp.core.*;
import java.io.Serializable;

public final class ABTSegmentList extends ABTSortedArray implements Serializable
{
   private static final long serialVersionUID = -4857582738693802480L;

	private double default_;

   public ABTSegmentList(double rate) {default_ = rate;}

   public final ABTSegment getSegment(int index) {return (ABTSegment)at(index);}

   public final double getDefault()            {return default_;}
   public final void   setDefault(double rate) {default_ = rate;}

   public final ABTTime getStart()  {return size() > 0 ? getSegment(0).getStart()         : null;}
   public final ABTTime getFinish() {return size() > 0 ? getSegment(size()-1).getFinish() : null;}

   public final ABTTime getFirst()
   {
   	for (int index = 0; index < size(); index++) {
   		ABTTime time = getSegment(index).getFirst();

   		if (time != null) return time;
   	}

      return null;
   }

   public final ABTTime getLast()
   {
   	for (int index = size(); index > 0; index--) {
   		ABTTime time = getSegment(index-1).getLast();

   		if (time != null) return time;
   	}

      return null;
   }

   private final int search(ABTTime time)
   {
	   int lower = 0;
	   int upper = size();

      if (upper <= lower) return lower;

      if (getSegment(upper-1).getFinish().compareTo(time) <= 0) return upper;
      if (getSegment(lower).getStart().compareTo(time)    >  0) return lower;

	   while (lower < upper) {
		   int index = (lower + upper) >> 1;

		   ABTSegment segment = getSegment(index);

		   if      (segment.getFinish().compareTo(time) <= 0) lower = index + 1;
		   else if (segment.getStart().compareTo(time)  >  0) upper = index;
		   else                                               return index;
	   }

	   return lower;
	}

   public final boolean isDefined(ABTTime time)
   {
   	int index = search(time);

   	return index < size() && getSegment(index).map(time);
   }

   public final boolean isDefined(ABTTime start, ABTTime finish)
   {
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start.compareTo(finish) >= 0) return false;

   	int index = search(start);

   	return index < size() && getSegment(index).map(start, finish);
   }

   public final double getRate(ABTTime time)
   {
   	int index = search(time);

   	if (index < size()) {
   	   ABTSegment segment = getSegment(index);

   	   if (segment.map(time)) return segment.getRate(time);
   	}

      return default_;
   }

   public final double getSum(ABTTime start, ABTTime finish)
   {
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start == null || finish == null) return 0;

   	if (start.compareTo(finish) >  0) return -getSum(finish, start);
   	if (start.compareTo(finish) == 0) return 0;

   	double result = default_ * ABTTime.diff(start, finish);

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		ABTTime time1 = ABTTime.max(segment.getStart(),  start);
   		ABTTime time2 = ABTTime.min(segment.getFinish(), finish);

   		result += segment.getSum(time1, time2) - default_ * ABTTime.diff(time1, time2);
   	}

   	return result;
   }

   public final double getSum() {return getSum(null, null);}

   public final boolean isZero()
   {
      if (default_ !=  0) return false;

   	for (int index = 0; index < size(); index++)
   	   if (getSegment(index).getRate() != 0) return false;

      return true;
   }

   public final void clipSegment(ABTTime start, ABTTime finish)
   {
   	for (int index = 0; index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   		if (segment.map(start, finish)) {
      		if (start  != null && segment.getStart().compareTo(start)   < 0) put(index, segment = new ABTSegment(start, segment.getFinish(), segment.getRate(), segment.getCalendar()));
      		if (finish != null && segment.getFinish().compareTo(finish) > 0) put(index, segment = new ABTSegment(segment.getStart(), finish, segment.getRate(), segment.getCalendar()));
      	} else remove(index--);
   	}
   }

   public final void clip(ABTSegmentList segments)
   {
   	ABTSegmentList result = new ABTSegmentList(default_);

   	for (int i = 0; i < segments.size(); i++) {
   	   ABTSegment p = getSegment(i);

   		ABTTime start  = p.getStart();
   		ABTTime finish = p.getFinish();

   		for (int j = 0; j < size(); j++) {
      	   ABTSegment q = getSegment(j);

   			if (q.map(start, finish)) {
         		ABTTime time1 = ABTTime.max(q.getStart(),  start);
         		ABTTime time2 = ABTTime.min(q.getFinish(), finish);

   				result.pushBack(new ABTSegment(time1, time2, q.getRate(), q.getCalendar()));
   			}
   		}
   	}

      copy(result);
   }

   public final void resetSegment(ABTTime start, ABTTime finish)
   {
   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

       	   if (! segment.map(start, finish)) break;

   		if (finish != null && segment.getFinish().compareTo(finish) > 0) insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		if (start  != null && segment.getStart().compareTo(start)   < 0) put(index, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		else                     		                                   remove(index--);
   	}
   }

   public final void setSegment(ABTTime start, ABTTime finish, double rate, ABTCalendar calendar)
   {
      setSegment(new ABTSegment(start, finish, rate, calendar));
   }

   public final void setSegment(ABTSegment segment)
   {
      resetSegment(segment.getStart(), segment.getFinish());

   	add(segment);
   }

   public final void setSegments(ABTSegmentList segments)
   {
   	for (int index = 0; index < segments.size(); index++) setSegment(segments.getSegment(index));
   }

   public final void addRate(double rate)
   {
      if (rate == 0) return;

     	explode();

      default_ += rate;

   	for (int index = 0; index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   put(index, new ABTSegment(segment.getStart(), segment.getFinish(), segment.getRate() + rate, segment.getCalendar()));
   	}
   }

   public final void subRate(double rate) {addRate(-rate);}

   public final void scaleRate(double rate)
   {
      if (rate == 0) {clear(); return;}
      if (rate == 1) return;

      default_ *= rate;

   	for (int index = 0; index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   put(index, new ABTSegment(segment.getStart(), segment.getFinish(), segment.getRate() * rate, segment.getCalendar()));
   	}
   }

   public final void divideRate(double rate) {scaleRate(rate != 0 ? 1/rate : 0);}

   public final void addSegment(ABTTime start, ABTTime finish, double rate, ABTCalendar calendar)
   {
   	if (rate == 0) return;

      int index;

   	for (index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (segment.getStart().compareTo(start) > 0) {     // new segment
   			insert(index++, new ABTSegment(start, segment.getStart(), rate + default_, calendar));
   			start = segment.getStart();
   		}

   		if (segment.getStart().compareTo(start) < 0) {     // front split
   		   put(index++, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		   insert(index, segment = new ABTSegment(start, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		}

   		if (segment.getFinish().compareTo(finish) > 0) {   // tail split
   		   insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		   put(index, segment = new ABTSegment(segment.getStart(), finish, segment.getRate(), segment.getCalendar()));
   		}

  		   put(index, segment = new ABTSegment(segment.getStart(), start = segment.getFinish(), segment.getRate() + rate, segment.getCalendar()));
   	}

   	if (finish.compareTo(start) > 0) insert(index, new ABTSegment(start, finish, rate + default_, calendar));   // new segment
   }

   public final void addSegment(ABTSegment segment)
   {
      addSegment(segment.getStart(), segment.getFinish(), segment.getRate(), segment.getCalendar());
   }

   public final void addSegments(ABTSegmentList segments)
   {
   	if (segments.default_ == 0) fixup(segments);
   	else 					          addRate(segments.default_);

   	for (int index = 0; index < segments.size(); index++) {
         ABTSegment segment = segments.getSegment(index);

   	   addSegment(segment.getStart(), segment.getFinish(), segment.getRate() - segments.default_, segment.getCalendar());
   	}
   }

   public final void subSegment(ABTTime start, ABTTime finish, double rate, ABTCalendar calendar)
   {
      addSegment(start, finish, -rate, calendar);
   }

   public final void subSegment(ABTSegment segment)
   {
      subSegment(segment.getStart(), segment.getFinish(), segment.getRate(), segment.getCalendar());
   }

   public final void subSegments(ABTSegmentList segments)
   {
   	if (segments.default_ == 0) fixup(segments);
   	else 					          subRate(segments.default_);

   	for (int index = 0; index < segments.size(); index++) {
   	   ABTSegment segment = segments.getSegment(index);

   	   subSegment(segment.getStart(), segment.getFinish(), segment.getRate() + segments.default_, segment.getCalendar());
   	}
   }

   public final void scaleSegment(ABTTime start, ABTTime finish, double rate, ABTCalendar calendar)
   {
   	if (rate == 0) {setSegment(start, finish, 0, null); return;}
   	if (rate == 1) return;

   	int index;

   	for (index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (segment.getStart().compareTo(start) > 0) {     // new segment
   			insert(index++, new ABTSegment(start, segment.getStart(), rate * default_, calendar));
   			start = segment.getStart();
   		}

   		if (segment.getStart().compareTo(start) < 0) {     // front split
   		   put(index++, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		   insert(index, segment = new ABTSegment(start, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		}

   		if (segment.getFinish().compareTo(finish) > 0) {   // tail split
   		   insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		   put(index, segment = new ABTSegment(segment.getStart(), finish, segment.getRate(), segment.getCalendar()));
   		}

  		   put(index, segment = new ABTSegment(segment.getStart(), start = segment.getFinish(), segment.getRate() * rate, segment.getCalendar()));
   	}

   	if (finish.compareTo(start) > 0) insert(index, new ABTSegment(start, finish, rate * default_, calendar));   // new segment
   }

   public final void scaleSegment(ABTSegment segment)
   {
      scaleSegment(segment.getStart(), segment.getFinish(), -segment.getRate(), segment.getCalendar());
   }

   public final void scaleSegments(ABTSegmentList segments)
   {
   	segments.normalize(this);

   	if (segments.default_ == 0) {
   		default_ = 0;

   		clip(segments);

   		for (int index = 0; index < segments.size(); index++) scaleSegment(segments.getSegment(index));
   	} else {
   		scaleRate(segments.default_);

   		for (int index = 0; index < segments.size(); index++) {
      	   ABTSegment segment = segments.getSegment(index);

      	   scaleSegment(segment.getStart(), segment.getFinish(), segment.getRate() / segments.default_, segment.getCalendar());
      	}
   	}
   }

   public final void divideSegment(ABTTime start, ABTTime finish, double rate, ABTCalendar calendar)
	{
		scaleSegment(start, finish, rate != 0 ? 1/rate : 0, calendar);
	}

   public final void divideSegment(ABTSegment segment)
   {
      scaleSegment(segment.getStart(), segment.getFinish(), segment.getRate() != 0 ? 1/segment.getRate() : 0, segment.getCalendar());
   }

   public final void divideSegments(ABTSegmentList segments)
   {
   	segments.normalize(this);

   	if (segments.default_ == 0) {
   		default_ = 0;

   		clip(segments);

   		for (int index = 0; index < segments.size(); index++) divideSegment(segments.getSegment(index));
   	} else {
   		divideRate(segments.default_);

   		for (int index = 0; index < segments.size(); index++) {
      	   ABTSegment segment = segments.getSegment(index);

      	   divideSegment(segment.getStart(), segment.getFinish(), segment.getRate() / segments.default_, segment.getCalendar());
      	}
   	}
   }

	public final ABTTime addWorktime(ABTTime time, double value)
	{
   	if (time == null) time = getStart();

   	if (time == null) return null;

		if (value < 0) return subWorktime(time, -value);

   	for (int index = search(time); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   		if (segment.getStart().compareTo(time) > 0) {
   			double work = ABTTime.diff(time, segment.getStart()) * default_;

   			if (value < work) {
					int duration = default_ != 0 ? (int)Math.round(value / default_) : 0;

   				return time.add(duration);
   			}

   			value -= work; time = segment.getStart();
   		}

  			double work = segment.getSum(time, null);

  			if (value < work) return segment.addWorktime(time, value);

   		value -= work; time = segment.getFinish();
   	}

		if (value > 0) {
			int duration = default_ != 0 ? (int)Math.round(value / default_) : 0;

			return time.add(duration);
		}

		return time;
	}

	public final ABTTime subWorktime(ABTTime time, double value)
	{
   	if (time == null) time = getFinish();

   	if (time == null) return null;

		if (value < 0) return addWorktime(time, -value);

   	for (int index = search(time); index >= 0; index--) {
   		if (index >= size()) continue;

   	   ABTSegment segment = getSegment(index);

   		if (segment.getFinish().compareTo(time) < 0) {
   			double work = ABTTime.diff(segment.getFinish(), time) * default_;

   			if (value < work) {
					int duration = default_ != 0 ? (int)Math.round(value / default_) : 0;

   				return time.sub(duration);
   			}

   			value -= work; time = segment.getFinish();
   		}

  			double work = segment.getSum(null, time);

  			if (value < work) return segment.subWorktime(time, value);

   		value -= work; time = segment.getStart();
   	}

		if (value > 0) {
			int duration = default_ != 0 ? (int)Math.round(value / default_) : 0;

			return time.sub(duration);
		}

		return time;
	}

	public final int diffWorktime(ABTTime start, ABTTime finish)
	{
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start == null || finish == null) return 0;

   	if (start.compareTo(finish) >  0) return -diffWorktime(finish, start);
   	if (start.compareTo(finish) == 0) return 0;

   	int result = default_ != 0 ? ABTTime.diff(start, finish) : 0;

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		ABTTime time1 = ABTTime.max(segment.getStart(),  start);
   		ABTTime time2 = ABTTime.min(segment.getFinish(), finish);

   		result += segment.diffWorktime(time1, time2) - (default_ != 0 ? ABTTime.diff(time1, time2) : 0);
   	}

   	return result;
	}

	public final void floor(ABTTime start, ABTTime finish, double rate)
	{
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start == null || finish == null) return;

   	if (start.compareTo(finish) >  0) {floor(finish, start, rate); return;}
   	if (start.compareTo(finish) == 0) return;

		if (default_ < rate) default_ = rate;

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (finish != null && segment.getFinish().compareTo(finish) > 0) insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		if (start  != null && segment.getStart().compareTo(start)   < 0) put(index, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		else if (segment.getRate() < rate) 										  put(index, new ABTSegment(segment.getStart(), segment.getFinish(), rate, segment.getCalendar()));
   	}
	}

	public final void ceil(ABTTime start, ABTTime finish, double rate)
	{
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start == null || finish == null) return;

   	if (start.compareTo(finish) >  0) {ceil(finish, start, rate); return;}
   	if (start.compareTo(finish) == 0) return;

		if (default_ > rate) default_ = rate;

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (finish != null && segment.getFinish().compareTo(finish) > 0) insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		if (start  != null && segment.getStart().compareTo(start)   < 0) put(index, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		else if (segment.getRate() > rate) 										  put(index, new ABTSegment(segment.getStart(), segment.getFinish(), rate, segment.getCalendar()));
   	}
	}

	public final boolean lessThan(ABTTime start, ABTTime finish, double rate)
	{
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start == null || finish == null) return false;

   	if (start.compareTo(finish) >  0) return lessThan(finish, start, rate);
   	if (start.compareTo(finish) == 0) return false;

		if (default_ < rate) return true;

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (segment.getRate() < rate) return true;
   	}

		return false;
	}

	public final boolean greaterThan(ABTTime start, ABTTime finish, double rate)
	{
   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start == null || finish == null) return false;

   	if (start.compareTo(finish) >  0) return greaterThan(finish, start, rate);
   	if (start.compareTo(finish) == 0) return false;

		if (default_ > rate) return true;

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (segment.getRate() > rate) return true;
   	}

		return false;
	}

	public final int 		diffWorktime() 				{return diffWorktime(null, null);}
	public final void 	floor(double rate)			{floor(null, null, rate);}
	public final void 	ceil(double rate)				{ceil(null, null, rate);}
	public final boolean lessThan(double rate)		{return lessThan(null, null, rate);}
	public final boolean greaterThan(double rate)	{return greaterThan(null, null, rate);}

	private final int explode(int index)
   {
   	ABTSegment segment = (ABTSegment)remove(index);

   	index = segment.explode(this, index);

   	return --index;
   }

   private final void explode(ABTTime start, ABTTime finish)
   {
      if (size() == 0) return;

   	if (start  == null) start  = getStart();
   	if (finish == null) finish = getFinish();

   	if (start.compareTo(finish) >= 0) return;

   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (segment.getCalendar() == null) continue;

   		if (segment.getStart().compareTo(start) < 0) {     // front split
   		   put(index++, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		   insert(index, segment = new ABTSegment(start, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		}

   		if (segment.getFinish().compareTo(finish) > 0) {   // tail split
   		   insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		   put(index, segment = new ABTSegment(segment.getStart(), finish, segment.getRate(), segment.getCalendar()));
   		}

   		index = explode(index);
   	}
   }

   private final void explode() {explode(null, null);}

   private final void fixup(ABTSegmentList segments)
   {
      normalize(segments);

      segments.normalize(this);
   }

   private final void normalize(ABTTime start, ABTTime finish, ABTCalendar calendar)
   {
   	for (int index = search(start); index < size(); index++) {
   	   ABTSegment segment = getSegment(index);

   	   if (! segment.map(start, finish)) break;

   		if (segment.getCalendar() == null || segment.getCalendar() == calendar) continue;

   		if (segment.getStart().compareTo(start) < 0) {     // front split
   		   put(index++, new ABTSegment(segment.getStart(), start, segment.getRate(), segment.getCalendar()));
   		   insert(index, segment = new ABTSegment(start, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		}

   		if (segment.getFinish().compareTo(finish) > 0) {   // tail split
   		   insert(index+1, new ABTSegment(finish, segment.getFinish(), segment.getRate(), segment.getCalendar()));
   		   put(index, segment = new ABTSegment(segment.getStart(), finish, segment.getRate(), segment.getCalendar()));
   		}

   		if (! segment.compatible(calendar)) index = explode(index);
   	}
   }

   private final void normalize(ABTSegment segment)
   {
      normalize(segment.getStart(), segment.getFinish(), segment.getCalendar());
   }

   private final void normalize(ABTSegmentList segments)
   {
   	for (int index = 0; index < segments.size(); index++) normalize(segments.getSegment(index));
   }

   public String toString()
   {
	   StringBuffer buffer = new StringBuffer();

	   if (default_ != 0) buffer.append("default:" + default_ + "\n");

      for (int index = 0; index < size(); index++) {
         if (index > 0) buffer.append("\n");

         buffer.append(getSegment(index));
      }

   	return buffer.toString();
	}
}