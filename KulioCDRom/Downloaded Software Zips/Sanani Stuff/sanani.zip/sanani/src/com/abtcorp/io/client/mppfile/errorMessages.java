package com.abtcorp.io.client.mppfile;

import java.util.ListResourceBundle;

public class errorMessages extends ListResourceBundle
   {
 	public Object[][] getContents() {
 		return contents;
 	}
 	static final Object[][] contents = {
 	   // LOCALIZE THIS
 	   {"100","An exception has occured"},
 	   {"101","Invalid project in "},
 	   {"102","MS Project File Driver:"}
	/*   {"103","object not in instance list"},
	   {"104","Invalid Functioncall"},
 	   {"105","Object Inaccessible"},
 	   {"106","Invalid property"},
 	   {"107","Unknown Property"},
 	   {"108","Invalid Value for Property"},*/ 	   
 	   // END OF MATERIAL TO LOCALIZE
      };
   }