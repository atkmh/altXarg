

package com.abtcorp.hub;

import com.abtcorp.core.*;


public class ABTTransactionContainer
{
   static final short MULTIPLE = 1;
   static final short SINGLE = 0;

   /*
      lock management
   */
   ABTUserSession  lockHolder;
   ABTHashtable lockHolders;

   boolean newLock = true;
   short type = SINGLE;
   /*
      data management
   */
   IABTTransactionInstance owner;
   ABTTransactionData main = null;
   ABTTransactionData current = null;
   /**
   * class constructor
   */
   public ABTTransactionContainer(IABTTransactionInstance owner_, short type_, IABTTransactionData data_)
   {
      type =  type_;
      if (type == MULTIPLE)
         lockHolders = new ABTHashtable();
      else
         lockHolder = null;
      owner = owner_;
      main = new ABTTransactionData(data_);
      current = main;
   }


   /**
   * return the current lockHolder or null if this is not explicitly locked
   */
   public ABTUserSession getLockHolder()
   {
        if (type == SINGLE)
         return lockHolder;
        else
         return null;
   }

   /**
   * try to lock
   */
   public synchronized boolean lock(ABTUserSession requestor)
   {
    if (getLockHolder() == null)
    {
        if (requestor.getTransactionLevel() == -1)
           return true;
        if (type == SINGLE)
        {
            lockHolder = requestor;
            newLock = true;
        }
        else
        {
            // there is no explicit lock - so don't do anyhting here yet

        }

        return true;
    }
    else
    {
       if (requestor == getLockHolder())
       {
           newLock = false;
           return true;
       }
        else
          return false;
     }
   }

   /**
   * try to unlock one step
   */
   public synchronized void removeOnelock(ABTUserSession requestor)
   {
    ABTUserSession lock = getLockHolder();
    if ((type == SINGLE) && (lock != null) && (requestor == lock))
    {
        if (newLock)
        {
            lockHolder = null;
        }
        else
            newLock = true;
        return;
    }
   }


    synchronized protected IABTTransactionData getActive(ABTUserSession session,boolean create)
    {
     if (type == MULTIPLE)
      return  getActiveMulti(session,create);
     ABTUserSession lock = getLockHolder();
     if (!(create))
     {
        if (lock == null)
            return main.getData();
        if (session != lock)
            return main.getData();
        else
            return current.getData();
     }
     int i = session.getTransactionLevel();
     if (( i == -1) || (lock == null))
        return main.getData();

     int j = current.getLevel();
     if (j != i)
     {
         current =  new ABTTransactionData(current,i);
         session.addInstance(owner,i);
     }
     return current.getData();
    }

    private IABTTransactionData getActiveMulti(ABTUserSession session,boolean create)
    {
     current = (ABTTransactionData)lockHolders.get(session);
     if (!(create))
     {
        if (current == null)
            return main.getData();
        else
            return current.getData();
     }
     int i = session.getTransactionLevel();
     if ( i == -1)
        return main.getData();

     int j = -1;
     if (current == null)
     {
        current = main;
     }
     else
      j = current.getLevel();
     if (j != i)
     {
         current =  new ABTTransactionData(current,i);
         session.addInstance(owner,i);
         lockHolders.put(session,current);
     }
     return current.getData();
    }

   /**
   * try to unlock
   */
   public synchronized boolean unLock(ABTUserSession requestor)
   {
    ABTUserSession lock = getLockHolder();

    if ((type == SINGLE) && (lock != null) && (requestor == lock))
    {
        if (newLock)
        {
            commitSingle(requestor,true,true);
        }
        else
            newLock = true;
        return true;
    }

    return false;
   }

    private void rollbackMultiple(ABTUserSession session,boolean all)
    {
     current = (ABTTransactionData)lockHolders.get(session);
     if (current == null)
            return;
     else
     {
         if (all)
          current = main;
         else
          current = current.previous;
         if (current == main)
              lockHolders.remove(session);
         else
             lockHolders.put(session,current);
         return;
     }
    }

    private void rollbackSingle(ABTUserSession requestor,boolean all)
    {
      ABTUserSession lock = getLockHolder();

      if ((lock != null) && (requestor == lock))
      {
         if (all)
          current = main;
         else
          current = current.previous;

        if (current == main)
        {
          lockHolders = null;
        }
        else
          newLock = true;
      }
      return;
    }

   public void commit(ABTUserSession requestor)
   {
    if (type == MULTIPLE)
      commitMultiple(requestor,false,false);
    else
      commitSingle(requestor,false,false);
    return;
   }

   public void commitAll(ABTUserSession requestor, boolean recall)
   {
    if (type == MULTIPLE)
      commitMultiple(requestor,true,recall);
    else
      commitSingle(requestor,true,recall);
    return;
   }

   public void rollback(ABTUserSession requestor)
   {
    if (type == MULTIPLE)
      rollbackMultiple(requestor,false);
    else
      rollbackSingle(requestor,false);
    return;
   }

   public void rollbackAll(ABTUserSession requestor)
   {
    if (type == MULTIPLE)
      rollbackMultiple(requestor,true);
    else
      rollbackSingle(requestor,true);
    return;  
   }

   private void commitSingle(ABTUserSession requestor,boolean all,boolean recall)
   {
      ABTUserSession lock = getLockHolder();

      if ((lock != null) && (requestor == lock))
      {
         if (current == main)
         {
            lockHolder = null;
            return;
         }
         ABTTransactionData target = current.previous;
         int i = current.getLevel();
         int j = target.getLevel();

         if ((all) || (i == 0))
         {
            lockHolder = null;
            current = current.rollUp(main);
            return;
         }
         else
         {
            if ((i-1) == j)
              current = current.rollUp(target);
            else
            {
              current.setLevel(i-1);
              requestor.addInstance(owner,i-1);
            }
            newLock = true;
         }
      }
      return;


   }
    private void commitMultiple(ABTUserSession session,boolean all,boolean recall)
    {
     current = (ABTTransactionData)lockHolders.get(session);
     if (current == null)
            return;
     else
     {

         ABTTransactionData target = current.previous;
         int i = current.getLevel();
         int j = target.getLevel();

         if ((!(all)) && (i > 0))
         {
           if ((i-1) == j)
             current = current.rollUp(target);
           else
            {
              current.setLevel(i-1);
              session.addInstance(owner,i-1);
            }
            lockHolders.put(session,current);
         }
         else
         {
           current = current.rollUp(main);
           lockHolders.remove(session);
         }
         return;
     }
    }
   }
           
    class ABTTransactionData extends ABTValue
   {
      int currentLevel = -1;
      IABTTransactionData data = null;
      ABTTransactionData previous = null;

      protected ABTTransactionData(IABTTransactionData data_)
      {
         this(null,-1);
         data = data_;
      }

      protected ABTTransactionData(ABTTransactionData parent_, int level_)
      {
         setLevel(level_);
         previous = parent_;
         if (previous != null)
            copyData(previous);
      }

      protected IABTTransactionData getData()
      {
         return data;
      }


      protected int getLevel()
      {
         return currentLevel;
      }
      protected void setLevel(int level_)
      {
         currentLevel = level_;
      }

      ABTTransactionData rollUp(ABTTransactionData target)
      {
        target.data = data.rollUp(target.data);
        return target;
      }

      void copyData(ABTTransactionData source)
      {
        data = source.data.copyData();
      }




   }




