package  com.abtcorp.objectModel.abt.fr;

/*
 * DisallowReset.java 08/05/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */

/*
 * HISTORY:
 *
 * Date           Author        Description
 * 09-22-98       SOB           Initial Design
 *
 */

import   java.util.*;

import   com.abtcorp.objectModel.*;
import   com.abtcorp.hub.*;
import   com.abtcorp.core.*;

/**
 * This field rule will prohibit a field from being reset.
 *
 * @version	1.0
 * @author  L. Xiao
 */

public class DisallowNullOrZero extends SiteFieldRule
{

   /**
    * Validates the value that is being set into the parent object container.
    * Returns an ABTError if the value is null or, for strings, all blank.
    *
    * @param session    - Session object for transaction support
    * @param parent     - The container object for this field property
    * @param property   - The property object
    * @param myValue    - The value currently available i.e. the ABTObject at this position
    * @param newValue   - The new value, i.e. the ABTObject to be placed instead
    * @param parameters - List of parameters and (field/app specific)
    *
    * @return ABTValue - ABTValue if successful, ABTError if not
    */
   protected ABTValue onSet( ABTUserSession session, ABTObject parent, ABTProperty property, ABTValue myValue, ABTValue newValue, ABTHashtable parameters )
   {
      String propName = property.getName();
      //String module   = propName + "->onSet";
      //String msg      = "Operation Disallowed";
      String info     = propName + " cannot be null, empty, blank, or zero";
      
      // if new value is null or empty, return an error.
      if( ABTValue.isNull( newValue ) )
         return new ABTError( "DisallowNullOrZero", 
                              "onSet",
                              errorMessages.ERR_INVALID_VALUE,
                              info );
      
      //
      // If the new value is a string of zero length (or all blanks),
      // reject it.  Otherwise, if it's a number and is zero, reject it.
      //
      if ( newValue instanceof ABTString )
      {
         String s = newValue.stringValue().trim();
         if (s.length() == 0)
            return new ABTError( "DisallowNullOrZero", 
                              "onSet",
                              errorMessages.ERR_INVALID_VALUE,
                              info );
      }
      else if ( (newValue instanceof ABTInteger ||
                newValue instanceof ABTShort ) &&
                newValue.intValue() == 0 )
     {
         return new ABTError( "DisallowNullOrZero", 
                              "onSet",
                              errorMessages.ERR_INVALID_VALUE,
                              info );
     }
     else if ( (newValue instanceof ABTDouble) &&
               newValue.doubleValue() == 0.0 )
     {
         return new ABTError( "DisallowNullOrZero", 
                              "onSet",
                              errorMessages.ERR_INVALID_VALUE,
                              info );
     }
      
      // every thing seems OK.
      
      return write( session, parent, property, myValue, newValue, false );
   }
}
