package test.repository;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;

public class TestSession implements Runnable, ABTNames
{
   public TestSession() {}

   public void run()
   {
      ABTSession session = ABTSession.login();

      System.out.println("session="     + session);
      System.out.println("id="          + session.getID());
      System.out.println("local="       + session.isLocal());
      System.out.println("prompt="      + session.getPrompt());
      System.out.println("user="        + session.getUserName());
      System.out.println("userID="      + session.getUserID());
      System.out.println("workstation=" + session.getWorkstation());
//    System.out.println("system="      + session.getSystem());
      System.out.println("time="        + session.getCurrentTime());
//    System.out.println("license="     + session.openLicense(null));
      
      ABTRepository repository = session.connect("?");      
      
      System.out.println("repository="  + repository);
      System.out.println("id="          + repository.getID());
      System.out.println("name="        + repository.getName());
      System.out.println("sql="         + repository.sqlString("test"));
      System.out.println("counter="     + repository.counter("test"));
      System.out.println("execute="     + repository.execute("select * from PRSite"));

      ABTCursor cursor = repository.select(TBL_PROJECT);

      System.out.println("cursor="      + cursor);

      System.out.println("table="       + cursor.getTableName());
      System.out.println("valid="       + cursor.isValid());
      System.out.println("count="       + cursor.getRecordCount());
      System.out.println("current="     + cursor.getCurrentRecord());
      System.out.println("time="        + cursor.getCursorTime());
      System.out.println("filter="      + cursor.getFilter());
      System.out.println("sort="        + cursor.getSort());
      
      cursor.moveFirst();
      
      System.out.println("name="  + cursor.getField(FLD_NAME));
      System.out.println("start=" + cursor.getField(FLD_START));
      System.out.println("finish=" + cursor.getField(FLD_FINISH));

      cursor.release();
      repository.release();
      session.release();
   }

   public static void main(String argv[])
   {
//    System.runFinalizersOnExit(true);

      try {
         TestSession test = new TestSession();

         test.run();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}