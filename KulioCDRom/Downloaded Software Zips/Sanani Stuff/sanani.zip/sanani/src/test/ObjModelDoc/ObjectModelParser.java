
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.api.local.*;
import java.io.*;

public class ObjectModelParser
{
    private IABTSortedArray list1;
    private IABTHashTable hash1;
    private IABTObjectSpace Os;

    public ObjectModelParser() {
        super();
        }


    public void parse(String objname){
      Os =  new ABTObjectSpaceLocal();
      Os.startSession(null);

      try {


        // initialize and clear the name list
      list1 = Os.newABTSortedArray();
      hash1 = Os.newABTHashTable();

      IABTPropertySet props;
      String FileName;
      FileName = "d:\\sanani\\doc\\" + objname + " Object_Model.html"  ;
      FileWriter out = new FileWriter(FileName);

      // make a cover sheet
      out.write("<a name=\"top()\"></a>");
      out.write("<BR>");
      out.write("<BR>");
      out.write("<BR>");
      out.write("<BR>");
      out.write("<HR><BR><CENTER>");
      out.write("<FONT SIZE=4><B> Sanani Object Model: </FONT><BR>");

      out.write("<FONT SIZE=8>" + objname + "</FONT><BR></B>");
      java.util.Date today = new java.util.Date(System.currentTimeMillis());
      out.write("<FONT SIZE=2>" + today.toString() + "</FONT><BR>");
      out.write("<HR><BR></CENTER>");

      // make a list of top-level rule objects
      listObjectProperties (objname);
      // go through the list and make a sorted array
      IABTEnumerator en = hash1.getKeys();
      while (en.hasMoreElements()){
         ABTString val = (ABTString)en.nextElement();
         list1.add(val);
         }


      // go through the list and make a table of contents
      java.util.Enumeration enu;
      enu = list1.getElements();
      while (enu.hasMoreElements()){
         ABTString rulename = (ABTString)enu.nextElement();
         out.write("<a href= #"+ rulename + "()>Object Rule :  " + rulename.stringValue() + "</a><BR>");
         }

      // go through the list and show properties for each object
      enu = list1.getElements();
      while (enu.hasMoreElements()){
         ABTString rulename = (ABTString)enu.nextElement();
         ShowObjectProperties (rulename.stringValue(), out);
         }

      out.close();
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
         }
      Os.endSession();
      }

// this function recursively lists object references by name, filtering out duplicates
private void listObjectProperties(String objname){
    hash1.putItemByString (objname,new ABTString(objname));
    IABTPropertySet props = Os.getProperties(objname);
    IABTProperty prop;
    IABTEnumerator en = props.getElements();
    while (en.hasMoreElements()){
      prop = (IABTProperty)en.nextValue();
      int ptype = prop.getType();
      if (ptype == IABTPropertyType.PROP_OBJECT || ptype == IABTPropertyType.PROP_OBJECTSET){
          String rulename = prop.getReferenceType();
          if (false == hash1.containsKey(new ABTString(rulename))){
             hash1.putItemByString(rulename,new ABTString(rulename));
             listObjectProperties(rulename);
             }
         }
      }
}

private void ShowObjectProperties(String objname, FileWriter out) throws IOException
   {
    IABTPropertySet props = Os.getProperties(objname);

    out.write("<a name=\""+objname + "()\"></a>");
    out.write("<a href=#top()> top </a><BR>");
    out.write("<FONT SIZE=5><B>" + objname + "</b></FONT>");
    out.write("<DIR>");

    IABTProperty prop;

    prop = props.getPropertybyIndex(0);
    String objRule = prop.getRuleName();
    if (!objRule.startsWith("com.abtcorp.hub"))
       objRule =Os.getRulebase()+ "."+objRule;
    out.write("Object rule: " + "<a href= api\\"+objRule+".html>"+objRule + "</a><BR>");

    out.write("<FONT SIZE=4><I><B>Object Reference Properties</b></I></FONT><DIR>");
    IABTEnumerator penum = props.getElements();
      while (penum.hasMoreElements()){
         prop = (IABTProperty)penum.nextValue();
         int ptype = prop.getType();
         if (ptype == IABTPropertyType.PROP_OBJECT || ptype == IABTPropertyType.PROP_OBJECTSET){
            if (prop.getCaption().length() > 0){
                out.write("<FONT SIZE=2 COLOR=green> ");
                out.write(prop.getCaption() + "<BR>");
                out.write("</FONT>");
            }

            out.write("<B><FONT SIZE=0><a href= #" + objname + "()>" + objname + "</a></FONT> : " + prop.getName() + "</B> :");
            if (ptype == IABTPropertyType.PROP_OBJECTSET)
                out.write(" set of ");
            else
                out.write(" object reference to: ");

            out.write("<a href= #" + prop.getReferenceType() + "()>" + prop.getReferenceType() + "</a>");
            out.write("<FONT SIZE=0><BR>");

            String fieldRule = prop.getFieldRuleName();
            if (!fieldRule.startsWith("com.abtcorp.hub"))
               fieldRule =Os.getRulebase()+ "."+fieldRule;
            out.write("Field rule: " + "<a href= api\\"+fieldRule+".html>"+fieldRule + "</a><BR>");
//            out.write("Field rule: " + prop.getFieldRuleName()+  "<BR>");
            displayExtendedProperties(prop,out);
            out.write("</FONT>");
            out.write("<BR>");
            out.write("<BR>");
         }
      }

    out.write("</DIR>");
    out.write("<FONT SIZE=4><I><B>Scalar properties</b></I></FONT><DIR>");
    penum = props.getElements();
    while (penum.hasMoreElements()){
        prop = (IABTProperty)penum.nextValue();
        int ptype = prop.getType();
        if (ptype != IABTPropertyType.PROP_OBJECT || ptype != IABTPropertyType.PROP_OBJECTSET){
            if (prop.getCaption().length() > 0){
                out.write("<FONT SIZE=2 COLOR=green> ");
                out.write(prop.getCaption() + "<BR>");
                out.write("</FONT>");
            }
            out.write("<B><FONT SIZE=0><a href= #" + objname + "()>" + objname + "</a></FONT> : " + prop.getName() + "</B> :");
            out.write(GetPropType(ptype));
            out.write("<FONT SIZE=0><BR>");
            String fieldRule = prop.getFieldRuleName();
            if (!fieldRule.startsWith("com.abtcorp.hub"))
               fieldRule =Os.getRulebase()+ "."+fieldRule;
            out.write("Field rule: " + "<a href= api\\"+fieldRule+".html>"+fieldRule + "</a><BR>");
            displayExtendedProperties (prop, out);
            out.write("</FONT>");
            out.write("<BR>");
            out.write("<BR>");
        }
    }
    out.write("</DIR>");
    out.write("</DIR>");
}

private void displayExtendedProperties(IABTProperty prop, FileWriter out) throws IOException
   {
    IABTHashTable epl = prop.getExtendedProperties();
    IABTEnumerator enm = epl.getKeys();
    while ( enm.hasMoreElements() ){
        ABTValue key;
        ABTValue val;
        String nm;
        key = enm.nextValue();
        val = epl.getItemByInt(key.intValue());
        if (val != null)
           nm = val.toString();
        else
           nm = "[null]";
        out.write("      " + getExtendedType(key.intValue()) + " = " + nm + "<BR>");
    }
}

private String getExtendedType(int key){
   String retVal = "toot";
   switch( key) {
        case IABTPropertyType.PROP_EXTTYPE_DATE:
            return "PROP_EXTTYPE_DATE"  ;
        case IABTPropertyType.PROP_EXTTYPE_MEMO:
            return"PROP_EXTTYPE_MEMO" ;
        case IABTPropertyType.PROP_EXTTYPE_MONEY:
            return"PROP_EXTTYPE_MONEY" ;
        case IABTPropertyType.PROP_EXTTYPE_PERCENT:
            return"PROP_EXTTYPE_PERCENT"  ;
        case IABTPropertyType.PROP_EXTTYPE_PM:
            return"PROP_EXTTYPE_PM"   ;
        case IABTPropertyType.PROP_EXTTYPE_RESAVAILUNIT:
            return"PROP_EXTTYPE_RESAVAILUNIT" ;
        case IABTPropertyType.PROP_EXTTYPE_RESUNIT:
            return"PROP_EXTTYPE_RESUNIT"   ;
        case IABTPropertyType.PROP_KAPPLICATIONSPECIFIC:
            return"PROP_KAPPLICATIONSPECIFIC" ;
        case IABTPropertyType.PROP_KDEFAULTVALUE:
            return"PROP_KDEFAULTVALUE"   ;
        case IABTPropertyType.PROP_KMAX:
            return"PROP_KMAX"     ;
        case IABTPropertyType.PROP_KMIN:
            return"PROP_KMIN"          ;
        case IABTPropertyType.PROP_KPOSSIBLEVALUES:
            return"PROP_KPOSSIBLEVALUES" ;
        case IABTPropertyType.PROP_KTRANSIENT:
            return"PROP_KTRANSIENT"  ;
        case IABTPropertyType.PROP_KUPDATABLE:
            return"PROP_KUPDATABLE";
        case IABTPropertyType.PROP_KVIRTUAL:
            return"PROP_KVIRTUAL"         ;
        case IABTPropertyType.PROP_KVISIBLE:
            return"PROP_KVISIBLE";
       }
    return "Unknown";
}

private String GetPropType(int ptype){
    switch(ptype) {
        case IABTPropertyType.PROP_BLOB:
            return"PROP_BLOB"  ;
        case IABTPropertyType.PROP_BOOLEAN:
            return"PROP_BOOLEAN" ;
        case IABTPropertyType.PROP_DATE:
            return"PROP_DATE"    ;
        case IABTPropertyType.PROP_DOUBLE:
            return"PROP_DOUBLE"  ;
        case IABTPropertyType.PROP_INT:
            return"PROP_INT"    ;
        case IABTPropertyType.PROP_LONG:
            return"PROP_LONG"   ;
        case IABTPropertyType.PROP_OBJECT:
            return"PROP_OBJECT"  ;
        case IABTPropertyType.PROP_OBJECTSET:
            return"PROP_OBJECTSET"  ;
        case IABTPropertyType.PROP_SHORT:
            return"PROP_SHORT"  ;
        case IABTPropertyType.PROP_STRING:
            return"PROP_STRING" ;
        case IABTPropertyType.PROP_TIME:
            return"PROP_TIME"  ;
        case IABTPropertyType.PROP_TIMESTAMP:
            return"PROP_TIMESTAMP" ;
        case IABTPropertyType.PROP_UNKNOWN:
            return"PROP_UNKNOWN"  ;
        case IABTPropertyType.PROP_ARRAY:
            return"PROP_ARRAY"   ;
        case IABTPropertyType.PROP_HASH:
            return"PROP_HASH"   ;
        case IABTPropertyType.PROP_ID:
            return"PROP_ID"    ;
    }
    return "Unknown";
   }

}