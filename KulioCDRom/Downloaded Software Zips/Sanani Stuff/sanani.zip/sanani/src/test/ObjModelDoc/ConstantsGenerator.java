
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.api.local.*;
import java.io.*;

public class ConstantsGenerator
{
    private IABTSortedArray list1;
    private IABTHashTable hash1;
    private IABTObjectSpace Os;

    public ConstantsGenerator() {
        super();
        }


    public void parse(String objname){
      Os =  new ABTObjectSpaceLocal();
      Os.startSession(null);

      try {

      int x = IPossibleValues_pm.pm_Assignment.BasePattern_CONTOUR;
      
        // initialize and clear the name list
      list1 = Os.newABTSortedArray();
      hash1 = Os.newABTHashTable();

      IABTPropertySet props;
      String FileName;
      String packageName = objname.substring(0,objname.indexOf('.'));

      FileName = "d:\\sanani\\src\\com\\abtcorp\\idl\\IPossibleValues_" + packageName + ".java"  ;
      FileWriter out = new FileWriter(FileName);

      // make a cover sheet
      out.write("package com.abtcorp.idl;\r");
      out.write("\r");
      out.write("\r");
      out.write("\r");
      out.write("public interface IPossibleValues_"+packageName+" {");
      out.write("\r");


      // make a list of top-level rule objects
      listObjectProperties (objname);
      // go through the list and make a sorted array
      IABTEnumerator en = hash1.getKeys();
      while (en.hasMoreElements()){
         ABTString val = (ABTString)en.nextElement();
         list1.add(val);
         }

      java.util.Enumeration enu;
      // go through the list and show properties for each object
      enu = list1.getElements();
      while (enu.hasMoreElements()){
         ABTString rulename = (ABTString)enu.nextElement();
         if (rulename.toString().startsWith(packageName))
            ShowObjectProperties (rulename.stringValue(), out);
         }
      out.write("}\r");
      out.close();
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
         }
      Os.endSession();
      }

// this function recursively lists object references by name, filtering out duplicates
private void listObjectProperties(String objname){
    hash1.putItemByString (objname,new ABTString(objname));
    IABTPropertySet props = Os.getProperties(objname);
    IABTProperty prop;
    IABTEnumerator en = props.getElements();
    while (en.hasMoreElements()){
      prop = (IABTProperty)en.nextValue();
      int ptype = prop.getType();
      if (ptype == IABTPropertyType.PROP_OBJECT || ptype == IABTPropertyType.PROP_OBJECTSET){
          String rulename = prop.getReferenceType();
          if (false == hash1.containsKey(new ABTString(rulename))){
             hash1.putItemByString(rulename,new ABTString(rulename));
             listObjectProperties(rulename);
             }
         }
      }
}

private void ShowObjectProperties(String objname, FileWriter out) throws IOException
   {
    IABTPropertySet props = Os.getProperties(objname);

    IABTProperty prop;
    prop = props.getPropertybyIndex(0);
    IABTEnumerator penum = props.getElements();
    boolean firstTime = true;
    while (penum.hasMoreElements()){
        prop = (IABTProperty)penum.nextValue();
        int ptype = prop.getType();
        if (ptype == IABTPropertyType.PROP_INT || ptype == IABTPropertyType.PROP_SHORT){
            if (firstTime == true){
               out.write("\r   public interface "+strip(objname)+"{\r");
//               out.write("\r   //Constants for object "+objname+"\r");
               }
            firstTime = false;
            displayExtendedProperties (prop, out);
           }
       }
     if (firstTime == false)
        out.write("   }\r");
   }

private void displayExtendedProperties(IABTProperty prop, FileWriter out) throws IOException
   {
    IABTHashTable epl = prop.getExtendedProperties();
    ABTValue posVals = epl.getItemByInt(IABTPropertyType.PROP_KPOSSIBLEVALUES);
    if (posVals instanceof IABTHashTable){
       IABTHashTable values = (IABTHashTable)posVals;
       IABTEnumerator enm = values.getKeys();
       while ( enm.hasMoreElements() ){
           ABTValue key;
           ABTValue val;
           String nm;
           key = enm.nextValue();
           val = values.getItemByInt(key.intValue());
           if (val != null){
              nm = val.toString();
              // strip the bad characters out of the constant name
              nm = strip(nm.toUpperCase());
              String constName = strip(prop.getName()+"_"+nm);
              out.write("         public static final int "+constName+" = " + key + ";\r");
              }
       }
    }

}

private String strip(String caption){
   String outPut = caption;
   for (int I = 0; I < outPut.length();++I){
      String badChars = " !@#$%^&*()-=`~+||\"':;?/>.<,";
      char c = outPut.charAt(I);
      if (c == ' '){
         char x = 'x';
         }
      if (badChars.lastIndexOf(c) >= 0)
         outPut = outPut.replace(c,'_');
      }
   return outPut;
   }

}
