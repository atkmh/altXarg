
//Title:        Your Product Name
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Steve Pierson
//Company:      ABT Corporation
//Description:  Your description

package SpaceView;

import java.awt.*;
import com.sun.java.swing.*;
//import borland.jbcl.layout.*;
import com.sun.java.swing.table.*;
import java.util.Hashtable;
import java.util.Vector;
import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;
import com.abtcorp.core.*;

import java.awt.event.*;

public class HashTableForm extends JDialog implements IABTDriverConstants{

   private class hashEntry {
         private String xKey = "a Key" ;
         private String xValue = "this is stuff";
         public hashEntry(String key, String type, String value){
            xKey = key;
            xValue = value;
           }
         public String getKey(){return xKey;}
         public String getValue(){return xValue;}
         public void putKey(String val){xKey = val;}
         public void putValue(String val){xValue = val;}
         }

   private JTable HashTable;
   private IABTHashTable ht;
   private dataModel dModel;

   public HashTableForm()
      { this(null, "", false); }

   public HashTableForm(Frame frame, String title, boolean modal) {
      super(frame, title, modal);
      try  {
         jbInit();
         pack();
      }
      catch (Exception ex) {
         ex.printStackTrace();
      }
   }

   public IABTHashTable getHashTable(){
      return ht;
      }

   JPanel panel1 = new JPanel();
   JToolBar jToolBar1 = new JToolBar();
   JButton jButton1 = new JButton("Ok");
   JButton jButton2 = new JButton("Cancel");
   JButton jButton3 = new JButton("Clear");
   BorderLayout borderLayout1 = new BorderLayout();

   private class dataModel extends AbstractTableModel
   {
      protected Vector values;

      public dataModel(){
         super();
         values = new Vector(15);
         }

      public void clear(){
         values.removeAllElements();
         }
      public Object getValueAt(int aRow, int aColumn){
         if (aRow < 0 || aRow >= values.size()) return null;
         hashEntry h = (hashEntry)values.elementAt(aRow);
         switch (aColumn){
            case 0:
               return h.getKey();
            case 1:
               return h.getValue();
            default:
               return null;
            }
        }


       public void setValueAt(Object aValue, int aRow, int aColumn){
         if (aRow < 0) return;
         hashEntry h;
         if (aRow >= values.size()) {
            h = new hashEntry("","ABTString","");
            values.addElement(h);
            }
         else
            h = (hashEntry)values.elementAt(aRow);
        switch (aColumn){
         case 0:
            h.putKey(aValue.toString());
            break;
         case 1:
            h.putValue(aValue.toString());
            break;
            }
         }

       public int getRowCount() {  return 10;  }
       public int getColumnCount() { return 2; }
       public String getColumnName(int aColumn) {
          return new Integer(aColumn).toString();
       }
       public boolean isCellEditable(int row, int column) {return true;  }

   };

   void jbInit() throws Exception {
      this.setModal(true);
      this.setResizable(false);

      panel1.setLayout(borderLayout1);
      panel1.add(jToolBar1, BorderLayout.SOUTH);

      jButton2.setText("jButton2");
      jButton2.setLabel("Cancel");

      jToolBar1.setMaximumSize(new Dimension(500, 27));
      jToolBar1.add(jButton1, null);
      jToolBar1.add(jButton2, null);
      jToolBar1.add(jButton3, null);

//      jButton1.setText("jButton1");
//      jButton1.setLabel("Ok");
      jButton1.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            jButton1_actionPerformed(e);
         }
      });


      jButton3.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            dModel.clear();
            panel1.repaint();
         }
      });
      dModel = new dataModel();
      HashTable = new JTable(dModel);
      HashTable.addFocusListener(new java.awt.event.FocusAdapter() {
         public void focusLost(FocusEvent e) {
            table_focusLost(e);
         }
      });
      HashTable.setRowHeight(22);
      panel1.add(new JScrollPane(HashTable), BorderLayout.NORTH);

      getContentPane().add(panel1);

      TableColumn col0 = HashTable.getColumn("0");
   	JComboBox keyCombo = new JComboBox();
      //keyCombo.setEditable(true);

    	keyCombo.addItem(KEY_REPONAME);
 	   keyCombo.addItem(KEY_USERNAME);
    	keyCombo.addItem(KEY_PASSWORD);
 	   keyCombo.addItem(KEY_PRODUCT);
    	keyCombo.addItem(KEY_TYPE);
 	   keyCombo.addItem(KEY_SUBTYPE);
    	keyCombo.addItem(KEY_EXTID);
 	   keyCombo.addItem(KEY_EXTIDS);
    	keyCombo.addItem(KEY_SOURCE);
 	   keyCombo.addItem(KEY_SOURCENAME);
    	keyCombo.addItem(KEY_DESTINATIONNAME);
 	   keyCombo.addItem(KEY_COMMAND);
    	keyCombo.addItem(KEY_LOCK);
 	   keyCombo.addItem(KEY_LOCKTYPE);
    	keyCombo.addItem(KEY_UNLOCK);
 	   keyCombo.addItem(KEY_FORCE);
    	keyCombo.addItem(KEY_SITE);
 	   keyCombo.addItem(KEY_PROGRESS);
   	keyCombo.addItem(KEY_FILENAME);
      keyCombo.addItem(TYPE_REPOSITORY);
      keyCombo.addItem(TYPE_PROJECT);
      keyCombo.addItem(TYPE_METHOD);
      keyCombo.addItem(TYPE_SITE);
      keyCombo.addItem(TYPE_ALL);
      keyCombo.addItem(TYPE_RESOURCE);
      keyCombo.addItem(TYPE_ESTMODEL);
      keyCombo.addItem(TYPE_CUSTOMFIELD);
      keyCombo.addItem(TYPE_ADJRULE);
      keyCombo.addItem(TYPE_CALENDAR);
      keyCombo.addItem(TYPE_TIMEPERIOD);
      keyCombo.addItem(SUBTYPE_FULL);
 	   keyCombo.addItem(SUBTYPE_PROJECTONLY);
    	keyCombo.addItem(SUBTYPE_PROJECTANDTASKSONLY);
 	   keyCombo.addItem(SUBTYPE_SAVEAS);
    	keyCombo.addItem(SUBTYPE_REFRESH);
      keyCombo.addItem(CMD_LIST);
      keyCombo.addItem(CMD_UNLOCK);
      col0.setCellEditor(new DefaultCellEditor(keyCombo));
      HashTable.getColumn("0").setWidth(150);
      HashTable.getColumn("1").setWidth(150);
   }

   void jButton1_actionPerformed(ActionEvent e) {
      CellEditor ed = HashTable.getCellEditor();
      if (ed != null)
         ed.stopCellEditing();
      if (HashTable.getRowCount() <= 0){
         ht = null;
         return;
         }
      else
         ht = new ABTHashTable();

      for (int i = 0; i < HashTable.getRowCount(); ++i){
         String key = (String)HashTable.getValueAt(i,0);
         String Value = (String)HashTable.getValueAt(i,1);
         ht.putItemByString(key,new ABTString(Value));
         }
      System.out.println(ht.toString());
      hide();
   }

   void table_focusLost(FocusEvent e) {
      CellEditor ed = HashTable.getCellEditor();
      if (ed != null)
         ed.stopCellEditing();
   }
}


