
//Title:        Your Product Name
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Steve Pierson
//Company:      ABT Corporation
//Description:  Your description

package SpaceView;

import java.awt.*;
import com.sun.java.swing.*;

public class ObjectViewer extends JDialog {
   JPanel panel1 = new JPanel();
   BorderLayout borderLayout1 = new BorderLayout();
   JSplitPane jSplitPane1 = new JSplitPane();

   
   public ObjectViewer(Frame frame, String title, boolean modal) {
      super(frame, title, modal);
      try  {
         jbInit();
         pack();
      }
      catch (Exception ex) {
         ex.printStackTrace();
      }
   }

   
   public ObjectViewer() {
      this(null, "", false);
   }

   void jbInit() throws Exception {
      panel1.setLayout(borderLayout1);
      getContentPane().add(panel1);
      panel1.add(jSplitPane1, BorderLayout.CENTER);
   }
}

