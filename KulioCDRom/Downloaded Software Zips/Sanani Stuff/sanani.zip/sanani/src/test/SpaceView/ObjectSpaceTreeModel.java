

package SpaceView;

import com.sun.java.swing.tree.*;
import com.sun.java.swing.event.*;
import com.abtcorp.idl.*;

import com.abtcorp.api.local.*;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;

public class ObjectSpaceTreeModel extends  DefaultTreeModel {

   IABTObjectSpace Os;
   int rootChildCount = 1;

   public ObjectSpaceTreeModel(IABTObjectSpace Os_) {
      super(new ObjectSpaceTreeNode("Object Space"));
      Os = Os_;
   }



    /**
     * Returns the child of <I>parent</I> at index <I>index</I> in the parent's
     * child array.  <I>parent</I> must be a node previously obtained from
     * this data source.
     *
     * @param   parent  a node in the tree, obtained from this data source
     * @return  the child of <I>parent</I> at index <I>index</I>
     */
    public Object xxxgetChild(Object parent, int index){
      return null;
    }


    /**
     * Returns the number of children of <I>parent</I>.  Returns 0 if the node
     * is a leaf or if it has no children.  <I>parent</I> must be a node
     * previously obtained from this data source.
     *
     * @param   parent  a node in the tree, obtained from this data source
     * @return  the number of children of the node <I>parent</I>
     */
    public int getChildCount(Object parent){
      ObjectSpaceTreeNode node = (ObjectSpaceTreeNode)parent;
      if (!node.getHasLoadedChildren()){
         loadChildren(node);
         }
      return node.getChildCount();
    }


    /* dynamic loading of child nodes happens here */
    protected void loadChildren( ObjectSpaceTreeNode inParent) {
      ABTValue nodeObj = inParent.getObject();
      if (nodeObj instanceof IABTObject){
         IABTObject theObj = (IABTObject)nodeObj;
         IABTPropertySet props = theObj.getProperties();
         IABTEnumerator en = props.getElements();
         while (en.hasMoreElements()){
            IABTProperty prop = (IABTProperty)en.nextElement();
            ABTValue val;
            val = theObj.getValue(prop.getName());
            String pName = prop.getName();
            switch (prop.getType()){
               case IABTPropertyType.PROP_OBJECT:
                  if (val instanceof IABTObject)
                     inParent.add(new ObjectSpaceTreeNode(pName, (IABTObject)val));
                  break;
               case IABTPropertyType.PROP_OBJECTSET:
                  if (val instanceof IABTObjectSet)
                     inParent.add(new ObjectSpaceTreeNode(pName,(IABTObjectSet)val));
                  break;
               default:
                  if (val instanceof ABTValue)
                     inParent.add(new ObjectSpaceTreeNode(pName + " = "+val.stringValue()));
                  break;
               }
            }
         }
      else if (nodeObj instanceof IABTObjectSet){
         IABTObjectSet theSet = (IABTObjectSet)nodeObj;
         IABTEnumerator en = theSet.getElements();
         int count = theSet.size();
         while (en.hasMoreElements()){
            IABTObject element = (IABTObject)en.nextElement();
            inParent.add(new ObjectSpaceTreeNode(element.getValue("Name").stringValue(),element));
            }
         }

      inParent.setHasLoadedChildren(true);
    }

    /**
     * Returns true if <I>node</I> is a leaf.  It is possible for this method
     * to return false even if <I>node</I> has no children.  A directory in a
     * filesystem, for example, may contain no files; the node representing
     * the directory is not a leaf, but it also has no children.
     *
     * @param   node    a node in the tree, obtained from this data source
     * @return  true if <I>node</I> is a leaf
     */
    public boolean isLeaf(Object node){
      ObjectSpaceTreeNode tn = (ObjectSpaceTreeNode)node;

      return tn.isLeaf();
    }

    /**
      * Messaged when the user has altered the value for the item identified
      * by <I>path</I> to <I>newValue</I>.  If <I>newValue</I> signifies
      * a truly new value the model should post a treeNodesChanged
      * event.
      *
      * @param path path to the node that the user has altered.
      * @param newValue the new value from the TreeCellEditor.
      */
    public void xxxvalueForPathChanged(TreePath path, Object newValue){
    }

    /**
     * Returns the index of child in parent.
     */
    public int xxxgetIndexOfChild(Object parent, Object child){
      return 1;
    }


}