package SpaceView;

class hashEntry {
         private String xKey = "a Key" ;
         private String xValue = "this is stuff";
         public hashEntry(String key, String type, String value){
            xKey = key;
            xValue = value;
           }
         public String getKey(){return xKey;}
         public String getValue(){return xValue;}
         public void putKey(String val){xKey = val;}
         public void putValue(String val){xValue = val;}
         }

