

package SpaceView;

import com.sun.java.swing.tree.*;
import com.abtcorp.core.*;
import com.abtcorp.idl.*;

public class ObjectSpaceTreeNode extends DefaultMutableTreeNode {

   private boolean hasLoadedChildren = false;
   private ABTValue obj = null;

   public ObjectSpaceTreeNode(ABTValue obj_) {
      super(obj_.stringValue());
      obj = obj_;
   }

   public ObjectSpaceTreeNode(String name, IABTObject obj_) {
      super(name);
      obj = (ABTValue)obj_;
   }

   public ObjectSpaceTreeNode(String name, IABTObjectSet obj_) {
      super(name);
      obj = (ABTValue)obj_;
   }

   public ObjectSpaceTreeNode(String name) {
      super(name);
   }

   public int getChildCount(){
      if (isLeaf()) return 0;
      return super.getChildCount();
   }

   public boolean isLeaf(){
      if (obj == null) return false;
      if (obj instanceof IABTObject) return false;
      if (obj instanceof IABTObjectSet) return false;
      return true;
   }

   public ABTValue getObject(){
      return obj;
   }

    public void setHasLoadedChildren(boolean well){ hasLoadedChildren = well; }
    public boolean getHasLoadedChildren(){ return hasLoadedChildren;}
}
