package SpaceView;

import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.abtcorp.api.local.*;
import java.io.*;

public class ObjectModelParser
{
    private ABTSortedArray list1;
    private IABTObjectSpace Os;

    public ObjectModelParser() {
      }


    public static void parse(IABTObject obj, IABTHashTable ht){
      parseByName(obj.getObjectSpace(), obj.getObjectType(), ht);
      }

    public static void parseByName(IABTObjectSpace Os, String ruleName, IABTHashTable ht){
      try {
      // make a list of top-level rule objects
      //if (ht.containsKey(new ABTString(ruleName)))return;
      System.out.println("Parsing: "+ruleName);

      IABTArray roots = new ABTArrayLocal();
      roots.setObjectSpace(Os);
      ht.putItemByString (ruleName,(ABTValue)roots);
      IABTPropertySet props = Os.getProperties(ruleName);
      IABTProperty prop;
      IABTEnumerator en = props.getElements();
      while (en.hasMoreElements()){
         prop = (IABTProperty)en.nextValue();
         int ptype = prop.getType();
         if (ptype == IABTPropertyType.PROP_OBJECT || ptype == IABTPropertyType.PROP_OBJECTSET){
            String propRuleName = prop.getReferenceType();
            if (!ht.containsKey(new ABTString(propRuleName))){
               IABTArray them = new ABTArrayLocal();
               them.setObjectSpace(Os);
               ht.putItemByString(propRuleName,(ABTValue)them);
               parseByName(Os, propRuleName, ht);
               }
            }
         }
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
         }
      }
}
