package SpaceView;

import java.awt.*;
import java.awt.event.*;
import com.sun.java.swing.*;
import com.sun.java.swing.tree.*;

import com.abtcorp.core.*;
import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;

import java.util.ListResourceBundle;


public class ViewerFrame extends JFrame implements IABTDriverConstants{

   private IABTHashTable myHashTable;
   JLabel hashView = new JLabel("HashTable contents:");
   //Construct the frame
   BorderLayout borderLayout1 = new BorderLayout();
   JMenuBar menuBar1 = new JMenuBar();
   JMenu menuFile = new JMenu();
   JMenuItem menuFileExit = new JMenuItem();
   JMenu menuHelp = new JMenu();
   JMenuItem menuHelpAbout = new JMenuItem();
   JToolBar toolBar = new JToolBar();
   JButton PopulateButton;// = new JButton();
   JButton SaveButton = new JButton();
   JButton HashButton = new JButton();
   ImageIcon image1;
   ImageIcon image2;
   ImageIcon image3;
   JSplitPane jSplitPane1 = new JSplitPane();
   JComboBox DriverName = new JComboBox();

   IABTObjectSpace Os;

   public ViewerFrame() {
      enableEvents(AWTEvent.WINDOW_EVENT_MASK);
      try  {
         jbInit();
         myHashTable = new ABTHashTable();
         SaveButton.setIcon(image2);
         HashButton.setIcon(image3);
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }
//Component initialization

   private void jbInit() throws Exception  {
      image1 = new ImageIcon(getClass().getResource("openFile.gif"));
      image2 = new ImageIcon(getClass().getResource("closeFile.gif"));
      image3 = new ImageIcon(getClass().getResource("help.gif"));
      this.getContentPane().setLayout(borderLayout1);
      this.setSize(new Dimension(675, 559));
      this.setTitle("Big Viewer");
      menuFile.setText("File");
      menuFileExit.setText("Exit");

      PopulateButton = new JButton();
      PopulateButton.setIcon(image1);
      PopulateButton.setText("Populate");
      PopulateButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) { doPopulate(); }
      });


      HashButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            System.out.println("stuff");
            //Populate_actionPerformed(e);
            HashTableForm htf = new HashTableForm();
            htf.show(true);
            myHashTable = htf.getHashTable();
            hashView.setText("Hashtable contents: "+myHashTable.toString());
         }
      });

      menuFileExit.addActionListener(new ActionListener()  {
         public void actionPerformed(ActionEvent e) {
            System.exit(0);
            //fileExit_actionPerformed(e);
         }
      });


      SaveButton.setLabel("Save");
      SaveButton.setToolTipText("Close File");
      HashButton.setText("Set HashTable");
      HashButton.setToolTipText("Help");

      Os = new ABTObjectSpaceLocal();
      Os.startSession(null);
      // Populate site object
      ABTHashTable args = new ABTHashTable();
      IABTDriver siteDriver = new ABTDriverLocal();
      siteDriver.initialize(Os,"com.abtcorp.io.siterepo.ABTSiteRepoDriver",null);

      args.putItemByString ("UserName", new ABTString("admin"));
      args.putItemByString ("Password", new ABTString("administrator"));
      args.putItemByString ("Product", new ABTString("ABT Workbench"));
      siteDriver.open (Os, args);

      args.clear();
      args.putItemByString ("Type", new ABTString("All"));
      args.putItemByString ("RepositoryName", new ABTString("ABTRepository"));
      args.putItemByString ("Product", new ABTString("ABT Workbench"));
      ABTValue val = siteDriver.populate (Os, args);
      IABTObject site = null;
      siteDriver.close(Os,null);

      if (val instanceof IABTObject){
         site = (IABTObject)val;
         site.setValue("Name", new ABTString("Site object"));
         }

      ObjectSpaceTreeModel tm = new ObjectSpaceTreeModel(Os);
      MutableTreeNode rootNode =new ObjectSpaceTreeNode("Site", site);
      tm.insertNodeInto(rootNode, (MutableTreeNode)tm.getRoot(),0);

      jSplitPane1.setLeftComponent(new ViewerByRule(site, "Site object"));


      DriverName.setEditable(true);
      DriverName.setAlignmentY((float) 0.0);

      DriverName.addItem("com.abtcorp.io.PMWRepo.ABTPMWRepoDriver");
      DriverName.addItem("com.abtcorp.io.siterepo.ABTSiteRepoDriver");

      toolBar.add(PopulateButton);
      toolBar.add(HashButton);
      toolBar.add(HashButton);
      toolBar.add(DriverName);
      this.getContentPane().add(toolBar, BorderLayout.NORTH);

      this.getContentPane().add(hashView,BorderLayout.SOUTH);

      this.getContentPane().add(jSplitPane1, BorderLayout.CENTER);
      menuFile.add(menuFileExit);
      menuHelp.add(menuHelpAbout);
      menuBar1.add(menuFile);
      menuBar1.add(menuHelp);
      this.setJMenuBar(menuBar1);

   }
//File | Exit action performed

   public void fileExit_actionPerformed(ActionEvent e) {
      System.exit(0);
   }
//Help | About action performed

   public void helpAbout_actionPerformed(ActionEvent e) {
      ViewerFrame_AboutBox dlg = new ViewerFrame_AboutBox(this);
      Dimension dlgSize = dlg.getPreferredSize();
      Dimension frmSize = getSize();
      Point loc = getLocation();
      dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
      dlg.setModal(true);
      dlg.show();
   }
//Overriden so we can exit on System Close

   protected void processWindowEvent(WindowEvent e) {
      super.processWindowEvent(e);
      if (e.getID() == WindowEvent.WINDOW_CLOSING) {
         fileExit_actionPerformed(null);
      }
   }

   private void doPopulate(){
      System.out.println("populate");
      // Create a pmw repo driver and get thin projects
      IABTDriver repoDriver = new ABTDriverLocal();
      repoDriver.initialize(Os,"com.abtcorp.io.PMWRepo.ABTPMWRepoDriver", null);

      IABTHashTable args = new ABTHashTable();
      args.clear();
      args.putItemByString ("UserName", new ABTString("admin"));
      args.putItemByString ("Password", new ABTString("administrator"));
      args.putItemByString ("Product", new ABTString("ABT Workbench"));
      args.putItemByString ("RepositoryName", new ABTString("ABTRepository"));
      repoDriver.open(Os,args);

      args.clear();
	   args.putItemByString( KEY_SOURCENAME, new ABTString("ABTRepository") );
  	   args.putItemByString( KEY_TYPE, new ABTString(TYPE_PROJECT ) );
      args.putItemByString( KEY_EXTID, new ABTString("TECHPROJ"));
      IABTObjectSet projs = (IABTObjectSet)repoDriver.populate(Os, args);
      IABTObject proj = (IABTObject)projs.getFront();
      repoDriver.close(Os,null);

      jSplitPane1.setRightComponent(new ViewerByRule(proj, proj.getValue("Name").toString()));
      jSplitPane1.paintAll(getGraphics());
      }


}


