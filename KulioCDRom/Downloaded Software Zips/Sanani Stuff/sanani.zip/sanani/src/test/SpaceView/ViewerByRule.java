
//Title:        Your Product Name
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Steve Pierson
//Company:      ABT Corporation
//Description:  Your description

package SpaceView;

import java.awt.*;
import java.awt.event.*;

import com.sun.java.swing.*;
import com.sun.java.swing.event.*;
import com.sun.java.swing.border.*;
import borland.jbcl.layout.*;
import com.abtcorp.api.local.*;
import java.util.Hashtable;
import com.abtcorp.idl.*;
import com.abtcorp.core.*;
import com.sun.java.swing.tree.*;


import com.sun.java.swing.tree.*;



public class ViewerByRule extends JPanel {

   private class ByRuleRenderer extends JLabel implements TreeCellRenderer{

    protected ImageIcon ObjectIcon;
    protected ImageIcon ObjectSetIcon;
    protected ImageIcon OtherIcon;

    public ByRuleRenderer(){
      super();
     	try {
          ObjectIcon = new ImageIcon("images/Task.GIF");
          ObjectSetIcon = new ImageIcon("images/set.gif");
          OtherIcon = new ImageIcon("images/yellow-ball.gif");
     	   }
      catch (Exception e) {
         System.out.println("Couldn't load images: " + e);
         }
      }
    public Component getTreeCellRendererComponent(JTree tree, Object value,
				   boolean selected, boolean expanded,
				   boolean leaf, int row, boolean hasFocus){

	      String stringValue = tree.convertValueToText(value, selected, expanded, leaf, row, hasFocus);
	      setText(stringValue);

	      if(hasFocus) setForeground(Color.blue);
	      else         setForeground(Color.black);

         if (value instanceof ByRuleObjectNode)         setIcon(ObjectIcon);
         else if (value instanceof ByRuleObjectSetNode) setIcon (ObjectSetIcon);
         else setIcon (OtherIcon);

         return this;
         }
      }

   private abstract class ByRuleNode extends DefaultMutableTreeNode{
      private String label;
      public ByRuleNode(String label_){
         super(label_);
         label = label_;
         }
      public String getLabel(){ return label; }
      public abstract int getChildCount();
      public abstract Object getChild(int n);
      }

   private class ByRuleObjectNode extends ByRuleNode{
      private IABTObject obj;
      public ByRuleObjectNode(String label, IABTObject obj_){
         super(label);
         obj = obj_;
         }
      public boolean isLeaf(){ return false; }
      public int getChildCount(){
         IABTPropertySet props = obj.getProperties();
         return props.countProperties();
         }

      public Object getChild(int n){
         IABTPropertySet props;
         IABTProperty prop;
         String propName;
         ABTValue propVal;
         String valString = null;
         try{
          props = obj.getProperties();
          prop = props.getPropertybyIndex(n);
          propName = prop.getName();
          if (propName.equals("FirstChildTask") )
            System.out.println("woo");
          propVal = obj.getValue(propName);
          if (propVal instanceof IABTObject){
            IABTObject it = (IABTObject) propVal;
            ABTValue nameValue = it.getValue("Name");
            if (nameValue instanceof ABTString){ valString = nameValue.stringValue(); }
            else{valString = ""; }
            return new ByRuleObjectNode(propName + " = "+valString,  (IABTObject)propVal);
            }
          else if (propVal instanceof IABTObjectSet){
            valString = "object set of type: "+((IABTObjectSet)propVal).getObjectType();
            return new ByRuleObjectSetNode(propName + " = "+valString, (IABTObjectSet)propVal);
            }
          else if (propVal != null)
             valString = propVal.toString();
         if (valString == null) valString = "null";
         return new DefaultMutableTreeNode(propName + " = "+valString);
         }
         catch (Exception huh){
            return null;
            }
         }
      }

   private class ByRuleObjectSetNode extends ByRuleNode{
      private IABTObjectSet obj;
      public ByRuleObjectSetNode(String label, IABTObjectSet obj_){
         super(label);
         obj = obj_;
         }
      public boolean isLeaf(){ return false; }
      public int getChildCount(){
         return obj.size();
         }

      public Object getChild(int n){
         IABTObject it = (IABTObject)obj.at(n);
         ABTValue nameValue = it.getValue("Name");
         String valString = "";
         if (nameValue instanceof ABTString) valString = nameValue.stringValue();
         else valString = "member "+new Integer(n).toString();
         return new ByRuleObjectNode(valString,  it);
         }
      }

   private class ByRuleRuleNode extends ByRuleNode{
      private IABTArray members;
      public ByRuleRuleNode(String label, IABTArray members_){
         super(label);
         members = members_;
         }

      public boolean isLeaf(){ return false; }

      public int getChildCount(){
         return members.size();
         }

      public Object getChild(int n){
         IABTObject member = (IABTObject)members.get(n);
         ABTValue theName =member.getValue("Name");
         String label;
         if (ABTError.isError(theName) == false)
            label = theName.toString();
         else
            label = member.toString();
         return new ByRuleObjectNode(label, member);
         }
      }

   private class ByRuleRootNode extends ByRuleNode{
      private ABTValue Obj;
      private String Name;
      private boolean traversedProps = false;
      private IABTHashTable objRules;
      public ByRuleRootNode(String label, ABTValue obj){
         super(label);
         objRules = new ABTHashTable();
         Obj = obj;
         Name = label;
         }
      public boolean isLeaf(){ return false; }
      public int getChildCount(){
         // We need to traverse through the entire object model, finding object rules
         if (traversedProps == false) {
            // first, extract the list of object rules found in links from this object
            ObjectModelParser.parse((IABTObject)Obj,objRules);
            // now traverse all property values and sort them into the rule categories
            scanValues((IABTObject)Obj);
            }
         return objRules.size();
         }

      public void scanValues(IABTObject scanWhat){
         try {
         // make a list of top-level rule objects
         IABTPropertySet props = (scanWhat.getProperties());
         IABTProperty prop;
         IABTEnumerator en = props.getElements();
         while (en.hasMoreElements()){
            prop = (IABTProperty)en.nextValue();
            int ptype = prop.getType();
            if (ptype == IABTPropertyType.PROP_OBJECT || ptype == IABTPropertyType.PROP_OBJECTSET){
               String rulename = prop.getReferenceType();
               ABTValue refObj = scanWhat.getValue(prop.getName());
               IABTArray ruleObjects;
               if (objRules.containsKey(new ABTString(rulename)) == false){
                  // this shouldn't happen (the parser should have gotten them all)
                  System.out.println("this shouldn't happen");
                  }
               else{
                  ABTValue woo =objRules.getItemByString(rulename);
                  ruleObjects = (IABTArray)objRules.getItemByString(rulename);
                  if (refObj instanceof IABTObject){
                     if (ruleObjects.contains(refObj) == false){
                        ruleObjects.add(refObj);
                        scanValues((IABTObject)refObj);
                        }
                     }
                  else if (refObj instanceof IABTObjectSet){
                     IABTObjectSet them = (IABTObjectSet)refObj;
                     IABTEnumerator en2 = them.getElements();
                     while (en2.hasMoreElements()){
                        ABTValue thing = en2.nextValue();
                        if (ruleObjects.contains(thing) == false){
                           ruleObjects.add(thing);
                           scanValues((IABTObject)thing);
                           }
                        }
                     }
                  }
               }
            }
         }
         catch (Exception e) {
            System.out.println(e.getMessage());
            }
         }

      public Object getChild(int n){
         IABTEnumerator en = objRules.getKeys();
         ABTString key = null;
         for (int i = 0; i <= n; ++i)
            key = (ABTString)en.nextValue();
         String keyName = key.stringValue();
         ABTValue val = objRules.getItemByString(keyName);
         if (val instanceof IABTArray)
            return new ByRuleRuleNode(key.stringValue(), (IABTArray)val);
         else
            return new ByRuleRuleNode(key.stringValue(), null);
         }
      }

   private class ByRuleTreeModel extends  DefaultTreeModel {

   public ByRuleTreeModel(ByRuleRootNode rootNode) {  super(rootNode);   }
   public int getChildCount(Object parent){
      if (parent instanceof ByRuleNode){
         ByRuleNode node = (ByRuleNode)parent;
         return node.getChildCount();
         }
      else return 0;
      }
   public Object getChild(Object parent, int index){
         if (parent instanceof ByRuleNode)
            return ((ByRuleNode)parent).getChild(index);
         else return null;
         }
   }

   IABTObject rootObject = null;
   String rootName;
   JTree ViewTree;
   BorderLayout borderLayout1 = new BorderLayout();

   public ViewerByRule(IABTObject rootObject_, String rootName_) {
      try  {
         rootObject = rootObject_;
         rootName = rootName_;
         jbInit();
      }
      catch (Exception ex) {
         ex.printStackTrace();
      }
   }

   void jbInit() throws Exception {
      this.setLayout(borderLayout1);
      this.setAutoscrolls(true);
      this.setMinimumSize(new Dimension(200, 500));

      ViewTree = new JTree(new ByRuleTreeModel(new ByRuleRootNode(rootName, (ABTValue)rootObject)));
      ViewTree.setBorder(new BevelBorder(0));
      ViewTree.setCellRenderer(new ByRuleRenderer());
      this.add(new JScrollPane(ViewTree), BorderLayout.CENTER);
/*
    ViewTree.addTreeExpansionListener(new TreeExpansionListener() {
      public void treeCollapsed(TreeExpansionEvent e){
         System.out.println("tree collapsed");
         }
      public void treeExpanded(TreeExpansionEvent e){
         System.out.println("tree expanded");
         }
      });
*/      
   }
}



