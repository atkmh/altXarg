import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import TestLib.*;

public class TestSananiApp 
{
   public TestSananiApp() {}
   
   public void run() 
   {
      try {
         // Create Log object for debug messages, 
         // do not prompt user to overwrite        
         // do create separate "FAIL"-only Log
         LogFile TestPropertiesLog = new LogFile("TestProperties",false,true);
         LogFile TestObjectPopulationLog = new LogFile("TestObject",false,true);
         // Local "driver", that does NOT extend ABTDriver or ABTRepositoryDriver
         // Instantiate testing object for Object Space / properties population
         TestProperties TestProp = new TestProperties(TestPropertiesLog);
         // Exercise exposed methods for properties and values in Object Space
//         TestProp.populate("com.abtcorp.rulebase",3);
        TestProp.populate(3);
  //       // Instantiate testing object for Object Space population 
         TestObjectPopulation TestObj = new TestObjectPopulation(TestObjectPopulationLog);
         // Exercise exposed methods which remove, add, verify Objects and ObjectSets
         // Number specified will be doubled:  n Objects, n ObjectSets
      //   TestObj.populate("com.abtcorp.rulebase",50);
        // AVP -7/14 - no longer specify rulebase, since will be hardcoded default
        // with no public setrulebase method in published API
          TestObj.populate(50); 
      } catch (Exception e) {
         e.printStackTrace();
      }      
   }
   
   public static void main(String args[])
   {
    System.out.println("Starting Test App");
    TestSananiApp app = new TestSananiApp();
    app.run();
   }
}