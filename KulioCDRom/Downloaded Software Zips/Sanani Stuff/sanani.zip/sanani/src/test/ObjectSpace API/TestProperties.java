import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.parser.*;
//No more rulebase package - AVP - 7/23
// import com.abtcorp.rulebase.*;
// AVP - 7/26 - TestEng "library" package - currently LogFile and ReadFile
import TestLib.*; 

import java.util.Enumeration;
import java.util.Date;
import java.util.Calendar;
import java.util.Vector;
import java.io.*;

public class TestProperties implements ILogType, IABTPropertyType
{
   ABTObjectSpace CurrentSpace; 
   // For logging test results
   LogFile CurrentLog;
   // Vector of all objects added to object space
   Vector ObjectVector;
   // counters, incremented to add new name and caption values
   // special hardcoded counters for certain values to verify
   // counter for Remote ID
   int
       NameNext = 0,
       CapNext = 0,
       CurrentObjectPtr = 0,
/*       
       Integer0Ptr = 0,
       IntegerNegativePtr = 0,
       TestIntStringPtr = 0,
       TestIntDoublePtr = 0,
       TestIntDatePtr = 0,
       TestTimePtr = 0,
       TestTimeMinPtr = 0,
       TestTimeMaxPtr = 0,
       TestTimeNowPtr = 0,
       TestTimeSamePtr = 0,
       TestTimeJulianPtr = 0,
*/       
       CurrentRemoteID = 0;
        ABTUserSession
            SessionID = null;

       
       
    // "max" string (really big, long, empty string buffer)
    // (currently non-existent)
   StringBuffer EmptyBuffer = new StringBuffer(999999);  
   String MaxEmptyString = new String(EmptyBuffer);
   // "max" string (really big, long, FULL string buffer)
   // (currently non-existent)
   StringBuffer FullBuffer = new StringBuffer();  
   String MaxFullString;
   
   public TestProperties(/*ABTObjectSpace space,*/LogFile log) throws ABTException
   {
        CurrentLog = log;
        CurrentRemoteID = 0;
   } // TestProperties constructor
   
   public void populate (int HowManyObjects)
   {
      CurrentLog.LogWrite(COMMENT,"STARTING populate method in TestProperties");
      for (int StringPtr = 0; StringPtr < 999999; StringPtr++)
          FullBuffer.append("X");
      MaxFullString = new String(FullBuffer);
      
      // AVP - 7/23 - no more setting hardcoded rulebase
      // Test different setRuleBase settings 
      // Blank (should be same as BOGUS)
//      TestRuleBase(" ");      
      // Null (should default to "com.abtcorp.hub")
//      TestObjects = TestRuleBase(null);
      // Non-existent (BOGUS)
//      TestRuleBase("BOGUS");
      // Exists, but not in package
//      TestRuleBase("NonpackagedRuleBase");
      // Exists, in package, correct and valid (if we specified it correctly!)
//      TestRuleBase(RuleBasePackage,HowManyObjects);
      TestRuleBase(HowManyObjects);
       
      CurrentLog.LogDisplay(COMMENT,"Testing Complete");
      
   }    // populate


    // AVP - 7/23 - no longer reference rulebase directly 
    // no longer use TestRuleBasePackage parameter
//   public void TestRuleBase(String TestRuleBasePackage, int LastObject)
   public void TestRuleBase(int LastObject)
   {
    // AVP - 7/23 - no longer test rulebase
//      String
//        RuleBaseString = null;
      ABTValue
        ObjectValue = null;
        
      // Create Object Space
      CurrentSpace = new ABTObjectSpace();
      SessionID = CurrentSpace.startSession(null);
      // TEMP - will phase out rulebase stuff when no longer public
//      CurrentSpace.setRulebase(TestRuleBasePackage);
      // Verify Rule Base
//      RuleBaseString = CurrentSpace.getRulebase();
//      if ((RuleBaseString != null) && (TestRuleBasePackage != null)) {
//         if (RuleBaseString.equals(TestRuleBasePackage))
//             CurrentLog.LogWrite(PASS,"getRuleBase = setRuleBase as " + TestRuleBasePackage);
//         else        
//             CurrentLog.LogDisplay(FAIL,"setRuleBase as " + TestRuleBasePackage + ", getRuleBase as " + RuleBaseString);
//      } else
//         if ((RuleBaseString == null) && (TestRuleBasePackage == null))
//             CurrentLog.LogWrite(PASS,"getRuleBase = setRuleBase as null");
//         else        
//             CurrentLog.LogDisplay(FAIL,"setRuleBase as null, getRuleBase as null");
      // Test Creating 1 ObjectSet, adding properties
  //    ABTValue TestObjects = CreateTestObject(true);
      // initialize counters for name and caption parameters
      NameNext = 0;
      CapNext = 0;
      // Test Creating multiple Objects in object space, adding properties
      ObjectVector = new Vector(5,1);
      for (CurrentObjectPtr = 0; CurrentObjectPtr < LastObject; CurrentObjectPtr++) {
          CurrentLog.LogDisplay(COMMENT,"Creating Object #" + (CurrentObjectPtr+1));
          ObjectValue = CreateTestObject(false,((CurrentObjectPtr > 0) && (CurrentObjectPtr < LastObject-1)) ? "TestEmptyObject2" : "TestEmptyObject");
          if (null == ObjectValue) // if not created correctly, then quit loop
          {
            break;
          } else              
          {
            CurrentLog.LogTotals(); // display and log total pass/fail so far
          }            
      } // end ObjectPtr for loop   
      if (ObjectValue != null) {
          // Test retrieving and extending property sets from each object
          TestPropertySet();
          // Test adding Properties which reference Properties in other Objects
          TestAddReference(LastObject-1,false); // with type OBJECT
          TestAddReference(LastObject-1,true); // with type OBJECT_SET
          CurrentLog.LogTotals();
      } // end if Objects/ObjectSets created correctly            
      CurrentSpace.endSession(SessionID);      
   } // TestRuleBase

   public ABTValue CreateTestObject(boolean IsObjectSet, String CurrentObjectName)
   {

   // local handle for results
      ABTValue 
        object = null;
                
      String ObjectText = (IsObjectSet) ? " Object Set " : " Object ";

      CurrentLog.LogDisplay(COMMENT,"Building " + ObjectText + CurrentObjectName);
      CurrentRemoteID++;
      ABTRemoteIDInteger RemoteID = new ABTRemoteIDInteger(CurrentRemoteID);
      
      // Create specified Object or Object Set, within Object Space
      if (IsObjectSet) 
         object = CurrentSpace.createObjectSet(SessionID,CurrentObjectName);
      else  
         object = CurrentSpace.createObject(SessionID,CurrentObjectName,RemoteID,null);
   // check for error
      if ((ABTError.isError(object)) || (object == null))
      {
         CurrentLog.LogDisplay(FAIL,"Creating " + ObjectText + CurrentObjectName + ((ABTError)object).getMessage() + " in " + CurrentSpace.getRulebase());
         return null;
      } else
         CurrentLog.LogWrite(PASS,"Creating " + ObjectText + CurrentObjectName + CurrentSpace.getRulebase());
      ObjectVector.addElement(object);  // store in vector
   // Robust testing of all addproperty parameters 
      TestAddRuleProperties(CurrentObjectName);
      TestAddNameProperties(CurrentObjectName);
      TestAddCaptionProperties(CurrentObjectName);      
      TestAddTypeProperties(CurrentObjectName);          
      TestAddFlagProperties(CurrentObjectName);          
// TODO:  AVP - 7/23 - Reference Type and Property Rule interfaces have changed
// These methods can not be run
//      TestAddReferenceTypeProperties(CurrentObjectName); 
  //    TestAddPropertyRuleProperties();          
      // Verify combinations of name, type, reference type, and property rule parameters
  //    TestAddCombo();          
      TestAddDefaultValueProperties(CurrentObjectName);          
      // Verify combinations of type and default value parameters
      TestAddTypeValueCombo(CurrentObjectName);
      // Verify Property Set that has been added
      TestGetPropertySet(object, CurrentObjectName, IsObjectSet);
      // Verify other ABTObjectSpace property extraction methods
      TestPropertiesOther(object, CurrentObjectName, RemoteID, IsObjectSet);
      // not an error so cast the ABTValue to an ObjectSet-handle
      return object;
   } // CreateTestObject

   public boolean TestAddRuleProperties(String CurrentObjectName)
   {
    ABTError testError;

    CurrentLog.LogWrite(COMMENT,"TESTING RULE PARAMETER");
    // test full specified rule parameter 
    TestAddProperty("full specified rule parameter",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    
    // test null rule parameter ("" string)
    TestAddProperty("empty rule parameter",   
                    "",
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    // test non-existent specified rule parameter
    TestAddProperty("non-existent specified rule parameter",   
                    "BOGUS",
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    TestAddProperty("maximum empty stringbuffer in rule parameter",   
                    MaxEmptyString,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
                    
/*                    
    // big string                    
    TestAddProperty("maximum FULL stringbuffer in rule parameter",   
                    MaxFullString,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null);
*/                    
     // add property that is already added (hardcoded) in ABTRule constructor
     // (should generate duplicate error)
     TestAddProperty("Duplicate of ABTRule constructor addproperty",
                  CurrentObjectName, 
                  "ABTDeleted",
                  "Deleted Flag",
                  ABTProperty.PROP_BOOLEAN,
                  false,
                  true,
                  true,
                  false,
                  null,
                  null,
                  null,
                  false); // should fail
    // test null rule parameter (null keyword)
    TestAddProperty("null rule parameter",   
                    null,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
                                 
     return(true);
   } // TestAddRuleProperties 

   public boolean TestAddNameProperties(String CurrentObjectName)
   {
    ABTError testError;
                                 
    CurrentLog.LogWrite(COMMENT,"TESTING NAME PARAMETER");
    // test full specified name parameter
    TestAddProperty("full specified name parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // test null name parameter ("")
    TestAddProperty("empty name parameter",   
                    CurrentObjectName,
                    "",
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    // test duplicate specified name parameter
    TestAddProperty("duplicate specified name parameter",   
                    CurrentObjectName,
                    "Name" + NameNext, // don't increment - dupe
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    // "max" string (really big, long, empty string buffer)
    TestAddProperty("maximum empty stringbuffer in name parameter",   
                    CurrentObjectName,
                    MaxEmptyString + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
/*                    
    // "max" string (really big, long, FULL string buffer)
    TestAddProperty("maximum FULL stringbuffer in name parameter",   
                    CurrentObjectName,
                    MaxFullString + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null);
*/                    
/*    // test null name parameter (null keyword)
    TestAddProperty("null name parameter",   
                    CurrentObjectName,
                    null,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null);
*/                    
    // test new specified name parameter (make sure everything is OK again)
    TestAddProperty("new specified name parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
                    
     return(true);
   } // TestAddNameProperties 


   public boolean TestAddCaptionProperties(String CurrentObjectName)
   {
    ABTError testError;
                                 
    CurrentLog.LogWrite(COMMENT,"TESTING CAPTION PARAMETER");
    // test full specified caption parameter
    TestAddProperty("full specified caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,                    
                    true); // should pass
    // test null caption parameter ("")
    TestAddProperty("empty caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // test duplicate specified caption parameter
    TestAddProperty("duplicate specified caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext, 
                    "Caption" + CapNext, // don't increment - dupe
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // "max" string (really big, long, empty string buffer)
    TestAddProperty("maximum empty stringbuffer in caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    MaxEmptyString + ++CapNext,                    
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
/*                    
    // "max" string (really big, long, FULL string buffer)
    TestAddProperty("maximum FULL stringbuffer in caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    MaxFullString + ++CapNext,                    
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null);
*/                    
    // test null caption parameter (null keyword)
    TestAddProperty("null caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    null,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // test new specified caption parameter (make sure everything is OK again)
    TestAddProperty("new specified caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
                                     
     return(true);
   } // TestAddCaptionProperties 

   public boolean TestAddTypeProperties(String CurrentObjectName)
   {
    ABTError testError;
    ReadFile InterfaceFile;
    int PropertyValue = 0;
    String PropertyString;

    CurrentLog.LogWrite(COMMENT,"TESTING TYPE PARAMETER");
    
    // Test with Type parameter of 0
    TestAddProperty("Type parameter 0",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    PropertyValue,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    // test null caption parameter (null keyword)
    TestAddProperty("null caption parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    null,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    // Test negative type parameter                    
    TestAddProperty("Type parameter -1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    PropertyValue - 1,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
                    
    // Open the Java Interface file that contains the valid property types
    try {
        InterfaceFile = new ReadFile("d:" + File.separatorChar + "sanani" + File.separatorChar + "src" + File.separatorChar + "com" + File.separatorChar + "abtcorp" + File.separatorChar + "hub" + File.separatorChar + "IABTPropertyType.java");
    } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception reading Type Interface File IABTPropertyType:" + e);
        CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
        return false;
      }
    CurrentLog.LogWrite(PASS,"Interface Java File IABTPropertyType opened and read successfully");      
    // Read each valid property type in file
    try {
        while (InterfaceFile.ReadFileTo("public static final int ")) {
            if ((PropertyString = InterfaceFile.ReadFileToString("=")) != null) {
                // stop if we have made it to PROP_K definitions, which are
                // for extensions, not for property types
                if (PropertyString.startsWith("PROP_K")) 
                    break;
                PropertyValue = Integer.parseInt(InterfaceFile.ReadFileToString(";").trim());
                TestAddProperty("Type parameter " + PropertyString + " = " + PropertyValue,
                                CurrentObjectName,
//                                (PropertyValue == ABTProperty.PROP_OBJECT) ? OFD_MM_ASSIGNMENTS : "Name" + ++NameNext,
                                "Name" + ++NameNext,
                                "Caption" + ++CapNext,
                                PropertyValue,
                                false,
                                true,
                                true,
                                true, //transient
   //                             (PropertyValue == ABTProperty.PROP_OBJECT) ? OBJ_MM_ASSIGNMENT : null,
   //                             (PropertyValue == ABTProperty.PROP_OBJECT) ? FR_MM_ASSIGNMENTS : null, 
                                null,
                                null,
                                null,                               
                                true); // should pass
            } // end if made it to "="                        
        } // end while reading public static final int                    
    } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception reading Type Interface File IABTPropertyType:" + e);
        CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
        return false;
    }
    // test above range of valid property types      
    TestAddProperty("Type parameter max + 1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    PropertyValue + 1,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
    // test real big number
    TestAddProperty("Type parameter 999999999",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    999999999,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    false); // should fail
   
     return(true);
   } // TestAddTypeProperties 

   public boolean TestAddFlagProperties(String CurrentObjectName)
   {
    ABTError testError;

    CurrentLog.LogWrite(COMMENT,"TESTING FLAG PARAMETERS");
    
    // Test with Virtual true, all others false
    TestAddProperty("Virtual Flag parameter true, all others false",
                    CurrentObjectName,
                 //   "Name" + ++NameNext,
                    "VirtualOnly",                
                    "Virtual Only",
//                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Visible true, all others false
    TestAddProperty("Visible flag parameter true, all others false",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
//                    "Caption" + ++CapNext,
                    "VisibleOnly",
                    "Visible Only",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    false,
                    false, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Updatable true, all others false
    TestAddProperty("Updatable true, all others false",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
  //                  "Caption" + ++CapNext,
                    "UpdatableOnly",
                    "Updatable Only",
                    ABTProperty.PROP_STRING,
                    false,
                    false,
                    true,
                    false, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Transient true, all others false
    TestAddProperty("Transient flag parameter true, all others false",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
//                    "Caption" + ++CapNext,
                    "TransientOnly",
                    "Transient Only",
                    ABTProperty.PROP_STRING,
                    false,
                    false,
                    false,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Virtual false, all others true
    TestAddProperty("Virtual flag parameter false, all others true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Visible false, all others true
    TestAddProperty("Visible flag parameter false, all others true",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
  //                  "Caption" + ++CapNext,
                    "VisibleFalse",
                    "Visible False",
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Updatable true, all others false
    TestAddProperty("Updatable flag parameter false, all others true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    true,
                    false,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Transient false, all others true
    TestAddProperty("Transient flag parameter false, all others true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    true,
                    true,
                    false, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with all false
    TestAddProperty("all flag parameters false",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
//                    "Caption" + ++CapNext,
                    "AllFlagsFalse",
                    "All Flags False",
                    ABTProperty.PROP_STRING,
                    false,
                    false,
                    false,
                    false, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with all true
    TestAddProperty("all flag parameters true",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
//                    "Caption" + ++CapNext,
                    "AllFlagsTrue",
                    "All Flags True",
                    ABTProperty.PROP_STRING,
                    true,
                    true,
                    true,
                    true,
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with first 2 false, second 2 true
    TestAddProperty("Virtual, Visible flag parameters false, others true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    false,
                    true,
                    true,
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with first 2 true, second 2 false
    TestAddProperty("Virtual, Visible flag parameters true, others false",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    true,
                    false,
                    false,
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with 1 and 3 true, 2 and 4 false
    TestAddProperty("Virtual, Updatable flag parameters true, others false",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    true,
                    false,
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with 1 and 3 false, 2 and 4 true
    TestAddProperty("Virtual, Updatable flag parameters false, others true",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
  //                  "Caption" + ++CapNext,
                    "Flag13false24true",
                    "Flag 1,3 false, 2,4 true",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    false,
                    true,
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with 2 and 3 true, 1 and 4 false
    TestAddProperty("Visible, Updatable flag parameters true, others false",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    false,
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with 2 and 3 false, 1 and 4 true
    TestAddProperty("Visible, Updatable flag parameters false, others true",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
//                    "Caption" + ++CapNext,
                    "Flag23false14true",
                    "Flag 2,3 false, 1,4 true",
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    true,
                    null,
                    null,
                    null,
                    true); // should pass

      return(true);
   } // TestAddFlagProperties 

   public boolean TestAddReferenceTypeProperties(String CurrentObjectName)
   {
    ABTError testError;
   
    CurrentLog.LogWrite(COMMENT,"TESTING REFERENCE TYPE PARAMETER");
    
    // Test with Reference Type parameter of null
    TestAddProperty("Reference Type parameter null",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test empty Reference Type parameter ("")
    TestAddProperty("empty Reference Type parameter",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    "",
                    null,
                    null,
                    false); // should fail
   TestReferenceTypeFile("IABTRuleConstants",CurrentObjectName);                     
   TestReferenceTypeFile("IABTMMRuleConstants",CurrentObjectName);                     
   TestReferenceTypeFile("IABTPMRuleConstants",CurrentObjectName);                     
    // test non-existent Reference Type
   TestAddProperty("non-existent Reference Type parameter",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    "BOGUS",
                    null,
                    null,
                    false); // should fail
    // "max" string (really big, long, empty string buffer)
    // (currently non-existent)
    TestAddProperty("maximum empty stringbuffer in reference type parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    MaxEmptyString,
                    null,
                    null,
                    false); // should fail
/*                    
    // "max" string (really big, long, FULL string buffer)
    // (currently non-existent)
    TestAddProperty("maximum FULL stringbuffer in reference type parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    MaxFullString,
                    null,
                    null);
*/                    
                    
     return(true);
   } // TestAddReferenceTypeProperties 
   
   public boolean TestReferenceTypeFile(String ReferenceFileName, String CurrentObjectName) 
   {  
    ABTError testError;
    ReadFile InterfaceFile;
    String ReferenceValue = null;
    String ReferenceString = null;

   // Open the Java Interface file that contains the valid reference types
    try {
        InterfaceFile = new ReadFile("d:" + File.separatorChar + "sanani" + File.separatorChar + "src" + File.separatorChar + "com" + File.separatorChar + "abtcorp" + File.separatorChar + "rulebase" + File.separatorChar + ReferenceFileName + ".java");
    } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception reading Reference Type Interface File " + ReferenceFileName + ":" + e);
        CurrentLog.LogDisplay(FAIL,"Reference Type Testing terminated due to Java error");
        return false;
      }
    CurrentLog.LogWrite(PASS,"Interface Java File " + ReferenceFileName + " opened and read successfully");      
    // Read each valid reference type in file
    try {
        while (InterfaceFile.ReadFileTo("public static final String ")) {
            if ((ReferenceString = InterfaceFile.ReadFileToString("=").trim()) != null) {
                // valid reference types are only those with OFD_ and NOT ending
                // with _CAP (those are captions)
                if ((ReferenceString.startsWith("OBJ_")) && (!ReferenceString.endsWith("_CAP"))) {
                    ReferenceValue = InterfaceFile.ReadFileToString(".intern();").trim();
                    TestAddProperty("Reference Type parameter " + ReferenceString + " = " + ReferenceValue,
                                    CurrentObjectName,
                                    "Name" + ++NameNext,
                                    "Caption" + ++CapNext,
                                    ABTProperty.PROP_STRING,
                                    false,
                                    true,
                                    true,
                                    true, //transient
                                    // strip off those pesky quote marks
                                    ReferenceValue.substring(1,ReferenceValue.length() - 1).intern(),
                                    null, 
                                    null,
                                    true); // should pass
                } // end if valid reference type                                    
            } // end if made it to "="                        
        } // end while reading public static final string                    
    } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception reading Reference Type Interface File " + ReferenceFileName + ":" + e);
        CurrentLog.LogDisplay(FAIL,"Reference Type Testing terminated due to Java error");
        return false;
    }
    // test duplicate reference type      
   TestAddProperty("Duplicate reference type parameter = " + ReferenceValue,
                   CurrentObjectName,
                   "Name" + ++NameNext,
                   "Caption" + ++CapNext,
                   ABTProperty.PROP_OBJECT,
                   false,
                   true,
                   true,
                   true, //transient
                   ReferenceValue.substring(1,ReferenceValue.length() - 1).intern(),
                   null, 
                   null,
                   true); // should pass
                   
    return true;
   } //  TestReferenceTypeFile

   public boolean TestAddPropertyRuleProperties(String CurrentObjectName)
   {
    ABTError testError;
   
    CurrentLog.LogWrite(COMMENT,"TESTING PROPERTY RULE PARAMETER");
    
    // Test with Property Rule parameter of null
    TestAddProperty("Property Rule parameter null",
                    CurrentObjectName,
                    "Name" + ++NameNext,
 //                  OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
   //                 OBJ_MM_ASSIGNMENT,
                    null,
                    null,
                    null,
                    false); // should fail
    // Test empty Property Rule parameter ("")
    TestAddProperty("empty Property Rule parameter",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    "",
                    null,
                    false); // should fail
   TestPropertyRuleFile("IABTRuleConstants",CurrentObjectName);                     
   TestPropertyRuleFile("IABTMMRuleConstants",CurrentObjectName);                     
   TestPropertyRuleFile("IABTPMRuleConstants",CurrentObjectName);                     
    // test non-existent Property Rule
   TestAddProperty("non-existent Property Rule parameter",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    "BOGUS",
                    null,
                    false); // should fail
    // "max" string (really big, long, empty string buffer)
    // (currently non-existent)
    TestAddProperty("maximum empty stringbuffer in Property Rule parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    MaxEmptyString,
                    null,
                    false); // should fail
/*                    
    // "max" string (really big, long, FULL string buffer)
    // (currently non-existent)
    TestAddProperty("maximum FULL stringbuffer in Property Rule parameter",   
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    MaxFullString,
                    null);
*/                    
                    
     return(true);
   } // TestAddPropertyRuleProperties 
   
   public boolean TestPropertyRuleFile(String ReferenceFileName, String CurrentObjectName) 
   {  
    ABTError testError;
    ReadFile InterfaceFile;
    String ReferenceValue = null;
    String ReferenceString = null;

   // Open the Java Interface file that contains the valid Property Rules
    try {
        InterfaceFile = new ReadFile("d:" + File.separatorChar + "sanani" + File.separatorChar + "src" + File.separatorChar + "com" + File.separatorChar + "abtcorp" + File.separatorChar + "rulebase" + File.separatorChar + ReferenceFileName + ".java");
    } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception reading Property Rule Interface File " + ReferenceFileName + ":" + e);
        CurrentLog.LogDisplay(FAIL,"Property Rule Testing terminated due to Java error");
        return false;
      }
    CurrentLog.LogWrite(PASS,"Interface Java File " + ReferenceFileName + " opened and read successfully");      
    // Read each valid Property Rule in file
    try {
        while (InterfaceFile.ReadFileTo("public static final String ")) {
            if ((ReferenceString = InterfaceFile.ReadFileToString("=").trim()) != null) {
                // valid Property Rules are only those with OFD_ and NOT ending
                // with _CAP (those are captions)
                if ((ReferenceString.startsWith("FR_")) && (!ReferenceString.endsWith("_CAP"))) {
                    ReferenceValue = InterfaceFile.ReadFileToString(".intern();").trim();
                    TestAddProperty("Property Rule parameter " + ReferenceString + " = " + ReferenceValue,
                                    CurrentObjectName,
                                    "Name" + ++NameNext,
                                    "Caption" + ++CapNext,
                                    ABTProperty.PROP_OBJECT,
                                    false,
                                    true,
                                    true,
                                    true, //transient
                                    null, // OBJ_MM_ASSIGNMENT, 
                                    // strip off those pesky quote marks
                                    ReferenceValue.substring(1,ReferenceValue.length() - 1).intern(),
                                    null,
                                    true); // should pass
                } // end if valid Property Rule                                    
            } // end if made it to "="                        
        } // end while reading public static final string                    
    } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception reading Property Rule Interface File " + ReferenceFileName + ":" + e);
        CurrentLog.LogDisplay(FAIL,"Property Rule Testing terminated due to Java error");
        return false;
    }
    // test duplicate Property Rule      
   if (ReferenceValue != null) 
       TestAddProperty("Duplicate Property Rule parameter = " + ReferenceValue,
                       CurrentObjectName,
                       "Name" + ++NameNext,
                       "Caption" + ++CapNext,
                       ABTProperty.PROP_OBJECT,
                       false,
                       true,
                       true,
                       true, //transient
       //                OBJ_MM_ASSIGNMENT, 
                       null,       
                       ReferenceValue.substring(1,ReferenceValue.length() - 1).intern(),
                       null,
                       true); // should pass

    return true;
   } //  TestPropertyRuleFile

/* TODO:  AVP - 7/23 - This approach no longer works - interfaces have changed for accessing
 reference types and property rules
   // Test all possible combinations of valid and invalid 
   // name, type, referencetype, and propertyrule parameters
   // since these all reference each other in error checking
   // (here, "valid" means a constant specified in an interface file
   //  "invalid" means another valid value that is NOT a matching constant)
   //  name:  valid:  OFD_MM_ASSIGNMENTS  invalid:  "Name" + ++NameNext
   //  type:  valid:  ABTProperty.PROP_OBJECT invalid:  ABTProperty.PROP_STRING
   //  referencetype:  valid: OBJ_MM_ASSIGNMENT invalid: OBJ_MM_METHOD
   //  propertyrule:  valid:  FR_MM_ASSIGNMENTS invalid:  FR_MM_METHOD
   public boolean TestAddCombo(String CurrentObjectName)
   {
    ABTError testError;

    CurrentLog.LogWrite(COMMENT,"TESTING NAME/TYPE/REFERENCE/PROPERTY PARAMETERS");
    
    // Test with name valid, all others invalid
    TestAddProperty("Name valid, all others invalid",
                    CurrentObjectName,
                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_METHOD,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with name invalid, all others valid
    TestAddProperty("Name invalid, all others valid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_ASSIGNMENT,
                    FR_MM_ASSIGNMENTS,
                    null,
                    false); // should fail
    // Test with name and reference type valid, others invalid
    TestAddProperty("Name and reference type valid, others invalid",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
                    OFD_MM_TASK,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_TASK,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with name and reference type invalid, others valid
    TestAddProperty("Name and reference type invalid, all others valid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_METHOD,
                    FR_MM_ASSIGNMENTS,
                    null,
                    false); // should fail
    // Test with name and type valid, others invalid
    TestAddProperty("Name and type valid, others invalid",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
                    OFD_MM_PACKAGE,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_PACKAGE,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with name and type invalid, others valid
    TestAddProperty("Name and type invalid, others valid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_ASSIGNMENT,
                    FR_MM_ASSIGNMENTS,
                    null,
                    false); // should fail
    // Test with name and property rule valid, others invalid
    TestAddProperty("Name and property rule valid, others invalid",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_METHOD,
                    FR_MM_ASSIGNMENTS,
                    null,
                    false); // should fail
    // Test with name and property rule invalid, others valid
    TestAddProperty("Name and property rule invalid, others valid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_ASSIGNMENT,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with name type and property rule valid, reference type invalid
    TestAddProperty("Name, type, and property rule valid, reference type invalid",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_METHOD,
                    FR_MM_ASSIGNMENTS,
                    null,
                    false); // should fail
    // Test with name type and property rule invalid, reference type valid
    TestAddProperty("Name, type, and property rule invalid, reference type valid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_ASSIGNMENT,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with name, reference type and property rule valid, type invalid
    TestAddProperty("Name, reference type, and property rule valid, type invalid",
                    CurrentObjectName,
//                    "Name" + ++NameNext,
                    OFD_MM_PAGEMEMBERS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_PAGEMEMBER,
                    FR_MM_PAGEMEMBERS,
                    null,
                    false); // should fail
    // Test with name, reference type and property rule invalid, type valid
    TestAddProperty("Name, reference type, and property rule invalid, type valid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_METHOD,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with all invalid 
    TestAddProperty("Name/type/reference/property parameters all invalid",
                    CurrentObjectName,
                    "Name" + ++NameNext,
//                    OFD_MM_ASSIGNMENTS,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_METHOD,
                    FR_MM_METHOD,
                    null,
                    false); // should fail
    // Test with all valid
    TestAddProperty("Name/type/reference/property parameters all valid",
                    CurrentObjectName,
          //          "Name" + ++NameNext,
                    OFD_MM_CUSTOMFIELD,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    true,
                    false,
                    false,
                    false, //transient
                    OBJ_MM_CUSTOMFIELD,
                    FR_MM_CUSTOMFIELD,
                    null,
                    true); // should pass
                    
      return(true);
   } // TestAddCombo
*/   

   public boolean TestAddDefaultValueProperties(String CurrentObjectName)
   {
    CurrentLog.LogWrite(COMMENT,"TESTING DEFAULT VALUE PARAMETER");
    
    // Test with Default Value parameter of null
    TestAddProperty("Default Value parameter null",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    // Test with Default Value parameter of integer 0
    TestAddProperty("Default Value parameter integer 0",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTInteger.valueOf("0"),
                    true); // should pass
//    Integer0Ptr = NameNext;                    
    // Test with Default Value parameter using constructor(int), with -12345
    TestAddProperty("Default Value parameter constructor integer -12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTInteger(-12345),
                    true); // should pass
  //  IntegerNegativePtr = NameNext;                    
    // Test with Default Value parameter using constructor(int), with 12345
    TestAddProperty("Default Value parameter constructor integer 12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTInteger(12345),
                    true); // should pass
    // Test with Default Value parameter using constructor(ABTValue), with 12345
    TestAddProperty("Default Value parameter constructor ABTValue integer 12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTInteger(ABTInteger.valueOf("12345")),
                    true); // should pass
    // Test with Default Value parameter using constructor(ABTValue), with -12345
    TestAddProperty("Default Value parameter constructor ABTValue integer -12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTInteger(ABTInteger.valueOf("-12345")),
                    true); // should pass
    // Test negative integer Default Value parameter
    TestAddProperty("Default Value parameter integer -1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTInteger.valueOf("-1"),
                    true); // should pass
    // Test excess integer Default Value parameter
    TestAddProperty("Default Value parameter integer 123456789123456789123456789123456789123456789123456789",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTInteger.valueOf("123456789123456789123456789123456789123456789123456789"),
                    false); // should fail
    // Test excess negative integer Default Value parameter
    TestAddProperty("Default Value parameter negative integer -123456789123456789123456789123456789123456789123456789",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTInteger.valueOf("-123456789123456789123456789123456789123456789123456789"),
                    false); // should fail
    // Test with Default Value parameter of short 0
    TestAddProperty("Default Value parameter short 0",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("0"),
                    true); // should pass
    // Test with Default Value parameter ABTShort constructor(int)
    TestAddProperty("Default Value parameter ABTShort constructor(int) 12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTShort((short)12345),
                    true); // should pass
    // Test with Default Value parameter ABTShort constructor(int)
    TestAddProperty("Default Value parameter ABTShort constructor(int) -12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTShort((short)-12345),
                    true); // should pass
    // Test with Default Value parameter using constructor(ABTValue), with 12345
    TestAddProperty("Default Value parameter constructor ABTValue short 12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTShort(ABTShort.valueOf("12345")),
                    true); // should pass
    // Test with Default Value parameter using constructor(ABTValue), with -12345
    TestAddProperty("Default Value parameter constructor ABTValue short -12345",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTShort(ABTShort.valueOf("-12345")),
                    true); // should pass
    // Test negative short Default Value parameter
    TestAddProperty("Default Value parameter short -1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("-1"),
                    true); // should pass
    // Test excess short Default Value parameter
    TestAddProperty("Default Value parameter short 123456789123456789123456789123456789123456789123456789",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123456789123456789123456789123456789123456789123456789"),
                    false); // should fail
    // Test max negative short Default Value parameter
    TestAddProperty("Default Value parameter negative short -123456789123456789123456789123456789123456789123456789",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("-123456789123456789123456789123456789123456789123456789"),
                    false); // should fail
    // Test with Default Value parameter of double 0
    TestAddProperty("Default Value parameter double 0",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("0"),
                    true); // should pass
    // Test with Default Value parameter of double 0.0
    TestAddProperty("Default Value parameter double 0.0",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("0.0"),
                    true); // should pass
    // Test with Default Value parameter of double 0.0
    TestAddProperty("Default Value parameter double .0",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf(".0"),
                    true); // should pass
    // Test negative double Default Value parameter
    TestAddProperty("Default Value parameter double -1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("-1"),
                    true); // should pass
    // Test negative double Default Value parameter
    TestAddProperty("Default Value parameter double -1.1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("-1.1"),
                    true); // should pass
    // Test negative double Default Value parameter
    TestAddProperty("Default Value parameter double -.1",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("-.1"),
                    true); // should pass
    // Test with Default Value parameter ABTShort constructor(double)
    TestAddProperty("Default Value parameter ABTShort constructor(double) 123.45",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDouble(123.45),
                    true); // should pass
    // Test with Default Value parameter ABTShort constructor(double)
    TestAddProperty("Default Value parameter ABTShort constructor(double) -123.45",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDouble((double)-123.45),
                    true); // should pass
    // Test with Default Value parameter using constructor(ABTValue), with 12345
    TestAddProperty("Default Value parameter constructor ABTValue double 123.45",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDouble(ABTDouble.valueOf("123.45")),
                    true); // should pass
    // Test with Default Value parameter using constructor(ABTValue), with -123.45
    TestAddProperty("Default Value parameter constructor ABTValue double -123.45",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDouble(ABTDouble.valueOf("-123.45")),
                    true); // should pass
    // Test excess double Default Value parameter
    TestAddProperty("Default Value parameter double 123456789123456789123456789123456789123456789123456789.123456789",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123456789123456789123456789123456789123456789123456789.123456789"),
                    false); // should fail
    // Test excess negative double Default Value parameter
    TestAddProperty("Default Value parameter negative double -123456789123456789123456789123456789123456789123456789.123456789",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("-123456789123456789123456789123456789123456789123456789.123456789"),
                    false); // should pass
    // Test boolean false Default Value parameter
    TestAddProperty("Default Value parameter boolean false",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("false"),
                    true); // should pass
    // Test boolean true Default Value parameter
    TestAddProperty("Default Value parameter boolean true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
    // Test boolean true Default Value parameter constructor(bool)
    TestAddProperty("Default Value parameter boolean constructor(bool) true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTBoolean(true),
                    true); // should pass
    // Test boolean true Default Value parameter constructor(ABTValue)
    TestAddProperty("Default Value parameter boolean constructor(ABTValue) true",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTBoolean(ABTBoolean.valueOf("true")),
                    true); // should pass
    // Test boolean true Default Value parameter constructor(ABTValue)
    TestAddProperty("Default Value parameter boolean constructor(ABTValue) false",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTBoolean(ABTBoolean.valueOf("false")),
                    true); // should pass
    // Test string null Default Value parameter
    TestAddProperty("Default Value parameter string null",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
    ABTString TestString1 = new ABTString("this is a test!!!");
    // Test string literal Default Value parameter
    TestAddProperty("Default Value parameter string ABTString object 'this is a test!!!'",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    true); // should pass
    // Test string Default Value parameter constructor(string)
    TestAddProperty("Default Value parameter string constructor(string) 'TEST(CONSTRUCTOR)'",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTString("TEST (CONSTRUCTOR)"),
                    true); // should pass
    ABTValue TestString = new ABTString("Testing ABTValue");
    // Test string Testing ABTValue Default Value parameter constructor(ABTValue)
    TestAddProperty("Default Value parameter string constructor(ABTValue) 'Testing ABTValue'",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTString(TestString),
                    true); // should pass
    // Test boolean true Default Value parameter constructor(ABTValue)
    TestAddProperty("Default Value parameter boolean constructor(ABTValue) false",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTBoolean(ABTBoolean.valueOf("false")),
                    true); // should pass
    ABTValue WrongDate = null;
    // Set variable to incorrect date format - will generate exception
    try 
    {
        WrongDate = ABTDate.valueOf("12.31.1998");
    } catch (Exception e)
    {
      CurrentLog.LogDisplay(FAIL,"Exception in ABTDate.valueOf with 12.31.1998: " + e);
    }    
    // Test Default Value parameter Date referencing pre-defined variable
    TestAddProperty("Default Value parameter Date mm/dd/yy",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    WrongDate,
                    true); // should fail
    // Test Default Value parameter Date hardcoded
    TestAddProperty("Default Value parameter Date mm/dd/yy",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("12/31/98"),
                    true); // should pass
    // Test Default Value parameter Date dd/mm/yy
    TestAddProperty("Default Value parameter Date dd/mm/yy",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("31/12/98"),
                    false); // should fail
    // Test Default Value parameter Date today()
    TestAddProperty("Default Value parameter Date today()",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    true); // should pass
    // Test Default Value parameter Date min("12/31/98,01/01/98")
    TestAddProperty("Default Value parameter Date min('12/31/98,01/01/98')",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.min(ABTDate.valueOf("12/31/98"),ABTDate.valueOf("01/01/98")),
                    true); // should pass
    // Test Default Value parameter Date max("12/31/98,01/01/98")
    TestAddProperty("Default Value parameter Date max('12/31/98,01/01/98')",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.max(ABTDate.valueOf("12/31/98"),ABTDate.valueOf("01/01/98")),
                    true); // should pass
    // Test Default Value parameter Date min same
    TestAddProperty("Default Value parameter Date min same (today,today)",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.min(ABTDate.today(),ABTDate.today()),
                    true); // should pass
    // Test Default Value parameter Date max same
    TestAddProperty("Default Value parameter Date max same ('03/05/87','03/05/87')",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.max(ABTDate.valueOf("03/05/87"),ABTDate.valueOf("03/05/87")),
                    true); // should pass
    // Test Default Value parameter Date constructor(julian)
    TestAddProperty("Default Value parameter Date constructor julian(10000))",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDate(10000),
                    true); // should pass
    // Test Default Value parameter Date constructor(y,m,d)
    TestAddProperty("Default Value parameter Date constructor julian(58,10,24)",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDate(58,10,24),
                    true); // should pass
    // Test Default Value parameter Date constructor(ABTTime,pm)
    TestAddProperty("Default Value parameter Date constructor (now(),PMtrue)",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDate(ABTTime.now(),true),
                    true); // should pass
    // Test Default Value parameter Date constructor(Date,pm)
    TestAddProperty("Default Value parameter Date constructor (Date(),PMtrue)",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDate(new Date(),true),
                    true); // should pass
    // Test Default Value parameter Date constructor(ABTValue,pm)
    TestAddProperty("Default Value parameter Date constructor (ABTValue 01/01/98,PMfalse)",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTDate(ABTDate.valueOf("01/01/98"),false),
                    true); // should pass
    // Test Default Value parameter Time hardcoded
    TestAddProperty("Default Value parameter Time dd/mm/yy hh:mm:ss",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.valueOf("1/1/98 1:35 PM"),
                    true); // should pass
    // Test Default Value parameter Time now()
    TestAddProperty("Default Value parameter Time now()",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
 //   TestTimeNowPtr = NameNext;                    
    // Test Default Value parameter Time min(1AM,2AM)
    TestAddProperty("Default Value parameter Time min('2:00 AM','1:00 PM')",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.min(ABTTime.valueOf("01/01/98 1:00 PM"),ABTTime.valueOf("01/01/98 2:00 AM")),
                    true); // should pass
  //  TestTimeMinPtr = NameNext;                    
    // Test Default Value parameter Time max(1AM, 2AM)
    TestAddProperty("Default Value parameter Time max('2:00,1:00')",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.max(ABTTime.valueOf("01/01/98 2:00 AM"),ABTTime.valueOf("01/01/98 1:00 AM")),
                    true); // should pass
 //   TestTimeMaxPtr = NameNext;                    
    // Test Default Value parameter Time min same
    TestAddProperty("Default Value parameter Time min same (now,now)",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.min(ABTTime.now(),ABTTime.now()),
                    true); // should pass
    // Test Default Value parameter Time max same
    TestAddProperty("Default Value parameter Time max same ('13:00:00','13:00:00')",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.max(ABTTime.valueOf("10/24/58 1:00 PM"),ABTTime.valueOf("10/24/58 1:00 PM")),
                    true); // should pass
 //   TestTimeSamePtr = NameNext;                    
    // Test Default Value parameter Time constructor(julian)
    TestAddProperty("Default Value parameter Time constructor julian(100000.23))",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(100000.23),
                    true); // should pass
//    TestTimeJulianPtr = NameNext;                    
    // Test Default Value parameter Time constructor(seconds)
    TestAddProperty("Default Value parameter Time constructor seconds(100000))",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(100000),
                    true); // should pass
    // Test Default Value parameter Time constructor(ABTDate, int)
    TestAddProperty("Default Value parameter Time constructor ABTDate, timeofday(12/31/98,1000))",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(ABTDate.valueOf("12/31/98"),1000),
                    true); // should pass
    // Test Default Value parameter Time constructor(ABTDate, int, int, int)
    TestAddProperty("Default Value parameter Time constructor ABTDate today, 14, 23, 32))",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(ABTDate.today(),14,23,32),
                    true); // should pass
    // Test Default Value parameter Time constructor(Calendar)
    TestAddProperty("Default Value parameter Time constructor Calendar()",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(Calendar.getInstance()),
                    true); // should pass
    // Test Default Value parameter Time constructor(Date)
    TestAddProperty("Default Value parameter Time constructor Date()",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(new Date()),
                    true); // should pass
    ABTValue TestTime = ABTTime.valueOf("12/31/98 04:30 PM");
    // Test Default Value parameter Time constructor(ABTValue)
    TestAddProperty("Default Value parameter Time constructor ABTValue()",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTTime(TestTime),
                    true); // should pass
                    
     return(true);
   } // TestAddDefaultValueProperties 

   public boolean TestAddTypeValueCombo(String CurrentObjectName)
   {
        ABTValue
            TestInteger1 = ABTInteger.valueOf("12345");
        ABTString
            TestString1 = new ABTString("this is a test!!!");

        CurrentLog.LogWrite(COMMENT,"Testing Type / Default incorrect combos");            
        // ALL COMBOS OF VALUES WITH TYPE INTEGER
        // Test with Type Int, Default Value String
        TestAddProperty("Type parameter Integer, Default parameter string",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
  //      TestIntStringPtr = NameNext;                    
        // Test with Type Int, Default Value boolean
        TestAddProperty("Type parameter Integer, Default parameter boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type Int, Default Value short
        TestAddProperty("Type parameter Integer, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type Int, Default Value double
        TestAddProperty("Type parameter Integer, Default parameter double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
   //     TestIntDoublePtr = NameNext;
        // Test with Type Int, Default Value Date
        TestAddProperty("Type parameter Integer, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    false); // should fail
//        TestIntDatePtr = NameNext;                    
        // Test with Type Int, Default Value Time
        TestAddProperty("Type parameter Integer, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE STRING
        // Test with Type String, Default Value Integer
        TestAddProperty("Type parameter String, Default parameter integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type String, Default Value boolean
        TestAddProperty("Type parameter String, Default parameter boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type String, Default Value short
        TestAddProperty("Type parameter String, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type String, Default Value double
        TestAddProperty("Type parameter String, Default parameter double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    true); // should pass
        // Test with Type String, Default Value Date
        TestAddProperty("Type parameter String, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    true); // should pass
        // Test with Type String, Default Value Time
        TestAddProperty("Type parameter String, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
        // ALL COMBOS OF VALUES WITH TYPE OBJECT
        // Test with Type Object, Default Value Integer
        TestAddProperty("Type parameter Object, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type Object, Default Value String
        TestAddProperty("Type parameter Object, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Object, Default Value boolean
        TestAddProperty("Type parameter Object, Default parameter boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type Object, Default Value short
        TestAddProperty("Type parameter Object, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    false); // should fail
        // Test with Type Object, Default Value double
        TestAddProperty("Type parameter Object, Default parameter double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
        // Test with Type Object, Default Value Date
        TestAddProperty("Type parameter Object, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    false); // should fail
        // Test with Type Object, Default Value Time
        TestAddProperty("Type parameter Object, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE OBJECTSET
        // Test with Type Object Set, Default Value Integer
        TestAddProperty("Type parameter Object Set, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type Object Set, Default Value String
        TestAddProperty("Type parameter Object Set, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Object Set, Default Value boolean
        TestAddProperty("Type parameter Object Set, Default parameter boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type Object Set, Default Value short
        TestAddProperty("Type parameter Object Set, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    false); // should fail
        // Test with Type Object Set, Default Value double
        TestAddProperty("Type parameter Object Set, Default parameter double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
        // Test with Type Object Set, Default Value Date
        TestAddProperty("Type parameter Object Set, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    false); // should fail
        // Test with Type Object Set, Default Value Time
        TestAddProperty("Type parameter Object Set, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_OBJECTSET,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE LONG
        // Test with Type Long, Default Value Integer
        TestAddProperty("Type parameter Long, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type Long, Default Value String
        TestAddProperty("Type parameter Long, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Long, Default Value boolean
        TestAddProperty("Type parameter Long, Default parameter boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Long, Default Value short
        TestAddProperty("Type parameter Long, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type Long, Default Value double
        TestAddProperty("Type parameter Long, Default parameter double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
        // Test with Type Long, Default Value Date
        TestAddProperty("Type parameter Long, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    false); // should fail
        // Test with Type Long, Default Value Time
        TestAddProperty("Type parameter Long, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_LONG,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
        // ALL COMBOS OF VALUES WITH TYPE BOOLEAN
        // Test with Type Boolean, Default Value Integer
        TestAddProperty("Type parameter Boolean, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type Boolean, Default Value String
        TestAddProperty("Type parameter Boolean, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Boolean, Default Value short
        TestAddProperty("Type parameter Boolean, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    false); // should fail
        // Test with Type Boolean, Default Value double
        TestAddProperty("Type parameter Boolean, Default parameter double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    true); // should pass
        // Test with Type Boolean, Default Value Date
        TestAddProperty("Type parameter Boolean, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    false); // should fail
        // Test with Type Boolean, Default Value Time
        TestAddProperty("Type parameter Boolean, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail

        // ALL COMBOS OF VALUES WITH TYPE DOUBLE
        // Test with Type Double, Default Value Integer
        TestAddProperty("Type parameter Double, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type Double, Default Value String
        TestAddProperty("Type parameter Double, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Double, Default Value short
        TestAddProperty("Type parameter Double, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type Double, Default Value Boolean
        TestAddProperty("Type parameter Double, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Double, Default Value Date
        TestAddProperty("Type parameter Double, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.valueOf("10/24/58"),
                    false); // should fail
        // Test with Type Double, Default Value Time
        TestAddProperty("Type parameter Double, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DOUBLE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE DATE
        // Test with Type Date, Default Value Integer
        TestAddProperty("Type parameter Date, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type Date, Default Value String
        TestAddProperty("Type parameter Date, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Date, Default Value short
        TestAddProperty("Type parameter Date, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    false); // should fail
        // Test with Type Date, Default Value Boolean
        TestAddProperty("Type parameter Date, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type Date, Default Value Date
        TestAddProperty("Type parameter Date, Default parameter Double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
        // Test with Type Date, Default Value Time
        TestAddProperty("Type parameter Date, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE TIME
        // Test with Type Time, Default Value Integer
        TestAddProperty("Type parameter Time, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type Time, Default Value String
        TestAddProperty("Type parameter Time, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Time, Default Value short
        TestAddProperty("Type parameter Time, Default parameter short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    false); // should fail
        // Test with Type Time, Default Value Boolean
        TestAddProperty("Type parameter Time, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type Time, Default Value Time
        TestAddProperty("Type parameter Time, Default parameter Double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
        // Test with Type Time, Default Value Date
        TestAddProperty("Type parameter Time, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE SHORT
        // Test with Type Short, Default Value Integer
        TestAddProperty("Type parameter Short, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type Short, Default Value String
        TestAddProperty("Type parameter Short, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type Short, Default Value Boolean
        TestAddProperty("Type parameter Short, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Short, Default Value Double
        TestAddProperty("Type parameter Short, Default parameter Double",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDouble.valueOf("123.45"),
                    false); // should fail
        // Test with Type Short, Default Value Date
        TestAddProperty("Type parameter Short, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    false); // should fail
        // Test with Type Short, Default Value Time
        TestAddProperty("Type parameter Short, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE TIMESTAMP
        // Test with Type TimeStamp, Default Value Integer
        TestAddProperty("Type parameter TimeStamp, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    false); // should fail
        // Test with Type TimeStamp, Default Value String
        TestAddProperty("Type parameter TimeStamp, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    false); // should fail
        // Test with Type TimeStamp, Default Value Boolean
        TestAddProperty("Type parameter TimeStamp, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type TimeStamp, Default Value Boolean
        TestAddProperty("Type parameter TimeStamp, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    false); // should fail
        // Test with Type TimeStamp, Default Value Short
        TestAddProperty("Type parameter TimeStamp, Default parameter Short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    false); // should fail
        // Test with Type TimeStamp, Default Value Date
        TestAddProperty("Type parameter TimeStamp, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    false); // should fail
        // Test with Type TimeStamp, Default Value Time
        TestAddProperty("Type parameter TimeStamp, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_TIMESTAMP,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    false); // should fail
        // ALL COMBOS OF VALUES WITH TYPE TIMESTAMP
        // Test with Type TimeStamp, Default Value Integer
        TestAddProperty("Type parameter TimeStamp, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type TimeStamp, Default Value String
        TestAddProperty("Type parameter TimeStamp, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    true); // should pass
        // Test with Type TimeStamp, Default Value Boolean
        TestAddProperty("Type parameter TimeStamp, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Boolean
        TestAddProperty("Type parameter TimeStamp, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Short
        TestAddProperty("Type parameter TimeStamp, Default parameter Short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Date
        TestAddProperty("Type parameter TimeStamp, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Time
        TestAddProperty("Type parameter TimeStamp, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
        // ALL COMBOS OF VALUES WITH TYPE BLOB
        // Test with Type Blob, Default Value Integer
        TestAddProperty("Type parameter Blob, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type Blob, Default Value String
        TestAddProperty("Type parameter Blob, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    true); // should pass
        // Test with Type Blob, Default Value Boolean
        TestAddProperty("Type parameter Blob, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Blob, Default Value Boolean
        TestAddProperty("Type parameter Blob, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Blob, Default Value Short
        TestAddProperty("Type parameter Blob, Default parameter Short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type Blob, Default Value Date
        TestAddProperty("Type parameter Blob, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    true); // should pass
        // Test with Type Blob, Default Value Time
        TestAddProperty("Type parameter Blob, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
        // ALL COMBOS OF VALUES WITH TYPE TIMESTAMP
        // Test with Type TimeStamp, Default Value Integer
        TestAddProperty("Type parameter TimeStamp, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type TimeStamp, Default Value String
        TestAddProperty("Type parameter TimeStamp, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    true); // should pass
        // Test with Type TimeStamp, Default Value Boolean
        TestAddProperty("Type parameter TimeStamp, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Boolean
        TestAddProperty("Type parameter TimeStamp, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Short
        TestAddProperty("Type parameter TimeStamp, Default parameter Short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Date
        TestAddProperty("Type parameter TimeStamp, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    true); // should pass
        // Test with Type TimeStamp, Default Value Time
        TestAddProperty("Type parameter TimeStamp, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_BLOB,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
        // ALL COMBOS OF VALUES WITH TYPE UNKNOWN
        // Test with Type Unknown, Default Value Integer
        TestAddProperty("Type parameter Unknown, Default parameter Integer",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestInteger1,
                    true); // should pass
        // Test with Type Unknown, Default Value String
        TestAddProperty("Type parameter Unknown, Default parameter String",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    TestString1,
                    true); // should pass
        // Test with Type Unknown, Default Value Boolean
        TestAddProperty("Type parameter Unknown, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Unknown, Default Value Boolean
        TestAddProperty("Type parameter Unknown, Default parameter Boolean",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTBoolean.valueOf("true"),
                    true); // should pass
        // Test with Type Unknown, Default Value Short
        TestAddProperty("Type parameter Unknown, Default parameter Short",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTShort.valueOf("123"),
                    true); // should pass
        // Test with Type Unknown, Default Value Date
        TestAddProperty("Type parameter Unknown, Default parameter Date",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    true); // should pass
        // Test with Type Unknown, Default Value Time
        TestAddProperty("Type parameter Unknown, Default parameter Time",
                    CurrentObjectName,
                    "Name" + ++NameNext,
                    "Caption" + ++CapNext,
                    ABTProperty.PROP_UNKNOWN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
                   
      return true;
   } // TestAddValueTypeCombo
   
    // This method calls the ObjectSpace.addProperty method, 
    // then performs error checking and logs diagnostic information
    // The property values are then verified via ABTObject.getProperty
    // Parameters:  Diagnostic - specific info. for this call, to log 
    //      Property values passed as arguments to ObjectSpace.addProperty:
    //                      String TestRule,
    //                           String TestName,
    //                            String TestCaption,
    //                            int     TestType,
    //                            boolean TestVirtual,
    //                            boolean TestVisible,
    //                            boolean TestUpdatable,
    //                            boolean TestTransient,
    //                            String  TestReferenceType,
    //                            String  TestPropertyRule,
    //                            ABTValue TestDefaultValue 
    //      boolean ShouldPass - diagnostic flag:  
    //              true=no error should occur
    //              false=error should be returned            
   public boolean TestAddProperty(String Diagnostic,
                           String TestRule,
                            String TestName,
                            String TestCaption,
                            int     TestType,
                            boolean TestVirtual,
                            boolean TestVisible,
                            boolean TestUpdatable,
                            boolean TestTransient,
                            String  TestReferenceType,
                            String  TestPropertyRule,
                            ABTValue TestDefaultValue,
                            boolean ShouldPass) 
   {                                 
    ABTError testError;

    try {
        testError = CurrentSpace.addProperty
                                 (  TestRule,
                                    TestName,
                                    TestCaption,
                                    TestType,
                                    TestVirtual,
                                    TestVisible,
                                    TestUpdatable,
                                    TestTransient,
                                    TestReferenceType,
                                    TestPropertyRule,
                                    TestDefaultValue
                                 );
    }  catch( Exception e )
      {
        CurrentLog.LogDisplay(FAIL,"Exception in addproperty with " + Diagnostic + ": " + e);
//        CurrentLog.LogDisplay(FAIL,"Testing terminated due to Java error");
        return false; // if exception encountered, return without verifying property
      }
   // check for error and record results in log file
   if (testError != null)
   {
      if (ShouldPass)
          CurrentLog.LogDisplay(FAIL,"addproperty with " + Diagnostic + " for TestEmptyObject: '" + testError.getMessage() + "'");
      else
          CurrentLog.LogWrite(PASS,"addproperty with " + Diagnostic + " for TestEmptyObject: '" + testError.getMessage() + "'");
      return false; // if error, return without verifying property
   } else 
      if (ShouldPass)
          CurrentLog.LogWrite(PASS,"addproperty with " + Diagnostic + " for TestEmptyObject");
      else
          CurrentLog.LogDisplay(FAIL,"addproperty with " + Diagnostic + " for TestEmptyObject - no error returned");
    // Verify Property that was just added  
    TestGetProperty((ABTObject)ObjectVector.elementAt(CurrentObjectPtr),TestName,TestCaption,TestType,TestVirtual,TestVisible,TestUpdatable,TestTransient,TestReferenceType,TestPropertyRule,TestDefaultValue);

    return true;      
   } // TestAddProperty      
   

   // This function tests the 2 applicable "getproperties" methods from ABTObjectSpace:
   // using the Object or ObjectSet reference, and using the Object name ("type")
   // since our test Object Space contains Object or ObjectSet of 1 type only,
   // these should match
   public boolean TestGetPropertySet(ABTValue TestObject, String CurrentObjectName, boolean IsObjectSet) 
   {
        ABTPropertySet 
            TestSet1 = null,
            TestSet2 = null,
            TestSet3 = null;
        int
            TestIndex1 = 0,
            TestIndex2 = 0,
            TestIndex3 = 0;
        String
            NullString = null,
            LastName = "Name" + NameNext, // last property added (assume PASS!)
            TestString1 = null,
            TestString2 = null,
            TestString3 = null;
            
        CurrentLog.LogDisplay(COMMENT,"TESTING OVERLOADED GETPROPERTIES");
        // should fail - null name
        try {
            TestSet3 = CurrentSpace.getProperties(NullString);
        } catch (Exception e) {
            CurrentLog.LogDisplay(FAIL,"Exception creating property set with null parameter: " + e);
      //      CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
    //        return false;
        }
//        if (IsObjectSet)           
//            TestSet1 = CurrentSpace.getProperties((ABTObjectSet)TestObject);
//        else
            TestSet1 = CurrentSpace.getProperties((ABTObject)TestObject);
        TestSet2 = CurrentSpace.getProperties(CurrentObjectName);
        // Look for last Property added to Object - index should match in each set
        TestIndex1 = TestSet1.indexForName(LastName);
        // Using index to last property, name of last property should be returned
        TestString1 = TestSet1.nameForIndex(TestIndex1);            
        if (TestString1.equals(LastName))
            CurrentLog.LogWrite(PASS,"Test nameForIndex method in ABTObjectSpace: Final Name = " + TestString1);
        else            
            CurrentLog.LogDisplay(FAIL,"Test nameForIndex method in ABTObjectSpace: Final Name = " + TestString1 + " , should be " + LastName);
        TestIndex2 = TestSet2.indexForName(LastName);
        TestString2 = TestSet2.nameForIndex(TestIndex2);
        if (TestIndex1 == TestIndex2)
            CurrentLog.LogWrite(PASS,"Test overloaded GetProperties methods in ABTObjectSpace using ABTPropertySet.indexForName: Final Index = " + TestIndex1);
        else            
            CurrentLog.LogDisplay(FAIL,"Test overloaded GetProperties methods in ABTObjectSpace using ABTPropertySet.indexForName: Final Index = " + TestIndex1 + " , " + TestIndex2);
        // Using index to last property, same name string should be returned from both propertysets            
        if (TestString1.equals(TestString2))
            CurrentLog.LogWrite(PASS,"Test overloaded GetProperties methods in ABTObjectSpace using ABTPropertySet.nameForIndex: Final Name = " + TestString1);
        else            
            CurrentLog.LogDisplay(FAIL,"Test overloaded GetProperties methods in ABTObjectSpace using ABTPropertySet.nameForIndex: Final Name = " + TestString1 + " , " + TestString2);
        // return first property in set
        TestString1 = TestSet1.nameForIndex(0);
        TestString2 = TestSet1.nameForIndex(0);
        // Using index to first property, same name string should be returned from both propertysets            
        if (TestString1.equals(TestString2))
            CurrentLog.LogWrite(PASS,"Test overloaded GetProperties methods in ABTObjectSpace using ABTPropertySet.nameForIndex: First Name = " + TestString1);
        else            
            CurrentLog.LogDisplay(FAIL,"Test overloaded GetProperties methods in ABTObjectSpace using ABTPropertySet.nameForIndex: First Name = " + TestString1 + " , " + TestString2);
        // non-existent (negative) index should return null
        TestString1 = TestSet1.nameForIndex(-1);
        if (TestString1 == null)
            CurrentLog.LogWrite(PASS,"Test nameForIndex method in ABTPropertySet: Non-existent index -1 returns null");
        else
            CurrentLog.LogDisplay(FAIL,"Test nameForIndex method in ABTPropertySet: Non-existent index -1 returns " + TestString1);
        // non-existent (max) index should return null
        TestString1 = TestSet1.nameForIndex(NameNext + 1000);
        if (TestString1 == null)
            CurrentLog.LogWrite(PASS,"Test nameForIndex method in ABTPropertySet: Non-existent index max value returns null");
        else
            CurrentLog.LogDisplay(FAIL,"Test nameForIndex method in ABTPropertySet: Non-existent index max value returns " + TestString1);
        // null name - should return -1 error
        TestIndex1 = TestSet1.indexForName(null);
        if (TestIndex1 == -1)
            CurrentLog.LogWrite(PASS,"Test indexForName method in ABTPropertySet: Non-existent null name returns -1 (error)");
        else            
            CurrentLog.LogDisplay(FAIL,"Test indexForName method in ABTPropertySet: Non-existent null name returns " + TestIndex1);
        // empty name - may exist!
        TestIndex1 = TestSet1.indexForName("");
        CurrentLog.LogDisplay(COMMENT,"Test indexForName method in ABTPropertySet: Empty name returns index: " + TestIndex1);
        // non-existent name
        TestIndex1 = TestSet1.indexForName("BOGUS");
        if (TestIndex1 == -1)
            CurrentLog.LogWrite(PASS,"Test indexForName method in ABTPropertySet: Non-existent BOGUS name returns -1 (error)");
        else            
            CurrentLog.LogDisplay(FAIL,"Test indexForName method in ABTPropertySet: Non-existent BOGUS name returns " + TestIndex1);
        // should fail - non-existent object
        TestSet3 = CurrentSpace.getProperties("BOGUS");
        if (TestSet3 == null)
            CurrentLog.LogWrite(PASS,"Test GetProperties method in ABTObjectSpace with BOGUS (non-existent) object - returns null");
        else  {
            CurrentLog.LogDisplay(FAIL,"Test GetProperties method in ABTObjectSpace with BOGUS (non-existent) object - does not return null");
            TestString3 = TestSet3.nameForIndex(0);
            CurrentLog.LogDisplay(COMMENT,"Test nameForIndex method in ABTPropertySet: Using non-existent propertyset 'BOGUS', returns index: " + TestIndex1);
        }            
        // should fail - non-existent empty object name
        TestSet3 = CurrentSpace.getProperties("");
        if (TestSet3 == null)
            CurrentLog.LogWrite(PASS,"Test GetProperties method in ABTObjectSpace with empty (non-existent) object - returns null");
        else  {
            CurrentLog.LogDisplay(FAIL,"Test GetProperties method in ABTObjectSpace with empty (non-existent) object - does not return null");
            TestString3 = TestSet3.nameForIndex(0);
            CurrentLog.LogDisplay(COMMENT,"Test nameForIndex method in ABTPropertySet: Using non-existent propertyset empty, returns index: " + TestIndex1);
        }            
/* NOT USED - now tested with each addproperty        
        // TEST GETPROPERTY FROM ABTOBJECT
        // Retrieve different properties and compare
        if (!IsObjectSet) {
            // First added property
            TestGetProperty((ABTObject)TestObject,"Name1","Caption1",ABTProperty.PROP_STRING,false,true,true,true,null,null,null);
            // Integer property with default value 0
            TestGetProperty((ABTObject)TestObject,"Name" + Integer0Ptr,"Caption" + Integer0Ptr,ABTProperty.PROP_INT,false,true,true,true,null,null,ABTInteger.valueOf("0"));
            // Integer property with default value -12345
            TestGetProperty((ABTObject)TestObject,"Name" + IntegerNegativePtr,"Caption" + IntegerNegativePtr,ABTProperty.PROP_INT,false,true,true,true,null,null,ABTInteger.valueOf("-12345"));
            // Time property with default value "01/01/98 01:35 AM"
            TestGetProperty((ABTObject)TestObject,"Name" + TestTimePtr,"Caption" + TestTimePtr,ABTProperty.PROP_TIME,false,true,true,true,null,null,ABTTime.valueOf("01/01/98 1:35 AM"));
            // Time property with default value min (1:00 PM, 2:00 AM)
            TestGetProperty((ABTObject)TestObject,"Name" + TestTimeMinPtr,"Caption" + TestTimeMinPtr,ABTProperty.PROP_TIME,false,true,true,true,null,null,ABTTime.valueOf("01/01/98 2:00 AM"));
            // Time property with default value max (1:00 AM, 2:00 AM)
            TestGetProperty((ABTObject)TestObject,"Name" + TestTimeMaxPtr,"Caption" + TestTimeMaxPtr,ABTProperty.PROP_TIME,false,true,true,true,null,null,ABTTime.valueOf("01/01/98 2:00 AM"));
            // Time property with default value max (1:00 AM, 1:00 AM)
            TestGetProperty((ABTObject)TestObject,"Name" + TestTimeSamePtr,"Caption" + TestTimeSamePtr,ABTProperty.PROP_TIME,false,true,true,true,null,null,ABTTime.valueOf("10/24/58 1:00 PM"));
            // Time property with default value now
            TestGetProperty((ABTObject)TestObject,"Name" + TestTimeNowPtr,"Caption" + TestTimeNowPtr,ABTProperty.PROP_TIME,false,true,true,true,null,null,ABTTime.now());
            // Time property with default value julian
            TestGetProperty((ABTObject)TestObject,"Name" + TestTimeJulianPtr,"Caption" + TestTimeJulianPtr,ABTProperty.PROP_TIME,false,true,true,true,null,null,new ABTTime(100000.23));
            // Integer property with string default value
            TestGetProperty((ABTObject)TestObject,"Name" + TestIntStringPtr,"Caption" + TestIntStringPtr,ABTProperty.PROP_INT,false,true,true,true,null,null,new ABTString("this is a test!!!"));
            // Integer property with double default value
            TestGetProperty((ABTObject)TestObject,"Name" + TestIntDoublePtr,"Caption" + TestIntDoublePtr,ABTProperty.PROP_INT,false,true,true,true,null,null,ABTDouble.valueOf("123.45"));
            // Integer property with date default value
            TestGetProperty((ABTObject)TestObject,"Name" + TestIntDatePtr,"Caption" + TestIntDatePtr,ABTProperty.PROP_INT,false,true,true,true,null,null,ABTDate.valueOf("10/24/58"));
            // FLAG PROPERTIES
            // Virtual Flag True Only
            TestGetProperty((ABTObject)TestObject,"VirtualOnly","Virtual Only",ABTProperty.PROP_STRING,true,false,false,false,null,null,null);
            // Visible Flag True Only
            TestGetProperty((ABTObject)TestObject,"VisibleOnly","Visible Only",ABTProperty.PROP_STRING,false,true,false,false,null,null,null);
            // Updatable Flag True Only
            TestGetProperty((ABTObject)TestObject,"UpdatableOnly","Updatable Only",ABTProperty.PROP_STRING,false,false,true,false,null,null,null);
            // Transient Flag True Only
            TestGetProperty((ABTObject)TestObject,"TransientOnly","Transient Only",ABTProperty.PROP_STRING,false,false,false,true,null,null,null);
        } // end if testing ABTObject            
*/        
//        TestProp2 = TestObject.getProperty(1);
        return true;
   } // TestGetPropertySet
   

//TODO:  Overload for key as well
   // This function retrieves one property from the specified ABTObject,
   // and verifies all values associated with the property, as passed in
   // Parameters:
   // TestObject - ABTObject
   // TestName - String name of Property 
   // TestCaption - String caption of Property
   // TestType - Int type of Property
   // TestVirtual - boolean Virtual flag
   // TestVisible - boolean Visible flag
   // TestUpdatable - boolean Updatable flag
   // TestTransient - boolean Transient flag
   // TestReferenceType - String reference type of Property
   // TestPropertyRule - String Property Rule
   // TestDefaultValue - ABTValue default value of Property
   public boolean TestGetProperty(ABTObject TestObject, String TestName, String TestCaption, int TestType, boolean TestVirtual, boolean TestVisible, boolean TestUpdatable, boolean TestTransient, String TestReferenceType, String TestPropertyRule, ABTValue TestDefaultValue)
   {
        ABTProperty
            TestProperty = null;
        String
            ReturnName = null,
            ReturnCaption = null;
        ABTRule            
            ReturnReferenceType = null;
        ABTValue
            ReturnSetValue = null,
            ReturnDefaultValue = null,
            TestGetValue = null;
    

        TestProperty = ((ABTObject)TestObject).getProperty(null,TestName);
        // name        
        if (TestProperty == null) {
            CurrentLog.LogDisplay(FAIL,"ABTObject getProperty with Name = " + TestName + " returns null");
            return false;
        }            
        ReturnName = TestProperty.getName();
        if ((TestName == null) || (ReturnName == null))
            if (TestName == null)
                CurrentLog.LogWrite(PASS,"ABTProperty getName returns correct value of null");
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getName returns incorrect value: instead of " + TestName + ", null");
        else                
            if (ReturnName.equals(TestName))
                CurrentLog.LogWrite(PASS,"ABTProperty getName returns correct value of " + TestName);
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getName returns incorrect value: instead of " + TestName + ", " + ReturnName);
        // caption            
        ReturnCaption = TestProperty.getCaption();
        if ((ReturnCaption == null) || (TestCaption == null))
            if (TestCaption == null)
                CurrentLog.LogWrite(PASS,"ABTProperty getCaption returns correct value of null");
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getCaption returns incorrect value: instead of " + TestCaption + ", null");
        else                
            if (ReturnCaption.equals(TestCaption))
                CurrentLog.LogWrite(PASS,"ABTProperty getCaption returns correct value of " + TestCaption);
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getCaption returns incorrect value: instead of " + TestCaption + ", " + ReturnCaption);
        // type                
        if (TestProperty.getType() == TestType)
            CurrentLog.LogWrite(PASS,"ABTProperty getType returns correct value of " + TestType);
        else                
            CurrentLog.LogDisplay(FAIL,"ABTProperty getType returns incorrect value: instead of " + TestType + ", " + TestProperty.getType());
        // Virtual flag
        if (TestProperty.isVirtual() == TestVirtual) 
            CurrentLog.LogWrite(PASS,"ABTProperty isVirtual returns correct boolean of " + TestVirtual);
        else                
            CurrentLog.LogDisplay(FAIL,"ABTProperty isVirtual returns incorrect boolean: instead of " + TestVirtual + ", " + TestProperty.isVirtual());
        // Visible flag
        if (TestProperty.isVisible() == TestVisible) 
            CurrentLog.LogWrite(PASS,"ABTProperty isVisible returns correct boolean of " + TestVisible);
        else                
            CurrentLog.LogDisplay(FAIL,"ABTProperty isVisible returns incorrect boolean: instead of " + TestVisible + ", " + TestProperty.isVisible());
        // Updatable flag
        if (TestProperty.isUpdatable() == TestUpdatable) 
            CurrentLog.LogWrite(PASS,"ABTProperty isUpdatable returns correct boolean of " + TestUpdatable);
        else                
            CurrentLog.LogDisplay(FAIL,"ABTProperty isUpdatable returns incorrect boolean: instead of " + TestUpdatable + ", " + TestProperty.isUpdatable());
        // Transient flag
        if (TestProperty.isTransient() == TestTransient) 
            CurrentLog.LogWrite(PASS,"ABTProperty isTransient returns correct boolean of " + TestTransient);
        else                
            CurrentLog.LogDisplay(FAIL,"ABTProperty isTransient returns incorrect boolean: instead of " + TestTransient + ", " + TestProperty.isTransient());
        // Reference Type                
        ReturnReferenceType = TestProperty.getReferenceType();
        if ((ReturnReferenceType == null) || (TestReferenceType == null))
            if (TestReferenceType == null)
                CurrentLog.LogWrite(PASS,"ABTProperty getReferenceType returns correct value of null");
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getReferenceType returns incorrect value: instead of " + TestReferenceType + ", null");
        else                
            if (ReturnReferenceType.equals(TestReferenceType))
                CurrentLog.LogWrite(PASS,"ABTProperty getReferenceType returns correct value of " + TestReferenceType);
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getReferenceType returns incorrect value: instead of " + TestReferenceType + ", " + ReturnReferenceType);
        // Default Value            
        ReturnDefaultValue = TestProperty.getDefaultValue();
        if ((ReturnDefaultValue == null) || (TestDefaultValue == null))
            if (TestDefaultValue == null)
                CurrentLog.LogWrite(PASS,"ABTProperty getDefaultValue returns correct value of null");
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getDefaultValue returns incorrect value: instead of " + TestDefaultValue + ", null");
        else                
            if (ReturnDefaultValue.equals(TestDefaultValue))
                CurrentLog.LogWrite(PASS,"ABTProperty getDefaultValue returns correct value of " + TestDefaultValue);
            else                
                CurrentLog.LogDisplay(FAIL,"ABTProperty getDefaultValue returns incorrect value: instead of " + TestDefaultValue + ", " + ReturnDefaultValue);
// TEMP - bug - getvalue does NOT return Default Value, so must call setValue first
        if (TestDefaultValue != null)
            ReturnSetValue = ((ABTObject)TestObject).setValue(SessionID,TestName,TestDefaultValue);
        // Confirm getValue returns Default Value
        switch (TestType) {
            case ABTProperty.PROP_INT :
                int TestGetInteger = (((ABTObject)TestObject).getValue(SessionID,TestName)).intValue();
                TestGetValue = new ABTInteger(TestGetInteger);
                break;
            case ABTProperty.PROP_SHORT :
                short TestGetShort = (((ABTObject)TestObject).getValue(SessionID,TestName)).shortValue();
                TestGetValue = new ABTShort(TestGetShort);
                break;
            case ABTProperty.PROP_BOOLEAN :
                boolean TestGetBool = ((ABTObject)TestObject).getValue(SessionID,TestName).booleanValue();
                TestGetValue = new ABTBoolean(TestGetBool);
                break;
            case ABTProperty.PROP_DOUBLE :
                double TestGetDouble = ((ABTObject)TestObject).getValue(SessionID,TestName).doubleValue();
                TestGetValue = new ABTDouble(TestGetDouble);
                break;
            case ABTProperty.PROP_DATE :
                ABTDate TestGetDate = ((ABTObject)TestObject).getValue(SessionID,TestName).dateValue(true);
                TestGetValue = TestGetDate;
                break;
            case ABTProperty.PROP_TIME :
                ABTTime TestGetTime = ((ABTObject)TestObject).getValue(SessionID,TestName).timeValue();
                TestGetValue = TestGetTime;
                break;
            default :
                TestGetValue = ((ABTObject)TestObject).getValue(SessionID,TestName);
                break;
        } // end switch TestType            
        if ((TestGetValue == null) || (TestDefaultValue == null))
            if (TestDefaultValue == null)
                CurrentLog.LogWrite(PASS,"ABTObject getValue returns correct value of null");
            else                
                CurrentLog.LogDisplay(FAIL,"ABTObject getValue returns incorrect value: instead of " + TestDefaultValue + ", null");
        else                
            if (TestGetValue.equals(TestDefaultValue))
                CurrentLog.LogWrite(PASS,"ABTObject getValue returns correct value of " + TestDefaultValue);
            else                
                CurrentLog.LogDisplay(FAIL,"ABTObject getValue returns incorrect value: instead of " + TestDefaultValue + ", " + TestGetValue);
            
        return true;            
   } // TestGetProperty
   
   // This function tests the data extraction methods in ABTObjectSpace:
   // getExtension()
   // getObjectPath()
   // getObjects()
   // findObject() (all overloaded methods)
   // using the Object or ObjectSet reference, and using the Object name ("type")
   public boolean TestPropertiesOther(ABTValue TestObject, String CurrentObjectName, ABTRemoteIDInteger RemoteID, boolean IsObjectSet)
   {
        ABTValue
            ReturnValue = null;
        String
            NullString = null,
            ObjectPath = null,
            Extension = null,
            Criteria = null;
        ABTRemoteIDInteger 
            RemoteID0 = new ABTRemoteIDInteger(0);

        CurrentLog.LogWrite(COMMENT,"TESTING GETEXTENSTION AND GETOBJECTPATH");
        ObjectPath = CurrentSpace.getObjectPath();
        CurrentLog.LogDisplay(COMMENT,"getObjectPath method  = " + ObjectPath);
        Extension = CurrentSpace.getExtension();
        CurrentLog.LogDisplay(COMMENT,"getExtension method  = " + Extension);
        CurrentLog.LogWrite(COMMENT,"TESTING GETOBJECTS");
        // Test with null object type
        try {
            ReturnValue = null;
            ReturnValue = CurrentSpace.getObjects(SessionID,null);
        } catch (Exception e) {
            CurrentLog.LogDisplay(FAIL,"Exception in getObjects method with null parameter: " + e);
      //      CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
    //        return false;
        }
        
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test getObjects method in ABTObjectSpace with null object type - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test getObjects method in ABTObjectSpace with null object type - did NOT return ABTError");
        // Test with real object type
        ReturnValue = null;
        ReturnValue = CurrentSpace.getObjects(null,CurrentObjectName);
        if (ReturnValue instanceof ABTObjectSet)
            CurrentLog.LogWrite(PASS,"Test getObjects method in ABTObjectSpace with correct object type - returns ABTObjectSet");
        else  
            CurrentLog.LogDisplay(FAIL,"Test getObjects method in ABTObjectSpace with correct object type - did NOT return ABTObjectSet");
                    
        // Test with non-existent object type
        ReturnValue = null;
        ReturnValue = CurrentSpace.getObjects(null,"BOGUS");
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test getObjects method in ABTObjectSpace with non-existent BOGUS object type - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test getObjects method in ABTObjectSpace with non-existent BOGUS object type - did NOT return ABTError");
        CurrentLog.LogWrite(COMMENT,"TESTING FINDOBJECT");
        // TEMP - bug with non-standard Name parameter in findobject - so, adding so repo-friendly names        
        TestAddProperty("adding PRNAME for criteria testing",
                    CurrentObjectName,
                    "PRNAME" + CurrentObjectPtr,
                    "Property Name",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTString("Test Name"),
                    true); // should pass
        TestAddProperty("adding PRID for criteria testing",
                    CurrentObjectName,
                    "PRID" + CurrentObjectPtr,
                    "Property ID",
                    ABTProperty.PROP_INT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTInteger.valueOf("1001"),
                    true); // should pass
        TestAddProperty("adding PRTIME for criteria testing",
                    CurrentObjectName,
                    "PRTIME" + CurrentObjectPtr,
                    "Property TIME",
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTTime.now(),
                    true); // should pass
        TestAddProperty("adding PRDATE for criteria testing",
                    CurrentObjectName,
                    "PRDATE" + CurrentObjectPtr,
                    "Property ID",
                    ABTProperty.PROP_DATE,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    ABTDate.today(),
                    true); // should pass
        TestAddProperty("adding PRTIMEBOOL for criteria testing",
                    CurrentObjectName,
                    "PRTIMEBOOL" + CurrentObjectPtr,
                    "Property Time with Boolean",
                    ABTProperty.PROP_TIME,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTBoolean(false),
                    false); // should fail
        TestAddProperty("adding PRBOOL for criteria testing",
                    CurrentObjectName,
                    "PRBOOL" + CurrentObjectPtr,
                    "Property Time with Boolean",
                    ABTProperty.PROP_BOOLEAN,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTBoolean(false),
                    false); // should fail
        TestAddProperty("adding PRSHORTSTRING for criteria testing",
                    CurrentObjectName,
                    "PRSHORTSTRING" + CurrentObjectPtr,
                    "Property Short with String",
                    ABTProperty.PROP_SHORT,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTString("ABCDEFG!!!"),
                    false); // should fail
        TestAddProperty("adding BADNAME for criteria testing",
                    CurrentObjectName,
                    "BADNAME" + CurrentObjectPtr,
                    "Property BADNAME",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTString("Bad Name"),
                    true); // should pass
        TestAddProperty("adding PRNULL for criteria testing",
                    CurrentObjectName,
                    "PRNULL" + CurrentObjectPtr,
                    "Property PRNULL",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    null,
                    true); // should pass
        // TEMP - Bug causes getvalue() to NOT retrieve default value.  Will set explicitly via
        // setValue
        ((ABTObject)TestObject).setValue(SessionID,"PRNAME" + CurrentObjectPtr,new ABTString("Test Name"));
        ((ABTObject)TestObject).setValue(SessionID,"PRID" + CurrentObjectPtr,ABTInteger.valueOf("1001"));
        ((ABTObject)TestObject).setValue(SessionID,"PRTIMEBOOL" + CurrentObjectPtr,new ABTBoolean(false));
        ((ABTObject)TestObject).setValue(SessionID,"PRBOOL" + CurrentObjectPtr,new ABTBoolean(false));
        ABTTime TimeValue = ABTTime.now();
        ((ABTObject)TestObject).setValue(SessionID,"PRTIME" + CurrentObjectPtr,TimeValue);
        ABTDate DateValue = ABTDate.today();
        ((ABTObject)TestObject).setValue(SessionID,"PRDATE" + CurrentObjectPtr,DateValue);
        ((ABTObject)TestObject).setValue(SessionID,"PRSHORTSTRING" + CurrentObjectPtr,new ABTString("ABCDEFG!!!"));
        ((ABTObject)TestObject).setValue(SessionID,"BADNAME" + CurrentObjectPtr,new ABTString("Bad Name"));
        // Test with null object type, correct Remote ID
        try {
            ReturnValue = null;
            ReturnValue = CurrentSpace.findObject(SessionID,null,RemoteID);
        } catch (Exception e) {
            CurrentLog.LogDisplay(FAIL,"Exception in findObject method with null type parameter, correct remote id: " + e);
      //      CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
    //        return false;
        }
        
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with null object type, correct remote id - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with null object type, correct remote id - did NOT return ABTError");
        // Test with correct object type, null Remote ID
        try {
            ReturnValue = null;
            ABTRemoteIDDate NullRemote = new ABTRemoteIDDate(null);
            ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,NullRemote);
        } catch (Exception e) {
            CurrentLog.LogDisplay(FAIL,"Exception in findObject method with correct type parameter, null remote id: " + e);
      //      CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
    //        return false;
        }
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type, null remote id - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type, null remote id - did NOT return ABTError");
        // Test with null object type, null Remote ID
        try {
            ReturnValue = null;
            ABTRemoteIDDate NullRemote = new ABTRemoteIDDate(null);
            ReturnValue = CurrentSpace.findObject(SessionID,null,NullRemote);
        } catch (Exception e) {
            CurrentLog.LogDisplay(FAIL,"Exception in findObject method with null object type, null remote id: " + e);
      //      CurrentLog.LogDisplay(FAIL,"Type Testing terminated due to Java error");
    //        return false;
        }
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with null object type, null remote id - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with null object type, null remote id - did NOT return ABTError");
        // Test with incorrect object type, correct remote id
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,"BOGUS",RemoteID);
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with incorrect object type and remote id - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with incorrect object type and remote id - did NOT return ABTError");
        // Test with correct object type, incorrect remote id
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,RemoteID0);
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type and incorrect remote id - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type and incorrect remote id - did NOT return ABTError");
        // Test with correct object type, correct remote id
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,RemoteID);
        if (ReturnValue instanceof ABTObject)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type and remote id - returns ABTObject");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type and remote id - did NOT return ABTObject");
       // TEST FINDOBJECT WITH LOCAL ID
       // Test with correct object type, integer value matching correct remote id
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,1);
        if (ReturnValue instanceof ABTObject)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type and local id - returns ABTObject");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type and local id - did NOT return ABTObject");
       // Test with incorrect object type, integer value matching correct remote id
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,"BOGUS",1);
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with incorrect object type and correct local id - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with incorrect object type and correct local id - did NOT return ABTError");
       // Test with correct object type, integer value 0
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,0);
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type and local id 0 - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type and local id 0 - did NOT return ABTError");
       // Test with correct object type, integer value -12345
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,-12345);
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type and local id -12345 - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type and local id -12345 - did NOT return ABTError");
       // Test with correct object type, integer value 99999999
        ReturnValue = null;
        ReturnValue = CurrentSpace.findObject(SessionID,CurrentObjectName,99999999);
        if (ReturnValue instanceof ABTError)
            CurrentLog.LogWrite(PASS,"Test findObject method in ABTObjectSpace with correct object type and local id 99999999 - returns ABTError");
        else  
            CurrentLog.LogDisplay(FAIL,"Test findObject method in ABTObjectSpace with correct object type and local id 99999999 - did NOT return ABTError");
               
       // TEST FINDOBJECT WITH VARIOUS SQL CRITERIA, INDICATE WHETHER CORRECT 
       // test with incorrect object name, correct integer property  - incorrect
       TestFindObjectCriteria("BOGUS","PRID" + CurrentObjectPtr + "=1001",false);
       // test with non-existent property name - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRBOGUS" + CurrentObjectPtr + "=1001",false);
       // test with integer property criteria
       TestFindObjectCriteria(CurrentObjectName,"PRID" + CurrentObjectPtr + "=1001",true);
       // test with integer property criteria - correct string of integer value
       TestFindObjectCriteria(CurrentObjectName,"PRID" + CurrentObjectPtr + " = '1001'",true);
       // test with integer property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRID" + CurrentObjectPtr + " < 0",false);
       // test with integer property criteria - correct - NOT EQUAL
       TestFindObjectCriteria(CurrentObjectName,"PRID" + CurrentObjectPtr + " <> 0",true);
       // test with integer property criteria - correct - NOT EQUAL
       TestFindObjectCriteria(CurrentObjectName,"PRID" + CurrentObjectPtr + " <> 1",true);
       // test with integer property criteria - incorrect - NOT EQUAL
       TestFindObjectCriteria(CurrentObjectName,"PRID" + CurrentObjectPtr + " <> 1001",false);
       // test with string property criteria - correct
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name'",true);
       // test with string property criteria - LIKE
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE 'Test Name'",true);
       // test with string property criteria - LIKE
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE '%Test Name%'",true);
       // test with string property criteria - LIKE
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE '%est Nam%'",true);
        TestAddProperty("adding PRNAMEOTHER for criteria testing",
                    CurrentObjectName,
                    "PRNAMEOTHER" + CurrentObjectPtr,
                    "Property Name",
                    ABTProperty.PROP_STRING,
                    false,
                    true,
                    true,
                    true, //transient
                    null,
                    null,
                    new ABTString("Test Name"),
                    true); // should pass
       // test with string property criteria - LIKE
       TestFindObjectCriteria(CurrentObjectName,"PRNAMEOTHER" + CurrentObjectPtr + " LIKE '%est Nam%'",true);
       // test with string property criteria - LIKE
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE 'Test Nam%'",true);
       // test with string property criteria  - LIKE
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE '%Name'",true);
       // test with string property criteria  - LIKE - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE '%est Nam'",false);
       // test with string property criteria - LIKE - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " LIKE 'est Nam%'",false);
       // test with string property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'BOGUS'",false);
       // test with string property criteria - ""
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = ''",false);
       // test with string property criteria - upper case incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'TEST NAME'",false);
       // test with time/boolean property criteria
       TestFindObjectCriteria(CurrentObjectName,"PRTIMEBOOL" + CurrentObjectPtr + " = false",true);
       // test with time/boolean property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRTIMEBOOL" + CurrentObjectPtr + " = '7/1/98 1:48 PM'",false);
       // test with date property criteria - correct - using toSQL
//       TestFindObjectCriteria(CurrentObjectName,"PRDATE" + CurrentObjectPtr + " >= " + DateValue.toSQL(),true);
       // test with time property criteria - correct - using toSQL
//       TestFindObjectCriteria(CurrentObjectName,"PRTIME" + CurrentObjectPtr + " >= " + TimeValue.toSQL(),true);
       // test with time property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRTIME" + CurrentObjectPtr + " = '7/1/98 1:48 PM'",false);
       // test with time property criteria - correct
       TestFindObjectCriteria(CurrentObjectName,"PRTIME" + CurrentObjectPtr + " >= '7/1/98 1:48 PM'",true);
       // test with date property criteria - correct
  //     TestFindObjectCriteria(CurrentObjectName,"PRDATE" + CurrentObjectPtr + " >= " + TimeValue.toSQL(),true);
       // test with date property criteria - Y2K - correct
       TestFindObjectCriteria(CurrentObjectName,"PRDATE" + CurrentObjectPtr + " <= '01/01/00'",true);
       // test with date property criteria - Y2K - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRDATE" + CurrentObjectPtr + " >= '01/01/00'",false);
       // test with time property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRDATE" + CurrentObjectPtr + " = '01/01/98'",false);
       // test with time property criteria - correct
       TestFindObjectCriteria(CurrentObjectName,"PRDATE" + CurrentObjectPtr + " >= '01/01/98'",true);
       // test with short/string property criteria
       TestFindObjectCriteria(CurrentObjectName,"PRSHORTSTRING" + CurrentObjectPtr + " = 'ABCDEFG!!!'",true);
       // test with short/string property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRSHORTSTRING" + CurrentObjectPtr + " = 0",false);
       // test with boolean property criteria
       TestFindObjectCriteria(CurrentObjectName,"PRBOOL" + CurrentObjectPtr + " = false",true);
       // test with time/boolean property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRBOOL" + CurrentObjectPtr + " = true",false);
       // test with BADNAME property criteria
       TestFindObjectCriteria(CurrentObjectName,"BADNAME" + CurrentObjectPtr + " = 'Bad Name'",true);
       // test with PRNULL property criteria
       TestFindObjectCriteria(CurrentObjectName,"PRNULL" + CurrentObjectPtr + " IS Null",true);
       // test with PRNULL property criteria - incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNULL" + CurrentObjectPtr + " = 'BOGUS'",false);
       // test with correct string and correct integer - AND 
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name' AND PRID" + CurrentObjectPtr +" <= 2000",true);
       // test with correct string and incorrect bool - AND - should be incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name' AND PRBOOL" + CurrentObjectPtr +" = true",false);
       // test with correct string and incorrect bool - OR - should be correct
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name' OR PRBOOL" + CurrentObjectPtr +" = true",true);
       // test with incorrect string and incorrect date - OR - should be incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Name' OR PRDATE" + CurrentObjectPtr +" > '10/31/99'",false);
       // test with multiple AND - correct
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name' AND PRID" + CurrentObjectPtr +" <= 2000 AND PRBOOL" + CurrentObjectPtr +" = false AND PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG!!!' AND PRDATE" + CurrentObjectPtr +" > '01/01/90' AND PRTIMEBOOL" + CurrentObjectPtr +" = false",true);
       // test with multiple AND - second to last incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name' AND PRID" + CurrentObjectPtr +" <= 2000 AND PRBOOL" + CurrentObjectPtr +" = false AND PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG!!!' AND PRDATE" + CurrentObjectPtr +" = '01/01/90' AND PRTIMEBOOL" + CurrentObjectPtr +" = false",false);
       // test with multiple AND - last incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'Test Name' AND PRID" + CurrentObjectPtr +" <= 2000 AND PRBOOL" + CurrentObjectPtr +" = false AND PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG!!!' AND PRDATE" + CurrentObjectPtr +" > '01/01/90' AND PRTIMEBOOL" + CurrentObjectPtr +" = true",false);
       // test with multiple AND - first incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'est Name' AND PRID" + CurrentObjectPtr +" <= 2000 AND PRBOOL" + CurrentObjectPtr +" = false AND PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG!!!' AND PRDATE" + CurrentObjectPtr +" > '01/01/90' AND PRTIMEBOOL" + CurrentObjectPtr +" = false",false);
       // test with multiple OR - first incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'est Name' OR PRID" + CurrentObjectPtr +" <= 2000 OR PRBOOL" + CurrentObjectPtr +" = false OR PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG!!!' OR PRDATE" + CurrentObjectPtr +" > '01/01/90' OR PRTIMEBOOL" + CurrentObjectPtr +" = false",true);
       // test with multiple OR - only second to last correct
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'est Name' OR PRID" + CurrentObjectPtr +" = 2000 OR PRBOOL" + CurrentObjectPtr +" = true OR PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG' OR PRDATE" + CurrentObjectPtr +" > '01/01/90' OR PRTIMEBOOL" + CurrentObjectPtr +" = true",true);
       // test with multiple OR - all incorrect
       TestFindObjectCriteria(CurrentObjectName,"PRNAME" + CurrentObjectPtr + " = 'est Name' OR PRID" + CurrentObjectPtr +" = 2000 OR PRBOOL" + CurrentObjectPtr +" = true OR PRSHORTSTRING" + CurrentObjectPtr +" = 'ABCDEFG' OR PRDATE" + CurrentObjectPtr +" = '01/01/90' OR PRTIMEBOOL" + CurrentObjectPtr +" = true",false);
       // test with AND incorrect / OR correct
       TestFindObjectCriteria(CurrentObjectName,"(PRNAME" + CurrentObjectPtr + " = 'est Name' AND PRID" + CurrentObjectPtr +" = 2000) OR PRTIMEBOOL" + CurrentObjectPtr +" = false",true);
       // test with AND correct / OR incorrect
       TestFindObjectCriteria(CurrentObjectName,"(PRNAME" + CurrentObjectPtr + " = 'Test Name' AND PRID" + CurrentObjectPtr +" = 1001) OR PRTIMEBOOL" + CurrentObjectPtr +" = true",true);
            
        return true;
   } // TestPropertiesOther
   
   
   // This method calls ABTObjectSpace.findObject, using the search criteria
   // Parameters:
   // String Object Name 
   // String Criteria (SQL string)
   // boolean CorrectCriteria (whether or not SQL search should be successfull)
   public boolean TestFindObjectCriteria (String ObjectName, String Criteria, boolean CorrectCriteria)
   {
        ABTValue
            ReturnValue = null;
    
        try {                
            try {                
               // test with BADNAME property criteria - incorrect
                ReturnValue = null;
                ReturnValue = CurrentSpace.findObject(SessionID,ObjectName,Criteria);
            } catch (Error e)  {
                CurrentLog.LogDisplay(FAIL,"Java Error in findObject method with object name parameter of " + ObjectName + ", criteria of " + Criteria);
                CurrentLog.LogDisplay(FAIL,"JAVA ERROR: " + e);
                return false;
            }            
        } catch (Exception e)  {
             CurrentLog.LogDisplay(FAIL,"Java Exception in findObject method with object name parameter of " + ObjectName + ", criteria of " + Criteria);
             CurrentLog.LogDisplay(FAIL,"JAVA EXCEPTION: " + e);
             return false;
        }            
         
            
        if (ReturnValue != null) 
            if (CorrectCriteria)
                if ((ReturnValue instanceof ABTObjectSet) && (!((ABTObjectSet)ReturnValue).isEmpty(SessionID)))
                    CurrentLog.LogWrite(PASS,"Test findObject method with CORRECT object name parameter of " + ObjectName + ", CORRECT criteria of " + Criteria + ": returned ABTObjectSet");
                else  
                    CurrentLog.LogDisplay(FAIL,"Test findObject method with CORRECT object name parameter of " + ObjectName + ", CORRECT criteria of " + Criteria + ": did not return ABTObjectSet");
            else                    
                if ((ReturnValue instanceof ABTError) || (((ABTObjectSet)ReturnValue).isEmpty(SessionID)))
                    CurrentLog.LogWrite(PASS,"Test findObject method with CORRECT object name parameter of " + ObjectName + ", INCORRECT criteria of " + Criteria + ": returned ABTError or empty ABTObjectSet");
                else  
                    CurrentLog.LogDisplay(FAIL,"Test findObject method with CORRECT object name parameter of " + ObjectName + ", INCORRECT criteria of " + Criteria + ": did not return ABTError or empty ABTObjectSet");
        else
            CurrentLog.LogDisplay(FAIL,"Test findObject method with object name parameter of " + ObjectName + ", criteria of " + Criteria + ": returned null");
    
        return true;
   } // TestFindObjectCriteria

   // Test extending and comparing Property Sets from different Objects
   boolean TestPropertySet()
   {
      ABTValue
        ReturnValue;

      // Property Set from first instantiation of first object
      ABTPropertySet Set1 = CurrentSpace.getProperties((ABTObject)ObjectVector.elementAt(0));
      // count properties
      int PropCtr1 = 0;
      for (PropCtr1 = 0; PropCtr1 < NameNext; PropCtr1++) {
        if (Set1.nameForIndex(PropCtr1) == null)
            break;
//        CurrentLog.LogWrite(COMMENT,Set1.nameForIndex(PropCtr1));
      }             
      // Compare count to ABTPropertySet.size (extended from Array via ABTArray)
      if (Set1.size() == PropCtr1)
        CurrentLog.LogWrite(PASS,"PropertySet.size for first Object returns " + Set1.size());
      else
        CurrentLog.LogDisplay(FAIL,"PropertySet.size for first Object returns " + Set1.size() + ", but only has " + PropCtr1 + " properties");
      // Second Property Set from second instantiation of first Object
      ABTPropertySet Set2 = CurrentSpace.getProperties((ABTObject)ObjectVector.elementAt(1));
      // count properties
      int PropCtr2 = 0;
      for (PropCtr2 = 0; PropCtr2 < NameNext; PropCtr2++) {
        if (Set2.nameForIndex(PropCtr2) == null)
            break;
//        CurrentLog.LogWrite(COMMENT,Set1.nameForIndex(PropCtr1));
      }              
      // Compare count to ABTPropertySet.size (extended from Array via ABTArray)
      if (Set2.size() == PropCtr2)
        CurrentLog.LogWrite(PASS,"PropertySet.size for second Object returns " + Set2.size());
      else
        CurrentLog.LogDisplay(FAIL,"PropertySet.size for second Object returns " + Set2.size() + ", but only has " + PropCtr2 + " properties");
      // Third Property Set from second Object
      ABTPropertySet Set3 = CurrentSpace.getProperties((ABTObject)ObjectVector.elementAt(2));
      // count properties
      int PropCtr3 = 0;
      for (PropCtr3 = 0; PropCtr3 < NameNext; PropCtr3++) {
        if (Set3.nameForIndex(PropCtr3) == null)
            break;
//        CurrentLog.LogWrite(COMMENT,Set1.nameForIndex(PropCtr1));
      }              
      // Compare count to ABTPropertySet.size (extended from Array via ABTArray)
      if (Set3.size() == PropCtr3)
        CurrentLog.LogWrite(PASS,"PropertySet.size for third Object returns " + Set3.size());
      else
        CurrentLog.LogDisplay(FAIL,"PropertySet.size for third Object returns " + Set3.size() + ", but only has " + PropCtr3 + " properties");
      if (PropCtr1 == PropCtr3)
        CurrentLog.LogWrite(PASS,"Property Sets for 2 instantiations of same object rule are equal");
      else        
        CurrentLog.LogDisplay(FAIL,"Property Sets for 2 instantiations of same object rule don't have same # of properties.  1:" + PropCtr1 + " 2:" + PropCtr3);
      // Try to extend for 2 Property Sets for same object "rule" -
      // array of "dupe" errors should be returned, and Property Set should
      // NOT be extended
      ReturnValue = Set1.extend(Set3);
      // Verify ErrorHub
      if (!(ReturnValue instanceof ABTErrorHub))
        CurrentLog.LogWrite(FAIL,"Extending Property Sets for same Object rule did not return Error Hub");
      else {        
          // Display all in Property Set                  
          int PropCtr4 = 0;
          for (PropCtr4 = 0; PropCtr4 < NameNext; PropCtr4++) {
            if (Set1.nameForIndex(PropCtr4) == null)
                break;
//            CurrentLog.LogWrite(COMMENT,Set1.nameForIndex(PropCtr4));
          }              
          if (PropCtr1 == PropCtr4)
            CurrentLog.LogWrite(PASS,"Property Set unchanged by bad extend() attempt");
          else            
            CurrentLog.LogDisplay(FAIL,"Property Set changed by bad extend() attempt.  Set1:" + PropCtr1 + " Set2:" + PropCtr4);
      } // end else                
      // Try to extend for 2 Property Sets for different object rules -
      // should pass with only some duplicates
      ReturnValue = Set1.extend(Set2);
      // Verify ErrorHub
      if (!(ReturnValue instanceof ABTErrorHub))
        CurrentLog.LogWrite(FAIL,"Extending Property Sets for 2 Objects with some duplicates did not return Error Hub");
      else {        
          // Display all in Property Set                  
          int PropCtr5 = 0;
          for (PropCtr5 = 0; PropCtr5 < NameNext; PropCtr5++) {
            if (Set1.nameForIndex(PropCtr5) == null)
                break;
//            CurrentLog.LogWrite(COMMENT,Set1.nameForIndex(PropCtr4));
          }   
          // Compare count to ABTPropertySet.size (extended from Array via ABTArray)
          if (Set1.size() == PropCtr5)
            CurrentLog.LogWrite(PASS,"PropertySet.size for second Object after extension returns " + Set1.size());
          else
            CurrentLog.LogDisplay(FAIL,"PropertySet.size for second Object after extension returns " + Set1.size() + ", but only has " + PropCtr5 + " properties");
          if (PropCtr1 < PropCtr5)
            CurrentLog.LogWrite(PASS,"Property Set extended by extend() attempt for 2 different Objects");
          else            
            CurrentLog.LogDisplay(FAIL,"Property Set not extended by extend() attempt for 2 different Objects.  Set1:" + PropCtr1 + " Set2:" + PropCtr2 + " Extended:" + PropCtr5 );
      } // end else                            
      // Try to extend for same Property Set -
      // should return array of errors, not be extended
      ReturnValue = Set3.extend(Set3);
      // Verify ErrorHub
      if (!(ReturnValue instanceof ABTErrorHub))
        CurrentLog.LogWrite(FAIL,"Extending Property Sets for same property set did not return Error Hub");
      else {        
        
          // Display all in Property Set                  
          int PropCtr6 = 0;
          for (PropCtr6 = 0; PropCtr6 < NameNext; PropCtr6++) {
            if (Set3.nameForIndex(PropCtr6) == null)
                break;
//            CurrentLog.LogWrite(COMMENT,Set1.nameForIndex(PropCtr4));
          }              
          // Compare count to ABTPropertySet.size (extended from Array via ABTArray)
          if (Set3.size() == PropCtr6)
            CurrentLog.LogWrite(PASS,"PropertySet.size for second Object after extension returns " + Set3.size());
          else
            CurrentLog.LogDisplay(FAIL,"PropertySet.size for second Object after extension returns " + Set3.size() + ", but only has " + PropCtr6 + " properties");
          if (PropCtr3 == PropCtr6)
            CurrentLog.LogWrite(PASS,"Property Set not extended by extend() attempt for same Property Set");
          else            
            CurrentLog.LogDisplay(FAIL,"Property Set extended by extend() attempt for same Property Set.  Set3:" + PropCtr3 + " Extended:" + PropCtr6 );
//            CurrentLog.LogWrite(COMMENT,"Extended Properties for Set3 = " + ((ABTProperty)((ABTObject)TestObject3).getProperty(1)).getExtendedProperties());              
      } // end else                            
      
        return true;
   } // TestPropertySet      

   // Test referencing one Object via property of second Object
   boolean TestAddReference(int LastObject, boolean ReferenceObjectSet)
   {
       ABTString
         StringSet = null,
         StringSetFinal = null;
       String         
         ReferenceName = new String((ReferenceObjectSet) ? "FirstObjectSetReference" : "FirstObjectReference");
       ABTValue
         StringGet = null,
         WrongValue = null;
        
        StringSet =  new ABTString("Name in First Object1");
        StringSetFinal =  new ABTString("Name in Last Object1");
        // Set value of PRNAME property in first Object
        ((ABTObject)ObjectVector.firstElement()).setValue(SessionID,"PRNAME0",StringSet);
        // Set value of same PRNAME property in last Object
        ((ABTObject)ObjectVector.lastElement()).setValue(SessionID,"PRNAME0",StringSetFinal);
        // add property to second object, with default value which references first object
        CurrentObjectPtr = 1;
        TestAddProperty("Type parameter " + ((ReferenceObjectSet) ? "OBJECTSET" : " OBJECT") + ", added to second Object, referencing first Object",
                        "TestEmptyObject2",
                        ReferenceName,
                        "First Object Reference",
                        ((ReferenceObjectSet) ? ABTProperty.PROP_OBJECTSET : ABTProperty.PROP_OBJECT),
                        false,
                        true,
                        true,
                        true, //transient
                        "TestEmptyObject",
                        null,
                        (ABTValue)ObjectVector.firstElement(),
                        (!ReferenceObjectSet)); // should pass if Object, not if ObjectSet
        // get value of Object1.PRNAME from Object2.FirstObjectReference, confirm values match
        ABTProperty NewProperty = ((ABTObject)ObjectVector.elementAt(1)).getProperty(SessionID,ReferenceName);
        ABTObject ThisObject = (ABTObject)NewProperty.getDefaultValue();
        
        StringGet = ThisObject.getValue(SessionID,"PRNAME0");
//       StringGet = ((ABTString)((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME0"));
       if (StringGet == null)
            CurrentLog.LogDisplay(FAIL,"Referencing Object 1 via Object 2 property: PRNAME value = null");
        else
            if (StringGet.equals(StringSet))
                CurrentLog.LogDisplay(PASS,"Referencing Object 1 via Object 2 property: PRNAME values equal " + StringSet);
            else                
                CurrentLog.LogDisplay(FAIL,"Referencing Object 1 via Object 2 property: PRNAME in Object 1 = " + StringSet + ", via Object 2 = " + StringGet);
        // now change the value of Object1.PRNAME        
        StringSet = new ABTString("Changed String in Object 1!!!!");          
        ((ABTObject)ObjectVector.firstElement()).setValue(SessionID,"PRNAME0",StringSet);
        // Verify change is reflected via Object2.FirstObjectReference
        StringGet = ((ABTString)((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME0"));
//        StringGet = ((ABTString)((ABTObject)NewProperty.getDefaultValue()).getValue(SessionID,"PRNAME0"));
        if (StringGet == null)
            CurrentLog.LogDisplay(FAIL,"Referencing Changed Object 1 via Object 2 property: PRNAME value = null");
        else
            if (StringGet.equals(StringSet))
                CurrentLog.LogDisplay(PASS,"Referencing Changed Object 1 via Object 2 property: PRNAME values equal " + StringSet);
            else                
                CurrentLog.LogDisplay(FAIL,"Referencing Changed Object 1 via Object 2 property: PRNAME in Object 1 = " + StringSet + ", via Object 2 = " + StringGet);
        // If so flagged, try to reference this object as objectset
        if (ReferenceObjectSet) {
            try {
                ABTValue InvalidObject = ((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName);
                ABTObjectSet InvalidObjectSet = (ABTObjectSet)InvalidObject;
                CurrentLog.LogDisplay(COMMENT,"Object Set size = " + InvalidObjectSet.size(SessionID));
                CurrentLog.LogDisplay(COMMENT,"Object Set isempty = " + InvalidObjectSet.isEmpty(SessionID));
                CurrentLog.LogDisplay(COMMENT,"Object Set contains first Object = " + InvalidObjectSet.contains(SessionID,((ABTObject)ObjectVector.firstElement())));
                CurrentLog.LogDisplay(COMMENT,"Object Set contains last Object = " + InvalidObjectSet.contains(SessionID,((ABTObject)ObjectVector.lastElement())));
            } catch (Exception e) {
                CurrentLog.LogDisplay(FAIL,"Exception trying to retrieve an Object as an ObjectSet from reference property: " + e);
            }                
        } // end if ReferenceObjectSet            
        // Change Object2.FirstObjectReference to reference Final Object
        ((ABTObject)ObjectVector.elementAt(1)).setValue(SessionID,ReferenceName,(ABTValue)ObjectVector.lastElement());
        // Verify value of Object3.PRNAME via Object2.ReferenceName
        StringGet = ((ABTString)((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME0"));
        if (StringGet == null)
            CurrentLog.LogDisplay(FAIL,"Referencing Final Object via Object 2 property: PRNAME value = null");
        else
            if (StringGet.equals(StringSetFinal))
                CurrentLog.LogDisplay(PASS,"Referencing Final Object via Object 2 property: PRNAME values equal " + StringSetFinal);
            else                
                CurrentLog.LogDisplay(FAIL,"Referencing Final Object via Object 2 property: PRNAME in Object 1 = " + StringSetFinal + ", via Object 2 = " + StringGet);
        // Try to select value from PRNAME1 property, which should not exist in Object 3
        StringGet = null;
        WrongValue = ((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME1");
        if (ABTError.isError(WrongValue))
            CurrentLog.LogDisplay(PASS,"Attempting to reference property which does not exist in final Object returned error: " + ((ABTError)WrongValue).getMessage());
        else {            
            StringGet = ((ABTString)((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME1"));
            CurrentLog.LogDisplay(FAIL,"Referencing non-existent final Object property from Object 2 - value? " + StringGet);
        }            
        // Change Object2.ReferenceName to reference ITSELF
        ((ABTObject)ObjectVector.elementAt(1)).setValue(SessionID,ReferenceName,(ABTValue)ObjectVector.elementAt(1));
        // Try to select value from PRNAME property, which should not exist in second Object
        StringGet = null;
        WrongValue = ((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME0");
        if (ABTError.isError(WrongValue))
            CurrentLog.LogDisplay(PASS,"Attempting to reference value via incorrect object reference returned error: " + ((ABTError)WrongValue).getMessage());
        else {            
            StringGet = ((ABTString)((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME0"));
            CurrentLog.LogDisplay(FAIL,"Referencing NAME0 Object from Object 2 - should not exist, returns value of " + StringGet);
        }            
        // Try to select value from PRNAME1 property, which SHOULD exist in second Object
        StringGet = null;
        WrongValue = ((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME1");
        if (ABTError.isError(WrongValue))
            CurrentLog.LogDisplay(PASS,"Attempting to reference value via incorrect object reference returned error: " + ((ABTError)WrongValue).getMessage());
        else {            
            StringGet = ((ABTString)((ABTObject)((ABTObject)ObjectVector.elementAt(1)).getValue(SessionID,ReferenceName)).getValue(SessionID,"PRNAME1"));
            CurrentLog.LogDisplay(COMMENT,"Referencing Object 2 from Object 2 - value? " + StringGet);
        }            
                    
        return true;
   } // TestAddReference 

} // TestProperties