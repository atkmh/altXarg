// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__E0DE081E_F4E2_11D1_ADFA_00E029143BC6__INCLUDED_)
#define AFX_DLGPROXY_H__E0DE081E_F4E2_11D1_ADFA_00E029143BC6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CVbscriptTestDlg;

/////////////////////////////////////////////////////////////////////////////
// CVbscriptTestDlgAutoProxy command target

class CVbscriptTestDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CVbscriptTestDlgAutoProxy)

	CVbscriptTestDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CVbscriptTestDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVbscriptTestDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CVbscriptTestDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CVbscriptTestDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CVbscriptTestDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CVbscriptTestDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__E0DE081E_F4E2_11D1_ADFA_00E029143BC6__INCLUDED_)
