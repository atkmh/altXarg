// vbscriptTestDlg.h : header file
//

#if !defined(AFX_VBSCRIPTTESTDLG_H__E0DE081C_F4E2_11D1_ADFA_00E029143BC6__INCLUDED_)
#define AFX_VBSCRIPTTESTDLG_H__E0DE081C_F4E2_11D1_ADFA_00E029143BC6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <comdef.h>
#import "P:\Program Files\Microsoft Script Control\msscript.ocx"
#import "d:\sanani\classes\com\abtcorp\pmw\pmw.tlb" named_guids
using namespace com_abtcorp_pmw;

class CVbscriptTestDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CVbscriptTestDlg dialog

class CVbscriptTestDlg : public CDialog
{
	DECLARE_DYNAMIC(CVbscriptTestDlg);
	friend class CVbscriptTestDlgAutoProxy;
    MSScriptControl::IScriptControlPtr m_Script;
    IABTObjectSpaceCOMPtr m_ObjectSpace;
    IABTRepositoryDriverCOMPtr m_RepoDriver;

// Construction
public:
	CVbscriptTestDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CVbscriptTestDlg();

// Dialog Data
	//{{AFX_DATA(CVbscriptTestDlg)
	enum { IDD = IDD_VBSCRIPTTEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVbscriptTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CVbscriptTestDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CVbscriptTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VBSCRIPTTESTDLG_H__E0DE081C_F4E2_11D1_ADFA_00E029143BC6__INCLUDED_)
