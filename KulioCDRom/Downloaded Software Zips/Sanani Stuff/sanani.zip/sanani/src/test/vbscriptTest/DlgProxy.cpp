// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "vbscriptTest.h"
#include "DlgProxy.h"
#include "vbscriptTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVbscriptTestDlgAutoProxy

IMPLEMENT_DYNCREATE(CVbscriptTestDlgAutoProxy, CCmdTarget)

CVbscriptTestDlgAutoProxy::CVbscriptTestDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CVbscriptTestDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CVbscriptTestDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CVbscriptTestDlgAutoProxy::~CVbscriptTestDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	AfxOleUnlockApp();
}

void CVbscriptTestDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CVbscriptTestDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CVbscriptTestDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CVbscriptTestDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CVbscriptTestDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IVbscriptTest to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {E0DE0817-F4E2-11D1-ADFA-00E029143BC6}
static const IID IID_IVbscriptTest =
{ 0xe0de0817, 0xf4e2, 0x11d1, { 0xad, 0xfa, 0x0, 0xe0, 0x29, 0x14, 0x3b, 0xc6 } };

BEGIN_INTERFACE_MAP(CVbscriptTestDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CVbscriptTestDlgAutoProxy, IID_IVbscriptTest, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {E0DE0815-F4E2-11D1-ADFA-00E029143BC6}
IMPLEMENT_OLECREATE2(CVbscriptTestDlgAutoProxy, "VbscriptTest.Application", 0xe0de0815, 0xf4e2, 0x11d1, 0xad, 0xfa, 0x0, 0xe0, 0x29, 0x14, 0x3b, 0xc6)

/////////////////////////////////////////////////////////////////////////////
// CVbscriptTestDlgAutoProxy message handlers
