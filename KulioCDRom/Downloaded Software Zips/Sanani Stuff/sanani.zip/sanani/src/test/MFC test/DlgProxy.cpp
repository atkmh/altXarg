// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "MFCSananiClient.h"
#include "DlgProxy.h"
#include "MFCSananiClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCSananiClientDlgAutoProxy

IMPLEMENT_DYNCREATE(CMFCSananiClientDlgAutoProxy, CCmdTarget)

CMFCSananiClientDlgAutoProxy::CMFCSananiClientDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CMFCSananiClientDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CMFCSananiClientDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CMFCSananiClientDlgAutoProxy::~CMFCSananiClientDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	AfxOleUnlockApp();
}

void CMFCSananiClientDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CMFCSananiClientDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CMFCSananiClientDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMFCSananiClientDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CMFCSananiClientDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMFCSananiClient to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {0D11AC69-DE1F-11D1-ADEF-00E029143BC6}
static const IID IID_IMFCSananiClient =
{ 0xd11ac69, 0xde1f, 0x11d1, { 0xad, 0xef, 0x0, 0xe0, 0x29, 0x14, 0x3b, 0xc6 } };

BEGIN_INTERFACE_MAP(CMFCSananiClientDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CMFCSananiClientDlgAutoProxy, IID_IMFCSananiClient, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {0D11AC67-DE1F-11D1-ADEF-00E029143BC6}
IMPLEMENT_OLECREATE2(CMFCSananiClientDlgAutoProxy, "MFCSananiClient.Application", 0xd11ac67, 0xde1f, 0x11d1, 0xad, 0xef, 0x0, 0xe0, 0x29, 0x14, 0x3b, 0xc6)

/////////////////////////////////////////////////////////////////////////////
// CMFCSananiClientDlgAutoProxy message handlers
