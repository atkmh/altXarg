// PropertiesDialog.cpp : implementation file
//

#include "stdafx.h"
#include "MFCSananiClient.h"
#include "PropertiesDialog.h"
#include "ABTObjectSpaceConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// PropertiesDialog dialog


PropertiesDialog::PropertiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(PropertiesDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(PropertiesDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void PropertiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PropertiesDialog)
	DDX_Control(pDX, IDC_LIST1, m_PropertyList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PropertiesDialog, CDialog)
	//{{AFX_MSG_MAP(PropertiesDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// PropertiesDialog message handlers

int PropertiesDialog::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DoModal();
}

BOOL PropertiesDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
    PropertySet = Object->getProperties();
    IABTEnumeratorCOMPtr enu = PropertySet->getElements();
    while (enu->hasMoreElements())
        {
        IABTPropertyCOMPtr prop = enu->nextElement();
        _bstr_t propString = prop->getName();
        propString += " = ";
        bstr_t propName = prop->getName();
        _variant_t propVal = Object->getValue(propName);

        // we know the name of the property, and its value
        // let's see if it is a enumerated type
        IABTHashTableCOMPtr epl = Object->getPropertyKey(propName, PROP_KPOSSIBLEVALUES);
        if (epl) {
            // There is an enum for this property
            if (epl->containsKey(propVal)) {
                //And the enum has a match for the property value
                propVal = epl->getItemByInt(propVal);
                }
            }

        if (V_VT(&propVal) == VT_NULL)
            propString += L"( NULL )";
        else if (V_VT(&propVal) == VT_DISPATCH)
            propString += L"( Object )";
        else
            {
            try {
                propString += _bstr_t(propVal);
                }
            catch (_com_error e)
                {
                propString += L"?";
                }
            }
        m_PropertyList.AddString(propString);
        }
	
    IABTObjectSpaceCOMPtr os = Object->getObjectSpace();
    os->doGarbageCollection ();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
