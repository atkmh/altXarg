// MFCSananiClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCSananiClient.h"
#include "MFCSananiClientDlg.h"
#include "DlgProxy.h"
#include "PropertiesDialog.h"
#include "ABTObjectSpaceConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCSananiClientDlg dialog

IMPLEMENT_DYNAMIC(CMFCSananiClientDlg, CDialog);

CMFCSananiClientDlg::CMFCSananiClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMFCSananiClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMFCSananiClientDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pAutoProxy = NULL;
}

CMFCSananiClientDlg::~CMFCSananiClientDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	if (m_pAutoProxy != NULL)
		m_pAutoProxy->m_pDialog = NULL;
}

void CMFCSananiClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMFCSananiClientDlg)
	DDX_Control(pDX, IDC_TREE2, m_TaskTree);
	DDX_Control(pDX, IDC_TREE1, m_RepoTree);
	DDX_Control(pDX, IDC_LABEL2, m_ProjectName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMFCSananiClientDlg, CDialog)
	//{{AFX_MSG_MAP(CMFCSananiClientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_NOTIFY(NM_DBLCLK, IDC_TREE1, OnDblclkTree1)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TREE1, OnDeleteitemTree1)
	ON_NOTIFY(NM_DBLCLK, IDC_TREE2, OnDblclkTree2)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TREE2, OnDeleteitemTree2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCSananiClientDlg message handlers

BOOL CMFCSananiClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

    // Go get the repo and project names
    PopulateRepoTree();    
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFCSananiClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMFCSananiClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFCSananiClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CMFCSananiClientDlg::OnClose() 
{
	if (CanExit())
        {
        Driver->close(NULL, NULL);
		CDialog::OnClose();
        }
    ObjectSpace->endSession();
}

void CMFCSananiClientDlg::OnOK() 
{
	if (CanExit())
		CDialog::OnOK();
}

void CMFCSananiClientDlg::OnCancel() 
{
	if (CanExit())
		CDialog::OnCancel();
}

BOOL CMFCSananiClientDlg::CanExit()
{
	// If the proxy object is still around, then the automation
	//  controller is still holding on to this application.  Leave
	//  the dialog around, but hide its UI.
	if (m_pAutoProxy != NULL)
	{
		ShowWindow(SW_HIDE);
		return FALSE;
	}

	return TRUE;
}

void CMFCSananiClientDlg::OnDblclkTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	HTREEITEM htItem = m_RepoTree.GetSelectedItem();
    DWORD x = m_RepoTree.GetItemData(htItem);
    if (x != NULL)
        {
        _variant_t *extref =((_variant_t*)x);
        if (V_VT(extref) == VT_BSTR)
            {
            // It's a string, so it represents an external ID
            // Go load the project and swap its interface pointer
            // into the ItemData Variant
            CString projName = "Loading ";
            projName += m_RepoTree.GetItemText(htItem);
            m_ProjectName.SetCaption(projName);
            //m_ProjectName.RedrawWindow();
            
            try {
                _bstr_t reponame = L"ABTRepository";
                HTREEITEM htParent = NULL;

                htParent = m_RepoTree.GetParentItem(htItem);
                reponame = m_RepoTree.GetItemText(htParent);
                HCURSOR OldCurse = SetCursor(LoadCursor(NULL, IDC_WAIT));
                IABTHashTableCOMPtr args(__uuidof(ABTHashTableCOM_));

                args->putItemByString ("Type", "Project");
                args->putItemByString ("SourceName", reponame);
                args->putItemByString ("ExtID", extref);

                IABTObjectSetCOMPtr Set = Driver->populate(ObjectSpace,args);
                SetCursor(OldCurse);
                IABTObjectCOMPtr Proj = Set->GetItem(0);
                *extref = (LPDISPATCH)Proj;

                }
            catch (CException e) {
                char ermsg[99];
                AfxMessageBox(e.GetErrorMessage(ermsg, 99));
                }
            }
        if (V_VT(extref) == VT_DISPATCH)
            {
            // It's an open project (either because we just opened it
            // or because we've been here before and now we're here again
            IABTObjectCOMPtr theProject = *extref;
            _bstr_t projName = theProject->getValue(L"Name");
            m_ProjectName.SetCaption(projName);
            IABTObjectSetCOMPtr allTasks = theProject->getValue("AllTasks");
            long numTasks = allTasks->size();
            m_TaskTree.DeleteAllItems();
            for (long I = 0; I < numTasks - 1; ++I)
                {
                IABTObjectCOMPtr Task = allTasks->GetItem(I);
                _bstr_t TaskName;
                long Level = (long)Task->getValue("WBSLevel");
                for (int l = 0; l < Level-1; ++l) TaskName += L" ";
                TaskName += _bstr_t(Task->getValue("Name"));
                HTREEITEM hT = m_TaskTree.InsertItem(TaskName);
                _variant_t *vTaskRef = new _variant_t;
                *vTaskRef = (LPDISPATCH)Task;
                m_TaskTree.SetItemData(hT,(long)vTaskRef);   // must delete this later
                }
            }
       }
	*pResult = 0;
}


void CMFCSananiClientDlg::PopulateRepoTree()
{
	// Create the sanani object space and driver objects
    ObjectSpace.CreateInstance(__uuidof(ABTObjectSpaceCOM_));
    ObjectSpace->startSession(NULL);

    IABTHashTableCOMPtr args(__uuidof(ABTHashTableCOM_));

    IABTDriverCOMPtr sitedriver (__uuidof(ABTDriverCOM_));
    sitedriver->initialize(ObjectSpace, "com.abtcorp.io.siterepo.ABTSiteRepoDriver", NULL);
    
    args->putItemByString ("UserName", "admin");
    args->putItemByString ("Password", "administrator");
    args->putItemByString ("Product", "ABT Workbench");
    sitedriver->open(ObjectSpace, args);

    args->clear();
    args->putItemByString ("Type", "All");
    args->putItemByString ("RepositoryName", "ABTRepository");
    args->putItemByString("Product", "ABT Workbench");
    sitedriver->populate(ObjectSpace, args);
    sitedriver->close(ObjectSpace, NULL);

    Driver.CreateInstance(__uuidof(ABTDriverCOM_));
    Driver->initialize(ObjectSpace, "com.abtcorp.io.PMWRepo.ABTPMWRepoDriver",NULL);


    args->clear();
    args->putItemByString("Product", "ABT Workbench");
    Driver->open(ObjectSpace, args);

    // get the list of repositories
    args->clear();
    args->putItemByString(IABTDriverConstants.KEY_COMMAND, IABTDriverConstants.CMD_LIST);
    args->putItemByString(IABTDriverConstants.KEY_TYPE, IABTDriverConstants.TYPE_REPOSITORY);

    IABTHashTableCOMPtr repoNames = Driver->execute(ObjectSpace,args);
    IABTEnumeratorCOMPtr repos = repoNames->getKeys();

    while (repos->hasMoreElements() )
        {
        _bstr_t RepoName = repos->nextElement();
        HTREEITEM h = m_RepoTree.InsertItem(RepoName);
        // get the projects from the repo


        args->putItemByString ("Command", "List");
        args->putItemByString ("Type", "Project");
        args->putItemByString ("RepositoryName", RepoName);

        IABTHashTableCOMPtr projNames = Driver->execute(ObjectSpace, args);
        IABTEnumeratorCOMPtr projs = projNames->getKeys();
        while (projs->hasMoreElements() )
            {
            _bstr_t projname;
            _bstr_t projID;
            projID = projs->nextElement();
            projname   = projNames->getItemByString(projID);
            HTREEITEM hp = m_RepoTree.InsertItem(projname, h);
            _variant_t *vProjID = new _variant_t;
            *vProjID = projID;
            m_RepoTree.SetItemData(hp,(long)vProjID);   // must delete this later
            }
        projNames = NULL;
        projs = NULL;
        }


    ObjectSpace->doGarbageCollection ();
}

void CMFCSananiClientDlg::OnDblclkTree2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// double poke happened in the task tree
	// get the task object and list its properties
	HTREEITEM htItem = m_TaskTree.GetSelectedItem();
    DWORD x = m_TaskTree.GetItemData(htItem);
    if (x != NULL)
        {
        _variant_t *vTask =((_variant_t*)x);
        if (V_VT(vTask) == VT_DISPATCH)
            {
            IABTObjectCOMPtr Task = *vTask;
            _bstr_t tname = Task->getValue("Name");
            IABTPropertySetCOMPtr props = Task->getProperties();
            PropertiesDialog pd;
            pd.Object = Task;
            pd.DoModal();
            }
        }
 
	*pResult = 0;
}

void CMFCSananiClientDlg::OnDeleteitemTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
    //******************************************************
    //  We need to free the VARIANT data that got associated
    //  with the nodes in the tree control
    //******************************************************
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// Since each node in the project tree control may
    // have a pointer to a _variant_t object in memory,
    // we need to delete the _variant_t when the node
    // gets removed from the list.  If the variant
    // holds an interface reference, this will cause a Release()
    TVITEM item = pNMTreeView->itemOld;
    DWORD itemData = m_RepoTree.GetItemData((HTREEITEM)item.hItem);
    if (itemData != NULL) delete (_variant_t *)itemData;
	*pResult = 0;
}
void CMFCSananiClientDlg::OnDeleteitemTree2(NMHDR* pNMHDR, LRESULT* pResult) 
{
    //******************************************************
    //  We need to free the VARIANT data that got associated
    //  with the nodes in the tree control
    //******************************************************
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// Since each node in the task tree control may
    // have a pointer to a _variant_t object in memory,
    // we need to delete the _variant_t when the node
    // The variant holds an interface reference, 
    // so this will cause a Release()
    TVITEM item = pNMTreeView->itemOld;
    DWORD itemData = m_TaskTree.GetItemData((HTREEITEM)item.hItem);
    if (itemData != NULL) delete (_variant_t *)itemData;
	*pResult = 0;
}
