#if !defined(AFX_PROPERTIESDIALOG_H__FD65F855_DF8C_11D1_ADF1_00E029143BC6__INCLUDED_)
#define AFX_PROPERTIESDIALOG_H__FD65F855_DF8C_11D1_ADF1_00E029143BC6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PropertiesDialog.h : header file
//

#import "\sanani\include\ABTObjectSpaceCOM.tlb" named_guids exclude ("IABTReferenceListenerCOM")
using namespace com_abtcorp_api_com;

/////////////////////////////////////////////////////////////////////////////
// PropertiesDialog dialog

class PropertiesDialog : public CDialog
{
// Construction
public:
	IABTObjectCOMPtr Object;
	IABTPropertySetCOMPtr PropertySet;
	PropertiesDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(PropertiesDialog)
	enum { IDD = IDD_DIALOG1 };
	CListBox	m_PropertyList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(PropertiesDialog)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(PropertiesDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTIESDIALOG_H__FD65F855_DF8C_11D1_ADF1_00E029143BC6__INCLUDED_)
