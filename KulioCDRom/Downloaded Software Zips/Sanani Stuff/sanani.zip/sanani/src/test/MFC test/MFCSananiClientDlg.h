// MFCSananiClientDlg.h : header file
//
//{{AFX_INCLUDES()
#include "labelcontrol.h"
//}}AFX_INCLUDES

#if !defined(AFX_MFCSANANICLIENTDLG_H__0D11AC6E_DE1F_11D1_ADEF_00E029143BC6__INCLUDED_)
#define AFX_MFCSANANICLIENTDLG_H__0D11AC6E_DE1F_11D1_ADEF_00E029143BC6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#import "\sanani\include\ABTObjectSpaceCOM.tlb" named_guids exclude ("IABTReferenceListenerCOM")
using namespace com_abtcorp_api_com;


class CMFCSananiClientDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CMFCSananiClientDlg dialog

class CMFCSananiClientDlg : public CDialog
{
	DECLARE_DYNAMIC(CMFCSananiClientDlg);
	friend class CMFCSananiClientDlgAutoProxy;

// Construction
public:
	CMFCSananiClientDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CMFCSananiClientDlg();

// Dialog Data
	//{{AFX_DATA(CMFCSananiClientDlg)
	enum { IDD = IDD_MFCSANANICLIENT_DIALOG };
	CTreeCtrl	m_TaskTree;
	CTreeCtrl	m_RepoTree;
	CLabelControl	m_ProjectName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCSananiClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void PopulateRepoTree();
	IABTObjectSpaceCOMPtr ObjectSpace;
    IABTDriverCOMPtr Driver;

	CMFCSananiClientDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CMFCSananiClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDblclkTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteitemTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkTree2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteitemTree2(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCSANANICLIENTDLG_H__0D11AC6E_DE1F_11D1_ADEF_00E029143BC6__INCLUDED_)
