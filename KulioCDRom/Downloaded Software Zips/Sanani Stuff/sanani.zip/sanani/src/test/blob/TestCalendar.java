package test.blob;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;
import com.abtcorp.blob.*;

public class TestCalendar implements Runnable, ABTNames
{
   public TestCalendar() {}

   public void run()
   {
      ABTSession    session    = ABTSession.login();
      ABTRepository repository = session.connect("");
      ABTCursor     cursor     = repository.select("select * from " + TBL_CALENDAR + " where prID=" + 1);
      
      if (cursor.moveFirst()) {
         ABTCalendar calendar = (ABTCalendar)cursor.getField(FLD_VALUE);
         
         System.out.println("id=" + cursor.getField(FLD_ID) + ", value=" + calendar);
         
         {
            long start = System.currentTimeMillis();
         
            for (int index = 0; index < 1000; index++) cursor.getField(FLD_VALUE);
         
            long stop = System.currentTimeMillis();

            long time = stop - start;

            System.out.println("getField=" + time / 1000.0);
         }
         
         {
            long start = System.currentTimeMillis();
         
            for (int index = 0; index < 1000; index++) cursor.setField(FLD_VALUE, calendar);
         
            long stop = System.currentTimeMillis();

            long time = stop - start;

            System.out.println("setField=" + time / 1000.0);
         }
      }
      
      cursor.release();
      repository.release();
      session.release();
   }

   public static void main(String argv[])
   {
      try {
         TestCalendar test = new TestCalendar();

         test.run();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}