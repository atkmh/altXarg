package test.blob;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;
import com.abtcorp.blob.*;

public class TestCurve implements Runnable, ABTNames
{
   public TestCurve() {}

   public void run()
   {
   	ABTDate today = ABTDate.today();
   	
   	ABTCalendar calendar = new ABTCalendar();
   	
   	ABTCurve curve = new ABTCurve();
   	
   	curve.setSegment(new ABTTime(today, 0), new ABTTime(today.add(7), 0), 40*3600, calendar);
   	
   	curve.ceil(0.75);
   	
   	System.out.println(curve.addWorktime(null, 20*3600));
   	System.out.println(curve.subWorktime(null, 10*3600));
   }

   public static void main(String argv[])
   {
      try {
         TestCurve test = new TestCurve();

         test.run();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}