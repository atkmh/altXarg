/*
 * $Header: d:\sanani\src\test\core\TestDate.java, 3, 4/30/98 9:56:22 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package test.core;

import com.abtcorp.core.*;

/**
 * TestArray is a simple unit test class for ABTDate. It will verify the
 * construction and parsing of an ABTDate.
 * <p>
 * Like all test classes, TestDate implements Runnable and contains a static main method.
 *
 * @version    $Revision: 3$, $Date: 4/30/98 9:56:22 PM$
 * @author     $Author: Benoit Menendez$
 *
 * @see        com.abtcorp.core.ABTDate
 *
 */
 
public class TestDate implements Runnable
{

/**
 * Default (empty) constructor
 */

   public TestDate() {}

/**
 * This is the main body of the unit test.
 */
 
   public void run()
   {
      ABTDate date = ABTDate.valueOf("4/3/98");
      
      System.out.println(date);
   }

/**
 * This is the TestDate entry point.
 *
 * @param   argv  the command line arguments (unused)
 *
 */
 
   public static void main(String argv[])
   {
      try {
         TestDate test = new TestDate();

         test.run();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}