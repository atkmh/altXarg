/*
 * $Header: d:\sanani\src\test\core\TestArray.java, 4, 4/30/98 9:56:22 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package test.core;

import com.abtcorp.core.*;
import com.abtcorp.repository.*;

/**
 * TestArray is a simple unit test class for ABTSortedArray. It uses the
 * task names out of a repository to exercise the binary search capability
 * of the ABTSortedArray. It will also time the insertion into the array for
 * later reference.
 * <p>
 * Like all test classes, TestArray implements Runnable and contains a static main method.
 *
 * @version    $Revision: 4$, $Date: 4/30/98 9:56:22 PM$
 * @author     $Author: Benoit Menendez$
 *
 * @see        com.abtcorp.core.ABTArray
 * @see        com.abtcorp.core.ABTSortedArray
 *
 */

public class TestArray implements Runnable, ABTNames
{
   
/**
 * Default (empty) constructor
 */
 
   public TestArray() {}

/**
 * This is the main body of the unit test.
 */
 
   public void run()
   {
      ABTSortedArray array = new ABTSortedArray(new ABTDefaultComparator());

      ABTSession    session    = ABTSession.login();
      ABTRepository repository = session.connect("");
      ABTCursor     cursor     = repository.select(TBL_TASK);

      cursor.moveBOF();
      
      long base = 0;

      {
         long start = System.currentTimeMillis();

         while (cursor.moveNext()) cursor.getField(FLD_NAME);

         long stop = System.currentTimeMillis();

         base = stop - start;

         System.out.println("base=" + base / 1000.0);
      }

      cursor.moveBOF();
      
      {
         long start = System.currentTimeMillis();
      
         while (cursor.moveNext()) array.add(cursor.getField(FLD_NAME));

         long stop = System.currentTimeMillis();
      
         System.out.println("size=" + array.size());
         System.out.println("time=" + (stop - start - base) / 1000.0);
      }

      cursor.release();
      repository.release();
      session.release();
   }

/**
 * This is the TestArray entry point.
 *
 * @param   argv  the command line arguments (unused)
 *
 */
 
  public static void main(String argv[])
   {
      try {
         TestArray test = new TestArray();

         test.run();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}