/*
 * $Header: d:\sanani\src\test\core\TestCOM.java, 3, 8/10/98 12:52:02 PM, Benoit Menendez$
 * 
 * Copyright (c) 1995, 1998 ABT Corporation. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of ABT
 * Corporation ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with ABT Corporation.
 * 
 * ABT CORPORATION MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 * A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ABT CORPORATION SHALL NOT
 * BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package test.core;

import com.abtcorp.core.*;
import com.abtcorp.core.COM.*;

public class TestCOM implements Runnable
{
   public TestCOM() {}
 
   public void run()
   {
      ABTDispatch application = ABTDispatch.create("MSProject.Application");

      ABTValue params[] = new ABTValue[12];

      params[0] = new ABTString("d:\\pvision 4.0\\data\\test.mpp");

      for (int i = 1; i < 12; i++) params[i] = ABTEmpty.getEmpty();

      application.invoke("FileOpen", params);

      ABTDispatch project = (ABTDispatch)application.getField("ActiveProject");
      ABTDispatch tasks   = (ABTDispatch)project.getField("Tasks");

      int count = tasks.getField("Count").intValue();

      for (int i = 1; i <= count; i++) {
         ABTDispatch task = (ABTDispatch)tasks.getDefault(i);

         System.out.println(task.getField("Name"));
         System.out.println(task.getField("Start"));
         System.out.println(task.getField("Finish"));

         task.release();
      }

      tasks.release();
      project.release();
      application.release();
   }

   public static void main(String argv[])
   {
      try {
         TestCOM test = new TestCOM();

         test.run();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}