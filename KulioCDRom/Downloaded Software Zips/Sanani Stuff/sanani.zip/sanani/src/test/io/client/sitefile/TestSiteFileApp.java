package test.io.client.sitefile;

import java.util.Enumeration;

import com.abtcorp.io.*;
import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTRepository;

import com.objectspace.jgl.ArrayIterator;

public class TestSiteFileApp implements IABTDriverConstants, IABTPMRuleConstants, IABTPropertyType
{
   private ABTString  repositoryName_    = null;
   private ABTString  projectExternalID_ = null;
   private ABTString  userName_          = null;
   private ABTString  productName_       = null;   
   private IABTDriver siteDriver_        = null;
   private IABTDriver lcldriver_         = null;
   private IABTObject site_              = null;
   private ABTObjectSpaceLocal space_    = null;   
   public  static final String PROD_PROJECTWORKBENCH	= "ABT Workbench".intern();
   
   public TestSiteFileApp(String[] args)
   {
      // initializations
      repositoryName_    = new ABTString("ABTRepository");
      projectExternalID_ = new ABTString("2.0.4N");
      productName_       = new ABTString(PROD_PROJECTWORKBENCH);
      userName_          = new ABTString("admin");
      
      if (args != null && args.length >	0) {
		 repositoryName_	= new ABTString(args[0]);

		 if	(args.length > 1) {
			projectExternalID_ = new ABTString(args[1]);
		 }
	  }

   }

   public void run()
   {
      ABTValue os  = null;        
      ABTError err = null;
      ABTValue val = null;

      System.out.println("\nTestSiteFileApp starting...");
      try
      {
         // create an object space and start an user seesion
         space_ = new ABTObjectSpaceLocal();
         space_.startSession(null);
         IABTObject siteObj = populateSite(space_);  
         System.out.println("\nPopulating Site from the repository has ended.");
	 
         System.out.println("\nTestSiteFileApp save local file.");
         lcldriver_ = space_.newABTDriver("com.abtcorp.io.client.sitefile.ABTIOSiteFileDriver", null);
        
         IABTHashTable argss = space_.newABTHashTable();	     
	     argss.putItemByString(KEY_DESTINATIONNAME, new ABTString("MarjanSite.lcl"));
	     argss.putItemByString(KEY_TYPE ,           new ABTString(TYPE_ALL));
	     argss.putItemByString(KEY_SOURCE,         (ABTValue)siteObj);	    
         System.out.println("\nTestSiteFileApp save to a local file.");
         lcldriver_.save(argss);

         System .out.println("\nTestSiteFileApp populate from a local file.");
         ABTObjectSpaceLocal space2 = new ABTObjectSpaceLocal();
         space2.startSession(null);
         IABTHashTable argp = space2.newABTHashTable();
    
         argp.putItemByString(KEY_SOURCENAME, new ABTString("MarjanSite.lcl"));
	     argp.putItemByString(KEY_TYPE ,      new ABTString(TYPE_ALL));
	     
         ABTValue value = lcldriver_.populate(argp);
         
         IABTObject siteObj2 = null;
         if (value instanceof IABTObject)
            siteObj2 = (IABTObject)value;
         

         
         IABTHashTable argss2 = space2.newABTHashTable();	    
	     argss2.putItemByString(KEY_DESTINATIONNAME, new ABTString("MarjanSite2.lcl"));
	     argss2.putItemByString(KEY_TYPE ,           new ABTString(TYPE_ALL));
	     argss2.putItemByString(KEY_SOURCE,         (ABTValue)siteObj2);	    
         System.out.println("\nTestSiteFileApp save to a local file.");
         lcldriver_.save(argss2);

      }
      
      catch (Exception e)
      {
         // exception caught, process error...
         if (e instanceof ABTException)
         {
            // if an ABTException, print the error info
            err = ((ABTException)e).getError();
            if (err!= null)
               processError(err);
         }
         System.out.println("\nException caught...printing stack trace...");
         e.printStackTrace();
      }
      
      finally
      {
         // clean up
         if (siteDriver_ != null)
            closeRepo(siteDriver_,space_);
            
         space_.endSession();         
      }
		System.out.println("\nTestSiteFileApp ended.");
   }

   private IABTObject populateSite(ABTObjectSpaceLocal space) throws ABTException
   {
      IABTObject obj = null;
      IABTHashTable args = space.newABTHashTable();
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
      
      siteDriver_ = space.newABTDriver("com.abtcorp.io.siterepo.ABTSiteRepoDriver",null);
          
         
      openRepo(siteDriver_, space);
    
      ABTValue val = siteDriver_.populate(args);
      
      if (ABTError.isError( val ) )
         throw new ABTException((ABTError) val);
      if (val instanceof IABTObject )
      {
         site_ = (IABTObject) val; 
         obj = site_;
      }
      else
         throw new ABTException("Site populate() failed and did not return a site object!");
     return obj;
   }
   
   

   private void openRepo(IABTDriver driver, ABTObjectSpaceLocal space) throws ABTException
   {
      IABTHashTable args = space.newABTHashTable();
      args.putItemByString(KEY_USERNAME, new ABTString("admin"));
      //args.putItemByString(KEY_PASSWORD, new ABTString("administrator"));
      
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_PRODUCT, new ABTString(productName_));
		if (driver.open(args) != (ABTValue)null ) 
		    throw new ABTException("Driver failed to open!");
   }
   
      
   private void closeRepo(IABTDriver driver, ABTObjectSpaceLocal space)
   {
      if (driver != null)
         driver.close( null);
   }


   //=======================================================================
   // print out the contents of an ABTError object
   //=======================================================================
   private void processError(ABTError err) 
   {
      System.out.println("\nERROR OCCURRED!!!");
      System.out.println("  Code: "      + err.getCode());
      System.out.println("  Component: " + err.getComponent());
      System.out.println("  Module: "    + err.getMethod());
      System.out.println("  Message: "   + err.getMessage());
      System.out.println("  Info: "      + err.getInfo().toString());
   }

   public static void main(String args[])
   {
      TestSiteFileApp app = new TestSiteFileApp(args);
      app.run();
   }

}