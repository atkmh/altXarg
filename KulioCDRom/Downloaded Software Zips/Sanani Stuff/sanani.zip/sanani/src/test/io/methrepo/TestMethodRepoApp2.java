package test.io.methrepo;

import java.util.Enumeration;

import com.abtcorp.io.*;
import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTRepository;
//import com.abtcorp.objectModel.abt.*;
//import com.abtcorp.objectModel.mm.*;
//import com.abtcorp.objectModel.mm.fr.*;

import com.objectspace.jgl.ArrayIterator;

public class TestMethodRepoApp2 implements ABTNames, IABTDriverConstants, IABTMMRuleConstants, IABTRuleConstants
{
   private String repositoryName_;
   private String product_;
   private ABTObjectSpaceLocal space_ = null;
   //private ABTObject site_ = null;
   private String server_ = null;
   private String user_ = null;
   private String password_ = null;
   private IABTDriver mdriver_ = null;
   private IABTDriver sdriver_ = null;
   private IABTObject site_ = null;

   public TestMethodRepoApp2(String[] args)
   {
      // initializations
      repositoryName_ = "RepoData";
      product_ = "ABT Planner";
      user_ = "lucy";
      password_ = "";

   }

   public void run()
   {
      ABTError err = null;
      ABTValue val = null;

      System.out.println("\nTestMethodRepoApp2 starting...");

      try
      {
         // create an object space and start an user seesion
         space_ = new ABTObjectSpaceLocal();
         
         err = space_.startSession(null);
         if (err!= null)
         {
            processError(err);
            return;
         }

			//test site driver.
			err = testSite();
         if (err!= null)
         {
            processError(err);
            return;
         }

			//open a method driver
			err = testOpen();
         if (err!= null)
         {
            processError(err);
            return;
         }

			//test method populate, save, etc.
			err = testMethod();
         if (err!= null)
         {
            processError(err);
            return;
         }
            
      }
      
      catch (Exception e)
      {
         // exception caught, process error...
         if (e instanceof ABTException)
         {
            // if an ABTException, print the error info
            err = ((ABTException)e).getError();
            if (err!= null)
               processError(err);
         }
         System.out.println("\nException caught...printing stack trace...");
         e.printStackTrace();
      }
      
      finally
      {
         // clean up
         if (mdriver_ != null)
            mdriver_.close(space_, null);
            
         if (sdriver_ != null)
            sdriver_.close(space_, null);
            
         space_.endSession();         
      }
		System.out.println("\nTestMethodRepoApp ended.");
   }


   //=======================================================================
   // instantiate a site repo driver, connect to the repository and
   // populate the site object
   //=======================================================================
   public ABTError testSite() throws ABTException
   {
      try
      {
         // instantiate a method repo driver 
       	sdriver_ = (IABTDriver) new ABTDriverLocal();
       	sdriver_.initialize(space_, "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
       	
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();
       	
       	// populate the hashtable with appropriate keys and values for open()       	
//    	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
    	   //args.putItemByString(KEY_REPONAME, new ABTString("RepoData"));
    	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
       	args.putItemByString(KEY_USERNAME, new ABTString(user_));
       	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

         System.out.println("\nConnecting to repository...");
         long startTime = System.currentTimeMillis();
         ABTValue val = sdriver_.open(space_, args);
         if (ABTError.isError(val))            return (ABTError)val;
         long endTime = System.currentTimeMillis();
         long elapseTime = endTime - startTime;
         System.out.println("\nConnect time = " + elapseTime + " milliseconds.");
         
         // populate the site
         System.out.println("\nPopulating site objects...");
       	args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
        
    	   args.putItemByString(KEY_SOURCENAME, new ABTString(repositoryName_));
         startTime = System.currentTimeMillis();
      	val = sdriver_.populate(space_, args);
      	if (ABTError.isError(val))      	   return (ABTError) val;
         endTime = System.currentTimeMillis();
         elapseTime = endTime - startTime;
         System.out.println("\nPopulate time for globals = " + elapseTime + " milliseconds.");
      	
      	site_ = (IABTObject)val;
      	
      	ABTError err = showSite(site_);
      	if (err != null)  return err;

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }
      return null;
   }

   private ABTError showSite(IABTObject site)
   {
      ABTError err = null;
      
      err = show(site, OFD_ID, OFD_NAME, OFD_CALENDARID);
      if (err != null)    return err;
   
      err = show(site, OFD_TYPECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CHARGECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CALENDARS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_TIMEPERIODS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ESTMODELS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ADJRULES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;

      err = show(site, OFD_RESOURCES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;

      //err = show(site, OFD_CUSTOMFIELDS, OFD_ID, OFD_NAME, null);
      err = showCustomFields(site);
      if (err != null)    return err;   

      // show site calendar
      System.out.println("\nScanning site calendar...");
      ABTValue val = site.getValue(OFD_STDCALENDAR);
      if (val instanceof  IABTObject)
         show ((IABTObject)val, OFD_ID, OFD_NAME, null);
      else
         return new ABTError("Test", "showSite()", "Invalid Data", "site calendar is not found.");

      return null;
   }


   private ABTError showCustomFields(IABTObject parent)
   {
      ABTError err = null;
    
      System.out.println("\nScanning custom fields...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(OFD_CUSTOMFIELDS);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of custom fields is 0.");
            return null;
         }
         else
            System.out.println("The total number of custom fields in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showCustomFields()", "Invalid Data", "CustomFields is not an obect set.");

      // getting custom fields and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;

         err = show(obj, OFD_AGGREGATEFIELDS, OFD_ID, OFD_SOURCEFIELDID, OFD_TARGETFIELDID);
         if (err != null)    return err;

         err = show(obj, OFD_CUSTOMENUMS, OFD_ID, OFD_FIELDID, OFD_VALUE);
         if (err != null)    return err;
         System.out.println(" ");         
         
      }      
      return null;
   }


   //=======================================================================
   // create some global objects to test save 
   //=======================================================================
   private ABTValue createNewGlobal(String type, IABTObject site)
   {
      ABTValue val = null;
      
      // create a new object 
      System.out.println("\nCreating new object " + type);
     	IABTHashTable parms = (IABTHashTable)new ABTHashTable();     	
     	parms.putItemByString(OFD_SITE, (ABTValue)site);      	
   	val = space_.createNewObject(type, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

   	IABTObject obj = (IABTObject) val;
   	
      // create some custom enums and agg fields for custom fields
      if (type.equals(OBJ_CUSTOMFIELD))
      {
         System.out.println("\nCreating new custom enum...");
      	parms.putItemByString(OFD_CUSTOMFIELD, (ABTValue) obj);      	
      	val = space_.createNewObject(OBJ_CUSTOMENUM, parms);
      	if (ABTError.isError(val))         return (ABTError)val;

         System.out.println("\nCreating new aggregate field...");
         val = space_.getObjects(OBJ_CUSTOMFIELD);
      	if (ABTError.isError(val))         return (ABTError)val;         
         parms.clear();
      	parms.putItemByString(OFD_TARGETFIELD, (ABTValue)((IABTObjectSet)val).at(0));      	
      	parms.putItemByString(OFD_SOURCEFIELD, (ABTValue)obj);      	
      	val = space_.createNewObject(OBJ_AGGREGATEFIELD, parms);
      	if (ABTError.isError(val))         return (ABTError)val;
   
         System.out.println(" ");
      }

      return (ABTValue)obj;
   }
   

   //=======================================================================
   // get a list of all the method names in the repository and populate them
   // into the object space.
   //=======================================================================
   public ABTError testMethod()
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      IABTObject method = null;
      ABTString extID = null;
      ABTError err = null;
      
      // create a hashtable for driver api
    	IABTHashTable args = (IABTHashTable)new ABTHashTable();
    	
      // get method list from repository. 
    	args.putItemByString(KEY_COMMAND,  new ABTString(CMD_LIST));
    	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
 	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

      ABTHashTable methodList = (ABTHashTable) mdriver_.execute(space_, args);

      // check error 
      if (ABTError.isError(val))            return (ABTError)val;

      // make sure the list is not empty
      if ((methodList == null) || methodList.isEmpty())
      {
         System.out.println("\nThe repository does not contain any method.");
         return null;
      }
      
      System.out.println("\nThe repository contains these methods:");

      // get external ids from the method list
      int i = 0;
      ABTArrayLocal extIDs = new ABTArrayLocal(space_);
      enum = methodList.getKeys();
      while (enum.hasMoreElements())
      {
         extIDs.add(new ABTString(enum.nextElement().toString()));
         System.out.println(extIDs.get(i));
         i++;
      }

      // test getUserName
    	args.putItemByString(KEY_COMMAND,  new ABTString(CMD_GETUSERNAME));
      ABTString userName = (ABTString) mdriver_.execute(space_, args);
      if (ABTError.isError(val))            return (ABTError)val;
      System.out.println("\nThe user's login name is " + userName.toString());


      // test thinly populate
      val = populateMethods(true, null);
      if (ABTError.isError(val))            return (ABTError)val;

      // test thickly populate 
//      val = populateMethods(false, "DB-SAMPLE");
      val = populateMethods(false, "RMM");
      if (ABTError.isError(val))            return (ABTError)val;
      
      oset = (IABTObjectSet) val;

/*
      // test create new
      val = createNewMethod();
   	if (ABTError.isError(val))      	   return (ABTError) val;
      
      method = (IABTObject) val;
      extID = (ABTString) method.getValue(OFD_EXTERNALID);
      // reprint method before save
      showMethodProps(method);
      err = showMethod(method);
      if (err != null)     return err;

      // test save as...
      System.out.println("\nSaving method " + extID + "...");
      args.clear();
    	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
    	args.putItemByString(KEY_SUBTYPE,  new ABTString(SUBTYPE_SAVEAS));
    	args.putItemByString(KEY_EXTID,  extID);
    	args.putItemByString(KEY_SOURCE, (ABTValue)method);
  	   args.putItemByString(KEY_DESTINATIONNAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
      val = mdriver_.save(space_, args);
   	if (ABTError.isError(val))            return (ABTError)val;
      System.out.println("End saving method as.");

      // reprint method after save
      showMethodProps(method);

      // test save...      
      System.out.println("\nSaving method...");
      args.clear();
    	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
    	//args.putItemByString(KEY_SOURCE, (ABTValue)method);
    	args.putItemByString(KEY_SOURCE, (ABTValue)oset);
  	   args.putItemByString(KEY_DESTINATIONNAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
      val = mdriver_.save(space_, args);
   	if (ABTError.isError(val))            return (ABTError)val;

      // test unlock....
      System.out.println("\nUnlocking method DB-SAMPLE...");
    	args.putItemByString(KEY_COMMAND, new ABTString(CMD_UNLOCK));
    	args.putItemByString(KEY_EXTID, new ABTString("DB-SAMPLE"));        
      val = mdriver_.execute(space_, args);
      if (ABTError.isError(val))            return (ABTError)val;
      System.out.println("End unlocking DB-SAMPLE.");

      // testing repopulate...
      val = populateMethods(false, "DB-SAMPLE");
      if (ABTError.isError(val))            return (ABTError)val;

*/
/*      
      // test deleting globals
      err = deleteObject(OBJ_MM_ASSIGNMENT);
      if (err != null)     return err;
      err = deleteObject(OBJ_RESOURCE);
      if (err != null)     return err;
      err = deleteObject(OBJ_MM_PAGEMEMBER);
      if (err != null)     return err;
      err = deleteObject(OBJ_CUSTOMFIELD);
      if (err != null)     return err;
      err = deleteObject(OBJ_MM_TASKESTIMATE);
      if (err != null)     return err;
      err = deleteObject(OBJ_ESTMODEL);
      if (err != null)     return err;
      err = deleteObject(OBJ_ADJRULE);
      if (err != null)     return err;

      System.out.println("\nShowing global objects...");
      showSite(site_);
      
*/
      return null;
   }


private ABTValue populateMethods(boolean thinly, String extID)
{
   ABTValue val = null;
   ABTError err = null;
   
 	IABTHashTable args = (IABTHashTable)new ABTHashTable();

   if (thinly)
   {
      System.out.println("\nPopulating methods thinly...");
    	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_METHODONLY));
   }
   else
      System.out.println("\nPopulating methods thickly...");

 	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
  	args.putItemByString(KEY_EXTID, new ABTString(extID));
   args.putItemByString(KEY_SOURCENAME, new ABTString(repositoryName_));
//   args.putItemByString(KEY_SOURCENAME, new ABTString("RepoData2"));
   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
 	args.putItemByString(KEY_USERNAME, new ABTString(user_));
 	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
 	if (!thinly)
    	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
  
   long startTime = System.currentTimeMillis();
   
	val = mdriver_.populate(space_, args);
	
   long endTime = System.currentTimeMillis();
   long elapseTime = endTime - startTime;
   System.out.println("\nPopulate time = " + elapseTime + " ms.");

   // if error, return
	if (ABTError.isError(val))      	   return (ABTError) val;

	// if succeeded, show the results
   IABTObjectSet oset = (IABTObjectSet) val;

   System.out.println("This method object set contains " + oset.size() + " objects.");
   System.out.println("Scanning method objects in object set...");
         
   for (int i = 0; i < oset.size(); i++)
   {
      IABTObject method = (IABTObject) oset.at(i);         
      if (thinly)
         err = showMethodProps(method);
      else
         err = showMethod(method);
      if (err != null)     return err;            
   }
      
   System.out.println(" ");
   return (ABTValue) oset;
}

private ABTError deleteObject(String type)
{
   System.out.println("Deleting objects of type " + type + " from the space...");         

	ABTValue val = space_.getObjects(type);
	if (ABTError.isError(val))         
	   return (ABTError)val;
	   
	if ((val instanceof IABTObjectSet) && (((IABTObjectSet)val).size() > 0))
	{
      System.out.println(((IABTObjectSet)val).size()+ " objects found in the space...");         
   
      IABTEnumerator e = ((IABTObjectSet)val).getElements();
      while( e.hasMoreElements() )
      {
         IABTObject object = (IABTObject)e.nextElement();
         val = object.delete();
         if( ABTError.isError( val ) )
            return (ABTError)val;
      }
	}
	else
      System.out.println("No object found in the space...");         
	
	return null;
}

   //=======================================================================
   // create some method to test save 
   //=======================================================================
   private ABTValue createNewMethod()
   {     
      ABTError err = null;
      ABTValue val = null;
      ABTValue site = null;
      
      // create some new globals 
     	// find the site object first
     	val = space_.findObject(OBJ_SITE, "ID > 0");
   	if (ABTError.isError(val))            	   return (ABTError)val;   	   
   	if (val instanceof IABTObjectSet)
   	{
   	   IABTObjectSet set = (IABTObjectSet) val;
   	   site = set.at(0);
      	if (ABTError.isError(site))        	   return (ABTError)site;
   	}

      val = createNewGlobal(OBJ_RESOURCE, (IABTObject)site);
   	if (ABTError.isError(val))            	   return (ABTError)val;   	   
   	IABTObject newRes = (IABTObject)val;

      val = createNewGlobal(OBJ_CUSTOMFIELD, (IABTObject)site);
   	if (ABTError.isError(val))            	   return (ABTError)val;   	   
   	IABTObject newCust = (IABTObject)val;
      
      val = createNewGlobal(OBJ_ESTMODEL, (IABTObject)site);
   	if (ABTError.isError(val))            	   return (ABTError)val;   	   
   	IABTObject newEst = (IABTObject)val;

      // create a new method
      System.out.println("\nCreating new method... ");
   	val = space_.createNewObject(OBJ_MM_METHOD, null);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

      // reset ext id
   	IABTObject newMethod = (IABTObject) val;
   	
      val = newMethod.getValue(OFD_EXTERNALID);
   	if (ABTError.isError(val))
         return (ABTError)val;
      String extID = val.stringValue().substring(0,15);
      val = newMethod.setValue(OFD_EXTERNALID, new ABTString(extID));
   	if (ABTError.isError(val))
         return (ABTError)val;
      
      // create some tasks, dependencies and deliverables for this method
   	err = createNewTasks(newMethod, newRes, newEst);
      if (err != null)    return err;

      err = createNewPages(newMethod, newCust);
      if (err != null)    return err;
      
      err = createNewPackages(newMethod);
      if (err != null)    return err;
      
      return (ABTValue)newMethod;
   }


   //=======================================================================
   // print out the method properties and the associated objects/object sets
   //=======================================================================
   private ABTError showMethod(IABTObject method)
   {
      ABTError err = null;
      
      System.out.println("\nDisplaying method...");

      err = show(method, OFD_ID, OFD_EXTERNALID, OFD_ISFULLYPOPULATED);
      if (err != null)    return err;

      ABTValue task = method.getValue(OFD_FIRSTCHILDTASK);
      if (task instanceof IABTObject)
      {
         ABTValue name = ((IABTObject) task).getValue(OFD_NAME);
         System.out.println("The first child task is " + name.toString());
      }

      task = method.getValue(OFD_LASTCHILDTASK);
      if (task instanceof IABTObject)
      {
         ABTValue name = ((IABTObject) task).getValue(OFD_NAME);
         System.out.println("The last child task for this method is " + name.toString());
      }

      err = displayTaskHierarchy(method);
      if (err != null)    return err;
  
      err = show(method, OFD_ALLPACKAGES, OFD_ID, OFD_NAME, OFD_METHODID);
      if (err != null)    return err;

      err = show(method, OFD_ALLPACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_PACKAGEID);
      if (err != null)    return err;
      /*
      err = moveTasks(method);
      if (err != null)    return err;
      

      // create some tasks for this method
   	err = createNewTasks(method);
      if (err != null)    return err;
      
      err = showTasks(method, OFD_ALLTASKS);
      if (err != null)    return err;

      err = showDeliverables(method, OFD_ALLDELIVERABLES);
      if (err != null)    return err;      

      err = showPages(method, OFD_ALLPAGES);
      if (err != null)    return err;
            
      err = show(method, OFD_ALLPAGEMEMBERS, OFD_ID, OFD_PAGEID, OFD_SEQUENCE);
      if (err != null)    return err;

      err = show(method, OFD_ALLPACKAGES, OFD_ID, OFD_NAME, OFD_METHODID);
      if (err != null)    return err;

      err = show(method, OFD_PACKAGES, OFD_ID, OFD_NAME, OFD_RECCONDITION);
      if (err != null)    return err;

      err = show(method, OFD_RECRULES, OFD_ID, OFD_NAME, OFD_RECCONDITION);
      if (err != null)    return err;

      err = show(method, OFD_ALLASSIGNMENTS, OFD_ID, OFD_TASKID, OFD_RESOURCEID);
      if (err != null)    return err;
      
      err = show(method, OFD_ALLDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
      if (err != null)    return err;
      
      err = show(method, OFD_ALLTASKESTIMATES, OFD_ID, OFD_FORMULA, OFD_TASKID);
      if (err != null)    return err;
      
      err = show(method, OFD_ALLPACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_PACKAGEID);
      if (err != null)    return err;
      
*/      
  
      System.out.println(" ");
      return null;
   }


   private ABTError showMethodProps(IABTObject method)
   {
      ABTError err = null;
      
      System.out.println("\nDisplaying method...");

      err = show(method, OFD_EXTERNALID, OFD_READONLYRIGHT, OFD_LOCKEDBY);
      if (err != null)    return err;
      err = show(method, OFD_LOCKEDBYME, OFD_REPONAME, OFD_ISFULLYPOPULATED);
      if (err != null)    return err;
      
      return null;
   }
   
   private ABTError createNewPages(IABTObject method, IABTObject newCust)
   {
      // create some new object 
      System.out.println("\nCreating new page...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);
   	
   	ABTValue val = space_.createNewObject(OBJ_MM_PAGE, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject page = (IABTObject) val;
      
      val = page.setValue(OFD_SEQUENCE, new ABTInteger(1));
   	if (ABTError.isError(val))         return (ABTError)val;

      createNewObject(OBJ_MM_PAGEMEMBER, OFD_PAGE, page, OFD_CUSTOMFIELD, newCust);
   	if (ABTError.isError(val))         return (ABTError)val;
      
      return null;
   }
   
   private ABTError createNewPackages(IABTObject method)
   {
      // create some new object 
      System.out.println("\nCreating new package...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);
   	parms.putItemByString(OFD_HIDDEN, new ABTBoolean(true));
   	
   	ABTValue val = space_.createNewObject(OBJ_MM_PACKAGE, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject pkg = (IABTObject) val;
      
      return null;
   }
   

   //=======================================================================
   // create some tasks to test the save logic
   //=======================================================================
   private ABTError createNewTasks(IABTObject method, IABTObject newRes, IABTObject newEst)
   {
      // create some new task to test save() 
      System.out.println("\nCreating new task...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);
   	
   	ABTValue val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))         return (ABTError)val;
     	IABTObject task1 = (IABTObject) val;
     	
   	val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))         return (ABTError)val;
     	IABTObject task2 = (IABTObject) val;
   	
   	val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))         return (ABTError)val;
     	IABTObject task3 = (IABTObject) val;
     	     	
      createNewObject(OBJ_MM_ASSIGNMENT, OFD_TASK, task1, OFD_RESOURCE, newRes );
   	if (ABTError.isError(val))         return (ABTError)val;

      createNewObject(OBJ_MM_ASSIGNMENT, OFD_TASK, task2, OBJ_RESOURCE, OFD_RESOURCE, "ExternalID = 'DBA'" );
   	if (ABTError.isError(val))         return (ABTError)val;
   	
      createNewObject(OBJ_MM_TASKESTIMATE, OFD_TASK, task1, OFD_ESTMODEL, newEst );
   	if (ABTError.isError(val))         return (ABTError)val;
   	
      createNewObject(OBJ_MM_TASKESTIMATE, OFD_TASK, task2, OBJ_ESTMODEL, OFD_ESTMODEL, "Name = 'DB-Top Down'" );
   	if (ABTError.isError(val))         return (ABTError)val;
   	
/*   	
      // create some dependencies
      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task1);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task2);

      System.out.println("\nCreating new dependency...");
   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

      // create some deliverables
      System.out.println("\nCreating new deliverables...");
    	parms.clear();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);
   	
   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;
     	IABTObject deliv1 = (IABTObject) val;
     	
   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;
     	IABTObject deliv2 = (IABTObject) val;

   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;
     	IABTObject deliv3 = (IABTObject) val;

      // create some task-deliv links
     	val = task1.getValue(OFD_DELIVERABLES);
   	if (ABTError.isError(val))            	   return (ABTError)val;
   	if (val instanceof IABTObjectSet)
   	{
         System.out.println("\nLinking deliverables to a task...");
   	   IABTObjectSet set = (IABTObjectSet) val;
      	set.add(deliv1);
     	   set.add(deliv2);
     	   set.add(deliv3);
      	val = task1.setValue(OFD_DELIVERABLES, (ABTValue) set);
      	if (ABTError.isError(val))            	   return (ABTError)val;
   	}
     	val = deliv3.getValue(OFD_TASKS);
   	if (ABTError.isError(val))            	   return (ABTError)val;
   	
   	if (val instanceof IABTObjectSet)
   	{
         System.out.println("\nLinking tasks to a deliverable...");
   	   IABTObjectSet set = (IABTObjectSet) val;
      	set.add(task2);
     	   set.add(task3);
      	val = deliv3.setValue(OFD_TASKS, (ABTValue) set);
      	if (ABTError.isError(val))            	   return (ABTError)val;
      }
*/      
      return null;
   }

   private ABTError createNewObject(String type, String refField, IABTObject refObj, String globalType, String globalField, String searchStr )
   {
   	ABTValue val = space_.findObject(globalType, searchStr);
   	if (ABTError.isError(val))            	   return (ABTError)val;
   	   
   	if (val instanceof IABTObjectSet)
   	{
   	   IABTObjectSet set = (IABTObjectSet) val;
   	   val = set.at(0);
      	if (ABTError.isError(val))            	   return (ABTError)val;
   	}
   	if (ABTValue.isNull(val))
         return new ABTError("Test", "createNewObj()", "Invalid Data", globalType + " empty or null.");
      ABTValue global = val;
      
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
      if (globalField != null)
      	parms.putItemByString(globalField, global);
      if (refField != null)
      	parms.putItemByString(refField, (ABTValue)refObj);
   	
   	val = space_.createNewObject(type, parms);
   	if (ABTError.isError(val))         return (ABTError)val;
   	
   	return null;
   }

   private ABTError createNewObject(String type, String refField, IABTObject refObj, String globalField, IABTObject globalObj )
   {
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
      if (globalField != null)
      	parms.putItemByString(globalField, (ABTValue)globalObj);
      if (refField != null)
      	parms.putItemByString(refField, (ABTValue)refObj);
   	
   	ABTValue val = space_.createNewObject(type, parms);
   	if (ABTError.isError(val))         return (ABTError)val;
   	
   	return null;
   }


   //=======================================================================
   // print out the task properties and the associated objects/object sets
   //=======================================================================
   private ABTError showTasks(IABTObject parent, String field)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + field + "...");
      
      IABTObjectSet taskoset = ( IABTObjectSet) parent.getValue(field);
      if (taskoset instanceof  IABTObjectSet)
      {
         if (taskoset.size() == 0)
         {
            System.out.println("The total number of tasks is 0.");
            return null;
         }
         else
            System.out.println("The total number of tasks in set = " +(( IABTObjectSet) taskoset).size());
      }
      else
         return new ABTError("Test", "showTasks()", "Invalid Data", field + " is not an obect set.");

      // getting tasks and their contents
      for (int j = 0; j < taskoset.size(); j++)
      {
         IABTObject task = (IABTObject) taskoset.at(j);
         
         err = show(task, OFD_ID, OFD_EXTERNALID, OFD_GUIDELINE_URL);
         if (err != null)    return err;


/*
         // test delete
         System.out.println("Removing task deliverable links... ");
        	ABTValue val = task.getValue(OFD_DELIVERABLES);
      	if (ABTError.isError(val))            	   return (ABTError)val;
      	IABTObjectSet delivs = (IABTObjectSet)val;
      	int m = delivs.size();
         for (int k = 0; k < m; k++)
         {
            val = delivs.removeAt(0);
         	if (ABTError.isError(val))            	   return (ABTError)val;
         }
         
         System.out.println("After task deliverable links removed... ");
         err = show(task, OFD_DELIVERABLES, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;
         
*/         

/*
         err = show(task, OFD_PARENTTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_FIRSTCHILDTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_LASTCHILDTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_PREVIOUSTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_NEXTTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;


         err = show(task, OFD_DELIVERABLES, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;

         err = show(task, OFD_PREDDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
         if (err != null)    return err;

         err = show(task, OFD_SUCCDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
         if (err != null)    return err;

         err = show(task, OFD_TASKESTIMATES, OFD_ID, OFD_TASKID, OFD_ESTMODELID);
         if (err != null)    return err;

         err = show(task, OFD_ASSIGNMENTS, OFD_ID, OFD_TASKID, OFD_RESOURCEID);
         if (err != null)    return err;

         err = show(task, OFD_PACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_RECORDID);
         if (err != null)    return err;
*/
         System.out.println(" ");         
         
         /*
         // temp code to test delete
         ABTInteger id = (ABTInteger) task.getValue(OFD_ID);
         if (id.intValue() == 3)
            task.delete();
         */
      }
      
      return null;
   }

   //=======================================================================
   // print out the deliverable properties and the associated tasks
   //=======================================================================
   private ABTError showDeliverables(IABTObject parent, String field)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + field + "...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(field);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of deliverables is 0.");
            return null;
         }
         else
            System.out.println("The total number of deliverables in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showDeliverables()", "Invalid Data", field + " is not an obect set.");

      // getting delivs and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;

/*
         err = show(obj, OFD_TASKS, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;

         // test delete
         System.out.println("Removing task deliverable links... ");
        	ABTValue val = obj.getValue(OFD_TASKS);
      	if (ABTError.isError(val))            	   return (ABTError)val;
      	IABTObjectSet tasks = (IABTObjectSet)val;
         for (int k = 0; k < tasks.size(); k++)
         {
            IABTObject task = (IABTObject) tasks.at(k);
            val = tasks.remove(task);
         	if (ABTError.isError(val))            	   return (ABTError)val;
         }
         
         System.out.println("After task deliverable links removed... ");
         err = show(obj, OFD_TASKS, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;
         //err = show(obj, OFD_PACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_RECORDID);
         //if (err != null)    return err;
*/
         System.out.println(" ");
      }
      
      return null;
   }

   private ABTError showPages(IABTObject parent, String field)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + field + "...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(field);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of page is 0.");
            return null;
         }
         else
            System.out.println("The total number of pages in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showPages()", "Invalid Data", field + " is not an obect set.");

      // getting pages and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;

         //err = show(obj, OFD_PAGEMEMBERS, OFD_ID, OFD_SEQUENCE, null);
         //if (err != null)    return err;
         
         ABTValue val = obj.getValue(OFD_PAGEMEMBERS);
         if (val instanceof ABTError)  return (ABTError) val;
         
         if (val instanceof IABTObjectSet)
         {
            IABTObjectSet mbrs = (IABTObjectSet)val;
            Enumeration e = mbrs.getElements();
            
            System.out.println("Displaying and deleting page members...");            
            while( e.hasMoreElements() )
            {
               IABTObject mbr = (IABTObject)e.nextElement();
               err = show(mbr, OFD_ID, OFD_SEQUENCE, null);
               if (err != null)    return (ABTError) err;
               val = mbr.delete();
               if( ABTError.isError( val ) )       return (ABTError)val;
            }
         }
         
      }
      
      return null;
   }

   private ABTError showList(IABTObject parent, String list, String nameField, String refField1, String nameField1, String refField2, String nameField2)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + list + "...");
      
      IABTObjectSet oset = (IABTObjectSet) parent.getValue(list);
      if (oset instanceof  IABTObjectSet)
         System.out.println("The total number of objects in set = " +(( IABTObjectSet) oset).size());
      else
         return new ABTError("Test", "showList()", "Invalid Data", list + " is not an obect set.");

      // iterate thru the object set
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, nameField, null);
         if (err != null)    return err;

         ABTValue val = obj.getValue(refField1);
         if (ABTError.isError(val))  
            return (ABTError) val;         
         else if (val instanceof IABTObject)
         {
            err = show((IABTObject)val, OFD_ID, nameField1, null);
            if (err != null)    return err;
         }
         
         val = obj.getValue(refField2);
         if (ABTError.isError(val))  
            return (ABTError) val;         
         else if (val instanceof IABTObject)
         {
            err = show((IABTObject)val, OFD_ID, nameField2, null);
            if (err != null)    return err;
         }
         
         System.out.println(" ");
      }
      
      return null;
   }

   //=======================================================================
   // Retrieve an object or an object set specified by "field" from the "parent" object
   // and print out the values in "field".
   //=======================================================================
   private ABTError show(IABTObject parent, String field, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTError err = null;

      val1 = parent.getValue(field);

      if (ABTValue.isNull(val1))
         System.out.println("\n" + field + ":  null or empty ");

      else if (val1 instanceof  IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) val1;
         
         System.out.println("\n" + field + ":  total number of objects in set = " + oset.size());
         
         if (oset.size() > 0)
         {
            for (int j = 0; j < oset.size(); j++)
            {
               IABTObject object = (IABTObject) oset.at( j);
               err = show (object, field1, field2, field3);
               if (err != null)
                  return err;
            }
         }
      }
      else if (val1 instanceof  IABTObject)
      {
         IABTObject object = (IABTObject) val1;
         System.out.println("\n" + field + ": ");         
         err = show (object, field1, field2, field3);
         if (err != null)
            return err;
      }
      else
         System.out.println( "\n" + field + " is not an object set or an object.");
         
      return null;
   }

   //=======================================================================
   // print out the property values of the input object
   //=======================================================================
   private ABTError show(IABTObject object, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTValue val3 = null;

      if (object == null)
         return new ABTError ("Test", "show()", "Invalid Data", "The input object is null");
      
      String type = pad (object.getObjectType() + ":", 22);
       ABTValue val = object.getValue("ABTRemoteID");
      if (ABTError.isError(val))
         return (ABTError)val;
      if (val instanceof ABTRemoteIDRepository)
         System.out.print( type + " RepoID = " + ((ABTRemoteIDRepository)val).getRepositoryID() + ",  ");
      else
         System.out.println(type + " RemoteID = null or empty ");
         
     if (field1 != null)
      {
         val1 = object.getValue(field1);
         if (ABTError.isError(val1))
            return (ABTError)val1;
         if (ABTValue.isNull(val1))
            System.out.println(field1 + ":  null or empty ");
         else
            System.out.print(field1 + " = " + val1.toString() + ",  ");
      }
         
      if (field2 != null)
      {
         val2 = object.getValue(field2);
         if (ABTError.isError(val2))
            return (ABTError)val2;
         if (ABTValue.isNull(val2))
            System.out.println(field2 + ":  null or empty ");
         else
            System.out.print(field2 + " = " + val2.toString() + ", ");
      }
      
      if (field3 != null)
      {
         val3 = object.getValue(field3);
         if (ABTError.isError(val3))
            return (ABTError)val3;
         if (ABTValue.isNull(val3))
            System.out.println(field3 + ":  null or empty ");
         else
            System.out.print(field3 + " = " + val3.toString());
      }
      
      System.out.println(" ");
      
      return null;
   }
   
   private String pad(String str, int maxlen)
   {
      String newStr = str;
      
      str.trim();
      for (int i=str.length(); i<maxlen; i++)
         newStr = newStr.concat(" ");
         
      return newStr;
   }

   //=======================================================================
   // instantiate a methodology repo driver and connect to the repository
   //=======================================================================
   public ABTError testOpen() 
   {
      ABTValue val = null;

      // instantiate a method repo driver 
    	mdriver_ = (IABTDriver) new ABTDriverLocal();
    	mdriver_.initialize(space_, "com.abtcorp.io.methrepo.ABTMMRepoDriver", null);
    	
      // create a hashtable for driver api
    	IABTHashTable args = (IABTHashTable)new ABTHashTable();
    	
    	// populate the hashtable with appropriate keys and values for open()
// 	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

      System.out.println("\nConnecting to " + repositoryName_ + "...");
      long startTime = System.currentTimeMillis();
      val = mdriver_.open(space_, args);
      if (ABTError.isError(val))                     return (ABTError)val;
      long endTime = System.currentTimeMillis();
      long elapseTime = endTime - startTime;
      System.out.println("\nConnect time = " + elapseTime + " milliseconds.");
         
      return null;         
   }
 
      
   private ABTError displayTaskHierarchy(IABTObject method)
   {
      System.out.println("\n* * * * Task Hierarchy Display * * * *");

      ABTValue v = method.getValue(OFD_ALLTASKS);
      if ( ABTError.isError( v ) )  return (ABTError) v;

      if (v instanceof IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) v;
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject taskObj = (IABTObject) oset.at(i);
            int WBSLevel = taskObj.getValue(OFD_WBSLEVEL).intValue();
            int seq = taskObj.getValue(OFD_WBSSEQUENCE).intValue();
            String indentation = getIndentation(WBSLevel);
            String taskName = taskObj.getValue(OFD_NAME).toString();
            if (taskName.length() == 0)
               taskName = "(Unknown task name)";
            System.out.println(indentation + seq + "). " + taskName.toString());
         }
      }
      return null;
   }

   private ABTError moveTasks(IABTObject method)
   {
      System.out.println("Moving tasks....");

      ABTValue v = method.getValue(OFD_ALLTASKS);
      if ( ABTError.isError( v ) )  return (ABTError) v;

      if (v instanceof IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) v;
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject taskObj = (IABTObject) oset.at(i);

            int WBSLevel = taskObj.getValue(OFD_WBSLEVEL).intValue();
            
            // moving the 1st task found on level 3 to level 2.
            if (WBSLevel == 3)
            {
               v = taskObj.getValue(OFD_PARENTTASK);
               if ( ABTError.isError( v ) )  return (ABTError) v;
               IABTObject parent1 = (IABTObject) v;
               
               v = parent1.getValue(OFD_PARENTTASK);
               if ( ABTError.isError( v ) )  return (ABTError) v;
               IABTObject parent2 = (IABTObject) v;
               
               v = taskObj.setValue(OFD_PARENTTASK, (ABTValue)parent2);
               if ( ABTError.isError( v ) )  return (ABTError) v;

               break;               
            }
/*            
            // moving the 1st task found on level 2 to level 1.
            if (WBSLevel == 2)
            {
               v = method.setValue(OFD_LASTCHILDTASK, (ABTValue)taskObj);
               if ( ABTError.isError( v ) )  return (ABTError) v;

               break;               
            }
*/            
         }
      }
      return null;
   }
   
   private String getIndentation(int WBSLevel)
   {
      StringBuffer sb = new StringBuffer(5*WBSLevel); // allow enough room for all spaces
      
      for (int i = 0; i < WBSLevel; i++)
         sb.append("     ");     // allow 5 blanks for each indentation level
      return sb.toString();
   }
      

   //=======================================================================
   // print out the contents of an ABTError object
   //=======================================================================
   private void processError(ABTError err) 
   {
      System.out.println("\nERROR OCCURRED!!!");
      System.out.println("  Package:   " + err.getPackage());
      System.out.println("  Component: " + err.getComponent());
      System.out.println("  Method:    " + err.getMethod());
      System.out.println("  Message:   " + err.getMessage());
      
      Object info = err.getInfo();
      if (info instanceof ABTArrayLocal)
      {
         ABTArrayLocal ar = (ABTArrayLocal) info;
         for (int i=0; i<ar.size(); i++)
         {
            ABTValue val = ar.get(i);
            if (val instanceof IABTObject)
            {
               IABTObject obj = (IABTObject)val;
               String type = obj.getObjectType();
               if (type == OBJ_RESOURCE)
                  val = obj.getValue(OFD_EXTERNALID);
               else
                  val = obj.getValue(OFD_NAME);                  
               System.out.println("  Info:      " + type + " = " + val.toString());            
            }
         }
      }
      else
         System.out.println("  Info:      " + info.toString());
   }

   public static void main(String args[])
   {
      TestMethodRepoApp2 app = new TestMethodRepoApp2(args);
      app.run();
   }

}