package test.io.methrepo;
import java.util.Enumeration;
import com.abtcorp.io.*;
import com.abtcorp.idl.*;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTRuleConstants;
import java.io.*;
import com.abtcorp.api.local.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTRepository;
//import com.abtcorp.objectModel.mm.fr.*;

import com.objectspace.jgl.ArrayIterator;
import com.abtcorp.core.ABTException;
import com.abtcorp.hub.*;
import com.abtcorp.blob.*;


public class LeeMethDriver implements ABTNames, IABTDriverConstants, IABTPropertyType, IABTRuleConstants, IABTMMRuleConstants
{
   private String repositoryName_;
   private String product_;
   private ABTObjectSpaceLocal space_ = null;
   private String server_ = null;
   private String user_ = null;
   private String password_ = null;
   private IABTDriver mdriver_ = null;
   private IABTDriver sdriver_ = null;
   private String projectExternalID_;
   private boolean outToFile_ ;
   private String outputFileName_ ;

   //private ABTUserSession userSession_;
   private   IABTObjectSet oset = null;
   private PrintWriter pStr = null;   
   public LeeMethDriver(String[] args)
   {
      // initializations
      repositoryName_ = "Anne";
      product_ = "ABT Planner";
      user_ = "arthur";
      password_ = "";
      projectExternalID_ = "101";
      outToFile_ = false;      
      outputFileName_ = null;      
      
      if (args != null && args.length > 0) {
         repositoryName_ = args[0];

         if (args.length > 1) {
            projectExternalID_ = args[1];
         }
             if (args.length > 2) {
                outToFile_ = true;
                outputFileName_ = args[2];           
             }
      }

   }

   public void run()
   {
      ABTError err = null;
      ABTValue val = null;

      System.out.println("\nLeeMethDriver starting...");

      try
      {
        if (outputFileName_ != null) {
            System.out.println("Opening output file.");
            pStr = new PrintWriter(new BufferedOutputStream(new FileOutputStream(outputFileName_)));
        }

         // create an object space and start an user seesion
         space_ = new ABTObjectSpaceLocal();

         err = space_.startSession(null);
         if (err != null)
         {
            processError(err);
            return;
         }

//test site driver.
	
			err = testSite();
         if (err!= null){
            processError(err);
            return;
          }

//make an MM driver
   			err = setDriver();
         if (err!= null){
            processError(err);
            return;
          }
//test method populate
        err = testMethod();
        if (err!= null){
            processError(err);
        }
      }

      catch (Exception e)
      {
         // exception caught, process error...
         if (e instanceof ABTException)
         {
            // if an ABTException, print the error info
            err = ((ABTException)e).getError();
            if (err!= null)
               processError(err);
         }
         System.out.println("\nException caught...printing stack trace...");
         e.printStackTrace();
      }

      finally
      {
         // clean up
         mdriver_.close(space_, null);
         sdriver_.close(space_, null);
                if (pStr != null) {
                    System.out.println("closing output file.");
                    pStr.close();
                } 
                else                 
                    System.out.println("Output sent to screen");                
         
         space_.endSession();
      }
		System.out.println("\nLeeMethDriver ended.");
   }


   //=======================================================================
   // instantiate a site repo driver, connect to the repository and
   // populate the site object
   //=======================================================================
   public ABTError testSite() throws ABTException
   {
      try
      {
         // instantiate a method repo driver 
       	sdriver_ = (IABTDriver) new ABTDriverLocal();
       	sdriver_.initialize(space_, "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
       	
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();
       	
       	// populate the hashtable with appropriate keys and values for open()
    	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
    	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
       	args.putItemByString(KEY_USERNAME, new ABTString(user_));
       	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

         ABTValue val = sdriver_.open(space_, args);
         if (ABTError.isError(val))            return (ABTError)val;
         
         // populate the site
         System.out.println("\nPopulating site objects...");
       	args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
        
      	val = sdriver_.populate(space_, args);
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
      	// if succeeded, show the results
         IABTObject site = (IABTObject) val;
         System.out.println("Scanning site object...");
            if(outToFile_)
            propertyPrint(site,"\nSITE");         
            else
            propertyScreen(site,"\nSITE");
//         ABTError err = showSite(site);
//         if (err != null)     return err;

         
         // test create new....
/*         val = createNewGlobal(OBJ_RESOURCE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
            
         val = createNewGlobal(OBJ_ESTMODEL, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
         
         val = createNewGlobal(OBJ_ADJRULE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
         
         val = createNewGlobal(OBJ_CUSTOMFIELD, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
         
         val = createNewGlobal(OBJ_TYPECODE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
         
         val = createNewGlobal(OBJ_CHARGECODE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
         
         val = createNewGlobal(OBJ_TIMEPERIOD, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
         
         val = createNewGlobal(OBJ_CALENDAR, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
*/        
         // test save...
/*         System.out.println("\nSaving site objects...");
       	args.putItemByString(KEY_SOURCE, (ABTValue)site);
      	val = sdriver_.save(space_, args);  // use previous args
      	if (ABTError.isError(val))      	   return (ABTError) val;
*/      	
      	
      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }
      return null;
   }
      //=======================================================================
   // Retrieve an object or an object set specified by "field" from the "parent" object
   // and print out the values in "field".
   //=======================================================================
/*   private ABTError show(IABTObject parent, String field, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTError err = null;

      val1 = parent.getValue(field);

      if (ABTValue.isNull(val1))
         System.out.println("\n" + field + ":  null or empty ");

      else if (val1 instanceof  IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) val1;
         
         System.out.println("\n" + field + ":  total number of objects in set = " + oset.size());
         
         if (oset.size() > 0)
         {
            for (int j = 0; j < oset.size(); j++)
            {
               IABTObject object = (IABTObject) oset.at( j);
               err = show (object, field1, field2, field3);
               if (err != null)
                  return err;
            }
         }
      }
      else if (val1 instanceof  IABTObject)
      {
         IABTObject object = (IABTObject) val1;
         System.out.println("\n" + field + ": ");         
         err = show (object, field1, field2, field3);
         if (err != null)
            return err;
      }
      else
         System.out.println( "\n" + field + " is not an object set or an object.");
         
      return null;
   }


   private ABTError showSite(IABTObject site)
   {
      ABTError err = null;
      
      err = show(site, OFD_ID, OFD_NAME, OFD_CALENDARID);
      if (err != null)    return err;
   
      err = show(site, OFD_TYPECODES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CHARGECODES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CALENDARS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_TIMEPERIODS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ESTMODELS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ADJRULES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;

      err = show(site, OFD_RESOURCES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;

      err = show(site, OFD_CUSTOMFIELDS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;

      // show site calendar
      System.out.println("\nScanning site calendar...");
      ABTValue val = site.getValue(OFD_STDCALENDAR);
      if (val instanceof  IABTObject)
         show ((IABTObject)val, OFD_ID, OFD_NAME, null);
      else
         return new ABTError("Test", "showSite()", "Invalid Data", "site calendar is not found.");

      return null;
   }

   //=======================================================================
   // print out the property values of the input object
   //=======================================================================
   private ABTError show(IABTObject object, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTValue val3 = null;

      if (object == null)
         return new ABTError ("Test", "show()", "Invalid Data", "The input object is null");
      
      if (field1 != null)
      {
         val1 = object.getValue(field1);
         if (ABTError.isError(val1))
            return (ABTError)val1;
         if (ABTValue.isNull(val1))
            System.out.println(field1 + ":  null or empty ");
         else
            System.out.print(field1 + " = " + val1.toString() + ";  ");
      }
         
      if (field2 != null)
      {
         val2 = object.getValue(field2);
         if (ABTError.isError(val2))
            return (ABTError)val2;
         if (ABTValue.isNull(val2))
            System.out.println(field2 + ":  null or empty ");
         else
            System.out.print(field2 + " = " + val2.toString() + "; ");
      }
      
      if (field3 != null)
      {
         val3 = object.getValue(field3);
         if (ABTError.isError(val3))
            return (ABTError)val3;
         if (ABTValue.isNull(val3))
            System.out.println(field3 + ":  null or empty ");
         else
            System.out.print(field3 + " = " + val3.toString() + "; ");
      }
      
      System.out.println(" ");
      
      return null;
   }

*/

   public ABTError testMethod() throws ABTException
   {
//      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;

      try
      {

         // create a hashtable for method populate
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();


         // get method list from repository.
       	args.putItemByString(KEY_COMMAND,  new ABTString(CMD_LIST));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));

        ABTHashTable methodList = (ABTHashTable) mdriver_.execute(space_, (IABTHashTable) args);

         // check error
         if (ABTError.isError(val))            return (ABTError)val;

         // make sure the list is not empty
         if ((methodList == null) || methodList.isEmpty())
         {
            System.out.println("\nThe repository does not contain any method.");
            return null;
         }

         System.out.println("\nThe repository contains these methods:");

         // get external ids from the method list
         int i = 0;
         extIDs = new ABTArray();
         enum = methodList.getElements();
         while (enum.hasMoreElements())
         {
            //extIDs.put(i, (ABTValue)enum.nextElement());
            System.out.println(enum.nextElement());
            
            //System.out.println(extIDs.at(i));
            i++;
         }

         // populate a single method (using external ID to find it)

      System.out.println("\nPopulating methods with lock...");
      args.clear();
    	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
    	//if no method external ID specified, get all methods
//    	if (projectExternalID_ == null)
//         	args.putItemByString(KEY_EXTIDS, extIDs);  
//        else
     	    args.putItemByString(KEY_EXTID, new ABTString(projectExternalID_));
    	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
    	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
  	   args.putItemByString(KEY_SOURCENAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
     
      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This method object set contains " + oset.size() + " objects.");
         System.out.println("Scanning method objects in object set...");
         for (i = 0; i < oset.size(); i++)
         {
            IABTObject method = (IABTObject) oset.at(i);
//            method.setValue(OFD_NAME, new ABTString("newName"));
 //           method.setValue(OFD_GUIDELINES, new ABTString("newGuidelines"));

            if(outToFile_)
            propertyPrint(method,"\nMETHOD");         
            else
            propertyScreen(method,"\nMETHOD");

//TASKS
                 ABTValue taskVal = method.getValue(OFD_ALLTASKS);
                 IABTObjectSet taskoset = (IABTObjectSet)taskVal;
                 if (taskoset.size()> 0)
                 {
//                    for (int j = 0; j < taskoset.size(); j++)
                    for (int j = 0; j < 10; j++)
                    {
                        IABTObject taskObj = (IABTObject) taskoset.at(j);
//                        taskObj.setValue(OFD_NAME, new ABTString( "newTaskName"));
                        if(outToFile_)
                        propertyPrint(taskObj,"\nTASK");         
                        else
                        propertyScreen(taskObj,"\nTASK");
                        
                    }

                 }
                 else {System.out.println("\nNO TASKS FOR THIS METHOD");}
//DELIVERABLES
                 ABTValue delivVal = method.getValue(OFD_ALLDELIVERABLES);
                 IABTObjectSet delivoset = (IABTObjectSet)delivVal;
                 if (delivoset.size()> 0)
                 {
//                    for (int j = 0; j < delivoset.size(); j++)
                    for (int j = 0; j < 10; j++)
                    {
                        IABTObject delivObj = (IABTObject) delivoset.at(j);
//                   delivObj.setValue(OFD_NAME, new ABTString("newDelivName"));
                        if(outToFile_)
                        propertyPrint(delivObj,"\nDELIVERABLE");         
                        else
                        propertyScreen(delivObj,"\nDELIVERABLE");
                        
                    }
                 }
                 else { System.out.println("\nNO DELIVERABLES FOR THIS METHOD");}

//PACKAGES
                 ABTValue packVal = method.getValue(OFD_ALLPACKAGES);
                 IABTObjectSet packoset = (IABTObjectSet)packVal;
                 if (packoset.size()> 0)
                 {
                    for (int j = 0; j < packoset.size(); j++)
                    {
                        IABTObject packObj = (IABTObject) packoset.at(j);
//                  packObj.setValue(OFD_NAME, new ABTString("newPackageName"));
                        if(outToFile_)
                        propertyPrint(packObj,"\nPACKAGE");         
                        else
                        propertyScreen(packObj,"\nPACKAGE");
                        
                    }

                 }
                 else { System.out.println("\nNO PACKAGES FOR THIS METHOD");}
//REC RULES
/*                 ABTValue rrVal = method.getValue(OFD_RECRULES);
                 IABTObjectSet rroset = (IABTObjectSet)rrVal;
                 if (rroset.size()> 0)
                 {
                    for (int j = 0; j < rroset.size(); j++)
                    {
                        IABTObject rrObj = (IABTObject) rroset.at(j);
                  rrObj.setValue(OFD_NAME, new ABTString("newRecRules"));
                        propertyPrint(rrObj,"\nREC RULE");
                    }

                 }
                 else { System.out.println("\nNO REC RULES FOR THIS METHOD");}
*/
//PACKAGE MEMBERS
                 ABTValue packmemVal = method.getValue(OFD_ALLPACKAGEMEMBERS);
                 IABTObjectSet packmemoset = (IABTObjectSet)packmemVal;
                 if (packmemoset.size()> 0)
                 {
                    for (int j = 0; j < packmemoset.size(); j++)
                    {
                        IABTObject packmemObj = (IABTObject) packmemoset.at(j);
//                  packmemObj.setValue(OFD_TABLENAME, new ABTString("newPkgTblName"));
                        if(outToFile_)
                        propertyPrint(packmemObj,"\nPACKAGE MEMBERS");         
                        else
                        propertyScreen(packmemObj,"\nPACKAGE MEMBERS");
                        
                    }

                 }
                 else { System.out.println("\nNO PACKAGE MEMBERS FOR THIS METHOD");}
//PAGES
                 ABTValue pageVal = method.getValue(OFD_ALLPAGES);
                 IABTObjectSet pageoset = (IABTObjectSet)pageVal;
                 if (pageoset.size()> 0)
                 {
                    for (int j = 0; j < pageoset.size(); j++)
                    {
                        IABTObject pageObj = (IABTObject) pageoset.at(j);
//                  pageObj.setValue(OFD_NAME, new ABTString("newPageName"));
                        if(outToFile_)
                        propertyPrint(pageObj,"\nPAGES");         
                        else
                        propertyScreen(pageObj,"\nPAGES");
                        
                    }

                 }
                 else { System.out.println("\nNO PAGES FOR THIS METHOD");}
//PAGE MEMBERS
                 ABTValue pagememVal = method.getValue(OFD_ALLPAGEMEMBERS);
                 IABTObjectSet pagememoset = (IABTObjectSet)pagememVal;
                 if (pagememoset.size()> 0)
                 {
                    for (int j = 0; j < pagememoset.size(); j++)
                    {
                        IABTObject pagememObj = (IABTObject) pagememoset.at(j);
                  pagememObj.setValue(OFD_SEQUENCE, new ABTInteger(4) );
                        if(outToFile_)
                        propertyPrint(pagememObj,"\nPAGE MEMBERS");         
                        else
                        propertyScreen(pagememObj,"\nPAGE MEMBERS");
                        
                    }

                 }
                 else { System.out.println("\nNO PAGE MEMBERS FOR THIS METHOD");}


//create dependency
/*        ABTError err = createNewDependency(method);
      if (err != null)    return err;



//create assignment
        err = createNewAssignment(method);
      if (err != null)    return err;

//create task estimate
        err = createNewTaskEst(method);
      if (err != null)    return err;
*/



//DEPENDENCIES
                 ABTValue dependVal = method.getValue(OFD_ALLDEPENDENCIES);
                 IABTObjectSet dependoset = (IABTObjectSet)dependVal;
                 if (dependoset.size()> 0)
                 {
                    for (int j = 0; j < dependoset.size(); j++)
                    {
                        IABTObject dependObj = (IABTObject) dependoset.at(j);
//                  dependObj.setValue(OFD_TYPE, new ABTInteger(2));
                        if(outToFile_)
                        propertyPrint(dependObj,"\nDEPENDENCIES");         
                        else
                        propertyScreen(dependObj,"\nDEPENDENCIES");
                        
                    }

                 }
                 else { System.out.println("\nNO DEPENDENCIES FOR THIS METHOD");}

//ASSIGNMENTS
                 ABTValue assignVal = method.getValue(OFD_ALLASSIGNMENTS);
                 IABTObjectSet assignoset = (IABTObjectSet)assignVal;
                 if (assignoset.size()> 0)
                 {
                    for (int j = 0; j < assignoset.size(); j++)
                    {
                        IABTObject assignObj = (IABTObject) assignoset.at(j);
//                  assignObj.setValue(OFD_WDM, new ABTDouble(1.1));
                        if(outToFile_)
                        propertyPrint(assignObj,"\nASSIGNMENTS");         
                        else
                        propertyScreen(assignObj,"\nASSIGNMENTS");
                        
                    }

                 }
                 else { System.out.println("\nNO ASSIGNMENTS FOR THIS METHOD");}
//TASK ESTIMATES

                 ABTValue tEstVal = method.getValue(OFD_ALLTASKESTIMATES);
                 IABTObjectSet tEstoset = (IABTObjectSet)tEstVal;
                 if (tEstoset.size()> 0)
                 {
                    for (int j = 0; j < tEstoset.size(); j++)
                    {
                        IABTObject tEstObj = (IABTObject) tEstoset.at(j);
//                  tEstObj.setValue(OFD_FORMULA, new ABTString("newTskEstFormula"));
                        if(outToFile_)
                        propertyPrint(tEstObj,"\nTASK ESTIMATES");         
                        else
                        propertyScreen(tEstObj,"\nTASK ESTIMATES");
                        
                    }

                 }
                 else { System.out.println("\nNO TASK ESTIMATES FOR THIS METHOD");}


         }

//save the method back to repository
         ABTError err = saveOset(oset, TYPE_METHOD);
         if (err != null)
         {
            processError(err);
            return null;
         }

//test saveAs functionality
/*        for (int j = 0; j < oset.size(); j++)
        {
            IABTObject methObj = (IABTObject)oset.at(j);
            ABTError err = saveMethodAs(methObj);
             if (err != null)
             {
                processError(err);
                return null;
             }
        }
*/
      }

      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }

   public ABTError saveOset(IABTObjectSet oset, String type) throws ABTException
   {

      try
      {
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();
        System.out.println("\nSaving an object set back to repository and unlocking ...");
       	args.putItemByString(KEY_TYPE,  new ABTString(type));
       	args.putItemByString(KEY_SOURCE, (ABTValue)oset);
       	args.putItemByString(KEY_UNLOCK, new ABTBoolean(true));
        ABTValue val = mdriver_.save(space_, args);
         // if error, return
      	if (ABTError.isError(val))            return (ABTError)val;
        System.out.println("End saving " + type + " object set. ");

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }

   public ABTError saveMethodAs(IABTObject obj) throws ABTException
   {

      try
      {
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();
        System.out.println("\nSaving new method back to repository ...");
        args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_SAVEAS));
        args.putItemByString(KEY_EXTID, new ABTString("Liz"));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
       	args.putItemByString(KEY_SOURCE, (ABTValue)obj);
//       	args.putItemByString(KEY_UNLOCK, new ABTBoolean(true));
        ABTValue val = mdriver_.save(space_, args);
         // if error, return
      	if (ABTError.isError(val))            return (ABTError)val;
        System.out.println("End saving new method. ");

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }


   public ABTError setDriver() throws ABTException
   {

      ABTValue val = null;

      try
      {
         // instantiate a method repo driver
       	mdriver_ = (IABTDriver) new ABTDriverLocal();
       	mdriver_.initialize(space_, "com.abtcorp.io.methrepo.ABTMMRepoDriver", null);

         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

       	// populate the hashtable with appropriate keys and values for open()
       	if (repositoryName_ != null)
       	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
       	if (product_ != null)
       	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
       	if (user_ != null)
          	args.putItemByString(KEY_USERNAME, new ABTString(user_));
       	if (password_ != null)
          	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

         val = mdriver_.open(space_, args);
         if (ABTError.isError(val))            return (ABTError)val;

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }
   //=======================================================================
   // create Dependency
   //=======================================================================
/*   private ABTError createNewDependency(IABTObject method)
   {

      // dependency needs some tasks first
      System.out.println("\nCreating new tasks for dependencies...");

    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject task1 = (IABTObject) val;


   	val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject task2 = (IABTObject) val;
      // create some dependencies
      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task1);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task2);

   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
     	IABTObject assign1 = (IABTObject) val;
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

      return null;
   }


   //=======================================================================
   // create assignment
   //=======================================================================
   private ABTError createNewAssignment(IABTObject method)
   {

      System.out.println("\nCreating new assignment...");

      // assignment needs some tasks first
      System.out.println("\nCreating new tasks for assignment...");
   	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val1 = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val1))
         return (ABTError)val1;

     	IABTObject task1 = (IABTObject) val1;


// make a resource (assignment needs a resource)
         val = createNewGlobal(OBJ_RESOURCE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;

   	IABTHashTable parms2 = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_RESOURCE, null);

             val = createNewGlobal(OBJ_RESOURCE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;

    ABTValue val2 = createNewGlobal(OBJ_RESOURCE,site);
      // if error, return
   	if (ABTError.isError(val2))
         return (ABTError)val2;

    IABTObject resource1 = (IABTObject) val2;


//now make an assignment
   	parms.putItemByString(OFD_TASK, (ABTValue)task1);
   	parms.putItemByString(OFD_RESOURCE, (ABTValue)resource1);
   	ABTValue val3 = space_.createNewObject(OBJ_MM_ASSIGNMENT, parms);
      // if error, return
   	if (ABTError.isError(val3))
         return (ABTError)val3;

      return null;
   }
   //=======================================================================
   // create Task Estimate
   //=======================================================================
   private ABTError createNewTaskEst(IABTObject method)
   {

      System.out.println("\nCreating new task estimate...");

      //  needs some tasks first
      System.out.println("\nCreating new tasks for task estimates...");
   	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val1 = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val1))
         return (ABTError)val1;

     	IABTObject task1 = (IABTObject) val1;


//first make an estModel (task est needs an estModel)

   	parms.clear();
   	parms.putItemByString(OFD_ESTMODEL, null);
   	
    ABTValue val2 = createNewGlobal(OBJ_ESTMODEL,site);
      	if (ABTError.isError(val))      	   return (ABTError) val;
    IABTObject estModel1 = (IABTObject) val2;
    estModel1.setValue(OFD_ID, new ABTInteger(1));

//now make a task estimate
   	parms.clear();
   	parms.putItemByString(OFD_TASK, (ABTValue)task1);
   	parms.putItemByString(OFD_ESTMODEL, (ABTValue)estModel1);
   	ABTValue val3 = space_.createNewObject(OBJ_MM_TASKESTIMATE, parms);
      // if error, return
   	if (ABTError.isError(val3))
         return (ABTError)val3;

      return null;
   }

*/
   public ABTError testAdjRule() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the adjRules
         System.out.println("\nPopulating adjRules with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_ADJRULE));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This adjRule object set contains " + oset.size() + " objects.");
         System.out.println("Scanning adjRule objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject adjRule = (IABTObject) oset.at(i);


//            adjRule.setValue(OFD_NAME, new ABTString("New adjRule"));

             if(outToFile_)
                propertyPrint(adjRule,"\nADJ RULES");         
             else
                propertyScreen(adjRule,"\nADJ RULES");
            
         }
         saveOset(oset,TYPE_ADJRULE);
      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }



   public ABTError testCustField() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the custFields
         System.out.println("\nPopulating custFields with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_CUSTOMFIELD));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This custField object set contains " + oset.size() + " objects.");
         System.out.println("Scanning custField objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject custField = (IABTObject) oset.at(i);
//                  custField.setValue(OFD_NAME, new ABTString("newCustFldName"));
                     if(outToFile_)
                        propertyPrint(custField,"\nCUSTOM FIELDS");         
                     else
                        propertyScreen(custField,"\nCUSTOM FIELDS");
                  
                  

//AGGREGATE FIELDS
                 ABTValue agFieldVal = custField.getValue(OFD_AGGREGATEFIELDS);
                 IABTObjectSet agFieldoset = (IABTObjectSet)agFieldVal;
                 if (agFieldoset.size()> 0)
                 {
                    for (int j = 0; j < agFieldoset.size(); j++)
                    {
                        IABTObject agFieldObj = (IABTObject) agFieldoset.at(j);
//                        agFieldObj.setValue(OFD_NAME, new ABTString("newAgFldName"));
                     if(outToFile_)
                        propertyPrint(agFieldObj,"\nAGGREGATE FIELD");         
                     else
                        propertyScreen(agFieldObj,"\nAGGREGATE FIELD");
                        
                    }
                 }
                 else {System.out.println ("\nAGGREGATE FIELDS: No Aggregate Fields");}
//CUSTOM ENUMS
                 ABTValue custEnumVal = custField.getValue(OFD_CUSTOMENUMS);
                 IABTObjectSet custEnumoset = (IABTObjectSet)custEnumVal;
                 if (custEnumoset.size()> 0)
                 {
                    for (int j = 0; j < custEnumoset.size(); j++)
                    {
                        IABTObject custEnumObj = (IABTObject) custEnumoset.at(j);
//                        custEnumObj.setValue(OFD_NAME, new ABTString("newCustEnumName"));
                     if(outToFile_)
                        propertyPrint(custEnumObj,"\nCUSTOM ENUMS");         
                     else
                        propertyScreen(custEnumObj,"\nCUSTOM ENUMS");
                        
                    }
                 }
                 else {System.out.println ("\nCUSTOM ENUMS: No Custom Enums");}

         }
         saveOset(oset, TYPE_CUSTOMFIELD);

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }


   public ABTError testEstModel() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the EstModel
         System.out.println("\nPopulating estModels with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_ESTMODEL));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This estModel object set contains " + oset.size() + " objects.");
         System.out.println("Scanning estModel objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject estModel = (IABTObject) oset.at(i);
//                  estModel.setValue(OFD_NAME, new ABTString("newEstModName"));
                     if(outToFile_)
                        propertyPrint(estModel,"\nEST MODELS");         
                     else
                        propertyScreen(estModel,"\nEST MODELS");
                  
         }
         saveOset(oset, TYPE_ESTMODEL);

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }


   public ABTError testResource() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the Resource
         System.out.println("\nPopulating Resources with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_RESOURCE));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))
      	return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This Resource object set contains " + oset.size() + " objects.");
         System.out.println("Scanning Resource objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject Resource = (IABTObject) oset.at(i);
//                  Resource.setValue(OFD_NAME, new ABTString("newResName"));
                     if(outToFile_)
                        propertyPrint(Resource,"\nRESOURCES");         
                     else
                        propertyScreen(Resource,"\nRESOURCES");
                  
         }
         saveOset(oset,TYPE_RESOURCE);

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }



   //=======================================================================
   // create some method to test save
   //=======================================================================
   private ABTValue createNewMethod()
   {
      ABTError err = null;

      // create a new method
      System.out.println("\nCreating new method... ");
   	ABTValue val = space_.createNewObject(OBJ_MM_METHOD, null);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

   	IABTObject newMethod = (IABTObject) val;
      val = newMethod.setValue(OFD_EXTERNALID, new ABTString("New Method9"));
   	if (ABTError.isError(val))
         return (ABTError)val;

      // create some tasks, dependencies and deliverables for this method
   	err = createNewTasks(newMethod);
      if (err != null)    return err;

      err = createNewPages(newMethod);
      if (err != null)    return err;

      err = createNewPackages(newMethod);
      if (err != null)    return err;

      return (ABTValue)newMethod;
   }

   private ABTError createNewPackages(IABTObject method)
   {
      // create some new object
      System.out.println("\nCreating new package...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);
   	parms.putItemByString(OFD_HIDDEN, new ABTBoolean(true));

   	ABTValue val = space_.createNewObject(OBJ_MM_PACKAGE, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject pkg = (IABTObject) val;

      return null;
   }


   private ABTError createNewPages(IABTObject method)
   {
      // create some new object
      System.out.println("\nCreating new page...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val = space_.createNewObject(OBJ_MM_PAGE, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject page = (IABTObject) val;

      System.out.println("\nCreating new page member...");
    	parms.clear();
   	parms.putItemByString(OFD_PAGE, (ABTValue)page);

   	val = space_.getObjects(OBJ_CUSTOMFIELD);
   	if (ABTError.isError(val))
   	   return (ABTError)val;

   	if (val instanceof IABTObjectSet)
   	{
   	   IABTObjectSet set = (IABTObjectSet) val;
   	   val = set.at(0);
      	if (ABTError.isError(val))            	   return (ABTError)val;
   	}
   	if (ABTValue.isNull(val))
         return new ABTError("Test", "createNewPages()", "Invalid Data", "Custom field empty or null.");
   	parms.putItemByString(OFD_CUSTOMFIELD, val);

   	val = space_.createNewObject(OBJ_MM_PAGEMEMBER, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject mbr = (IABTObject) val;

      val = mbr.setValue(OFD_SEQUENCE, new ABTInteger(15));
   	if (ABTError.isError(val))         return (ABTError)val;

      return null;
   }
   //=======================================================================
   // create some global objects to test save 
   //=======================================================================
   private ABTError createNewGlobal(String type, IABTObject site)throws ABTException
   {
     	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
     	
      // create a new object 
      System.out.println("\nCreating new object " + type);
     	parms.putItemByString(OFD_SITE, (ABTValue)site);      	
   	ABTValue val = space_.createNewObject(type, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

   	IABTObject obj = (IABTObject) val;

      // create some custom enums and agg fields for custom fields
      if (type.equals(OBJ_CUSTOMFIELD))
      {
         System.out.println("\nCreating new custom enum...");
      	parms.putItemByString(OFD_CUSTOMFIELD, (ABTValue) obj);      	
      	val = space_.createNewObject(OBJ_CUSTOMENUM, parms);
      	if (ABTError.isError(val))         return (ABTError)val;

         System.out.println("\nCreating new aggregate field...");
         val = space_.getObjects(OBJ_CUSTOMFIELD);
      	if (ABTError.isError(val))         return (ABTError)val;         
         parms.clear();
      	parms.putItemByString(OFD_TARGETFIELD, (ABTValue)((IABTObjectSet)val).at(0));      	
      	parms.putItemByString(OFD_SOURCEFIELD, (ABTValue)obj);      	
      	val = space_.createNewObject(OBJ_AGGREGATEFIELD, parms);
      	if (ABTError.isError(val))         return (ABTError)val;
   
         System.out.println(" ");
      }
        if(outToFile_)
            propertyPrint(site,type);         
        else
            propertyScreen(site,type);
      
      
      return null;
   }
 


   //=======================================================================
   // create some tasks to test the save logic
   //=======================================================================
   private ABTError createNewTasks(IABTObject method)
   {
      // create some new task to test save()
      System.out.println("\nCreating new task...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val))         return (ABTError)val;

     	IABTObject task1 = (IABTObject) val;
      val = task1.setValue(OFD_EXTERNALID, new ABTString(" "));
   	if (ABTError.isError(val))         return (ABTError)val;

   	val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject task2 = (IABTObject) val;
      val = task2.setValue(OFD_EXTERNALID, new ABTString("  "));
   	if (ABTError.isError(val))         return (ABTError)val;

      // create some dependencies
      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task1);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task2);

      System.out.println("\nCreating new dependency...");
   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

      if (val instanceof IABTObject)
         ((IABTObject)val).delete();

      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task2);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task1);

      System.out.println("\nRecreating dependency...");
   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;


      // create some deliverables
      System.out.println("\nCreating new deliverables...");
    	parms.clear();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject deliv1 = (IABTObject) val;

   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject deliv2 = (IABTObject) val;

/*
      // create some task-deliv links
     	val = task1.getValue(OFD_DELIVERABLES);
   	if (ABTError.isError(val))            	   return (ABTError)val;
   	if (val instanceof IABTObjectSet)
   	{
         System.out.println("\nLinking deliverables to a task...");
   	   IABTObjectSet set = (IABTObjectSet) val;
      	set.add(deliv1);
     	   set.add(deliv2);
      	val = task1.setValue(OFD_DELIVERABLES, (ABTValue) set);
      	if (ABTError.isError(val))            	   return (ABTError)val;
   	}
*/
      return null;
   }

   private void propertyPrint(IABTObject obj, String objType) throws ABTException
   {
          IABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.getElements();
   
          pStr.println("\n\n" + objType + ":");
          for (int Count = 0; Count < Props.countProperties(); Count++)
          {
              

              IABTProperty pass =   (IABTProperty) e.nextElement();
              String Caption = pass.getCaption();
              String Name = pass.getName();
              ABTValue  one_ = obj.getValue(Name);
              if (ABTError.isError(one_)){ 

                processErrorToFile((ABTError) one_);     
                continue;              
              }//end if
              else 
              {
                if (ABTValue.isNull(one_)){      
                    pStr.println(Name + "|" + Caption + "|empty/null|");
                    continue;
                }
              }//end else
              
              int type = pass.getType();

//add an "x" to all strings, to check saving of mods in obj space
//              if (type == 1)  //it's a string  PROP_STRING
//                  obj.setValue(Name, new ABTString("newPropValue"));
//              System.out.println(Caption + "            " + Name + ": " +  one_);
            int propType = pass.getType();

            switch (propType)

              {
                case PROP_INT:
                       pStr.println(Caption + "|" + Name + "|" +  one_ +"|Integer|" + one_.intValue());
                       break;
                    case PROP_STRING:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|String|" + one_.stringValue());
                       break;
                    case PROP_OBJECT:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Object|");
                       break;
                    case PROP_OBJECTSET:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|ObjectSet|");                     
                       break;
                    case PROP_LONG:
                     pStr.println(Caption + "|" + Name + "|" + one_ + "|Long|"+ one_.intValue());
                       break;
                    case PROP_BOOLEAN:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Boolean|"+ one_.booleanValue());
                       break;
                    case PROP_DOUBLE:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Double|" + one_.doubleValue());
                       break;
                    case PROP_DATE:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Date|");
                       break;
                    case PROP_TIME:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Time|" + one_.timeValue());
                       break;
                    case PROP_TIMESTAMP:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|TimeStamp|");
                       break;
                    case PROP_BLOB:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Blob|");
                       break;
                    case PROP_SHORT:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Short|" + one_.shortValue());
                       break;
                    case PROP_ID:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Remote ID|");
                        break;
                    case PROP_UNKNOWN:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Unknown|");

                    default:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Default|");
                       break;
               }//end switch
  
      }//end for
   } //end propertyPrint
   

   private void propertyScreen(IABTObject obj, String objType) throws ABTException
   {

          IABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.getElements();
          System.out.println(objType + ":");
          for (int Count = 0; Count < Props.countProperties(); Count++)
          {

              IABTProperty pass =   (IABTProperty) e.nextElement();
              String Caption = pass.getCaption();
              String Name = pass.getName();
              ABTValue  one_ = obj.getValue(Name);
              if (ABTError.isError(one_)){ 

                processError((ABTError) one_);     
                continue;              
              }//end if
              else {
                if (ABTValue.isNull(one_)){      
                    System.out.println(Name + "|" + Caption + "|empty/null|");
                    continue;
                }
              }//end else
              int type = pass.getType();

//add an "x" to all strings, to check saving of mods in obj space
//              if (type == 1)  //it's a string  PROP_STRING
//                  obj.setValue(Name, new ABTString("newPropValue"));
//              System.out.println(Caption + "            " + Name + ": " +  one_);
            int propType = pass.getType();

            switch (propType)

              {
                case PROP_INT:
                       System.out.println(Caption + "|" + Name + "|" +  one_ +"|Integer|" + one_.intValue() + "\n" );
                       break;
                    case PROP_STRING:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|String|" + one_.stringValue()+ "\n");
                       break;
                    case PROP_OBJECT:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Object|\n");
                       break;
                    case PROP_OBJECTSET:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|ObjectSet|\n");                     
                       break;
                    case PROP_LONG:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Long|"+ one_.intValue()+ "\n");
                       break;
                    case PROP_BOOLEAN:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Boolean|"+ one_.booleanValue()+ "\n");
                       break;
                    case PROP_DOUBLE:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Double|" + one_.doubleValue()+ "\n");
                       break;
                    case PROP_DATE:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Date|\n");
                       break;
                    case PROP_TIME:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Time|" + one_.timeValue()+ "\n");
                       break;
                    case PROP_TIMESTAMP:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|TimeStamp|\n");
                       break;
                    case PROP_BLOB:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Blob|\n");
                       break;
                    case PROP_SHORT:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Short|" + one_.shortValue() + "\n");
                       break;
                    case PROP_ID:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Remote ID|\n");
                        break;
                    case PROP_UNKNOWN:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Unknown|\n");

                    default:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Default|\n");
                       break;
               }//end switch
      }
   }

   private void processErrorToFile(ABTError err)
   {
      pStr.println("\nERROR OCCURRED!!!");
      if (err.getCode() > 0)
      pStr.println("  Code: " + err.getCode());
      if (err.getComponent() != null)
      pStr.println("  Component: " + err.getComponent());
      if (err.getMethod() != null)
      pStr.println("  Module: " + err.getMethod());
      if (err.getMessage() != null)
      pStr.println("  Message: " + err.getMessage());
      if (err.getInfo() != null)
      pStr.println("  Info: " + err.getInfo().toString());
   }//end processErrorToFile



   private void processError(ABTError err)
   {
      System.out.println("\nERROR OCCURRED!!!");
      System.out.println("  Code: " + err.getCode());
      System.out.println("  Component: " + err.getComponent());
      System.out.println("  Module: " + err.getMethod());
      System.out.println("  Message: " + err.getMessage());
      System.out.println("  Info: " + err.getInfo().toString());
   }

   public static void main(String args[])
   {
      LeeMethDriver app = new LeeMethDriver(args);
      app.run();
   }

}