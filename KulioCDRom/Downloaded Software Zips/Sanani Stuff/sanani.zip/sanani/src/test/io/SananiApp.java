package test.io;

import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;

public class SananiApp 
{
   ABTUserSession userSession_ = null;
   
   public SananiApp() {}
   
   public void run() 
   {
      try {
         // Get all projects that start with 'A' from a repository data source
         ABTObjectSpace space = new ABTObjectSpace();
         userSession_ = space.startSession(null);
         HardWiredDriver driver = new HardWiredDriver(space, userSession_);
         ABTValue os = driver.populate((String)null);
         driver.close();      
      
      } catch (Exception e) {
         e.printStackTrace();
      }      
   }
   
   public static void main(String args[])
   {
      SananiApp app = new SananiApp();
      app.run();
   }
}