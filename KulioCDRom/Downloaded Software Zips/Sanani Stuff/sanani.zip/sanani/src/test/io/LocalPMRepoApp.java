package test.io;

import com.abtcorp.io.*;

import com.abtcorp.api.local.*;
import com.abtcorp.idl.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTHashtable;

import com.abtcorp.objectModel.pm.IABTPMRuleConstants;

public class LocalPMRepoApp implements IABTDriverConstants, IABTPMRuleConstants
{
   private String repositoryName_;
   private String projectExternalID_;
   private IABTObjectSpace space_;
   
   public LocalPMRepoApp(String[] args) 
   {
      repositoryName_ = "ABTRepository";
      projectExternalID_ = "2.0.4N";
      
      if (args != null && args.length > 0) {
         repositoryName_ = args[0];
         
         if (args.length > 1) {
            projectExternalID_ = args[1];
         } 
      }
   }

   public void run()
   {
   }

   public static void main(String args[])
   {
      LocalPMRepoApp app = new LocalPMRepoApp(args);
      app.run();
   }

}