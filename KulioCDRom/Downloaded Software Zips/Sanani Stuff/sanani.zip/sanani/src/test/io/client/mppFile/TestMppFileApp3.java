package test.io.client.mppfile;

/* ***************************************************************************
	Reads a project from a file and saves it to a repository
*****************************************************************************/


import com.abtcorp.io.ABTDriver;
import com.abtcorp.io.client.*;
import com.abtcorp.io.client.mppfile.*;

import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTDriver;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.api.local.ABTObjectSpaceLocal;
import com.abtcorp.api.local.ABTDriverLocal;
import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTHashtable;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;

import com.abtcorp.core.COM.*;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;


public class TestMppFileApp3 implements IABTPMRuleConstants, IABTDriverConstants
{
	protected ABTValue site_;
	IABTObjectSpace space_;
	private IABTDriver projDriver_;
	private IABTDriver siteDriver_;

	public TestMppFileApp3() {}

	public static void main(String args[])
	{
		TestMppFileApp3 app = new TestMppFileApp3();
		app.run();
	}

	public void run()
	{
		try
		{
			System.out.println("TestMppFileApp3 starting... Populate from MPP and save to repository");
			space_ = new ABTObjectSpaceLocal();
			space_.startSession( null );

			siteDriver_ = space_.newABTDriver( "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
			populateSite();

			projDriver_ = space_.newABTDriver( "com.abtcorp.io.client.mppfile.ABTClientMppDriver", null );
			projDriver_.open( null );

			IABTHashTable args = space_.newABTHashTable();

			args.putItemByString( KEY_SOURCENAME, new ABTString("d:\\projects\\project1.mpp") );

			ABTValue obj = projDriver_.populate( args );
			if (ABTError.isError(obj)) throw new ABTException(((ABTError)obj).getMessage());

			IABTObject proj = (IABTObject) obj;
			IABTObject object;

			// The MPP file driver's populate() method 
			// will return a Project object.

			if ( proj instanceof IABTObject )
			{
				// Identify ourself.
				ABTValue val;
				ABTValue prID = proj.getValue( OFD_ID );
				ABTValue prName = proj.getValue( OFD_NAME );
				ABTValue prFileName = proj.getValue( OFD_FILENAME );
				System.out.println("ID = " + prID.toString() + ", NAME = " + prName.toString() );
				System.out.println("From file: " + prFileName.toString() );
				projDriver_.close( null );
				space_.endSession();
				projDriver_ = null;
				args = null;
			}

			if ( projDriver_ == null && proj instanceof IABTObject )
			{
				// Open a repository and save this project into it.
				System.out.println( "Saving the project to the repository..." );

				projDriver_ = space_.newABTDriver( "com.abtcorp.io.PMWRepo.ABTPMWRepoDriver", null);
				openRepo( projDriver_ );

				// Save the project to the repository.
				args = space_.newABTHashTable();
				args.putItemByString( KEY_TYPE, new ABTString( TYPE_PROJECT ) );
				args.putItemByString( KEY_SUBTYPE, new ABTString( SUBTYPE_SAVEAS ) );
				args.putItemByString( KEY_EXTID, new ABTString( "TestMPP" ) );
				args.putItemByString( KEY_SOURCE, (ABTValue)proj );
				projDriver_.save( args );

				closeRepo( projDriver_ );
			}

			closeRepo( siteDriver_ );
		}

		catch (Exception e)
		{
			System.out.println("Exception caught...printing stack trace...");
			e.printStackTrace();
		}
		finally
		{
			System.out.println("TestMppFileApp ended.");
		}

	}

	private void openRepo( IABTDriver driver ) throws ABTException
	{
		IABTHashTable args = space_.newABTHashTable();
		ABTValue retVal = null;

		args.putItemByString(KEY_USERNAME, new ABTString( "admin" ));
		args.putItemByString(KEY_REPONAME, new ABTString( "ABT Repository" ));
		args.putItemByString(KEY_PRODUCT, new ABTString( "ABT Workbench" ));

		retVal = driver.open( args );
		if ( ABTError.isError( retVal ) )
		{
			System.out.println( "openRepo error from " + ((ABTError)retVal).getMethod() +
								((ABTError)retVal).getMessage() );
			throw new ABTException( "Driver failed to open!" );
		}
	}

	private void closeRepo( IABTDriver driver )
	{
		if ( driver != null )
			driver.close( null );
	}

	private void populateSite() throws ABTException
	{
		openRepo( siteDriver_ );

		IABTHashTable args = space_.newABTHashTable();
		args.putItemByString( KEY_TYPE, new ABTString(TYPE_ALL) );
		ABTValue val = siteDriver_.populate( args );

		if (ABTError.isError( val ) )
			throw new ABTException((ABTError) val);

		if ( val instanceof IABTObject )
			site_ = val;   
		else
			throw new ABTException("Site populate() failed and did not return a site object!");
	}

	public IABTObject createCalendar( int id ) throws ABTException
	{
		IABTHashTable reqparms = space_.newABTHashTable();
		reqparms.putItemByString( OFD_SITE, site_ );
		IABTObject calendar = (IABTObject)space_.createObject( OBJ_CALENDAR, null, reqparms );
		calendar.setValue( OFD_ID, new ABTInteger( id ) );

		return calendar;
	}
   
}