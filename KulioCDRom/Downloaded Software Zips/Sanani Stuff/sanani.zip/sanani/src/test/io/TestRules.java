package test.io;

import java.util.*;

import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.objectModel.pm.*;
import com.abtcorp.io.PMWRepo.*;

import com.objectspace.jgl.*;

public class TestRules extends SananiBuilder implements com.abtcorp.idl.IABTPMRuleConstants, com.abtcorp.idl.IABTPropertyType
{
   public TestRules( String[] args )
   {
      if( args != null && args.length > 0 )
      {
         repositoryName_ = args[0];

         if( args.length > 1 )
            projectExternalID_ = args[1];
      }
   }

   private ABTValue populate() throws TestRuleException
   {
//      projectExternalID_ = "NEWPRODS";
//
//      ABTValue v = driver_.populate( repositoryName_ + "\\" + projectExternalID_ );
//      checkError( v );
//      ABTObject project = (ABTObject)((ABTObjectSet)v).front( session_ );
//
//      checkError( driver_.populate( repositoryName_ + "\\GYROSOFT" ) );

//      return project;
      return null;
   }

   public void run()
   {
      System.out.println( "TestRules starting..." );

      try
      {
         createObjectSpace();

         //testTaskStartFinish();

         projectDeletionTest();
//         testSiteObjects();
//         testExists();
//         testTaskIteration();
//         lucy();
//         testExternalid();
//         testIDs();
//         robin();
//         testParser();
//         testWBSLevel();
//         moveTaskTest();
//         deliverables();
//         taskEstimates();
//         deleteTaskTest();
//         custfieldvalues();
//         notes();
//         constraints();
//         subprojectlinks();
//         childTasks();
//         dependencies();
//         assignments();
//         oneAssignmentMethod1();
      }
      catch( TestRuleException e )
      {
         System.out.println( e.error_.getPackage() );
         System.out.println( e.error_.getMessage() );
         System.out.println( e.error_.getInfo() );
      }
      catch( Exception e )
      {
         System.out.println( "Exception caught... printing stack trace..." );
         e.printStackTrace();
      }

      System.out.println( "TestRules ended." );
   }

   private void testProjectStartFinish() throws Exception
   {
      ABTObject project = createObject(OBJ_PROJECT, null);

      ABTObject site = (ABTObject)createObject(OBJ_SITE, null);

      ABTCalendar calendar = (ABTCalendar)site.getValue(session_, OFD_CALENDAR, null);

      ABTDate finishDate = calendar.addWorkday(ABTDate.today(), 4);

      ABTValue v = project.setValue(session_, OFD_START, new ABTTime(finishDate));
      v = project.setValue(session_, OFD_FINISH, ABTTime.now());

   }

   private void projectDeletionTest() throws Exception
   {
      projectDeletion_TestA();
      projectDeletion_TestB();
      projectDeletion_TestC();
      projectDeletion_TestD();
      projectDeletion_TestE();
      projectDeletion_TestF();
      projectDeletion_TestG();
      projectDeletion_TestH();
      projectDeletion_TestI();
   }

   private void projectDeletion_TestI() throws Exception
   {
      // test SPL redirection
      // E -> Pa -*-> Pb, E -> Pb, then Pa -*-> Pc, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

     // set Pa explicit interest
      v = Pb.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc1
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc1 = createObject(OBJ_TASK, taskreqs);

      // print space
      dumpObjectSpace();

       // reset SPLab to ac
      setValue(SPLab, OFD_SUBPROJECT, Pc);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // test case Pa, Pc are deleted, Pb is not
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == true)  ||
          (Pc.isDeleted(session_) == false))
         throw new Exception("projectDeletion_TestI failure");

      // print space
      dumpObjectSpace();

   }

   private void projectDeletion_TestH() throws Exception
   {
      // test SPL redirection
      // E -> Pa -*-> Pb, then Pa -*-> Pc, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc1
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc1 = createObject(OBJ_TASK, taskreqs);

      // print space
      //dumpObjectSpace();

       // reset SPLab to ac
      setValue(SPLab, OFD_SUBPROJECT, Pc);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // test case Pa, Pb, Pc are all deleted
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == false) ||
          (Pc.isDeleted(session_) == false))
         throw new Exception("projectDeletion_TestH failure");

      // print space
      //dumpObjectSpace();
   }

   private void projectDeletion_TestG() throws Exception
   {
      // EE -> Pa -> Pb -> Pc -> Pa, Pc->Pd, delete Pa, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc1
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc1 = createObject(OBJ_TASK, taskreqs);

      // create Tc2
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc2 = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create SPLca, Pc->Pa
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tc1);
      ABTObject SPLca = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLca, OFD_ID, new ABTInteger(3));
      setValue(SPLca, OFD_SUBPROJECT, Pa);
      setValue(SPLca, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pd
      ABTObject Pd = createObject(OBJ_PROJECT, null);

      // create Td
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pd);
      ABTObject Td = createObject(OBJ_TASK, taskreqs);

      // create SPLcd, Pc->Pd
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tc2);
      ABTObject SPLcd = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLcd, OFD_ID, new ABTInteger(4));
      setValue(SPLcd, OFD_SUBPROJECT, Pd);
      setValue(SPLcd, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // test case Pa, Pb, Pc, Px not deleted
      if ((Pa.isDeleted(session_) == true) ||
          (Pb.isDeleted(session_) == true) ||
          (Pc.isDeleted(session_) == true) ||
          (Pd.isDeleted(session_) == true))
         throw new Exception("projectDeletion_TestG failure");

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa, Pb, Pc, Px not deleted
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == false) ||
          (Pc.isDeleted(session_) == false) ||
          (Pd.isDeleted(session_) == false))
         throw new Exception("projectDeletion_TestG failure");
   }

   private void projectDeletion_TestF() throws Exception
   {
      // E -> Pa -> Pb -> Pc -> Pa, E->Px->Pb, delete Pa, then delete Px

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create SPLca, Pc->Pa
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tc);
      ABTObject SPLca = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLca, OFD_ID, new ABTInteger(3));
      setValue(SPLca, OFD_SUBPROJECT, Pa);
      setValue(SPLca, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Px
      ABTObject Px = createObject(OBJ_PROJECT, null);

      // set Px explicit interest
      v = Px.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Tx
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Px);
      ABTObject Tx = createObject(OBJ_TASK, taskreqs);

      // create SPLxb, Px->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tx);
      ABTObject SPLxb = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLxb, OFD_ID, new ABTInteger(3));
      setValue(SPLxb, OFD_SUBPROJECT, Pb);
      setValue(SPLxb, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa, Pb, Pc, Px not deleted
      if ((Pa.isDeleted(session_) == true) ||
          (Pb.isDeleted(session_) == true) ||
          (Pc.isDeleted(session_) == true) ||
          (Px.isDeleted(session_) == true))
         throw new Exception("projectDeletion_TestF failure");

      // delete Pa
      v = Px.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa, Pb, Pc, Px deleted
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == false) ||
          (Pc.isDeleted(session_) == false) ||
          (Px.isDeleted(session_) == false))
         throw new Exception("projectDeletion_TestF failure");
   }

   private void projectDeletion_TestE() throws Exception
   {
      // E -> Pa -> Pb -> Pc -> Pa, Px->Pb, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create SPLca, Pc->Pa
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tc);
      ABTObject SPLca = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLca, OFD_ID, new ABTInteger(3));
      setValue(SPLca, OFD_SUBPROJECT, Pa);
      setValue(SPLca, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Px
      ABTObject Px = createObject(OBJ_PROJECT, null);

      // create Tx
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Px);
      ABTObject Tx = createObject(OBJ_TASK, taskreqs);

      // create SPLxb, Px->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tx);
      ABTObject SPLxb = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLxb, OFD_ID, new ABTInteger(3));
      setValue(SPLxb, OFD_SUBPROJECT, Pb);
      setValue(SPLxb, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa, Pb, Pc not deleted
      if ((Pa.isDeleted(session_) == true) ||
          (Pb.isDeleted(session_) == true) ||
          (Pc.isDeleted(session_) == true) ||
          (Px.isDeleted(session_) == true))
         throw new Exception("projectDeletion_TestE failure");
   }

   private void projectDeletion_TestD() throws Exception
   {
      // E -> Pa -> Pb -> Pc -> Pa, E->Pb, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // set Pb explicit interest
      v = Pb.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create SPLca, Pc->Pa
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tc);
      ABTObject SPLca = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLca, OFD_ID, new ABTInteger(3));
      setValue(SPLca, OFD_SUBPROJECT, Pa);
      setValue(SPLca, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa, Pb, Pc not deleted
      if ((Pa.isDeleted(session_) == true) ||
          (Pb.isDeleted(session_) == true) ||
          (Pc.isDeleted(session_) == true))
         throw new Exception("projectDeletion_TestD failure");
   }

   private void projectDeletion_TestC() throws Exception
   {
      // E -> Pa -> Pb -> Pc -> Pa, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create SPLca, Pc->Pa
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tc);
      ABTObject SPLca = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLca, OFD_ID, new ABTInteger(3));
      setValue(SPLca, OFD_SUBPROJECT, Pa);
      setValue(SPLca, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa, Pb, Pc deleted
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == false) ||
          (Pc.isDeleted(session_) == false))
         throw new Exception("projectDeletion_TestC failure");
   }

   private void projectDeletion_TestB() throws Exception
   {
      // E -> Pa -> Pb -> Pc, E -> Pb, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // set Pa explicit interest
      v = Pb.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa deleted, Pb, Pc not deleted
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == true) ||
          (Pc.isDeleted(session_) == true))
         throw new Exception("projectDeletion_TestB failure");
   }

   private void projectDeletion_TestA() throws Exception
   {
      // E -> Pa -> Pb -> Pc, Px -> Pb, delete Pa

      ABTHashtable taskreqs;
      ABTValue v;
      ABTHashtable subprjreqs;

      // create Pa
      ABTObject Pa = createObject(OBJ_PROJECT, null );

      // set Pa explicit interest
      v = Pa.setValue(session_, OFD_EXPLICITINTEREST, new ABTBoolean(true));
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // create Ta
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pa);
      ABTObject Ta = createObject(OBJ_TASK, taskreqs);

      // create Pb
      ABTObject Pb = createObject(OBJ_PROJECT, null);

      // create Tb
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pb);
      ABTObject Tb = createObject(OBJ_TASK, taskreqs);

      // create SPLab, Pa->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Ta);
      ABTObject SPLab = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLab, OFD_ID, new ABTInteger(1));
      setValue(SPLab, OFD_SUBPROJECT, Pb);
      setValue(SPLab, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Pc
      ABTObject Pc = createObject(OBJ_PROJECT, null);

      // create Tc
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Pc);
      ABTObject Tc = createObject(OBJ_TASK, taskreqs);

      // create SPLbc, Pb->Pc
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tb);
      ABTObject SPLbc = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLbc, OFD_ID, new ABTInteger(2));
      setValue(SPLbc, OFD_SUBPROJECT, Pc);
      setValue(SPLbc, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // create Px
      ABTObject Px = createObject(OBJ_PROJECT, null);

      // create Tx
      taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString(OFD_PROJECT), Px);
      ABTObject Tx = createObject(OBJ_TASK, taskreqs);

      // create SPLxb, Px->Pb
      subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString(OFD_TASK), Tx);
      ABTObject SPLxb = createObject(OBJ_SUBPROJECTLINK, subprjreqs);
      setValue(SPLxb, OFD_ID, new ABTInteger(3));
      setValue(SPLxb, OFD_SUBPROJECT, Pb);
      setValue(SPLxb, OFD_SUBPROJECTTYPE, new ABTInteger(PROJECT_TYPE));

      // print space
      //dumpObjectSpace();

      // delete Pa
      v = Pa.delete(session_);
      if (ABTError.isError(v)) throw new Exception(v.toString());

      // print space
      //dumpObjectSpace();

      // test case Pa deleted, Pb, Pc, Px not deleted
      if ((Pa.isDeleted(session_) == false) ||
          (Pb.isDeleted(session_) == true) ||
          (Pc.isDeleted(session_) == true) ||
          (Px.isDeleted(session_) == true))
         throw new Exception("projectDeletion_TestA failure");
   }


   private void testSiteObjects() throws TestRuleException
   {
      createSite();

      ABTObject   calendar1 = createCalendar( 1 );
      ABTObject   calendar2 = createCalendar( 2 );

      ABTObject   typecode1 = createTypeCode( 1 );
      ABTObject   typecode2 = createTypeCode( 2 );
      
      ABTObject   resource1 = createResource( 1, calendar1, typecode1 );
      ABTObject   resource2 = createResource( 2, calendar2, typecode2 );
      
      ABTObject   chargecode1 = createChargeCode( 1 );
      ABTObject   chargecode2 = createChargeCode( 2 );
      
      ABTObject   timeperiod1 = createTimePeriod( 1 );
      ABTObject   timeperiod2 = createTimePeriod( 2 );
      
      ABTObject   adjrule1 = createAdjRule( 1 );
      ABTObject   adjrule2 = createAdjRule( 2 );

      ABTObject   customfield1 = createCustomField( 1 );
      ABTObject   customfield2 = createCustomField( 2 );
      
      createAggregateField( 1, customfield1, customfield2 );
      
      ABTObject   estmodel1 = createEstModel( 1 );
      ABTObject   estmodel2 = createEstModel( 2 );
      
   }
   
   private void lucy() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      getValue( project, OFD_CALENDAR );
   }

   private void testExists() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTObject    resource1  = createResource( 1, null, null );
      ABTObject    resource2  = createResource( 2, null, null );

      ABTObject    team1      = createTeamResource( project, resource1, 3 );
      ABTObject    team2      = createTeamResource( project, resource2, 4 );

      ABTObjectSet os = findObject( "pm.Team", "Exists( pmResource.pmId = 3 )" );
      iterateObjectSet( os );

   }

   private void testTaskIteration() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTObject    task1      = createTask( project, null, 1 );
      ABTObject    task2      = createTask( project, null, 2 );
      ABTObject    task3      = createTask( project, null, 3 );
      ABTObject    task11     = createTask( project, task1, 4 );
      ABTObject    task12     = createTask( project, task1, 5 );
      ABTObject    task13     = createTask( project, task1, 6 );
      ABTObject    task21     = createTask( project, task2, 7 );
      ABTObject    task22     = createTask( project, task2, 8 );
      ABTObject    task23     = createTask( project, task2, 9 );

      ABTObject    project2   = createObject( OBJ_PROJECT, null );
      ABTObject    prj2Task1  = createTask( project2, null, 100 );
      ABTObject    prj2Task2  = createTask( project2, null, 101 );
      ABTObject    subproject = createSubprojectlink( task22, 1000 );

      setValue( subproject, OFD_SUBTASK, prj2Task1 );
      setValue( subproject, OFD_SUBPROJECTTYPE, new ABTInteger( TASK_TYPE ) );

      ABTValue sum = getValue( task2, "pmSumIDs" );
      System.out.println( sum );
   }

   private void testExternalid() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTObject    task1      = createTask( project, null, 1 );
      ABTObject    task2      = createTask( project, null, 2 );
      ABTObject    task3      = createTask( project, null, 3 );

      setValue( task1, OFD_EXTERNALID, new ABTString( "A'B" ) );
      setValue( task1, OFD_EXTERNALID, new ABTString( "1" ) );

      setValue( task2, OFD_EXTERNALID, new ABTString( "2" ) );
      setValue( task3, OFD_EXTERNALID, new ABTString( "3" ) );

      ABTObject    deliverable1 = createDeliverable( project, 4 );
      ABTObject    deliverable2 = createDeliverable( project, 5 );
      ABTObject    deliverable3 = createDeliverable( project, 6 );

      setValue( deliverable1, OFD_EXTERNALID, new ABTString( "1" ) );
      setValue( deliverable2, OFD_EXTERNALID, new ABTString( "2" ) );
      setValue( deliverable3, OFD_EXTERNALID, new ABTString( "3" ) );

      ABTObject resource1 = createResource( 7, null, null );
      ABTObject resource2 = createResource( 8, null, null );
      ABTObject resource3 = createResource( 9, null, null );

      setValue( resource1, OFD_EXTERNALID, new ABTString( "1" ) );
      setValue( resource2, OFD_EXTERNALID, new ABTString( "2" ) );
      setValue( resource3, OFD_EXTERNALID, new ABTString( "1" ) );

      iterateTasks( project );
   }

   private void testIDs() throws TestRuleException
   {
      ABTObject    project       = createObject( OBJ_PROJECT, null );
      ABTObjectSet deliverables  = getObjectSet( project, OFD_ALLDELIVERABLES );

      ABTObject    deliverable1  = createDeliverable( project, 1 );
      ABTObject    deliverable2  = createDeliverable( project, 2 );
      ABTObject    deliverable3  = createDeliverable( project, 3 );
      ABTObject    deliverable4  = createDeliverable( project, 4 );
      ABTObject    deliverable5  = createDeliverable( project, 5 );
      ABTObject    deliverable6  = createDeliverable( project, 6 );
      ABTObject    deliverable7  = createDeliverable( project, 7 );
      ABTObject    deliverable8  = createDeliverable( project, 8 );
      ABTObject    deliverable9  = createDeliverable( project, 9 );
      ABTObject    deliverable10 = createDeliverable( project, 10 );

      deleteObject( deliverable1 );
      deleteObject( deliverable2 );
      deleteObject( deliverable3 );
      deleteObject( deliverable4 );
      deleteObject( deliverable5 );

      ABTObjectSetIDs set = deliverables.getIDSet( session_ );

      java.util.Enumeration e = set.getActiveIDs();
      while( e.hasMoreElements() )
      {
         ABTID id = (ABTID)e.nextElement();
         int i = 0;
      }

//      e = set.getDeletedIDs();
      while( e.hasMoreElements() )
      {
         ABTID id = (ABTID)e.nextElement();
         int i = 0;
      }
   }

   private void robin() throws TestRuleException
   {
      ABTObject project = (ABTObject)populate();

      ABTObjectSet allTasks = getObjectSet( project, OFD_ALLTASKS );

      ABTObject task = createTask( project, null, 1000 );

      iterateObjectSet( allTasks );

      setValue( project, OFD_WBSVALIDATE, new ABTBoolean( true ) );

      iterateTasks( project );
   }

   private void testParser() throws TestRuleException
   {
      ABTObject   test1       = createObject( "pm.PMRule", null );

      space_.addProperty( "pm.PMRule", "PROP1", "", ABTRule.PROP_STRING,
         false, true, true, false, null, null, null );
      setValue( test1, "mahbck", ABTDate.today() );

      ABTObjectSet os = findObject( "pm.PMRule", "PROP1 like '%ahab%'" );
      iterateObjectSet( os );
   }

   public void testWBSLevel() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTObject    task1      = createTask( project, null, 1 );
      ABTObject    task2      = createTask( project, null, 2 );
      ABTObject    task3      = createTask( project, null, 3 );
      ABTObject    task11     = createTask( project, task1, 11 );
      ABTObject    task12     = createTask( project, task1, 12 );
      ABTObject    task13     = createTask( project, task1, 13 );
      ABTObject    task21     = createTask( project, task2, 21 );
      ABTObject    task22     = createTask( project, task2, 22 );
      ABTObject    task23     = createTask( project, task2, 23 );
      ABTObject    task111    = createTask( project, task11, 111 );
      ABTObject    task112    = createTask( project, task11, 112 );
      ABTObject    task113    = createTask( project, task11, 113 );
      ABTObject    task114    = createTask( project, task11, 114 );
      ABTObject    task115    = createTask( project, task11, 115 );
      ABTObject    task1111   = createTask( project, task111, 1111 );
      ABTObject    task11111  = createTask( project, task1111, 11111 );

      setValue( project, OFD_WBSVALIDATE, new ABTBoolean( true ) );

      iterateTasks( project );
   }

   public void moveTaskTest() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTObject    task1      = createTask( project, null, 1 );
      ABTObject    task2      = createTask( project, null, 2 );
      ABTObject    task3      = createTask( project, null, 3 );
      ABTObject    task11     = createTask( project, task1, 11 );
      ABTObject    task12     = createTask( project, task1, 12 );
      ABTObject    task13     = createTask( project, task1, 13 );
      ABTObject    task21     = createTask( project, task2, 21 );
      ABTObject    task22     = createTask( project, task2, 22 );
      ABTObject    task23     = createTask( project, task2, 23 );
      ABTObject    task111    = createTask( project, task11, 111 );
      ABTObject    task112    = createTask( project, task11, 112 );
      ABTObject    task113    = createTask( project, task11, 113 );
      ABTObject    task114    = createTask( project, task11, 114 );
      ABTObject    task115    = createTask( project, task11, 115 );
      ABTObject    task1111   = createTask( project, task111, 1111 );
      ABTObject    task11111  = createTask( project, task1111, 11111 );

      setValue( task11, OFD_PREVIOUSTASK, task13 );
      setValue( project, OFD_WBSVALIDATE, new ABTBoolean( true ) );
      iterateTasks( project );
   }

   public void deliverables() throws TestRuleException
   {
      ABTObject   project  = createObject( OBJ_PROJECT, null );

      ABTObject   task     = createTask( project, null, 1 );
      ABTObject   deliv1   = createDeliverable( project, 2 );

      ABTObjectSet os = getObjectSet( task, OFD_DELIVERABLES );
      addListMember( os, deliv1 );

//      checkError( deliv1.delete( session_ ) );

      os = getObjectSet( project, OFD_ALLDELIVERABLES );
      iterateObjectSet( os );
   }

   public void taskEstimates() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTObject    task1      = createTask( project, null, 10 );
      ABTObject    task2      = createTask( project, null, 11 );
      ABTObject    task3      = createTask( project, null, 12 );

      ABTObject    estmodel1  = createEstmodel( project, 2 );
      ABTObject    estmodel2  = createEstmodel( project, 3 );
      ABTObject    estmodel3  = createEstmodel( project, 4 );

      ABTObject    taskest1   = createTaskestimate( task1, estmodel1, 5 );
      ABTObject    taskest2   = createTaskestimate( task2, estmodel2, 6 );
      ABTObject    taskest3   = createTaskestimate( task3, estmodel3, 7 );

      checkError( estmodel1.delete( session_ ) );

      iterateObjectSet( getObjectSet( project, OFD_ALLTASKESTIMATES ) );
   }

   public void deleteTaskTest() throws TestRuleException
   {
      ABTObject   project     = createObject( OBJ_PROJECT, null );

      //
      // Create all the resources for the project
      //
      ABTObject   resource1   = createResource( 1, null, null );
      ABTObject   resource2   = createResource( 2, null, null );
      ABTObject   resource3   = createResource( 3, null, null );
      ABTObject   team1       = createTeamResource( project, resource1, 4 );
      ABTObject   team2       = createTeamResource( project, resource2, 5 );
      ABTObject   team3       = createTeamResource( project, resource3, 6 );

      //
      // Create all of the tasks for the project
      //
      ABTObject    task1      = createTask( project, null, 7 );
      ABTObject    task2      = createTask( project, null, 8 );
      ABTObject    task3      = createTask( project, null, 9 );

      //
      // Create the assignments for the project
      //
      ABTObject    assignment1 = createAssignment( task1, resource1, 10 );
      ABTObject    assignment2 = createAssignment( task2, resource2, 11 );
      ABTObject    assignment3 = createAssignment( task3, resource3, 12 );

      //
      // Create estimating models and task estimates for the project
      //
      ABTObject    estmodel1  = createEstmodel( project, 13 );
      ABTObject    estmodel2  = createEstmodel( project, 14 );
      ABTObject    estmodel3  = createEstmodel( project, 15 );
      ABTObject    taskest1   = createTaskestimate( task1, estmodel1, 16 );
      ABTObject    taskest2   = createTaskestimate( task2, estmodel2, 17 );
      ABTObject    taskest3   = createTaskestimate( task3, estmodel3, 18 );

      //
      // Create a few dependencies
      //
      ABTObject    dependency1 = createDependency( task1, task2, 19 );
      ABTObject    dependency2 = createDependency( task2, task3, 20 );

      //
      // Create a few deliverables
      //
      ABTObject deliv1 = createDeliverable( project, 21 );
      ABTObject deliv2 = createDeliverable( project, 22 );
      ABTObject deliv3 = createDeliverable( project, 23 );

      addListMember( getObjectSet( task1, OFD_DELIVERABLES ), deliv1 );
      addListMember( getObjectSet( task2, OFD_DELIVERABLES ), deliv2 );
      addListMember( getObjectSet( task3, OFD_DELIVERABLES ), deliv3 );

      //
      // Add some notes
      //
      ABTObject      note1 = createNote( 24 );
      ABTObject      note2 = createNote( 25 );
      ABTObject      note3 = createNote( 26 );
      addListMember( getObjectSet( project, OFD_NOTES ), note1 );
      addListMember( getObjectSet( project, OFD_NOTES ), note2 );
      addListMember( getObjectSet( project, OFD_NOTES ), note3 );

      //
      // Add some custom field values
      //
      ABTObject      custfieldvalue1 = createCustfieldvalue( 27 );
      ABTObject      custfieldvalue2 = createCustfieldvalue( 28 );
      ABTObject      custfieldvalue3 = createCustfieldvalue( 29 );
      addListMember( getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue1 );
      addListMember( getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue2 );
      addListMember( getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue3 );

      checkError( resource1.delete( session_ ) );

//      iterateObjectSet( getObjectSet( resource1, OFD_ASSIGNMENTS ) );
      iterateObjectSet( getObjectSet( task1, OFD_ASSIGNMENTS ) );
      iterateObjectSet( getObjectSet( project, OFD_NOTES ) );
   }

   public void iterate( ABTObjectSet os, String object, String prop ) throws TestRuleException
   {
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject listelem = (ABTObject)e.nextElement();
         ABTObject obj = getObject( listelem, object );
         ABTValue v = getValue( obj, prop );
         String s = v.toString();
         int i = 0;
      }
   }

   public void custfieldvalues() throws TestRuleException
   {
      ABTObject    project       = createObject( OBJ_PROJECT, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task          = createObject( OBJ_TASK, taskreqs );
      ABTObject    custvalue1    = createObject( OBJ_CUSTFIELDVALUE, null );
      ABTObject    custvalue2    = createObject( OBJ_CUSTFIELDVALUE, null );
      ABTObject    custvalue3    = createObject( OBJ_CUSTFIELDVALUE, null );
      ABTObjectSet custvalues    = getObjectSet( task, OFD_CUSTFIELDVALUES );

      setValue( project, OFD_FIRSTCHILDTASK, task );

      addListMember( custvalues, custvalue1 );
      addListMember( custvalues, custvalue2 );
      addListMember( custvalues, custvalue3 );

      setValue( custvalue1, OFD_ID, new ABTInteger( 1 ) );
      setValue( custvalue2, OFD_ID, new ABTInteger( 2 ) );
      setValue( custvalue3, OFD_ID, new ABTInteger( 3 ) );

      removeListMember( custvalues, custvalue1 );

      iterateObjectSet( custvalues );
   }

   public void notes() throws TestRuleException
   {
      ABTObject    project  = createObject( OBJ_PROJECT, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task     = createObject( OBJ_TASK, taskreqs );
      ABTObject    note1    = createObject( OBJ_NOTE, null );
      ABTObject    note2    = createObject( OBJ_NOTE, null );
      ABTObject    note3    = createObject( OBJ_NOTE, null );
      ABTObjectSet notes    = getObjectSet( task, OFD_NOTES );

      setValue( project, OFD_FIRSTCHILDTASK, task );

      addListMember( notes, note1 );
      addListMember( notes, note2 );
      addListMember( notes, note3 );

      setValue( note1, OFD_ID, new ABTInteger( 1 ) );
      setValue( note2, OFD_ID, new ABTInteger( 2 ) );
      setValue( note3, OFD_ID, new ABTInteger( 3 ) );

      removeListMember( notes, note1 );

      iterateObjectSet( notes );
   }

   public void constraints() throws Exception
   {
      ABTObject    project       = createObject( OBJ_PROJECT, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task          = createObject( OBJ_TASK, taskreqs );

      ABTHashtable constraintreqs = new ABTHashtable();
      constraintreqs.put( new ABTString(OFD_TASK), task );

      ABTObject    constraint1   = createObject( OBJ_CONSTRAINT, constraintreqs );
      ABTObject    constraint2   = createObject( OBJ_CONSTRAINT, constraintreqs );

      setValue( constraint1, OFD_ID, new ABTInteger( 1 ) );
      setValue( constraint2, OFD_ID, new ABTInteger( 2 ) );

      // bug 621 test
      ABTValue t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)3));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      ABTBoolean b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != true)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)4));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != true)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)5));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != true)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)1));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != false)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)2));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != false)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)6));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != false)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)7));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != false)
         throw new Exception("constraints failure");

      t = constraint1.setValue(session_, OFD_TYPE, new ABTShort((short)8));
      if ((ABTError.isError(t)) || (t == null)) throw new Exception("constraints failure");
      b = (ABTBoolean)constraint1.getPropertyKey(session_, OFD_TIME, PROP_EXTTYPE_PM);
      if (b.booleanValue() != false)
         throw new Exception("constraints failure");

      constraint1.delete(session_);

      ABTObjectSet os = getObjectSet( task, OFD_CONSTRAINTS );
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTValue v = getValue( (ABTObject)e.nextElement(), OFD_ID );
         String s = v.stringValue();
         int i = 0;
      }
   }

   public void subprojectlinks() throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task       = createObject( OBJ_TASK, taskreqs );

      ABTHashtable subprjreqs = new ABTHashtable();
      subprjreqs.put( new ABTString(OFD_TASK), task );

      ABTObject    sublink    = createObject( OBJ_SUBPROJECTLINK, subprjreqs );

      setValue( sublink, OFD_ID, new ABTInteger( 1 ) );

      iterateObjectSet( getObjectSet( project, OFD_SUBPROJECTLINKS ) );

      projectIntegrity( project );
   }

   public void childTasks() throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task1       = createObject( OBJ_TASK, taskreqs );
      ABTObject    task2       = createObject( OBJ_TASK, taskreqs );
      ABTObject    task3       = createObject( OBJ_TASK, taskreqs );
      ABTObject    task4       = createObject( OBJ_TASK, taskreqs );
      ABTObject    taskMain    = createObject( OBJ_TASK, taskreqs );

      setValue( task1, OFD_PARENTTASK, taskMain );
      setValue( task2, OFD_PARENTTASK, taskMain );
      setValue( task3, OFD_PARENTTASK, taskMain );
      setValue( task4, OFD_PARENTTASK, taskMain );

      setValue( task1, OFD_ID, new ABTInteger( 1 ) );
      setValue( task2, OFD_ID, new ABTInteger( 2 ) );
      setValue( task3, OFD_ID, new ABTInteger( 3 ) );
      setValue( task4, OFD_ID, new ABTInteger( 4 ) );

      setValue( taskMain, OFD_ID, new ABTInteger( 5 ) );

      setValue( project, OFD_LASTCHILDTASK, taskMain );
      setValue( taskMain, OFD_LASTCHILDTASK, task1 );

      setValue( task1, OFD_PREVIOUSTASK, task4 );
      setValue( task1, OFD_PREVIOUSTASK, task2 );

      setValue( taskMain, OFD_LASTCHILDTASK, task3 );

      iterateTasksBackwards( taskMain );
   }

   public void iterateTasks( ABTObject parent ) throws TestRuleException
   {
      ABTValue v = getValue( parent, OFD_FIRSTCHILDTASK );
      checkError( v );

      while( v != null )
      {
         ABTObject task = (ABTObject)v;

         v = getValue( task, OFD_WBSLEVEL );
         int level = v.intValue();

         v = getValue( task, OFD_WBSSEQUENCE );
         int sequence = v.intValue();

         v = getValue( task, OFD_ID );
         int id = v.intValue();

         StringBuffer buf = new StringBuffer();
         int numspaces = 2 * ( level - 1 );
         for( int i = 0; i < numspaces; i++ ) { buf.append( ' ' ); }

//         System.out.println( buf.toString() + id + ":" + sequence );
         System.out.println( buf.toString() + id );

         iterateTasks( task );

         v = getValue( task, OFD_NEXTTASK );
         checkError( v );
      }
   }

   public void iterateObjectSet( ABTObjectSet os ) throws TestRuleException
   {
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject obj = (ABTObject)e.nextElement();
         ABTValue v = getValue( obj, OFD_ID );
         String s = v.stringValue();
         System.out.println( s );
      }
   }

   public void iterateTasksBackwards( ABTObject parent ) throws TestRuleException

   {
      ABTObject task = getObject( parent, OFD_LASTCHILDTASK );
      ABTObject firsttask = getObject( parent, OFD_FIRSTCHILDTASK );
      ABTValue v = task.getValue( session_, OFD_ID, null );
      String s = v.stringValue();

      while( task != firsttask )
      {
         task = getObject( task, OFD_PREVIOUSTASK );
         v = task.getValue( session_, OFD_ID, null );
         s = v.stringValue();
         int i = 0;
      }
   }

   public void dependencies() throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task1       = createObject( OBJ_TASK, taskreqs );
      ABTObject    task2       = createObject( OBJ_TASK, taskreqs );

      ABTHashtable dependreqs = new ABTHashtable();
      dependreqs.put( new ABTString(OFD_PREDTASK), task1 );
      dependreqs.put( new ABTString(OFD_SUCCTASK), task2 );

      ABTObject    dependency  = createObject( OBJ_DEPENDENCY, dependreqs );

      checkError( dependency.delete( session_ ) );

      ABTObjectSet os = getObjectSet( project, OFD_ALLDEPENDENCIES );
      iterateObjectSet( os );

      ABTObjectSet succDependencies = getObjectSet( task1, OFD_SUCCDEPENDENCIES );
      java.util.Enumeration e = succDependencies.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject dependElem = (ABTObject)e.nextElement();
         String s = dependElem.getObjectType();
         int j = 0;
      }

      ABTObjectSet predDependencies = getObjectSet( task2, OFD_PREDDEPENDENCIES );
      e = predDependencies.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject dependElem = (ABTObject)e.nextElement();
         String s = dependElem.getObjectType();
         int j = 0;
      }
   }

   public void assignments() throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null );
      ABTObject    resource1   = createObject( OBJ_RESOURCE, null );
      ABTObject    resource2   = createObject( OBJ_RESOURCE, null );
      ABTObject    resource3   = createObject( OBJ_RESOURCE, null );

      ABTHashtable hash1       = new ABTHashtable();
      ABTHashtable hash2       = new ABTHashtable();
      ABTHashtable hash3       = new ABTHashtable();

      hash1.put( new ABTString(OFD_PROJECT), project );
      hash2.put( new ABTString(OFD_PROJECT), project );
      hash3.put( new ABTString(OFD_PROJECT), project );
      hash1.put( new ABTString(OFD_RESOURCE), resource1 );
      hash2.put( new ABTString(OFD_RESOURCE), resource2 );
      hash3.put( new ABTString(OFD_RESOURCE), resource3 );

      ABTObject    team1       = createObject( OBJ_TEAM, hash1 );
      ABTObject    team2       = createObject( OBJ_TEAM, hash2 );
      ABTObject    team3       = createObject( OBJ_TEAM, hash3 );

      ABTObjectSet teams       = getObjectSet( project, OFD_TEAMRESOURCES );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task        = createObject( OBJ_TASK, taskreqs );

      setValue( project, OFD_FIRSTCHILDTASK, task );

      //
      // Set the name fields in each resource
      //
      setValue( resource1, OFD_NAME, new ABTString( "Resource 1" ) );
      setValue( resource2, OFD_NAME, new ABTString( "Resource 2" ) );
      setValue( resource3, OFD_NAME, new ABTString( "Resource 3" ) );

      ABTHashtable hash4       = new ABTHashtable();
      ABTHashtable hash5       = new ABTHashtable();
      ABTHashtable hash6       = new ABTHashtable();

      hash4.put( new ABTString(OFD_TASK), task );
      hash5.put( new ABTString(OFD_TASK), task );
      hash6.put( new ABTString(OFD_TASK), task );
      hash4.put( new ABTString(OFD_RESOURCE), resource1 );
      hash5.put( new ABTString(OFD_RESOURCE), resource2 );
      hash6.put( new ABTString(OFD_RESOURCE), resource3 );

      ABTObject    assignment1 = createObject( OBJ_ASSIGNMENT, hash4 );
      ABTObject    assignment2 = createObject( OBJ_ASSIGNMENT, hash5 );
      ABTObject    assignment3 = createObject( OBJ_ASSIGNMENT, hash6 );

      //
      // Now delete one of the team resources
      //
//      resource1.delete( session_ );

      ABTObjectSet os = getObjectSet( task, OFD_ASSIGNMENTS );
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject obj = (ABTObject)e.nextElement();
      }

      projectIntegrity( project );
   }

   public void viewTeam( ABTObject team ) throws TestRuleException
   {
      ABTObject resource = getObject( team, OFD_RESOURCE );
      ABTValue v = getValue( resource, OFD_NAME );
      String s = v.stringValue();
      int i = 0;
   }

   public void oneAssignmentMethod1() throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null );
      ABTObject    resource    = createObject( OBJ_RESOURCE, null );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject task = createObject( OBJ_TASK, taskreqs );
      setValue( project, OFD_FIRSTCHILDTASK, task );

      ABTHashtable hash = new ABTHashtable();
      hash.put( new ABTString(OFD_PROJECT), project );
      hash.put( new ABTString(OFD_RESOURCE), resource );
      ABTObject team = createObject( OBJ_TEAM, hash );

      ABTHashtable assignmentParams = new ABTHashtable();
      assignmentParams.put( new ABTString(OFD_TASK), task );
      assignmentParams.put( new ABTString(OFD_RESOURCE), resource );
      ABTObject assignment  = createObject( OBJ_ASSIGNMENT, assignmentParams );

      projectIntegrity( project );
   }
   
   public void projectIntegrity( ABTObject project ) throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         task;
      int               i, size;

      os = getObjectSet( project, OFD_SUBPROJECTLINKS );
      Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject sublink = (ABTObject)e.nextElement();
         ABTValue v = sublink.getValue( session_, OFD_ID, null );
         if( ABTError.isError( v ) )
            return;
      }

      teamResources( project );

      task = getObject( project, OFD_FIRSTCHILDTASK );
      while( task != null )
      {
         taskIntegrity( task );
         task = getObject( task, OFD_NEXTTASK );
      }
   }

   public void taskIntegrity( ABTObject task ) throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         assignment;
      int               i, size;

      os = getObjectSet( task, OFD_CONSTRAINTS );
      Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject constraint = (ABTObject)e.nextElement();
         ABTValue v = constraint.getValue( session_, OFD_ID, null );
         if( ABTError.isError( v ) )
            return;
      }

      System.out.println( "Assignment resources" );

      os = getObjectSet( task, OFD_ASSIGNMENTS );
      size = os.size( session_ );
      for( i = 0; i < size; i++ )
      {
         assignment = (ABTObject)os.at( session_, i );
         assignmentIntegrity( assignment );
      }
   }

   public void assignmentIntegrity( ABTObject assignment ) throws TestRuleException
   {
      ABTObject resource = getObject( assignment, OFD_RESOURCE );
      resourceIntegrity( resource );

      ABTObject task = getObject( assignment, OFD_TASK );

      int i = 0;
   }

   public void resourceIntegrity( ABTObject resource ) throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         assignment;
      int               i, size;
      ABTValue          name;

      name = getValue( resource, OFD_NAME );
      String s = name.stringValue();
      System.out.println( s );
      
      os = getObjectSet( resource, OFD_ASSIGNMENTS );
      size = os.size( session_ );
      for( i = 0; i < size; i++ )
      {
         assignment = (ABTObject)os.at( session_, i );
         int j = 0;
      }
   }
   
   public void teamResources( ABTObject project ) throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         team;
      int               i, size;

      System.out.println( "Team resources" );

      os = getObjectSet( project, OFD_TEAMRESOURCES );
      size = os.size( session_ );
      for( i = 0; i < size; i++ )
      {
         team = (ABTObject)os.at( session_, i );
         ABTObject resource = getObject( team, OFD_RESOURCE );
         resourceIntegrity( resource );
      }
   }

   public static void main( String args[] )
   {
      TestRules app = new TestRules( args );
      app.run();
   }
}