package test.io.client.mppfile;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTDriver;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.api.local.ABTObjectSpaceLocal;
import com.abtcorp.api.local.ABTDriverLocal;
import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTHashtable;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTDouble;


public class TestMppFileApp implements IABTPMRuleConstants, IABTDriverConstants
{
	protected ABTValue site_;
	IABTObjectSpace space_;
	private IABTDriver projDriver_;
	private IABTDriver siteDriver_;
		
	public TestMppFileApp() {}

	public void run()
	{
		try
		{
			System.out.println("TestMppFileApp starting...");
			space_ = new ABTObjectSpaceLocal();
            space_.startSession( null );

			siteDriver_ = space_.newABTDriver( "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
			populateSite();

            projDriver_ = space_.newABTDriver( "com.abtcorp.io.client.mppfile.ABTClientMppDriver", null );
			projDriver_.open( null );

            IABTHashTable args = space_.newABTHashTable();
            args.putItemByString( KEY_SOURCENAME, new ABTString("d:\\projects\\project1.mpp") );

			ABTValue obj = projDriver_.populate( args );
            if (ABTError.isError(obj)) throw new ABTException(((ABTError)obj).getMessage());

            IABTObject proj = (IABTObject) obj;
			IABTObject object;

			// The driver's populate() method will return an ABTValue
			// object containing an ABTProject object and associated
			// ABTTask objects.

			if ( proj instanceof IABTObject )
			{
				ABTValue prID = proj.getValue( OFD_ID );
				ABTValue prName = proj.getValue( OFD_NAME );
				System.out.println("ID = " + prID.toString() + ", NAME = " + prName.toString() );
                ABTValue val;

				System.out.println("Scanning task objects for this project...");

                val = proj.getValue( OFD_ALLTASKS );
                if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                IABTObjectSet taskoset = (IABTObjectSet) val;

                if (taskoset.size() > 0)
                {
                    for (int j = 0; j < taskoset.size(); j++)
                    {
                        object = (IABTObject) taskoset.at( j );
                        prID =  object.getValue( OFD_ID );
                        prName = object.getValue( OFD_NAME );
                      System.out.println( "Task Name = " + prName.toString() + " ID = " + prID.toString() );

                        ABTValue predDependencies = object.getValue( OFD_PREDDEPENDENCIES );
                    if ( predDependencies instanceof IABTObjectSet)
                      System.out.println( "The number of predecessor dependencies is " +
                                       ((IABTObjectSet) predDependencies).size() );

                        ABTValue succDependencies = object.getValue( OFD_SUCCDEPENDENCIES );
                    if ( succDependencies instanceof IABTObjectSet )
                      System.out.println( "The number of successor dependencies is " +
                                         ((IABTObjectSet) succDependencies).size() );

                        ABTValue assignments = object.getValue( OFD_ASSIGNMENTS );
                      System.out.println( "The number of assignments for this task is " +
                                         ((IABTObjectSet) assignments).size() );

                       ABTValue constraints = object.getValue( OFD_CONSTRAINTS );
                      if ( ((IABTObjectSet)constraints).size() > 0 )
                          System.out.println( "Task has other than default constraint" ); 
                    }
                }
              else
                  System.out.println("There are no tasks for this project.");

				System.out.println("Scanning team resources for this project...");

                val = proj.getValue( OFD_TEAMRESOURCES );
                if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                IABTObjectSet teamSet = (IABTObjectSet) val;

                if (teamSet.size() > 0)
                {
                    for (int j = 0; j < teamSet.size(); j++)
                    {
                        object = (IABTObject) teamSet.at( j );
                        prID =  object.getValue( OFD_ID );
						System.out.println( " ID = " + prID.toString() );
                    }
                }
            else
                  System.out.println("There are no team resources for this project.");
            }

			projDriver_.close( null );
            space_.endSession();

		}
		catch (Exception e)
		{
			System.out.println("Exception caught...printing stack trace...");
			e.printStackTrace();
		}
		finally
		{
			System.out.println("TestMppFileApp ended.");
		}

	}

	public static void main(String args[])
	{
		TestMppFileApp app = new TestMppFileApp();
		app.run();
	}


	private void populateSite() throws ABTException
	{
		IABTHashTable args = space_.newABTHashTable();
		ABTValue retVal = null;

		args.putItemByString(KEY_USERNAME, new ABTString( "admin" ));
		args.putItemByString(KEY_REPONAME, new ABTString( "ABT Repository" ));
		args.putItemByString(KEY_PRODUCT, new ABTString( "ABT Workbench" ));

		retVal = siteDriver_.open( args );
		if ( ABTError.isError( retVal ) )
		{
			System.out.println( "openRepo error from " + ((ABTError)retVal).getMethod() +
								((ABTError)retVal).getMessage() );
			throw new ABTException( "Driver failed to open!" );
		}

		args.putItemByString( KEY_TYPE, new ABTString(TYPE_ALL) );
		ABTValue val = siteDriver_.populate( args );

		if (ABTError.isError( val ) )
			throw new ABTException((ABTError) val);

		if ( siteDriver_ != null )
			siteDriver_.close( null );

		if ( val instanceof IABTObject )
			site_ = val;   
		else
			throw new ABTException("Site populate() failed and did not return a site object!");
	}

/*
		_MSProject		mspApp = null;
		Project			curProj = null;
		Tasks			taskSet = null;
		Task			curTask = null;

		try
		{
			mspApp = Application.create_MSProject();
//			if ( curTask != null )
			{
				mspApp.FileOpen(
					new ABTString( "d:\\projects\\project1.mpp" ),
					new ABTBoolean(false),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty(),
					ABTEmpty.getEmpty() );

				curProj = mspApp.getActiveProject();
				if ( curProj != null )
				{
					taskSet = curProj.getTasks();
					if ( taskSet != null )
					{
						int count = taskSet.getCount();

						if ( count > 0 )
						{
							for ( int i = 1; i <= count ; i++ )
							{
								curTask = taskSet.getItem( new ABTInteger(i) );
								if ( curTask != null )
								{
	                                System.out.println( "Name = " + new ABTString( curTask.getName().toString() )+
	                                 " ID = " + new ABTInteger( curTask.getID() ) );
									curTask.release();
								}
							}
						}
						taskSet.release();
					}
					curProj.release();
				}

				if ( mspApp != null )
				{
					mspApp.FileClose( new ABTInteger(0), new ABTBoolean(false) ); // 0 means "no save"
					mspApp.release();
				}
			}
		}
*/
}