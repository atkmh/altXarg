package test.io.client.mppfile;

/* ***********************************************************************
	Reads a project from a repository and saves it to 
	a new MPP file.
 **************************************************************************/

import com.abtcorp.io.ABTDriver;
import com.abtcorp.io.client.*;
import com.abtcorp.io.client.mppfile.*;

import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTDriver;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.api.local.ABTObjectSpaceLocal;
import com.abtcorp.api.local.ABTDriverLocal;
import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTHashtable;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;

import com.abtcorp.core.COM.*;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;


public class TestMppFileApp4 implements IABTPMRuleConstants, IABTDriverConstants
{
	protected ABTValue site_;
	IABTObjectSpace space_;
	private IABTDriver projDriver_;
	private IABTDriver siteDriver_;

	public TestMppFileApp4() {}

	public static void main(String args[])
	{
		TestMppFileApp4 app = new TestMppFileApp4();
		app.run();
	}

	public void run()
	{
		IABTHashTable args = null;
		ABTValue obj = null;

		try
		{
			System.out.println("TestMppFileApp4 starting... Populate from repository and save to MPP");
			space_ = new ABTObjectSpaceLocal();
			space_.startSession( null );

			siteDriver_ = space_.newABTDriver( "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
			populateSite();

			// Open the repository and the project we want to export.
			System.out.println( "Exporting project from the repository..." );
			projDriver_ = space_.newABTDriver( "com.abtcorp.io.PMWRepo.ABTPMWRepoDriver", null);
			openRepo( projDriver_ );

			// Populate a project from the repository.
			args = space_.newABTHashTable();
			args.putItemByString( KEY_TYPE, new ABTString( TYPE_PROJECT ) );
			args.putItemByString( KEY_SUBTYPE, new ABTString( SUBTYPE_FULL ) );
			args.putItemByString( KEY_EXTID, new ABTString( "TestMPP" ) );

			System.out.println( "Calling repository populate..." );
			obj = projDriver_.populate( args );
			if (ABTError.isError(obj)) throw new ABTException( "Repository populate failure " + 
																((ABTError)obj).getMessage());

			System.out.println( "Closing repository and site drivers..." );
			closeRepo( projDriver_ );
			closeRepo( siteDriver_ );

			// Got the project.  Save it to an MPP file.
			IABTObjectSet projOSet = (IABTObjectSet) obj;

			if ( projOSet instanceof IABTObjectSet )
			{
                if ( ((IABTObjectSet)projOSet).size() > 0 )
				{
                    IABTObject proj = (IABTObject) projOSet.at( 0 );
                    if ( ABTError.isError(proj) )
                        throw new ABTException( "Bad project returned " + ((ABTError)proj).getMessage());

					ABTValue val;
					ABTValue prID = proj.getValue( OFD_ID );
					ABTValue prName = proj.getValue( OFD_NAME );
					System.out.println("ID = " + prID.toString() + ", NAME = " + prName.toString() );

					System.out.println( "Creating and opening MPP driver..." );
					projDriver_ = space_.newABTDriver( "com.abtcorp.io.client.mppfile.ABTClientMppDriver", null );
					projDriver_.open( null );

					args = space_.newABTHashTable();
					args.putItemByString( KEY_DESTINATIONNAME, new ABTString("d:\\projects\\project3.mpp") );
					args.putItemByString( KEY_SOURCE, (ABTValue)proj );

					System.out.println( "Saving to d:\\projects\\project3.mpp" );
					obj = projDriver_.save( args );
					if ( ABTError.isError( obj ) )
						throw new ABTException("Error from MPP save " + ((ABTError)obj).getMessage() );

					System.out.println( "Save successful" );
					projDriver_.close( null );
					space_.endSession();
				}
			}
		}
		catch( ABTException e )
		{
			System.out.println( "ABTException caught " + e.getMessage() );
		}
		catch ( Exception e )
		{
			System.out.println("Exception caught...printing stack trace...");
			e.printStackTrace();
		}
		finally
		{
			System.out.println("TestMppFileApp ended.");
		}

	}

	private void openRepo( IABTDriver driver ) throws ABTException
	{
		IABTHashTable args = space_.newABTHashTable();
		ABTValue retVal = null;

		args.putItemByString(KEY_USERNAME, new ABTString( "admin" ));
		args.putItemByString(KEY_REPONAME, new ABTString( "ABT Repository" ));
		args.putItemByString(KEY_PRODUCT, new ABTString( "ABT Workbench" ));

		retVal = driver.open( args );
		if ( ABTError.isError( retVal ) )
		{
			System.out.println( "openRepo error from " + ((ABTError)retVal).getMethod() +
								((ABTError)retVal).getMessage() );
			throw new ABTException( "Driver failed to open!" );
		}
	}

	private void closeRepo( IABTDriver driver )
	{
		if ( driver != null )
			driver.close( null );
	}

	private void populateSite() throws ABTException
	{
		openRepo( siteDriver_ );

		IABTHashTable args = space_.newABTHashTable();
		args.putItemByString( KEY_TYPE, new ABTString(TYPE_ALL) );
		ABTValue val = siteDriver_.populate( args );

		if (ABTError.isError( val ) )
			throw new ABTException((ABTError) val);

		if ( val instanceof IABTObject )
			site_ = val;   
		else
			throw new ABTException("Site populate() failed and did not return a site object!");
	}
}