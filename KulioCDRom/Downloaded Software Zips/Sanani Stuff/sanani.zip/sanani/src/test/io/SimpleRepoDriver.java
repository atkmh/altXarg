package test.io;

import java.util.Vector;

import com.abtcorp.io.*;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTUserSession;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;

public class SimpleRepoDriver extends ABTRepositoryDriver
{
   public SimpleRepoDriver(ABTObjectSpace space, ABTUserSession session) {super(space, session);}
   
   public SimpleRepoDriver(ABTObjectSpace space, ABTUserSession session, String server, String repository, String user, String password, String product) throws ABTException, ABTInvalidLoginException, ABTInvalidLicenseException, ABTInvalidRepositoryException 
   {
      super(space, session, server, repository, user, password, product);
   }

	public boolean open() 
	{
		boolean ret = false;
		ABTRepository repo = null;
		
		try
		{
   		if (getSession() == null) login();
   	   if (getRepository() == null) 
   		{	   	
   	   	repo = getSession().connect(getRepositoryName());
   	   	if (repo != null) 
   	   		setRepository(repo);
   			else   		
   		   {
   	   	   getSession().release();
   	   	   setSession(null);
   	      	throw new ABTInvalidRepositoryException();
   		   }
   		}
   		ret = true;
		}
		catch (ABTException e)
		{
		   System.out.println(e);
		   ret = false;
		}
		finally
		{
		   return ret;
		}
	}

	private void login() throws ABTException
	{
   	ABTSession sess = ABTSession.login();
      
      if (sess != null) 
      	setSession(sess);
      else
      	throw new ABTInvalidLoginException();
	}
	
	public String[] getProjectList()
	{
      ABTCursor cursor = getRepository().select("select prName from PRProject");
      Vector v = new Vector();
      while(cursor.moveNext()) 
      {
         v.addElement(cursor.getFieldString("prName"));
      }
      
      cursor.release();
      
      String[] names = new String[v.size()];
      for (int i = 0;i < v.size();i++) 
      {
         names[i] = (String)v.elementAt(i);
      }
      
      return names;
	}

}

