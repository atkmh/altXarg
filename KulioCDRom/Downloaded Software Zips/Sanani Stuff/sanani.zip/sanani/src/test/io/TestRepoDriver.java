package test.io;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

import com.abtcorp.hub.ABTObjectSpace;
import com.abtcorp.hub.ABTObjectSet;
import com.abtcorp.hub.ABTObject;
import com.abtcorp.rulebase.*;

import com.abtcorp.repository.ABTSession;
import com.abtcorp.repository.ABTRepository;
import com.abtcorp.repository.ABTLicense;
import com.abtcorp.repository.ABTCursor;
import com.abtcorp.repository.ABTNames;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTError;

import com.abtcorp.io.*;

public class TestRepoDriver extends ABTRepositoryDriver implements ABTNames
{
   private ABTRepoDataDictionary dataDictionary_ = null;

   public TestRepoDriver(ABTObjectSpace space) {super(space);}

   public TestRepoDriver(){super();}

   public TestRepoDriver(ABTObjectSpace space, String server, String repository, String user, String password, String product) throws ABTException, ABTInvalidLoginException, ABTInvalidLicenseException, ABTInvalidRepositoryException
   {
      super(space, server, repository, user, password, product);
   }

	public boolean open() 
	{
		ABTRepository repo = null;
      boolean ret = false;
		try
		{
   		if (getSession() == null) login();
   		dataDictionary_ = new ABTRepoDataDictionary();
   		if (!dataDictionary_.isValid())
   		   dataDictionary_.createRepoDataDictionary(getSession());   // get the repository data dictionary
   	   if (getRepository() == null)
   		{
   	   	repo = getSession().connect(getRepositoryName());
   	   	if (repo != null)
   	   		setRepository(repo);
   			else
   		   {
   	   	   getSession().release();
   	   	   setSession(null);
   	      	throw new ABTInvalidRepositoryException();
   		   }
   		}
   		ret = true;
		}
		catch (ABTException e)
		{
		   System.out.println(e);
		   ret = false;
		}
		finally
		{
		   return ret;
		}
	}

	private void login() throws ABTException
	{
   	ABTSession sess = ABTSession.login();

      if (sess != null)
      	setSession(sess);
      else
      	throw new ABTInvalidLoginException();
	}

   public ABTValue populate(String selector) throws ABTException
   {
      try
      {
         ABTValue os = null;
         if (selector != null)
         {
           	os = populateProjects(selector);
         }
         else
         {
         	// No selection, get all the projects and their associated tasks...
         }              // end if (selector != null)

         return os;
      }                    // end try block
      catch (ABTException e)
      {
         System.out.println(e);
         throw e;
      }
   }

   protected String getTableName(String objectType)
   {
      if (objectType.equals("Project")) return "PRProject";
      else if (objectType.equals("Task")) return "PRTask";
      else if (objectType.equals("Resource")) return "PRResource";
      else if (objectType.equals("Assignment")) return "PRAssignment";
      // others...
      return null;
   }

	private ABTValue populateProjects(String criteria) throws ABTException
	{
      ABTValue object = null;    // local handle for results
      ABTRepository repo = getRepository();
      ABTValue val = getSpace().createObjectSet("ABTProject", "com.abtcorp.rulebase", null);
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");
         System.out.println(((ABTError)val).getMessage());
         return val;
      }
      ABTObjectSet osProj = (ABTObjectSet) val;
      ABTCursor cursor = repo.select(criteria);

      // populate object space and object set with fields from the cursor...

      try
      {
         while(cursor.moveNext()) 		// for every project in the result set...
         {
            ABTRemoteIDRepository id = new ABTRemoteIDRepository(repo.getID(),
                                                                 cursor.getFieldInt(FLD_ID));
            System.out.println("The repository ID is " + id.getRepositoryID());
            System.out.println("The prID of the current project is " + id.getPrID());

            object = getSpace().createObject("ABTProject", id, "com.abtcorp.rulebase", null);
         	if (ABTError.isError(object))
         	{
         	   System.out.println("Unable to create ABTProject in object space: " + ((ABTError) object).getMessage());
         	   return object;
         	}
         	ABTObject abtobject = (ABTObject) object; // explicit cast
         	abtobject.setValue("PRID", cursor.getField(FLD_ID));
         	abtobject.setValue("PRNAME", cursor.getField(FLD_NAME));
         	object = populateTasks(cursor.getField(FLD_NAME), abtobject.getValue("PRID").intValue());
         	if (ABTError.isError(object))
         	{
         	   System.out.println("ERROR!");
         	   System.out.println("Unrecoverable error during populating tasks");
         	   return object;
         	}
         	abtobject.setValue("PRALLTASKS", (ABTObjectSet) object);
         	osProj.add(abtobject);						// add this project object to the object set
         }                 // end while(cursor.moveNext())
      }                    // end try block
      finally
      {
         if (cursor != null)
            cursor.release();
      }

      return osProj;
	}

	private ABTValue populateTasks(ABTValue projectName, int projectID) throws ABTException
	{
	   ABTValue object = null;             // local ABTObject
	   ABTRepository repo = getRepository();
	   ABTValue val = getSpace().createObjectSet("ABTTask", "com.abtcorp.rulebase", null);
	   if (ABTError.isError(val))
	   {
	      System.out.println("ERROR!");
	      System.out.println(((ABTError)val).getMessage());
	      return val;
	   }

   	ABTObjectSet taskObjectSet = (ABTObjectSet) val;

   	ABTCursor taskCursor = repo.select("select * from prTask " +
   	                                   "where prIsTask <> 0 " +
   	                                   "and prIsMilestone = 0 " +
   	                                   "and prProjectID = " + projectID);
      try
      {
      	while (taskCursor.moveNext())		// for every task in the result set...
      	{
            ABTRemoteIDRepository id2 = new ABTRemoteIDRepository(repo.getID(),
                                               taskCursor.getFieldInt(FLD_ID));
            System.out.println("The prID of the current task is " + id2.getPrID());
      		object = getSpace().createObject("ABTTask", id2, "com.abtcorp.rulebase", null);
      		if (ABTError.isError(object))
      		{
      		   System.out.println("Unable to create an ABTTask object in the object space: " + ((ABTError) object).getMessage());
               return object;
      		}

      		ABTObject abttask = (ABTObject) object; // cast
   			abttask.setValue("PRID", taskCursor.getField(FLD_ID));
   			abttask.setValue("PRNAME", projectName);
   			abttask.setValue("PRTASKNAME", taskCursor.getField(FLD_NAME));
   			taskObjectSet.add(abttask);
   			System.out.println("Added task '" + taskCursor.getFieldString(FLD_NAME) + "' to object set.");
      	}                    // end while (taskCursor.moveNext())
   	}                       // end try block
   	finally
   	{
		   if (taskCursor != null)
		      taskCursor.release();
		}

		return taskObjectSet;

	}

   private void listAllProperties()
   {
      if (dataDictionary_ == null) return;
      if (!dataDictionary_.isValid()) return;

      //
      // Get the keys (really table names) of the data dictionary.  These will be used
      // as indexes into the data dictionary to retrieve the associated vector objects,
      // which contain rows of properties.
      //

      Hashtable repordd = dataDictionary_.getDataDictionary();
      for (Enumeration ddkeys = repordd.keys(); ddkeys.hasMoreElements();)
      {
         String objName = (String) ddkeys.nextElement();
         System.out.println("Printing properties of object '" + objName + "'");
         Vector rddVector = (Vector) repordd.get(objName);
         for (int i = 0; i < rddVector.size(); i++)
         {
            ABTRepoDataDictionary rdd = (ABTRepoDataDictionary) rddVector.elementAt(i);
            System.out.println("   " + rdd.getName());
         }

      }
   }
}
