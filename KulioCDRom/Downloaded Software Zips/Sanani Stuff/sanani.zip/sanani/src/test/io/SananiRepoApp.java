package test.io;

import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;

public class SananiRepoApp
{
   public SananiRepoApp() {}

   public void run()
   {
      try 
      {
         System.out.println("SananiRepoApp starting...");
         ABTObjectSpace space = new ABTObjectSpace();
         SimpleRepoDriver driver = new SimpleRepoDriver(space, "steveb", "ABTRepository", null, null, "Project Workbench" );
			driver.open();

			String[] list = driver.getDataRepositoryList();
			if (list.length > 0) 
			{
				System.out.println("List of ABT Repositories: ");
				for (int i = 0; i < list.length; i++)
					System.out.println(list[i]);
         	String[] projectList = driver.getProjectList();
         	if (projectList.length > 0)
         	{
         		System.out.println("List of projects in repository " + driver.getRepositoryName() + ":");
         		for (int i = 0; i < projectList.length; i++)
         			System.out.println(projectList[i]);
				}
				else
					System.out.println("There are no projects.");
			}
			else
				System.out.println("There are no repositories!");

         driver.close();
			
      } catch (Exception e) 
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
			System.out.println("SananiRepoApp ended.");
      }
   }

   public static void main(String args[])
   {
      SananiRepoApp app = new SananiRepoApp();
      app.run();
   }
}