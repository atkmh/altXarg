package  test.io;

import java.util.Enumeration;

import com.abtcorp.io.*;
import com.abtcorp.io.PMWRepo.*;
import com.abtcorp.hub.*;
import com.abtcorp.blob.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTDouble;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTEmpty;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTHashtable;
import com.abtcorp.core.ABTRemoteID;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

public class LeeNewDriver implements IABTDriverConstants, IABTPMRuleConstants, IABTPMWRepoConstants
{
   private String repositoryName_;
   private String projectExternalID_;
   private ABTObjectSpace space_;
   private ABTUserSession userSession_;
   private ABTPMWRepoDriver driver_;
   private ABTObjectSet oSet_;

   public LeeNewDriver(String[] args)
   {
      repositoryName_ = "ABTData";
      projectExternalID_ = "newProject";

      if (args != null && args.length > 0) {
         repositoryName_ = args[0];

         if (args.length > 1) {
            projectExternalID_ = args[1];
         }
      }
   }

   public void run()
   {
      try
      {
         System.out.println("LeeNewDriver starting...");
         space_ = new ABTObjectSpace();
         driver_ = new ABTPMWRepoDriver();
         driver_.setSpace(space_);
         userSession_ = space_.startSession(null);
         driver_.setUserSession(userSession_);
         openRepo();

         displayRepositories();
         displayProjects();
//make a new project
               ABTValue os = deleteTaskTest();

               oSet_ = (ABTObjectSet) os;

// Save a new project back to the repository.
 
//         saveProject("newProject");

         closeRepo();
         System.out.println("LeeNewDriver ended.");
      }
      catch (ABTException e)
      {
         e.printStackTrace();
      }

   }

   public static void main(String args[])
   {
      LeeNewDriver app = new LeeNewDriver(args);
      app.run();
   }

   private void displayRepositories()
   {
      ABTHashtable args = new ABTHashtable();
      args.put(new ABTString(KEY_COMMAND), new ABTString(CMD_LIST));
      args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_REPOSITORY));
      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         return;
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of Repositories on the currently-connected server:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
         System.out.println(e.nextElement());
      }
      System.out.println(" ");
   }

   private void displayProjects()
   {
      ABTHashtable args = new ABTHashtable();
      args.put(new ABTString(KEY_COMMAND), new ABTString(CMD_LIST));
      args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_PROJECT));
      args.put(new ABTString(KEY_REPONAME), new ABTString(repositoryName_));

      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         return;
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of projects on the currently-connected Repository:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
         System.out.println(e.nextElement());
      }
      System.out.println(" ");
   }

   private void openRepo() throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.put(new ABTString(KEY_USERNAME), new ABTString("annp"));
//      args.put(new ABTString(KEY_PASSWORD), new ABTString("administrator"));
      //
      //Use null password.
      //
//      args.put(new ABTString(KEY_REPONAME), new ABTString(repositoryName_));
      args.put(new ABTString(KEY_REPONAME), new ABTString("ann"));
		if (driver_.open(space_, userSession_, args) != null ) throw new ABTException("Driver failed to open!");
   }

      private void closeRepo()
   {
      driver_.close(space_, userSession_, null);
   }



   public ABTObjectSet deleteTaskTest() throws ABTException
   {

      LeeDriver2 sb = new LeeDriver2(repositoryName_, projectExternalID_,space_,userSession_);
      ABTValue val =  space_.createObjectSet(userSession_, OBJ_PROJECT);
      if (ABTError.isError(val))
        throw new ABTException(new ABTError( "TestRules",
         "TestRules->createDriver", "Error", "Failed to create project object set" ) );
      ABTObjectSet objSet = (ABTObjectSet) val;
      ABTObject   project     = sb.createObject( OBJ_PROJECT, null );
      //set values
      sb.setValue(project, OFD_EXTERNALID, new ABTString("ID0"));
      sb.setValue( project, OFD_NAME, new ABTString( "Project 1" ) );
      sb.setValue(project, OFD_READONLY, new ABTBoolean(false));
//      sb.setValue(project, OFD_ISLOCKED, new ABTBoolean(true));
      ((ABTObjectSet)objSet).add(userSession_, project);

      //
      // Create all the resources for the project
      //
      ABTObject   resource1   = sb.createResource( 1 );
      ABTObject   resource2   = sb.createResource( 2 );
//      ABTObject   resource3   = sb.createResource( 3 );
      ABTCurve    curve1      = new ABTCurve();
      curve1.setDefault(1);

      ABTObject   team1       = sb.createTeamResource( project, resource1, 4 );
      ABTObject   team2       = sb.createTeamResource( project, resource2, 5 );
//      ABTObject   team3       = sb.createTeamResource( project, resource3, 6 );


      //set specific resource values for each of the three resources

      sb.setValue(resource1, OFD_ID, new ABTString("1"));
      sb.setValue(resource1, OFD_EXTERNALID, new ABTString("1"));      
      sb.setValue(resource1,OFD_AVAILCURVE, curve1);

      sb.setValue(resource2, OFD_ID, new ABTString("2"));
      sb.setValue(resource2, OFD_EXTERNALID, new ABTString("2"));
      sb.setValue(resource2,OFD_AVAILCURVE, curve1);

//      sb.setValue(resource3, OFD_EXTERNALID, new ABTString("D3"));
//      sb.setValue(resource3,OFD_AVAILCURVE, curve1);


      sb.setValue( resource1, OFD_NAME, new ABTString( "Resource 1" ) );
      sb.setValue( resource2, OFD_NAME, new ABTString( "Resource 2" ) );
//      sb.setValue( resource3, OFD_NAME, new ABTString( "Resource 3" ) );

      sb.setValue( resource1, OFD_COUNT, new ABTDouble( 1 ) );
      sb.setValue( resource2, OFD_COUNT, new ABTDouble( 2 ) );
//      sb.setValue( resource3, OFD_COUNT, new ABTDouble( 3 ) );


      //
      // Create all of the tasks for the project
      //
      ABTObject    task1      = sb.createTask( project, null, 7, "task1" );
      ABTObject    task2      = sb.createTask( project, null, 8, "task2" );
      ABTObject    task3      = sb.createTask( project, null, 9, "task3" );

      //set values
      sb.setValue(task1, OFD_EXTERNALID, new ABTString("ID7"));
      sb.setValue(task2, OFD_EXTERNALID, new ABTString("ID8"));
      sb.setValue(task3, OFD_EXTERNALID, new ABTString("ID9"));
      sb.setValue( task1, OFD_NAME, new ABTString( "Task 1" ) );
      sb.setValue( task2, OFD_NAME, new ABTString( "Task 2" ) );
      sb.setValue( task3, OFD_NAME, new ABTString( "Task 3" ) );

      //
      // Create the assignments for the project
      //
      ABTObject    assignment1 = sb.createAssignment( task1, resource1, 10);
      ABTObject    assignment2 = sb.createAssignment( task2, resource2, 11);
//      ABTObject    assignment3 = sb.createAssignment( task3, resource3, 12);

      //
      // Create estimating models and task estimates for the project
      //
      ABTObject    estmodel1  = sb.createEstmodel( project, 13 );
      ABTObject    estmodel2  = sb.createEstmodel( project, 14 );
      ABTObject    estmodel3  = sb.createEstmodel( project, 15 );
      ABTObject    taskest1   = sb.createTaskestimate( task1, estmodel1, 16 );
      ABTObject    taskest2   = sb.createTaskestimate( task2, estmodel2, 17 );
      ABTObject    taskest3   = sb.createTaskestimate( task3, estmodel3, 18 );

      //
      // Create a few dependencies
      //
      ABTObject    dependency1 = sb.createDependency( task1, task2, 19 );
      ABTObject    dependency2 = sb.createDependency( task2, task3, 20 );

      //
      // Create a few deliverables
      //
      ABTObject deliv1 = sb.createDeliverable( project, 21 );
      ABTObject deliv2 = sb.createDeliverable( project, 22 );
      ABTObject deliv3 = sb.createDeliverable( project, 23 );
      //set values
      sb.setValue(deliv1, OFD_EXTERNALID, new ABTString("ID21"));
      sb.setValue(deliv2, OFD_EXTERNALID, new ABTString("ID22"));
      sb.setValue(deliv3, OFD_EXTERNALID, new ABTString("ID23"));
      sb.setValue( deliv1, OFD_NAME, new ABTString( "deliv 1" ) );
      sb.setValue( deliv2, OFD_NAME, new ABTString( "deliv 2" ) );
      sb.setValue( deliv3, OFD_NAME, new ABTString( "deliv 3" ) );


      sb.addListMember( sb.getObjectSet( task1, OFD_DELIVERABLES ), deliv1 );
      sb.addListMember( sb.getObjectSet( task2, OFD_DELIVERABLES ), deliv2 );
      sb.addListMember( sb.getObjectSet( task3, OFD_DELIVERABLES ), deliv3 );


      // Add some notes
      //
      ABTObject      note1 = sb.createNote( 24 );
      ABTObject      note2 = sb.createNote( 25 );
      ABTObject      note3 = sb.createNote( 26 );
      sb.addListMember( sb.getObjectSet( project, OFD_NOTES ), note1 );
      sb.addListMember( sb.getObjectSet( project, OFD_NOTES ), note2 );
      sb.addListMember( sb.getObjectSet( project, OFD_NOTES ), note3 );

      //
      // Add some custom field values
      //
      ABTObject      custfieldvalue1 = sb.createCustfieldvalue( 27 );
      ABTObject      custfieldvalue2 = sb.createCustfieldvalue( 28 );
      ABTObject      custfieldvalue3 = sb.createCustfieldvalue( 29 );
      sb.addListMember( sb.getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue1 );
      sb.addListMember( sb.getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue2 );
      sb.addListMember( sb.getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue3 );

        return  objSet;
   }

   private void saveProject(String extID)
   {
      try
      {
         System.out.println("Beginning save back to repository.");
         ABTHashtable args = new ABTHashtable();
         args.clear();
         args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_PROJECT));
         args.put(new ABTString(KEY_SOURCE), oSet_);
         args.put(new ABTString(KEY_UNLOCK), new ABTBoolean(true));
         ABTValue val = null;

//          if (extID != null)
//         {
            args.put(new ABTString(KEY_SUBTYPE), new ABTString(SUBTYPE_SAVEAS));
            args.put(new ABTString(KEY_EXTID), new ABTString(extID));
//         }

         val = driver_.save(space_, userSession_, args); // Save it back.
         if (val == null)
            System.out.println("Ended successful save back to repository.");
         else if (val instanceof ABTError)
            System.out.println("Save Error: " + ((ABTError)val).getMessage());
      }
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
      }

   }
}