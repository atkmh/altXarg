package test.io;

import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;

import com.abtcorp.repository.ABTNames;

import java.util.*;
import java.io.*;

public class RepositoryPropertyList implements ABTNames, ABTDriverConstants
{
   private String repositoryName_      = "DataRepo";
   private String projectExternalID_   = "2.0.5N";

   public RepositoryPropertyList()
   {
   }

   public void run()
   {
      ABTPMWRepoDriver driver = null;
      try
      {
         System.out.println( "RepositoryPropertyList starting..." );
         ABTObjectSpace space = new ABTObjectSpace();
         driver = new ABTPMWRepoDriver();
         driver.setSpace( space );
			if( !driver.open() )
			   throw new ABTException( "Driver failed to open!" );
			   
			/* I have the tables and their fields in a hashtable
			*/
			Hashtable h = driver.getDataDictionary().getDataDictionary();
			Enumeration e = h.keys();
			while( e.hasMoreElements() )
			{
			   String tablename = (String)e.nextElement();
			   makeRuleFile( tablename, ((Vector)h.get( tablename )).elements() );
		   }
	   }
      catch( Exception e )
      {
         System.out.println( "Exception caught...printing stack trace..." );
         e.printStackTrace();
      }
      finally
      {
         try
         {
            driver.close();
         }
         catch( Exception e )
         {
            e.printStackTrace();
         }
			System.out.println( "RepositoryPropertyList ended." );
      }
   }
   
   private void makeRuleFile( String tablename, Enumeration fields )
   {
      String      classname   = "ABT" + tablename.substring( 2, 3 ).toUpperCase() +
                                tablename.substring( 3 );
      String      filename    = classname + ".java";
      FileWriter  out;
      
      try { out = new FileWriter( filename ); }
      catch( IOException e ) { System.out.println( e.getMessage() ); return; }
      
      ABTRepoDataDictionary dictionary;

      writeline( out, "package com.abtcorp.rulebase;" );
      writeline( out, "" );
      writeline( out, "import  com.abtcorp.core.*;" );
      writeline( out, "import  com.abtcorp.hub.*;" );
      writeline( out, "" );
      writeline( out, "public class " + classname + " extends com.abtcorp.hub.ABTRule" );
      writeline( out, "{" );
      writeline( out, "" );
      writeline( out, "   public " + classname + "()" );
      writeline( out, "   {" );
      writeline( out, "      super();" );
      writeline( out, "   }" );
      writeline( out, "" );
      
		writeline( out, "   protected void setDefaultProperties()" );
      writeline( out, "   {" );
      
      while( fields.hasMoreElements() )
		{
		   dictionary = (ABTRepoDataDictionary)fields.nextElement();
		   
		   String prop = "\"" + dictionary.getName() + "\"";
		   String caption = "\"" + dictionary.getCaption() + "\"";
		   
		   writeline( out,
		      "      addProperty( " +
		      prop +
		      ", " +
		      caption +
		      ", " +
		      dictionary.getStringDataType() +
		      ", " +
		      "false, true, true, false, null, null, null );"
		   );
      }

      writeline( out, "   }" );
      writeline( out, "" );

      writeline( out, "   public String toString()" );
      writeline( out, "   {" );
      writeline( out, "      return \"" + classname + "\";" );
      writeline( out, "   }" );

      writeline( out, "}" );

      try { out.close(); }
      catch( IOException e ) { System.out.println( e.getMessage() ); }
	}
	
	private void writeline( FileWriter out, String line )
	{
	   try
	   {
	      out.write( line, 0, line.length() );
	      out.write( "\n", 0, 1 );
	   }
	   catch( IOException e )
	   {
	      System.out.println( e.getMessage() );
	   }
	}

   public static void main( String args[] )
   {
      RepositoryPropertyList app = new RepositoryPropertyList();
      app.run();
   }
}