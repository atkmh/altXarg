package test.io;

import java.util.Enumeration;
import java.util.Date;

import com.abtcorp.io.*;
import com.abtcorp.io.server.*;
import com.abtcorp.io.PMWRepo.*;
import com.abtcorp.io.siterepo.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.*;

import com.abtcorp.blob.ABTCurve;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;
import com.abtcorp.idl.IABTPropertyType;

public class TestPMWRepoApp implements IABTDriverConstants, IABTPMRuleConstants, IABTPMWRepoConstants, ABTNames, IABTPropertyType
{
   private String repositoryName_;
   private String productName_;
   private String projectExternalID_;
   private ABTObjectSpace space_;
   private ABTUserSession userSession_;
   private ABTPMWRepoDriver driver_;
   private ABTSiteRepoDriver siteDriver_;
   private ABTObjectSet oSet_;
   private ABTObject site_;

   public static void main(String args[])
   {
      TestPMWRepoApp app = new TestPMWRepoApp(args);
      app.run();
   }

   public TestPMWRepoApp(String[] args)
   {
//      repositoryName_ = "ABTLegacyRepo";
//      repositoryName_ = "steverep";
//      repositoryName_ = "Hajo";
      repositoryName_ = "ABTRepository";
//      repositoryName_ = "Planner";
//      repositoryName_ = "AGData";

//      projectExternalID_ = "BarfBag1";
//      projectExternalID_ = "answr05";
      projectExternalID_ = "2.0.4N";
//      projectExternalID_ = "Brutus";
//      projectExternalID_ = "PPA261";
//      projectExternalID_ = "MASTER";   // steverep
//      projectExternalID_ = "A/UA0403";
//      projectExternalID_ = "P2";       // Planner
      
      productName_ = "ABT Workbench";

      if (args != null && args.length > 0) {
         repositoryName_ = args[0];

         if (args.length > 1) {
            projectExternalID_ = args[1];
         }
      }
   }

   public void run()
   {
      try
      {
         System.out.println("TestPMWRepoApp starting at " + new Date() );

         space_ = new ABTObjectSpace();
         userSession_ = space_.startSession(null);
         boolean displayResults = true;
         
         populateSite();

         driver_ = new ABTPMWRepoDriver();
         driver_.setSpace(space_);
         driver_.setUserSession(userSession_);
         openRepo(driver_);

         //
         // Test various driver.execute() functionality
         //
         //testExecuteFunctionality();
         
         //
         // Unlock a project.
         //
         //unlockProject();

         //
         // Display a list of repositories.
         //
         //displayRepositories();

         //
         // Display a list of projects.
         //
         //displayProjects();

         //
         // Populate thin projects.
         //
         //populateThinProjects();

         //
         // Populate the object space n times.  This will test populating a clean
         // space and also populating a space that already contains the same
         // project.
         //
         for (int pass = 1; pass < 2; pass++)
         {
		      System.out.println("Beginning pass " + pass + " of populating an object space.");
            populateProject(displayResults);
            //populateProject(false);
         }

         //removeSubProjectLink();
         
         displayTaskHierarchy();
         
         //unlockProject();
         //checkProjectAggregations();
         
         //
         // Save project back to repository.
         //
         //saveProject(null);
         //populateProject(displayResults);

         //
         // Save the project back a second time.  This will verify project version number incrementing.
         //
         //saveProject(null);

         //
         // Save a new project back to the repository.
         //
         //saveProject("BarfBag1");

         //
         // Delete project and then repopulate it.
         //
         //deleteProject("BarfBag1");
         //deleteProject("2.0.4N");
         //projectExternalID_ = "Barfbag1";
         //populateProject();

         //
         // Delete a Resource object
         //
         //deleteResource("DBA");
         //deleteResource("DBA");

         closeRepo(driver_);
         closeRepo(siteDriver_);

         System.out.println("TestPMWRepoApp ended at " + new Date());
      }
      catch (ABTException e)
      {
         e.printStackTrace();
      }
   }

   private void populateSite() throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
      siteDriver_ = new ABTSiteRepoDriver();
      siteDriver_.setSpace(space_);
      siteDriver_.setUserSession(userSession_);
      openRepo(siteDriver_);
      
      for (int i = 0; i <= 0; i++)
      {
         System.out.println("Populating site object, pass " + (i+1) );
         ABTValue val = siteDriver_.populate(space_, userSession_, args);
         if (ABTError.isError( val ) )
            throw new ABTException((ABTError) val);
         if (val instanceof ABTObject )
         {
            site_ = (ABTObject) val;
         }
         else
            throw new ABTException("Site populate() failed and did not return a site object!");
      }
   }

   private void displayRepositories()
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_COMMAND, new ABTString(CMD_LIST));
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_REPOSITORY));
      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         System.exit(1);
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of Repositories on the currently-connected server:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
         System.out.println(e.nextElement());
      }
      System.out.println(" ");
   }

   private void displayProjects()
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_COMMAND, new ABTString(CMD_LIST));
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_PROJECT));
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));

      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         System.exit(1);
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of projects on the currently-connected Repository:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
         System.out.println(e.nextElement());
      }
      System.out.println(" ");
   }

   private void openRepo(ABTRepositoryDriver driver) throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_USERNAME, new ABTString("admin"));
      args.putItemByString(KEY_PASSWORD, new ABTString("administrator"));

      //args.putItemByString(KEY_USERNAME, new ABTString("Steve"));
      //args.putItemByString(KEY_PASSWORD, new ABTString(""));

      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_PRODUCT, new ABTString(productName_));
		if (driver.open(space_, userSession_, args) != null ) throw new ABTException("Driver failed to open!");
   }

   private void closeRepo(ABTRepositoryDriver driver)
   {
      if (driver != null)
         driver.close(space_, userSession_, null);
   }

   private void populateThinProjects()
   {
      populateThinByType(1);     // projects only
      populateThinByType(4);     // projects + custom field values only
      populateThinByType(2);     // projects + tasks only
      populateThinByType(3);     // projects + tasks only (driven by ABTArray)
   }

   private void populateThinByType(int type)
   {
      try
      {
         String sType;
         ABTHashtable args = new ABTHashtable();
		   args.putItemByString(KEY_TYPE, new ABTString(TYPE_PROJECT));

         switch (type)
         {
            case 1:        // projects only
		         args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_PROJECTONLY));
		         sType = "(Projects only; driven by repository)";
		         break;

            case 2:       // projects + tasks only
               args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_PROJECTANDTASKSONLY));
               sType = "(Projects and Tasks only; driven by repository)";
               break;

            case 3:      // projects + tasks only (driven by ABTArray)
               args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_PROJECTANDTASKSONLY));
               ABTArray extIDs = new ABTArray();
               extIDs.add(new ABTString(projectExternalID_));
               args.putItemByString(KEY_EXTIDS, extIDs);
               sType = "(Projects and Tasks only; driven by ABTArray entries)";
               break;

            case 4:      // projects + cust field values only 
               args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_PROJECTANDCUSTFIELDSONLY));
               sType = "(Projects and Custom Field Values only; driven by repository)";
               break;
               
            default:
               return;
         }

		   ABTValue val = driver_.populate(space_, userSession_, args);
         if (ABTError.isError(val))
         {
            ABTError err = (ABTError) val;
            System.out.println("Populate Error: Component: " + err.getComponent());
            System.out.println("Populate Error: Method: "    + err.getMethod());
            System.out.println("Populate Error: Message: "   + err.getMessage());
            Object info = err.getInfo();
            if (info != null)
            {
               if (info instanceof String)
                  System.out.println("Populate Error: Info: " + info);
               else if (info instanceof ABTError)
               {
                  System.out.println("Populate Error: Info Component: " + err.getComponent());
                  System.out.println("Populate Error: Info Method: "    + err.getMethod());
                  System.out.println("Populate Error: Info Message: "   + err.getMessage());
               }

            }
            System.exit(1);
         }
         
         System.out.println("The following projects have been thinly loaded " + sType + ":");
         oSet_ = (ABTObjectSet) val;
         int size = oSet_.size(userSession_);
         for (int i = 0; i < size; i++)
         {
            ABTObject proj = (ABTObject) oSet_.at(userSession_, i);
            ABTValue extID = proj.getValue(userSession_, OFD_EXTERNALID);
            if (ABTError.isError(extID)) continue;
            ABTValue readonly = proj.getValue(userSession_, OFD_READONLY);
            if (ABTError.isError(readonly)) continue;
            System.out.println(extID.toString() + (readonly.booleanValue() ? " (READONLY)" : " (READ/WRITE)") );
         }
      }
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
         System.exit(1);
      }
      finally
      {
      }
   }

   private void populateProject(boolean displayResults)
   {
      System.out.println("Populating project '" + projectExternalID_ + "'");
      try
      {
         ABTHashtable args = new ABTHashtable();

			// Ask the Repository driver to populate the object space with a
			// project and its tasks.  The driver's populate() method will return
			// an ABTValue objectset containing ABTProject objects and associated
			// ABTTask objects.

		   args.putItemByString(KEY_TYPE, new ABTString(TYPE_PROJECT));
		   args.putItemByString(KEY_EXTID, new ABTString(projectExternalID_));
		   args.putItemByString(KEY_LOCK, new ABTBoolean(true));
		   args.putItemByString(KEY_RELAXSUBPROJECTLOCKING, new ABTBoolean(true));
		   ABTValue os = driver_.populate(space_, userSession_, args);
         if (os instanceof ABTObjectSet)
         {
            oSet_ = (ABTObjectSet) os;
            if ( !displayResults ) return;
            System.out.println("This project object set contains " + oSet_.size(userSession_) + " objects.");
            System.out.println("Scanning project objects in object set...");
            for (int i = 0; i < oSet_.size(userSession_); i++)
            {
               ABTObject object = (ABTObject) oSet_.at(userSession_, i);
               ABTValue prID = object.getValue(userSession_, OFD_ID);
         	   if (ABTError.isError(prID)) throw new ABTException(((ABTError)prID).getMessage());

               ABTValue prName = object.getValue(userSession_, OFD_NAME);
         	   if (ABTError.isError(prName)) throw new ABTException(((ABTError)prName).getMessage());

               ABTRemoteIDRepository rmtID = (ABTRemoteIDRepository) object.getValue(userSession_, "ABTRemoteID");

               System.out.println("PRID = "        + prID.toString() +
                                  ", PRNAME = "    + prName.toString() +
                                  ", REMOTEID = " + rmtID.getRepositoryID() + "," + rmtID.getPrID());

               System.out.println("The project is tagged as " + (object.isDeleted(userSession_) ? "deleted" : "not deleted") );
               ABTValue val;

               val = object.getValue(userSession_, OFD_REPONAME);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("The project came from repository " + val);

               val = object.getValue(userSession_, OFD_VERSION);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("The project's version number is " + val);

               val = object.getValue(userSession_, OFD_ISOPEN);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("The project's isOpen flag is set to '" + val.booleanValue() + "' (" + val.intValue() + ")");

               val = object.getValue(userSession_, OFD_READONLY);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("This project is " + (val.booleanValue() ? "READONLY" : "READ/WRITE")  );

               val = object.getValue(userSession_, OFD_READONLYRIGHT);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("This project's READONLYRIGHT value is " + (val.booleanValue() ? "true" : "false")  );

               val = object.getValue(userSession_, OFD_ISMASTER);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("This project " + (val.booleanValue() ? "IS " : "IS NOT ") + "a master project" );

               val = object.getValue(userSession_, OFD_LOCKEDBYME);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("This project " + (val.booleanValue() ? "IS " : "IS NOT ") + "locked by the current user" );

               val = object.getValue(userSession_, OFD_LOCKEDBY);
               if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("The userid who has the lock on this project is " + (ABTValue.isNull(val) ? "NOBODY!" : val.stringValue())  );

               val = object.getValue(userSession_, OFD_TEAMRESOURCES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println("The number of team resources is " + ((ABTObjectSet)val).size(userSession_));

               ABTObjectSet assObjects = (ABTObjectSet) object.getValue(userSession_, OFD_ALLASSIGNMENTS);
               System.out.println("The number of assignments read for this project is " + assObjects.size(userSession_));

               ABTObjectSet estModels = (ABTObjectSet) object.getValue(userSession_, OFD_ESTMODELS);
               System.out.println("The number of estimating models for this project is " + estModels.size(userSession_));

               ABTObjectSet taskEstimates = (ABTObjectSet) object.getValue(userSession_, OFD_ALLTASKESTIMATES);
               System.out.println("The number of task estimates for this project is " + taskEstimates.size(userSession_));

               int childTaskCount = getChildTaskCount(object);
               System.out.println("The number of tasks whose parent is the project is " +  childTaskCount);

               ABTObjectSet noteObjects = (ABTObjectSet) object.getValue(userSession_, OFD_NOTES);
               System.out.println("The number of notes for this project object is " + noteObjects.size(userSession_));

               ABTObjectSet subLinks = (ABTObjectSet) object.getValue(userSession_, OFD_SUBPROJECTLINKS);
               System.out.println("The number of subproject links for this project object is " + subLinks.size(userSession_));

               //
               // Test reading not-visible property
               //
               ABTProperty prop = object.getProperty(userSession_, OFD_RESOLVEIPDLIST);
               val = prop.getPropertyKey(PROP_KVISIBLE);
               if ( ABTError.isError( val ) ) throw new ABTException( (ABTError) val );
               boolean visible = (ABTValue.isNull( val ) ? false : val.booleanValue() );
               System.out.println("Project property OFD_RESOLVEIPDLIST " + (visible ? "IS " : "IS NOT ") + "visible");
               
               System.out.println("Scanning task objects for this project...");

               val = object.getValue(userSession_, OFD_ALLTASKS);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
         	   ABTObjectSet taskoset = (ABTObjectSet) val;

               if (taskoset.size(userSession_) > 0)
               {
                  for (int j = 0; j < taskoset.size(userSession_); j++)
                  {
                     object = (ABTObject) taskoset.at(userSession_, j);
                     prID = object.getValue(userSession_, OFD_ID);
                     prName = object.getValue(userSession_, OFD_NAME);
                     val = object.getValue(userSession_, "ABTRemoteID");
                     String sRemoteID;
                     if ( val instanceof ABTRemoteIDRepository )
                     {
                        rmtID = (ABTRemoteIDRepository) val;
                        sRemoteID = rmtID.getRepositoryID() + "," + rmtID.getPrID();
                     }
                     else
                        sRemoteID  = "UNKNOWN (NEW OBJECT)";
                     System.out.println("  PRID = " + prID.toString() +
                                        ", PRNAME = " + prName.toString() +
                                        ", REMOTEID = " + sRemoteID);

                     childTaskCount = getChildTaskCount(object);
                     System.out.println("The number of child tasks is " + childTaskCount);

                     ABTValue predDependencies = object.getValue(userSession_, OFD_PREDDEPENDENCIES);
                     if (predDependencies instanceof ABTObjectSet)
                        System.out.println("The number of predecessor dependencies is " +((ABTObjectSet) predDependencies).size(userSession_));
                     ABTValue succDependencies = object.getValue(userSession_, OFD_SUCCDEPENDENCIES);
                     if (succDependencies instanceof ABTObjectSet)
                        System.out.println("The number of successor dependencies is " +((ABTObjectSet) succDependencies).size(userSession_));
                     ABTValue assignments = object.getValue(userSession_, OFD_ASSIGNMENTS);
                     System.out.println("The number of assignments for this task is " +((ABTObjectSet) assignments).size(userSession_));

                     ABTValue sl = object.getValue(userSession_, OFD_SUBPROJECTLINK);
                     if (!ABTError.isError( sl ) && !ABTValue.isNull( sl ) )
                     {
                        System.out.println("* * * * * This task is a subproject proxy task * * * * *");
                        ABTObject subLink = (ABTObject) sl;
                        ABTValue slType = subLink.getValue(userSession_, OFD_SUBPROJECTTYPE);
                        String type = "UNKNOWN";
                        if (slType.shortValue() == 2)
                           type = "PROJECT";
                        else if (slType.shortValue() == 3)
                           type = "TASK";
                        System.out.println("* * * * * The subproject type is " + type + " * * * * *");
                        if (type.equals("TASK"))
                        {
                           ABTValue v = subLink.getValue(userSession_, OFD_SUBTASK);
                           if (v instanceof ABTObject)
                           {
                              ABTObject subTask = (ABTObject) v;
                              v = subTask.getValue(userSession_, OFD_NAME);
                              if (!ABTError.isError( v ) )
                                 System.out.println("The name of the task referenced in the subproject link is " + v.stringValue() );
                              v = subTask.getValue(userSession_, OFD_PROJECT);
                              if (v instanceof ABTObject)
                              {
                                 ABTObject subProj = (ABTObject) v;
                                 v = subProj.getValue(userSession_, OFD_NAME);
                                 if (!ABTError.isError( v ))
                                    System.out.println("The project name of the project which owns the task referenced in the subproject link is " + v.stringValue() );
                              }
                           }
                        }
                     }
                     if (j == 21)
                     {
                        object.setValue(userSession_, OFD_NAME, new ABTString(prName.toString() + "x"));
                        prName = object.getValue(userSession_, OFD_NAME);
                        System.out.println("The new value of this task's name is " + prName.toString());
                     }           // end if (j == 21)
                  }              // end for (int j = 0; j < taskoset.size(.....
               }                 // end if (taskoset.size(userSession_) ...
               else
                  System.out.println("There are no tasks for this project.");
            }                    // end for (int i = 0; ...
         }                       // end if (os instanceof ABTObjectSet)
         else if (os instanceof ABTError)
         {
            ABTError err = (ABTError) os;
            System.out.println("Populate Error: Component: " + err.getComponent());
            System.out.println("Populate Error: Method: "    + err.getMethod());
            System.out.println("Populate Error: Message: "   + err.getMessage());
            Object info = err.getInfo();
            if (info != null)
            {
               if (info instanceof String)
                  System.out.println("Populate Error: Info: " + info);
               else if (info instanceof ABTError)
               {
                  System.out.println("Populate Error: Info Component: " + err.getComponent());
                  System.out.println("Populate Error: Info Method: "    + err.getMethod());
                  System.out.println("Populate Error: Info Message: "   + err.getMessage());
               }
               else if (info instanceof Throwable)
               {
                  System.err.println("Populate Error: Info message: " + ((Throwable)info).getMessage() );
                  System.err.println("Populate Error: Info string: " + ((Throwable)info).toString() );
                  ((Throwable)info).printStackTrace();
               }

            }
         }
      }                          // end try block
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
      }
   }

   private int getChildTaskCount(ABTObject obj)
   {
      ABTValue task = obj.getValue(userSession_, OFD_FIRSTCHILDTASK);
      if (task == null || ABTError.isError(task) || task instanceof ABTEmpty)
         return 0;
      ABTValue lastTask = obj.getValue(userSession_, OFD_LASTCHILDTASK);
      if (task == null || ABTError.isError(lastTask) || lastTask instanceof ABTEmpty)
         return 0;

      int count = 1;
      while (task != lastTask)
      {
         count++;
         task = ((ABTObject)task).getValue(userSession_, OFD_NEXTTASK);
      }

      return count;
   }

   private void saveProject(String extID)
   {
      try
      {
         System.out.println("Beginning save back to repository.");

         /*
         ABTObject projObj = (ABTObject) oSet_.at(userSession_, 0);
         ABTObjectSet teamOs = (ABTObjectSet) projObj.getValue(userSession_, OFD_TEAMRESOURCES);
         ABTObject teamObj = (ABTObject) teamOs.at(userSession_, 0);
         ABTObject resourceObj = (ABTObject) teamObj.getValue(userSession_, OFD_RESOURCE);
         resourceObj.setValue(userSession_, OFD_EXTERNALID, new ABTString("Barf") );
         resourceObj.setValue(userSession_, OFD_ID, new ABTInteger(9999) );
         */

         ABTHashtable args = new ABTHashtable();
         args.putItemByString(KEY_TYPE, new ABTString(TYPE_PROJECT));
         args.putItemByString(KEY_SOURCE, oSet_);
         // args.putItemByString(KEY_UNLOCK, new ABTBoolean(true));
         if (extID != null)
         {
            args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_SAVEAS));
            args.putItemByString(KEY_EXTID, new ABTString(extID));
         }
         ABTValue val = null;
         
         ABTObject proj = (ABTObject) oSet_.at(userSession_, 0);
         val = proj.getValue(userSession_, OFD_REPONAME);
         if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
         System.out.println("The project's home repository is " + val);

         
         val = driver_.save(space_, userSession_, args); // Save it back.
         if (val == null)
            System.out.println("Ended successful save back to repository.");
         else if (val instanceof ABTError)
         {
            ABTError err = (ABTError) val;
            System.out.println("Save Error: Component: " + err.getComponent());
            System.out.println("Save Error: Method:    " + err.getMethod());
            System.out.println("Save Error: Message:   " + err.getMessage());
            System.out.println("Save Error: Code:      " + err.getCode() );
            Object info = err.getInfo();
            if (info != null)
            {
               if (info instanceof String)
                  System.out.println("Save Error: Info: " + info);
               else if (info instanceof ABTError)
               {
                  System.out.println("Save Info Error: Component: " + err.getComponent());
                  System.out.println("Save Info Error: Method: "    + err.getMethod());
                  System.out.println("Save Info Error: Message: "   + err.getMessage());
               }
               else if (info instanceof Throwable)
               {
                  System.err.println("Populate Error: Info message: " + ((Throwable)info).getMessage() );
                  System.err.println("Populate Error: Info string: " + ((Throwable)info).toString() );
                  ((Throwable)info).printStackTrace();
               }

            }
         }
      }
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
      }

   }

   private void deleteProject(String extID)
   {
      System.out.println("Deleting project '" + extID + "' from the object space");

      ABTObjectSet os = (ABTObjectSet) space_.findObject( userSession_, OBJ_PROJECT,
         OFD_EXTERNALID + " = '" + extID + "'" );

      Enumeration e = os.elements( userSession_ );
      if (e.hasMoreElements())
      {
         ABTObject proj = (ABTObject) e.nextElement();
         proj.delete(userSession_);
      }
   }

   private void testDeleted(String extID)
   {
      if (extID == null) return;

      System.out.println("Beginning delete object test using External ID '" + extID + "'");

      int size = oSet_.size(userSession_);
      ABTObjectSet os = (ABTObjectSet) space_.findObject( userSession_, OBJ_PROJECT,
         OFD_EXTERNALID + " = '" + extID + "'" );

      Enumeration e = os.elements( userSession_ );
      if ( e.hasMoreElements() )
      {
         ABTObject proj = (ABTObject) e.nextElement();
         ABTValue candidateExtID = proj.getValue(userSession_, OFD_EXTERNALID);
         if (ABTError.isError(candidateExtID) || candidateExtID == null)
         {
            System.out.println("Cannot extract external ID property from project object");
            return;
         }

         if (!extID.equals(candidateExtID.stringValue()) )
         {
            System.out.println("External IDs don't match.");
            return;
         }

         ABTRemoteIDRepository id = (ABTRemoteIDRepository) proj.getID().getRemote(userSession_);
         proj.delete(userSession_);
         boolean isDeleted = proj.isDeleted(userSession_);
         System.out.println("After project deletion, the project is tagged as " +
                            (isDeleted ? "deleted" : "not deleted") );

         ABTValue deletedObj = space_.findObject(userSession_, OBJ_PROJECT, id);
         if (ABTError.isError(deletedObj))
         {
            System.out.println("Error occurred when trying to get a deleted project");
            return;
         }

         if (deletedObj.equals(proj))
         {
            isDeleted = ((ABTObject)deletedObj).isDeleted(userSession_);
            System.out.println("After retrieval of deleted project, the project is tagged as " +
                               (isDeleted ? "deleted" : "not deleted") );
            ABTValue err = ((ABTObject)deletedObj).setValue(userSession_, OFD_ID, new ABTInteger(1234567));
            if (ABTError.isError(err))
               System.out.println("Error in trying to set pmID in project object: " +
                                  ((ABTError)err).getMessage());
         }
      }
      System.out.println("Ending delete object test using External ID '" + extID + "'");
   }

   private void unlockProject()
   {
      ABTHashtable args = new ABTHashtable();

      args.putItemByString(KEY_COMMAND,  new ABTString(CMD_UNLOCK));
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_LOCKTYPE, new ABTString(LCK_IMPORTEXPORT));
      args.putItemByString(KEY_EXTID,    new ABTString(projectExternalID_));

      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
         System.out.println(((ABTError)val).getMessage());
      else
         System.out.println("Lock successfully released (or lock not held in the first place!)");
   }

   private void deleteResource(String extID) throws ABTException
   {
      System.out.println("Deleting Resource object with external ID " + extID);
      boolean deleted = false;

      //
      // Get the collection of Resource objects held by the Site.
      //
      ABTValue val = site_.getValue(userSession_, OFD_RESOURCES);
      if ( ABTError.isError( val ) )
         throw new ABTException((ABTError) val);

      //
      // Search the Resource collection looking for the one we want to
      // delete.
      //
      Enumeration e = ((ABTObjectSet)val).elements(userSession_);
      while (e.hasMoreElements())
      {
         ABTObject resource = (ABTObject) e.nextElement();
         val = resource.getValue(userSession_, OFD_EXTERNALID);
         if (ABTError.isError( val ))
            throw new ABTException((ABTError) val);
         String resExtID = val.stringValue();

         if (extID.equals(resExtID))
         {
            val = resource.delete(userSession_);
            if (ABTError.isError( val ))
               throw new ABTException((ABTError) val);
            deleted = true;
            break;
         }     // end if
      }        // end while()

      if (deleted)
         System.out.println("Resource found and deleted!");
      else
         System.out.println("Resource not found");
   }

   private void displayTaskHierarchy() throws ABTException
   {
      System.out.println("* * * * Task Hierarchy Display * * * *");
      ABTObject projObj = (ABTObject) oSet_.at(userSession_, 0);
      String projName = projObj.getValue(userSession_, OFD_NAME).toString();
      System.out.println(projName);
      ABTValue v = projObj.getValue(userSession_, OFD_WBSSEQUENCE);
      if ( ABTValue.isNull( v ) )
         throw new ABTException( "Can't get WBSSequence!" );
      ABTArray WBSTaskArray = (ABTArray) v;
      int size = WBSTaskArray.size();
      for (int i = 0; i < size; i++)
      {
         ABTObject taskObj = (ABTObject) WBSTaskArray.at(i);
         int WBSLevel = taskObj.getValue(userSession_, OFD_WBSLEVEL).intValue();
         String indentation = getIndentation(WBSLevel);
         String taskName = taskObj.getValue(userSession_, OFD_NAME).toString();
         if (taskName.length() == 0)
            taskName = "(Unknown task name)";
         System.out.println(indentation + taskName.toString());
      }
   }

   private String getIndentation(int WBSLevel)
   {
      StringBuffer sb = new StringBuffer(3*WBSLevel); // allow enough room for all spaces

      for (int i = 0; i < WBSLevel; i++)
         sb.append("   ");     // allow 3 blanks for each indentation level
      return sb.toString();
   }

   private void checkAggregations(String aggName) throws ABTException
   {
      ABTValue val;
      ABTObject proj = (ABTObject) oSet_.at(userSession_, 0);
      
      System.out.println("");
      System.out.println("* * * * * * Testing Aggregations * * * * * *");
      
      val = proj.getValue(userSession_, OFD_MASTER_TEAM);
      if (ABTError.isError( val ))
         throw new ABTException(((ABTError)val).getMessage());
      
      //val = proj.getValue(userSession_, OFD_TEAMRESOURCES);
      
      ABTHashtable args = new ABTHashtable();
      Enumeration e = ((ABTSortedArray)val).elements();
      while (e.hasMoreElements())
      {
         //ABTObject team = (ABTObject) e.nextElement();
         //ABTObject resource = (ABTObject) team.getValue(userSession_, OFD_RESOURCE);
         ABTObject resource = (ABTObject) e.nextElement();
         String rName = resource.getValue(userSession_, OFD_NAME).toString();
         args.clear();
         args.putItemByString(OFD_RESOURCE, resource);
         args.putItemByString(OFD_UNIT, new ABTShort( kHours ));
         System.out.println("Aggregating property '" + aggName + "' over resource '" + rName + "'");
         val = proj.getValue(userSession_, aggName, args);  // e.g., OFD_ALLOCCURVE
         if (ABTError.isError( val ))
            throw new ABTException((ABTError)val);
         if ( !(val instanceof ABTCurve) && !(val instanceof ABTTime) && !(val instanceof ABTBoolean) && !(ABTValue.isNull(val)) )
            throw new ABTException("Oops! Aggregation is not an ABTCurve or an ABTTime!");
         if ( val instanceof ABTTime || val instanceof ABTBoolean )
            System.out.println("The value of Project." + aggName + " is " + val.toString() );
      }
   }

   private void checkProjectAggregations() throws ABTException
   {
      checkAggregations(OFD_ALLOCCURVE);
      checkAggregations(OFD_ACTCURVE);
      checkAggregations(OFD_ESTCURVE);
      checkAggregations(OFD_EACCURVE);
      checkAggregations(OFD_VARIANCECURVE);
      checkAggregations(OFD_EACH_AVAIL);
      checkAggregations(OFD_AVAILABILITY);
      checkAggregations(OFD_UNUSED_AVAILABILITY);
      
      checkAggregations(OFD_AVAILSTART);
      checkAggregations(OFD_AVAILFINISH);
      checkAggregations(OFD_ISOPEN);
   }

   private void testExecuteFunctionality() throws ABTException
   {
      ABTValue val;
      ABTHashtable args = new ABTHashtable();
      
      //
      // Filter by criteria
      //
      args.putItemByString(KEY_COMMAND, new ABTString(CMD_FILTER_PROJECTS_BY_CRITERIA));
      args.putItemByString(KEY_PCTEXPENDED, new ABTDouble(0.0));
      val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
         throw new ABTException( (ABTError)val );
   }

   private void removeSubProjectLink() throws ABTException
   {
      ABTValue val;
      ABTObject proj = (ABTObject) oSet_.at(userSession_, 0);
      val = proj.getValue(userSession_, OFD_SUBPROJECTLINKS);
      if ( ABTError.isError( val ) ) throw new ABTException((ABTError) val);
      ABTObjectSet subProjOs = (ABTObjectSet) val;
      int size;
      if ((size = subProjOs.size(userSession_)) > 0)
      {
         System.out.println("Prior to removal, there are " + size + " subproject link objects in the project.");
         ABTObject subProjectLink = (ABTObject) subProjOs.at(userSession_, 0);
         val = subProjectLink.delete(userSession_);
         if ( ABTError.isError( val ) ) throw new ABTException((ABTError) val);
         size = subProjOs.size(userSession_);
         System.out.println("After deletion of subprojectlink[0], there are " + size + " subproject link objects in the project.");
      }
      
   }
}