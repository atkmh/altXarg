package test.io;

//
// This program stress tests the finalizer logic for ABT Repository-related objects.
// The program should run from start to finish with no errors detected.  There should
// be no error dialog boxes or message boxes from the repository.
// It should be run against a repository with multiple projects and tasks.
//

import java.lang.Thread;
import com.abtcorp.core.*;
import com.abtcorp.repository.*;

public class FinalizerStressTest implements Runnable, ABTNames
{
   private ABTSession session_;
   
   public FinalizerStressTest() {}

   public void run()
   {
      System.out.println("FinalizerStressTest beginning...");

      //
      // Create a Repository session.
      //
      
      session_ = ABTSession.login();
      if (session_ == null)
      {
         System.out.println("Unable to get an ABT Session object.");
         return;
      }

      //
      // Connect to the system repository and fetch rows from the PRField table.
      //
      
      fetchRepoInfo();
      
      //
      // Connect to the data repository and fetch rows from PRProject and PRTask tables.
      //
      
      fetchProjectInfo();
      
      session_.release();        // finally, release the session
      System.gc();               // schedule garbage collection
      System.runFinalization();  // force finalize() methods to run
      
      System.out.println("FinalizerStressTest ended.");
   }                    // end run()

   private void fetchRepoInfo()
   {
		ABTRepository systemRepo = session_.getSystem();
		
		if (systemRepo == null)
		{
		   System.out.println("Unable to get a system repository!");
		   return;
		}

   	ABTCursor cursor = systemRepo.select("select * from prField order by prTableName, prName");

   	System.out.println("Beginning fetch of PRField tuples...");
      int i;
      for (i = 0; cursor.moveNext(); i++){}
      System.out.println("Ended fetch of " + i + " PRField tuples...");
      
      cursor.release();          // first release cursor
      systemRepo.release();      // then release repository
      System.gc();               // force garbage collection
      System.runFinalization();  // run finalizer methods
   }
   
   private void fetchProjectInfo()
   {
      ABTRepository dataRepo = session_.connect("?");
      if (dataRepo == null)
      {
         System.out.println("Unable to get an ABT Data Repository object.");
         return;
      }

      System.out.println("Selecting all projects from the PRProject table...");
      
      ABTCursor cursor = dataRepo.select("select * from PRProject");

      if (cursor != null)
      {
         while(cursor.moveNext()) 		// for every project in the result set...
         {
         	System.out.println("Fetching tasks for a repository project...");
         	//
         	// Now get all the tasks for this project.
         	//
         	ABTCursor taskCursor = dataRepo.select("select * from prTask " + 
         	                                   "where prIsTask <> 0 " + 
         	                                   "and prIsMilestone = 0 " + 
         	                                   "and prProjectID = " + cursor.getFieldInt(FLD_ID));
         	if (taskCursor != null)
         	{
            	while (taskCursor.moveNext())		// for every task in the 2nd result set...
            	{
            	}
               
               System.out.println("Done fetching tasks for a repostiory project...");
               
           		taskCursor.release();
            	
            	//
            	// Invoke the Java VM garbage collector.  If there is anything wrong with
            	// the management of repository-related objects after releasing a cursor
            	// object, it will be manifested shortly.  
            	//
            	
            	System.gc();               // schedule garbage collection
            	System.runFinalization();  // invoke finalizer methods now
         	}                 // end if (taskCursor != null)   
         }                    // end while (cursor.moveNext())
      }                       // end if (cursor != null)

      cursor.release();    // first release the project cursor
      dataRepo.release();  // then release the repository

      System.gc();               // schedule garbage collector
      System.runFinalization();  // run all of the finalizer methods      
   }
   
   private void sleep(long sleeptime)
   {
      try
      {
         Thread.sleep(sleeptime);
      }
      catch (InterruptedException e)
      {
         e.printStackTrace();
      }
   }
   
   public static void main(String argv[])
   {
//      System.runFinalizersOnExit(true);

      try
      {
         FinalizerStressTest fst = new FinalizerStressTest();

         fst.run();
      } catch (Exception exception)
      {
         exception.printStackTrace();
      }
   }
}