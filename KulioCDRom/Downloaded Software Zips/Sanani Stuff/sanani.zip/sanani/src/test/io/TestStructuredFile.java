package test.io;

import java.io.*;
import java.util.*;
import com.abtcorp.io.*;

public class TestStructuredFile implements Runnable
{
   static final int NUMBER_OF_THREADS     = 20;
   static final int NUMBER_OF_ITERATIONS  = 1000;
   static final int NUMBER_OF_OBJECTS     = 5000;
   static final int MEAN_SIZE             = 10000;
   static final int SDEV_SIZE             = 1000;
   
   static int uniform (Random random, int min, int max)        {return (int)Math.round(random.nextDouble() * (max - min) + min);}
   static int gaussian(Random random, int mean, double sdev)   {return (int)Math.round(random.nextGaussian() * sdev + mean);}
   
   File              path_;
   ABTStructuredFile file_;
   Random            key_  = new Random();
   Random            size_ = new Random();
   
   Object randomKey()   {return new Integer(uniform(key_, 1, NUMBER_OF_OBJECTS));}
   int    randomSize()  {return gaussian(size_, MEAN_SIZE, SDEV_SIZE);}

   public TestStructuredFile(String name) throws IOException
   {
      path_ = new File("test.dat"); path_.delete();
      file_ = new ABTStructuredFile(path_);
   }
   
   public void run()
   {
      try {
         for (int index = 0; index < NUMBER_OF_ITERATIONS; index++) {
            Object key = randomKey();

            file_.readBytes(key);

            int size = randomSize();

            if (size <= 0) file_.remove(key);
            else           file_.writeBytes(key, new byte[size]);
         }
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
   
   void start() throws InterruptedException
   {
      Thread[] threads = new Thread[NUMBER_OF_THREADS];

      for (int index = 0; index < NUMBER_OF_THREADS; index++) {
         threads[index] = new Thread(this);
         threads[index].start();
      }

      for (int index = 0; index < NUMBER_OF_THREADS; index++)
         threads[index].join();
   }

   void dump()
   {
      System.out.println(file_);
   }

   public void compact() throws IOException
   {
      System.out.println("Compacting...");

      File temporary = changeExtension(path_, "tmp"); temporary.delete();

      ABTStructuredFile tmp = new ABTStructuredFile(temporary);
         
      for (Enumeration enumeration = file_.keys(); enumeration.hasMoreElements(); ) {
         Object key = enumeration.nextElement();

         tmp.writeBytes(key, file_.readBytes(key));
      }

      tmp.close();

      file_.close(); path_.delete();
      
      temporary.renameTo(path_);
      
      file_ = new ABTStructuredFile(path_);
   }

   static File changeExtension(File path, String extension)
   {
      String result = path.getPath();
      
      int name   = result.lastIndexOf(File.separator);
      int period = result.lastIndexOf('.');

      if (period > name) result = result.substring(0, period);

      return new File(result + "." + extension);
   }

   public static void main(String argv[])
   {
      try {
         TestStructuredFile test = new TestStructuredFile("test.dat");

         test.start();

         test.compact();
         
         test.dump();
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }
}