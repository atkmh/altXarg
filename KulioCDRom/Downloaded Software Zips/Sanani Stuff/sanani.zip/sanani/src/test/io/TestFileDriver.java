package test.io;

import java.io.File;

import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.core.ABTException;

public class TestFileDriver extends ABTFileDriver
{
   public TestFileDriver(ABTObjectSpace space, String file) {super(space,file);}
   
   public void save(ABTValue os, Object criteria) throws ABTNotImplementedException
   {
      // How do I get the objects that I need to write from the space?
      File file = getFile();
   }
}