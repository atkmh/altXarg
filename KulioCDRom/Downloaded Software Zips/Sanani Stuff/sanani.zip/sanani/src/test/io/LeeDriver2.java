package test.io;

import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.objectModel.pm.*;
import com.abtcorp.io.PMWRepo.*;
import com.abtcorp.idl.IABTPMRuleConstants;


public class LeeDriver2 implements IABTPMRuleConstants
{
   protected String             repositoryName_ = "ABTRepository";
   protected String             projectExternalID_;
   protected ABTObjectSpace     space_;
   protected ABTUserSession     session_;
   protected ABTPMWRepoDriver   driver_;

   public LeeDriver2()
   {
   }

   public LeeDriver2(String repo, String extID, ABTObjectSpace objSpace, ABTUserSession sess)
   {
    repositoryName_ = repo;
    projectExternalID_ = extID;
    space_ = objSpace;
    session_ = sess;
   }


   private void createDriver() throws ABTException
   {
//      driver_ = new ABTPMWRepoDriver();
//      driver_.setSpace( space_ );
//      driver_.setUser( "admin" );
//      driver_.setUserSession( session_ );
//      if( !driver_.open() )
//         throw new ABTException( new ABTError( "TestRules",
//            "TestRules->createDriver", "Error", "Driver failed to open!" ) );
   }

   public void setValue( ABTObject object, String propname, ABTValue value ) throws ABTException
   {
      ABTValue err = object.setValue( session_, propname, value, null );
      checkError( err );
   }

   public ABTValue getValue( ABTObject object, String propname ) throws ABTException
   {
      ABTValue err = object.getValue( session_, propname, null );
      checkError( err );
      return err;
   }

   public void addListMember( ABTObjectSet set, ABTObject object ) throws ABTException
   {
      ABTValue err = set.add( session_, object );
      checkError( err );
   }

   public ABTObject addNew( ABTObjectSet set ) throws ABTException
   {
      ABTValue err = set.addToSet( session_, null, false );
      checkError( err );
      return (ABTObject)err;
   }

   public void removeListMember( ABTObjectSet set, ABTObject object ) throws ABTException
   {
      ABTValue err = set.removeFromSet( session_, object, 0 );
      checkError( err );
   }

   public void checkError( ABTValue value ) throws ABTException
   {
      if( ABTError.isError( value ) )
         throw new ABTException( (ABTError)value );
   }

//   public void createObjectSpace() throws ABTException
   public void createObjectSpace() throws ABTException
   {
      space_ = new ABTObjectSpace();
      session_ = space_.startSession( null );

//      createDriver();
   }

   public ABTObject createObject( String type, ABTHashtable h ) throws ABTException
   {
      ABTValue v = space_.createObject( session_, type, null, h );
//      setValue( (ABTObject)v, OFD_EXTERNALID, new ABTString( "proj1" ) );
      checkError( v );
      return (ABTObject)v;
   }

   public ABTObject createAssignment( ABTObject task, ABTObject resource, int id) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_TASK), task );
      hash.put( new ABTString(OFD_RESOURCE), resource );

      ABTObject assignment = createObject( OBJ_ASSIGNMENT, hash );
      setValue( assignment, OFD_ID, new ABTInteger( id ) );
      return assignment;
   }

   public ABTObject createConstraint( ABTObject task, int id ) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_TASK), task );

      ABTObject constraint = createObject( OBJ_CONSTRAINT, hash );
      setValue( constraint, OFD_ID, new ABTInteger( id ) );

      return constraint;
   }

   public ABTObject createCustfieldvalue( int id ) throws ABTException
   {
      ABTObject custfieldvalue = createObject( OBJ_CUSTFIELDVALUE, null );
      setValue( custfieldvalue, OFD_ID, new ABTInteger( id ) );

      return custfieldvalue;
   }

   public ABTObject createDeliverable( ABTObject project, int id ) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_PROJECT), project );

      ABTObject deliverable = createObject( OBJ_DELIVERABLE, hash );
      setValue( deliverable, OFD_ID, new ABTInteger( id ) );

      return deliverable;
   }

   public ABTObject createDependency( ABTObject prevtask, ABTObject succtask, int id ) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_PREDTASK), prevtask );
      hash.put( new ABTString(OFD_SUCCTASK), succtask );

      ABTObject dependency = createObject( OBJ_DEPENDENCY, hash );
      setValue( dependency, OFD_ID, new ABTInteger( id ) );

      return dependency;
   }

   public ABTObject createEstmodel( ABTObject project, int id ) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_PROJECT), project );

      ABTObject estmodel = createObject( OBJ_ESTIMATINGMODEL, hash );
      setValue( estmodel, OFD_ID, new ABTInteger( id ) );

      return estmodel;
   }

   public ABTObject createNote( int id ) throws ABTException
   {
      ABTObject note = createObject( OBJ_NOTE, null );
      setValue( note, OFD_ID, new ABTInteger( id ) );

      return note;
   }

   public ABTObject createResource( int id ) throws ABTException
   {
      ABTObject resource = createObject( OBJ_RESOURCE, null );
      setValue( resource, OFD_ID, new ABTInteger( id ) );

      return resource;
   }

   public ABTObject createTask( ABTObject project, ABTObject parentTask, int id ,String extID) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_PROJECT), project );
      if( parentTask != null )
         hash.put( new ABTString(OFD_PARENTTASK), parentTask );

      ABTObject task = createObject( OBJ_TASK, hash );
      setValue( task, OFD_ID, new ABTInteger( id ) );
      setValue( task, OFD_EXTERNALID, new ABTString( extID ) );

      return task;
   }

   public ABTObject createTaskestimate( ABTObject task, ABTObject estmodel, int id ) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_TASK), task );
      hash.put( new ABTString(OFD_ESTMODEL), estmodel );

      ABTObject taskestimate = createObject( OBJ_TASKESTIMATE, hash );
      setValue( taskestimate, OFD_ID, new ABTInteger( id ) );

      return taskestimate;
   }

   public ABTObject createTeamResource( ABTObject project, ABTObject resource, int id ) throws ABTException
   {
      ABTHashtable hash = new ABTHashtable();

      hash.put( new ABTString(OFD_PROJECT), project );
      hash.put( new ABTString(OFD_RESOURCE), resource );

      ABTObject team = createObject( OBJ_TEAM, hash );
      setValue( team, OFD_ID, new ABTInteger( id ) );

      return team;
   }

   public ABTObjectSet findObject( String objectType, String criteria ) throws ABTException
   {
      ABTValue v = space_.findObject( session_, objectType, criteria );
      checkError( v );
      return (ABTObjectSet)v;
   }

   public ABTObjectSet getObjectSet( ABTObject object, String objectSetName )
      throws ABTException
   {
      ABTValue err = object.getValue( session_, objectSetName, null );
      checkError( err );
      return (ABTObjectSet)err;
   }

   public ABTObject getObject( ABTObject object, String objectName )
      throws ABTException
   {
      ABTValue err = object.getValue( session_, objectName, null );
      checkError( err );
      return (ABTObject)err;
   }

   public void deleteObject( ABTObject object ) throws ABTException
   {
      checkError( object.delete( session_ ) );
   }
}
