package	test.io.client.pmwfile;

import com.abtcorp.io.client.pmwfile.*;

import com.abtcorp.api.local.*;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;
import com.abtcorp.idl.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTArray;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;

import com.abtcorp.objectModel.pm.*;

import java.util.Enumeration;
import java.io.*;

import com.abtcorp.core.*;

public class TestPMWFileApp implements	IABTDriverConstants, IABTPMRuleConstants, IABTPropertyType
{
   private ABTString repositoryName_;
   private ABTString productName_;
   private ABTString projectExternalID_;
   private ABTString userName_;
   private ABTObjectSpaceLocal space_;   
   private IABTDriver driver_;
   private IABTDriver siteDriver_;
   private IABTObjectSet oSet_;
   private IABTObject site_;
   private IABTDriver lcldriver_;
   public static final String PROD_WORKBENCH	= "ABT Workbench".intern();
       
   
   public TestPMWFileApp(String[] args)
   {
	  //repositoryName_     = new ABTString("ABTRepository");
	  //projectExternalID_  = new ABTString("2.0.4N");
	  repositoryName_     = new ABTString("steverep");
	  projectExternalID_  = new ABTString("MASTER");
	  productName_        = new ABTString(PROD_WORKBENCH);
	  userName_           = new ABTString("admin");
	  
	  if (args != null && args.length >	0) {
		 repositoryName_	= new ABTString(args[0]);

		 if	(args.length > 1) {
			projectExternalID_ = new ABTString(args[1]);
		 }
	  }
   }

   public void run()
   {
    ABTValue value = null;
    IABTObject projObj = null;
    try
      {
         System.out.println("TestPMWFileApp starting...");
         
         space_  = new ABTObjectSpaceLocal();
         space_.startSession(null);
         
         site_ = populateSite(space_);
        // showSite(site_);
         
         driver_ = space_.newABTDriver("com.abtcorp.io.PMWRepo.ABTPMWRepoDriver", null);
       
         openRepo(driver_, space_);
		 System.out.println("Populating an object space.");
         value = populateProject(space_);
         
         closeRepo(driver_, space_);        
         closeRepo(siteDriver_, space_);

         // Get the project out of the set 
	     if (value instanceof IABTObjectSet) 
         { 
            IABTObjectSet  projectSet = (IABTObjectSet)value;                   
            value = projectSet.at(0);         
            if (value instanceof IABTObject)
                projObj = (IABTObject)value;
         }
 
         
	     System.out.println("\nPopulating from the repository has ended.");
	     showProject((IABTObject)projObj);
	     
	 
	 
        System.out.println("\nTestPMWFileApp save local file.");
        lcldriver_ = space_.newABTDriver("com.abtcorp.io.client.pmwfile.ABTIOPMWFileDriver", null);
        
        IABTHashTable argss = space_.newABTHashTable();	        
	    argss.putItemByString(KEY_DESTINATIONNAME,new ABTString("d:\\sanani\\ide\\io\\client\\pmwfile\\Marjan.lcl"));
	    argss.putItemByString(KEY_TYPE ,new ABTString("Project"));
	    argss.putItemByString(KEY_SOURCE ,(ABTValue)projObj);	
	 //   System.out.println("\nBefore Saving to a file.");
	 //   showProject((IABTObject)projObj); 
        lcldriver_.save(argss);
        
       
     
        
        ABTObjectSpaceLocal   space2  = new ABTObjectSpaceLocal();
        lcldriver_ = space2.newABTDriver("com.abtcorp.io.client.pmwfile.ABTIOPMWFileDriver", null);	    
        space2.startSession(null);
//        populateSite(space2);
        IABTHashTable argpp = space2.newABTHashTable();	        
	    argpp.putItemByString(KEY_SOURCENAME,new ABTString("d:\\sanani\\ide\\io\\client\\pmwfile\\Marjan.lcl"));
	    argpp.putItemByString(KEY_TYPE ,new ABTString("Project"));
	    System.out.println("\nTestPMWFileApp populate from local file.");  
	    //space2.startTransaction();
        ABTValue value2 = lcldriver_.populate(argpp);
      
        showProject((IABTObject)value2); 
        /*
        if ( value2 instanceof IABTObject)
            displayTaskHierarchy((IABTObject)value2);
        if ( value2 instanceof IABTObject)
	        printWBSStructure((IABTObject)value2, "     ");
	    */    
        IABTHashTable argss2 = space2.newABTHashTable();
        //CHECK THIS IT MIGHT NEED TO BE SPACE2
	       
	    argss2.putItemByString(KEY_DESTINATIONNAME,new ABTString("d:\\sanani\\ide\\io\\client\\pmwfile\\Marjan2.lcl"));
	    argss2.putItemByString(KEY_TYPE ,new ABTString("Project"));
	    argss2.putItemByString(KEY_SOURCE ,value2);	    
        System.out.println("\nTestPMWFileApp save  from local file 2nd time."); 
        lcldriver_.save(argss2);

        System.out.println("TestPMWFileApp ended.");
      }
      catch (ABTException e)
      {
         e.printStackTrace();
      }
   }
   
   
   private IABTObject populateSite(ABTObjectSpaceLocal space) throws ABTException
   {
      IABTHashTable args = space.newABTHashTable();
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
      
      siteDriver_ = space.newABTDriver("com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);

      openRepo(siteDriver_, space);
     
      ABTValue val = siteDriver_.populate(args);
      
      if (ABTError.isError( val ) )
         throw new ABTException((ABTError) val);
      if (val instanceof IABTObject )
      {
         site_ = (IABTObject) val;   
      }
      else
         throw new ABTException("Site populate() failed and did not return a site object!");
     return site_;
   }
   
   

   private void openRepo(IABTDriver driver, ABTObjectSpaceLocal space) throws ABTException
   {
      IABTHashTable args = space.newABTHashTable();
      args.putItemByString(KEY_USERNAME, new ABTString("admin"));
      args.putItemByString(KEY_PASSWORD, new ABTString("administrator"));
      
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_PRODUCT, new ABTString(productName_));
      if (driver.open(args) != (ABTValue)null ) 
		    throw new ABTException("Driver failed to open!");
   }
   
      
   private void closeRepo(IABTDriver driver, ABTObjectSpaceLocal space)
   {
      if (driver != null)
         driver.close(null);
   }

    
   private ABTValue populateProject(ABTObjectSpaceLocal space)
   {
     ABTValue ret = (ABTValue) null;
      System.out.println("Populating project '" + projectExternalID_ + "'");
      try
      {
         IABTHashTable args = space.newABTHashTable();
			// Ask the Repository driver to populate the object space with a
			// project and its tasks.  The driver's populate() method will return
			// an ABTValue objectset containing ABTProject objects and associated
			// ABTTask objects.

		   args.putItemByString(KEY_TYPE,  new ABTString(TYPE_PROJECT));
		   args.putItemByString(KEY_EXTID, new ABTString(projectExternalID_));
		   args.putItemByString(KEY_LOCK,  new ABTBoolean(true));
		   ABTValue os = driver_.populate(args);
         if (os instanceof IABTObjectSet)
         {
            oSet_ = (IABTObjectSet) os;
            System.out.println("This project object set contains " + oSet_.size() + " objects.");
            System.out.println("Scanning project objects in object set...");            
            ret = (ABTValue) oSet_;
         }                       // end if (os instanceof ABTObjectSet)
         else if (os instanceof ABTError)
         {
            ABTError err = (ABTError) os;
            System.out.println("Populate Error: Component: " + err.getComponent());
            System.out.println("Populate Error: Method: "    + err.getMethod());
            System.out.println("Populate Error: Message: "   + err.getMessage());
            Object info = err.getInfo();
            if (info != null)
            {
               if (info instanceof String)
                  System.out.println("Populate Error: Info: " + info);
               else if (info instanceof ABTError)
               {
                  System.out.println("Populate Error: Info Component: " + err.getComponent());
                  System.out.println("Populate Error: Info Method: "    + err.getMethod());
                  System.out.println("Populate Error: Info Message: "   + err.getMessage());
               }
               
            }
         }
      } 
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
        return ret;
      }
   }

   //=======================================================================
   // print out the method properties and the associated objects/object sets
   //=======================================================================
   private ABTError showSite(IABTObject site)
   {
      ABTError err = null;
      
      err = show(site, OFD_ID, OFD_NAME, OFD_WEEKSTART);
      if (err != null)    return err;
/*   
      // show calendar blob
      ABTValue val = site.getValue(OFD_CALENDAR);
      if (ABTError.isError(val))
         return (ABTError)val;
      if (ABTValue.isNull(val))
         System.out.println(OFD_CALENDAR + ":  null or empty ");
      else
         System.out.print(OFD_CALENDAR + " = " + val.toString() + ";  ");

      // show site calendar object
      System.out.println("\nSite calendar:");
      val = site.getValue(OFD_STDCALENDAR);
      if (val instanceof  IABTObject)
         show ((IABTObject)val, OFD_ID, OFD_NAME, null);
      else
         return new ABTError("Test", "showSite()", "Invalid Data", "site calendar is not found.");

      err = show(site, OFD_TYPECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CHARGECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CALENDARS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_TIMEPERIODS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ESTMODELS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ADJRULES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
*/
      err = showResources(site);
      if (err != null)    return err;
/*
      err = showCustomFields(site);
      if (err != null)    return err;
 */  
      return null;
   }


   //=======================================================================
   // print out the resource properties and the associated objects/object sets
   //=======================================================================
   private ABTError showResources(IABTObject parent)
   {
      ABTError err = null;
    
      System.out.println("\nScanning resources...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(OFD_RESOURCES);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of resources is 0.");
            return null;
         }
         else
            System.out.println("The total number of resources in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showResources()", "Invalid Data", "Resources is not an obect set.");

      // getting resources and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, OFD_EXTERNALID, OFD_CATEGORY);
         if (err != null)    return err;
        /*
         // show calendar blob
         ABTValue val = obj.getValue(OFD_CALENDAR);
         if (ABTError.isError(val))
            return (ABTError)val;
         if (ABTValue.isNull(val))
            System.out.println(OFD_CALENDAR + ":  null or empty ");
         else
            System.out.print(OFD_CALENDAR + " = " + val.toString() + ";  ");

         err = show(obj, OFD_BASECALENDAR, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;

         err = show(obj, OFD_TYPECODE, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;
         
         err = show(obj, OFD_NOTES, OFD_ID, OFD_RECORDID, OFD_VALUE);
         if (err != null)    return err;
         
        */
        /*
         // change some value to test save
         ABTValue val = obj.setValue(OFD_NAME, new ABTString (obj.getValue(OFD_NAME).stringValue() + 1));
         if (val instanceof ABTError)
            return (ABTError) val;
         */ 
         System.out.println(" ");         
         
      }
      
      return null;
   }

   //=======================================================================
   // print out the team properties and the associated objects/object sets
   //=======================================================================
   private ABTError showTeams(IABTObject parent)
   {
      ABTError err = null;
    
      System.out.println("\nScanning teams...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(OFD_TEAMRESOURCES);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of teams is 0.");
            return null;
         }
         else
            System.out.println("The total number of teams in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showTeams()", "Invalid Data", "Teams is not an object set.");

      // getting teams and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         
         err = show(obj, OFD_ID, OFD_PROJECTID, OFD_RESOURCEID);
         if (err != null)    return err;
         
//         err = show(obj, OFD_RESOURCE, OFD_ID, OFD_NAME, null);
//         if (err != null)    return err;
         
          System.out.println(" ");                  
      }
      
      return null;
   }

   
   
   private ABTError showProject(IABTObject project)
   {
      ABTError err = null;
      
      System.out.println("\nDisplaying project...");

      err = show(project, OFD_ID, OFD_EXTERNALID, OFD_NAME);
      if (err != null)    return err;
      
 //    err = showTeams(project);
 //    if (err != null)    return err;

/*
      ABTValue task = project.getValue(OFD_FIRSTCHILDTASK);
      if (task instanceof IABTObject)
      {
         ABTValue name = ((IABTObject) task).getValue(OFD_NAME);
         System.out.println("The first child task is " + name.toString());
      }

      task = project.getValue(OFD_LASTCHILDTASK);
      if (task instanceof IABTObject)
      {
         ABTValue name = ((IABTObject) task).getValue(OFD_NAME);
         System.out.println("The last child task for this project is " + name.toString());
      }
  */
      try{
     //  displayTaskHierarchy(project);
      //if (err != null)    return err;
      }
      catch (Exception e)
      {
        ;
      }
     //err = showList(project, OFD_ALLASSIGNMENTS, null, OFD_TASK, OFD_NAME, OFD_RESOURCE, OFD_NAME);
     // if (err != null)    return err;
      
     //err = showList(project, OFD_TEAMRESOURCES, null, OFD_RESOURCE, OFD_NAME, OFD_RESOURCEID, OFD_PROJECTID );
     // if (err != null)    return err;
      
      err = showList(project, OFD_SUBPROJECTLINKS, null, OFD_SUBPROJECT, OFD_NAME, OFD_SUBTASK, OFD_NAME);
      if (err != null)    return err;
  /*    
      err = showList(project, OFD_ALLTASKESTIMATES, null, OFD_TASK, OFD_NAME, OFD_ESTMODEL, OFD_NAME);
      if (err != null)    return err;
      
      err = showList(project, OFD_ALLPAGEMEMBERS, null, OFD_PAGE, OFD_NAME, OFD_CUSTOMFIELD, OFD_NAME);
      if (err != null)    return err;
      
      
      err = moveTasks(project);
      if (err != null)    return err;
      

      // create some tasks for this project
   	err = createNewTasks(project);
      if (err != null)    return err;
    
      err = showTasks(project, OFD_ALLTASKS);
      if (err != null)    return err;

      err = showDeliverables(project, OFD_ALLDELIVERABLES);
      if (err != null)    return err;      

      err = showPages(project, OFD_ALLPAGES);
      if (err != null)    return err;
            
      //err = showPages(project, OFD_ALLPAGES);
      //if (err != null)    return err;
      
      err = show(project, OFD_ALLPAGEMEMBERS, OFD_ID, OFD_PAGEID, OFD_SEQUENCE);
      if (err != null)    return err;

      err = show(project, OFD_ALLPACKAGES, OFD_ID, OFD_NAME, OFD_projectID);
      if (err != null)    return err;

      err = show(project, OFD_PACKAGES, OFD_ID, OFD_NAME, OFD_RECCONDITION);
      if (err != null)    return err;

      err = show(project, OFD_RECRULES, OFD_ID, OFD_NAME, OFD_RECCONDITION);
      if (err != null)    return err;

      err = show(project, OFD_ALLASSIGNMENTS, OFD_ID, OFD_TASKID, OFD_RESOURCEID);
      if (err != null)    return err;
      
      err = show(project, OFD_ALLDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
      if (err != null)    return err;
      
      err = show(project, OFD_ALLTASKESTIMATES, OFD_ID, OFD_FORMULA, OFD_TASKID);
      if (err != null)    return err;
      
      err = show(project, OFD_ALLPACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_PACKAGEID);
      if (err != null)    return err;
      */    
  
      System.out.println(" ");
      return null;
   }


   
   private ABTError showList(IABTObject parent, String list, String nameField, String refField1, String nameField1, String refField2, String nameField2)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + list + "...");
      
      IABTObjectSet oset = (IABTObjectSet) parent.getValue(list);
      if (oset instanceof  IABTObjectSet)
         System.out.println("The total number of objects in set = " +(( IABTObjectSet) oset).size());
      else
         return new ABTError("Test", "showList()", "Invalid Data", list + " is not an obect set.");

      // iterate thru the object set
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, nameField, null);
         if (err != null)    return err;

         ABTValue val = obj.getValue(refField1);
         if (ABTError.isError(val))  
            return (ABTError) val;         
         else if (val instanceof IABTObject)
         {
            err = show((IABTObject)val, OFD_ID, nameField1, null);
            if (err != null)    return err;
         }
         
         val = obj.getValue(refField2);
         if (ABTError.isError(val))  
            return (ABTError) val;         
         else if (val instanceof IABTObject)
         {
            err = show((IABTObject)val, OFD_ID, nameField2, null);
            if (err != null)    return err;
         }
         
         System.out.println(" ");
      }
      
      return null;
   }

   //=======================================================================
   // Retrieve an object or an object set specified by "field" from the "parent" object
   // and print out the values in "field".
   //=======================================================================
   private ABTError show(IABTObject parent, String field, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTError err = null;

      val1 = parent.getValue(field);

      if (ABTValue.isNull(val1))
         System.out.println("\n" + field + ":  null or empty ");

      else if (val1 instanceof  IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) val1;
         
         System.out.println("\n" + field + ":  total number of objects in set = " + oset.size());
         
         if (oset.size() > 0)
         {
            for (int j = 0; j < oset.size(); j++)
            {
               IABTObject object = (IABTObject) oset.at( j);
               err = show (object, field1, field2, field3);
               if (err != null)
                  return err;
            }
         }
      }
      else if (val1 instanceof  IABTObject)
      {
         IABTObject object = (IABTObject) val1;
         System.out.println("\n" + field + ": ");         
         err = show (object, field1, field2, field3);
         if (err != null)
            return err;
      }
      else
         System.out.println( "\n" + field + " is not an object set or an object.");
         
      return null;
   }

   //=======================================================================
   // print out the property values of the input object
   //=======================================================================
   private ABTError show(IABTObject object, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTValue val3 = null;

      if (object == null)
         return new ABTError ("Test", "show()", "Invalid Data", "The input object is null");
      
      String type = pad (object.getObjectType() + ":", 22);
       ABTValue val = object.getValue("ABTRemoteID");
      if (ABTError.isError(val))
         return (ABTError)val;
      //if (val instanceof ABTRemoteIDRepository)
      //   System.out.print( type + " RepoID = " + ((ABTRemoteIDRepository)val).getRepositoryID() + ",  ");
      //else
      //   System.out.println(type + " RemoteID = null or empty ");
         
     if (field1 != null)
      {
         val1 = object.getValue(field1);
         if (ABTError.isError(val1))
            return (ABTError)val1;
         if (ABTValue.isNull(val1))
            System.out.println(field1 + ":  null or empty ");
         else
            System.out.print(field1 + " = " + val1.toString() + ",  ");
      }
         
      if (field2 != null)
      {
         val2 = object.getValue(field2);
         if (ABTError.isError(val2))
            return (ABTError)val2;
         if (ABTValue.isNull(val2))
            System.out.println(field2 + ":  null or empty ");
         else
            System.out.print(field2 + " = " + val2.toString() + ", ");
      }
      
      if (field3 != null)
      {
         val3 = object.getValue(field3);
         if (ABTError.isError(val3))
            return (ABTError)val3;
         if (ABTValue.isNull(val3))
            System.out.println(field3 + ":  null or empty ");
         else
            System.out.print(field3 + " = " + val3.toString());
      }
      
      System.out.println(" ");
      
      return null;
   }
   
   private String pad(String str, int maxlen)
   {
      String newStr = str;
      
      str.trim();
      for (int i=str.length(); i<maxlen; i++)
         newStr = newStr.concat(" ");
         
      return newStr;
   }
   
   
   
   public static void main(String args[])
   {
	  TestPMWFileApp app =	new TestPMWFileApp(args);
	  app.run();
	  System.out.println( "\n End of Main");
   }




  private void displayTaskHierarchy(IABTObject projObj) throws ABTException
   {
      System.out.println("* * * * Task Hierarchy Display * * * *");
      
      String projName = projObj.getValue(OFD_NAME).toString();
      System.out.println(projName);
      ABTValue v = projObj.getValue(OFD_WBSSEQUENCE);
      if ( ABTValue.isNull( v ) )
         throw new ABTException( "Can't get WBSSequence!" );
      
      IABTArray WBSTaskArray = null;   
      if ( v instanceof IABTArray)
        WBSTaskArray = (IABTArray) v;
      
      int size = WBSTaskArray.size();
      for (int i = 0; i < size; i++)
      {
         IABTObject taskObj = (IABTObject) WBSTaskArray.get(i);
         int WBSLevel = taskObj.getValue(OFD_WBSLEVEL).intValue();
         String indentation = getIndentation(WBSLevel);
         String taskName = taskObj.getValue(OFD_NAME).toString();
         if (taskName.length() == 0)
            taskName = "(Unknown task name)";
      
         System.out.println(indentation + taskName.toString());
     
      }
   }
   
   private String getIndentation(int WBSLevel)
   {
      StringBuffer sb = new StringBuffer(5*WBSLevel); // allow enough room for all spaces
      
      for (int i = 0; i < WBSLevel; i++)
         sb.append("     ");     // allow 5 blanks for each indentation level
      return sb.toString();
   }


static public void printWBSStructure(IABTObject currentNode, String indent)
	{

		try
		{
			ABTValue val = currentNode.getValue(OFD_FIRSTCHILDTASK);
			if (ABTError.isError(val))
				throw new ABTException(((ABTError)val).getMessage() + " (error ongetValue(OFD_FIRSTCHILDTASK))");

			while (!ABTValue.isNull(val))
			{
				// add task to vector
				IABTObject task = (IABTObject) val;
				System.out.println(indent + task.getValue(OFD_NAME));
				// get children
				printWBSStructure(task, indent + "  ");
				// get the next sibling task
				val = task.getValue(OFD_NEXTTASK);
				if (ABTError.isError(val))
            		throw new ABTException(((ABTError)val).getMessage() + " (erroron getValue(OFD_FIRSTCHILDTASK))");
			}
		}
		catch (Exception e)
		{
			System.out.println("printWBSStructure exception...");
			e.printStackTrace();
		}
	}



}