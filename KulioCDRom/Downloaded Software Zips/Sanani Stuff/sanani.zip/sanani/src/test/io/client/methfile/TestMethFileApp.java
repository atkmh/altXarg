package	test.io.client.methfile;

import com.abtcorp.io.client.methfile.*;

import com.abtcorp.api.local.*;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;
import com.abtcorp.idl.*;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;

import com.abtcorp.objectModel.pm.*;

import java.util.Enumeration;
import java.io.*;

import com.abtcorp.core.*;

public class TestMethFileApp implements	IABTDriverConstants, IABTPMRuleConstants, IABTPropertyType
{
   private ABTString repositoryName_;
   private ABTString productName_;
   private ABTString projectExternalID_;
   private ABTString userName_;
   private ABTObjectSpaceLocal space_;
   private IABTDriver driver_;
   private IABTDriver siteDriver_;
   private IABTObjectSet oSet_;
   private IABTObject site_;
   private IABTDriver lcldriver_;
   public static final String PROD_ABTPLANNER= "ABT Planner".intern();


   public  TestMethFileApp(String[] args)
   {
	  repositoryName_     = new ABTString("ABTRepository");
	  projectExternalID_  = new ABTString("DB-SAMPLE");
	  productName_        = new ABTString(PROD_ABTPLANNER);
	  userName_           = new ABTString("admin");

	  if (args != null && args.length >	0) {
		 repositoryName_	= new ABTString(args[0]);

		 if	(args.length > 1) {
			projectExternalID_ = new ABTString(args[1]);
		 }
	  }
   }

   public void run()
   {
    ABTValue os = null;

    try
      {
         System.out.println("TestPMWFileApp starting...");

         space_  = new ABTObjectSpaceLocal();
         space_.startSession(null);

         populateSite(space_);

         driver_ = space_.newABTDriver("com.abtcorp.io.methrepo.ABTMMRepoDriver", null);
       
         openRepo(driver_, space_);
		 System.out.println("Populating an object space.");
         os = populateMethod(space_);


         closeRepo(driver_, space_);
         closeRepo(siteDriver_, space_);
         
        // Get the project out of the set
	    if (os instanceof IABTObjectSet)
        {
            IABTObjectSet  projectSet = (IABTObjectSet)os;
            os = projectSet.at(0);
         }
       
        showMethod((IABTObject)os);

	    System.out.println("\nPopulating from the repository has ended.");

        System.out.println("\nTestMethFileApp save local file.");
        lcldriver_ = space_.newABTDriver("com.abtcorp.io.client.methfile.ABTIOMethFileDriver", null);

        IABTHashTable argss = space_.newABTHashTable();	
	    argss.putItemByString(KEY_DESTINATIONNAME,new ABTString("Marjanm.lcl"));
	    argss.putItemByString(KEY_TYPE ,new ABTString("Method"));

/*
	    // Get the project out of the set
	    if (os instanceof IABTObjectSet)
        {
            IABTObjectSet  projectSet = (IABTObjectSet)os;
            os = projectSet.at(0);
         }
*/
	    argss.putItemByString(KEY_SOURCE ,os);

        lcldriver_.save(argss);


        ABTObjectSpaceLocal   space2  = new ABTObjectSpaceLocal();
        space2.startSession(null);
        
       lcldriver_ = space_.newABTDriver("com.abtcorp.io.client.methfile.ABTIOMethFileDriver", null);
        populateSite(space2);
        IABTHashTable argpp = space2.newABTHashTable();
	
	    argpp.putItemByString(KEY_SOURCENAME,new ABTString("Marjanm.lcl"));
	    argpp.putItemByString(KEY_TYPE ,new ABTString("Method"));
	    System.out.println("\nTestPMWFileApp populate from local file.");
        ABTValue os2 = lcldriver_.populate(argpp);
        

        IABTHashTable argss2 = space2.newABTHashTable();
        //CHECK THIS IT MIGHT NEED TO BE SPACE2
	 
	    argss2.putItemByString(KEY_DESTINATIONNAME,new ABTString("Marjan2.lcl"));
	    argss2.putItemByString(KEY_TYPE ,new ABTString("Method"));
	    argss2.putItemByString(KEY_SOURCE ,os2);
        System.out.println("\nTestPMWFileApp save  from local file 2nd time.");
        lcldriver_.save(argss2);
 

         System.out.println("TestPMWFileApp ended.");
      }
      catch (ABTException e)
      {
         e.printStackTrace();
      }


   }


   private void populateSite(ABTObjectSpaceLocal space) throws ABTException
   {
      IABTHashTable args = space.newABTHashTable();
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));

      siteDriver_ = space.newABTDriver("com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
      
      openRepo(siteDriver_, space);
      
      ABTValue val = siteDriver_.populate(args);

      if (ABTError.isError( val ) )
         throw new ABTException((ABTError) val);
      if (val instanceof IABTObject )
      {
         site_ = (IABTObject) val;
      }
      else
         throw new ABTException("Site populate() failed and did not return a site object!");
   }



   private void openRepo(IABTDriver driver, ABTObjectSpaceLocal space) throws ABTException
   {
      IABTHashTable args = space.newABTHashTable();
      args.putItemByString(KEY_USERNAME, new ABTString("admin"));
      //args.putItemByString(KEY_PASSWORD, new ABTString("administrator"));

      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_PRODUCT, new ABTString(productName_));
		if (driver.open(args) != (ABTValue)null )
		    throw new ABTException("Driver failed to open!");
   }


   private void closeRepo(IABTDriver driver, ABTObjectSpaceLocal space)
   {
      if (driver != null)
         driver.close(null);
   }


   private ABTValue populateMethod(ABTObjectSpaceLocal space)
   {
     ABTValue ret = (ABTValue) null;
      System.out.println("Populating Method '" + projectExternalID_ + "'");
      try
      {
         IABTHashTable args = space.newABTHashTable();
			// Ask the Repository driver to populate the object space with a
			// project and its tasks.  The driver's populate() method will return
			// an ABTValue objectset containing ABTProject objects and associated
			// ABTTask objects.

		   args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
		   args.putItemByString(KEY_EXTID, new ABTString(projectExternalID_));
		   args.putItemByString(KEY_LOCK,  new ABTBoolean(true));
		   ABTValue os = driver_.populate(args);
         if (os instanceof IABTObjectSet)
         {
            oSet_ = (IABTObjectSet) os;
            System.out.println("This project object set contains " + oSet_.size() + " objects.");
            System.out.println("Scanning project objects in object set...");
            ret = (ABTValue) oSet_;
         }                       // end if (os instanceof ABTObjectSet)
         else if (os instanceof ABTError)
         {
            ABTError err = (ABTError) os;
            System.out.println("Populate Error: Component: " + err.getComponent());
            System.out.println("Populate Error: Method: "    + err.getMethod());
            System.out.println("Populate Error: Message: "   + err.getMessage());
            Object info = err.getInfo();
            if (info != null)
            {
               if (info instanceof String)
                  System.out.println("Populate Error: Info: " + info);
               else if (info instanceof ABTError)
               {
                  System.out.println("Populate Error: Info Component: " + err.getComponent());
                  System.out.println("Populate Error: Info Method: "    + err.getMethod());
                  System.out.println("Populate Error: Info Message: "   + err.getMessage());
               }

            }
         }
      }
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
        return ret;
      }
   }
  
   
   private ABTError showMethod(IABTObject method)
   {
      ABTError err = null;
      
      System.out.println("\nDisplaying method...");

      err = show(method, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;

      ABTValue task = method.getValue(OFD_FIRSTCHILDTASK);
      if (task instanceof IABTObject)
      {
         ABTValue name = ((IABTObject) task).getValue(OFD_NAME);
         System.out.println("The first child task is " + name.toString());
      }

      task = method.getValue(OFD_LASTCHILDTASK);
      if (task instanceof IABTObject)
      {
         ABTValue name = ((IABTObject) task).getValue(OFD_NAME);
         System.out.println("The last child task for this method is " + name.toString());
      }

      //err = displayTaskHierarchy(method);
      //if (err != null)    return err;
  /*
      err = showList(method, OFD_ALLASSIGNMENTS, null, OFD_TASK, OFD_NAME, OFD_RESOURCE, OFD_NAME);
      if (err != null)    return err;
      
      err = showList(method, OFD_ALLTASKESTIMATES, null, OFD_TASK, OFD_NAME, OFD_ESTMODEL, OFD_NAME);
      if (err != null)    return err;
      
      err = showList(method, OFD_ALLPAGEMEMBERS, null, OFD_PAGE, OFD_NAME, OFD_CUSTOMFIELD, OFD_NAME);
      if (err != null)    return err;
      
      
      err = moveTasks(method);
      if (err != null)    return err;
      

      // create some tasks for this method
   	err = createNewTasks(method);
      if (err != null)    return err;
     */ 
      err = showTasks(method, OFD_ALLTASKS);
      if (err != null)    return err;
/*
      err = showDeliverables(method, OFD_ALLDELIVERABLES);
      if (err != null)    return err;      

      err = showPages(method, OFD_ALLPAGES);
      if (err != null)    return err;
            
      //err = showPages(method, OFD_ALLPAGES);
      //if (err != null)    return err;
      
      err = show(method, OFD_ALLPAGEMEMBERS, OFD_ID, OFD_PAGEID, OFD_SEQUENCE);
      if (err != null)    return err;

      err = show(method, OFD_ALLPACKAGES, OFD_ID, OFD_NAME, OFD_METHODID);
      if (err != null)    return err;

      err = show(method, OFD_PACKAGES, OFD_ID, OFD_NAME, OFD_RECCONDITION);
      if (err != null)    return err;

      err = show(method, OFD_RECRULES, OFD_ID, OFD_NAME, OFD_RECCONDITION);
      if (err != null)    return err;

      err = show(method, OFD_ALLASSIGNMENTS, OFD_ID, OFD_TASKID, OFD_RESOURCEID);
      if (err != null)    return err;
      
      err = show(method, OFD_ALLDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
      if (err != null)    return err;
      
      err = show(method, OFD_ALLTASKESTIMATES, OFD_ID, OFD_FORMULA, OFD_TASKID);
      if (err != null)    return err;
      
      err = show(method, OFD_ALLPACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_PACKAGEID);
      if (err != null)    return err;
          
  */
      System.out.println(" ");
      return null;
   }


   
   private ABTError showList(IABTObject parent, String list, String nameField, String refField1, String nameField1, String refField2, String nameField2)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + list + "...");
      
      IABTObjectSet oset = (IABTObjectSet) parent.getValue(list);
      if (oset instanceof  IABTObjectSet)
         System.out.println("The total number of objects in set = " +(( IABTObjectSet) oset).size());
      else
         return new ABTError("Test", "showList()", "Invalid Data", list + " is not an obect set.");

      // iterate thru the object set
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, nameField, null);
         if (err != null)    return err;

         ABTValue val = obj.getValue(refField1);
         if (ABTError.isError(val))  
            return (ABTError) val;         
         else if (val instanceof IABTObject)
         {
            err = show((IABTObject)val, OFD_ID, nameField1, null);
            if (err != null)    return err;
         }
         
         val = obj.getValue(refField2);
         if (ABTError.isError(val))  
            return (ABTError) val;         
         else if (val instanceof IABTObject)
         {
            err = show((IABTObject)val, OFD_ID, nameField2, null);
            if (err != null)    return err;
         }
         
         System.out.println(" ");
      }
      
      return null;
   }

   //=======================================================================
   // Retrieve an object or an object set specified by "field" from the "parent" object
   // and print out the values in "field".
   //=======================================================================
   private ABTError show(IABTObject parent, String field, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTError err = null;

      val1 = parent.getValue(field);

      if (ABTValue.isNull(val1))
         System.out.println("\n" + field + ":  null or empty ");

      else if (val1 instanceof  IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) val1;
         
         System.out.println("\n" + field + ":  total number of objects in set = " + oset.size());
         
         if (oset.size() > 0)
         {
            for (int j = 0; j < oset.size(); j++)
            {
               IABTObject object = (IABTObject) oset.at( j);
               err = show (object, field1, field2, field3);
               if (err != null)
                  return err;
            }
         }
      }
      else if (val1 instanceof  IABTObject)
      {
         IABTObject object = (IABTObject) val1;
         System.out.println("\n" + field + ": ");         
         err = show (object, field1, field2, field3);
         if (err != null)
            return err;
      }
      else
         System.out.println( "\n" + field + " is not an object set or an object.");
         
      return null;
   }

   //=======================================================================
   // print out the property values of the input object
   //=======================================================================
   private ABTError show(IABTObject object, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTValue val3 = null;

      if (object == null)
         return new ABTError ("Test", "show()", "Invalid Data", "The input object is null");
      
      String type = pad (object.getObjectType() + ":", 22);
       ABTValue val = object.getValue("ABTRemoteID");
      if (ABTError.isError(val))
         return (ABTError)val;
      //if (val instanceof ABTRemoteIDRepository)
      //   System.out.print( type + " RepoID = " + ((ABTRemoteIDRepository)val).getRepositoryID() + ",  ");
      //else
      //   System.out.println(type + " RemoteID = null or empty ");
         
     if (field1 != null)
      {
         val1 = object.getValue(field1);
         if (ABTError.isError(val1))
            return (ABTError)val1;
         if (ABTValue.isNull(val1))
            System.out.println(field1 + ":  null or empty ");
         else
            System.out.print(field1 + " = " + val1.toString() + ",  ");
      }
         
      if (field2 != null)
      {
         val2 = object.getValue(field2);
         if (ABTError.isError(val2))
            return (ABTError)val2;
         if (ABTValue.isNull(val2))
            System.out.println(field2 + ":  null or empty ");
         else
            System.out.print(field2 + " = " + val2.toString() + ", ");
      }
      
      if (field3 != null)
      {
         val3 = object.getValue(field3);
         if (ABTError.isError(val3))
            return (ABTError)val3;
         if (ABTValue.isNull(val3))
            System.out.println(field3 + ":  null or empty ");
         else
            System.out.print(field3 + " = " + val3.toString());
      }
      
      System.out.println(" ");
      
      return null;
   }
   
   private String pad(String str, int maxlen)
   {
      String newStr = str;
      
      str.trim();
      for (int i=str.length(); i<maxlen; i++)
         newStr = newStr.concat(" ");
         
      return newStr;
   }
   
   
   //=======================================================================
   // print out the deliverable properties and the associated tasks
   //=======================================================================
   private ABTError showDeliverables(IABTObject parent, String field)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + field + "...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(field);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of deliverables is 0.");
            return null;
         }
         else
            System.out.println("The total number of deliverables in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showDeliverables()", "Invalid Data", field + " is not an obect set.");

      // getting delivs and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;

         err = show(obj, OFD_TASKS, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;

/*
         // test delete
         System.out.println("Removing task deliverable links... ");
        	ABTValue val = obj.getValue(OFD_TASKS);
      	if (ABTError.isError(val))            	   return (ABTError)val;
      	IABTObjectSet tasks = (IABTObjectSet)val;
         for (int k = 0; k < tasks.size(); k++)
         {
            IABTObject task = (IABTObject) tasks.at(k);
            val = tasks.remove(task);
         	if (ABTError.isError(val))            	   return (ABTError)val;
         }
         
         System.out.println("After task deliverable links removed... ");
         err = show(obj, OFD_TASKS, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;
         //err = show(obj, OFD_PACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_RECORDID);
         //if (err != null)    return err;
*/
         System.out.println(" ");
      }
      
      return null;
   }

   //=======================================================================
   // print out the task properties and the associated objects/object sets
   //=======================================================================
   private ABTError showTasks(IABTObject parent, String field)
   {
      ABTError err = null;
    
      System.out.println("\nScanning " + field + "...");
      
      IABTObjectSet taskoset = ( IABTObjectSet) parent.getValue(field);
      if (taskoset instanceof  IABTObjectSet)
      {
         if (taskoset.size() == 0)
         {
            System.out.println("The total number of tasks is 0.");
            return null;
         }
         else
            System.out.println("The total number of tasks in set = " +(( IABTObjectSet) taskoset).size());
      }
      else
         return new ABTError("Test", "showTasks()", "Invalid Data", field + " is not an obect set.");

      // getting tasks and their contents
      for (int j = 0; j < taskoset.size(); j++)
      {
         IABTObject task = (IABTObject) taskoset.at(j);
         
         err = show(task, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;


/*
         // test delete
         System.out.println("Removing task deliverable links... ");
        	ABTValue val = task.getValue(OFD_DELIVERABLES);
      	if (ABTError.isError(val))            	   return (ABTError)val;
      	IABTObjectSet delivs = (IABTObjectSet)val;
      	int m = delivs.size();
         for (int k = 0; k < m; k++)
         {
            val = delivs.removeAt(0);
         	if (ABTError.isError(val))            	   return (ABTError)val;
         }
         
         System.out.println("After task deliverable links removed... ");
         err = show(task, OFD_DELIVERABLES, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;
         
*/         

/*
         err = show(task, OFD_PARENTTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_FIRSTCHILDTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_LASTCHILDTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_PREVIOUSTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

         err = show(task, OFD_NEXTTASK, OFD_ID, OFD_EXTERNALID, OFD_ISTASK);
         if (err != null)    return err;

*/
         err = show(task, OFD_DELIVERABLES, OFD_ID, OFD_EXTERNALID, null);
         if (err != null)    return err;
/*
         err = show(task, OFD_PREDDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
         if (err != null)    return err;

         err = show(task, OFD_SUCCDEPENDENCIES, OFD_ID, OFD_PREDTASKID, OFD_SUCCTASKID);
         if (err != null)    return err;

         err = show(task, OFD_TASKESTIMATES, OFD_ID, OFD_TASKID, OFD_ESTMODELID);
         if (err != null)    return err;

         err = show(task, OFD_ASSIGNMENTS, OFD_ID, OFD_TASKID, OFD_RESOURCEID);
         if (err != null)    return err;

         err = show(task, OFD_PACKAGEMEMBERS, OFD_ID, OFD_TABLENAME, OFD_RECORDID);
         if (err != null)    return err;
*/
         System.out.println(" ");         
         
         /*
         // temp code to test delete
         ABTInteger id = (ABTInteger) task.getValue(OFD_ID);
         if (id.intValue() == 3)
            task.delete();
         */
      }
      
      return null;
   }
  
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   

   public static void main(String args[])
   {
	  TestMethFileApp app =	new TestMethFileApp(args);
	  app.run();
	  System.out.println( "\n End of Main");
   }

}