package test.io.methrepo;

import com.abtcorp.io.*;
import com.abtcorp.io.methrepo.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;

import com.abtcorp.repository.ABTNames;

import com.abtcorp.objectModel.mm.*;

import com.objectspace.jgl.ArrayIterator;

public class TestMethodRepoApp implements ABTNames, IABTIOMethRepoConstants, IABTMMRuleConstants
{
   private String repositoryName_;
   private String methodExternalIDs_[] = new String[2];
   private ABTUserSession userSession_;
   private ABTIOMethRepoDriver driver_ = null;

   public TestMethodRepoApp(String[] args)
   {
      repositoryName_ = "ABTRepository";
      methodExternalIDs_[0] = "Method_A";
      methodExternalIDs_[1] = "Method_B";
   }

   public void run()
   {
      ABTObject siteObject = null;
      ABTObjectSet oset = null;
      
      try
      {
         System.out.println("TestMethodRepoApp starting...");
         ABTObjectSpace space = new ABTObjectSpace();
         driver_ = new ABTIOMethRepoDriver();
         driver_.setSpace(space);
         driver_.setProduct("Methods Architect");
         userSession_ = space.startSession(null);
         driver_.setUserSession(userSession_);

		if (!driver_.open()) throw new ABTException("Driver failed to open!");

         // first populate the site object
			ABTValue site = driver_.populateSite(repositoryName_);
         if (site instanceof ABTObjectSet)
         {
            oset = (ABTObjectSet) site;
            siteObject = (ABTObject) oset.at(userSession_, 0); // there should be only 1 site obj
            System.out.println("The repository contains the following site data:  ");
            showSite(siteObject);    
         }

			// Ask the Repository driver to populate the object space with all the
			// methods found in the repository.  The driver's populate() method will return
			// an ABTValue objectset containing the method objects and all associated
			// objects.

         String[] methodList = driver_.getMethodExtIDList(repositoryName_);
         
         System.out.println("The repository contains these methods:  ");
         for (int i = 0; i < methodList.length; i++)
         {
            System.out.println(methodList[i] + "  ");
         }
         
         System.out.println("Populating methods with lock...");
			ABTValue os = driver_.populateMethods(repositoryName_, methodList, true);
         if (os instanceof ABTObjectSet)
         {
            oset = (ABTObjectSet) os;
            System.out.println("This method object set contains " + oset.size(userSession_) + " objects.");
            System.out.println("Scanning method objects in object set...");
            for (int i = 0; i < oset.size(userSession_); i++)
            {
               ABTObject object = (ABTObject) oset.at(userSession_, i);
               
               ABTObject method = object;  // save this method
               
               ABTValue id = method.getValue(userSession_, OFD_MM_ID);
               ABTValue name = method.getValue(userSession_, OFD_MM_NAME);
               System.out.println("\n METHOD ID = " + id.toString() +
                                  ", NAME = " + name.toString() );

               ABTValue dependencies = method.getValue(userSession_, OFD_MM_ALLDEPENDENCIES);
               if (dependencies instanceof ABTObjectSet)
                  System.out.println("The total number of dependencies for this method is " +((ABTObjectSet) dependencies).size(userSession_));
               
               ABTValue task = object.getValue(userSession_, OFD_MM_LASTCHILDTASK);
               if (task instanceof ABTObject)
               {
                  name = ((ABTObject) task).getValue(userSession_, OFD_MM_NAME);
                  System.out.println("The last child task for this method is " + name.toString());
               }

               /*
               ABTValue childtasks = method.getValue(userSession_, OFD_MM_CHILDTASKS);
               if (childtasks instanceof ABTObjectSet)
                  System.out.println("The total number of child tasks for this method is " +((ABTObjectSet) childtasks).size(userSession_));
               */
                  
               ABTValue defEstmodel = method.getValue(userSession_, OFD_MM_DEFESTMODEL);
               if (defEstmodel instanceof ABTObject)
               {
                  System.out.println("The default estimate model for this method is ");
                  System.out.println(((ABTObject)defEstmodel).getValue(userSession_, OFD_MM_NAME).toString());
               }
                  
               showTasks(method);
               showPages(method);
               showPackages(method);

               // update the fields in the method object (to test save)
               method.setValue(userSession_, OFD_MM_GUIDELINES, new ABTString("Test"+i));

            }
         }

         System.out.println("Saving methods back to repository and unlocking ...");
         driver_.saveMethods(repositoryName_, oset, true); 
         System.out.println("End saving methods.");

      } catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
         try {
            driver_.close();
         } catch (Exception e) {
            e.printStackTrace();
         }
			System.out.println("TestMethodRepoApp ended.");
      }
   }
   
   private void showTasks(ABTObject method)
   {
      ABTObjectSet taskoset = (ABTObjectSet) method.getValue(userSession_, OFD_MM_ALLTASKS);
      if (taskoset instanceof ABTObjectSet)
         System.out.println("\nThe total number of tasks for this method is " +((ABTObjectSet) taskoset).size(userSession_));
         
      // getting tasks and their contents
      System.out.println("Scanning task objects for this method...");
      if (taskoset.size(userSession_) > 0)
      {
         for (int j = 0; j < taskoset.size(userSession_); j++)
         {
            ABTObject object = (ABTObject) taskoset.at(userSession_, j);
            ABTValue id = object.getValue(userSession_, OFD_MM_ID);
            ABTValue name = object.getValue(userSession_, OFD_MM_NAME);
            System.out.println("\n  TASK ID = " + id.toString() +
                               ", NAME = " + name.toString() );

            ABTValue task = object.getValue(userSession_, OFD_MM_PARENTTASK);
            if (task instanceof ABTObject)
            {
               name = ((ABTObject) task).getValue(userSession_, OFD_MM_NAME);
               System.out.println("The parent task is " + name.toString());
            }

            task = object.getValue(userSession_, OFD_MM_LASTCHILDTASK);
            if (task instanceof ABTObject)
            {
               name = ((ABTObject) task).getValue(userSession_, OFD_MM_NAME);
               System.out.println("The last child task is " + name.toString());
            }

            /*
            ABTValue childTasks = object.getValue(userSession_, OFD_MM_CHILDTASKS);
            if (childTasks instanceof ABTObjectSet)
               System.out.println("The number of child tasks is " + ((ABTObjectSet) childTasks).size(userSession_));
            */

            ABTValue predDependencies = object.getValue(userSession_, OFD_MM_PREDDEPENDENCIES);
            if (predDependencies instanceof ABTObjectSet)
               System.out.println("The number of predecessor dependencies is " +((ABTObjectSet) predDependencies).size(userSession_));

            ABTValue succDependencies = object.getValue(userSession_, OFD_MM_SUCCDEPENDENCIES);
            if (succDependencies instanceof ABTObjectSet)
               System.out.println("The number of successor dependencies is " +((ABTObjectSet) succDependencies).size(userSession_));

            ABTValue deliverables = object.getValue(userSession_, OFD_MM_DELIVERABLES);
            if (deliverables instanceof ABTObjectSet)
               System.out.println("The number of deliverables for this task is " +((ABTObjectSet) deliverables).size(userSession_));

            ABTValue taskestimates = object.getValue(userSession_, OFD_MM_TASKESTIMATES);
            if (taskestimates instanceof ABTObjectSet)
            {
               System.out.println("The number of taskestimates for this task is " +((ABTObjectSet) taskestimates).size(userSession_));
               showTaskEstimates(object);
            }  

            ABTValue assignments = object.getValue(userSession_, OFD_MM_ASSIGNMENTS);
            if (assignments instanceof ABTObjectSet)
            {
               System.out.println("The number of assignments for this task is " +((ABTObjectSet) assignments).size(userSession_));
               showAssignments(object);
            }

            // change some values to test save()
            object.setValue(userSession_, OFD_MM_SHORTNAME, new ABTString("Test"+j*2));
         }
      }
      
      // create some new tasks to test save()
      ABTValue val = driver_.getSpace().createObject(userSession_, OBJ_MM_TASK, null, null);
      if (val instanceof ABTObject)
      {
      	ABTObject newTask = (ABTObject) val;
         newTask.setValue(userSession_, OFD_MM_EXTERNALID, new ABTString("New task ext id"));
         newTask.setValue(userSession_, OFD_MM_NAME, new ABTString("New task name"));
         newTask.setValue(userSession_, OFD_MM_METHOD, method);
         taskoset.add(userSession_, newTask);
	      method.setValue(userSession_, OFD_MM_ALLTASKS, taskoset);
	   }
         
   }


   private void showAssignments(ABTObject task)
   {
      ABTObject object = null;
      ABTValue id, name;
      
      ABTValue ass = task.getValue(userSession_, OFD_MM_ASSIGNMENTS);
      if (ass instanceof ABTObjectSet)
      {
         ABTObjectSet assoset = (ABTObjectSet) ass;
            
         if (assoset.size(userSession_) > 0)
         {
            System.out.println("Scanning assignment objects for this task...");
            for (int j = 0; j < assoset.size(userSession_); j++)
            {
               ABTObject assobj = (ABTObject) assoset.at(userSession_, j);
               id = assobj.getValue(userSession_, OFD_MM_ID);
               name = assobj.getValue(userSession_, OFD_MM_NAME);
               System.out.println("  ASSIGNMENT ID = " + id.toString());

               ABTValue res = assobj.getValue(userSession_, OFD_MM_RESOURCE);
               if (res instanceof ABTObject)
               {
                  System.out.println("The resource assigned to this assignment is ");
                  object = (ABTObject) res;
                  id = object.getValue(userSession_, OFD_MM_ID);
                  name = object.getValue(userSession_, OFD_MM_NAME);
                  System.out.println("  ASSIGNMENT RESOURCE ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
               }
               else
                  System.out.println("Resource not found.");
                  
               ABTValue reftask = assobj.getValue(userSession_, OFD_MM_TASK);
               if (reftask instanceof ABTObject)
               {
                  System.out.println("The reference task for this assignment is ");
                  object = (ABTObject) reftask;
                  id = object.getValue(userSession_, OFD_MM_ID);
                  name = object.getValue(userSession_, OFD_MM_NAME);
                  System.out.println("  ASSIGNMENT TASK ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
               }
               else
                  System.out.println("Task not found.");
            }
         }
      }
      else
         System.out.println("There are no assignments for this task.");
   }
   

   private void showTaskEstimates(ABTObject task)
   {
      ABTObject object = null;
      ABTValue id, name;
      
      ABTValue val = task.getValue(userSession_, OFD_MM_TASKESTIMATES);
      if (val instanceof ABTObjectSet)
      {
         ABTObjectSet oset = (ABTObjectSet) val;
            
         if (oset.size(userSession_) > 0)
         {
            System.out.println("Scanning task estimate objects for this task...");
            for (int j = 0; j < oset.size(userSession_); j++)
            {
               ABTObject obj = (ABTObject) oset.at(userSession_, j);
               id = obj.getValue(userSession_, OFD_MM_ID);
               System.out.println("  TASK ESTIMATE ID = " + id.toString());

               val = obj.getValue(userSession_, OFD_MM_ESTMODEL);
               if (val instanceof ABTObject)
               {
                  System.out.println("The est model for this task estimate is ");
                  object = (ABTObject) val;
                  id = object.getValue(userSession_, OFD_MM_ID);
                  name = object.getValue(userSession_, OFD_MM_NAME);
                  System.out.println("  TASK ESTIMATE MODEL ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
               }
               else
                  System.out.println("Est model not found.");
                  
               ABTValue reftask = obj.getValue(userSession_, OFD_MM_TASK);
               if (reftask instanceof ABTObject)
               {
                  System.out.println("The reference task for this task estimate is ");
                  object = (ABTObject) reftask;
                  id = object.getValue(userSession_, OFD_MM_ID);
                  name = object.getValue(userSession_, OFD_MM_NAME);
                  System.out.println("  TASK ESTIMATE TASK ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
               }
               else
                  System.out.println("Task not found.");
            }
         }
      }
      else
         System.out.println("There are no task estimates for this task.");
   }
   


   private void showPageMembers(ABTObject page)
   {
      ABTObject object = null;
      ABTValue id, name;
      
      ABTValue val = page.getValue(userSession_, OFD_MM_PAGEMEMBERS);
      if (val instanceof ABTObjectSet)
      {
         ABTObjectSet oset = (ABTObjectSet) val;
            
         if (oset.size(userSession_) > 0)
         {
            System.out.println("Scanning page member objects for this page...");
            for (int j = 0; j < oset.size(userSession_); j++)
            {
               ABTObject obj = (ABTObject) oset.at(userSession_, j);
               id = obj.getValue(userSession_, OFD_MM_ID);
               System.out.println("  PAGE MEMBER ID = " + id.toString());

               val = obj.getValue(userSession_, OFD_MM_CUSTOMFIELD);
               if (val instanceof ABTObject)
               {
                  System.out.println("The custom field associated with this page member is ");
                  object = (ABTObject) val;
                  id = object.getValue(userSession_, OFD_MM_ID);
                  name = object.getValue(userSession_, OFD_MM_NAME);
                  System.out.println("  PAGE MEMBER CUSTOM FIELD ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
               }
               else
                  System.out.println("Custom field not found.");
                  
               ABTValue ref = obj.getValue(userSession_, OFD_MM_PAGE);
               if (ref instanceof ABTObject)
               {
                  System.out.println("The reference page for this page member is ");
                  object = (ABTObject) ref;
                  id = object.getValue(userSession_, OFD_MM_ID);
                  name = object.getValue(userSession_, OFD_MM_NAME);
                  System.out.println("  PAGE MEMBER PAGE ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
               }
               else
                  System.out.println("Page not found.");
            }
         }
      }
      else
         System.out.println("There are no page members for this task.");
   }
   

   private void showPages(ABTObject method)
   {
      // getting pages and page members
      ABTValue pages = method.getValue(userSession_, OFD_MM_PAGES);
      if (pages instanceof ABTObjectSet)
      {
         System.out.println("\nThe total number of pages for this method is " +((ABTObjectSet) pages).size(userSession_));
         ABTObjectSet pageoset = (ABTObjectSet) pages;
            
         if (pageoset.size(userSession_) > 0)
         {
            System.out.println("Scanning page objects for this method...");
            for (int j = 0; j < pageoset.size(userSession_); j++)
            {
               ABTObject object = (ABTObject) pageoset.at(userSession_, j);
               ABTValue id = object.getValue(userSession_, OFD_MM_ID);
               ABTValue name = object.getValue(userSession_, OFD_MM_NAME);
               System.out.println("  PAGE ID = " + id.toString() +
                                  ", NAME = " + name.toString() );

               ABTValue pagemembers = object.getValue(userSession_, OFD_MM_PAGEMEMBERS);
               if (pagemembers instanceof ABTObjectSet)
               {
                  System.out.println("The number of members for this page is " +((ABTObjectSet) pagemembers).size(userSession_));
                  showPageMembers(object);
               }
            }
         }
      }
      else
         System.out.println("There are no pages for this method.");
   }
   
   private void showPackages(ABTObject method)
   {
      // getting packages and package members
      ABTValue packages = method.getValue(userSession_, OFD_MM_PACKAGES);
      if (packages instanceof ABTObjectSet)
      {
         System.out.println("\nThe total number of packages for this method is " +((ABTObjectSet) packages).size(userSession_));
         ABTObjectSet packageoset = (ABTObjectSet) packages;
            
         if (packageoset.size(userSession_) > 0)
         {
            System.out.println("Scanning package objects for this method...");
            for (int j = 0; j < packageoset.size(userSession_); j++)
            {
               ABTObject object = (ABTObject) packageoset.at(userSession_, j);
               ABTValue id = object.getValue(userSession_, OFD_MM_ID);
               ABTValue name = object.getValue(userSession_, OFD_MM_NAME);
               System.out.println("  PACKAGE ID = " + id.toString() +
                                  ", NAME = " + name.toString() );

               ABTValue packagemembers = object.getValue(userSession_, OFD_MM_PACKAGEMEMBERS);
               if (packagemembers instanceof ABTObjectSet)
               {
                  System.out.println("The number of members for this package is " +((ABTObjectSet) packagemembers).size(userSession_));
                  ABTObjectSet pmoset = (ABTObjectSet) packagemembers;
                     
                  if (pmoset.size(userSession_) > 0)
                  {
                     for (int k = 0; k < pmoset.size(userSession_); k++)
                     {
                        object = (ABTObject) pmoset.at(userSession_, k);
                        id = object.getValue(userSession_, OFD_MM_ID);
                        name = object.getValue(userSession_, OFD_MM_TABLENAME);
                        System.out.println("  PACKAGE MEMBER ID = " + id.toString() +
                                           ", TABLE NAME = " + name.toString() );

                        ABTValue ref = object.getValue(userSession_, OFD_MM_TASK);
                        if (ref instanceof ABTObject)
                        {
                           ABTObject refObj = (ABTObject) ref;
                           id = refObj.getValue(userSession_, OFD_MM_ID);
                           name = refObj.getValue(userSession_, OFD_MM_NAME);
                           System.out.println("  REFERENCED TASK ID = " + id.toString() +
                                           ", TASK NAME = " + name.toString() );
                        }

                        ref = object.getValue(userSession_, OFD_MM_DELIVERABLE);
                        if (ref instanceof ABTObject)
                        {
                           ABTObject refObj = (ABTObject) ref;
                           id = refObj.getValue(userSession_, OFD_MM_ID);
                           name = refObj.getValue(userSession_, OFD_MM_NAME);
                           System.out.println("  REFERENCED DELIVERABLE ID = " + id.toString() +
                                           ", DELIVERABLE NAME = " + name.toString() );
                        }
                     }
                  }
               }
               else
                  System.out.println("There are no package members for this package.");
            }
         }
      }
      else
         System.out.println("There are no packages for this method.");
   }
   
   private void showSite(ABTObject site)
   {
      ABTObjectSet oset = null;
      ABTObject object = null;
      ABTValue id, name;
      
      // getting resources
      ABTValue val = site.getValue(userSession_, OFD_MM_ALLRESOURCES);
      if (val instanceof ABTObjectSet)
      {
         oset = (ABTObjectSet) val;
         System.out.println("The total number of resources for this site is " + oset.size(userSession_));
            
         if (oset.size(userSession_) > 0)
         {
            System.out.println("Scanning resource objects...");
            for (int j = 0; j < oset.size(userSession_); j++)
            {
               object = (ABTObject) oset.at(userSession_, j);
               id = object.getValue(userSession_, OFD_MM_ID);
               name = object.getValue(userSession_, OFD_MM_NAME);
               System.out.println("  RESOURCE ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
            }
         }
      }
      else
         System.out.println("There are no resources for this site.");

      // getting est models
      val = site.getValue(userSession_, OFD_MM_ALLESTMODELS);
      if (val instanceof ABTObjectSet)
      {
         oset = (ABTObjectSet) val;
         System.out.println("The total number of est models for this site is " + oset.size(userSession_));
            
         if (oset.size(userSession_) > 0)
         {
            System.out.println("Scanning est model objects...");
            for (int j = 0; j < oset.size(userSession_); j++)
            {
               object = (ABTObject) oset.at(userSession_, j);
               id = object.getValue(userSession_, OFD_MM_ID);
               name = object.getValue(userSession_, OFD_MM_NAME);
               System.out.println("  EST MODEL ID = " + id.toString() +
                                  ", NAME = " + name.toString() );
            }
         }
      }
      else
         System.out.println("There are no resources for this site.");

      // getting custom fields
      val = site.getValue(userSession_, OFD_MM_ALLCUSTOMFIELDS);
      if (val instanceof ABTObjectSet)
      {
         oset = (ABTObjectSet) val;
         System.out.println("The total number of custom fields for this site is " + oset.size(userSession_));
            
         if (oset.size(userSession_) > 0)
         {
            System.out.println("Scanning custom field objects...");
            for (int j = 0; j < oset.size(userSession_); j++)
            {
               object = (ABTObject) oset.at(userSession_, j);
               id = object.getValue(userSession_, OFD_MM_ID);
               name = object.getValue(userSession_, OFD_MM_NAME);
               System.out.println("  CUSTOM FIELD ID = " + id.toString() +
                                  ", NAME = " + name.toString() );

               ABTValue af = object.getValue(userSession_, OFD_MM_AGGREGATEFIELDS);
               if (af instanceof ABTObjectSet)
                  System.out.println("The number of aggregate fields for this custom field is " +((ABTObjectSet) af).size(userSession_));
            }
         }
      }
      else
         System.out.println("There are no custom fields for this site.");
     
   }
   
   
   public static void main(String args[])
   {
      TestMethodRepoApp app = new TestMethodRepoApp(args);
      app.run();
   }
      
}