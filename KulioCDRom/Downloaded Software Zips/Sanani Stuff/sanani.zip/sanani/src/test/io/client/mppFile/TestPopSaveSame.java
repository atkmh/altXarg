package test.io.client.mppfile;

import com.abtcorp.io.ABTDriver;
import com.abtcorp.io.client.*;
import com.abtcorp.io.client.mppfile.*;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTDriver;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.api.local.ABTObjectSpaceLocal;
import com.abtcorp.api.local.ABTDriverLocal;
import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTHashtable;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTDouble;


public class TestPopSaveSame implements IABTPMRuleConstants, IABTDriverConstants
{
	public TestPopSaveSame() {}

	public void run()
	{
		try
		{

			System.out.println("TestMppFileApp starting...");

			IABTObjectSpace space = new ABTObjectSpaceLocal();
         space.startSession( null );

         ABTHashTable args = new ABTHashTable();
         IABTDriver siteDriver = new ABTDriverLocal();
         siteDriver.initialize(space,"com.abtcorp.io.siterepo.ABTSiteRepoDriver",null);

         args.putItemByString ("UserName", new ABTString("admin"));
         //args.putItemByString ("Password", new ABTString("administrator"));
         args.putItemByString ("Password", new ABTString(""));
         args.putItemByString ("Product", new ABTString("Project Workbench"));
         siteDriver.open (space, args);

         args.clear();
         args.putItemByString ("Type", new ABTString("All"));
         args.putItemByString ("RepositoryName", new ABTString("ABTRepository"));
         args.putItemByString ("Product", new ABTString("ABT Workbench"));
         ABTValue siteAbtValue  = siteDriver.populate (space, args);
         siteDriver.close(space,null);

         IABTDriver driver = new ABTDriverLocal();
         driver.initialize(space, "com.abtcorp.io.client.mppfile.ABTClientMppDriver", null );
			driver.open( space, null );

         args = new ABTHashTable();

         args.putItemByString( KEY_SOURCENAME, new ABTString("d:\\projects\\project1.mpp"));

			ABTValue obj = driver.populate( space, args );
            if (ABTError.isError(obj)) throw new ABTException(((ABTError)obj).getMessage());

            IABTObject proj = (IABTObject) obj;
			IABTObject object;

			// The driver's populate() method will return an ABTValue
			// object containing an ABTProject object and associated
			// ABTTask objects.

			if ( proj instanceof IABTObject )
			{
                ABTValue val;
				ABTValue prID = proj.getValue( OFD_ID );
				ABTValue prName = proj.getValue( OFD_NAME );
                ABTValue prFileName = proj.getValue( OFD_FILENAME );
                ABTValue prStart = proj.getValue( OFD_START );
                ABTValue prFinish = proj.getValue( OFD_FINISH );
				System.out.println("ID = " + prID.toString() + ", NAME = " + prName.toString() +
                                    "From file = " + prFileName.toString() );
                System.out.println("Start date: " + prStart.toString() );
                System.out.println("End date: " + prFinish.toString() );
            }

            // Now, try to save the same project.
            args.putItemByString( KEY_DESTINATIONNAME,
                                  new ABTString("d:\\projects\\project1.mpp") );
            obj = driver.save( space, args );

			driver.close( space, null );
            space.endSession();
		}

		catch (Exception e)
		{
			System.out.println("Exception caught...printing stack trace...");
			e.printStackTrace();
		}
		finally
		{
			System.out.println("TestMppFileApp ended.");
		}

	}

	public static void main(String args[])
	{
		TestPopSaveSame app = new TestPopSaveSame();
		app.run();
	}

}