package test.io.client.mppfile;

/* *************************************************************************
		Reads a file and writes it back out, sometimes to the same one
***************************************************************************/

import com.abtcorp.io.ABTDriver;
import com.abtcorp.io.client.*;
import com.abtcorp.io.client.mppfile.*;

import com.abtcorp.idl.IABTObjectSpace;
import com.abtcorp.idl.IABTObject;
import com.abtcorp.idl.IABTObjectSet;
import com.abtcorp.idl.IABTDriver;
import com.abtcorp.idl.IABTHashTable;

import com.abtcorp.api.local.ABTObjectSpaceLocal;
import com.abtcorp.api.local.ABTDriverLocal;
import com.abtcorp.api.local.ABTHashTable;

import com.abtcorp.core.ABTHashtable;

import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;

import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;
import com.abtcorp.core.ABTString;
import com.abtcorp.core.ABTEmpty;

import com.abtcorp.core.COM.*;
import com.abtcorp.autowrap.msproject.*;
import com.abtcorp.core.ABTBoolean;
import com.abtcorp.core.ABTInteger;
import com.abtcorp.core.ABTDouble;


public class TestMppFileApp2 implements IABTPMRuleConstants, IABTDriverConstants
{
	protected ABTValue site_;
	IABTObjectSpace space_;
	private IABTDriver projDriver_;
	private IABTDriver siteDriver_;

	public TestMppFileApp2() {}

	public void run()
	{
		try
		{
			System.out.println("TestMppFileApp2 starting...");
			System.out.println("Reading a file and writing it back to a file." );
			space_ = new ABTObjectSpaceLocal();
			space_.startSession( null );

			siteDriver_ = space_.newABTDriver( "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
			populateSite();
			siteDriver_.close( null );

            IABTDriver driver = space_.newABTDriver( "com.abtcorp.io.client.mppfile.ABTClientMppDriver", null );
			driver.open( null );

			ABTString fileName = new ABTString("d:\\projects\\project1.mpp");
			System.out.println( "Input file name is " + fileName.stringValue() );

            IABTHashTable args = space_.newABTHashTable();
            args.putItemByString( KEY_SOURCENAME, fileName );

			ABTValue obj = driver.populate( args );
            if (ABTError.isError(obj)) throw new ABTException(((ABTError)obj).getMessage());

            IABTObject proj = (IABTObject) obj;
			IABTObject object;

			// The driver's populate() method will return an ABTValue
			// object containing an ABTProject object and associated
			// ABTTask objects.

			if ( proj instanceof IABTObject )
			{
                ABTValue val;
				ABTValue prID = proj.getValue( OFD_ID );
				ABTValue prName = proj.getValue( OFD_NAME );
                ABTValue prFileName = proj.getValue( OFD_FILENAME );
                ABTValue prStart = proj.getValue( OFD_START );
                ABTValue prFinish = proj.getValue( OFD_FINISH );
				System.out.println("ID = " + prID.toString() + ", NAME = " + prName.toString() );
                System.out.println("From file: " + prFileName.toString() );
                System.out.println("Start date: " + prStart.toString() );
                System.out.println("End date: " + prFinish.toString() );

/*                // Test deleting something from the project so we can see
                // what happens when it gets saved.
                System.out.println( "Deleting a team resource...." );

                val = proj.getValue( OFD_TEAMRESOURCES );
                if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                IABTObjectSet teamSet = (IABTObjectSet) val;

                if (teamSet.size() > 0)
                {
                    ABTValue delVal = null;
                    object = (IABTObject)teamSet.at( teamSet.size()-1 );
                    if ( object instanceof IABTObject )
                    {
						System.out.println( "Deleting team object " + (object.getValue( OFD_ID )).toString() );
                        delVal = ((IABTObject)object).delete();
                    }
                    if ( ABTError.isError( delVal ) )
                        System.out.println( "Delete error ... " + ((ABTError)delVal).getMessage() );
                }
*/
				// Now, try to save the same project.
				fileName = null;
				System.out.println( "Starting save." );
				fileName = new ABTString("d:\\projects\\projectA.mpp");
				System.out.println( "Output file name is " + fileName.stringValue() );

				args.putItemByString( KEY_DESTINATIONNAME, fileName );
				args.putItemByString( KEY_SOURCE, (ABTValue)proj );

				obj = driver.save( args );
            }

			driver.close( null );
            space_.endSession();
		}

		catch (Exception e)
		{
			System.out.println("Exception caught...printing stack trace...");
			e.printStackTrace();
		}
		finally
		{
			System.out.println("TestMppFileApp ended.");
		}

	}

	public static void main(String args[])
	{
		TestMppFileApp2 app = new TestMppFileApp2();
		app.run();
	}

	private void populateSite() throws ABTException
	{
		openRepo( siteDriver_ );

		IABTHashTable args = space_.newABTHashTable();
		args.putItemByString( KEY_TYPE, new ABTString(TYPE_ALL) );
		ABTValue val = siteDriver_.populate( args );

		if (ABTError.isError( val ) )
			throw new ABTException((ABTError) val);

		if ( val instanceof IABTObject )
			site_ = val;   
		else
			throw new ABTException("Site populate() failed and did not return a site object!");
	}

	private void openRepo( IABTDriver driver ) throws ABTException
	{
		IABTHashTable args = space_.newABTHashTable();
		ABTValue retVal = null;

		args.putItemByString(KEY_USERNAME, new ABTString( "admin" ));
		args.putItemByString(KEY_REPONAME, new ABTString( "ABT Repository" ));
		args.putItemByString(KEY_PRODUCT, new ABTString( "ABT Workbench" ));

		retVal = driver.open( args );
		if ( ABTError.isError( retVal ) )
		{
			System.out.println( "openRepo error from " + ((ABTError)retVal).getMethod() +
								((ABTError)retVal).getMessage() );
			throw new ABTException( "Driver failed to open!" );
		}
	}

   
}