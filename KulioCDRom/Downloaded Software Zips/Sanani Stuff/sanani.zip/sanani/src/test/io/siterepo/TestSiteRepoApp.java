package test.io.siterepo;

import java.util.Enumeration;

import com.abtcorp.io.*;
import com.abtcorp.idl.*;
import com.abtcorp.api.local.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTRepository;

import com.objectspace.jgl.ArrayIterator;

public class TestSiteRepoApp implements ABTNames, IABTDriverConstants, IABTRuleConstants
{
   private String repositoryName_;
   private String product_;
   private ABTObjectSpaceLocal space_ = null;
   //private ABTObject site_ = null;
   private String server_ = null;
   private String user_ = null;
   private String password_ = null;
   private IABTDriver sdriver_ = null;

   public TestSiteRepoApp(String[] args)
   {
      // initializations
      repositoryName_ = "RepoData";
      product_ = "ABT Planner";
      user_ = "admin";
      password_ = "";

   }

   public void run()
   {
      ABTError err = null;
      ABTValue val = null;

      System.out.println("\nTestSiteRepoApp starting...");

      try
      {
         // create an object space and start an user seesion
         space_ = new ABTObjectSpaceLocal();
         
         err = space_.startSession(null);
         if (err!= null)
         {
            processError(err);
            return;
         }
         
			//open a repository connection
			err = testOpen();
         if (err!= null)
         {
            processError(err);
            return;
         }
         
			//test site driver.
			err = testSite();
         if (err!= null)
         {
            processError(err);
            return;
         }

      }
      
      catch (Exception e)
      {
         // exception caught, process error...
         if (e instanceof ABTException)
         {
            // if an ABTException, print the error info
            err = ((ABTException)e).getError();
            if (err!= null)
               processError(err);
         }
         System.out.println("\nException caught...printing stack trace...");
         e.printStackTrace();
      }
      
      finally
      {
         // clean up
         if (sdriver_ != null)
            sdriver_.close(space_, null);
            
         space_.endSession();         
      }
		System.out.println("\nTestMethodRepoApp ended.");
   }

   //=======================================================================
   // instantiate a  repo driver and connect to the repository
   //=======================================================================
   public ABTError testOpen() 
   {
      ABTValue val = null;

      // instantiate a site repo driver 
    	sdriver_ = (IABTDriver) new ABTDriverLocal();
    	sdriver_.initialize(space_, "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);
    	
      // create a hashtable for driver api
    	IABTHashTable args = (IABTHashTable)new ABTHashTable();
    	
    	// populate the hashtable with appropriate keys and values for open()
 	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

      val = sdriver_.open(space_, args);
      if (ABTError.isError(val))            
         return (ABTError)val;
         
      return null;         
   }

   //=======================================================================
   // populate and/or save the site object
   //=======================================================================
   public ABTError testSite() throws ABTException
   {
      ABTError err = null;
      String repo = null;
      ABTValue val = null;
      IABTObject site = null;
      
      try
      {  

         // test populate all

         val = populateSite(repositoryName_, TYPE_ALL, null);
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	else site = (IABTObject)val;

//       err = deleteObject(OBJ_CUSTOMFIELD);
//       if (err != null)     return err;

/*
         val = populateSite("RepoData2", TYPE_CUSTOMFIELD, null);
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	else site = (IABTObject)val;

         val = populateSite(repositoryName_, TYPE_CUSTOMFIELD, null);
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	else site = (IABTObject)val;

         val = populateSite(repositoryName_, TYPE_RESOURCE, null);
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	else site = (IABTObject)val;
*/
         // test resource category list
         val = getResCats(repositoryName_);
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	ABTArrayLocal cats = (ABTArrayLocal)val;

      	// test populate resource by category
      	for (int i=0; i<cats.size(); i++)
      	{
      	   ABTString cat = (ABTString)cats.get(i);
            System.out.println("\nPopulating resource objects that are of category '" + cat + "'...");
            val = populateSite(repositoryName_, TYPE_RESOURCE, cat);
         	if (ABTError.isError(val))      	   return (ABTError) val;
         	
         	//finding objects of the category
            System.out.println("\nFinding resource objects that are of category '" + cat + "'...");
         	val = space_.findObject(OBJ_RESOURCE, "Category = '" + cat + "'");
         	if (ABTError.isError(val))      	   return (ABTError) val;
         	
         	if (val instanceof IABTObjectSet)
         	   showResources((IABTObjectSet)val);         	
      	}

/*
         // test create new....
      	
         val = createNewGlobal(OBJ_RESOURCE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	      	
         val = createNewGlobal(OBJ_ESTMODEL, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
         val = createNewGlobal(OBJ_ADJRULE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
         val = createNewGlobal(OBJ_CUSTOMFIELD, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
         val = createNewGlobal(OBJ_TYPECODE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
         val = createNewGlobal(OBJ_CHARGECODE, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
         val = createNewGlobal(OBJ_TIMEPERIOD, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;
      	
         val = createNewGlobal(OBJ_CALENDAR, site);         
      	if (ABTError.isError(val))      	   return (ABTError) val;

         // testing save...
      	val = saveSite(repositoryName_, site);
      	if (ABTError.isError(val))      	   return (ABTError) val;
*/
      	
         
      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }
      
      return null;
   }


private ABTError deleteObject(String type)
{
   System.out.println("Deleting objects of type " + type + " from the space...");         

	ABTValue val = space_.getObjects(type);
	if (ABTError.isError(val))         
	   return (ABTError)val;
	   
	if ((val instanceof IABTObjectSet) && (((IABTObjectSet)val).size() > 0))
	{
      System.out.println(((IABTObjectSet)val).size()+ " objects found in the space...");         
   
      IABTEnumerator e = ((IABTObjectSet)val).getElements();
      while( e.hasMoreElements() )
      {
         IABTObject object = (IABTObject)e.nextElement();
         val = object.delete();
         if( ABTError.isError( val ) )
            return (ABTError)val;
      }
	}
	else
      System.out.println("No object found in the space...");         
	
	return null;
}


private ABTValue getResCats(String repo)
{
    	IABTHashTable args = (IABTHashTable)new ABTHashTable();
 	   args.putItemByString(KEY_REPONAME, new ABTString(repo));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
    	args.putItemByString(KEY_TYPE, new ABTString(TYPE_RESOURCE));
    	args.putItemByString(KEY_COMMAND, new ABTString(CMD_LIST));
      System.out.println("\nGetting resource categories from repo '" + repo + "'...");
   	ABTValue val = sdriver_.execute(space_, args);
   	if (ABTError.isError(val))      	   return (ABTError) val;
   	if (val instanceof ABTArrayLocal)
   	{
   	   ABTArrayLocal ar = (ABTArrayLocal)val;
   	   for (int i=0; i<ar.size(); i++)
            System.out.println("\n  Resource Category: " + ar.get(i));
   	}
   	return val;
}

private ABTValue populateSite(String repo, String type, ABTString cat)
{
      ABTValue val = null;

  /*
      System.out.println("\nBefore populate...");
   	val = space_.findObject(OBJ_SITE, "ID > 0");
   	if (ABTError.isError(val))      	   return (ABTError) val;
   	
   	if ((val instanceof IABTObjectSet) && (((IABTObjectSet)val).size() > 0))
   	{
   	   IABTObject site = (IABTObject) ((IABTObjectSet)val).at(0);
         ABTError err = showSite(site);
         if (err != null)     return err;
      }
      else
         System.out.println("\nSite object not found.");
   */
   
      System.out.println("\nPopulating objects of type '" + type + "'...");
    	IABTHashTable args = (IABTHashTable)new ABTHashTable();
 	   args.putItemByString(KEY_SOURCENAME, new ABTString(repo));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
    	args.putItemByString(KEY_TYPE, new ABTString(type));
    	
    	if (cat != null)
       	args.putItemByString(KEY_CATEGORY, cat);
   	val = sdriver_.populate(space_, args);
   	if (ABTError.isError(val))      	   return (ABTError) val;
   	IABTObject site = (IABTObject) val;
      System.out.println("\nAfter populate...");
      ABTError err = showSite(site);
      if (err != null)     return err;
      
      return (ABTValue)site;
}


private ABTValue saveSite(String repo, IABTObject site)
{
    	IABTHashTable args = (IABTHashTable)new ABTHashTable();
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));
 	   args.putItemByString(KEY_DESTINATIONNAME, new ABTString(repo));
     	args.putItemByString(KEY_SOURCE, (ABTValue)site);
      System.out.println("\nSaving global objects to repo '" + repo + "'...");
   	return sdriver_.save(space_, args);
}


   //=======================================================================
   // create some global objects to test save 
   //=======================================================================
   private ABTError createNewGlobal(String type, IABTObject site)
   {
     	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
     	
      // create a new object 
      System.out.println("\nCreating new object " + type);
     	parms.putItemByString(OFD_SITE, (ABTValue)site);      	
   	ABTValue val = space_.createNewObject(type, parms);
      // if error, return
   	if (ABTError.isError(val))         return (ABTError)val;

   	IABTObject obj = (IABTObject) val;

      // create some custom enums and agg fields for custom fields
      if (type.equals(OBJ_CUSTOMFIELD))
      {
         System.out.println("\nCreating new custom enum...");
      	parms.putItemByString(OFD_CUSTOMFIELD, (ABTValue) obj);      	
      	val = space_.createNewObject(OBJ_CUSTOMENUM, parms);
      	if (ABTError.isError(val))         return (ABTError)val;

         System.out.println("\nCreating new aggregate field...");
         val = space_.getObjects(OBJ_CUSTOMFIELD);
      	if (ABTError.isError(val))         return (ABTError)val;         
         parms.clear();
      	parms.putItemByString(OFD_TARGETFIELD, (ABTValue)((IABTObjectSet)val).at(0));      	
      	parms.putItemByString(OFD_SOURCEFIELD, (ABTValue)obj);      	
      	val = space_.createNewObject(OBJ_AGGREGATEFIELD, parms);
      	if (ABTError.isError(val))         return (ABTError)val;   
      }
      
      else if (type.equals(OBJ_RESOURCE))
      {
         val = obj.setValue(OFD_ISROLE, ABTBoolean.True());
      	if (ABTError.isError(val))         return (ABTError)val;
         val = obj.setValue(OFD_CALENDARID, new ABTInteger(17));
      	if (ABTError.isError(val))         return (ABTError)val;
      }

      System.out.println(" ");
      return null;
   }
         
      
   //=======================================================================
   // print out the method properties and the associated objects/object sets
   //=======================================================================
   private ABTError showSite(IABTObject site)
   {
      ABTError err = null;
      
      err = show(site, OFD_ID, OFD_NAME, OFD_WEEKSTART);
      if (err != null)    return err;
   
/*   
      // show calendar blob
      ABTValue val = site.getValue(OFD_CALENDAR);
      if (ABTError.isError(val))
         return (ABTError)val;
      if (ABTValue.isNull(val))
         System.out.println(OFD_CALENDAR + ":  null or empty ");
      else
         System.out.print(OFD_CALENDAR + " = " + val.toString() + ";  ");

      // show site calendar object
      System.out.println("\nSite calendar:");
      val = site.getValue(OFD_STDCALENDAR);
      if (val instanceof  IABTObject)
         show ((IABTObject)val, OFD_ID, OFD_NAME, null);
      else
         return new ABTError("Test", "showSite()", "Invalid Data", "site calendar is not found.");

      err = show(site, OFD_TYPECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CHARGECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CALENDARS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_TIMEPERIODS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ESTMODELS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      err = show(site, OFD_ADJRULES, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;

      err = showCustomFields(site);
      if (err != null)    return err;
   
*/
      err = show(site, OFD_TYPECODES, OFD_ID, OFD_EXTERNALID, null);
      if (err != null)    return err;
   
      err = show(site, OFD_CALENDARS, OFD_ID, OFD_NAME, null);
      if (err != null)    return err;
   
      IABTObjectSet oset = ( IABTObjectSet) site.getValue(OFD_RESOURCES);
      if (oset instanceof  IABTObjectSet)
      {
         err = showResources(oset);
         if (err != null)    return err;
      }
      
      err = showCustomFields(site);
      if (err != null)    return err;
   
      return null;
   }


   //=======================================================================
   // print out the resource properties and the associated objects/object sets
   //=======================================================================
   private ABTError showResources(IABTObjectSet oset)
   {
      ABTError err = null;
    
      System.out.println("\nScanning resources...");
      
      //IABTObjectSet oset = ( IABTObjectSet) parent.getValue(OFD_RESOURCES);
      
      System.out.println("The total number of resources in set = " +(( IABTObjectSet) oset).size());

      // getting resources and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_EXTERNALID, OFD_CATEGORY, OFD_ISROLE);
         if (err != null)    return err;

/*
         // show calendar blob
         ABTValue val = obj.getValue(OFD_CALENDAR);
         if (ABTError.isError(val))
            return (ABTError)val;
         if (ABTValue.isNull(val))
            System.out.println(OFD_CALENDAR + ":  null or empty ");
         else
            System.out.print(OFD_CALENDAR + " = " + val.toString() + ";  ");

         err = show(obj, OFD_BASECALENDAR, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;

         err = show(obj, OFD_TYPECODE, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;
         
         err = show(obj, OFD_NOTES, OFD_ID, OFD_RECORDID, OFD_VALUE);
         if (err != null)    return err;
*/         
         System.out.println(" ");         
         
      }
      
      return null;
   }

   //=======================================================================
   // print out the custom field properties and the associated objects/object sets
   //=======================================================================
   private ABTError showCustomFields(IABTObject parent)
   {
      ABTError err = null;
    
      System.out.println("\nScanning custom fields...");
      
      IABTObjectSet oset = ( IABTObjectSet) parent.getValue(OFD_CUSTOMFIELDS);
      if (oset instanceof  IABTObjectSet)
      {
         if (oset.size() == 0)
         {
            System.out.println("The total number of custom fields is 0.");
            return null;
         }
         else
            System.out.println("The total number of custom fields in set = " +(( IABTObjectSet) oset).size());
      }
      else
         return new ABTError("Test", "showCustomFields()", "Invalid Data", "CustomFields is not an obect set.");

      // getting custom fields and their contents
      for (int j = 0; j < oset.size(); j++)
      {
         IABTObject obj = (IABTObject) oset.at(j);
         
         err = show(obj, OFD_ID, OFD_NAME, null);
         if (err != null)    return err;

         err = show(obj, OFD_AGGREGATEFIELDS, OFD_ID, OFD_SOURCEFIELDID, OFD_TARGETFIELDID);
         if (err != null)    return err;

         err = show(obj, OFD_CUSTOMENUMS, OFD_ID, OFD_FIELDID, OFD_VALUE);
         if (err != null)    return err;
         System.out.println(" ");         
         
      }      
      return null;
   }


   //=======================================================================
   // Retrieve an object or an object set specified by "field" from the "parent" object
   // and print out the values in "field".
   //=======================================================================
   private ABTError show(IABTObject parent, String field, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTError err = null;

      val1 = parent.getValue(field);

      if (ABTValue.isNull(val1))
         System.out.println("\n" + field + ":  null or empty ");

      else if (val1 instanceof  IABTObjectSet)
      {
         IABTObjectSet oset = (IABTObjectSet) val1;
         
         if (oset.size() > 0)
         {
            System.out.println("\n" + field + ":  total number of objects in set = " + oset.size());         
            for (int j = 0; j < oset.size(); j++)
            {
               IABTObject object = (IABTObject) oset.at( j);
               err = show (object, field1, field2, field3);
               if (err != null)
                  return err;
            }
         }
      }
      else if (val1 instanceof  IABTObject)
      {
         IABTObject object = (IABTObject) val1;
         System.out.println("\n" + field + ": ");         
         err = show (object, field1, field2, field3);
         if (err != null)
            return err;
      }
      else
         System.out.println( "\n" + field + " is not an object set or an object.");
         
      return null;
   }

   //=======================================================================
   // print out the property values of the input object
   //=======================================================================
   private ABTError show(IABTObject object, String field1, String field2, String field3)
   {
      ABTValue val1 = null;
      ABTValue val2 = null;
      ABTValue val3 = null;

      if (object == null)
         return new ABTError ("Test", "show()", "Invalid Data", "The input object is null");
      
      ABTValue val = object.getValue("ABTRemoteID");
      if (ABTError.isError(val))
         return (ABTError)val;
      if (val instanceof ABTRemoteIDRepository)
         System.out.print("RepoID = " + ((ABTRemoteIDRepository)val).getRepositoryID() + ";  ");
      else
         System.out.println("RemoteID:  null or empty ");
         
      if (field1 != null)
      {
         val1 = object.getValue(field1);
         if (ABTError.isError(val1))
            return (ABTError)val1;
         if (ABTValue.isNull(val1))
            System.out.println(field1 + ":  null or empty ");
         else
            System.out.print(field1 + " = " + val1.toString() + ";  ");
      }
         
      if (field2 != null)
      {
         val2 = object.getValue(field2);
         if (ABTError.isError(val2))
            return (ABTError)val2;
         if (ABTValue.isNull(val2))
            System.out.println(field2 + ":  null or empty ");
         else
            System.out.print(field2 + " = " + val2.toString() + "; ");
      }
      
      if (field3 != null)
      {
         val3 = object.getValue(field3);
         if (ABTError.isError(val3))
            return (ABTError)val3;
         if (ABTValue.isNull(val3))
            System.out.println(field3 + ":  null or empty ");
         else
            System.out.print(field3 + " = " + val3.toString() + "; ");
      }
      
      System.out.println(" ");
      
      return null;
   }


   //=======================================================================
   // print out the contents of an ABTError object
   //=======================================================================
   private void processError(ABTError err) 
   {
      System.out.println("\nERROR OCCURRED!!!");
      System.out.println("  Package:   " + err.getPackage());
      System.out.println("  Component: " + err.getComponent());
      System.out.println("  Method:    " + err.getMethod());
//      System.out.println("  Code:      " + err.getCode());
      System.out.println("  Message:   " + err.getMessage());
      System.out.println("  Info:      " + err.getInfo().toString());
   }

   public static void main(String args[])
   {
      TestSiteRepoApp app = new TestSiteRepoApp(args);
      app.run();
   }

}