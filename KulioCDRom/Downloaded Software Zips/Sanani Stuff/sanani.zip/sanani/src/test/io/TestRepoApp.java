package test.io;

//
// This Java program demonstrates usage of the Sanani facilities to populate and access
// ABT project objects in the Sanani object space.
//
// 1.  Create an ABT Object Space
// 2.  Instantiate a Repository Driver and open it.
// 3.  Create an object selector object which identifies which object(s) to create and
//     populate.
// 4.  Request the driver to populate the object(s) and return an object set.  For the
//     purposes of this program, the object set should contain all of the projects in
//     an ABT Repository.  Each project will reference its associated tasks.
// 5.  Iterate through the object set and print the name and ID of each project.
// 6.  For each project in the object, also iterate through the associated task objects
//     and print each task's ID and task name.
// 7.  Close the driver.
//
// TO BE ADDED:
//
// 1.  Write project(s) to the local file system.
// 2.  Read project(s) from the local file system.
// 3.  Write the project(s) back to the ABT Repository.
//

import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import com.abtcorp.core.ABTError;

import com.abtcorp.rulebase.*;

import com.objectspace.jgl.ArrayIterator;

public class TestRepoApp
{
   public TestRepoApp() {}

   public void run()
   {
      try
      {
         System.out.println("TestRepoApp starting...");
         ABTObjectSpace space = new ABTObjectSpace();
         TestRepoDriver driver = new TestRepoDriver(space,
         												"steveb",
         												"ABTRepository",
         												null,
         												null,
         												"Project Workbench" );
			driver.open();
/*			
			String[] repolist = driver.getDataRepositoryList();
			for (int i = 0; i < repolist.length; i++)
			{
			   System.out.println("The projects for repository '" + repolist[i] + "' are...");
			   String[] projlist = driver.getProjectNameList(repolist[i]);
			   for (int j = 0; j < projlist.length; j++)
			      System.out.println("  " + projlist[j]);
			}
*/
			// Ask the Repository driver to populate the object space with
			// projects and tasks.  The driver's populate() method will return
			// an ABTValue objectset containing ABTProject objects and associated
			// ABTTask objects.

			ABTValue os = driver.populate("select * from prProject");
         if (os instanceof ABTObjectSet)
         {
            ABTObjectSet oset = (ABTObjectSet) os;
            System.out.println("This project object set contains " + oset.size() + " objects.");
            System.out.println("Scanning project objects in object set...");
            for (int i = 0; i < oset.size(); i++)
            {
               ABTObject object = (ABTObject) oset.at(i);
               ABTValue prID = object.getValue("PRID");
               ABTValue prName = object.getValue("PRNAME");
               System.out.println("PRID = " + prID.toString() +
                                  ", PRNAME = " + prName.toString() );
               System.out.println("Scanning task objects for this project...");
               ABTObjectSet taskoset = (ABTObjectSet) object.getValue("PRALLTASKS");
               if (taskoset.size() > 0)
               {
                  for (int j = 0; j < taskoset.size(); j++)
                  {
                     object = (ABTObject) taskoset.at(j);
                     prID = object.getValue("PRID");
                     prName = object.getValue("PRTASKNAME");
                     System.out.println("  PRID = " + prID.toString() +
                                        ", PRTASKNAME = " + prName.toString() );
                  }
               }
               else
                  System.out.println("There are no tasks for this project.");
            }
         }

         driver.close();

      } catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
			System.out.println("TestRepoApp ended.");
      }
   }

   public static void main(String args[])
   {
      TestRepoApp app = new TestRepoApp();
      app.run();
   }
}