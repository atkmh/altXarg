package test.io.methrepo;
import java.io.*;
import java.util.Enumeration;
import com.abtcorp.io.*;
import com.abtcorp.idl.*;
import com.abtcorp.idl.IABTPropertyType;
import com.abtcorp.idl.IABTRuleConstants;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTLocalID;
import com.abtcorp.api.local.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.ABTNames;
import com.abtcorp.repository.ABTRepository;
//import com.abtcorp.objectModel.mm.fr.*;


import com.objectspace.jgl.ArrayIterator;
import com.abtcorp.core.ABTException;
import com.abtcorp.hub.*;
import com.abtcorp.blob.*;


public class LeeAPI implements ABTNames, IABTDriverConstants, IABTPropertyType, IABTRuleConstants, IABTMMRuleConstants
{
   private String repositoryName_;
   private String product_;
   private ABTObjectSpaceLocal space_ = null;
   private String server_ = null;
   private String user_ = null;
   private String password_ = null;
   private IABTDriver mdriver_ = null;
   private IABTDriver sdriver_ = null;
   private IABTObject site_, resource_, estModel_, adjRule_, customField_;

   //private ABTUserSession userSession_;
   private   IABTObjectSet oset = null;
   private PrintWriter pStr = null;   
   
   public LeeAPI(String[] args)
   {
      // initializations
      repositoryName_ = "ABTData";
      product_ = "ABT Planner";
      user_ = "admin";
      password_ = "administrator";

   }

   public void run()
   {
      ABTError err = null;
      ABTValue val = null;

      System.out.println("\nLeeAPI starting...");

      try
      {
//make an output file
        System.out.println("Opening output file.");
        pStr = new PrintWriter(new BufferedOutputStream(new FileOutputStream("OutFile.txt")));

         // create an object space and start a user seesion
         space_ = new ABTObjectSpaceLocal();

         err = space_.startSession(null);
         if (err != null)
         {
            processError(err);
            return;

         }

//test site driver.

			testSite();
         if (site_ == null){
            System.out.println("testSite() didn't work");
            return;
          }

//*****************************************************************
// ObjectSpaceLocal methods to be tested
//*****************************************************************

//addProperty()

        err = space_.addProperty("abt.Site","leeName", "leeCaption", 0,false, true, true, false, null, null,null );
         if (err!= null){
            processError(err);
            return;
          }
     propertyScreen(site_,"\nSITE");  //check to see if new prop added

//getProperties()
     IABTPropertySet props = space_.getProperties(OBJ_SITE);


//getRulebase()
String ruleBase = space_.getRulebase();
System.out.println("Rulebase = " + ruleBase);

//getExtension()
String ext = space_.getExtension();
System.out.println("extension = " + ext);

//getObjectPath()
String objPath = space_.getObjectPath();
System.out.println("object path = " + objPath);

//createObject()
        ABTRemoteIDInteger
            RemoteID0 = new ABTRemoteIDInteger(0);
        val = space_.createObject(OBJ_MM_METHOD, RemoteID0,null);
        IABTObject testObj = (IABTObject)val;        
        propertyPrint(testObj,"\nNewMethod");  //check to see if new prop added
        
//createNewObjectSet()
        val = space_.createNewObjectSet(OBJ_SITE);
        IABTObjectSet testObjSet = (IABTObjectSet) val;
        testObjSet.add(site_);
/*        if (testObjSet.isCloseEnoughType(3,OBJ_SITE, resource_))
            System.out.println("ok");
        else
            System.out.println("not ok");
*/            
        testObjSet.add(resource_);

        if (testObjSet.size() > 0)
        {

         for (int j = 0; j < testObjSet.size(); j++)
         {
           IABTObject obj = (IABTObject) testObjSet.at(j);
           propertyScreen(obj,"SITE-in objset");
         }
        }

        
//findObject()
    val = space_.findObject(OBJ_SITE,"Name LIKE '%TestName%'");
        testObjSet = (IABTObjectSet) val;
        if (testObjSet.size() > 0)
        {

         for (int j = 0; j < testObjSet.size(); j++)
         {
           IABTObject obj = (IABTObject) testObjSet.at(j);
           //propertyScreen(obj,"SITE-after findObject()");
         }
        }
//findObjectbyID()
    IABTLocalID objId = site_.getID();    
    val = space_.findObjectByID(OBJ_SITE,objId);
    IABTObject obj = (IABTObject) val;
//    propertyScreen(obj,"SITE-after findObjectById()");
        
//findObjectByRemoteID()
    ABTRemoteIDInteger R_id = new ABTRemoteIDInteger(20);
    site_.setValue(OFD_REMOTEID,R_id);
    val = site_.getValue(OFD_REMOTEID);
    R_id = (ABTRemoteIDInteger) val;
    System.out.println("remote id for site_: " + R_id); 
    val = space_.findObjectByRemoteID(OBJ_SITE, R_id);
    obj = (IABTObject) val;
    propertyScreen(obj,"SITE-after findObjectByRemoteId()");
    
//startTransaction()
    val = space_.startTransaction();
        val = space_.startTransaction();
    //do something
        val = space_.createNewObjectSet(OBJ_SITE);
        testObjSet = (IABTObjectSet) val;
        testObjSet.add(site_);
    //roll it back        
    val = space_.rollbackTransaction();

    //do something again
        val = space_.createNewObjectSet(OBJ_SITE);
        testObjSet = (IABTObjectSet) val;
        testObjSet.add(site_);
    //commit it
    val = space_.commitTransaction();

//make an MM driver
   			err = setDriver();
         if (err!= null){
            processError(err);
            return;
          }
//test method populate
        err = testMethod();
        if (err!= null){
            processError(err);
        }
      }

      catch (IOException e) 
      {
            System.err.println("Caught IOException: " + e.getMessage());
      }
      catch (Exception e)
      {
         // exception caught, process error...
         if (e instanceof ABTException)
         {
            // if an ABTException, print the error info
            err = ((ABTException)e).getError();
            if (err!= null)
               processError(err);
         }
         System.out.println("\nException caught...printing stack trace...");
         e.printStackTrace();
      }

        
      finally
      {
         // clean up
         mdriver_.close(space_, null);
         sdriver_.close(space_, null);
         space_.endSession();
            if (pStr != null) {
                System.out.println("closing output file.");
                pStr.close();
            }else {
                System.out.println("PrintStream not open");
            }

      }
		System.out.println("\nLeeAPI ended.");
   }


   //=======================================================================
   // instantiate a site repo driver, connect to the repository and
   // populate the site object
   //=======================================================================
   public IABTObject testSite() throws ABTException
   {
      try
      {
         // instantiate a method repo driver
       	sdriver_ = (IABTDriver) new ABTDriverLocal();
       	sdriver_.initialize(space_, "com.abtcorp.io.siterepo.ABTSiteRepoDriver", null);

         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

       	// populate the hashtable with appropriate keys and values for open()
    	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
    	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
       	args.putItemByString(KEY_USERNAME, new ABTString(user_));
       	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

         ABTValue val = sdriver_.open(space_, args);
         if (ABTError.isError(val))            return null;

         // populate the site
         System.out.println("\nPopulating site objects...");
       	args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));

      	val = sdriver_.populate(space_, args);
      	if (ABTError.isError(val))      	   return null;

      	// if succeeded, show the results
         site_ = (IABTObject) val;
         System.out.println("Scanning site object...");
            propertyPrint(site_,"\nSITE");

//         ABTError err = showSite(site);
//         if (err != null)     return err;


         // test create new....
         val = createNewGlobal(OBJ_RESOURCE, site_);
      	if (ABTError.isError(val))      	   return null;
        resource_ = (IABTObject) val;
        
         val = createNewGlobal(OBJ_ESTMODEL, site_);
      	if (ABTError.isError(val))      	   return null;
        estModel_ = (IABTObject) val;
        
         val = createNewGlobal(OBJ_ADJRULE, site_);
      	if (ABTError.isError(val))      	   return null;
        adjRule_ = (IABTObject) val;
        
         val = createNewGlobal(OBJ_CUSTOMFIELD, site_);
      	if (ABTError.isError(val))      	   return null;
        customField_ = (IABTObject) val;

         val = createNewGlobal(OBJ_TYPECODE, site_);
      	if (ABTError.isError(val))      	   return null;

         val = createNewGlobal(OBJ_CHARGECODE, site_);
      	if (ABTError.isError(val))      	   return null;

         val = createNewGlobal(OBJ_TIMEPERIOD, site_);
      	if (ABTError.isError(val))      	   return null;

         val = createNewGlobal(OBJ_CALENDAR, site_);
      	if (ABTError.isError(val))      	   return null;

         // test save...
         System.out.println("\nSaving site objects...");
       	args.putItemByString(KEY_SOURCE, (ABTValue)site_);
      	val = sdriver_.save(space_, args);  // use previous args
      	if (ABTError.isError(val))      	   return null;


      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }
      return site_;
   }
   public ABTError testMethod() throws ABTException
   {
//      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;

      try
      {

         // create a hashtable for method populate
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();


         // get method list from repository.
       	args.putItemByString(KEY_COMMAND,  new ABTString(CMD_LIST));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));

        ABTHashTable methodList = (ABTHashTable) mdriver_.execute(space_, (IABTHashTable) args);

         // check error
         if (ABTError.isError(val))            return (ABTError)val;

         // make sure the list is not empty
         if ((methodList == null) || methodList.isEmpty())
         {
            System.out.println("\nThe repository does not contain any method.");
            return null;
         }

         System.out.println("\nThe repository contains these methods:");

         // get external ids from the method list
         int i = 0;
         extIDs = new ABTArray();
         enum = methodList.getElements();
         while (enum.hasMoreElements())
         {
            //extIDs.put(i, (ABTValue)enum.nextElement());
            System.out.println(enum.nextElement());
            //System.out.println(extIDs.at(i));
            i++;
         }

         // populate a single method (using external ID to find it)

      System.out.println("\nPopulating methods with lock...");
      args.clear();
    	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
     	args.putItemByString(KEY_EXTID, new ABTString("SAMPLE1"));
    	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
    	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
  	   args.putItemByString(KEY_SOURCENAME, new ABTString(repositoryName_));
 	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
    	args.putItemByString(KEY_USERNAME, new ABTString(user_));
    	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This method object set contains " + oset.size() + " objects.");
         System.out.println("Scanning method objects in object set...");
         for (i = 0; i < oset.size(); i++)
         {
            IABTObject method = (IABTObject) oset.at(i);
//            method.setValue(OFD_NAME, new ABTString("newName"));
 //           method.setValue(OFD_GUIDELINES, new ABTString("newGuidelines"));

            propertyPrint(method,"\nMETHODS");

//TASKS
                 ABTValue taskVal = method.getValue(OFD_ALLTASKS);
                 IABTObjectSet taskoset = (IABTObjectSet)taskVal;
                 if (taskoset.size()> 0)
                 {
//                    for (int j = 0; j < taskoset.size(); j++)
                    for (int j = 0; j < 10; j++)
                    {
                        IABTObject taskObj = (IABTObject) taskoset.at(j);
//                        taskObj.setValue(OFD_NAME, new ABTString( "newTaskName"));
                        propertyPrint(taskObj,"\nTASK");
                    }

                 }
                 else { System.out.println("\nNO TASKS FOR THIS METHOD");}
//DELIVERABLES
                 ABTValue delivVal = method.getValue(OFD_ALLDELIVERABLES);
                 IABTObjectSet delivoset = (IABTObjectSet)delivVal;
                 if (delivoset.size()> 0)
                 {
//                    for (int j = 0; j < delivoset.size(); j++)
                    for (int j = 0; j < 10; j++)
                    {
                        IABTObject delivObj = (IABTObject) delivoset.at(j);
//                   delivObj.setValue(OFD_NAME, new ABTString("newDelivName"));
                        propertyPrint(delivObj,"\nDELIVERABLE");
                    }
                 }
                 else { System.out.println("\nNO DELIVERABLES FOR THIS METHOD");}

//PACKAGES
                 ABTValue packVal = method.getValue(OFD_ALLPACKAGES);
                 IABTObjectSet packoset = (IABTObjectSet)packVal;
                 if (packoset.size()> 0)
                 {
                    for (int j = 0; j < packoset.size(); j++)
                    {
                        IABTObject packObj = (IABTObject) packoset.at(j);
//                  packObj.setValue(OFD_NAME, new ABTString("newPackageName"));
                        propertyPrint(packObj,"\nPACKAGE");
                    }

                 }
                 else { System.out.println("\nNO PACKAGES FOR THIS METHOD");}
//REC RULES
/*                 ABTValue rrVal = method.getValue(OFD_RECRULES);
                 IABTObjectSet rroset = (IABTObjectSet)rrVal;
                 if (rroset.size()> 0)
                 {
                    for (int j = 0; j < rroset.size(); j++)
                    {
                        IABTObject rrObj = (IABTObject) rroset.at(j);
                  rrObj.setValue(OFD_NAME, new ABTString("newRecRules"));
                        propertyPrint(rrObj,"\nREC RULE");
                    }

                 }
                 else { System.out.println("\nNO REC RULES FOR THIS METHOD");}
*/
//PACKAGE MEMBERS
                 ABTValue packmemVal = method.getValue(OFD_ALLPACKAGEMEMBERS);
                 IABTObjectSet packmemoset = (IABTObjectSet)packmemVal;
                 if (packmemoset.size()> 0)
                 {
                    for (int j = 0; j < packmemoset.size(); j++)
                    {
                        IABTObject packmemObj = (IABTObject) packmemoset.at(j);
//                  packmemObj.setValue(OFD_TABLENAME, new ABTString("newPkgTblName"));
                        propertyPrint(packmemObj,"\nPACKAGE MEMBERS");
                    }

                 }
                 else { System.out.println("\nNO PACKAGE MEMBERS FOR THIS METHOD");}
//PAGES
                 ABTValue pageVal = method.getValue(OFD_ALLPAGES);
                 IABTObjectSet pageoset = (IABTObjectSet)pageVal;
                 if (pageoset.size()> 0)
                 {
                    for (int j = 0; j < pageoset.size(); j++)
                    {
                        IABTObject pageObj = (IABTObject) pageoset.at(j);
//                  pageObj.setValue(OFD_NAME, new ABTString("newPageName"));
                        propertyPrint(pageObj,"\nPAGES");
                    }

                 }
                 else { System.out.println("\nNO PAGES FOR THIS METHOD");}
//PAGE MEMBERS
                 ABTValue pagememVal = method.getValue(OFD_ALLPAGEMEMBERS);
                 IABTObjectSet pagememoset = (IABTObjectSet)pagememVal;
                 if (pagememoset.size()> 0)
                 {
                    for (int j = 0; j < pagememoset.size(); j++)
                    {
                        IABTObject pagememObj = (IABTObject) pagememoset.at(j);
                  pagememObj.setValue(OFD_SEQUENCE, new ABTInteger(4) );
                        propertyPrint(pagememObj,"\nPAGE MEMBERS");
                    }

                 }
                 else { System.out.println("\nNO PAGE MEMBERS FOR THIS METHOD");}


//create dependency
/*        ABTError err = createNewDependency(method);
      if (err != null)    return err;



//create assignment
        err = createNewAssignment(method);
      if (err != null)    return err;

//create task estimate
        err = createNewTaskEst(method);
      if (err != null)    return err;
*/



//DEPENDENCIES
                 ABTValue dependVal = method.getValue(OFD_ALLDEPENDENCIES);
                 IABTObjectSet dependoset = (IABTObjectSet)dependVal;
                 if (dependoset.size()> 0)
                 {
                    for (int j = 0; j < dependoset.size(); j++)
                    {
                        IABTObject dependObj = (IABTObject) dependoset.at(j);
//                  dependObj.setValue(OFD_TYPE, new ABTInteger(2));
                        propertyPrint(dependObj,"\nDEPENDENCIES");
                    }

                 }
                 else { System.out.println("\nNO DEPENDENCIES FOR THIS METHOD");}

//ASSIGNMENTS
                 ABTValue assignVal = method.getValue(OFD_ALLASSIGNMENTS);
                 IABTObjectSet assignoset = (IABTObjectSet)assignVal;
                 if (assignoset.size()> 0)
                 {
                    for (int j = 0; j < assignoset.size(); j++)
                    {
                        IABTObject assignObj = (IABTObject) assignoset.at(j);
//                  assignObj.setValue(OFD_WDM, new ABTDouble(1.1));
                        propertyPrint(assignObj,"\nASSIGNMENTS");
                    }

                 }
                 else { System.out.println("\nNO ASSIGNMENTS FOR THIS METHOD");}
//TASK ESTIMATES

                 ABTValue tEstVal = method.getValue(OFD_ALLTASKESTIMATES);
                 IABTObjectSet tEstoset = (IABTObjectSet)tEstVal;
                 if (tEstoset.size()> 0)
                 {
                    for (int j = 0; j < tEstoset.size(); j++)
                    {
                        IABTObject tEstObj = (IABTObject) tEstoset.at(j);
//                  tEstObj.setValue(OFD_FORMULA, new ABTString("newTskEstFormula"));
                        propertyPrint(tEstObj,"\nTASK ESTIMATES");
                    }

                 }
                 else { System.out.println("\nNO TASK ESTIMATES FOR THIS METHOD");}


         }

//save the method back to repository
         ABTError err = saveOset(oset, TYPE_METHOD);
         if (err != null)
         {
            processError(err);
            return null;
         }

//test saveAs functionality
/*        for (int j = 0; j < oset.size(); j++)
        {
            IABTObject methObj = (IABTObject)oset.at(j);
            ABTError err = saveMethodAs(methObj);
             if (err != null)
             {
                processError(err);
                return null;
             }
        }
*/
      }

      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }

   public ABTError saveOset(IABTObjectSet oset, String type) throws ABTException
   {

      try
      {
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();
        System.out.println("\nSaving an object set back to repository and unlocking ...");
       	args.putItemByString(KEY_TYPE,  new ABTString(type));
       	args.putItemByString(KEY_SOURCE, (ABTValue)oset);
       	args.putItemByString(KEY_UNLOCK, new ABTBoolean(true));
        ABTValue val = mdriver_.save(space_, args);
         // if error, return
      	if (ABTError.isError(val))            return (ABTError)val;
        System.out.println("End saving " + type + " object set. ");

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }

   public ABTError saveMethodAs(IABTObject obj) throws ABTException
   {

      try
      {
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();
        System.out.println("\nSaving new method back to repository ...");
        args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_SAVEAS));
        args.putItemByString(KEY_EXTID, new ABTString("Liz"));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_METHOD));
       	args.putItemByString(KEY_SOURCE, (ABTValue)obj);
//       	args.putItemByString(KEY_UNLOCK, new ABTBoolean(true));
        ABTValue val = mdriver_.save(space_, args);
         // if error, return
      	if (ABTError.isError(val))            return (ABTError)val;
        System.out.println("End saving new method. ");

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }


   public ABTError setDriver() throws ABTException
   {

      ABTValue val = null;

      try
      {
         // instantiate a method repo driver
       	mdriver_ = (IABTDriver) new ABTDriverLocal();
       	mdriver_.initialize(space_, "com.abtcorp.io.methrepo.ABTMMRepoDriver", null);

         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

       	// populate the hashtable with appropriate keys and values for open()
       	if (repositoryName_ != null)
       	   args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
       	if (product_ != null)
       	   args.putItemByString(KEY_PRODUCT, new ABTString(product_));
       	if (user_ != null)
          	args.putItemByString(KEY_USERNAME, new ABTString(user_));
       	if (password_ != null)
          	args.putItemByString(KEY_PASSWORD, new ABTString(password_));

         val = mdriver_.open(space_, args);
         if (ABTError.isError(val))            return (ABTError)val;

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }
   //=======================================================================
   // create Dependency
   //=======================================================================
/*   private ABTError createNewDependency(IABTObject method)
   {

      // dependency needs some tasks first
      System.out.println("\nCreating new tasks for dependencies...");

    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject task1 = (IABTObject) val;


   	val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject task2 = (IABTObject) val;
      // create some dependencies
      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task1);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task2);

   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
     	IABTObject assign1 = (IABTObject) val;
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

      return null;
   }


   //=======================================================================
   // create assignment
   //=======================================================================
   private ABTError createNewAssignment(IABTObject method)
   {

      System.out.println("\nCreating new assignment...");

      // assignment needs some tasks first
      System.out.println("\nCreating new tasks for assignment...");
   	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val1 = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val1))
         return (ABTError)val1;

     	IABTObject task1 = (IABTObject) val1;


// make a resource (assignment needs a resource)
         val = createNewGlobal(OBJ_RESOURCE, site);
      	if (ABTError.isError(val))      	   return (ABTError) val;

   	IABTHashTable parms2 = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_RESOURCE, null);

             val = createNewGlobal(OBJ_RESOURCE, site);
      	if (ABTError.isError(val))      	   return (ABTError) val;

    ABTValue val2 = createNewGlobal(OBJ_RESOURCE,site);
      // if error, return
   	if (ABTError.isError(val2))
         return (ABTError)val2;

    IABTObject resource1 = (IABTObject) val2;


//now make an assignment
   	parms.putItemByString(OFD_TASK, (ABTValue)task1);
   	parms.putItemByString(OFD_RESOURCE, (ABTValue)resource1);
   	ABTValue val3 = space_.createNewObject(OBJ_MM_ASSIGNMENT, parms);
      // if error, return
   	if (ABTError.isError(val3))
         return (ABTError)val3;

      return null;
   }
   //=======================================================================
   // create Task Estimate
   //=======================================================================
   private ABTError createNewTaskEst(IABTObject method)
   {

      System.out.println("\nCreating new task estimate...");

      //  needs some tasks first
      System.out.println("\nCreating new tasks for task estimates...");
   	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val1 = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val1))
         return (ABTError)val1;

     	IABTObject task1 = (IABTObject) val1;


//first make an estModel (task est needs an estModel)

   	parms.clear();
   	parms.putItemByString(OFD_ESTMODEL, null);

    ABTValue val2 = createNewGlobal(OBJ_ESTMODEL,site);
      	if (ABTError.isError(val))      	   return (ABTError) val;
    IABTObject estModel1 = (IABTObject) val2;
    estModel1.setValue(OFD_ID, new ABTInteger(1));

//now make a task estimate
   	parms.clear();
   	parms.putItemByString(OFD_TASK, (ABTValue)task1);
   	parms.putItemByString(OFD_ESTMODEL, (ABTValue)estModel1);
   	ABTValue val3 = space_.createNewObject(OBJ_MM_TASKESTIMATE, parms);
      // if error, return
   	if (ABTError.isError(val3))
         return (ABTError)val3;

      return null;
   }

*/
   public ABTError testAdjRule() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the adjRules
         System.out.println("\nPopulating adjRules with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_ADJRULE));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This adjRule object set contains " + oset.size() + " objects.");
         System.out.println("Scanning adjRule objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject adjRule = (IABTObject) oset.at(i);


//            adjRule.setValue(OFD_NAME, new ABTString("New adjRule"));

            propertyPrint(adjRule,"\nADJ RULES");
         }
         saveOset(oset,TYPE_ADJRULE);
      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }



   public ABTError testCustField() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the custFields
         System.out.println("\nPopulating custFields with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_CUSTOMFIELD));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This custField object set contains " + oset.size() + " objects.");
         System.out.println("Scanning custField objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject custField = (IABTObject) oset.at(i);
//                  custField.setValue(OFD_NAME, new ABTString("newCustFldName"));
                  propertyPrint(custField,"\nCUSTOM FIELDS");

//AGGREGATE FIELDS
                 ABTValue agFieldVal = custField.getValue(OFD_AGGREGATEFIELDS);
                 IABTObjectSet agFieldoset = (IABTObjectSet)agFieldVal;
                 if (agFieldoset.size()> 0)
                 {
                    for (int j = 0; j < agFieldoset.size(); j++)
                    {
                        IABTObject agFieldObj = (IABTObject) agFieldoset.at(j);
//                        agFieldObj.setValue(OFD_NAME, new ABTString("newAgFldName"));
                        propertyPrint(agFieldObj,"\nAGGREGATE FIELD");
                    }
                 }
                 else {System.out.println ("\nAGGREGATE FIELDS: No Aggregate Fields");}
//CUSTOM ENUMS
                 ABTValue custEnumVal = custField.getValue(OFD_CUSTOMENUMS);
                 IABTObjectSet custEnumoset = (IABTObjectSet)custEnumVal;
                 if (custEnumoset.size()> 0)
                 {
                    for (int j = 0; j < custEnumoset.size(); j++)
                    {
                        IABTObject custEnumObj = (IABTObject) custEnumoset.at(j);
//                        custEnumObj.setValue(OFD_NAME, new ABTString("newCustEnumName"));
                        propertyPrint(custEnumObj,"\nCUSTOM ENUMS");
                    }
                 }
                 else {System.out.println ("\nCUSTOM ENUMS: No Custom Enums");}

         }
         saveOset(oset, TYPE_CUSTOMFIELD);

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }


   public ABTError testEstModel() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the EstModel
         System.out.println("\nPopulating estModels with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_ESTMODEL));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))      	   return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This estModel object set contains " + oset.size() + " objects.");
         System.out.println("Scanning estModel objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject estModel = (IABTObject) oset.at(i);
//                  estModel.setValue(OFD_NAME, new ABTString("newEstModName"));
                  propertyPrint(estModel,"\nEST MODELS");
         }
         saveOset(oset, TYPE_ESTMODEL);

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }


   public ABTError testResource() throws ABTException
   {
      IABTObjectSet oset = null;
      ABTValue val = null;
      Enumeration enum = null;
      ABTArray extIDs = null;
      try
      {
         // create a hashtable for driver api
       	IABTHashTable args = (IABTHashTable)new ABTHashTable();

         // populate the Resource
         System.out.println("\nPopulating Resources with lock...");
       	args.putItemByString(KEY_SUBTYPE, new ABTString(SUBTYPE_FULL));
       	args.putItemByString(KEY_LOCK, new ABTBoolean(true));
       	args.putItemByString(KEY_TYPE,  new ABTString(TYPE_RESOURCE));

      	val = mdriver_.populate(space_, args);

         // if error, return
      	if (ABTError.isError(val))
      	return (ABTError) val;

      	// if succeeded, show the results
         oset = (IABTObjectSet) val;
         System.out.println("This Resource object set contains " + oset.size() + " objects.");
         System.out.println("Scanning Resource objects in object set...");
         for (int i = 0; i < oset.size(); i++)
         {
            IABTObject Resource = (IABTObject) oset.at(i);
//                  Resource.setValue(OFD_NAME, new ABTString("newResName"));
                  propertyPrint(Resource,"\nRESOURCES");
         }
         saveOset(oset,TYPE_RESOURCE);

      }
      catch (Exception e)
      {
         if (e instanceof ABTException)
            throw (ABTException) e;
         else
         {
            System.out.println("Exception caught...printing stack trace...");
            e.printStackTrace();
         }
      }

      return null;
   }



   //=======================================================================
   // create some method to test save
   //=======================================================================
   private ABTValue createNewMethod()
   {
      ABTError err = null;

      // create a new method
      System.out.println("\nCreating new method... ");
   	ABTValue val = space_.createNewObject(OBJ_MM_METHOD, null);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

   	IABTObject newMethod = (IABTObject) val;
      val = newMethod.setValue(OFD_EXTERNALID, new ABTString("New Method9"));
   	if (ABTError.isError(val))
         return (ABTError)val;

      // create some tasks, dependencies and deliverables for this method
   	err = createNewTasks(newMethod);
      if (err != null)    return err;

      err = createNewPages(newMethod);
      if (err != null)    return err;

      err = createNewPackages(newMethod);
      if (err != null)    return err;

      return (ABTValue)newMethod;
   }

   private ABTError createNewPackages(IABTObject method)
   {
      // create some new object
      System.out.println("\nCreating new package...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);
   	parms.putItemByString(OFD_HIDDEN, new ABTBoolean(true));

   	ABTValue val = space_.createNewObject(OBJ_MM_PACKAGE, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject pkg = (IABTObject) val;

      return null;
   }


   private ABTError createNewPages(IABTObject method)
   {
      // create some new object
      System.out.println("\nCreating new page...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val = space_.createNewObject(OBJ_MM_PAGE, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject page = (IABTObject) val;

      System.out.println("\nCreating new page member...");
    	parms.clear();
   	parms.putItemByString(OFD_PAGE, (ABTValue)page);

   	val = space_.getObjects(OBJ_CUSTOMFIELD);
   	if (ABTError.isError(val))
   	   return (ABTError)val;

   	if (val instanceof IABTObjectSet)
   	{
   	   IABTObjectSet set = (IABTObjectSet) val;
   	   val = set.at(0);
      	if (ABTError.isError(val))            	   return (ABTError)val;
   	}
   	if (ABTValue.isNull(val))
         return new ABTError("Test", "createNewPages()", "Invalid Data", "Custom field empty or null.");
   	parms.putItemByString(OFD_CUSTOMFIELD, val);

   	val = space_.createNewObject(OBJ_MM_PAGEMEMBER, parms);
   	if (ABTError.isError(val))         return (ABTError)val;

      IABTObject mbr = (IABTObject) val;

      val = mbr.setValue(OFD_SEQUENCE, new ABTInteger(15));
   	if (ABTError.isError(val))         return (ABTError)val;

      return null;
   }
   //=======================================================================
   // create some global objects to test save
   //=======================================================================
   private ABTValue createNewGlobal(String type, IABTObject site)throws ABTException
   {
     	IABTHashTable parms = (IABTHashTable)new ABTHashTable();

      // create a new object
      System.out.println("\nCreating new object " + type);
     	parms.putItemByString(OFD_SITE, (ABTValue)site);
   	ABTValue val = space_.createNewObject(type, parms);
      // if error, return
   	if (ABTError.isError(val))
         return null;

   	IABTObject obj = (IABTObject) val;

      // create some custom enums and agg fields for custom fields
      if (type.equals(OBJ_CUSTOMFIELD))
      {
         System.out.println("\nCreating new custom enum...");
      	parms.putItemByString(OFD_CUSTOMFIELD, (ABTValue) obj);
      	val = space_.createNewObject(OBJ_CUSTOMENUM, parms);
      	if (ABTError.isError(val))         return null;

         System.out.println("\nCreating new aggregate field...");
         val = space_.getObjects(OBJ_CUSTOMFIELD);
      	if (ABTError.isError(val))         return null;
         parms.clear();
      	parms.putItemByString(OFD_TARGETFIELD, (ABTValue)((IABTObjectSet)val).at(0));
      	parms.putItemByString(OFD_SOURCEFIELD, (ABTValue)obj);
      	val = space_.createNewObject(OBJ_AGGREGATEFIELD, parms);
      	if (ABTError.isError(val))         return null;

         System.out.println(" ");
      }
      propertyPrint(site,type);
      return (ABTValue)obj;
   }



   //=======================================================================
   // create some tasks to test the save logic
   //=======================================================================
   private ABTError createNewTasks(IABTObject method)
   {
      // create some new task to test save()
      System.out.println("\nCreating new task...");
    	IABTHashTable parms = (IABTHashTable)new ABTHashTable();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	ABTValue val = space_.createNewObject(OBJ_MM_TASK, parms);
      // if error, return
   	if (ABTError.isError(val))         return (ABTError)val;

     	IABTObject task1 = (IABTObject) val;
      val = task1.setValue(OFD_EXTERNALID, new ABTString(" "));
   	if (ABTError.isError(val))         return (ABTError)val;

   	val = space_.createNewObject(OBJ_MM_TASK, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject task2 = (IABTObject) val;
      val = task2.setValue(OFD_EXTERNALID, new ABTString("  "));
   	if (ABTError.isError(val))         return (ABTError)val;

      // create some dependencies
      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task1);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task2);

      System.out.println("\nCreating new dependency...");
   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

      if (val instanceof IABTObject)
         ((IABTObject)val).delete();

      parms.clear();
   	parms.putItemByString(OFD_PREDTASK, (ABTValue)task2);
   	parms.putItemByString(OFD_SUCCTASK, (ABTValue)task1);

      System.out.println("\nRecreating dependency...");
   	val = space_.createNewObject(OBJ_MM_DEPENDENCY, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;


      // create some deliverables
      System.out.println("\nCreating new deliverables...");
    	parms.clear();
   	parms.putItemByString(OFD_METHOD, (ABTValue)method);

   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
      // if error, return
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject deliv1 = (IABTObject) val;

   	val = space_.createNewObject(OBJ_MM_DELIVERABLE, parms);
   	if (ABTError.isError(val))
         return (ABTError)val;

     	IABTObject deliv2 = (IABTObject) val;

/*
      // create some task-deliv links
     	val = task1.getValue(OFD_DELIVERABLES);
   	if (ABTError.isError(val))            	   return (ABTError)val;
   	if (val instanceof IABTObjectSet)
   	{
         System.out.println("\nLinking deliverables to a task...");
   	   IABTObjectSet set = (IABTObjectSet) val;
      	set.add(deliv1);
     	   set.add(deliv2);
      	val = task1.setValue(OFD_DELIVERABLES, (ABTValue) set);
      	if (ABTError.isError(val))            	   return (ABTError)val;
   	}
*/
      return null;
   }

   private void propertyPrint(IABTObject obj, String objType) throws ABTException
   {

          IABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.getElements();
          pStr.println(objType + ":");
          for (int Count = 0; Count < Props.countProperties(); Count++)
          {

              IABTProperty pass =   (IABTProperty) e.nextElement();
              String Caption = pass.getCaption();
              String Name = pass.getName();
              ABTValue  one_ = obj.getValue(Name);
              if (ABTError.isError(one_)) throw new ABTException(((ABTError)one_).getMessage());
              if (ABTValue.isNull(one_)){

                pStr.println(Name + " is NULL. Can't determine property type.");

                continue;
              }
              int type = pass.getType();

//add an "x" to all strings, to check saving of mods in obj space
//              if (type == 1)  //it's a string  PROP_STRING
//                  obj.setValue(Name, new ABTString("newPropValue"));
//              System.out.println(Caption + "            " + Name + ": " +  one_);
            int propType = pass.getType();

            switch (propType)

              {
                case PROP_INT:
                       pStr.println(Caption + "            " + Name + ": " +  one_ +"  (Integer) " + one_.intValue());
                       break;
                    case PROP_STRING:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  String  " + one_.stringValue());
                       break;
                    case PROP_OBJECT:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  Object  ");
                       break;
                    case PROP_OBJECTSET:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  ObjectSet");
                       break;
                    case PROP_LONG:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + " Long " + one_.intValue());
                       break;
                    case PROP_BOOLEAN:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  Boolean  " + one_.booleanValue());
                       break;
                    case PROP_DOUBLE:
                     pStr.println(Caption + "            " + Name + ": " +   one_  + "  Double  " + one_.doubleValue());
                       break;
                    case PROP_DATE:
                     pStr.println(Caption + "            " + Name + ": " +  one_ +  one_ + "  Date");
                       break;
                    case PROP_TIME:
                     pStr.println(Caption + "            " + Name + ": "+  one_ + "  Time  " + one_.timeValue());
                       break;
                    case PROP_TIMESTAMP:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  TimeStamp ");
                       break;
                    case PROP_BLOB:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  Blob ");
                       break;
                    case PROP_SHORT:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  Short  " + one_.shortValue());
                       break;
                    case PROP_ID:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  Remote ID ");
                        break;
                    case PROP_UNKNOWN:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + "  Unknown");

                    default:
                     pStr.println(Caption + "            " + Name + ": " +  one_ + " Default");
                       break;
               }

      }
        

   }

   private void propertyScreen(IABTObject obj, String objType) throws ABTException
   {


          IABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.getElements();
          System.out.println(objType + ":");
          for (int Count = 0; Count < Props.countProperties(); Count++)
          {

              IABTProperty pass =   (IABTProperty) e.nextElement();
              String Caption = pass.getCaption();
              String Name = pass.getName();
              ABTValue  one_ = obj.getValue(Name);
              if (ABTError.isError(one_)) throw new ABTException(((ABTError)one_).getMessage());
              if (ABTValue.isNull(one_)){

                System.out.println(Name + " is NULL. Can't determine property type.");

                continue;
              }
              int type = pass.getType();

//add an "x" to all strings, to check saving of mods in obj space
//              if (type == 1)  //it's a string  PROP_STRING
//                  obj.setValue(Name, new ABTString("newPropValue"));
//              System.out.println(Caption + "            " + Name + ": " +  one_);
            int propType = pass.getType();

            switch (propType)

              {
                case PROP_INT:
                       System.out.println(Caption + "            " + Name + ": " +  one_ +"  (Integer) " + one_.intValue());
                       break;
                    case PROP_STRING:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  String  " + one_.stringValue());
                       break;
                    case PROP_OBJECT:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  Object  ");
                       break;
                    case PROP_OBJECTSET:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  ObjectSet");
                       break;
                    case PROP_LONG:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + " Long " + one_.intValue());
                       break;
                    case PROP_BOOLEAN:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  Boolean  " + one_.booleanValue());
                       break;
                    case PROP_DOUBLE:
                     System.out.println(Caption + "            " + Name + ": " +   one_  + "  Double  " + one_.doubleValue());
                       break;
                    case PROP_DATE:
                     System.out.println(Caption + "            " + Name + ": " +  one_ +  one_ + "  Date");
                       break;
                    case PROP_TIME:
                     System.out.println(Caption + "            " + Name + ": "+  one_ + "  Time  " + one_.timeValue());
                       break;
                    case PROP_TIMESTAMP:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  TimeStamp ");
                       break;
                    case PROP_BLOB:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  Blob ");
                       break;
                    case PROP_SHORT:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  Short  " + one_.shortValue());
                       break;
                    case PROP_ID:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  Remote ID ");
                        break;
                    case PROP_UNKNOWN:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + "  Unknown");

                    default:
                     System.out.println(Caption + "            " + Name + ": " +  one_ + " Default");
                       break;
               }

      }
        

   }

   private void processError(ABTError err)
   {
      System.out.println("\nERROR OCCURRED!!!");
      System.out.println("  Code: " + err.getCode());
      System.out.println("  Component: " + err.getComponent());
      System.out.println("  Module: " + err.getMethod());
      System.out.println("  Message: " + err.getMessage());
      System.out.println("  Info: " + err.getInfo().toString());
   }

   public static void main(String args[])
   {
      LeeAPI app = new LeeAPI(args);
      app.run();
   }

}