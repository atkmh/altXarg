package TestLib;
import java.io.*;
import java.util.Date;

// This object is intended for logging results
// to an ASCII text file when running Java test code.
// A separate log file is created for all "FAIL" messages
// This object contains methods to:
// Create and replace ASCII text file (Results File)
// Write Messages to ASCII text Results File
// Write and Display Messages to ASCII text Results File 
// Log the different message Types currently stored in
// interface file ILogType
// Accumulate exposed Total variables for PASS and FAIL
// which the Java tester can access
// (AVP - 7/26 - currently only totaling PASS and FAIL)
// TODO:  Error and exception handling
// TODO:  Set diagnostics level 
// AVP 1/4/99: Added all "COMMENT"'s to failure log as well, so easier to follow
public class LogFile extends Object implements ILogType
{
	private FileOutputStream ResultsFileOut = null;
	private FileOutputStream FailFileOut = null;
	private PrintStream ResultsFilePrint = null;
	private PrintStream FailFilePrint = null;
	private int 
	    TotalFailures = 0,
	    TotalPass = 0;
	
	// LogFile Constructor
	// This method will instantiate the Java objects which will create the actual text log files 
	// Parameters:
	//          String strFileName - Name for log file (Results File)
	//          boolean VerifyExistence - Flag to notify user when overwriting Results File
	//          boolean LogFailure - Flag to log Failures twice - once in Results File,
	//                               and again in separate FAIL log file
	public LogFile(String strFileName, boolean boolVerifyExistence, boolean boolLogFailure) throws IOException
	{
	    File
	        ResultsFile = null,
	        FailFile = null;
	        
	    // Create Log file with specified strFileName, append .log if no extension
		// Create separate Log file for FAIL messages
	    if (-1 == strFileName.indexOf("."))
	    {
    		ResultsFile = new File(strFileName + ".log");
      		FailFile = new File(strFileName + "FAIL" + ".log");
        } else {   		
    		ResultsFile = new File(strFileName);
      		FailFile = new File("FAIL" + strFileName);
        }    		
        // Verification message string
		String VerifyFileMessage = null;
		// Initialize global variables
        FailFileOut = null;		    
        TotalFailures = 0;
        TotalPass = 0;
        // PROCESS RESULTS FILE
		// Check if the Results file exists
		// If so flagged, display to user before deleting
   		if (true == ResultsFile.exists()) 
   		{
            if (true == boolVerifyExistence) 
            {
    		    System.out.println(strFileName+" already exists and will be overwritten when you press ENTER!");
        	    System.in.read();
            } // end if VerifyExistence        	    
	   		ResultsFile.delete();
        }
        // Instantiate Java objects for writing to ASCII text file
		ResultsFileOut = new FileOutputStream(ResultsFile);
		ResultsFilePrint = new PrintStream(ResultsFileOut);
		// PROCESS FAIL FILE
		// Check if the Fail file exists
		// If so flagged, display to user before deleting
		if (true == boolLogFailure)
		{
       		if (true == FailFile.exists()) 
       		{
                if (boolVerifyExistence) 
                {
        		    System.out.println(strFileName+"FAIL" + " already exists and will be overwritten when you press ENTER!");
            	    System.in.read();
                } // end if VerifyExistence        	    
    	   		FailFile.delete();
            }
    		FailFileOut = new FileOutputStream(FailFile);
    		FailFilePrint = new PrintStream(FailFileOut);
        } // end if Log Failure
	 } // LogFile constructor

     // First overriden method    
     // This method will display the results message
     // before calling local method LogWrite 
     // Parameters:
     //             String strLogType - message type - should match entry in ILogType interface
     //             String strMsg - contents of message to be displayed and logged
	 public void LogDisplay(String strLogType, String strMsg) {
// AVP - 7/26 - currently not using TranslateLogType
//	    System.out.println(TranslateLogType(strLogType) + ": " + strMsg);
	    System.out.println(strLogType + ": " + strMsg);
	    LogWrite(strLogType, strMsg);
     } // LogDisplay(1) 

     // Second overriden method
     // This method will display the results message
     // before calling local method LogWrite 
     // WITHOUT Time Stamp or FAIL/PASS comment imbedded in message (no formatting - print as is)
     // Parameters:
     //             String strMsg - contents of message to be displayed and logged
	 public void LogDisplay(String strMsg) {
	    System.out.println(strMsg);
        // Write message to Results File		    
		ResultsFilePrint.println(strMsg);
     } // LogDisplay(2) 

     // This method will:
     //     Write the message to the Results log file
     //     Date/time stamp will be prefixed to the message logged to file
     //     If Fail log file has been created in constructor,
     //     will write any FAIL message to the FAIL log file
     //     Accumulate total PASS and FAIL messges
     // AVP 1/4/99: Added all "COMMENT"'s to failure log as well, so easier to follow
	 public void LogWrite(String strLogType, String strMsg)
	 {
	    Date 
	        CurrentTime = new Date();
// AVP - 7/26 - currently not using TranslateLogType
//		String strFinalMsg = CurrentTime.toLocaleString()+":"+TranslateLogType(strLogType)+":"+" "+strMsg;
		String 
		    strFinalMsg = CurrentTime.toLocaleString()+":"+strLogType+":"+" "+strMsg;
        // Accumulate FAIL messages	    
		if (strLogType == ILogType.FAIL)
		    TotalFailures++;
        // Accumulate PASS messages		    
		if (strLogType == ILogType.PASS)
		    TotalPass++;
        // Write message to Results File		    
		ResultsFilePrint.println(strFinalMsg);
		// if FAIL message, and FAIL file has been created, write message
        // AVP 1/4/99: Added all "COMMENT"'s to failure log as well, so easier to follow
		if ((strLogType == ILogType.FAIL) || (strLogType == ILogType.COMMENT))
		{
            if (FailFileOut != null) 
        	    FailFilePrint.println(strFinalMsg);
        } 
	 } // LogWrite
	 
	 // This method will display and log the total FAIL and PASS so far
	 public void LogTotals()
	 {
	    LogDisplay(ILogType.COMMENT,"Totals so far: FAIL = " + TotalFailures + ", PASS = " + TotalPass);
     } // LogTotals	    

/* AVP - 7/26 - NO LONGER USED	 
Interface now contains String representation of each message type
     private String TranslateLogType(int intLogType)
     {
		 switch (intLogType)
         {
			 case ILogType.COMMENT: return "COMMENT";
		     case ILogType.DEBUG:   return "DEBUG";
			 case ILogType.FAIL:    return "FAIL";
			 case ILogType.PASS:    return "PASS";
			 default: return "Undefined message type!";		  
         }
     }
*/     

    // Close files during garbage collection
    // (when log files are out of scope)
	protected void finalize()
	{
		try{ 
		    if (ResultsFileOut != null)
		    {
			    ResultsFileOut.close();          
            }			    
			if (FailFileOut != null) 
			{
			    FailFileOut.close();
            }			    
		} catch (IOException e){
			System.out.println("ERROR: Cannot close the LOG file.");
		}
	}
} // LogFile
		 
		     		 


	  	 	  
			     
		  


