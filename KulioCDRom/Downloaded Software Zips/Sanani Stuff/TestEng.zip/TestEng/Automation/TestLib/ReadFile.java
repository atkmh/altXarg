package TestLib;
import java.io.*;

// This object is intended for reading a pre-existing 
// ASCII text file when running Java test code.
// This object contains methods to:
// Create and replace ASCII text file (Results File)
// Write Messages to ASCII text Results File
// Write and Display Messages to ASCII text Results File 
// Log the different message Types currently stored in
// interface file ILogType
// Accumulate exposed Total variables for PASS and FAIL
// which the Java tester can access
// (AVP - 7/26 - currently only totaling PASS and FAIL)
// TODO:  Error and exception handling
// TODO:  Set diagnostics level 
public class ReadFile extends Object 
{
	private FileInputStream FileIn;
	private String FileName;
	private int ReadValue = ' ';

    // Constructor
    // Instantiates Java object to open text file for reading
    // Parameters:
    //          String strFileName - name of text file to read
	public ReadFile(String strFileName) throws IOException 
	{
	    // initialize global variables
		ReadValue = ' ';
	    FileName = strFileName;
	    FileIn = null;
	    // Instantiate object for specified Text file to be read
		FileIn = new FileInputStream(strFileName);
    } // ReadFile constructor

    // Read text file up until a specified string StopString is reached
    // (read to END of the specified StopString)
    // Parameters:
    //          String StopString - text to match which will stop read
    public boolean ReadFileTo(String StopString) throws IOException 
    {
        int
            CompareCtr = 0;

        do  {  
            // if we've read to end of StopString, with perfect match,
            // stop now, and return success
            if (CompareCtr >= StopString.length()) 
                return true;
            // If we've matched 1 character, move to next for comparison                
            if ((char)ReadValue == StopString.charAt(CompareCtr))
                CompareCtr++;
            else
                CompareCtr = 0;
        } while ((ReadValue = FileIn.read()) != -1); // end while read() 
        
        // Never did read the full StopString, so return failure
        return false;
    } // ReadFileTo

    // This method will:
    // read to StopString (as in ReadFileTo above)
    // store all bytes (up until StopString) into a String Buffer 
    // then return String Buffer as String
    public String ReadFileToString(String StopString) throws IOException 
    {
        StringBuffer StoreString = new StringBuffer(0);
        int
            CompareCtr = 0;

       do  { // while reading valid byte from file
            // if we've read to end of StopString, with perfect match,
            // stop now and return String Buffer of all bytes read
            // before StopString
            if (CompareCtr >= StopString.length()) {
                // remove StopString from this buffer
                StoreString.setLength(StoreString.length() - CompareCtr);
                return (new String(StoreString));
            }                
            // append each character we've read
            StoreString.append((char)ReadValue);
            // If we've matched 1 character, move to next for comparison                
            if ((char)ReadValue == StopString.charAt(CompareCtr))
                CompareCtr++;
            else 
                CompareCtr = 0;
        }  while ((ReadValue = FileIn.read()) != -1); // end while read()
        
        // Never did read the full StopString, so return null
        return null; 
    } // ReadFileToString

    // Perform during garbage collection, when objects are out of scope
	protected void finalize()
	{
        if (FileIn != null)
            try {
    			FileIn.close();
    		} catch (IOException e){
    			System.out.println("ERROR: Cannot close the file " + FileName);
    		}
	} // finalize
	
} // ReadFile









