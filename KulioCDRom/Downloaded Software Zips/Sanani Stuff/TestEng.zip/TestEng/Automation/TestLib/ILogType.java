// This package is intended for use by Java testers 
// AVP - 7/26 - currently contains: 
//  LogFile
//  ReadFile
package TestLib;

// This interface is used to store a string representation
// of the different message types logged to a testing results log file
public interface ILogType  {
    public static final String 
        COMMENT = "COMMENT",
        DEBUG = "DEBUG",
    	FAIL = "FAIL",
    	PASS = "PASS";
}
