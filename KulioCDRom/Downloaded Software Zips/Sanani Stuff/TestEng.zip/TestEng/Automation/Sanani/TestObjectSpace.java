import java.util.Enumeration;

import com.abtcorp.io.*;
import com.abtcorp.repository.*;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.parser.*;

import java.util.Enumeration;

public class TestObjectSpace implements LogType
{
   ABTObjectSpace CurrentSpace; 
   LogFile CurrentLog;
   
       
   public TestObjectSpace(ABTObjectSpace space, LogFile log) throws ABTException
   {
      CurrentSpace = space;
      CurrentLog = log;
   }
   
   public ABTValue populate (String whatever)
   {
      CurrentLog.LogWrite(COMMENT,"STARTING populate method in TestObjectSpace");
      int numberTasks = 10;
      int numberProjects = 5;
      //create a set of projects

    //  CurrentSpace.setRulebase("com.abtcorp.rulebase");
      ABTObjectSet projects = test_createSimpleProject(CurrentSpace,null,null,numberProjects,numberTasks);
     
      //test parsing
      test_parser( CurrentSpace, projects );
//      benchmark.stop();

      //test parsing
      test_parser4( CurrentSpace, projects );
  //    benchmark.stop();

      //test integrated parsing
      test_parser_integrated(CurrentSpace,projects);
    //  benchmark.stop();
      
      //resort the projects
      test_resortProjects(CurrentSpace,projects,"PRID",2);
//      benchmark.stop();

      //print out the result (without the tasks)
      test_printProjects(projects,10,0);
//      benchmark.stop();

      
      //test Steve's rules....
//      test_StevesRules(CurrentSpace,projects);
  //    benchmark.stop();
      

      //test an invalid object
      test_ErrorInvalidObject(CurrentSpace);
//      benchmark.stop();

      // test dump
      // test_dump(CurrentSpace,projects);
      // benchmark.stop();
      
      CurrentLog.LogDisplay(COMMENT,"Testing done");
      
      return projects;
   }    


/*   public void test_StevesRules(ABTObjectSpace space, ABTObjectSet projects)
   {
      // Steve P. has implemented (and I extended) some funny rules in the ABTTaskHajo rule definition
      // showing the use of a virtual field (i.e. "prBiteMe"), a "protected" field
      // (i.e. "prBiteYou") and a non-existing field 

      System.out.println("Start testing special rules....");
      // start out by getting to one task
      if ((projects == null) || (projects.size() < 1))
      {
         // whoops, no projects..... stop just here
         System.out.println("Sorry, can't run test without projects");
         return;
      }
      ABTObject aProject = (ABTObject)(projects.at(0));
      // let's just say that was successfull
      // get the childtasks
      ABTValue val  = aProject.getValue("PRCHILDTASKS");
      if (ABTError.isError(val))
      {
         System.out.println("ERROR in retrieving child tasks!");
         System.out.println( ((ABTError)val).getMessage());
         return;
      }

      
      if ((val == null) || (((ABTObjectSet)val).size() < 1))
      {
         // whoops, no projects..... stop just here
         System.out.println("Sorry, can't run test without childtasks");
         return;
      }
      
      ABTObject task = (ABTObject) ((ABTObjectSet)val).at(0);
      // let's just say that was successfull
      System.out.println("Get Steve's special field");
      
      ABTValue a4 = task.getValue("prBiteMe");
      if ( ABTError.isError(a4))
         System.out.println("Error in retrieving field prBiteYou :" + ((ABTError)a4).getMessage());      
      else
         System.out.println("Value for >prBiteMe< = " + a4.toString());

      a4 = task.getValue("prBiteYou");
      if ( ABTError.isError(a4))
         System.out.println("Error in retrieving field prBiteYou :" + ((ABTError)a4).getMessage());      
      else
         System.out.println("Value for >prBiteYou< = " + a4.toString());

      System.out.println("Get a field which doesn't exist");
      a4 = task.getValue("Steve");
      if ( ABTError.isError(a4))
         System.out.println("Error in retrieving field >Steve< :" + ((ABTError)a4).getMessage());      
      else
         System.out.println("Value for >Steve< = " + a4.toString());      

      System.out.println("Done testing special rules....");
   }

*/
   public void test_ErrorInvalidObject(ABTObjectSpace space)
   {
      System.out.println("Test create an invalid object type....");  

      ABTValue val = space.createObjectSet("ABTSteve");
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");
         System.out.println( ((ABTError)val).getMessage());
      }         
     
      System.out.println("Test for Error successfull");  
 
   }


   public ABTObjectSet test_createSimpleProject(ABTObjectSpace space,String useExtension, String useClassPath,int numberProjects,int numberTasks)
   {

   // set the new extension for ABTObject and ABTObjectSet...
   // e.g. COM , RMI or null if default
   // so the objectspace is now trying to instantiate ABTObjectXXX and ABTObjectSetXXX
      if (useExtension != null)
         space.setExtension(useExtension);
   // Tell the objectspace where to find ABTObjectXXX and ABTObjectSetXXX - class files
   // e.g. "com.abtcorp.io", "com.abtcorp.rulebase" or null for default
      if (useClassPath != null)
         space.setObjectPath(useClassPath);

   // local handle for results
      ABTValue object = null;

      System.out.println("Building " + numberProjects + " Projects");

   //create additional properties
//      ABTPropertySet ps = new ABTPropertySet();
//
//      ps.add(new ABTProperty("SteveP",ABTProperty.PROP_STRING));
//      ps.add(new ABTProperty("Hajo",ABTProperty.PROP_STRING));

      ABTError testError = CurrentSpace.addProperty
                                 (  "ABTProjectHajo",
                                    "SteveP",
                                    "Steves personal field",
                                 ABTProperty.PROP_STRING,
                                 false,
                                 true,
                                 true,
                                 true, //transient
                                 null,
                                 null,
                                 null
                                 );
      System.out.println("Finished testError");                                 

      ABTError testError2 = CurrentSpace.addProperty
                                 (  "ABTProjectHajo",
                                    "Hajo",
                                    "Hajos personal field",
                                 ABTProperty.PROP_STRING,
                                 false,
                                 true,
                                 true,
                                 true, // transient
                                 null,
                                 null,
                                 null
                                 );

      System.out.println("Finished testError2");                                 

   // create a container for the projects to be created
   // pass in the name/type of the objects (i.e. the name of the rule-file)
   // and the path to the class file for the rule (or null if default)
      ABTValue val = space.createObjectSet("ABTProjectHajo");
   // check for error
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");
         // see ABTError for all the possibilities...
         System.out.println( ((ABTError)val).getMessage());
         return null;
      }
   // not an error so cast the ABTValue to an ObjectSet-handle
      ABTObjectSet oSetProjects = (ABTObjectSet)val;

   // simple loop to create multiple objects
      for (int i = 0;i < numberProjects;i++)
      {
         // create a remote id (e.g. ABTRemoteIDRepository, ABTRemoteIDInteger...)
         ABTRemoteIDInteger id =  new ABTRemoteIDInteger(numberProjects - i);
         // call objectspace to create a new instance
         // pass in the name/type of the objects (i.e. the name of the rule-file)
         // the remoteID if applicable (meaning if you are in an application you would
         // pass null instead....
         // and the path to the class file for the rule (or null if default)
         object = space.createObject("ABTProjectHajo",id);
         // check for error
         if (ABTError.isError(object))
            System.out.println("Failed to create ABTProject in object space: " + ((ABTError)object).getMessage());
         else
         {

            // test for empty value
            ABTValue val2 =  ((ABTObject)object).getValue("PRID");
            if (ABTError.isError(val2))
               System.out.println("Failed to access field PRID " + ((ABTError)val2).getMessage());
            if (ABTValue.isEmpty(val2))
               System.out.println("field PRID is empty");

            // set a few values for properties - valid properties are defined
            // via the rule, so in this case check for ABTProjectXXX.java to find
            // the appropriate properties

            ((ABTObject)object).setValue("PRID",new ABTInteger(i));
            // explicit vs. implicit casting
            ABTObject abtObject = (ABTObject)object;
            abtObject.setValue("PRNAME",new ABTString("Project" + i));

            abtObject.setValue("SteveP",new ABTString("Test Value " + i ));

            // one of the properties in our ABTProject is CHILDTASKS,
            // so now we create the objectset holding the childtasks
            ABTObjectSet oSetTask;
            if (i == 1)
                oSetTask = test_createSimpleTask(space,useExtension, useClassPath,-1, 1000);
            else
                oSetTask = test_createSimpleTask(space,useExtension, useClassPath,numberTasks, (i)*50);

            // the result is used like any other ABTValue....
            abtObject.setValue("PRCHILDTASKS",oSetTask);

            // add the filled out ABTObject to the ABTObjectSet
            oSetProjects.add(abtObject);
         } // end no error
         System.out.println("Done building " + i + " of " + numberProjects + " Projects");
      } // next i
      System.out.println("Done building " + numberProjects + " Projects");

      return oSetProjects;
   }

   public void test_logic_Projects(ABTObjectSet projects)
   {
      // create a new HashTABLE for variables
      ABTHashtable myHash = new ABTHashtable();
      //create dynamic variable
//      ABTDynamicValue dyn = new ABTDynamicValue(myHash,"Project","PRNAME");
      
   }
   
   public void test_printProjects(ABTObjectSet projects,int max_print,int max_print_childtasks)
   {
      //simple loop based through the project
      for (int i = 0;i < (projects.size() > max_print ? max_print:projects.size());i++)
      {
         // abolute index-access better be in correct bounds - otherwise
         // there will be an array-out-of-bounds exception
         ABTObject object = (ABTObject)projects.at(i);

         printOneProject(object,max_print_childtasks);

      }


   }

   public void printOneProject(ABTObject object, int max_print_childtasks)
   {

               //retrieve the values
         ABTValue a1 = ((ABTObject)object).getValue("PRID");
         //check for error
         if (ABTError.isError(a1))
         {
            System.out.println("ERROR in retrieving PRID!");
            System.out.println( ((ABTError)a1).getMessage());
         }
         ABTValue a2 = ((ABTObject)object).getValue("PRNAME");
         if (ABTError.isError(a2))
         {
            System.out.println("ERROR in retrieving PRNAME!");
            System.out.println( ((ABTError)a2).getMessage());
         }

         ABTValue a2b = ((ABTObject)object).getValue("SteveP");
         if (ABTError.isError(a2b))
         {
            System.out.println("ERROR in retrieving PRNAME!");
            System.out.println( ((ABTError)a2b).getMessage());
         }

         System.out.println("PRID = " + a1.toString() + "... PRName = " + a2.toString() + " .. with Steve's field " + a2b.toString());

         ABTValue a3 = ((ABTObject)object).getValue("PRCHILDTASKS");
         if (ABTError.isError(a3))
         {
            System.out.println("ERROR in retrieving child tasks!");
            System.out.println( ((ABTError)a3).getMessage());
         }
         else
            if (max_print_childtasks>0)
            // call the print routine for tasks with the ABTValue casted to an objectset
               test_printTasks((ABTObjectSet)a3,max_print_childtasks,5);

   }
   

   public void test_printTasks(ABTObjectSet tasks,int max_print, int indent)
   {
      String s = new String("");
      for (int j = 0; j<=indent;j++)
         s = s + " ";
         
      //simple loop based through the project
      for (int i = 0;i < (tasks.size() > max_print ? max_print:tasks.size());i++) 
      {
            ABTObject object = (ABTObject)tasks.at(i);
            ABTValue a1b = object.getValue("PRID");
            ABTValue a2b = object.getValue("PRNAME");
            ABTValue a3b = object.getValue("PRTASKNAME");
            System.out.println(s = "PRID = " + a1b.toString() + "... PRName = " + a2b.toString() + "... PRTaskName = " + a3b.toString());
      }//next i
   }
   


public void test_resortProjects(ABTObjectSpace space,ABTObjectSet projects,String fieldname,int max_print_childtasks)
   {
      System.out.println("Change sortorder on " + fieldname);  
      // get the existing one
      ABTSortOrderDefinition sOrder = projects.getSortOrder();
      //add another field to the sort order (name of field, ascending=true)
      sOrder.add(fieldname,false);
      
      Enumeration e;
      e = projects.sortedElements(sOrder);
      while (e.hasMoreElements())
      {
         // abolute index-access better be in correct bounds - otherwise
         // there will be an array-out-of-bounds exception
         ABTValue v1 = (ABTValue) e.nextElement();
         if (ABTError.isError(v1))
         {
            // whoops
         }
         else
         {
             ABTObject o = (ABTObject)v1;
             printOneProject(o,max_print_childtasks);

         }
         
      }



      System.out.println("Done change sortorder on " + fieldname);  
      System.out.println("Show it again unsorted ");
      Enumeration e2;
      e2 = projects.elements();
      while (e2.hasMoreElements())
      {
         // abolute index-access better be in correct bounds - otherwise
         // there will be an array-out-of-bounds exception
         ABTValue v2 = (ABTValue) e2.nextElement();
         if (ABTError.isError(v2))
         {
            // whoops
         }
         else
         {
             ABTObject o2 = (ABTObject)v2;
             printOneProject(o2,max_print_childtasks);

         }
         
      }
      System.out.println("Done showing unsorted");  
      

   }



   public ABTObjectSet test_createSimpleTask(ABTObjectSpace space,String useExtension, String useClassPath,int numberTasks, int id_offset)
   {

   // set the new extension for ABTObject and ABTObjectSet...
   // e.g. COM , RMI or null if default
   // so the objectspace is now trying to instantiate ABTObjectXXX and ABTObjectSetXXX
      if (useExtension != null)
         space.setExtension(useExtension);
   // Tell the objectspace where to find ABTObjectXXX and ABTObjectSetXXX - class files
   // e.g. "com.abtcorp.io", "com.abtcorp.rulebase" or null for default
      if (useClassPath != null)
         space.setObjectPath(useClassPath);

   // local handle for results
      ABTValue object = null;

      System.out.println("Building " + numberTasks + " Tasks");

   // create a container for the Tasks to be created
   // pass in the name/type of the objects (i.e. the name of the rule-file)
   // and the path to the class file for the rule (or null if default)
      ABTValue val = space.createObjectSet("ABTTaskHajo");
   // check for error
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");
         // see ABTError for all the possibilities...
         System.out.println( ((ABTError)val).getMessage());
         return null;
      }
   // not an error so cast the ABTValue to an ObjectSet-handle
      ABTObjectSet oSetTasks = (ABTObjectSet)val;

    if (numberTasks < 0)
    {
        // create a remote id (e.g. ABTRemoteIDRepository, ABTRemoteIDInteger...)
        ABTRemoteIDInteger id =  new ABTRemoteIDInteger(id_offset + 9999);
        // call objectspace to create a new instance
        // pass in the name/type of the objects (i.e. the name of the rule-file)
        // the remoteID if applicable (meaning if you are in an application you would
        // pass null instead....
        // and the path to the class file for the rule (or null if default)
         object = space.createObject("ABTTaskHajo",id);
         // check for error
         if (ABTError.isError(object))
            System.out.println("Failed to create ABTTaskHajo in object space: " + ((ABTError)object).getMessage());
         else
         {
            // set a few values for properties - valid properties are defined
            // via the rule, so in this case check for ABTTaskHajoXXX.java to find
            // the appropriate properties

            ((ABTObject)object).setValue("PRID",new ABTInteger(id_offset * 9999));
            // explicit vs. implicit casting
            ABTObject abtObject = (ABTObject)object;
            abtObject.setValue("PRNAME",new ABTString("Task" + (id_offset + 999)));
            abtObject.setValue(
                              "PRTASKNAME",
                              new ABTString("TaskName" + id_offset +  9999)
                               );

            // add the filled out ABTObject to the ABTObjectSet
            oSetTasks.add(abtObject);
         } // end no error
    }
    else
    {
   // simple loop to create multiple objects
      for (int i = 0;i < numberTasks;i++)
      {
        // create a remote id (e.g. ABTRemoteIDRepository, ABTRemoteIDInteger...)
        ABTRemoteIDInteger id =  new ABTRemoteIDInteger(id_offset + numberTasks - i);
        // call objectspace to create a new instance
        // pass in the name/type of the objects (i.e. the name of the rule-file)
        // the remoteID if applicable (meaning if you are in an application you would
        // pass null instead....
        // and the path to the class file for the rule (or null if default)
         object = space.createObject("ABTTaskHajo",id);
         // check for error
         if (ABTError.isError(object))
            System.out.println("Failed to create ABTTaskHajo in object space: " + ((ABTError)object).getMessage());
         else
         {
            // set a few values for properties - valid properties are defined
            // via the rule, so in this case check for ABTTaskHajoXXX.java to find
            // the appropriate properties

            ((ABTObject)object).setValue("PRID",new ABTInteger(id_offset +  i));
            // explicit vs. implicit casting
            ABTObject abtObject = (ABTObject)object;
            abtObject.setValue("PRNAME",new ABTString("Task" + (id_offset +  i)));
            abtObject.setValue(
                              "PRTASKNAME",
                              new ABTString("TaskName" + (id_offset +  numberTasks - i))
                               );

            // add the filled out ABTObject to the ABTObjectSet
            oSetTasks.add(abtObject);
         } // end no error
//         System.out.println("Done building " + i + " of " + numberTasks + " Tasks");
      } // next i
    }
    System.out.println("Done building " + numberTasks + " Tasks");
    return oSetTasks;
   }




   public void test_parser( ABTObjectSpace space, ABTObjectSet projects )
   {
      int numhits = 0;
      int numtasks = 0;

      System.out.println( "Testing parser first test..." );

      ABTArray array = new ABTArray();
      VisitorExpression v = new VisitorExpression( array );

      ABTValue l;
      try
      { 
        l = v.parse( "exists( PRCHILDTASKS.PRNAME = 'Task1999' )"  );
      }
      catch( Exception e )
      {
         System.out.println("Parser Failed.");
         System.out.println( e.getMessage());
         e.printStackTrace();
         return;
      }

      ABTValue val = space.createObjectSet("ABTProjectHajo");
      /* check for error
      */
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");

         /* see ABTError for all the possibilities...
         */
         System.out.println( ((ABTError)val).getMessage());
         System.out.println("FAILED");
         return;
      }

      /* not an error so cast the ABTValue to an ObjectSet-handle
      */
      ABTObjectSet oSetTasks = (ABTObjectSet)val;

      Enumeration e = projects.elements();
      while( e.hasMoreElements() )
      {
         ABTValue value = (ABTValue)e.nextElement();
         if( !ABTError.isError( value ) )
         {
            ABTObject o = (ABTObject)value;
            if (array.size() > 0)
                array.put( 0, o );
            else
                array.add( o );

            numtasks++;
            if( l.booleanValue() )
            {
               oSetTasks.add( o );
               numhits++;
            }
         }
      }

      System.out.println("Done parsing ");
      test_printProjects( oSetTasks, 10, 10 );
      System.out.println( "There where " + numhits + " of " + numtasks + " childtasks matching the request" );
   }


public void test_parser_integrated( ABTObjectSpace space, ABTObjectSet projects )
   {
      int numhits = 0;
      int numtasks = 0;

      System.out.println( "Testing integrated .." );


      ABTValue val = projects.select("exists( PRCHILDTASKS.PRNAME = 'Task1999' ) or (PRID > 2 AND PRID < 4) ");
      /* check for error
      */
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");

         /* see ABTError for all the possibilities...
         */
         System.out.println( ((ABTError)val).getMessage());
         System.out.println("FAILED");
         return;
      }
   // not an error so cast the ABTValue to an ObjectSet-handle      
      numhits = ((ABTObjectSet)val).size();
      numtasks = projects.size();

      System.out.println("Done parsing ");


      test_printProjects( ((ABTObjectSet)val), 10, 10 );
      System.out.println( "There where " + numhits + " of " + numtasks + " childtasks matching the request" );
   }



public void test_dump( ABTObjectSpace space, ABTObjectSet projects )
   {
      ABTObject o = (ABTObject) projects.at(0);
      System.out.println(o.dump(0,1));
      
   }
public void test_parser4( ABTObjectSpace space, ABTObjectSet projects )
   {
      int numhits = 0;
      int numtasks = 0;

      System.out.println( "Testing parser again..." );

      ABTArray array = new ABTArray();
      VisitorExpression v = new VisitorExpression( array );

      ABTValue l;
      try
      { 
         l = v.parse( "all( PRCHILDTASKS.PRNAME = 'Task1999' )"  );
      }
      catch( Exception e )
      {
         System.out.println("Parser Failed.");
         System.out.println( e.getMessage());
         e.printStackTrace();
         return;
      }

      ABTValue val = space.createObjectSet("ABTProjectHajo");
      /* check for error
      */
      if (ABTError.isError(val))
      {
         System.out.println("ERROR!");

         /* see ABTError for all the possibilities...
         */
         System.out.println( ((ABTError)val).getMessage());
         System.out.println("FAILED");
         return;
      }
   // not an error so cast the ABTValue to an ObjectSet-handle      
      ABTObjectSet oSetTasks = (ABTObjectSet)val;

      /* not an error so cast the ABTValue to an ObjectSet-handle
      */

      Enumeration e = projects.elements();
      while( e.hasMoreElements() )
      {
         ABTValue value = (ABTValue)e.nextElement();
         if( !ABTError.isError( value ) )
         {
            ABTObject o = (ABTObject)value;
            if (array.size() > 0)
                array.put( 0, o );
            else
                array.add( o );
                

            numtasks++;
            if( l.booleanValue() )
            {
               oSetTasks.add( o );
               numhits++;
            }
         }
      }
      System.out.println("Done parsing ");


      test_printProjects( oSetTasks, 10, 10 );
      System.out.println( "There where " + numhits + " of " + numtasks + " childtasks matching the request" );
   }


}
