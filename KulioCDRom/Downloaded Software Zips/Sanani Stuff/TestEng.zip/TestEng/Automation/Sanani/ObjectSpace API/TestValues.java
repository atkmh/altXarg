import com.abtcorp.io.*;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.parser.*;
// AVP - 7/26 - TestEng "library" package - currently LogFile and ReadFile
import TestLib.*;
// No more rulebase package - AVP - 7/23
// import com.abtcorp.rulebase.*;

import java.util.Enumeration;
import java.util.Date;
import java.util.Calendar;
import java.util.Vector;
import java.lang.reflect.*;
import java.io.*;

// This class was created to facilitate testing of property values
// at ABTObject level
// ABTObject.setValue (4 overloaded methods)
// ABTObject.getValue (4 overloaded methods)
public class TestValues implements ILogType //, IABTMMRuleConstants
{
   ABTUserSession
        SessionID = null;
   // Object Space to be created
   ABTObjectSpace CurrentSpace = null;
   // For logging test results (diagnostics)
   LogFile CurrentLog = null;
   // counter for Current ABTObject, Current rule type, Remote ID
   int
       CurrentObjectPtr = 0,
       CurrentRulePtr = 0,
       CurrentRemoteID = 0,
       // special negative return value when no Index found
       // TODO:  should be pre-defined in interface
       NotIndex = -1;

   // Constructor
   // Parameters:
   //           LogFile log - Reference to logfile to record diagnostics
   public TestValues(LogFile log) throws ABTException
   {
        CurrentLog = log;
        CurrentRemoteID = 0;
   } // TestSessions constructor

   // This method sets the reference to the current SessionID
   // Parameters:
   //           ABTUserSession ThisSession - reference to ABTUserSession that has been opened
   public void setCurrentSession(ABTUserSession ThisSession)
   {
        SessionID = ThisSession;
   } // setCurrentSession

   // This method retrieves the reference to the current SessionID
   public ABTUserSession getCurrentSession()
   {
        return(SessionID);
   } // setCurrentSession

   // Call all local methods of TestSetValue to set value of all properties in 1 object
   // and verify those values via all local methods of TestGetValue
   // Parameters:
   //           ABTObject TestObject - reference to ABTObject whose properties should be set
   //           int StartingValue - value of first Property (will be incremented)
   public boolean SetVerifyValues(ABTObject TestObject, int StartingValue)
   {
        ABTPropertySet
            ReturnProperties = null;
        ABTProperty
            ThisProperty = null;
        boolean
            SetVerifyResult = false;

        CurrentLog.LogDisplay(COMMENT,"Testing set all Properties in 1 Object - starting value " + StartingValue);
        ReturnProperties = TestObject.getProperties();
        if (null == ReturnProperties)
        {
            CurrentLog.LogDisplay(FAIL,"getProperties for " + TestObject + " returned null");
            return false;
        }  else if (ReturnProperties instanceof ABTPropertySet)
        {
            CurrentLog.LogWrite(PASS,"getProperties for " + TestObject + " returned ABTPropertySet");
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"getProperties did not return null or ABTPropertySet");
            return false;
        } // end if-else for TestObject.getProperties
        // Loop through entire property set for a particular object
        // Set each property to incremental value (all were defaulted as integers)
        // If deleted flag is set, will cause all other sets/gets to fail,
        // since deleted objects no longer accessible
        for (int PropertyPtr = 0; PropertyPtr < ReturnProperties.size(); PropertyPtr++)
        {
            // AVP - 9/9/98 - test new property key PROP_KINTERNALUSE (via method isInternal)
            // this flag is set for properties whose values should not be directly set/get
            // (currently remote id and delete flag)
            ThisProperty = TestObject.getProperty(SessionID,PropertyPtr);
            if (ThisProperty != null)
            {
                if (false == ThisProperty.isInternal())
                {
                    SetVerifyResult = SetVerifyValue(TestObject,PropertyPtr,ReturnProperties.nameForIndex(PropertyPtr),null,new ABTInteger(PropertyPtr + StartingValue));
                    // When we hit failure, stop!  (this prevents trying multiple properties on deleted object)
                    if (false == SetVerifyResult)
                        break;
                }
            }                
        }

        return true;
   } // SetVerifyValues


   // Verify values of all Properties in 1 Object
   // via all local methods of TestGetValue
   // Parameters:
   //           ABTObject TestObject - reference to ABTObject whose properties have been set
   //           int StartingValue - value of first Property (will be incremented)
   public boolean GetVerifyValues(ABTObject TestObject, int StartingValue)
   {
        ABTPropertySet
            ReturnProperties = null;
        ABTProperty
            ThisProperty = null;
        boolean
            GetVerifyResult = false;

        CurrentLog.LogDisplay(COMMENT,"Testing get all Properties in 1 Object - starting value " + StartingValue);
        ReturnProperties = TestObject.getProperties();
        if (null == ReturnProperties)
        {
            CurrentLog.LogDisplay(FAIL,"getProperties for " + TestObject + " returned null");
            return false;
        }  else if (ReturnProperties instanceof ABTPropertySet)
        {
            CurrentLog.LogWrite(PASS,"getProperties for " + TestObject + " returned ABTPropertySet");
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"getProperties did not return null or ABTPropertySet");
            return false;
        } // end if-else for TestObject.getProperties

        // Loop through entire property set for a particular object
        // Verify each property's incremental value (all were defaulted as integers)
        // If deleted flag is set, will cause all other sets/gets to fail,
        // since deleted objects no longer accessible
        for (int PropertyPtr = 0; PropertyPtr < ReturnProperties.size(); PropertyPtr++)
        {
            // AVP - 9/9/98 - test new property key PROP_KINTERNALUSE (via method isInternal)
            // this flag is set for properties whose values should not be directly set/get
            // (currently remote id and delete flag)
            ThisProperty = TestObject.getProperty(SessionID,PropertyPtr);
            if (ThisProperty != null)
            {
                if (false == ThisProperty.isInternal())
                {
                    GetVerifyValue(TestObject,PropertyPtr,ReturnProperties.nameForIndex(PropertyPtr),null,new ABTInteger(PropertyPtr + StartingValue));
                    // When we hit failure, stop!  (this prevents trying multiple properties on deleted object)
                    if (false == GetVerifyResult)
                        break;
                }
            }                
        }

        return true;
   } // GetVerifyValues

   // Call all local methods of TestSetValue to set value of 1 property in 1 object
   // and verify those values via all local methods of TestGetValue
   // Parameters:
   //           ABTObject TestObject - reference to ABTObject whose properties should be set
   //           int PropertyIndex - numeric reference within PropertySet, to Property which will be changed
   //           String PropertyName - name attribute of Property which will be changed
   //           ABTHashTable Parameters - currently null
   //           ABTValue NewValue - value to which Property should be set
   public boolean SetVerifyValue(ABTObject TestObject, int PropertyIndex, String PropertyName, ABTHashtable Parameters, ABTValue NewValue)
   {
        ABTValue
            ReturnPropertyValue = null;
        boolean
            ReturnVerifyValue = true;

        CurrentLog.LogWrite(COMMENT,"Testing set Property #" + PropertyIndex + " to " + NewValue);
        // Numeric setValue without hashtable, verify with getValue
        ReturnPropertyValue = TestSetValue(TestObject,PropertyIndex,NewValue);
        // If failure on setvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        ReturnPropertyValue = TestGetValue(TestObject,PropertyIndex);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        // String setValue without hashtable, verify with getValue
        ReturnPropertyValue = TestSetValue(TestObject,PropertyName,NewValue);
        // If failure on setvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        ReturnPropertyValue = TestGetValue(TestObject,PropertyName);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        // Numeric setValue with hashtable, verify with getValue
        ReturnPropertyValue = TestSetValue(TestObject,PropertyIndex,Parameters,NewValue);
        // If failure on setvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        ReturnPropertyValue = TestGetValue(TestObject,PropertyIndex,Parameters);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        // String setValue with hashtable, verify with getValue
        ReturnPropertyValue = TestSetValue(TestObject,PropertyName,Parameters,NewValue);
        // If failure on setvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        ReturnPropertyValue = TestGetValue(TestObject,PropertyName,Parameters);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;

        return ReturnVerifyValue;
    } // SetVerifyValue

   // Verify values of 1 property in 1 Object
   // via all local methods of TestGetValue
   // Parameters:
   //           ABTObject TestObject - reference to ABTObject whose properties have been set
   //           int PropertyIndex - numeric reference within PropertySet, to Property which has been changed
   //           String PropertyName - name attribute of Property which has been changed
   //           ABTHashTable Parameters - currently null
   //           ABTValue NewValue - value to which Property has been set
   public boolean GetVerifyValue(ABTObject TestObject, int PropertyIndex, String PropertyName, ABTHashtable Parameters, ABTValue NewValue)
   {
        ABTValue
            ReturnPropertyValue = null;
        boolean
            ReturnVerifyValue = true;

        CurrentLog.LogWrite(COMMENT,"Testing get Property #" + PropertyIndex);
        // Numeric getValue without hashtable, verify with getValue
        ReturnPropertyValue = TestGetValue(TestObject,PropertyIndex);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        // String getValue without hashtable, verify with getValue
        ReturnPropertyValue = TestGetValue(TestObject,PropertyName);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        // Numeric getValue with hashtable, verify with getValue
        ReturnPropertyValue = TestGetValue(TestObject,PropertyIndex,Parameters);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;
        // String getValue with hashtable, verify with getValue
        ReturnPropertyValue = TestGetValue(TestObject,PropertyName,Parameters);
        // If failure on getvalue, go no further
        if (null == ReturnPropertyValue)
            return false;
        if (false == VerifyPropertyValue(ReturnPropertyValue,NewValue))
            ReturnVerifyValue = false;

        return ReturnVerifyValue;
    } // GetVerifyValue

    // Confirm that 2 ABTValues are equal (contain same value)
    // Currently used to verify return value from ABTObject.setValue or ABTObject.getValue
    // against intended value
    // Parameters:
    //          ABTValue ReturnedValue - value to compare
    //          ABTValue MatchValue - value to match
    public boolean VerifyPropertyValue(ABTValue ReturnedValue, ABTValue MatchValue)
    {
        // We have already tested for "legal" return value - now verify that it
        // matches intended value (NewValue)
        if (null == ReturnedValue)
        {
            return false;
        } else if (ReturnedValue.equals(MatchValue))
        {
            CurrentLog.LogWrite(PASS,"TestObject.getValue returned matching value");
        } else // if not null, but not equal
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue returned wrong ABTValue - " + ReturnedValue.toString());
            return false;
        }

        return true;
    } // VerifyPropertyValue

    // ABTObject.getValue METHODS
    //
    // This overloaded method (1)
    // Calls ABTObject.getValue, referencing property by numeric index within Property Set
    // and using hashtable parameters (AVP - 8/3 - currently null)
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          int PropertyIndex - numeric reference to property within property set
    //          ABTHashtable TestParameters - AVP - 8/3 - currently null
    // Returns value retrieved from getvalue
    public ABTValue TestGetValue(ABTObject TestObject, int PropertyIndex, ABTHashtable TestParameters)
    {
        ABTValue
            GetValueReturnValue;

        GetValueReturnValue = TestObject.getValue(SessionID, PropertyIndex, TestParameters);
        // Success if ABTValue
        if (ABTError.isError(GetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.getValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            }
        } else if (GetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.getValue for Property #" + PropertyIndex + " with hashtable returned ABTValue");
        } else if (null == GetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property #" + PropertyIndex + " with hashtable returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property #" + PropertyIndex + " with hashtable did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for getValue return value

        return GetValueReturnValue;
    } // TestGetValue(1)

    // This overloaded method (2)
    // Calls ABTObject.getValue, referencing property by name
    // and using hashtable parameters (AVP - 8/3 - currently null)
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          String PropertyName - property name
    //          ABTHashtable TestParameters - AVP - 8/3 - currently null
    // Returns value retrieved from getvalue
    public ABTValue TestGetValue(ABTObject TestObject, String PropertyName, ABTHashtable TestParameters)
    {
        ABTValue
            GetValueReturnValue;

        GetValueReturnValue = TestObject.getValue(SessionID, PropertyName, TestParameters);
        // Success if ABTValue
        if (ABTError.isError(GetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.getValue for Property Name " + PropertyName + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property Name " + PropertyName + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            }
        } else if (GetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.getValue for Property Name " + PropertyName + " with hashtable returned ABTValue");
        } else if (null == GetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property Name " + PropertyName + " with hashtable returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property Name " + PropertyName + " with hashtable did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for getValue return value

        return GetValueReturnValue;
    } // TestGetValue(2)

    // This overloaded method (3)
    // Calls ABTObject.getValue, referencing property by numeric index within Property Set
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          int PropertyIndex - numeric reference to property within property set
    // Returns value retrieved from getvalue
    public ABTValue TestGetValue(ABTObject TestObject, int PropertyIndex)
    {
        ABTValue
            GetValueReturnValue;

        GetValueReturnValue = TestObject.getValue(SessionID, PropertyIndex);
        // Success if ABTValue

        if (ABTError.isError(GetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.getValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            }
        } else if (GetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.getValue for Property #" + PropertyIndex + " returned ABTValue");
        } else if (null == GetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property #" + PropertyIndex + " returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property #" + PropertyIndex + " did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for getValue return value

        return GetValueReturnValue;
    } // TestGetValue(3)

    // This overloaded method (4)
    // Calls ABTObject.getValue, referencing property by name
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          String PropertyName - property name
    // Returns value retrieved from getvalue
    public ABTValue TestGetValue(ABTObject TestObject, String PropertyName)
    {
        ABTValue
            GetValueReturnValue;

        GetValueReturnValue = TestObject.getValue(SessionID, PropertyName);
        // Success if ABTValue
        if (ABTError.isError(GetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.getValue for Property Name" + PropertyName + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property Name" + PropertyName + " with hashtable returned ABTError message " + ((ABTError)GetValueReturnValue).getMessage());
                return null;
            }
        } else if (GetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.getValue for Property Name " + PropertyName + " returned ABTValue");
        } else if (null == GetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property Name " + PropertyName + " returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.getValue for Property Name " + PropertyName + " did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for getValue return value

        return GetValueReturnValue;
    } // TestGetValue(4)

    // ABTObject.setValue METHODS
    //
    // This overloaded method (1)
    // Calls ABTObject.setValue, referencing property by numeric index within Property Set
    // and using hashtable parameters (AVP - 8/3 - currently null)
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          int PropertyIndex - numeric reference to property within property set
    //          ABTHashtable TestParameters - AVP - 8/3 - currently null
    //          ABTValue TestValue - value to which property should be set
    // Returns value retrieved from setvalue
    public ABTValue TestSetValue(ABTObject TestObject, int PropertyIndex, ABTHashtable TestParameters, ABTValue TestValue)
    {
        ABTValue
            SetValueReturnValue;

        SetValueReturnValue = TestObject.setValue(SessionID, PropertyIndex, TestValue, TestParameters);
        // Success if ABTValue
        if (ABTError.isError(SetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.setValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            }
        } else if (SetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.setValue for Property #" + PropertyIndex + " with hashtable returned ABTValue");
        } else if (null == SetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property #" + PropertyIndex + " with hashtable returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property #" + PropertyIndex + " with hashtable did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for setValue return value

        return SetValueReturnValue;
    } // TestsetValue(1)

    // This overloaded method (2)
    // Calls ABTObject.setValue, referencing property by name
    // and using hashtable parameters (AVP - 8/3 - currently null)
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          String PropertyName - property name
    //          ABTHashtable TestParameters - AVP - 8/3 - currently null
    //          ABTValue TestValue - value to which property should be set
    // Returns value retrieved from setvalue
    public ABTValue TestSetValue(ABTObject TestObject, String PropertyName, ABTHashtable TestParameters, ABTValue TestValue)
    {
        ABTValue
            SetValueReturnValue;

        SetValueReturnValue = TestObject.setValue(SessionID, PropertyName, TestValue, TestParameters);
        // Success if ABTValue
        if (ABTError.isError(SetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.setValue for Property Name " + PropertyName + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property Name " + PropertyName + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            }
        } else if (SetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.setValue for Property Name " + PropertyName + " with hashtable returned ABTValue");
        } else if (null == SetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property Name " + PropertyName + " with hashtable returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property Name " + PropertyName + " with hashtable did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for setValue return value

        return SetValueReturnValue;
    } // TestSetValue(2)

    // This overloaded method (3)
    // Calls ABTObject.setValue, referencing property by numeric index within Property Set
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          int PropertyIndex - numeric reference to property within property set
    //          ABTValue TestValue - value to which property should be set
    // Returns value retrieved from setvalue
    public ABTValue TestSetValue(ABTObject TestObject, int PropertyIndex, ABTValue TestValue)
    {
        ABTValue
            SetValueReturnValue;

        SetValueReturnValue = TestObject.setValue(SessionID, PropertyIndex, TestValue);
        // Success if ABTValue
        if (ABTError.isError(SetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.setValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property #" + PropertyIndex + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            }
        } else if (SetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.setValue for Property #" + PropertyIndex + " returned ABTValue");
        } else if (null == SetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property #" + PropertyIndex + " returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property #" + PropertyIndex + " did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for setValue return value

        return SetValueReturnValue;
    } // TestSetValue(3)

    // This overloaded method (4)
    // Calls ABTObject.setValue, referencing property by name
    // and verifies return value
    // Parameters:
    //          ABTObject TestObject - reference to ABTObject whose property value will be extracted
    //          String PropertyName - property name
    //          ABTValue TestValue - value to which property should be set
    // Returns value retrieved from setvalue
    public ABTValue TestSetValue(ABTObject TestObject, String PropertyName, ABTValue TestValue)
    {
        ABTValue
            SetValueReturnValue;

        SetValueReturnValue = TestObject.setValue(SessionID, PropertyName, TestValue);
        // Success if ABTValue
        if (ABTError.isError(SetValueReturnValue)) // if error, fail
        {
            if (true == TestObject.isDeleted(SessionID))
            {
                CurrentLog.LogWrite(PASS,"Deleted TestObject.setValue for Property Name " + PropertyName + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            } else
            {
                CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property Name " + PropertyName + " with hashtable returned ABTError message " + ((ABTError)SetValueReturnValue).getMessage());
                return null;
            }
        } else if (SetValueReturnValue instanceof ABTValue)
        {
            CurrentLog.LogWrite(PASS,"TestObject.setValue for Property Name " + PropertyName + " returned ABTValue");
        } else if (null == SetValueReturnValue) // if null, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property Name " + PropertyName + " returned null");
            return null;
        } else // default else, fail
        {
            CurrentLog.LogDisplay(FAIL,"TestObject.setValue for Property Name " + PropertyName + " did not return ABTValue, ABTError, or null");
            return null;
        }  // end if-else for setValue return value

        return SetValueReturnValue;
    } // TestSetValue(4)


} // TestValues