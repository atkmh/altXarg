package com.abtcorp.objectModel;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;

// The purpose is to create a generic object pre-populated with default properties,
// for low-level mechanical testing of ObjectSpace API
// There are no actual rules invoked for this object, no Rule methods overridden
// except SetDefault
// "Full" Object 1 of 2
public class TestFullObject1 extends TestObject
{
    public TestFullObject1()
    {
      super();
    }

    protected void setDefaultProperties()
    {
        for (int NameCtr = 0, CaptionCtr = 0; NameCtr < 10; NameCtr++, CaptionCtr++)    
            addProperty("Name" + NameCtr,"Caption" + CaptionCtr,PROP_INT,false,true,true,false,null,null,null);
    } // SetDefaultProperties
    

  /**
   * return true if strong type checking on >onADD< should be used
   * @return boolean - true if new ABTObject have to be of the same rule type
   */
  protected boolean enforceType ()
  {
    return true;
  }

  /**
   * return true if uniqueness >onADD< should be enforced
   * @return boolean - true if new ABTObject have to be unique 
   */
  protected boolean enforceUniqueness ()
  {
    return true;
  }


} // TestFullObject1






