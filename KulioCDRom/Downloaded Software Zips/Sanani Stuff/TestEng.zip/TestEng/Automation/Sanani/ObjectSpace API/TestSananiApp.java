import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;
import TestLib.*;

public class TestSananiApp
{
   public TestSananiApp() {}

   public void run()
   {
      try {
         // Instantiate testing object and run tests for Object Space / properties population
    //    RunTestProperties();
       // Instantiate testing object and run tests for Object Space population
        RunTestObjectPopulation();
        // Instantiate testing objects and run tests for Session handling
  //      RunTestSessions();
        // Instantiate testing objecrs and run tests for Transaction handling
    //    RunTestTransactions();
      } catch (Exception e) { 
         e.printStackTrace();
      }
   } // run

   // This method will instantiate the log file and test objects
   // for testing properties and values within 1 ObjectSpace
   // for specified number of objects/objectsets
   private void RunTestProperties() throws Exception
   {
        // Create Log object for debug messages,
        // do not prompt user to overwrite
        // do create separate "FAIL"-only Log
        LogFile TestPropertiesLog = new LogFile("TestProperties",false,true);
        // Instantiate test object
        TestProperties TestProp = new TestProperties(TestPropertiesLog);
        // AVP -7/14 - no longer specify rulebase, since will be hardcoded default
        // with no public setrulebase method in published API
        // TestProp.populate("com.abtcorp.rulebase",3);
        // Exercise exposed methods for properties and values in Object Space
        TestProp.populate(3);
   } // RunTestProperties

   // This method will instantiate the log file and test objects
   // for testing Object Space population (add, delete, remove)
   // for specified number of objects/objectsets
   private void RunTestObjectPopulation() throws Exception
   {
        // Create Log object for debug messages,
        // do not prompt user to overwrite
        // do create separate "FAIL"-only Log
        LogFile TestObjectPopulationLog = new LogFile("TestObject",false,true);
        // Instantiate test object
        TestObjectPopulation TestObj = new TestObjectPopulation(TestObjectPopulationLog);
        // Exercise exposed methods which add, remove, delete, verify Objects and ObjectSets
        // Number of Objects/Objectsets created in ObjectSpace will be double of
        // specified parameter:  n Objects + n ObjectSets
        // Must be atleast 30
        TestObj.populate(50);
   } // RunTestObjectPopulation

   // This method will instantiate the log file and test objects
   // for testing Session handling with Object Space population
   // for specified number of Sessions and objects/objectsets
   private void RunTestSessions() throws Exception
   {
        // Create Log object for debug messages,
        // do not prompt user to overwrite
        // do create separate "FAIL"-only Log
        LogFile TestSessionsLog = new LogFile("TestSessions",false,true);
        // Instantiate test object
        TestSessions TestSess = new TestSessions(TestSessionsLog);
        // Exercise exposed methods which open and close Sessions
        // within each Session, run TestObjectPopulation methodology
        // Total number of Objects/ObjectSets created in ObjectSpace:
        // Number of sessions (parameter 1) * numberofobjects (parameter 2)
        // * 2 (for Objects and ObjectSets)
        TestSess.populate(5,50);
   } // RunTestSessions

   // This method will instantiate the log file and test objects
   // for testing Transaction processing with Object Space population
   // for specified number objects/objectsets per Transaction
   private void RunTestTransactions() throws Exception
   {
        // Create Log object for debug messages,
        // do not prompt user to overwrite
        // do create separate "FAIL"-only Log
        LogFile TestTransactionsLog = new LogFile("TestTransactions",false,true);
        // Instantiate test object
        TestTransactions TestTrans = new TestTransactions(TestTransactionsLog);
        // Number of Objects/Objectsets created in ObjectSpace will be double of
        // specified parameter:  n Objects + n ObjectSets
        TestTrans.populate(5,50);
   } // RunTestTransactions

   public static void main(String args[])
   {
        System.out.println("Starting Test App");
        TestSananiApp app = new TestSananiApp();
        app.run();
   }
} // TestSananiApp