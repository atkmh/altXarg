import com.abtcorp.io.*;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.parser.*;
import com.abtcorp.objectModel.*;
// AVP - 7/26 - TestEng "library" package - currently LogFile and ReadFile
import TestLib.*; 
// No more rulebase package - AVP - 7/23
// import com.abtcorp.rulebase.*;

import java.util.Enumeration;
import java.util.Date;
import java.util.Calendar;
import java.util.Vector;
import java.lang.reflect.*;
import java.io.*;

// This class was created to facilitate testing of object space population
// - Creating Objects and ObjectSets
// - Deleting Objects and ObjectSets
// - Population of ObjectSets with new and old Objects
// - Removal of Objects from ObjectSets
// - Verification of the above operations
public class TestObjectPopulation implements ILogType //, IABTMMRuleConstants
{
   // Reference to Session ID currently opened
   ABTUserSession SessionID = null;
   // Object Space to be created 
   private ABTObjectSpace CurrentSpace = null; 
   // For logging test results (diagnostics)
   LogFile CurrentLog = null;
   // Vector of all objects added to object space
   Vector ObjectVector = null;
   // Vector of all generic Rule types used for this test
   Vector RuleVector = null;
   // Vector of all ObjectSets
   Vector ObjectSetVector = null;
   // counter for Current ABTObject, Current rule type, Remote ID
   int
       CurrentObjectPtr = 0,
       CurrentRulePtr = 0,
       CurrentRemoteID = 0,
       // TODO:  both below should be pre-defined in interface
       // special negative return value when no Index found
       NotIndex = -1;
       
   // Constructor
   // Parameters:
   //           LogFile log - Reference to logfile to record diagnostics
   public TestObjectPopulation(LogFile log) throws ABTException
   {
        CurrentLog = log;
        CurrentRemoteID = 0;
        // Instantiate and populate RuleVector with hardcoded generic rules
        RuleVector = new Vector(2);
        RuleVector.addElement(new TestRuleElement("TestFullObject1"));
        RuleVector.addElement(new TestRuleElement("TestFullObject2"));
        // Instantiate Vector to be used for storing ABTObject and ABTObjectSet references
        // Will sequentially store contents of 1 ABTObjectSpace, in order added
        ObjectVector = new Vector(5,1);
        // Instantiate Vector to be used for storing ABTObject references
        // Will sequentially store contents of 1 ABTObjectSet, in order added
        ObjectSetVector = new Vector(10, 1);
   } // TestObjectPopulation constructor

   // This method sets the reference to the current ABTObjectSpace
   // Parameters:
   //           ABTObjectSpace ThisSpace - reference to ABTObjectSpace that has been instantiated
   public void setCurrentSpace(ABTObjectSpace ThisSpace)
   {
        CurrentSpace = ThisSpace;
   } // setCurrentSpace 
   
   // This method retrieves the reference to the current ABTObjectSpace
   public ABTObjectSpace getCurrentSpace()
   {
        return(CurrentSpace);
   } // getCurrentSpace 
   
   // This method sets the reference to the current RemoteID
   // Parameters:
   //           ABTUserSession ThisSession - reference to ABTUserSession that has been opened
   public void setCurrentSession(ABTUserSession ThisSession)
   {
        SessionID = ThisSession;
   } // setCurrentSession
   
   // This method retrieves the reference to the current SessionID
   public ABTUserSession getCurrentSession()
   {
        return(SessionID);
   } // getCurrentSession 
   
   // This method sets the reference to the current RemoteID
   // Parameters:
   //           int ThisID - integer value to set Remote ID
   public void setCurrentRemoteID(int ThisID)
   {
        CurrentRemoteID = ThisID;
   } // setCurrentRemoteID 
   
   // This method retrieves an Object within ObjectVector
   // returns ABTObject reference
   // Parameters:
   //           int Index - Pointer to element within ObjectVector
   public ABTObject getTestObject(int Index)
   {
        return ((TestObjectElement)ObjectVector.elementAt(Index)).CurrentObject;
   } // getTestObject 

   // This method should be called immediately after constructor
   // Calls methods which instantiate and populate ObjectSpace with ABTObjects and ABTObjectSets
   // Calls method which performs delete testing
   // Parameters:
   //           int HowManyObjects     - How many Objects and Object Sets to \
   //           (total objects added will be double: 
   //           if HowManyObjects=10, will add 10 ABTObjects and 10 ABTObjectSets, total 20
   // AVP - 7/14 - removing hardcoded Rule Base testing, since 
   // ultimately will default with no public setRuleBase methods in API 
   // parameter String RuleBasePackage no longer needed
   public void populate (/*String RuleBasePackage, */ int HowManyObjects)
   {
      // Return values from CreateMultiObjects
      boolean
        TestObjectReturn = false,
        TestObjectSetReturn = false,
        TestDeleteReturn = false;
    
      CurrentLog.LogWrite(COMMENT,"STARTING Object Space population in TestObjectPopulation");
       
      // Create Object Space
      setCurrentSpace(new ABTObjectSpace());
      // 7/27 - AVP - get Session ID
      setCurrentSession(CurrentSpace.startSession(null));
      // Test Creating multiple ABTObjects in object space
      TestObjectReturn = CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECT);
      // Test Creating multiple ABTObjectSets in object space
      TestObjectSetReturn = CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECTSET);
      CurrentLog.LogTotals(); // display and log total pass/fail so far
      // If we have created successfully, call various methods to delete and verify different objects
      if ((true == TestObjectReturn) && (true == TestObjectSetReturn))  
      {
          // Before Delete, Verify basic Remove functionality
          // Add same (old) Objects twice to ObjectSet
          if (5 == TestPopulateObjectSet(HowManyObjects+1,5,false))
          {            
              // AVP 10/15/98: if enforceUniqueness() is true, this will return false
              TestPopulateObjectSet(HowManyObjects+1,5,false);
              // Test removing 1 Object by Index - make sure ONLY this Object
              // removed, not other references to same Object
              TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet,1);
              // Test removing 2 Objects by reference (same Object twice)
              TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet,(TestObjectElement)ObjectVector.elementAt(1),2);
          }                
          // Clear and verify populated object set
          TestClearVerifyObjectSet(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet);
          // Add new Objects to ObjectSet
          if (5 == TestPopulateObjectSet(HowManyObjects+1,5,true))
          {
              // Test removing 1 Object by Index
              TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet,1);
              // Test removing 1 Object by reference
              TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet,(TestObjectElement)ObjectVector.lastElement(),4);
          }    
          // Clear and verify populated object set
          TestClearVerifyObjectSet(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet);
          // Clear and verify empty object set
          TestClearVerifyObjectSet(((TestObjectElement)ObjectVector.elementAt(HowManyObjects)).CurrentObjectSet);
          // Now delete objects, within and without objectSet
          TestDeleteReturn = TestDeleteObjects(HowManyObjects, HowManyObjects+1);
          CurrentLog.LogTotals(); // display and log total pass/fail so far
          if (true == TestDeleteReturn) 
          {
              // Verify that ABTObjects can still be found, after all additions and deletions and removals
              // KLUGE:  hardcode the number of objects, based on hardcoded arguments in other methods
              VerifyMultiObjects(HowManyObjects+100);
              CurrentLog.LogTotals(); // display and log total pass/fail so far
          }              
      } // end if Objects and ObjectSets created successfully      
      // Test duplicate Remote ID - reset to 1
      CurrentRemoteID = 0; // this will be incremented in CreateTestObject
      TestObjectReturn = CreateMultiObjects(1,ABTProperty.PROP_OBJECT);
      if (true == TestObjectReturn)
      {
           // Since this is duplicate Remote ID, total object count does NOT increase
           ((TestRuleElement)RuleVector.elementAt(0)).CurrentObjectCount--;
            VerifyMultiObjects(HowManyObjects+100+1);  
      } // end if Object created successfully
      CurrentLog.LogTotals();
      // 7/27 - AVP - end Session
      CurrentSpace.endSession(SessionID);
      CurrentLog.LogDisplay(COMMENT,"Testing Complete");
   } // populate

   // to ABTObjectSpace, calling local methods CreateTestObject or CreateTestObjectSet
   // Parameters:
   //           int LastObject - How Many ABTObjects or ABTObjectSets to create
   //           int ObjectType - Using Properties interface, specifies which to add
   //                            (ABTObject or ABTObjectSet)
   public boolean CreateMultiObjects(int LastObject, int ObjectType)
   {
     ABTValue
        CreatedValue = null;
    
      for (CurrentObjectPtr = 0, CurrentRulePtr = 0; CurrentObjectPtr < LastObject; CurrentObjectPtr++, CurrentRulePtr++) {
          // Toggle Rule Type through hardcoded values in Rule Vector
          if (CurrentRulePtr > RuleVector.size() - 1)
            CurrentRulePtr = 0;
          CurrentLog.LogDisplay(COMMENT,
          "Creating Object" + ((ABTProperty.PROP_OBJECTSET == ObjectType) ? " Set " : " ") + "#" + (CurrentObjectPtr+1) + ", of rule: " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType);
          CreatedValue = null;  
          // Call correct local method to instantiate and add to ObjectSpace
          switch (ObjectType)
          {
            case ABTProperty.PROP_OBJECT:
                CreatedValue = CreateTestObject(((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType); 
                // Track how many ABTObject of each Ruletype are successfully added to Object Space
                if (CreatedValue != null)
                   ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentObjectCount++;
                break;
            case ABTProperty.PROP_OBJECTSET:
                CreatedValue = CreateTestObjectSet(((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType); 
                break;
            default:
                CurrentLog.LogDisplay(FAIL,"ObjectType specified as " + ObjectType + ", not valid");
          } // end switch on ObjectType            
          if (null == CreatedValue)
            return false;
      } // end ObjectPtr for loop   

      return true;
   } // CreateMultiObjects
   
   // This method instantiates and adds 1 new ABTObject to the
   // Object Space, for the specified Rule Type, with a unique
   // incremented Remote ID
   // the referenced for the new ABTObject is stored in a Vector
   // Parameters:
   //           String CurrentObjectName - Rule Type for this object
   public ABTObject CreateTestObject(String CurrentObjectName)
   {

   // local handle for results
      ABTValue 
        object = null;
                
   // Increment Remote ID
      CurrentRemoteID++;
      ABTRemoteIDInteger RemoteID = new ABTRemoteIDInteger(CurrentRemoteID);
      
      // Create specified Object 
      object = CurrentSpace.createObject(SessionID,CurrentObjectName,RemoteID,null);
     // check for error
      if (object instanceof ABTObject) // if ABTObject, success
      {
         CurrentLog.LogWrite(PASS,"Creating object " + CurrentObjectName + " in " + CurrentSpace.getRulebase() + " id:" + ((ABTRemoteIDInteger)RemoteID).getInt());
      } else if (ABTError.isError(object)) // ABTError, failure
      {
         CurrentLog.LogDisplay(FAIL,"Creating object " + CurrentObjectName + " " + ((ABTError)object).getMessage() + " in " + CurrentSpace.getRulebase());
         return null;
      } else if (null == object) // null, failure
      {
         CurrentLog.LogDisplay(FAIL,"Creating object " + CurrentObjectName + " returned null in " + CurrentSpace.getRulebase());
         return null;
      } else // default else, failure
      {
         CurrentLog.LogDisplay(FAIL,"Creating object " + CurrentObjectName + " did not return ABTObject, ABTError, or null in " + CurrentSpace.getRulebase());
         return null;
      }  // end if-else for CurrentSpace.createObject
      
      // Store reference to object in Vector, not yet deleted
      ObjectVector.addElement(new TestObjectElement((ABTObject)object,false,CurrentObjectName));  
      
      // not an error so cast the ABTValue to an ObjectSet-handle
      return (ABTObject)object;
   } // CreateTestObject

   // This method instantiates and adds 1 new ABTObjectSet to the
   // Object Space, for the specified Rule Type, with a unique
   // incremented Remote ID
   // the referenced for the new ABTObject is stored in a Vector
   // Parameters:
   //           String CurrentObjectName - Rule Type for this object
   public ABTObjectSet CreateTestObjectSet(String CurrentObjectSetName)
   {

   // local handle for results
      ABTValue 
        objectset = null;
                
      CurrentRemoteID++;
      
      // Create specified Object Set 
      objectset = CurrentSpace.createObjectSet(SessionID,CurrentObjectSetName);
   // check for error
      if (objectset instanceof ABTObjectSet) // if ABTObjectSet, success
      {
         CurrentLog.LogWrite(PASS,"Creating objectset " + CurrentObjectSetName + " in " + CurrentSpace.getRulebase() + " id:" + CurrentRemoteID);
      } else if (ABTError.isError(objectset)) // ABTError, failure
      {
         CurrentLog.LogDisplay(FAIL,"Creating objectset " + CurrentObjectSetName + " " + ((ABTError)objectset).getMessage() + " in " + CurrentSpace.getRulebase());
         return null;
      } else if (null == objectset) // null, failure
      {
         CurrentLog.LogDisplay(FAIL,"Creating objectset " + CurrentObjectSetName + " returned null in " + CurrentSpace.getRulebase());
         return null;
      } else // default else, failure
      {
         CurrentLog.LogDisplay(FAIL,"Creating objectset " + CurrentObjectSetName + " did not return ABTObjectSet, ABTError, or null in " + CurrentSpace.getRulebase());
         return null;
      }  // end if-else for CurrentSpace.createobjectset
      
      // Store reference to objectset in Vector, not yet deleted
      ObjectVector.addElement(new TestObjectElement((ABTObjectSet)objectset,false,CurrentObjectSetName));  
      
    // not an error so cast the ABTValue to an ObjectSet-handle
      return (ABTObjectSet)objectset;
   } // CreateTestObjectSet
   
   // This method calls various methods:
   // Delete multiple ABTObjects from original population, verify
   // Populate ABTObjectSet with new and referenced Objects
   // Delete ABTObjects from with ABTObjectSet, verify
   // Arguments for each method are hardcoded and can be changed, added,
   // or re-arranged here
   // Parameters:
   //           int LastObject - how many ABTObjects and ABTObjectSets requested in ABTObjectSpace
   //           int WhichObjectSet - which ABTObjectSet reference to use (index in ObjectVector)
   public boolean TestDeleteObjects(int LastObject, int WhichObjectSet)
   {
      boolean
        ObjectSetDelete = false;
        
      CurrentLog.LogDisplay(COMMENT,"Testing ABTObject Delete functionality");
      TestDeleteMultiObjects(20,5,1);
      CurrentLog.LogDisplay(COMMENT,"Testing ABTObjectSet Delete functionality");
      ObjectSetVector.removeAllElements(); // start fresh here
      ObjectSetDelete = TestDeleteFromObjectSet(LastObject,WhichObjectSet);
      // KLUGE:  We will return false if we could not populate object set within
      // TestDeleteFromObjectSet method
      // So, TestRemoveFromObjectSet only called if success
      if (true == ObjectSetDelete)
      {
          CurrentLog.LogDisplay(COMMENT,"Testing ABTObjectSet Remove functionality");
          TestRemoveFromObjectSet(LastObject,WhichObjectSet);
      }            

      return ObjectSetDelete;
   } // TestDeleteObjects 
   
   // This method calls various methods:
   // Populate ABTObjectSet with new and referenced Objects
   // Delete ABTObjects from within ABTObjectSet, verify
   // Arguments for each method are hardcoded and can be changed, added,
   // or re-arranged here
   // Parameters:
   //           int LastObject - how many ABTObjects and ABTObjectSets requested in ABTObjectSpace
   //           int WhichObjectSet - which ABTObjectSet reference to use (index in ObjectVector)
   public boolean TestDeleteFromObjectSet(int LastObject, int WhichObjectSet)
   {
      // Rule type of this object set
      String objectsetRuleType = 
        ((TestRuleElement)RuleVector.elementAt((WhichObjectSet) % RuleVector.size())).CurrentRuleType; 

      // TEST delete method of objects within ABTObjectSet, for 1 object in 1 objectset
      // First, populate Object Set with 10 Objects (all new)
      if (10 != TestPopulateObjectSet(WhichObjectSet+1,10,true))
        return false;
      // Now, delete Objects that were added to Object Set
      // Index 1 (2nd new Object)
      TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,1);
      // Index 0 (first new Object)testp
      TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,0);
      // Index 9 (last new Object)
      TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,ObjectSetVector.size() - 1);
      // Delete Index 0 again!
      TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,0);
      // Add Objects to Object Set that reference pre-existing Objects
      // TODO: Reference correct rule
      if (10 != TestPopulateObjectSet(WhichObjectSet+1,10,false))
        return false;
      // Index 11 (2nd "old" Object)
      if (true == TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,11))
    /* AVP 10/23/98 no longer need to set objectvector deletestatus explicitly, since objectsetvector contains same object as objectvector,
       and is set in testdeleteobjectsetobject
       {
            // Set flag in ObjectVector
            ((TestObjectElement)ObjectVector.elementAt(1)).CurrentDeleteStatus = true;
       }        
    */   
      // Index 10 (first "old" Object)
      if (true == TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,10))
    /* AVP 10/23/98 no longer need to set objectvector deletestatus explicitly, since objectsetvector contains same object as objectvector,
       and is set in testdeleteobjectsetobject
      {
        // Set flag in ObjectVector
            ((TestObjectElement)ObjectVector.elementAt(0)).CurrentDeleteStatus = true;
      }        
    */      
      // Index 19 (last "old" Object)
      if (true == TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,ObjectSetVector.size() - 1))
    /* AVP 10/23/98 no longer need to set objectvector deletestatus explicitly, since objectsetvector contains same object as objectvector,
       and is set in testdeleteobjectsetobject
      {
        // Set flag in ObjectVector
         ((TestObjectElement)ObjectVector.elementAt(9)).CurrentDeleteStatus = true;
      }        
    */          
      // Delete Index 10 again!
      TestDeleteObjectSetObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,10);
      // Delete Object directly from ABTObject that was referenced in Object Set, and has not yet been deleted
      // First, find Object not yet deleted
      for (int ObjectSetPtr = 0; ObjectSetPtr < ObjectSetVector.size(); ObjectSetPtr++)
      {
          ABTObject thisObject = ((TestObjectElement)ObjectSetVector.elementAt(ObjectSetPtr)).CurrentObject;  
          ABTID thisID = thisObject.getID();
          ABTValue thisRemoteID = thisID.getRemote(SessionID);
          int thisObjectPtr = thisObject.getID().getLocal();
          // If this is object with Remote ID, and has not been deleted, delete!
          if ((false == thisObject.isDeleted(SessionID)) && (thisRemoteID != null) && (thisRemoteID instanceof ABTRemoteID))
          {
              if (true == TestDeleteObject(objectsetRuleType,(ABTRemoteID)thisRemoteID,((TestObjectElement)ObjectVector.elementAt(thisObjectPtr - 1)).CurrentDeleteStatus))
              {
                  // Set flag in ObjectVector
                  ((TestObjectElement)ObjectVector.elementAt(thisObjectPtr - 1)).CurrentDeleteStatus = true;
                  ((TestObjectElement)ObjectSetVector.elementAt(ObjectSetPtr)).CurrentDeleteStatus = true;
                  // Verify Deleted Object
                  VerifyDeletedObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet, ObjectSetPtr, thisObject);
                  break;
              }        
          }                
      }  
      // Delete last Object in Object Space directly from ABTObject,
      // then attempt to add to Object Set
      for (int ObjectPtr = LastObject-1; ObjectPtr >= 0; ObjectPtr--)
      {
          ABTObject thisObject = ((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentObject;  
          ABTID thisID = thisObject.getID();
          ABTValue thisRemoteID = thisID.getRemote(SessionID);
          String thisRuleType = ((TestRuleElement)RuleVector.elementAt((ObjectPtr) % RuleVector.size())).CurrentRuleType;
          // If this is object with Remote ID, and has not been deleted, test to delete
          if ((false == thisObject.isDeleted(SessionID)) && (thisRemoteID != null) && (thisRemoteID instanceof ABTRemoteID))
          {
              // if same Rule Type, and not already in objectset, delete it!
              if ((thisRuleType.equals(objectsetRuleType)) && (false == ObjectSetVector.contains(ObjectVector.elementAt(ObjectPtr))))
              {
                  if (true == TestDeleteObject(objectsetRuleType,(ABTRemoteID)thisRemoteID,((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentDeleteStatus))
                  {
                      // Set flag in ObjectVector
                      ((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentDeleteStatus = true;
                      // Add last Object (just deleted) to ABTObjectSet
                      TestAddObjectOld(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,((TestObjectElement)ObjectVector.elementAt(ObjectPtr)),(WhichObjectSet) % RuleVector.size());
                      // Verify Deleted Object
                      VerifyDeletedObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet, ObjectSetVector.size() - 1, ((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentObject);      
                      break;
                  }        
              }                  
          }                
      }  
     
      
      return true;
   } // TestDeleteFromObjectSet

   // This method calls local method RemoveVerifyObject, which:
   // Removes ABTObject at specified Index from ABTObjectSet
   // Verifies how ABTObjectSet contents have changed
   // Removes reference to ABTObject at same Index from ObjectSetVector
   // Verifies that ABTObjectSet and ObjectSetVector now match
   // Arguments for each call to RemoveVerifyObject are hardcoded and can be changed, added,
   // or re-arranged here
   // Parameters:
   //           int LastObject - how many ABTObjects and ABTObjectSets requested in ABTObjectSpace
   //           int WhichObjectSet - which ABTObjectSet reference to use (index in ObjectVector)
   public boolean TestRemoveFromObjectSet(int LastObject, int WhichObjectSet)
   {
      TestObjectElement
        RemovedObject = null;
      int
        ObjectsAdded = 0;

      // Instantiate enumerator
      // AVP - 7/31 - per Hajo, with new Session/Transaction handling,
      // enumerators will only reflect immediate snapshot, will not be 
      // adjusted to reflect changes
      // Can no longer open enumerator before all changes, then verify after all changes
//      Enumeration TestEnum = GetObjectSetEnum(((TestObjectElement)ObjectVector.elementAt(LastObject+1)).CurrentObjectSet);
      // Remove 1st element in Object Set
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,1);
      // Reference 5th element in Object Set
      RemovedObject = (TestObjectElement)ObjectSetVector.elementAt(4);
      // Remove 5th element from Object Set, referencing by index
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,5);
      // Attempt to remove 5th element from Object Set by referencing object directly (should NOT be removable!)
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,RemovedObject,5);
      // Remove 5th element again (should really be 6th)
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,5);
      // Attempt to remove too high
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet).size(SessionID)+10);
      // Attempt to remove -1
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,0);
      // Loop through and remove all others, starting at end and working backwards 
      for (int IndexPtr = (((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet).size(SessionID); IndexPtr > 0; IndexPtr--)  
      {
          TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,IndexPtr);
      } // end for loop          
      // Attempt to remove element from empty ObjectSet
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,5);
      // Now re-populate with a vengeance
      // Referencing pre-existing Objects
      if (LastObject > 10)
      {
          ObjectsAdded = TestPopulateObjectSet(WhichObjectSet+1,LastObject-10,false);
      } else          
      {  
          ObjectsAdded = TestPopulateObjectSet(WhichObjectSet+1,5,false);
      }   
      // Reference last object added
      RemovedObject = (TestObjectElement)ObjectSetVector.lastElement();
      // Remove referenced Object
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,RemovedObject,ObjectsAdded);
      // 100 brand new!
      if (100 != TestPopulateObjectSet(WhichObjectSet+1,100,true))
        return false;
      // Reference first new Object added
      RemovedObject = (TestObjectElement)ObjectSetVector.elementAt(ObjectsAdded);
//      RemovedObject = (TestObjectElement)ObjectSetVector.firstElement();
      // Remove referenced Object
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,RemovedObject,ObjectsAdded+1);
      // Remove first old Object added      
      RemovedObject = (TestObjectElement)ObjectSetVector.firstElement();
      // Remove referenced Object
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,RemovedObject,1);
      // Reference last new Object added
      RemovedObject = (TestObjectElement)ObjectVector.lastElement();
      // Remove referenced Object
      TestRemoveVerifyObject(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet,RemovedObject,ObjectSetVector.size());
      // Final enumerator verification
      // AVP - 7/31 - per Hajo, with new Session/Transaction handling,
      // enumerators will only reflect immediate snapshot, will not be 
      // adjusted to reflect changes
      // Can no longer open enumerator before all changes, then verify after all changes
//      TestObjectSetEnum(((TestObjectElement)ObjectVector.elementAt(WhichObjectSet)).CurrentObjectSet, TestEnum);
         
      return true;
   } // TestRemoveFromObjectSet 

   // This overloaded method(1) calls various local methods which:
   // Removes ABTObject at specified Index from ABTObjectSet
   // Verifies how ABTObjectSet contents have changed
   // Removes reference to ABTObject at same Index from ObjectSetVector
   // Verifies that ABTObjectSet and ObjectSetVector now match
   // Parameters:
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which Object should be removed
   //           int Index - reference to numeric placement of ABTObject to be removed, within ABTObjectSet
   public boolean TestRemoveVerifyObject(ABTObjectSet TestObjectSet, int Index)
   {
      TestObjectElement
        RemovedObjectElement = null;
      boolean
        ObjectRemoved = false;
        
      // Remove specified Object from Object Set
      ObjectRemoved = TestRemoveObject(TestObjectSet,Index-1);
      // If there is no object left in ObjectSetVector,
      // "dummy" with object from ObjectVector
      if ((Index <= ObjectSetVector.size()) && (ObjectSetVector.size() > 0) && (Index > 0))
      {
          RemovedObjectElement = (TestObjectElement)ObjectSetVector.elementAt(Index-1);
      } else
      {
        // KLUGE:  just point at an object, hardcoded here, that I know I have not added
        // to object set
          RemovedObjectElement = (TestObjectElement)ObjectVector.elementAt(18);
      }             
      // If remove occurred successfully:
      // Verify ObjectSet changed
      // Remove from ObjectSetVector
      if (true == ObjectRemoved) 
      {
          // Verify state of Object Set after Remove
          VerifyRemovedObject(TestObjectSet, Index, RemovedObjectElement, false);      
          // Remove same object from ObjectSetVector
          if ((Index <= ObjectSetVector.size()) && (ObjectSetVector.size() > 0) && (Index > 0)) 
              ObjectSetVector.removeElementAt(Index-1);
      } else // end if we removed object              
      {
        // KLUGE:  just point at an object, hardcoded here, that I know I have not added
        // to object set
          RemovedObjectElement = (TestObjectElement)ObjectVector.elementAt(18);
      } 
      // Verify Object Set now matches ObjectSetVector
      VerifyRemovedObject(TestObjectSet, Index, RemovedObjectElement, true);      
      
      return true;
   } // TestRemoveVerifyObject(1)

   // This overloaded method(2) calls various local methods which:
   // Removes ABTObject (referencing ABTObject directly) from ABTObjectSet
   // Verifies how ABTObjectSet contents have changed
   // Removes reference to ABTObject at same Index from ObjectSetVector
   // Verifies that ABTObjectSet and ObjectSetVector now match
   // Parameters:
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which Object should be removed
   //           TestObjectElement RemovedObjectElement - reference to element in ObjectVector, 
   //           int Index - reference to numeric placement of Object to be removed, within ObjectSet    
   //               which contains reference to ABTObject to be removed
   public boolean TestRemoveVerifyObject(ABTObjectSet TestObjectSet, TestObjectElement RemovedObjectElement, int Index)
   {
      int
        ObjectsRemoved = 0;

      // Remove specified Object from Object Set
      ObjectsRemoved = TestRemoveObject(TestObjectSet,RemovedObjectElement.CurrentObject);
      // If remove occurred successfully:
      // Verify ObjectSet changed
      // Remove Object from ObjectSetVector
      if (ObjectsRemoved > 0) 
      {
          // Verify state of Object Set after Remove
          // 8/27 - AVP - won't work when  remove by Object, because more thatn
          // one Object may have been removed - can't confirm
    //      VerifyRemovedObject(TestObjectSet, Index, RemovedObjectElement, false);      
          // Remove all instances of object from ObjectSetVector
          if ((Index <= ObjectSetVector.size()) && (ObjectSetVector.size() > 0) && (Index > 0)) 
        // Test if RemoveObject exists in ObjectSetVector 
        // if so, Remove should be success
        // if not, Remove should fail
            for (int ObjectSetPtr = 0; ObjectSetPtr < ObjectSetVector.size(); ObjectSetPtr++)
            {
                if (RemovedObjectElement.CurrentObject.equals(((TestObjectElement)ObjectSetVector.elementAt(ObjectSetPtr)).CurrentObject))
                    ObjectSetVector.removeElementAt(ObjectSetPtr);                                        
            } // end for loop                
      } 
      // Verify Object Set now matches ObjectSetVector
      VerifyRemovedObject(TestObjectSet, Index, RemovedObjectElement, true);      
      
      return true;
   } // TestRemoveVerifyObject(2)      
   
   // This method will call the local method TestAddObjectNew or TestAddObjectOld to
   // add objects to an ObjectSet
   // Parameters:
   //           int ObjectSetID- the RemoteID of ABTObjectSet to be populated
   //           int HowManyObjects - how many new ABTObjects should be added to ObjectSet
   //           boolean AddNew - Call TestAddObjectNew if true, TestAddObjectOld if false
   //                          - determines whether new Objects are instantiated, or old are referenced
   // Return value:
   //           int - how many objects actually added
   public int TestPopulateObjectSet(int ObjectSetID, int HowManyObjects, boolean AddNew)
   {
        int
            ObjectPtr = 0,
            ObjectsAdded = 0;
        ABTValue
            PopulateObjectSet = null;
        boolean
            ObjectAdded = false,
            ReturnValue = false;

        CurrentRulePtr = (ObjectSetID+1) % RuleVector.size();
        CurrentLog.LogDisplay(COMMENT,"Adding Objects to Object Set " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType + ((AddNew) ? " using addNew " : " using add(Object)"));    
        // Reference ObjectSet to populate from our own ObjectVector
        for (ObjectPtr = 0; ObjectPtr < ObjectVector.size(); ObjectPtr++)
        {
            if (true == AddNew)
            {
                ObjectAdded = TestAddObjectNew(((TestObjectElement)ObjectVector.elementAt(ObjectSetID-1)).CurrentObjectSet,CurrentRulePtr);
            } else 
            {
                ObjectAdded = TestAddObjectOld(((TestObjectElement)ObjectVector.elementAt(ObjectSetID-1)).CurrentObjectSet,((TestObjectElement)ObjectVector.elementAt(ObjectPtr)),CurrentRulePtr);
            } // end if false
            // keep track of how many were added successfully
            if (true == ObjectAdded)
                ObjectsAdded++;
            // no more than we asked for!
            if (ObjectsAdded == HowManyObjects)
                break;
        } // end for loop            
        
        return ObjectsAdded;
   } // TestPopulateObjectSet

   // This method will delete one ABTobject that is referenced within 1 ABTObjectSet
   // ABTObject reference is retrieved from ABTObjectSet, deleted, then verified
   // via both ABTObject.isDeleted and ABTObjectSet.isDeleted
   // other ABTObjectSet methods are called to insure integrity of Object Set
   // Parameters:
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which
   //                                        ABTObject will be deleted 
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   public boolean TestDeleteObjectSetObject(ABTObjectSet TestObjectSet, int Index)
   {
        ABTValue
            DeleteObject = null,
            DeleteReturnValue = null;
        String            
            DeleteObjectType = null;

        CurrentLog.LogDisplay(COMMENT,"Deleting Object #" + Index + " from current ABTObjectSet");
        // Call method to return reference to ABTObject, as specified by Index    
        DeleteObject = TestObjectSet.at(SessionID,Index);
        // Verify that ABTObject is valid and exists in ABTObjectSet
        if (DeleteObject instanceof ABTObject) // valid reference to ABTObject
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.at returned ABTObject correctly");
        } else if (ABTError.isError(DeleteObject)) // ABTError returned
        {
            CurrentLog.LogDisplay(FAIL,"with ABTObjectSet.at, index " + Index + " returned error: " + ((ABTError)DeleteObject).getMessage()); 
            return false;
        } else if (null == DeleteObject) // null returned
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.at, index " + Index + " returned null");
            return false;
        } else  // default else   
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.at did not return ABTObject or ABTerror or null");
            return false;
        } // end if-else ABTObject verification
        // Call method to mark ABTObject as deleted
        DeleteReturnValue = ((ABTObject)DeleteObject).delete(SessionID);
        // Verify that method performed correctly
        if (null == DeleteReturnValue) // delete method returns null if success
        {
            CurrentLog.LogWrite(PASS,"delete method success");
        } else if (ABTError.isError(DeleteReturnValue)) // ABTError returned
        {
            CurrentLog.LogDisplay(FAIL,"delete method returned error: " + ((ABTError)DeleteReturnValue).getMessage()); 
            return false;
        } else // default else    
        {
            CurrentLog.LogDisplay(FAIL,"delete method did not return ABTError OR null");
            return false;
        } // end if-else delete method verification
        // AVP - 8/26/98 - Reduce count for this rule type - delete now reduces count in ABTObjectSpace.getobjects
        for (int RulePtr = 0; RulePtr < RuleVector.size(); RulePtr++) 
        {
            if (((TestObjectElement)ObjectSetVector.elementAt(Index)).CurrentRuleType.equals(((TestRuleElement)RuleVector.elementAt(RulePtr)).CurrentRuleType))
                if (false == ((TestObjectElement)ObjectSetVector.elementAt(Index)).CurrentDeleteStatus)
                {
                    ((TestRuleElement)RuleVector.elementAt(RulePtr)).CurrentObjectCount--;                
                }        
        } // end for loop RulePtr    
        // Set flag in ObjectSetVector
        ((TestObjectElement)ObjectSetVector.elementAt(Index)).CurrentDeleteStatus = true;
        // Use ABTObject and ABTObjectSet methods to verify deleted object
        VerifyDeletedObject(TestObjectSet, Index, (ABTObject)DeleteObject);
        // AVP - 7/9
        //  Could NOT get this to work - how does a new Object get an ID???
        // Following logic is convoluted, but DOES test functionality
        // of more methods - instead of directly deleting this Object reference,
        // retrieve the rule type and index, and pass those to TestDeleteObject
        //DeleteObjectType = ((ABTObject)DeleteObject).getObjectType();
        //CurrentLog.LogDisplay(COMMENT,DeleteObjectType);
        //DeleteObjectID = ((ABTObject)DeleteObject).getID();
        //CurrentLog.LogDisplay(COMMENT,"ID = " + DeleteObjectID);
        
        return true;
   } // TestDeleteObjectSetObject

   // This method calls various local methods, which will call ABTObject or ABTObjectSet methods
   // to verify that ABTObject DeleteObject has been flagged as deleted,
   // without any damage to data integrity of ABTObjectSet TestObjectSet
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which
   //                                        ABTObject has been deleted 
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   //           ABTObject DeleteObject - reference to ABTObject which has been deleted
   public boolean VerifyDeletedObject(ABTObjectSet TestObjectSet, int Index, ABTObject DeleteObject)
   {
        CurrentLog.LogDisplay(COMMENT,"Verifying deleted Object #" + Index + " from current ABTObjectSet");
        // Verify ABTObject.isDeleted method
        VerifyIsDeleted(DeleteObject,true);
        // Verify ABTObject.equals() method still returns true for deleted object
        VerifyObjectEquals(TestObjectSet,Index,DeleteObject,true);
        // Verify is deleted - ABTObjectSet method
        VerifyIsDeleted(TestObjectSet,Index,true);
        // Verify ABTObjectSet.front() method still returns first object in vector, no errors
        VerifyObjectSetFront(TestObjectSet,true,false);
        // Verify ABTObjectSet.back() method still returns last object in vector, no errors
        VerifyObjectSetBack(TestObjectSet,true,false);
        // Verify ABTObjectSet.size() method still returns size of vector
        VerifyObjectSetSize(TestObjectSet,true);
        // Verify ABTObjectSet.isEmpty() method still returns false
        VerifyObjectSetIsEmpty(TestObjectSet,false);
        // Verify ABTObjectSet.contains() method still returns true for deleted object
        VerifyObjectSetContains(TestObjectSet,DeleteObject,true);
        // Verify ABTObjectSet.checkIndex() method still returns true for deleted object
        VerifyObjectSetCheckIndex(TestObjectSet,Index,true);

        return true;
   } // VerifyDeletedObject
   
   // This method calls various local methods, which will call ABTObject or ABTObjectSet methods
   // to verify that ABTObject RemoveObject has been removed from ABTObjectSet, 
   // without being flagged as deleted
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which
   //                                        ABTObject has been removed 
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   //           TestObjectElement RemoveObjectElement - reference to element in ObjectVector, 
   //                               which contains reference to ABTObject which has been removed, and deleted status
   //           boolean RemovedFromVector - true if Object has also been removed from local ObjectSet vector
   public boolean VerifyRemovedObject(ABTObjectSet TestObjectSet, int Index, TestObjectElement RemoveObjectElement, boolean RemovedFromVector)
   {
        CurrentLog.LogDisplay(COMMENT,"Verifying removed Object #" + Index + " from current ABTObjectSet, " + ((RemovedFromVector) ? "AFTER " : "BEFORE") + " removing object from ObjectSetVector");
        // Verify ABTObjectSet.isEmpty() method still returns true
        // only if ObjectSetVector is empty, or if 1 left in ObjectSetVector, not yet removed
        if ((ObjectSetVector.isEmpty()) || ((false == RemovedFromVector) && (1 == ObjectSetVector.size())))
        {
            VerifyObjectSetIsEmpty(TestObjectSet,true);
//            return true;
        } else
        {
            VerifyObjectSetIsEmpty(TestObjectSet,false);
        }    
        // Verify ABTObject.isDeleted method returns correct value
        VerifyIsDeleted(RemoveObjectElement.CurrentObject,RemoveObjectElement.CurrentDeleteStatus);
        // Verify ABTObject.equals() method returns false for removed object
        if (Index >= TestObjectSet.size(SessionID))
        {
            VerifyObjectEquals(TestObjectSet,TestObjectSet.size(SessionID)-1,RemoveObjectElement.CurrentObject,false);
        } else
        {
            VerifyObjectEquals(TestObjectSet,Index-1,RemoveObjectElement.CurrentObject,false);
        }     
        // AVP - 7/16 - this makes no sense because element no longer
        // exists in ABTObjectSet after removal - no way to verify deleted flag
        // Verify ABTObjectSet.isDeleted method returns correct value
//        VerifyIsDeleted(TestObjectSet,Index,RemoveObjectElement.CurrentDeleteStatus);
        // If ObjectSet is being cleared, error should return            
        if ((ObjectSetVector.isEmpty()) || ((false == RemovedFromVector) && (1 == ObjectSetVector.size())))
        {
            VerifyObjectSetFront(TestObjectSet,false,true);
        // If first element has been removed, and not yet removed from objectset vector,
        // ABTObjectSet.front() method will not return first object in vector
        } else if ((false == RemovedFromVector) && (1 == Index))
        {
            VerifyObjectSetFront(TestObjectSet,false,false);
        } else
        {
            VerifyObjectSetFront(TestObjectSet,true,false);
        }    
        // If ObjectSet is being cleared, error should return            
        if ((ObjectSetVector.isEmpty()) || ((false == RemovedFromVector) && (1 == ObjectSetVector.size())))
        {
            VerifyObjectSetBack(TestObjectSet,false,true);
        // If last element has been removed, and not yet removed from objectset vector,
        // ABTObjectSet.back() method will not return last object in vector
        } else if ((false == RemovedFromVector) && (ObjectSetVector.size() == Index))
        {
            VerifyObjectSetBack(TestObjectSet,false,false);
        } else            
        {
            VerifyObjectSetBack(TestObjectSet,true,false);
        }    
        // Verify ABTObjectSet.size() method returns size of ObjectSetVector,
        // if object removed from ObjectSetVector
        VerifyObjectSetSize(TestObjectSet,RemovedFromVector);
        // Verify ABTObjectSet.contains() method returns false for removed object
        VerifyObjectSetContains(TestObjectSet,RemoveObjectElement.CurrentObject,false);
        // Verify ABTObjectSet.checkIndex() method 
        // returns true unless total size of ObjectSetVector is below Index
        VerifyObjectSetCheckIndex(TestObjectSet,Index-1,((Index < ObjectSetVector.size()) && (Index > 0)));
        // Verify ABTObjectSet enumeration (unsorted)
        VerifyEnumeration(TestObjectSet);
        return true;
   } // VerifyRemovedObject

   // This overloaded method(1) calls ABTObject.isDeleted
   // and verifies results
   // Parameter:        
   //           ABTObject DeleteObject - reference to ABTObject to be tested
   //           boolean ShouldReturn - true if ABTObject should have been deleted
   public boolean VerifyIsDeleted(ABTObject DeleteObject, boolean ShouldReturn)
   { 
        boolean
            DeletedFlag = false; // return value from isDeleted
            
        // Call ABTObject.isDeleted method
        DeletedFlag = DeleteObject.isDeleted(SessionID);
        // verify return value
        if (ShouldReturn == DeletedFlag) // if matches expected result, success
        {
            CurrentLog.LogWrite(PASS,"ABTObject.isDeleted flag set to " + DeletedFlag);
        } else if (!ShouldReturn == DeletedFlag)  // if does not match expected result, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObject.isDeleted flag set to " + DeletedFlag);
            return false;
        } else // default else - not true or false
        {
            CurrentLog.LogDisplay(FAIL,"ABTObject.isDeleted method did NOT return boolean");
            return false;
        }    
        
        return true;
   } // VerifyIsDeleted(1)        
   
   // This overloaded method(2) calls ABTObjectSet.isDeleted
   // and verifies results
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which
   //                                        ABTObject may have been deleted 
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   //           boolean ShouldReturn - true if ABTObject should have been deleted
   public boolean VerifyIsDeleted(ABTObjectSet TestObjectSet, int Index, boolean ShouldReturn)
   { 
        boolean
            DeletedFlag = false; // return value from isDeleted

        // call ABTObjectSet.isDeleted method
        DeletedFlag = TestObjectSet.isDeleted(SessionID,Index);
        // verify return value
        if (ShouldReturn == DeletedFlag) // if matches expected result, success
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.isDeleted flag set to " + DeletedFlag);
        } else if (!ShouldReturn == DeletedFlag)  // if does not match expected result, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.isDeleted flag set to " + DeletedFlag);
            return false;
        } else // default else - not true or false
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.isDeleted method did NOT return boolean");
            return false;
        }    
        
        return true;
   } // VerifyIsDeleted(2)        
   
   // This method calls ABTObject.equals
   // and verifies results
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet from which
   //                                        ABTObject has been deleted 
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   //           ABTObject EqualObject - reference to ABTObject 
   //           boolean ShouldReturn - true if ABTObject should be referenced in ABTObjectSet at Index
   public boolean VerifyObjectEquals(ABTObjectSet TestObjectSet, int Index, ABTObject EqualObject, boolean ShouldReturn)
   { 
        boolean
            DeletedFlag = false; // return value from isDeleted
            
        DeletedFlag = EqualObject.equals(TestObjectSet.at(SessionID,Index));
        // verify return value
        if (ShouldReturn == DeletedFlag) // if matches expected result, success
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.equals returns " + DeletedFlag);
        } else if (!ShouldReturn == DeletedFlag)  // if does not match expected result, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.equals returns " + DeletedFlag);
            return false;
        } else // default else - not true or false
        {
            CurrentLog.LogDisplay(FAIL,"ABTObject.isDeleted method did NOT return boolean");
            return false;
        }    
        
        return true;
   } // VerifyObjectEquals   

   // This method calls ABTObjectSet.front()
   // and verifies that reference to first ABTObject in ABTObjectSet is returned
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet to test
   //           boolean ShouldReturn - true if first object has not been removed from local objectset vector
   //           boolean ShouldError - should return Error (currently only if ObjectSet is empty)
   public boolean VerifyObjectSetFront(ABTObjectSet TestObjectSet, boolean ShouldReturn, boolean ShouldError)
   {
        ABTValue
            DeleteReturnValue = null;
            
        // call ABTObjectSet.front() method    
        DeleteReturnValue = TestObjectSet.front(SessionID);
        // Verify return value
        if (DeleteReturnValue instanceof ABTObject) // correctly returns ABTObject 
        {
            // if first object not removed from local ObjectSet vector, should equal first object
            // if first object removed from local ObjectSet vector, should equal second object
            if (((ABTObject)DeleteReturnValue).equals((true == ShouldReturn) ? ((TestObjectElement)ObjectSetVector.firstElement()).CurrentObject : ((TestObjectElement)ObjectSetVector.elementAt(1)).CurrentObject))
                CurrentLog.LogWrite(PASS,"ABTObjectSet.front() returned first object in object set"); 
            else // if returned reference to other Object, failure
                CurrentLog.LogDisplay(FAIL,"ABTObjectSet.front() did not return first object in object set");
        } else if (ABTError.isError(DeleteReturnValue)) // returned ABTError, failure
        {
            if (true == ShouldError)
            {
                CurrentLog.LogWrite(PASS,"ABTObjectSet.front() returned error: " + ((ABTError)DeleteReturnValue).getMessage()); 
            }                
            else                
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSet.front() returned error: " + ((ABTError)DeleteReturnValue).getMessage()); 
            }                
        } else if (null == DeleteReturnValue) // return null, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.front() returned null: ");
        } else // default else 
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.front() did not return ABTError, ABTObject or null");
        } // end if-else TestObjectSet.front() method verification
        
        return true;
   } // VerifyObjectSetFront
        
   // This method calls ABTObjectSet.back()
   // and verifies that reference to last ABTObject in ABTObjectSet is returned
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet to test
   //           boolean ShouldReturn - true if last object has not been removed from object set 
   //           boolean ShouldError - should return Error (currently only if ObjectSet is empty)
  public boolean VerifyObjectSetBack(ABTObjectSet TestObjectSet, boolean ShouldReturn, boolean ShouldError)
   {
        ABTValue
            DeleteReturnValue = null;
            
        // call ABTObjectSet.back() method    
        DeleteReturnValue = TestObjectSet.back(SessionID);
        // Verify return value
        if (DeleteReturnValue instanceof ABTObject) // correctly returns ABTObject 
        {
            // if last object not removed, should equal last object
            // if last object removed, should equal second to last object
            if (((ABTObject)DeleteReturnValue).equals((true == ShouldReturn) ? ((TestObjectElement)ObjectSetVector.lastElement()).CurrentObject : ((TestObjectElement)ObjectSetVector.elementAt(ObjectSetVector.size() - 2)).CurrentObject))
                CurrentLog.LogWrite(PASS,"ABTObjectSet.back() returned last object in object set"); 
            else // if returned reference to other Object, failure
                CurrentLog.LogDisplay(FAIL,"ABTObjectSet.back() did not return last object in object set");
        } else if (ABTError.isError(DeleteReturnValue)) // returned ABTError, failure
        {
            if (true == ShouldError)
            {
                CurrentLog.LogWrite(PASS,"ABTObjectSet.back() returned error: " + ((ABTError)DeleteReturnValue).getMessage()); 
            }                
            else                
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSet.back() returned error: " + ((ABTError)DeleteReturnValue).getMessage()); 
            }                
        } else if (null == DeleteReturnValue) // return null, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.back() returned null: ");
        } else // default else 
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.back() did not return ABTError, ABTObject or null");
        } // end if-else TestObjectSet.back() method verification
        
        return true;
   } // VerifyObjectSetBack         
        
   // This method calls ABTObjectSet.size()
   // and verifies that correct number of ABTObjects in ABTObjectSet is returned
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet to test
   //           boolean ShouldReturn - true if object has not been removed from object set 
   public boolean VerifyObjectSetSize(ABTObjectSet TestObjectSet, boolean ShouldReturn)
   {
        int
            DeleteReturnInt = 0;
            
        // call ABTObjectSet.size() method            
        DeleteReturnInt = TestObjectSet.size(SessionID);
        // If we have just removed object, increment return value by 1 to match size
        if (false == ShouldReturn)
            DeleteReturnInt++;
        // Verify return value
        if (DeleteReturnInt == ObjectSetVector.size()) // matches ABTObjectSet vector
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.size() returned correct # of objects in object set");
        } else // if no match, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.size() returned " + DeleteReturnInt + ", instead of " + ObjectSetVector.size());
        }            
        
        return true;
   } // VerifyObjectSetSize         

   // This method calls ABTObjectSet.isEmpty()
   // and verifies that correct boolean value of true or false is returned
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet to test
   //           boolean ShouldReturn - true if ABTObjectSet IS empty, otherwise false
   public boolean VerifyObjectSetIsEmpty(ABTObjectSet TestObjectSet, boolean ShouldReturn)
   {
        boolean
            DeletedFlag = false;

        // call ABTObjectSet.isEmpty() method    
        DeletedFlag = TestObjectSet.isEmpty(SessionID);
        // Verify return value
        if (ShouldReturn == DeletedFlag) // if match expected return, success
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.isEmpty() returns " + ShouldReturn);
        } else // if not match expected return, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.isEmpty() returns " + !ShouldReturn);
        }            
    
        return true;
   } // VerifyObjectSetIsEmpty        
   
   // This method calls ABTObjectSet.contains()
   // and verifies that correct boolean value of true or false is returned
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet to test
   //           ABTObject DeleteObject - reference to ABTObject that should exist in ABTObjectSet
   //           boolean ShouldReturn - true if ABTObjectSet contains this ABTObject, otherwise false
   public boolean VerifyObjectSetContains(ABTObjectSet TestObjectSet, ABTObject DeleteObject, boolean ShouldReturn)
   {
        boolean
            DeletedFlag = false;

        // call ABTObjectSet.contains method
        DeletedFlag = TestObjectSet.contains(SessionID,DeleteObject);
        // verify return value
        if (ShouldReturn == DeletedFlag) // if matches expected return, success
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.contains() returns " + ShouldReturn);
        } else // if not match expected return, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.contains() returns " + !ShouldReturn);
        }            
        
        return true;
   } // VerifyObjectSetContains
   
   // This method calls ABTObjectSet.checkIndex()
   // and verifies that correct boolean value of true or false is returned
   // Parameter:        
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet to test
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   //           boolean ShouldReturn - true if ABTObjectSet contains this index, otherwise false
   public boolean VerifyObjectSetCheckIndex(ABTObjectSet TestObjectSet, int Index, boolean ShouldReturn)
   {
        boolean
            DeletedFlag = false;

        // call method ABTObjectSet.checkIndex
        DeletedFlag = TestObjectSet.checkIndex(SessionID,Index);
        // verify return value
        if (ShouldReturn == DeletedFlag) // if matches expected value, success
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.checkIndex() returns true");
        } else  // if does not match expected value, failure
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.checkIndex() returns false");
        }     
        
        return true;
   } // VerifyObjectSetCheckIndex

   // This method adds 1 new Object to an ObjectSet
   // using ABTObjectSet.addNew()
   // Parameters:
   //           ABTObjectSet PopulateObjectSet - reference to the ObjectSet to be populated
   //           int CurrentRulePtr - points to Ruletype for this ObjectSet
   // Returns true if success, false if fail
   public boolean TestAddObjectNew(ABTObjectSet PopulateObjectSet, int CurrentRulePtr)
   {
        ABTValue
            AddNewObject = null;
            
        AddNewObject = PopulateObjectSet.addNew(SessionID);
        if (ABTError.isError(AddNewObject))
        {
            CurrentLog.LogDisplay(FAIL,"addnew method returned error: " + ((ABTError)AddNewObject).getMessage()); 
            return false;
        } else if (null == AddNewObject)
        {
            CurrentLog.LogDisplay(FAIL,"addnew method returned null");
            return false;
        } else if (AddNewObject instanceof ABTObject)
        {
            CurrentLog.LogWrite(PASS,"addnew method success");
            ObjectVector.addElement(new TestObjectElement((ABTObject)AddNewObject,false,((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType));
            // 10/23/98 AVP:  No longer create new object and add to ObjectSetVector
            // Instead, now add existing ObjectVector element to vector
            // This way, both vectors will always have identical object data
            ObjectSetVector.addElement(ObjectVector.lastElement());
            if ((CurrentRulePtr >= 0) && (CurrentRulePtr < RuleVector.size()))
                ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentObjectCount++;
        } else {
            CurrentLog.LogDisplay(FAIL,"addnew method did not return ABTError, ABTObject, or null");
            return false;
        } // default else
        
        return true;
   } // TestAddObjectNew
   
   // This method adds 1 "old" Object to an ObjectSet
   // using ABTObjectSet.add()
   // Parameters:
   //           ABTObjectSet PopulateObjectSet - reference to the ObjectSet to be populated
   //           TestObjectElement WhichObjectElement - reference to element in ObjectVector which contains
   //                                           reference to ABTObject to be added
   //                                           delete status of ABTObject
   //           int RulePtr - points to ruletype for PopulateObjectSet
   // Returns true if success, false if fail
   public boolean TestAddObjectOld(ABTObjectSet PopulateObjectSet, TestObjectElement WhichObjectElement, int CurrentRulePtr)
   {
        ABTValue
            AddOldObject = null;
        String
            ObjectSetRuleType = null,
            ObjectRuleType = null;
        boolean
            enforceType = false,
            enforceUniqueness = false;
            
        AddOldObject = PopulateObjectSet.add(SessionID,WhichObjectElement.CurrentObject);
        enforceType = ((TestObject)PopulateObjectSet.getRule()).enforceThisType();
        enforceUniqueness = ((TestObject)PopulateObjectSet.getRule()).enforceThisUniqueness();
        if (ABTError.isError(AddOldObject))
        {
            // AVP 10/14/98:  If rule type is not correct, and error was returned, then 
            // NO failure
            ObjectSetRuleType = ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType;            
            ObjectRuleType = WhichObjectElement.CurrentRuleType;            
            if (ObjectSetRuleType.equals(ObjectRuleType))
            {
                if (true == enforceUniqueness)
                {
                    CurrentLog.LogWrite(PASS,"ABTObjectSet.add method returned error: " + ((ABTError)AddOldObject).getMessage() + " and enforceType = true"); 
                } else {
                    CurrentLog.LogDisplay(FAIL,"ABTObjectSet.add method returned error: " + ((ABTError)AddOldObject).getMessage()); 
                }                    
                return false;
            } else {
                if (true == enforceType)
                {
                    CurrentLog.LogWrite(PASS,"ABTObjectSet.add method returned error: " + ((ABTError)AddOldObject).getMessage() + " and enforceType = true"); 
                } else {
                    CurrentLog.LogDisplay(FAIL,"ABTObjectSet.add method returned error: " + ((ABTError)AddOldObject).getMessage() + " and enforceType = false"); 
                }     
                return false;
            }                
        } else if (null == AddOldObject)
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.add method returned null");
            return false;
        } else if (AddOldObject instanceof ABTObject)
        {
            CurrentLog.LogWrite(PASS,"ABTObjectSet.add method success");
            // 10/23/98 AVP:  No longer create new object and add to ObjectSetVector
            // Instead, now add existing ObjectVector element to vector
            // This way, both vectors will always have identical object data
            ObjectSetVector.addElement(WhichObjectElement);
//            if ((CurrentRulePtr >= 0) && (CurrentRulePtr < RuleVector.size()))
  //              ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentObjectCount++;
        } else {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.add method did not return ABTError, ABTObject, or null");
            return false;
        } // default else
        
        return true;
   } // TestAddObjectOld

   // This method will call the local TestDeleteObject method to 
   // "delete" specified object(s) from the Object Space
   // Parameters:  
   //           int StartObject- the RemoteID of first ABTObject to delete (starting at 1)
   //           int NumberObjects- how many ABTObjects to delete
   //           int ObjectSpacing- how many ABTObjects to skip between each delete
   public boolean TestDeleteMultiObjects(int StartObject, int NumberObjects, int ObjectSpacing)
   {
        ABTValue
            DeleteObject = null; // reference to ABTObject to be deleted
        ABTRemoteIDInteger 
            DeleteRemoteID = null; // reference to Remote ID of ABTObject to be deleted
        int
            DeletePtr = 0; // Integer representation of Remote ID

        CurrentLog.LogDisplay(COMMENT,"Test Deleting " + NumberObjects + 
        " ABTObjects from Object Space, starting at " + StartObject + " and spacing by " + ObjectSpacing);
        // Loop through and delete all requested objects
        for (DeletePtr = StartObject; DeletePtr < StartObject + NumberObjects * ObjectSpacing; DeletePtr += ObjectSpacing)
        {
            // Figure out which rule for this object
            CurrentRulePtr = (DeletePtr+1) % RuleVector.size();
            // Convert Remote ID from integer
            DeleteRemoteID = new ABTRemoteIDInteger(DeletePtr);
            if (true == TestDeleteObject(((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType,DeleteRemoteID,((TestObjectElement)ObjectVector.elementAt(DeletePtr - 1)).CurrentDeleteStatus))
            {            
                // Set flag in ObjectVector
                ((TestObjectElement)ObjectVector.elementAt(DeletePtr - 1)).CurrentDeleteStatus = true;
            }                
        } // end for loop            
   
        return true;
   } // TestDeleteMultiObjects

   // This method calls ABTObject.delete method to
   // "delete" one ABTObject from the Object Space
   // The "delete" status is then verified with ABTObject.isDeleted
   // Parameters:
   //               String RuleType - which Type of ABTObject
   //               ABTRemoteID DeleteRemoteID - Remote ID of ABTObject
   //               boolean AlreadyDeleted - if true, should not be found with getobjectremote
   public boolean TestDeleteObject(String RuleType, ABTRemoteID DeleteRemoteID, boolean AlreadyDeleted)
   {
        ABTObject
            DeleteObject = null;      // Return value from findObject 
        ABTValue
            DeleteReturnValue = null; // Return value from delete method
        boolean
            DeletedFlag = false; // Return value from isDeleted
            
        CurrentLog.LogDisplay(COMMENT,"Deleting Object type " + RuleType + " #" + ((ABTRemoteIDInteger)DeleteRemoteID).getInt() + " from current Object Space");
        // Retrieve Object to delete
        DeleteObject = GetObjectRemote(RuleType,DeleteRemoteID,AlreadyDeleted);
        // If didn't get found, we will not delete!
        if (null == DeleteObject)
            return false;
        // Delete it!
        DeleteReturnValue = ((ABTObject)DeleteObject).delete(SessionID);
        if (null == DeleteReturnValue) // delete method returns null if success
        {
            CurrentLog.LogWrite(PASS,"delete method success");
        } else if (ABTError.isError(DeleteReturnValue))
        {
            CurrentLog.LogDisplay(FAIL,"delete method returned error: " + ((ABTError)DeleteReturnValue).getMessage()); 
            return false;
        } else // default else    
        {
            CurrentLog.LogDisplay(FAIL,"delete method did not return ABTError OR null");
            return false;
        } 
        // AVP - 8/26/98 - Reduce count for this rule type - delete now reduces count in ABTObjectSpace.getobjects
        for (int RulePtr = 0; RulePtr < RuleVector.size(); RulePtr++) 
        {
            if (RuleType.equals(((TestRuleElement)RuleVector.elementAt(RulePtr)).CurrentRuleType))
            {            
                ((TestRuleElement)RuleVector.elementAt(RulePtr)).CurrentObjectCount--;                
            }                                
        } // end for loop RulePtr    
        // Verify via ABTObject.isDeleted
        VerifyIsDeleted(DeleteObject,true);

        return true;
   } // TestDeleteObject
   
   public ABTObject GetObjectRemote(String RuleType, ABTRemoteID FindRemoteID, boolean AlreadyDeleted)
    {
        ABTValue
            FindObject = null;
    
        FindObject = CurrentSpace.findObject(SessionID,RuleType,FindRemoteID);
        if (ABTError.isError(FindObject))
        {
            if (AlreadyDeleted) // should return error if object is deleted
            {
                CurrentLog.LogWrite(PASS,"findObject method, for deleted Object type " + RuleType + " with ID=" + ((ABTRemoteIDInteger)FindRemoteID).getInt() + " returned error: " + ((ABTError)FindObject).getMessage()); 
            } else
            {
                CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with ID=" + ((ABTRemoteIDInteger)FindRemoteID).getInt() + " returned error: " + ((ABTError)FindObject).getMessage()); 
            }                                
            return null;
        } else if (null == FindObject) 
        {
            CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with ID=" + ((ABTRemoteIDInteger)FindRemoteID).getInt() + " returned null");
            return null;
        } else if (FindObject instanceof ABTObject)
        {
            CurrentLog.LogWrite(PASS,"findObject method returned Object of Type " + RuleType + " with ID=" + ((ABTRemoteIDInteger)FindRemoteID).getInt()); 
        } else
        {
            CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with ID=" + ((ABTRemoteIDInteger)FindRemoteID).getInt() + " did not return ABTError, null, or ABTObject");
            return null;
        } // default else
        
        return ((ABTObject)FindObject);
   } // GetObjectRemote

   // This overloaded method (1) calls
   // ABTObjectSpace.findObject(String Rule, ABTID LocalID)
   // Returns object found (or null if error)
   public ABTObject GetObjectLocal(String RuleType, ABTID FindLocalID, boolean AlreadyDeleted)
   {
        ABTValue
            FindObject = null;
    
        try {
            FindObject = CurrentSpace.findObject(SessionID,RuleType,FindLocalID);
        } catch (Exception e) {
            CurrentLog.LogDisplay(FAIL,"Exception finding Object with local ID = " + FindLocalID.getLocal() +  ": " + e);
            return null;
        }
        
        if (ABTError.isError(FindObject))
        {
            if (AlreadyDeleted) // should return error if object is deleted
            {
                CurrentLog.LogWrite(PASS,"findObject method, for deleted Object type " + RuleType + " with Local ID=" + FindLocalID.getLocal() + " returned error: " + ((ABTError)FindObject).getMessage()); 
            } else
            {
                CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with Local ID=" + FindLocalID.getLocal() + " returned error: " + ((ABTError)FindObject).getMessage()); 
            }                                
            return null;
        } else if (null == FindObject) 
        {
            CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with Local ID=" + FindLocalID + " returned null");
            return null;
        } else if (FindObject instanceof ABTObject)
        {
            CurrentLog.LogWrite(PASS,"findObject method returned Object of Type " + RuleType + " with Local ID=" + FindLocalID); 
        } else
        {
            CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with Local ID=" + FindLocalID + " did not return ABTError, null, or ABTObject");
            return null;
        } // default else
        
        return ((ABTObject)FindObject);
   } // GetObjectLocal(1)

   // This overloaded method (2) calls
   // ABTObjectSpace.findObject(String Rule, int LocalID)
   // Returns object found (or null if error)
   public ABTObject GetObjectLocal(String RuleType, int FindLocalID, boolean AlreadyDeleted)
   {
        ABTValue
            FindObject = null;
    
        FindObject = CurrentSpace.findObject(SessionID,RuleType,FindLocalID);
        if (ABTError.isError(FindObject))
        {
            if (AlreadyDeleted) // should return error if object is deleted
            {
                CurrentLog.LogWrite(PASS,"findObject method, for deleted Object type " + RuleType + " with Local ID=" + FindLocalID + " returned error: " + ((ABTError)FindObject).getMessage()); 
            } else
            {
                CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with Local ID=" + FindLocalID + " returned error: " + ((ABTError)FindObject).getMessage()); 
            }                                
            return null;
        } else if (null == FindObject) 
        {
            CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with Local ID=" + FindLocalID + " returned null");
            return null;
        } else if (FindObject instanceof ABTObject)
        {
            CurrentLog.LogWrite(PASS,"findObject method returned Object of Type " + RuleType + " with Local ID=" + FindLocalID); 
        } else
        {
            CurrentLog.LogDisplay(FAIL,"findObject method, for Object type " + RuleType + " with Local ID=" + FindLocalID + " did not return ABTError, null, or ABTObject");
            return null;
        } // default else
        
        return ((ABTObject)FindObject);
   } // GetObjectLocal(2)

   // This overloaded method(1) calls ABTObjectSet.remove(int index) 
   // method to "remove" one ABTObject from the currently referenced
   // Object Set
   // Parameters:
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet 
   //           int Index - reference to numeric placement of ABTObject within ABTObjectSet
   public boolean TestRemoveObject(ABTObjectSet TestObjectSet, int Index)
   {
        ABTValue
            RemoveReturnValue = null; // Return value from remove method
            
        CurrentLog.LogDisplay(COMMENT,"Removing Object #" + (Index+1) + " from current Object Set");
        // Remove it!
        RemoveReturnValue = TestObjectSet.remove(SessionID,Index);
        // if ABTObject returned, success
        if (RemoveReturnValue instanceof ABTObject)
        {
            // If we should have error, fail
            if ((Index >= 0) && (Index <= TestObjectSet.size(SessionID))) 
            {
                CurrentLog.LogWrite(PASS,"remove method success");
            } else
            {
                CurrentLog.LogDisplay(FAIL,"remove method returned ABTObject when Index = " + Index);
                return false;
            }    
        } else if (ABTError.isError(RemoveReturnValue)) // ABTError returned...
        {
            // If we shouldn't have error, fail
            if ((Index >= 0) && (Index <= TestObjectSet.size(SessionID))) 
            {
                CurrentLog.LogDisplay(FAIL,"remove method returned error: " + ((ABTError)RemoveReturnValue).getMessage()); 
            } else                
            {
                CurrentLog.LogWrite(PASS,"remove method returned error: " + ((ABTError)RemoveReturnValue).getMessage()); 
            }                 
            return false; // we didn't remove object
        } else if (ABTErrorHub.isError(RemoveReturnValue)) // ABTErrorHub returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"remove method returned error: " + ((ABTErrorHub)RemoveReturnValue).getMessage()); 
            return false; // we didn't remove object
        } else if (null == RemoveReturnValue) // if null returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"remove method returned null");
            return false; // we didn't remove object
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"remove method did not return ABTObject, ABTError, ABTErrorHub, or null");
            return false; // we didn't remove object
        } // end if-else verification of remove method
        
        return true; // we did remove object
   } // TestRemoveObject(1)

   // This overloaded method(2) calls ABTObjectSet.remove(ABTObject object) 
   // method to "remove" one ABTObject from the currently referenced
   // Object Set
   // Parameters:
   //           ABTObjectSet TestObjectSet - reference to ABTObjectSet 
   //           ABTObject RemoveObject - reference to ABTObject to be removed from ABTObjectSet
   //           Returns integer count of objects removed (if same object referenced more than once in ObjectSet)
   public int TestRemoveObject(ABTObjectSet TestObjectSet, ABTObject RemoveObject)
   {
        ABTValue
            RemoveReturnValue = null; // Return value from remove method
        int
            ObjectSetPtr = 0, // Ptr to matching Object in ObjectSetVector
            ObjectCtr = 0;            

        CurrentLog.LogDisplay(COMMENT,"Removing Object from current Object Set");
        // Test if RemoveObject exists in ObjectSetVector 
        // if so, Remove should be success
        // if not, Remove should fail
        for (ObjectSetPtr = 0; ObjectSetPtr < ObjectSetVector.size(); ObjectSetPtr++)
        {
            if (RemoveObject.equals(((TestObjectElement)ObjectSetVector.elementAt(ObjectSetPtr)).CurrentObject))
                ObjectCtr++;
        } // end for loop                
        // Remove it!
        RemoveReturnValue = TestObjectSet.remove(SessionID,RemoveObject);
        if (RemoveReturnValue instanceof ABTObject) // if ABTObject returned...
        {        
            // If we shouldn't have error, PASS
            if (ObjectCtr > 0)
            {
                CurrentLog.LogWrite(PASS,"remove method success");
            } else // if we should have error, FAIL
            {
                CurrentLog.LogDisplay(FAIL,"remove method returned ABTObject");
                return -1;
            }    
        } else if (ABTError.isError(RemoveReturnValue)) // ABTError returned...
        {
            // If we should have error, PASS
            if (ObjectCtr <= 0)
            {
                CurrentLog.LogWrite(PASS,"remove method returned error: " + ((ABTError)RemoveReturnValue).getMessage()); 
            } else  // If we shouldn't have error, FAIL
            {
                CurrentLog.LogDisplay(FAIL,"remove method returned error: " + ((ABTError)RemoveReturnValue).getMessage()); 
                return -1;
            }                 
            return -1; // we didn't remove object
        } else if (ABTErrorHub.isError(RemoveReturnValue)) // ABTErrorHub returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"remove method returned error: " + ((ABTErrorHub)RemoveReturnValue).getMessage()); 
            return -1;
        } else if (null == RemoveReturnValue) // if null returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"remove method returned null");
            return -1;
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"remove method did not return ABTObject, ABTError, ABTErrorHub, or null");
            return -1;
        } // end if-else verification of remove method
        
        return ObjectCtr;
   } // TestRemoveObject(2)

   // This method calls local methods to verify:
   // ABTObjectSpace.findObject(String Rule, ABTRemoteID ID)
   // ABTObjectSpace.findObject(String Rule, int LocalID)
   // ABTObjectSpace.getObjects(String Rule)
   // all return correct values for all ABTObjects in this Object Space
   // Parameters:
   //           int HowManyObjects - how many ABTObjects of this "type" should exist in Object Space
   public boolean VerifyMultiObjects(int HowManyObjects)
   {
        ABTValue
            ThisObject = null,
            ReturnValue = null;
        ABTID
            ThisObjectID = null;
        ABTObject
            RemoteObject = null,
            LocalObject = null;
        int
            ObjectPtr = 0,
            CurrentRulePtr = 0,
            LocalID = 0;
            
        CurrentLog.LogDisplay(COMMENT,"Verifying findObject and getObject methods for all Objects in space"); 
        for (ObjectPtr = 0; ObjectPtr < HowManyObjects; ObjectPtr++)
        {
            CurrentLog.LogDisplay(COMMENT,"Verifying Object # " + (ObjectPtr+1));
            // Retrieve next object from vector 
            ThisObject = ((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentObject;
            // If this object is ABTObject (not ABTObjectSet or null), and still exists in rowset
            if (ThisObject instanceof ABTObject) 
            {
//                if (true == ThisObject.booleanValue())
                if (true)
                {
                    // Extract Remote ID from this object
                    ThisObjectID = ((ABTObject)ThisObject).getID();
                    if (ThisObjectID != null)
                    {
                        // 8/25/98 - AVP - now the Object Space limits access of 
                        // Objects that have been deleted.  Previously, isDeleted flag was
                        // set to true, no other effect. Now, certain functionality is limited
                        ReturnValue = ThisObjectID.getRemote(SessionID);
                        // If error returned, verify isDeleted
                        if (ABTError.isError(ReturnValue)) 
                        {
                            if (true == ((ABTObject)ThisObject).isDeleted(SessionID))
                            {
                                CurrentLog.LogWrite(PASS,"Object #" + (ObjectPtr+1) + " returned error " + ((ABTError)ReturnValue).getMessage() + " and was deleted");
                            } else     
                            {
                                CurrentLog.LogDisplay(FAIL,"Object #" + (ObjectPtr+1) + " returned error " + ((ABTError)ReturnValue).getMessage() + " but was not deleted");
                            }                            
                        } else
                        {
                            // Verify 2 overloaded findObject methods for each Object 
                            // TEMP - AVP - objects added to objectsets via addnew have
                            // NO Remote ID - don't know if this is right
                            if ((ReturnValue instanceof ABTRemoteID) && (ReturnValue != null))
                            {
                                RemoteObject = GetObjectRemote(((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentRuleType,(ABTRemoteID)ReturnValue,((ABTObject)ThisObject).isDeleted(SessionID));
                                if (RemoteObject == ThisObject)
                                {
                                    CurrentLog.LogWrite(PASS,"RemoteObject with Remote ID = " + ((ABTRemoteIDInteger)ReturnValue).getInt() + " returned matching object from ABTObjectSpace.findObject");
                                } else   
                                {
                                    CurrentLog.LogDisplay(FAIL,"RemoteObject with Remote ID = " + ((ABTRemoteIDInteger)ReturnValue).getInt() + " did NOT return matching object from ABTObjectSpace.findObject");
                                }                        
                            } else // end if Remote ID correctly returned
                            {
                                CurrentLog.LogWrite(COMMENT,"Object #" + (ObjectPtr+1) + " has NO Remote ID");
                            }    
                        } // end if Remote ID did NOT generate error                  
                        // TEMP - AVP - 8/25 - try with ABTId instead of local int ID
    //                    LocalObject = GetObjectLocal(((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentRuleType,ThisObjectID.getLocal());
                        LocalObject = GetObjectLocal(((TestObjectElement)ObjectVector.elementAt(ObjectPtr)).CurrentRuleType,ThisObjectID,((ABTObject)ThisObject).isDeleted(SessionID));
                        if (LocalObject == ThisObject)
                        {
                            if (false == ((ABTObject)ThisObject).isDeleted(SessionID))
                            {
                                CurrentLog.LogWrite(PASS,"LocalObject with Local ID = " + ThisObjectID.getLocal() + " returned matching object from ABTObjectSpace.findObject");
                            } else
                            {
                                CurrentLog.LogDisplay(FAIL,"LocalObject with Local ID = " + ThisObjectID.getLocal() + " did returned matching object from ABTObjectSpace.findObject, even though deleted");
                            }    
                        } else if (LocalObject == null) // if unable to find object  
                        {
                            if (true == ((ABTObject)ThisObject).isDeleted(SessionID))
                            {
                                CurrentLog.LogWrite(PASS,"LocalObject with Local ID = " + ThisObjectID.getLocal() + " did not return matching object from ABTObjectSpace.findObject, because Object is deleted");
                            } else
                            {
                                CurrentLog.LogDisplay(FAIL,"LocalObject with Local ID = " + ThisObjectID.getLocal() + " did not return matching object from ABTObjectSpace.findObject");
                            } 
                        }  else // not null, but did not match
                        {
                            CurrentLog.LogDisplay(FAIL,"LocalObject with Local ID = " + ThisObjectID.getLocal() + " did not return matching object from ABTObjectSpace.findObject");
                        }    
                    } else // no valid Object ID for Object
                    {
                        if (true == ((ABTObject)ThisObject).isDeleted(SessionID))
                        {                        
                           CurrentLog.LogDisplay(PASS,"Object # " + (ObjectPtr+1) + " returned null Object ID for deleted Object");
                        } else                                                       
                        {
                           CurrentLog.LogDisplay(FAIL,"Object # " + (ObjectPtr+1) + " returned null Object ID for deleted Object");
                        }                            
                    }    
                } // if ABTObject row no longer valid
            } else // if NOT ABTObject, advance upper limit 
            {
                HowManyObjects++; // Advance limit
            }    
        } // end for loop for all objects
        // Verify getObjects of each rule type returns Object Set of correct size
        if (false == VerifyGetObjects())
            return false;

        return true;
   } // VerifyMultiObjects 
   
   // This method calls method ABTObjectSpace.getObjects(String rule) to verify:
   // Object Set of correct size is returned for each rule type
   // Parameters:  none
   public boolean VerifyGetObjects()
   {
        ABTValue
            ReturnObjectSet = null; // return value from getobjects method
        // true if object set size is as expected for each rule type
        // set to false for any error, incorrect value or return type, for any rule type
        boolean
            ReturnResult = true; 
                                
        // Use ABTObjectSpace.getObjects to extract an Object Set containing all Objects/ObjectSets of this RuleType
        for (CurrentRulePtr = 0; CurrentRulePtr < RuleVector.size(); CurrentRulePtr++)
        {
            ReturnObjectSet = CurrentSpace.getObjects(SessionID,((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType);
            if (ReturnObjectSet instanceof ABTObjectSet)
            {
                if (((ABTObjectSet)ReturnObjectSet).size(SessionID) == ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentObjectCount) // returns expected objectset, success
                {
                    CurrentLog.LogWrite(PASS,"ABTObjectSpace.getObjects method returns correct # of objects, " +  ((ABTObjectSet)ReturnObjectSet).size(SessionID) + ", for " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType);
                } else // not equal, failure
                {
                    CurrentLog.LogDisplay(FAIL,"ABTObjectSpace.getObjects method returns " + ((ABTObjectSet)ReturnObjectSet).size(SessionID) + " instead of " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentObjectCount + ", for " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType);
                    ReturnResult = false;
                }    
            } else if (ABTError.isError(ReturnObjectSet)) // returned ABTError, failure
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSpace.getObjects method returned error: " + ((ABTError)ReturnObjectSet).getMessage()); 
                ReturnResult = false;
            } else if (null == ReturnObjectSet) // returns null, failure
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSpace.getObjects method returned null for " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType);
                ReturnResult = false;
            } else // default else, failure
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSpace.getObjects method did not return ABTObjectSet, ABTError, or null for " + ((TestRuleElement)RuleVector.elementAt(CurrentRulePtr)).CurrentRuleType);
                ReturnResult = false;
            } // end if-else for getObjects return value    
        } // end for loop for RulePtr
        
        return ReturnResult;
   } // VerifyGetObjects        
   
   // This method calls local methods,
   // which verify that ABTObjectSetEnumerator:
   // can be instantiated
   // performs nextElement correctly
   // performs hasMoreElements correctly
   // This enumerator is unsorted
   // Parameters:
   //           ABTObjectSet TestObjectSet - ObjectSet to enumerate
   public boolean VerifyEnumeration(ABTObjectSet TestObjectSet)
   {
        Enumeration
            TestEnum = null;
        boolean
            EnumResult = false;
        
        // Instantiate enumerator - ABTObjectSet.elements()
        TestEnum = GetObjectSetEnum(TestObjectSet);
        // If we could not get enumerator, return failure
        if (null == TestEnum)
            return false;
        // Verify ABTObjectSetEnumerator.nextElement            
        // Verify ABTObjectSetEnumerator.hasmoreElements
        // (same method for both tests, since so simple)
        EnumResult = TestObjectSetEnum(TestObjectSet, TestEnum);
        
        return EnumResult;
   } // VerifyEnumeration
   
   // This method calls the ABTObjectSet.elements() method,
   // which should return an instantation of ABTObjectSetEnumerator
   // This enumerator is unsorted
   // Parameters:
   //           ABTObjectSet TestObjectSet - ObjectSet to enumerate
   // Returns:
   //           Enumeration, if success
   //           null, if fail
   public Enumeration GetObjectSetEnum(ABTObjectSet TestObjectSet)
   {
        Enumeration
            EnumReturnValue = null;
            
        EnumReturnValue = TestObjectSet.elements(SessionID);
        // If Enumerator reference returned, success
        if (EnumReturnValue instanceof Enumeration) 
        {        
           CurrentLog.LogWrite(PASS,"ABTObjectSet.elements method success");
        } else if (ABTError.isError(EnumReturnValue)) // ABTError returned...
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.elements method returned error: " + ((ABTError)EnumReturnValue).getMessage()); 
            return null;
        } else if (ABTErrorHub.isError(EnumReturnValue)) // ABTErrorHub returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.elements method returned error: " + ((ABTErrorHub)EnumReturnValue).getMessage()); 
            return null;
        } else if (null == EnumReturnValue) // if null returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.elements method returned null");
            return null;
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSet.elements method did not return ABTObjectSetEnum, ABTError, ABTErrorHub, or null");
            return null;
        } // end if-else verification of elements method
        
        return (Enumeration)(EnumReturnValue);            
   } // GetObjectSetEnum

   // This method verifies:
   // ABTObjectSetEnumerator.nextElement for entire enumerator (calling local method)
   // ABTObjectSetEnumerator.hasMoreElements
   // This enumerator is unsorted
   // This method assumes that enumerator has been successfully instantiated
   // and enumerator has not yet called nextElement
   // Parameters:
   //           ABTObjectSet TestObjectSet - ObjectSet that was enumerated
   //           ABTObjectSetEnumerator - instantiation of enumerator
   public boolean TestObjectSetEnum(ABTObjectSet TestObjectSet, Enumeration TestEnum)
   {
        // Return value from TestObjectSetEnumNextElement
        int
            NextEnumIndex = NotIndex;
        // Return value for this method
        boolean
            NextEnumResult = true;
        // Array of boolean values, matching size of ABTObjectSet
        // True = ABTObject at this index was found by ABTObjectSetEnumerator.nextElement
        // False = ABTObject at this index was NOT found by ABTObjectSetEnumerator.nextElement
        // Initialize IndexFoundArray with "false"
        boolean [] IndexFoundArray = new boolean[TestObjectSet.size(SessionID)];
         
        for (int ArrayPtr = 0; ArrayPtr < TestObjectSet.size(SessionID); ArrayPtr++)
        {
            IndexFoundArray[ArrayPtr] = false;
        }    
        
        while (true == TestEnum.hasMoreElements())
        {
            // Return Index of next ABTObject in ABTObjectSet, using ABTObjectSetEnumerator.nextElement
            NextEnumIndex = TestObjectSetEnumNextElement(TestObjectSet,TestEnum);
            // If nextelement not found in ABTObjectSet, flag failure
            if (NotIndex == NextEnumIndex)
            {
                NextEnumResult = false;
            } else // if found, test that it is not dupe (has not been found before in this loop)
            {
                // if nextelement has not returned this index before
                if (false == IndexFoundArray[NextEnumIndex])
                {
                    IndexFoundArray[NextEnumIndex] = true;
                }
                else // if nextelement returned this index before
                {
                    CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement returned object at Index " + NextEnumIndex + " more than once");
                    NextEnumResult = false;
                }    
            } // end "else" (if Index found by nextelement)    
        } // end while loop     
        // loop through and make sure no objects were missed by nextelement
        for (int ArrayPtr = 0; ArrayPtr < TestObjectSet.size(SessionID); ArrayPtr++)
        {
            if (false == IndexFoundArray[ArrayPtr])
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement never referenced Index #" + ArrayPtr);
                NextEnumResult = false;
            }                 
        }    
        
        return NextEnumResult;
   } // TestObjectSetEnum
   
   // This method verifies 1 call to ABTObjectSetEnumerator.nextElement as follows:
   // returns instance of ABTObject
   // return ABTObject which exists in ABTObjectSet
   // Parameters:
   //           ABTObjectSet TestObjectSet - ObjectSet that was enumerated
   //           ABTObjectSetEnumerator - instantiation of enumerator
   // Returns:
   //           NotIndex (-1) if failure
   //           numeric reference to placement of ABTObject in ABTObjectSet, if success
   public int TestObjectSetEnumNextElement(ABTObjectSet TestObjectSet, Enumeration TestEnum)
   {
        Object
            NextEnumObject = null;
        int
            ThisIndex = NotIndex;
    
        NextEnumObject = TestEnum.nextElement();
        // If ABTObject reference returned...
        if (NextEnumObject instanceof ABTObject)
        {    
            // if ABTObject exists in ABTObjectSet...
            if (true == TestObjectSet.contains(SessionID,(ABTObject)NextEnumObject))
            {
                // Find and retain Index in ABTObjectSet
                for (int ObjectSetPtr = 0; ObjectSetPtr < TestObjectSet.size(SessionID); ObjectSetPtr++)
                {
                    // Break when we have a match
                    if (((ABTObject)TestObjectSet.at(SessionID,ObjectSetPtr)).equals(NextEnumObject)) 
                    {
                        ThisIndex = ObjectSetPtr;
                        break;
                    }                        
                } // end for loop
                // If we found it in loop
                if (ThisIndex != NotIndex)
                {
                    CurrentLog.LogWrite(PASS,"Next Element returned Index of " + ThisIndex);    
                } else // if we didn't find Object in ObjectSet
                {
                    // This should NEVER happen, unless bug in ABTObjectSet.at or ABTObjectSet.contains
                    CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement method returned ABTObject which was verified in ABTObjectSet.contains, but was not found in loop");
                }    
            } else // if ABTObject NOT in ABTObjectSet, fail
            {
                CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement method returned ABTObject which did not exist in specified Object Set");
            }    
        } else if (ABTError.isError(NextEnumObject)) // ABTError returned...
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement method returned error: " + ((ABTError)NextEnumObject).getMessage()); 
        } else if (null == NextEnumObject) // if null returned, fail
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement method returned null");
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"ABTObjectSetEnumerator.nextElement method did not return ABTObject, ABTError, or null");
        } // end if-else verification of elements method
           
        return ThisIndex;
   } // GetObjectSetEnumerator
   

   public boolean TestClearVerifyObjectSet(ABTObjectSet TestObjectSet)
   {
      TestObjectElement
        RemovedObjectElement = null;
      boolean
        ObjectCleared = false;
        
      // Remove specified Object from Object Set
      ObjectCleared = TestClearObjectSet(TestObjectSet);
      // If there is no object left in ObjectSetVector,
      // "dummy" with object from ObjectVector
      if (ObjectSetVector.size() > 0)
      {
          RemovedObjectElement = (TestObjectElement)ObjectSetVector.elementAt(0);
      } else
      {
        // KLUGE:  just point at an object, hardcoded here, that I know I have not added
        // to object set
          RemovedObjectElement = (TestObjectElement)ObjectVector.elementAt(18);
      }             
      // If clear occurred successfully:
      // Verify ObjectSet changed
      // Clear ObjectSetVector
      if (true == ObjectCleared) 
      {
          // Set size to 1 (so verifyremovedobject understands that vector is about to be cleared)
          ObjectSetVector.setSize(1);
          // Verify state of Object Set after Clear
          VerifyRemovedObject(TestObjectSet, 1, RemovedObjectElement, false);      
          // Clear ObjectSetVector
          ObjectSetVector.removeAllElements();
      } else // end if we removed object              
      {
        // KLUGE:  just point at an object, hardcoded here, that I know I have not added
        // to object set
          RemovedObjectElement = (TestObjectElement)ObjectVector.elementAt(18);
      } 
      // Verify Object Set now matches ObjectSetVector
      VerifyRemovedObject(TestObjectSet, 1, RemovedObjectElement, true);      
    
      return true;      
   } // TestClearVerifyObjectSet 
   
   // This method calls ABTObjectSet.clear, which in turn calls the
   // ABTRule.onClear 
   // If no rules invoked, Clear Set will 
   public boolean TestClearObjectSet(ABTObjectSet TestObjectSet)
   {
    
        TestObjectSet.clear(SessionID);
        
        return true;
   } // TestClearObjectSet 
   
   
} // TestObjectPopulation

// These classes are used to reference elements in Vectors of
// ABTObjects with ABTObjectSpace, ABTObjects with ABTObjectSet
// ABTRules

// Each element in the ObjectVector or ObjectSetVector
// will contain a reference to an ABTObject or ABTObjectSet,
// a flag indicating whether deleted, and String of rule type
class TestObjectElement extends Object
{
    public ABTObject
        CurrentObject = null;
    public ABTObjectSet
        CurrentObjectSet = null;
    public boolean
        CurrentDeleteStatus = false;
    public String
        CurrentRuleType = null;

    // TestObjectElement constructor, overloaded for ABTObject
    // Parameters:
    //          ABTObject AddObject - Reference to Object being added to Object Space
    //          boolean DeleteFlag - Deleted Status of this Object
    //          String RuleType - Rule "type" specified when creating this Object
    TestObjectElement(ABTObject AddObject, boolean DeleteFlag, String RuleType)
    {
        CurrentObjectSet = null;
        CurrentObject = AddObject;
        CurrentDeleteStatus = DeleteFlag;
        CurrentRuleType = RuleType;
    } // TestObjectElement constructor(1)

    // TestObjectElement constructor, overloaded for ABTObjectSet
    //          ABTObjectSet AddObjectSet - Reference to ObjectSet being added to Object Space
    //          boolean DeleteFlag - Deleted Status of this ObjectSet
    //          String RuleType - Rule "type" specified when creating this ObjectSet
    TestObjectElement(ABTObjectSet AddObjectSet, boolean DeleteFlag, String RuleType)
    {
        CurrentObject = null;
        CurrentObjectSet = AddObjectSet;
        CurrentDeleteStatus = DeleteFlag;
        CurrentRuleType = RuleType;
    } // TestObjectElement constructor(2)

} // TestObjectElement

// Each element in the RuleVector
// will contain a string ruletype
// and a count of how many ABTObjects created for that ruletype
class TestRuleElement extends Object
{
    public String
        CurrentRuleType = null;
    public int
        CurrentObjectCount = 0;

    // TestRuleElement constructor
    // Parameters:
    //          String RuleType - Rule "type" that exists in default package
    TestRuleElement(String RuleType)
    {
        // Start with none created yet
        CurrentObjectCount = 0;
        CurrentRuleType = RuleType;
    } // TestRuleElement constructor

} // TestRuleElement

