import com.abtcorp.io.*;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.parser.*;
// AVP - 7/26 - TestEng "library" package - currently LogFile and ReadFile
import TestLib.*; 

import java.util.Enumeration;
import java.util.Date;
import java.util.Calendar;
import java.util.Vector;
import java.lang.reflect.*;
import java.io.*;

// This class was created to facilitate testing of object session handling
// - Instantiate ABTObjectSpace
// - Open and close multiple Sessions with
//   additions:
//      ABTObjectSpace.createObject
//      ABTObjectSpace.createObjectSet
//      ABTObjectSet.addNew
//   modify:
//      ABTObject.setValue(4)
//      ABTObject.delete
//      ABTObjectSet.clear
//      ABTObjectSet.remove(2)
//      ABTObjectSet.add
//   verify:
//      ABTObjectSpace.getObject
//      ABTObjectSpace.findObjects(3)
//      ABTObject.isDeleted
//      ABTObject.getValue(4)
//      ABTObjectSet.isEmpty
//      ABTObjectSet.size
//      ABTObjectSet.isDeleted
//      ABTObjectSet.back
//      ABTObjectSet.front
//      ABTObjectSet.at
public class TestSessions implements ILogType //, IABTMMRuleConstants
{
   ABTUserSession
        SessionID = null;

   // Object Space to be created 
   ABTObjectSpace CurrentSpace = null; 
   // TestObjectPopulation object to be used for populating ObjectSpace
   TestObjectPopulation ObjPop = null;
   // TestValues object to be used for setting and getting property values
   TestValues Values = null;
   // For logging test results (diagnostics)
   LogFile CurrentLog = null;
   // Vector of Sessions
   Vector SessionVector = null;
   // counter for Current ABTObject, Current rule type, Remote ID
   int
       CurrentObjectPtr = 0,
       CurrentRulePtr = 0,
       CurrentRemoteID = 0,
       // special negative return value when no Index found
       // TODO:  should be pre-defined in interface
       NotIndex = -1;
       
   // Constructor
   // Parameters:
   //           LogFile log - Reference to logfile to record diagnostics
   public TestSessions(LogFile log) throws ABTException
   {
        CurrentLog = log;
        CurrentRemoteID = 0;
        // Instantiate Vector of Session IDs
        SessionVector = new Vector(10);
        // Instantiate object which contains Values test methods
        Values = new TestValues(log);
   } // TestSessions constructor
   
   // This method should be called immediately after constructor
   // Calls method which instantiate ObjectSpace 
   // Calls methods which perform Session testing
   // Parameters:
   //           int HowManySessions - How many Sessions to open during testing
   public void populate (int HowManySessions, int HowManyObjects)
   {
      CurrentLog.LogWrite(COMMENT,"STARTING Session testing in TestSession");
      // 1 loop - open, perform mods and adds, close 
      TestDifferent1(HowManySessions,HowManyObjects); 
      // 3 separate loops - open all, perform mods and adds on all, close all
  //    TestDifferent3(HowManySessions,HowManyObjects); 
      // 1 loop - open, perform dupe mods and adds, close
//      TestSame1(HowManySessions,HowManyObjects);
      CurrentLog.LogDisplay(COMMENT,"Testing Complete");
   } // populate
   
   // This method will test the following in 1 loop:
   //   Open 1 Session
   //   Perform different adds and mods 
   //   Verify all adds and mods so far
   //   Close Session
   // for each Session requested
   //   Parameters:
   //           int HowManySessions - how many Sessions to loop through
   //           int HowManyObjects - how many Objects to create in 1 Session
   public boolean TestDifferent1(int HowManySessions, int HowManyObjects)
   {
     // Return values from CreateMultiObjects, DeleteObjects
     boolean
        TestObjectReturn = false,
        TestObjectSetReturn = false,
        TestDeleteReturn = false;
     ABTObject  
        firstObject = null,
        lastObject = null;
        
      CurrentLog.LogDisplay(COMMENT,"Testing 1 loop - open, mod, close, for each Session");
      // Create Object Population object for this test
      try {
        // Create Object Space
        CurrentSpace = new ABTObjectSpace();
        ObjPop = new TestObjectPopulation(CurrentLog);
      } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception trying to instantiate test object TestObjectPopulation");
        CurrentLog.LogDisplay(FAIL,"TestDifferent1 Testing terminated due to Java exception");
        return false;
      }
      // Reference local ABTObjectSpace in ObjectPopulation test object
      ObjPop.setCurrentSpace(CurrentSpace);
      // Clear out Session vector
      SessionVector.removeAllElements();
      // Loop through all requested Sessions
      for (int SessionPtr = 0; SessionPtr < HowManySessions; SessionPtr++)
      {
          CurrentLog.LogDisplay(COMMENT,"Testing Session # " + (SessionPtr+1));
          // Open this Session
          TestOpenSession();
          // Perform Object Population in this Session
          // Reference local ABTObjectSpace in ObjectPopulation test object
          ObjPop.setCurrentSpace(CurrentSpace);
          // Reference current Session ID, in all instantiated objects
          SessionID = (ABTUserSession)SessionVector.elementAt(SessionPtr);
          ObjPop.setCurrentSession(SessionID);
          Values.setCurrentSession(SessionID);
          // Test Creating multiple ABTObjects in object space
          TestObjectReturn = ObjPop.CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECT);
          // Test Creating multiple ABTObjectSets in object space
          TestObjectSetReturn = ObjPop.CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECTSET);
          // If Objects were created successfully
          if ((true == TestObjectReturn) && (true == TestObjectSetReturn))  
          {
              // reference first Object in OS - always the same for all sessions
              firstObject = ObjPop.getTestObject(0);
              // reference last ABTObject added - increases with each session (crazy math - sorry)
              lastObject = ObjPop.getTestObject((HowManyObjects*2+100+1) * (SessionPtr) + HowManyObjects - 1);
              // Verify contents of Objects
              ObjPop.VerifyMultiObjects((HowManyObjects+100+1) * (SessionPtr) + HowManyObjects);
              // Test Setting and Getting Values 
              // (If deleted - can't set the values)
              Values.SetVerifyValues(firstObject,1);
              Values.SetVerifyValues(lastObject,1);
              // If we have created successfully, call various methods to delete and verify different objects
              // This method also calls methods which populate ObjectSets, then test delete and remove from ObjectSet
              TestDeleteReturn = ObjPop.TestDeleteObjects(HowManyObjects,HowManyObjects+SessionPtr*2+1);
              CurrentLog.LogTotals(); // display and log total pass/fail so far
              if (true == TestDeleteReturn) 
              {
                  // Verify that ABTObjects can still be found, after all additions and deletions and removals
                  ObjPop.VerifyMultiObjects((HowManyObjects+100+1) * (SessionPtr+1));
              } // end if Deletes were successfull                  
              // Test Getting Values - verify earlier setValues
              Values.GetVerifyValues(firstObject,1);
              Values.GetVerifyValues(lastObject,1);
              // Test resetting Values for same Objects
              Values.SetVerifyValues(firstObject,1001);
              Values.SetVerifyValues(lastObject,1001);
              // Verify reset Values
              Values.GetVerifyValues(firstObject,1001);
              Values.GetVerifyValues(lastObject,1001);
              CurrentLog.LogTotals(); // display and log total pass/fail so far
          } // end if Objects and ObjectSets created successfully          
          // Close this Session
          TestCloseSession(SessionPtr);
          CurrentLog.LogTotals(); // display and log total pass/fail so far
      } // end SessionPtr for loop
      
      return ((TestObjectReturn) && (TestObjectSetReturn) && (TestDeleteReturn));
   } // TestDifferent1

   // This method will test the following in 1 loop:
   //   Open 1 Session
   //   Perform same adds and mods (each time)
   //   Verify all adds and mods so far
   //   Close Session
   // for each Session requested
   //   Parameters:
   //           int HowManySessions - how many Sessions to loop through
   //           int HowManyObjects - how many Objects to create in 1 Session
   public boolean TestSame1(int HowManySessions, int HowManyObjects)
   {
     // Return values from CreateMultiObjects, DeleteObjects
     boolean
        TestObjectReturn = false,
        TestObjectSetReturn = false,
        TestDeleteReturn = false;
        
      CurrentLog.LogDisplay(COMMENT,"Testing 1 loop - open, mod, close, for each Session");
      // Create Object Population object for this test
      try {
        // Create Object Space
        CurrentSpace = new ABTObjectSpace();
        ObjPop = new TestObjectPopulation(CurrentLog);
      } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception trying to instantiate test object TestObjectPopulation");
        CurrentLog.LogDisplay(FAIL,"TestDifferent1 Testing terminated due to Java exception");
        return false;
      }
      // Reference local ABTObjectSpace in ObjectPopulation test object
      ObjPop.setCurrentSpace(CurrentSpace);
      // Clear out Session vector
      SessionVector.removeAllElements();
      // Loop through all requested Sessions
      for (int SessionPtr = 0; SessionPtr < HowManySessions; SessionPtr++)
      {
          CurrentLog.LogDisplay(COMMENT,"Testing Session # " + (SessionPtr+1));
          // Open this Session
          TestOpenSession();
          // Perform Object Population in this Session
          // Reference local ABTObjectSpace in ObjectPopulation test object
          ObjPop.setCurrentSpace(CurrentSpace);
          // Reference current Session ID, in all instantiated objects
          SessionID = (ABTUserSession)SessionVector.elementAt(SessionPtr);
          ObjPop.setCurrentSession(SessionID);
          Values.setCurrentSession(SessionID);
          // Since duplicating Remote ID, start at 0 each Session
          CurrentRemoteID = 0;
          // Test Creating multiple ABTObjects in object space
          TestObjectReturn = ObjPop.CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECT);
          // Test Creating multiple ABTObjectSets in object space
          TestObjectSetReturn = ObjPop.CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECTSET);
          // If Objects were created successfully
          if ((true == TestObjectReturn) && (true == TestObjectSetReturn))  
          {
              // Verify contents of Objects
              // Because of dupe Remote ID, new Objects aren't actually added with each Session
              ObjPop.VerifyMultiObjects(HowManyObjects);
              // Test Setting and Getting Values - same Object each Session
//              Values.SetVerifyValues(ObjPop.getTestObject(1),1);
              // If we have created successfully, call various methods to delete and verify different objects
              // This method also calls methods which populate ObjectSets, then test delete and remove from ObjectSet
              CurrentLog.LogTotals(); // display and log total pass/fail so far
              // Test Deleting same Objects in each Session
              ObjPop.TestDeleteMultiObjects(20,5,1);
              // Test populating and deleting from within same ObjectSet each Session
              TestDeleteReturn = ObjPop.TestDeleteFromObjectSet(HowManyObjects,HowManyObjects+1);
              if (true == TestDeleteReturn)
              {
                  CurrentLog.LogDisplay(COMMENT,"Testing ABTObjectSet Remove functionality");
                  // Test Removing from same Object Set each Session
                  TestDeleteReturn = ObjPop.TestRemoveFromObjectSet(HowManyObjects,HowManyObjects+1);
              }            
              if (true == TestDeleteReturn) 
              {
                  // Verify that ABTObjects can still be found, after all additions and deletions and removals
                  // Since dupe Remote ID was used, only the original set are created
                  // Then, additions to ObjectSets are added in each Session
                  ObjPop.VerifyMultiObjects(HowManyObjects + 100);
              } // end if Deletes were successfull                  
              // Test Getting Values - verify earlier setValues
//              Values.GetVerifyValues(ObjPop.getTestObject(1),1);
              // Test resetting Values for same Object
  //            Values.SetVerifyValues(ObjPop.getTestObject(1),1001);
              CurrentLog.LogTotals(); // display and log total pass/fail so far
          } // end if Objects and ObjectSets created successfully          
          // Close this Session
          TestCloseSession(SessionPtr);
          CurrentLog.LogTotals(); // display and log total pass/fail so far
      } // end SessionPtr for loop
      
      return ((TestObjectReturn) && (TestObjectSetReturn) && (TestDeleteReturn));
   } // TestSame1

   // This method will test the following, in 3 loops:
   // Loop 1: Open all Sessions 
   // Loop 2: Perform different adds and mods in each Session and
   //         verify mods and adds in all Sessions so far
   // Loop 3: Close all Sessions
   public boolean TestDifferent3(int HowManySessions, int HowManyObjects)
   {
     // Return values from CreateMultiObjects
     boolean
        TestObjectReturn = false,
        TestObjectSetReturn = false,
        TestDeleteReturn = false;
            
      CurrentLog.LogDisplay(COMMENT,"Testing 3 Separate loops - open all, mod all, close all");
      // Create Object Population object for this test
      try {
        // Create Object Space
        CurrentSpace = new ABTObjectSpace();
        ObjPop = new TestObjectPopulation(CurrentLog);
      } catch (Exception e) {
        CurrentLog.LogDisplay(FAIL,"Exception trying to instantiate test object TestObjectPopulation");
        CurrentLog.LogDisplay(FAIL,"TestDifferent3 Testing terminated due to Java exception");
        return false;
      }
      // Reference local ABTObjectSpace in ObjectPopulation test object
      ObjPop.setCurrentSpace(CurrentSpace);
      // Clear out Session vector
      SessionVector.removeAllElements();
      // Loop through all requested Sessions
      for (int SessionPtr = 0; SessionPtr < HowManySessions; SessionPtr++)
      {
          TestOpenSession();
      }            
      // Perform Object Population in each open Session
      for (int SessionPtr = 0; SessionPtr < HowManySessions; SessionPtr++)
      {
          CurrentLog.LogDisplay(COMMENT,"Testing Session # " + (SessionPtr+1));
          // Reference current Session ID, in all instantiated objects
          SessionID = (ABTUserSession)SessionVector.elementAt(SessionPtr);
          ObjPop.setCurrentSession(SessionID);
          Values.setCurrentSession(SessionID);
          // Test Creating multiple ABTObjects in object space
          TestObjectReturn = ObjPop.CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECT);
          // Test Creating multiple ABTObjectSets in object space
          TestObjectSetReturn = ObjPop.CreateMultiObjects(HowManyObjects,ABTProperty.PROP_OBJECTSET);
          // If Objects were created successfully
          if ((true == TestObjectReturn) && (true == TestObjectSetReturn))  
          {
              // Verify contents of Objects
              ObjPop.VerifyMultiObjects(HowManyObjects * (SessionPtr+1));
              // Test Setting and Getting Values 
              Values.SetVerifyValues(ObjPop.getTestObject(SessionPtr * HowManyObjects * 2),1);
              // If we have created successfully, call various methods to delete and verify different objects
              // This method also calls methods which populate ObjectSets, then test delete and remove from ObjectSet
              TestDeleteReturn = ObjPop.TestDeleteObjects(HowManyObjects,HowManyObjects+SessionPtr*2+1);
              CurrentLog.LogTotals(); // display and log total pass/fail so far
              if (true == TestDeleteReturn) 
              {
                  // Verify that ABTObjects can still be found, after all additions and deletions and removals
                  ObjPop.VerifyMultiObjects((HowManyObjects+100) * (SessionPtr+1));
              } // end if Deletes were successfull                  
              // Test Getting Values - verify earlier setValues
              Values.GetVerifyValues(ObjPop.getTestObject(SessionPtr * HowManyObjects * 2),1);
              // Test resetting Values for same Object
              Values.SetVerifyValues(ObjPop.getTestObject(SessionPtr * HowManyObjects * 2),1001);
              CurrentLog.LogTotals(); // display and log total pass/fail so far
          } // end if Objects and ObjectSets created successfully          
          CurrentLog.LogTotals(); // display and log total pass/fail so far
      } // end SessionPtr for loop
      // Close all requested Sessions consecutively
      for (int SessionPtr = 0; SessionPtr < HowManySessions; SessionPtr++)
      {
          TestCloseSession(SessionPtr);
          // if we still have open Sessions
          if (SessionPtr < HowManySessions - 1)
          {
              // Reference current Session ID, in all instantiated objects
              SessionID = (ABTUserSession)SessionVector.elementAt(SessionPtr);
              ObjPop.setCurrentSession(SessionID);
              Values.setCurrentSession(SessionID);
              // Verify contents of all Objects
              ObjPop.VerifyMultiObjects((HowManyObjects+100) * (HowManySessions));
              // Test Getting Values - verify earlier setValues
              Values.GetVerifyValues(ObjPop.getTestObject(SessionPtr * HowManyObjects * 2),1001);
          } // end if Sessions still open
      } // end close Session loop
      CurrentLog.LogTotals(); // display and log total pass/fail so far
      
      return ((TestObjectReturn) && (TestObjectSetReturn) && (TestDeleteReturn));
   } // TestDifferent3 

   // This method opens a new Session by calling ABTObjectSpace.openSession
   // AVP - 7/31 (hashtable parameter currently null - will later contain user/password)
   // The unique Session ID is then stored in the local Vector SessionVector
   public boolean TestOpenSession()
   {
        SessionID = CurrentSpace.startSession(null);
        SessionVector.addElement(SessionID);
        
        return true;
   } // TestOpenSession

   // This method closes a previously opened Session by calling ABTObjectSpace.endSession
   // Parameters:
   //           int SessionPtr - element in Session Vector to access
   public boolean TestCloseSession(int SessionPtr)
   {
        SessionID = (ABTUserSession)SessionVector.elementAt(SessionPtr);
        CurrentSpace.endSession(SessionID);
        
        return true;
   } // TestCloseSession

} // TestSessions