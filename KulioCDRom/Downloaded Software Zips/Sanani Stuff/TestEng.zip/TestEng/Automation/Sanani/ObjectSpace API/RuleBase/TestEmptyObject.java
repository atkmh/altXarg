package com.abtcorp.objectModel;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;

// AVP - 7/27/98 - 7/15 BUILD Added logic for the following:
// Methods now declared abstract in ABTRule, added "empty" rules here

// The purpose is to create a generic "empty" object (except for default property
// added in super constructor), for low-level mechanical testing of
// ObjectSpace API
// There are no actual rules invoked for this object, no Rule methods overridden
// (other than empty SetDefault below)
// Empty object 1 of 2
public class TestEmptyObject extends TestObject
{
    public TestEmptyObject()
    {
      super();
    }

    protected void setDefaultProperties()
    {
        // Start with empty setDefaultProperties
    }

  /**
   * return true if strong type checking on >onADD< should be used
   * @return boolean - true if new ABTObject have to be of the same rule type
   */
  protected boolean enforceType ()
  {
    return true;
  }

  /**
   * return true if uniqueness >onADD< should be enforced
   * @return boolean - true if new ABTObject have to be unique 
   */
  protected boolean enforceUniqueness ()
  {
    return true;
  }


} // TestEmptyObject






