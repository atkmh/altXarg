package com.abtcorp.objectModel;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;

// The purpose is to create a generic object pre-populated with default properties,
// for low-level mechanical testing of ObjectSpace API
// This rule is the "base" from which my other rules are extended
public abstract class TestObject extends com.abtcorp.hub.ABTRule
{
    public TestObject()
    {
      super();
    }

    // Empty rules
    protected ABTValue onGet (ABTUserSession session,ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters)
    {
        return myValue;
    }  
    protected ABTValue onGet (ABTUserSession session,ABTObjectSet parent, ABTObject myValue, int myIndex, ABTHashtable parameters)
    {
        return myValue;
    }  
    protected ABTValue isValid (ABTUserSession session,ABTObjectSet parent, ABTValue myValue, ABTHashtable parameters)
    {
        return new ABTBoolean(true);
    }  
    protected ABTValue onSet (ABTUserSession session,ABTObject parent, ABTProperty property,  ABTValue myValue, ABTValue newValue, ABTHashtable parameters)
    {
        return newValue;
    }  
    protected ABTValue onInitialize (ABTUserSession session, ABTObject parent, ABTProperty property,  ABTValue myValue, ABTHashtable parameters)
    {
        return myValue;
    }  
    protected ABTValue onAdd (ABTUserSession session,ABTObjectSet parent, ABTValue newValue,boolean existing)
    {
       return parent.addToSet(session,newValue,existing);
    }  
    protected ABTValue onDelete (ABTUserSession session,ABTObject parent)
    {
       return deleteObject(session,parent);
    }  
    protected ABTValue onRemove (ABTUserSession session,ABTObjectSet parent,  ABTValue myValue,int myIndex)
    {
       return parent.removeFromSet(session,myValue,myIndex);
    }  
    protected ABTValue onClear (ABTUserSession session,ABTObjectSet parent)
    {
       return parent.clearSet(session);
    }  
    protected ABTError notifyReferenceSet (ABTUserSession session,ABTObjectSet parent, IABTReferenceSource child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue )
    {
        return null;
    }  
    public ABTError notifyReferenceDelete (ABTUserSession session,ABTObjectSet parent, IABTReferenceSource child)
    {
        return null;
    }  
    protected ABTValue onInitialize ( ABTUserSession session,ABTObject object,ABTHashtable requiredParameters)
    {
        return null;
    }  
    
   /**
    * Notification of a delete operation on an object referenced in this property.
    *
    * @param session  - The session object for transaction support
    * @param parent   - The object containing this object as a property
    * @param child    - The object currently referenced in this property
    *
    * @return null if allowed, ABTError if rejected.
    */
   public ABTError notifyReferenceDelete( ABTUserSession session, ABTObjectSet parent, IABTReferenceSource child, boolean dirty )
   {
      return null;
   }

   /**
    * Notification of a set operation in an element of the object set stored
    * in this object set.  This notification is activated by setting the flag
    * <code>notifySet</code> in the rule constructor to <code>true</code>.
    *
    * @param session        - The session object for transaction support
    * @param parent         - The object set containing this object as an element
    * @param child          - The object in the childset which was modified
    * @param childProperty  - The property modified
    * @param oldValue       - The old value in the child property
    * @param newValue       - The new value in the child property
    *
    * @return null if allowed, ABTError if rejected.
    */
   protected ABTError notifyReferenceSet( ABTUserSession session, ABTObjectSet parent, IABTReferenceSource child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue, boolean dirty )
   {
      return null;
   }

   public boolean enforceThisType()
   {
        return enforceType();
   }             
   
   public boolean enforceThisUniqueness()
   {
        return enforceUniqueness();
   }             


} // TestFullObject1






