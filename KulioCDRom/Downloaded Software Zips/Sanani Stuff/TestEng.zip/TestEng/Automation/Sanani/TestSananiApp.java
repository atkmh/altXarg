import com.abtcorp.io.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.ABTException;
import com.abtcorp.core.ABTValue;

public class TestSananiApp 
{
   public TestSananiApp() {}
   
   public void run() 
   {
      try {
         // Create Log object for debug messages, do not prompt user to overwrite        
         LogFile TestLog = new LogFile("TestObject.Log",false);
         ABTObjectSpace TestSpace = new ABTObjectSpace();
         // Local "driver", that does NOT extend ABTDriver or ABTRepositoryDriver
         TestObjectSpace Tester = new TestObjectSpace(TestSpace, TestLog);
         // Fill the Object Space with hardcoded stuff
         ABTValue os = Tester.populate((String)null);
      } catch (Exception e) {
         e.printStackTrace();
      }      
   }
   
   public static void main(String args[])
   {
    System.out.println("Starting Test App");
    TestSananiApp app = new TestSananiApp();
    app.run();
   }
}