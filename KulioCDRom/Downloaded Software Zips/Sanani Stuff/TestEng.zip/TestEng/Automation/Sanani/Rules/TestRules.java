import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.objectModel.pm.*;
import com.abtcorp.io.PMWRepo.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.text.MessageFormat;
import com.objectspace.jgl.ArrayIterator;
import Sanani.Lib.*;
import TestLib.*;

/* AVP 10/29/98:  This code was originally used by Scott Ellis to test business rules.
I have kluged it to test data models (Project Model, Global Model, Methodology Model),
Task Movement, and other object-level business rules.
Methods added to TestRules:
         testAssignment()
         testConstraint()
         testCustFieldValue()
         testFieldRules()
         moveTasktest()
*/
public class TestRules extends SananiBuilder
{
   public TestRules( String[] args )
   {
      if( args != null && args.length > 0 )
      {
         repositoryName_ = args[0];

         if( args.length > 1 )
            projectExternalID_ = args[1];
      }
   }

   private ABTValue populate() // throws TestRuleException
   {
//      projectExternalID_ = "NEWPRODS";
//
//      ABTValue v = driver_.populate( repositoryName_ + "\\" + projectExternalID_ );
//      checkError( v );
//      ABTObject project = (ABTObject)((ABTObjectSet)v).front( session_ );
//
//      checkError( driver_.populate( repositoryName_ + "\\GYROSOFT" ) );

//      return project;
      return null;
   }

   public void run()
   {

      try
      {
          // 9/9/98 - AVP - create Log object
          CurrentLog = new LogFile("TestObjectRules",false,true);
          CurrentLog.LogDisplay(COMMENT, "TestRules starting..." );
          createObjectSpace();

//         lucy();
//         testExternalid();
//         testIDs();
//         robin();
//         testParser();
//         testWBSLevel();
//         moveTaskTest();
//         deliverables();
//         taskEstimates();
//         deleteTaskTest();
//         custfieldvalues();
//         notes();
//         constraints();
//         subprojectlinks();
//         childTasks();
//         dependencies();
//           testAssignment();
//         testConstraint();
//         testCustFieldValue();
//         oneAssignmentMethod1();
         testFieldRules();
      }
/*
      catch( TestRuleException e )
      {
         CurrentLog.LogDisplay(COMMENT, e.error_.getModule() );
         CurrentLog.LogDisplay(COMMENT, e.error_.getMessage() );
         CurrentLog.LogDisplay(COMMENT, e.error_.getInfo() );
      }
*/
      catch( Exception e )
      {
         CurrentLog.LogDisplay(COMMENT, "Exception caught... printing stack trace..." );
         e.printStackTrace();
      }

      CurrentLog.LogDisplay(COMMENT, "TestRules ended." );
   }

/*
   private void lucy() // throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null, -1, true );

      getValue( project, OFD_CALENDAR );
   }

   private void testExternalid() // throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null, -1, true );

      ABTObject    task1      = createTask( project, null, 1, true );
      ABTObject    task2      = createTask( project, null, 2, true );
      ABTObject    task3      = createTask( project, null, 3, true );

      setValue( task1, OFD_EXTERNALID, new ABTString( "1" ), true );
      setValue( task2, OFD_EXTERNALID, new ABTString( "2" ), true );
      setValue( task3, OFD_EXTERNALID, new ABTString( "3" ), true );

      ABTObject    deliverable1 = createDeliverable( project, 4, true );
      ABTObject    deliverable2 = createDeliverable( project, 5, true );
      ABTObject    deliverable3 = createDeliverable( project, 6, true );

      setValue( deliverable1, OFD_EXTERNALID, new ABTString( "1" ), true );
      setValue( deliverable2, OFD_EXTERNALID, new ABTString( "2" ), true );
      setValue( deliverable3, OFD_EXTERNALID, new ABTString( "3" ), true );

      ABTObject resource1 = createResource( 7, true );
      ABTObject resource2 = createResource( 8, true );
      ABTObject resource3 = createResource( 9, true );

      setValue( resource1, OFD_EXTERNALID, new ABTString( "1" ), true );
      setValue( resource2, OFD_EXTERNALID, new ABTString( "2" ), true );
      setValue( resource3, OFD_EXTERNALID, new ABTString( "1" ), true );

      iterateTasks( project, true );
   }

   private void testIDs() // throws TestRuleException
   {
      ABTObject    project       = createObject( OBJ_PROJECT, null, -1, true );
      ABTObjectSet deliverables  = getObjectSet( project, OFD_ALLDELIVERABLES, true );

      ABTObject    deliverable1  = createDeliverable( project, 1, true );
      ABTObject    deliverable2  = createDeliverable( project, 2, true );
      ABTObject    deliverable3  = createDeliverable( project, 3, true );
      ABTObject    deliverable4  = createDeliverable( project, 4, true );
      ABTObject    deliverable5  = createDeliverable( project, 5, true );
      ABTObject    deliverable6  = createDeliverable( project, 6, true );
      ABTObject    deliverable7  = createDeliverable( project, 7, true );
      ABTObject    deliverable8  = createDeliverable( project, 8, true );
      ABTObject    deliverable9  = createDeliverable( project, 9, true );
      ABTObject    deliverable10 = createDeliverable( project, 10, true );

      deleteObject( deliverable1, true );
      deleteObject( deliverable2, true );
      deleteObject( deliverable3, true );
      deleteObject( deliverable4, true );
      deleteObject( deliverable5, true );

      ABTObjectSetIDs set = deliverables.getIDSet( session_ );

      java.util.Enumeration e = set.getActiveIDs();
      while( e.hasMoreElements() )
      {
         ABTID id = (ABTID)e.nextElement();
         int i = 0;
      }

//      e = set.getDeletedIDs();
      while( e.hasMoreElements() )
      {
         ABTID id = (ABTID)e.nextElement();
         int i = 0;
      }
   }

   private void robin() // throws TestRuleException
   {
      ABTObject project = (ABTObject)populate();

      ABTObjectSet allTasks = getObjectSet( project, OFD_ALLTASKS, true );

      ABTObject task = createTask( project, null, 1000, true );

      iterateObjectSet( allTasks, true );

      setValue( project, OFD_WBSVALIDATE, new ABTBoolean( true ), true );

      iterateTasks( project, true );
   }

   private void testParser() // throws TestRuleException
   {
      ABTObject   test1       = createObject( "pm.PMRule", null, -1, true );

      space_.addProperty( "pm.PMRule", "PROP1", "", ABTRule.PROP_STRING,
         false, true, true, false, null, null, null );
      setValue( test1, "mahbck", ABTDate.today() );

      ABTObjectSet os = findObject( "pm.PMRule", "PROP1 like '%ahab%'", true );
      iterateObjectSet( os );
   }

   public void testWBSLevel() // throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null, -1, true );

      ABTObject    task1      = createTask( project, null, 1, true );
      ABTObject    task2      = createTask( project, null, 2, true );
      ABTObject    task3      = createTask( project, null, 3, true );
      ABTObject    task11     = createTask( project, task1, 11, true );
      ABTObject    task12     = createTask( project, task1, 12, true );
      ABTObject    task13     = createTask( project, task1, 13, true );
      ABTObject    task21     = createTask( project, task2, 21, true );
      ABTObject    task22     = createTask( project, task2, 22, true );
      ABTObject    task23     = createTask( project, task2, 23, true );
      ABTObject    task111    = createTask( project, task11, 111, true );
      ABTObject    task112    = createTask( project, task11, 112, true );
      ABTObject    task113    = createTask( project, task11, 113, true );
      ABTObject    task114    = createTask( project, task11, 114, true );
      ABTObject    task115    = createTask( project, task11, 115, true );
      ABTObject    task1111   = createTask( project, task111, 1111, true );
      ABTObject    task11111  = createTask( project, task1111, 11111, true );

      setValue( project, OFD_WBSVALIDATE, new ABTBoolean( true ), true );

      iterateTasks( project, true );
   }
*/
   public void moveTaskTest() // throws TestRuleException
   {
      Vector
          TaskVector = new Vector(10,1);

      // AVP 11/12/98 - these Site objects now always required
      ABTObject    site       = createSite(1, true);
      verifyValue(site,OFD_TRACKSCALE, new ABTInteger(2), "DEFAULT", true);
      ABTObject    calendar = createCalendar (site, 1, true);
      setValue(site,OFD_CALENDAR,new ABTCalendar(),true);
      ABTObject    project    = createProject( 1, true );
      // create phases
      ABTObject    task1      = createTask( project, TaskVector, null, 1, true );
// 11/10/98 AVP:  Per Hajo, should not have to set Task to false if you are adding children
//      setValue(task1,OFD_ISTASK, new ABTBoolean(false), true);
      // Try setting to phase explicitly (should work since WBSLevel is 1)
      // TEMP - AVP - testing Bug #550
//      setValue(task1,OFD_ISTASK, new ABTBoolean(false), true);
//      setValue(task1,OFD_WBSTYPE,new ABTInteger(1),true);
//      verifyValue(task1,OFD_WBSTYPE,new ABTInteger(1),"TASKMOVE",true);
      ABTObject    task2      = createTask( project, TaskVector,null, 2, true );
// 11/10/98 AVP:  Per Hajo, should not have to set Task to false if you are adding children
      // (StarTeam defect #552)
//      setValue(task2,OFD_ISTASK, new ABTBoolean(false), true);
   //   setValue(task2,OFD_ISMILESTONE,new ABTBoolean(true),true);
      ABTObject    task3      = createTask( project, TaskVector,null, 3, true );
      setValue(task3,OFD_ISTASK, new ABTBoolean(false), true);
      // create activities
      ABTObject    task11     = createTask( project, TaskVector,task1, 11, true );
// 11/10/98 AVP:  Per Hajo, should not have to set Task to false if you are adding children
      // (StarTeam defect #552)
//      setValue(task11,OFD_ISTASK, new ABTBoolean(false), true);
// Per Hajo (#552), IsMilestone should also be set to false once children are created
// Let's set OFD_ISMILESTONE to true BEFORE children are created
      setValue(task11,OFD_ISMILESTONE, new ABTBoolean(true), true);
      ABTObject    task12     = createTask( project, TaskVector,task1, 12, true );
      setValue(task12,OFD_ISTASK, new ABTBoolean(false), true);
      ABTObject    task13     = createTask( project, TaskVector,task1, 13, true );
      setValue(task13,OFD_ISTASK, new ABTBoolean(false), true);
      ABTObject    task21     = createTask( project, TaskVector,task2, 21, true );
      setValue(task21,OFD_ISTASK, new ABTBoolean(false), true);
      ABTObject    task22     = createTask( project, TaskVector,task2, 22, true );
      setValue(task22,OFD_ISTASK, new ABTBoolean(false), true);
      ABTObject    task23     = createTask( project, TaskVector,task2, 23, true );
      setValue(task23,OFD_ISTASK, new ABTBoolean(false), true);
      // create tasks
      ABTObject    task111    = createTask( project, TaskVector,task11, 111, true );
      ABTObject    task112    = createTask( project, TaskVector,task11, 112, true );
      ABTObject    task113    = createTask( project, TaskVector,task11, 113, true );
      // Make this one a milestone
      setValue(task113,OFD_ISMILESTONE, new ABTBoolean(true), true);
      ABTObject    task114    = createTask( project, TaskVector,task11, 114, true );
      ABTObject    task115    = createTask( project, TaskVector,task11, 115, true );

      // AVP 11/10/98:  StarTeam defect #552
      // verify that all objects with children have both task and milestone set to false
      verifyValue(task1,OFD_ISTASK, new ABTBoolean(false), true);
      verifyValue(task1,OFD_ISMILESTONE, new ABTBoolean(false), true);
      verifyValue(task11,OFD_ISTASK, new ABTBoolean(false), true);
      verifyValue(task11,OFD_ISMILESTONE, new ABTBoolean(false), true);
      // (StarTeam defect #552)
      // Both should return Error Code 142 - not updateable
      setValue(task1,OFD_ISTASK, new ABTBoolean(true), false);
      setValue(task1,OFD_ISMILESTONE, new ABTBoolean(true), false);
      setValue(task11,OFD_ISTASK, new ABTBoolean(true), false);
      setValue(task11,OFD_ISMILESTONE, new ABTBoolean(true), false);
      // verify that all objects with children have both task and milestone set to false
      verifyValue(task1,OFD_ISTASK, new ABTBoolean(false), true);
      verifyValue(task1,OFD_ISMILESTONE, new ABTBoolean(false), true);
      verifyValue(task11,OFD_ISTASK, new ABTBoolean(false), true);
      verifyValue(task11,OFD_ISMILESTONE, new ABTBoolean(false), true);

      // how many WBS levels allowed here?
//      ABTObject    task1111   = createTask( project, task111, 1111, true );
//      ABTObject    task11111  = createTask( project, task1111, 11111, true );
      CurrentLog.LogDisplay(COMMENT,"FIRST ITERATION");
      iterateTasks( "", project );
      // Test Case 1 - move Activity 11 and all Tasks (111-115) below Activity 13
      setValue( task11, OFD_PREVIOUSTASK, task13, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 1 - AFTER MOVE Activity 11 and children AFTER Activity 13");
      iterateTasks( "", project );
      // Test Case 2 - move Activity 11 and all Tasks (111-115) to Phase 2 (between Activities 22 and 23)
      setValue( task11, OFD_PREVIOUSTASK, task22, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 2 - AFTER MOVE Activity 11 and children AFTER Activity 22");
      iterateTasks( "", project );
      // Test Case 3 - add Activity 24 to Phase 2
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 3 - AFTER add Activity Task24 after Activity Task23");
      ABTObject    task24     = createTask( project, TaskVector,task2, 24, true );
      setValue(task24,OFD_ISTASK, new ABTBoolean(false), true);
      iterateTasks( "", project );
      // Test Case 4 - move Activity 11 and all Tasks (111-115) to Phase 3
      //  11/12/98 AVP:  Testing Bug #552 - OFD_ISTASK should be reset to false
      // when I make task3 a parent
      setValue(task3,OFD_ISTASK, new ABTBoolean(true), true);
      setValue( task11, OFD_PARENTTASK, task3, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 4 - AFTER MOVE Activity 11 and all children under Phase 3");
      iterateTasks( "", project );
      // Test Case 5 - add Task 116 to Activity 11
      ABTObject    task116    = createTask( project, TaskVector,task1, 116, true );
      setValue(task116,OFD_ISTASK, new ABTBoolean(false), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 5 - AFTER ADD Activity task116, parent Phase 1");
      iterateTasks( "", project );
      // Test Case 6 - add Activity 31 to Phase 3
      ABTObject    task31     = createTask( project, TaskVector,task3, 31, true );
      setValue(task31,OFD_ISTASK, new ABTBoolean(false), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 6 - AFTER ADD Activity 31, parent Phase 3");
      iterateTasks( "", project );
      // Test Case 7 - add Phase 4 to Project
      ABTObject    task4     = createTask( project, TaskVector,null, 4, true );
      setValue(task4,OFD_ISTASK, new ABTBoolean(false), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 7 - AFTER ADD Phase 4, parent null");
      iterateTasks( "", project );
      // Test Case 8 - move Task113 to Phase 4, using OFD_FIRSTCHILDTASK
      // Task113 becomes Activity, so OFD_ISTASK must be set to false
      // 11/12/98 AVP:  To further test StarTeam Defect #552, reset OFD_ISTASK to true
      // Should be set to false when child is created
      setValue(task4,OFD_ISTASK, new ABTBoolean(true), true);
      setValue( task4, OFD_FIRSTCHILDTASK, task113, true, true );
      setValue(task113,OFD_ISTASK, new ABTBoolean(false), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 8 - AFTER move Activity task113 under Phase 4");
      iterateTasks( "", project );
      // Test Case 9 - remove Task113 from Phase 4, using OFD_NEXTTASK
      // task4 should STAY OFD_ISTASK = false
      setValue(task113, OFD_NEXTTASK, task4, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 9 - AFTER remove Activity task113 from under Phase 4 - task113 becomes Phase");
      iterateTasks( "", project );
      // Test Case 10 - re-attach Task113 to Phase 4, using OFD_LASTCHILDTASK
      // 11/12/98 AVP:  To further test StarTeam Defect #552, reset OFD_ISTASK to true
      // Should be set to false when child is created
      setValue(task4,OFD_ISTASK, new ABTBoolean(true), true);
      setValue(task4, OFD_LASTCHILDTASK, task113, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 10 - AFTER remove Activity task113 from under Phase 4");
      iterateTasks( "", project );
      // Test Case 11 - move Task114 to task23, using OFD_LASTCHILDTASK
      setValue( task23, OFD_LASTCHILDTASK, task114, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 11 - AFTER move task114 under Activity 23");
      iterateTasks( "", project );
      // Test Case 12 - move Task116 to Phase 4, using OFD_NEXTTASK
      setValue( task116, OFD_NEXTTASK, task113, true, true );
      setValue(task116,OFD_ISTASK, new ABTBoolean(false), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 12 - AFTER move task116 under phase 4, before task 113");
      iterateTasks( "", project );
      // Test Case 13 = move Task11 after Phase 4, using OFD_PREVIOUSTASK
      // Task 11 and all children task should move up 1 WBSLevel
      setValue( task11, OFD_PREVIOUSTASK, task4, true, true );
//      setValue(task11,OFD_ISTASK, new ABTBoolean(false), true);
      setValue(task111,OFD_ISTASK, new ABTBoolean(false), true);
      setValue(task112,OFD_ISTASK, new ABTBoolean(false), true);
      setValue(task115,OFD_ISTASK, new ABTBoolean(false), true);
      // If I verify 1 one of the children BEFORE verifying parent,
      // Bug #557 is avoided
      // AVP 11/12/98 - 557 fixed, this work-around no longer needed
   //   verifyValue(task115,OFD_WBSTYPE, new ABTShort((short)2), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 13 - AFTER move Activity 11 after phase 4, up 1 WBSLevel - becomes Phase and Activities");
      iterateTasks( "", project );
      // Test Case 14 = move Task11 BEFORE Phase 4, using OFD_NEXTTASK
      // Do NOT move children
      setValue( task11, OFD_NEXTTASK, task4, false, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 14 - AFTER move Phase 11 BEFORE phase 4 - children don't come along, become Phases");
      iterateTasks( "", project );
      // Test Case 15 - re-attach children to Task11, using OFD_PARENT
      setValue( task111, OFD_PARENTTASK, task11, true, true);
      setValue( task112, OFD_PARENTTASK, task11, true, true);
      setValue( task115, OFD_PARENTTASK, task11, true, true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 15 - AFTER re-attach Activities 111,112,115 to Phase task11 as children");
      iterateTasks( "", project );
      // Test Case 16 = move Task11 under Phase 4, using OFD_FIRSTCHILD - move children
      setValue( task4, OFD_FIRSTCHILDTASK, task11, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 16 - AFTER move task11 UNDER phase 4 - children come along - all go back down 1 WBSLevel");
      // Children become tasks again
      setValue(task111,OFD_ISTASK, new ABTBoolean(true), true);
      setValue(task112,OFD_ISTASK, new ABTBoolean(true), true);
      setValue(task115,OFD_ISTASK, new ABTBoolean(true), true);
      iterateTasks( "", project );
      // Let's try to break FIRST CHILD / LAST CHILD
      // Test Case 17 - Make task115 child of task22, using LASTCHILD
      setValue( task22, OFD_LASTCHILDTASK, task115, true, true );
      setValue(task115,OFD_ISTASK, new ABTBoolean(true), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 17 - AFTER move task115 UNDER Activity 22 - using OFD_LASTCHILD - task115 becomes Task");
      iterateTasks( "", project );
      // Test Case 18 - Now set task115 as FIRSTCHILD
      setValue( task22, OFD_FIRSTCHILDTASK, task115, true, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 18 - now make task115 OFD_FIRSTCHILD of Activity 22 - should be no change");
      iterateTasks( "", project );
      // Test Case 19 - Now set task112 as FIRSTCHILD
      setValue( task22, OFD_FIRSTCHILDTASK, task112, true, true );
      setValue(task112,OFD_ISTASK, new ABTBoolean(true), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 19 - now make task112 OFD_FIRSTCHILD of Activity 22 - Task112 becomes task again");
      iterateTasks( "", project );
      // Test Case 20 - Now set task22 PREVIOUSTASK as 3 - move it up 1 level - should move children
      setValue( task22, OFD_PREVIOUSTASK, task3, true, true );
      setValue(task112,OFD_ISTASK, new ABTBoolean(false), true);
      setValue(task115,OFD_ISTASK, new ABTBoolean(false), true);
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 20 - now move task22 up 1 level using OFD_PREVIOUSTASK - between 3 and 4 - should bring children");
      iterateTasks( "", project );
      // Test Case 21 - Now set task22 NEXTTASK as 3 - move it on chain - DO NOT BRING CHILDREN
      setValue( task22, OFD_NEXTTASK, task3, false, true );
      CurrentLog.LogDisplay(COMMENT,"TEST CASE 21 - now move task22 between 2 and 3 using OFD_NEXTTASK - DO NOT BRING CHILDREN - children should become phases");
      iterateTasks( "", project );
   }

/*
   public void deliverables() // throws TestRuleException
   {
      ABTObject   project  = createObject( OBJ_PROJECT, null, -1, true );

      ABTObject   task     = createTask( project, null, 1, true );
      ABTObject   deliv1   = createDeliverable( project, 2, true );

      ABTObjectSet os = getObjectSet( task, OFD_DELIVERABLES, true );
      addListMember( os, deliv1, true );

//      checkError( deliv1.delete( session_ ) );

      os = getObjectSet( project, OFD_ALLDELIVERABLES, true );
      iterateObjectSet( os, true );
   }

   public void taskEstimates() // throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null, -1, true );

      ABTObject    task1      = createTask( project, null, 10 );
      ABTObject    task2      = createTask( project, null, 11 );
      ABTObject    task3      = createTask( project, null, 12 );

      ABTObject    estmodel1  = createEstmodel( project, 2 );
      ABTObject    estmodel2  = createEstmodel( project, 3 );
      ABTObject    estmodel3  = createEstmodel( project, 4 );

      ABTObject    taskest1   = createTaskestimate( task1, estmodel1, 5 );
      ABTObject    taskest2   = createTaskestimate( task2, estmodel2, 6 );
      ABTObject    taskest3   = createTaskestimate( task3, estmodel3, 7 );

      checkError( estmodel1.delete( session_ ) );

      iterateObjectSet( getObjectSet( project, OFD_ALLTASKESTIMATES ) );
   }

   public void deleteTaskTest() // throws TestRuleException
   {
      ABTObject   project     = createObject( OBJ_PROJECT, null, -1 );

      //
      // Create all the resources for the project
      //
      ABTObject   resource1   = createResource( 1 );
      ABTObject   resource2   = createResource( 2 );
      ABTObject   resource3   = createResource( 3 );
      ABTObject   team1       = createTeamResource( project, resource1, 4 );
      ABTObject   team2       = createTeamResource( project, resource2, 5 );
      ABTObject   team3       = createTeamResource( project, resource3, 6 );

      //
      // Create all of the tasks for the project
      //
      ABTObject    task1      = createTask( project, null, 7 );
      ABTObject    task2      = createTask( project, null, 8 );
      ABTObject    task3      = createTask( project, null, 9 );

      //
      // Create the assignments for the project
      //
      ABTObject    assignment1 = createAssignment( task1, resource1, 10 );
      ABTObject    assignment2 = createAssignment( task2, resource2, 11 );
      ABTObject    assignment3 = createAssignment( task3, resource3, 12 );

      //
      // Create estimating models and task estimates for the project
      //
      ABTObject    estmodel1  = createEstmodel( project, 13 );
      ABTObject    estmodel2  = createEstmodel( project, 14 );
      ABTObject    estmodel3  = createEstmodel( project, 15 );
      ABTObject    taskest1   = createTaskestimate( task1, estmodel1, 16 );
      ABTObject    taskest2   = createTaskestimate( task2, estmodel2, 17 );
      ABTObject    taskest3   = createTaskestimate( task3, estmodel3, 18 );

      //
      // Create a few dependencies
      //
      ABTObject    dependency1 = createDependency( task1, task2, 19 );
      ABTObject    dependency2 = createDependency( task2, task3, 20 );

      //
      // Create a few deliverables
      //
      ABTObject deliv1 = createDeliverable( project, 21 );
      ABTObject deliv2 = createDeliverable( project, 22 );
      ABTObject deliv3 = createDeliverable( project, 23 );

      addListMember( getObjectSet( task1, OFD_DELIVERABLES ), deliv1 );
      addListMember( getObjectSet( task2, OFD_DELIVERABLES ), deliv2 );
      addListMember( getObjectSet( task3, OFD_DELIVERABLES ), deliv3 );

      //
      // Add some notes
      //
      ABTObject      note1 = createNote( 24 );
      ABTObject      note2 = createNote( 25 );
      ABTObject      note3 = createNote( 26 );
      addListMember( getObjectSet( project, OFD_NOTES ), note1 );
      addListMember( getObjectSet( project, OFD_NOTES ), note2 );
      addListMember( getObjectSet( project, OFD_NOTES ), note3 );

      //
      // Add some custom field values
      //
      ABTObject      custfieldvalue1 = createCustfieldvalue( 27 );
      ABTObject      custfieldvalue2 = createCustfieldvalue( 28 );
      ABTObject      custfieldvalue3 = createCustfieldvalue( 29 );
      addListMember( getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue1 );
      addListMember( getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue2 );
      addListMember( getObjectSet( project, OFD_CUSTFIELDVALUES ), custfieldvalue3 );

      checkError( resource1.delete( session_ ) );


//      iterateObjectSet( getObjectSet( resource1, OFD_ASSIGNMENTS ) );
      iterateObjectSet( getObjectSet( task1, OFD_ASSIGNMENTS ) );
      iterateObjectSet( getObjectSet( project, OFD_NOTES ) );
   }

   public void iterate( ABTObjectSet os, String object, String prop ) // throws TestRuleException
   {
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject listelem = (ABTObject)e.nextElement();
         ABTObject obj = getObject( listelem, object );
         ABTValue v = getValue( obj, prop );
         String s = v.toString();
         int i = 0;
      }
   }

   public void custfieldvalues() // throws TestRuleException
   {
      ABTObject    project       = createObject( OBJ_PROJECT, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put( new ABTString(OFD_PROJECT), project );

      ABTObject    task          = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    custvalue1    = createObject( OBJ_CUSTFIELDVALUE, null, -1 );
      ABTObject    custvalue2    = createObject( OBJ_CUSTFIELDVALUE, null, -1 );
      ABTObject    custvalue3    = createObject( OBJ_CUSTFIELDVALUE, null, -1 );
      ABTObjectSet custvalues    = getObjectSet( task, OFD_CUSTFIELDVALUES );

      setValue( project, OFD_FIRSTCHILDTASK, task );

      addListMember( custvalues, custvalue1 );
      addListMember( custvalues, custvalue2 );
      addListMember( custvalues, custvalue3 );

      setValue( custvalue1, OFD_ID, new ABTInteger( 1 ) );
      setValue( custvalue2, OFD_ID, new ABTInteger( 2 ) );
      setValue( custvalue3, OFD_ID, new ABTInteger( 3 ) );

      removeListMember( custvalues, custvalue1 );

      iterateObjectSet( custvalues );
   }

   public void notes() // throws TestRuleException
   {
      ABTObject    project  = createObject( OBJ_PROJECT, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString( OFD_PROJECT), project );

      ABTObject    task     = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    note1    = createObject( OBJ_NOTE, null, -1 );
      ABTObject    note2    = createObject( OBJ_NOTE, null, -1 );
      ABTObject    note3    = createObject( OBJ_NOTE, null, -1 );
      ABTObjectSet notes    = getObjectSet( task, OFD_NOTES );

      setValue( project, OFD_FIRSTCHILDTASK, task );

      addListMember( notes, note1 );
      addListMember( notes, note2 );
      addListMember( notes, note3 );

      setValue( note1, OFD_ID, new ABTInteger( 1 ) );
      setValue( note2, OFD_ID, new ABTInteger( 2 ) );
      setValue( note3, OFD_ID, new ABTInteger( 3 ) );

      removeListMember( notes, note1 );

      iterateObjectSet( notes );
   }

   public void constraints() // throws TestRuleException
   {
      ABTObject    project       = createObject( OBJ_PROJECT, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString( OFD_PROJECT), project );

      ABTObject    task          = createObject( OBJ_TASK, taskreqs, -1 );

      ABTHashtable constraintreqs = new ABTHashtable();
      constraintreqs.put(new ABTString( OFD_TASK), task );

      ABTObject    constraint1   = createObject( OBJ_CONSTRAINT, constraintreqs, -1 );
      ABTObject    constraint2   = createObject( OBJ_CONSTRAINT, constraintreqs, -1 );

      setValue( constraint1, OFD_ID, new ABTInteger( 1 ) );
      setValue( constraint2, OFD_ID, new ABTInteger( 2 ) );

      constraint1.delete( session_ );

      ABTObjectSet os = getObjectSet( task, OFD_CONSTRAINTS );
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTValue v = getValue( (ABTObject)e.nextElement(), OFD_ID );
         String s = v.stringValue();
         int i = 0;
      }
   }

   public void subprojectlinks() // throws TestRuleException
   {
      ABTObject    project    = createObject( OBJ_PROJECT, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString( OFD_PROJECT), project );

      ABTObject    task       = createObject( OBJ_TASK, taskreqs, -1 );

      ABTHashtable subprjreqs = new ABTHashtable();
      subprjreqs.put(new ABTString( OFD_TASK), task );

      ABTObject    sublink    = createObject( OBJ_SUBPROJECTLINK, subprjreqs, -1 );

      setValue( sublink, OFD_ID, new ABTInteger( 1 ) );

      iterateObjectSet( getObjectSet( project, OFD_SUBPROJECTLINKS ) );

      project( project, null );
   }

   public void childTasks() // throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString( OFD_PROJECT), project );

      ABTObject    task1       = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    task2       = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    task3       = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    task4       = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    taskMain    = createObject( OBJ_TASK, taskreqs, -1 );

      setValue( task1, OFD_PARENTTASK, taskMain );
      setValue( task2, OFD_PARENTTASK, taskMain );
      setValue( task3, OFD_PARENTTASK, taskMain );
      setValue( task4, OFD_PARENTTASK, taskMain );

      setValue( task1, OFD_ID, new ABTInteger( 1 ) );
      setValue( task2, OFD_ID, new ABTInteger( 2 ) );
      setValue( task3, OFD_ID, new ABTInteger( 3 ) );
      setValue( task4, OFD_ID, new ABTInteger( 4 ) );

      setValue( taskMain, OFD_ID, new ABTInteger( 5 ) );

      setValue( project, OFD_LASTCHILDTASK, taskMain );
      setValue( taskMain, OFD_LASTCHILDTASK, task1 );

      setValue( task1, OFD_PREVIOUSTASK, task4 );
      setValue( task1, OFD_PREVIOUSTASK, task2 );

      setValue( taskMain, OFD_LASTCHILDTASK, task3 );

      iterateTasksBackwards( taskMain );
   }
*/
   public void iterateTasks( String startString, ABTObject parent ) // throws TestRuleException
   {
      ABTValue
          v = null,
          vid = null;
      ABTObject
          task = null;
      String
          displayString = null;
      int
          WBSLevel = 0,
          WBSSequence = 0,
          id = 0,
          prevID = 0,
          nextID = 0,
          parentID = 0,
          firstChildID = 0,
          lastChildID = 0;

/*  AVP 11/12/98 Right now this just clutters up my results.
Will re-institute later
// First check project-level property set (if we are at that level)
      if (parent.getObjectType().equals(OBJ_PROJECT))
      {
          v = getValue( parent, OFD_ALLTASKS, true);
          ABTObjectSet TaskSet = (ABTObjectSet)v;
          Enumeration e = TaskSet.elements(session_);
          while (e.hasMoreElements())
          {
             task = (ABTObject)e.nextElement();
             getTaskValues("PROJECT LEVEL: ", task);
          }
      }
*/
      v = getValue( parent, OFD_FIRSTCHILDTASK, true );
 //     checkError( v, true);

      while( false == checkError (v, true) )
      {
         task = (ABTObject)v;

         displayString = startString + "---";
         // retrieve and display the property values of this Task (id, prev, next, parent, firstchild, lastchild)
         getTaskValues( displayString, task);

         // iterate through any children (horizontal branch)
         iterateTasks( displayString, task);

         // get next task in vertical branch
         v = getValue( task, OFD_NEXTTASK, true);

      }
   }

   // Retrieve Task properties which are object references, retrieve id of the objects referenced,
   // label and log/display id values
   public void getTaskValues( String displayString, ABTObject task ) // throws TestRuleException
   {
      ABTValue
          v = null,
          vid = null,
          WBSTypeDescription = null;
      String
          WBSTypeDescriptionString = null;
      short
//      int
          WBSType = 0;
      int
          WBSLevel = 0,
          WBSSequence = 0,
          id = 0,
          prevID = 0,
          nextID = 0,
          parentID = 0,
          firstChildID = 0,
          lastChildID = 0;
      boolean
          isMilestone = false,
          isTask = false;

         v = getValue( task, OFD_WBSLEVEL, true );
         if (false == checkError( v, true))
             WBSLevel = v.intValue();

/* 10/8/98 AVP Removed from task object per Zane
         v = getValue( task, OFD_WBSSEQUENCE, true );
         if (false == checkError( v, true))
             WBSSequence = v.intValue();
*/

         v = getValue( task, OFD_ID, true);
         if (false == checkError( v, true))
             id = v.intValue();

         v = getValue( task, OFD_PREVIOUSTASK, true);
         if (false == checkError( v, true))
         {
            vid = getValue ((ABTObject)v, OFD_ID, true);
            prevID = vid.intValue();
         } else {
            prevID = 0;
         }

         v = getValue( task, OFD_NEXTTASK, true);
         if (false == checkError( v, true))
         {
            vid = getValue ((ABTObject)v, OFD_ID, true);
            nextID = vid.intValue();
         } else {
            nextID = 0;
         }

         v = getValue( task, OFD_PARENTTASK, true);
         if (false == checkError( v, true))
         {
            vid = getValue ((ABTObject)v, OFD_ID, true);
            parentID = vid.intValue();
         } else {
            parentID = 0;
         }

         v = getValue( task, OFD_FIRSTCHILDTASK, true);
         if (false == checkError( v, true))
         {
            vid = getValue ((ABTObject)v, OFD_ID, true);
            firstChildID = vid.intValue();
         } else {
            firstChildID = 0;
         }

         v = getValue( task, OFD_LASTCHILDTASK, true);
         if (false == checkError( v, true))
         {
            vid = getValue ((ABTObject)v, OFD_ID, true);
            lastChildID = vid.intValue();
         } else {
            lastChildID = 0;
         }
         v = getValue( task, OFD_ISMILESTONE, true);
         if ((false == checkError( v, true)) && (v instanceof ABTBoolean))
         {
            isMilestone = v.booleanValue();
         } else {
            isMilestone = false;
         }
         v = getValue( task, OFD_ISTASK, true);
         if ((false == checkError( v, true)) && (v instanceof ABTBoolean))
         {
            isTask = v.booleanValue();
         } else {
            isTask = false;
         }
         v = getValue( task, OFD_WBSTYPE, true);
         if ((false == checkError( v, true)) && (v instanceof ABTShort))
         {
            WBSType = v.shortValue();
         } else {
            WBSType = 0;
         }
         // Get description for this enumeration value
         ABTProperty WBSTypeProp = task.getProperty(session_,OFD_WBSTYPE);
//         ABTExtendedPropertyList WBSTypeExtendedPropertyList = convertStringtoList(WBSTypeProp.getPropertyKey(PROP_KPOSSIBLEVALUES).toString().substring(indexOf("Array(")),"=,}",true);
         ABTExtendedPropertyList WBSTypeExtendedPropertyList = (ABTExtendedPropertyList)WBSTypeProp.getPropertyKey(PROP_KPOSSIBLEVALUES);
         WBSTypeDescription = WBSTypeExtendedPropertyList.get(WBSType);
         if (null == WBSTypeDescription)
            WBSTypeDescriptionString = "NOT FOUND";
         else if (WBSTypeDescription.isEmpty(session_))
            WBSTypeDescriptionString = "NOT FOUND";
         else
             WBSTypeDescriptionString = WBSTypeDescription.toString().trim();
         CurrentLog.LogDisplay(COMMENT,displayString + "Task " + id + " Properties: WBSLevel = " + WBSLevel);
         CurrentLog.LogDisplay(COMMENT,"           prevtask = "  + prevID + ", nexttask = " + nextID);
         CurrentLog.LogDisplay(COMMENT,"           parent = " + parentID + ", WBSType = " + WBSTypeDescriptionString + ", short = " + WBSType);
         CurrentLog.LogDisplay(COMMENT,"           firstchild = "  + firstChildID + ", lastChildID = " + lastChildID);
         CurrentLog.LogDisplay(COMMENT,"           isTask = " + isTask + ", isMilestone = " + isMilestone);
    }

/*
   public void iterateObjectSet( ABTObjectSet os ) // throws TestRuleException
   {
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject obj = (ABTObject)e.nextElement();
         ABTValue v = getValue( obj, OFD_ID );
         String s = v.stringValue();
         CurrentLog.LogDisplay(COMMENT, s );
      }
   }

   public void iterateTasksBackwards( ABTObject parent ) // throws TestRuleException

   {
      ABTObject task = getObject( parent, OFD_LASTCHILDTASK );
      ABTObject firsttask = getObject( parent, OFD_FIRSTCHILDTASK );
      ABTValue v = task.getValue( session_, OFD_ID, null );
      String s = v.stringValue();

      while( task != firsttask )
      {
         task = getObject( task, OFD_PREVIOUSTASK );
         v = task.getValue( session_, OFD_ID, null );
         s = v.stringValue();
         int i = 0;
      }
   }

   public void dependencies() // throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString( OFD_PROJECT), project );

      ABTObject    task1       = createObject( OBJ_TASK, taskreqs, -1 );
      ABTObject    task2       = createObject( OBJ_TASK, taskreqs, -1 );

      ABTHashtable dependreqs = new ABTHashtable();
      dependreqs.put(new ABTString( OFD_PREDTASK), task1 );
      dependreqs.put(new ABTString( OFD_SUCCTASK), task2 );

      ABTObject    dependency  = createObject( OBJ_DEPENDENCY, dependreqs, -1 );

      checkError( dependency.delete( session_ ) );

      ABTObjectSet os = getObjectSet( project, OFD_ALLDEPENDENCIES );
      iterateObjectSet( os );

      ABTObjectSet succDependencies = getObjectSet( task1, OFD_SUCCDEPENDENCIES );
      java.util.Enumeration e = succDependencies.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject dependElem = (ABTObject)e.nextElement();
         String s = dependElem.getObjectType();
         int j = 0;
      }

      ABTObjectSet predDependencies = getObjectSet( task2, OFD_PREDDEPENDENCIES );
      e = predDependencies.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject dependElem = (ABTObject)e.nextElement();
         String s = dependElem.getObjectType();
         int j = 0;
      }
   }
*/

   // This method will test basic object-level rules for the assignment object:
   // Creation (onInitialize)
   // TODO:  not currently done - Creation (setDefaultProperties)
   // Modification (onSet)
   // Retrieval (onGet (parameter ABTValue myValue)
   //            onGet (parameter int myIndex))
   // Addition to object set (onAdd)
   // Removal from Object set (onRemove)
   // Clear entire object set (onClear)
   // Append any child objects to object  (notes)
   // Delete object (onDelete)
   // SPECIAL TESTS:
   //       Test with null Task
   //       Test with null resource
   //       Test with all null
   //       Test with deleted Task
   //       Test with deleted Resource
   //       Valid task and resource, NOT on project team
   //       Test with extra parameter in hashtable (extra Task object)
   //       Test with wrong object type in hashtable (team and project)
   //       Test duplicate Assignment (same Task, same Resource)
   //       Test different Task, same Resource
   //       Test different Resource, same Task
   //       Test duplicate internal ID
   public void testAssignment() // throws TestRuleException
   {
      Vector
        noteVector = null;
      CurrentLog.LogDisplay(COMMENT,"Testing Assignment object");
      // First, create the parent objects needed for assignments
      ABTObject    project     = createObject( OBJ_PROJECT, null, -1, true );
      ABTObject    task        = createTask( project, null, null, 10, true );
      ABTObject    task2       = createTask( project, null, null, 11, true );
      ABTObject    site       = createSite(1, true);
      ABTObject    resource   = createResource(site, 1, true);
      ABTObject    resource2  = createResource(site, 2, true);
      ABTObject    deletedresource = createResource (site, 3, true);
      ABTObject    noteamresource = createResource (site, 4, true);
      ABTObject    team       = createTeamResource( project, resource, 1, true );
      ABTObject    team2       = createTeamResource( project, resource2, 3, true );
      ABTObject    deletedteam = createTeamResource( project, deletedresource, 2, true );
      ABTObjectSet teams       = getObjectSet( project, OFD_TEAMRESOURCES, true );
      ABTObject    task3       = createTask( project, null, null, 12, true );
      ABTObject    deletedtask        = createTask( project, null, null, 20, true );
      ABTObject    noteamtask        = createTask( project, null, null, 30, true );
//      setValue( resource, OFD_NAME, new ABTString( "Resource 1" ), true );


      // Just testing circular reference error bug - this should now work, even if value already set
      setValue( project, OFD_FIRSTCHILDTASK, task, true );
      ABTValue FirstChildTask = getValue( project, OFD_FIRSTCHILDTASK, true);
      setValue( project, OFD_FIRSTCHILDTASK, task, true );
      FirstChildTask = getValue( project, OFD_FIRSTCHILDTASK, true);
      setValue( project, OFD_FIRSTCHILDTASK, task2, true );
      FirstChildTask = getValue( project, OFD_FIRSTCHILDTASK, true);
      setValue( task2, OFD_FIRSTCHILDTASK, task, true);
      FirstChildTask = getValue( task2, OFD_FIRSTCHILDTASK, true);
      setValue( task2, OFD_FIRSTCHILDTASK, task, true);
      FirstChildTask = getValue( task2, OFD_FIRSTCHILDTASK, true);


      // Attempt to create Assignment with null parameters
      CurrentLog.LogDisplay(COMMENT,"Testing bad assignments - should generate errors");

      CurrentLog.LogDisplay(COMMENT,"Create assignment with null parameters - should fail");
      ABTObject nullassignment = createAssignment( null, null, 0, false);
      // Attempt to create with just null Task
      CurrentLog.LogDisplay(COMMENT,"Create assignment with null task - should fail");
      nullassignment = createAssignment( null, resource, 1, false);
      // Attempt to create with just null Resource
      CurrentLog.LogDisplay(COMMENT,"Create assignment with null resource - should fail");
      nullassignment = createAssignment( task, null, 2, false);
      // Attempt to create with deleted Team
      deletedteam.delete(session_);
      boolean teamDeleted = deletedteam.isDeleted(session_);
      CurrentLog.LogDisplay(COMMENT,"Create assignment with deleted team - should fail");
      nullassignment = createAssignment( task, deletedresource, 3, false);
      // Attempt to create with deleted Resource (and Team)
      deletedresource.delete(session_);
      boolean resourceDeleted = deletedresource.isDeleted(session_);
      CurrentLog.LogDisplay(COMMENT,"Create assignment with deleted team and resource - should fail");
      nullassignment = createAssignment( task, deletedresource, 4, false);
      // Attempt to create with deleted Task, Resource, and Team
      deletedtask.delete(session_);
      CurrentLog.LogDisplay(COMMENT,"Create assignment with deleted team, resource, task - should fail");
      nullassignment = createAssignment( deletedtask, deletedresource, 5, false);
      // Attempt to create with Task and Resource not on a project team
      CurrentLog.LogDisplay(COMMENT,"Create assignment with task and resource not on team - should fail");
      nullassignment = createAssignment( noteamtask, noteamresource, 6, false);
      // Attempt to create with wrong objects (Team and Project)
      CurrentLog.LogDisplay(COMMENT,"Create assignment with wrong objects team and project - should fail");
      nullassignment = createAssignment( team, project, 7, false);
      // Attempt to create with 1 wrong object (Task and Team)
      CurrentLog.LogDisplay(COMMENT,"Create assignment with wrong objects task and project - should fail");
      nullassignment = createAssignment( task, project, 8, false);
      // Attempt to create with 1 wrong object (Project and Resource)
      CurrentLog.LogDisplay(COMMENT,"Create assignment with wrong objects project and resource - should fail");
      nullassignment = createAssignment( project, resource, 9, false);
      // Create and verify assignnment object (should invoke oninitialize and
      // setdefaultproperties)
      CurrentLog.LogDisplay(COMMENT,"Create and verify good assignment");
      ABTObject assignment1 = createandVerifyAssignment(task, resource, 100, true);
      CurrentLog.LogDisplay(COMMENT,"Create and verify duplicate assignment - different task, same resource with different ID");
      ABTObject assignment2 = createandVerifyAssignment( task2, resource, 101, true);
      CurrentLog.LogDisplay(COMMENT,"Create and verify duplicate assignment - same task, different resource with different ID");
      ABTObject assignment3 = createandVerifyAssignment( task2, resource2, 102, true);
      CurrentLog.LogDisplay(COMMENT,"Create and verify assignment with duplicate Remote ID to rejected object - should be handled correctly");
      ABTObject dupeassignment = createandVerifyAssignment( task, resource2, 1, true);
      CurrentLog.LogDisplay(COMMENT,"Create and verify assignment with duplicate Remote ID to created object - will not reference new task,resource");
      ABTObject assignment4 = createandVerifyAssignment( task3, resource2, 101, false);
      // Attempt to create duplicate assignment (same task and resource)
      CurrentLog.LogDisplay(COMMENT,"Create and verify duplicate assignment - same task and resource with different ID - should be rejected");
      ABTObject assignment5 = createandVerifyAssignment( task, resource, 105, false);
      // Attempt to clear notes attached to second assignment - member notes should be deleted
      CurrentLog.LogDisplay(COMMENT,"Clear and verify note object set - Assignment not deleted");
      ABTObjectSet noteobjectset1 = getObjectSet(assignment2, OFD_NOTES, true);
      noteVector = storeNotes(noteobjectset1);
      // Clear note object set
      clear(noteobjectset1,true);
      // Are notes deleted?  Should be!
      verifyNoteClear(noteobjectset1, noteVector);
      // Delete Assignment (onDelete)
      CurrentLog.LogDisplay(COMMENT,"Delete Assignment objects");
      if (assignment1 != null)
      {
          CurrentLog.LogDisplay(COMMENT,"Deleting first assignment");
          ABTObjectSet noteobjectset = getObjectSet(assignment1, OFD_NOTES, true);
          noteVector = storeNotes(noteobjectset);
          if (true == deleteObject(assignment1,true))
          {
              CurrentLog.LogWrite(PASS,"Delete success");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Delete failure");
          }
          verifyNoteClear(noteobjectset, noteVector);
          // Attempt to explicitly delete Notes
          // 9/4/98 - AVP - not currently allowed
    //      note11.delete(session_);
    //      note12.delete(session_);
    //      note13.delete(session_);
       //   projectIntegrity( project );
          assignmentIntegrity(assignment1, task, resource, 100, false);
          // Notes should no longer exist
          // Attempt to delete again - should fail
          if (false == deleteObject(assignment1,false))
          {
              CurrentLog.LogWrite(PASS,"Second delete failure");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Second delete allowed - should fail");
          }
      }
      // Delete second assignment
      if (assignment2 != null)
      {
          CurrentLog.LogDisplay(COMMENT,"Deleting second assignment");
          if (true == deleteObject(assignment2,true))
          {
              CurrentLog.LogWrite(PASS,"Delete success");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Delete failure");
          }
          // Attempt to explicitly delete Notes
          // 9/4/98 - AVP - not currently allowed
    //      note11.delete(session_);
    //      note12.delete(session_);
    //      note13.delete(session_);
       //   projectIntegrity( project );
          assignmentIntegrity(assignment2, task2, resource, 101, false);
          // Attempt to delete again - should fail
          if (false == deleteObject(assignment2,false))
          {
              CurrentLog.LogWrite(PASS,"Second delete failure");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Second delete allowed - should fail");
          }
      }
   } // testAssignment

   public ABTObject createandVerifyAssignment(ABTObject task, ABTObject resource, int remoteID, boolean shouldPass) // throws TestRuleException
   {

      ABTObject   testAssignment = createAssignment( task, resource, remoteID, shouldPass );
      if (null == testAssignment)
      {
        return null;
      }
      assignmentIntegrity(testAssignment, task, resource, remoteID, shouldPass);
      // Testing setting values for default properties (those that don't invoke field-level rules)
      propertyDefaults(testAssignment, shouldPass);
      // Retrieve assignment object property values (test onget)
      // Attempt to add to object set (onAdd)
      CurrentLog.LogDisplay(COMMENT,"Attempt ObjectSet manipulation directly - should not be allowed");
      ABTObjectSet TestAssignments = createObjectSet(OBJ_ASSIGNMENT, true);
      add(TestAssignments,testAssignment, false);
//      addListMember(TestAssignments,testAssignment, false);
      addNew(TestAssignments, false);
      // Attempt to remove from object set (onRemove)
      remove(TestAssignments,testAssignment, false);
//      removeListMember(TestAssignments,testAssignment, false);
      // Attempt to clear an object set (onClear)
      clear(TestAssignments, false);
//      clearListMember(TestAssignments, false);
      // Add only child objects - Notes
      ABTObject      note11 = createNote(11, true);
      ABTObject      note12 = createNote(12, true);
      ABTObject      note13 = createNote(13, true);
      add( getObjectSet( testAssignment, OFD_NOTES, true ), note11, shouldPass);
      add( getObjectSet( testAssignment, OFD_NOTES, true ), note12, shouldPass);
      add( getObjectSet( testAssignment, OFD_NOTES, true ), note13, shouldPass);
      ABTObjectSet NoteObjectSet = getObjectSet(testAssignment, OFD_NOTES, true);
      assignmentIntegrity(testAssignment, task, resource, remoteID, shouldPass);
      taskIntegrity(task, resource, testAssignment, shouldPass);
    //  resourceIntegrity(resource, task, testAssignment, shouldPass);

      return testAssignment;
   } // createandVerifyAssignment
/*
   // This method will test basic object-level rules for the constraint object:
   // Creation (onInitialize)
   // TODO:  not currently done - Creation (setDefaultProperties)
   // Modification (onSet)
   // Retrieval (onGet (parameter ABTValue myValue)
   //            onGet (parameter int myIndex))
   // Addition to object set (onAdd)
   // Removal from Object set (onRemove)
   // Clear entire object set (onClear)
   // Delete object (onDelete)
   // SPECIAL TESTS:
   //       Test with null Task
   //       Test with deleted Task
   //       Valid task whose project has been deleted
   //       Test with extra parameter in hashtable (extra Task object)
   //       Test with wrong object type in hashtable (project)
   //       Test duplicate Constraint (same Task)???
   //       Test different Task
   //       Test duplicate internal ID???
   public void testConstraint() // throws TestRuleException
   {
      CurrentLog.LogDisplay(COMMENT,"Testing Constraint object");
      // First, create the parent objects needed for Constraints
      ABTObject    project     = createObject( OBJ_PROJECT, null, -1, true );
      ABTObject    project2     = createObject( OBJ_PROJECT, null, -1, true );
      ABTObject    task        = createTask( project, null, 10, true );
      ABTObject    task2       = createTask( project2, null, 11, true );
      ABTObject    deletedtask        = createTask( project, null, 20, true );
      // Attempt to create Constraint with null parameters
      CurrentLog.LogDisplay(COMMENT,"Testing bad Constraints - should generate errors");
      // Test with null Task
      ABTObject nullConstraint = createConstraint( null, 0, false);
      // Attempt to create with deleted Task
      deletedtask.delete(session_);
      nullConstraint = createConstraint( deletedtask, 1, false);
      // Attempt to create with wrong object (Project)
      nullConstraint = createConstraint( project, 2, false);
      // Create and verify Constraint object (should invoke oninitialize and
      // setdefaultproperties)
      CurrentLog.LogDisplay(COMMENT,"Create and verify good Constraint");
      ABTObject constraint1 = createandVerifyConstraint(task, 100, true);
      // Attempt to create duplicate Constraint (same task and resource)
      CurrentLog.LogDisplay(COMMENT,"Create and verify duplicate Constraint - same task with different ID - should be OK");
      ABTObject constraint2 = createandVerifyConstraint( task, 101, true);
      CurrentLog.LogDisplay(COMMENT,"Create and verify other Constraint - different task with different ID");
      ABTObject constraint3 = createandVerifyConstraint( task2, 102, true);
      // Delete Constraint (onDelete)
      CurrentLog.LogDisplay(COMMENT,"Delete Constraint objects");
      if (constraint1 != null)
      {
          CurrentLog.LogDisplay(COMMENT,"Deleting first Constraint");
          if (true == deleteObject(constraint1,true))
          {
              CurrentLog.LogWrite(PASS,"Delete success");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Delete failure");
          }
          // Attempt to explicitly delete Notes
          // 9/4/98 - AVP - not currently allowed
    //      note11.delete(session_);
    //      note12.delete(session_);
    //      note13.delete(session_);
       //   projectIntegrity( project );
          constraintIntegrity(constraint1, null, false);
          // Attempt to delete again - should fail
          if (false == deleteObject(constraint1,false))
          {
              CurrentLog.LogWrite(PASS,"Second delete failure");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Second delete allowed - should fail");
          }
      }
      if (constraint2 != null)
      {
          CurrentLog.LogDisplay(COMMENT,"Deleting second constraint");
          if (true == deleteObject(constraint2,true))
          {
              CurrentLog.LogWrite(PASS,"Delete success");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Delete failure");
          }
          // Attempt to explicitly delete Notes
          // 9/4/98 - AVP - not currently allowed
    //      note11.delete(session_);
    //      note12.delete(session_);
    //      note13.delete(session_);
       //   projectIntegrity( project );
          constraintIntegrity(constraint2, null, false);
          // Attempt to delete again - should fail
          if (false == deleteObject(constraint2,false))
          {
              CurrentLog.LogWrite(PASS,"Second delete failure");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Second delete allowed - should fail");
          }
      }
      if (constraint3 != null)
      {
          CurrentLog.LogDisplay(COMMENT,"Deleting third constraint");
          if (true == deleteObject(constraint3,true))
          {
              CurrentLog.LogWrite(PASS,"Delete success");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Delete failure");
          }
          // Attempt to explicitly delete Notes
          // 9/4/98 - AVP - not currently allowed
    //      note11.delete(session_);
    //      note12.delete(session_);
    //      note13.delete(session_);
       //   projectIntegrity( project );
          constraintIntegrity(constraint3, null, false);
          // Attempt to delete again - should fail
          if (false == deleteObject(constraint3,false))
          {
              CurrentLog.LogWrite(PASS,"Third delete failure");
          } else
          {
              CurrentLog.LogDisplay(FAIL,"Third delete allowed - should fail");
          }
      }
   } // testConstraint

   public ABTObject createandVerifyConstraint(ABTObject task, int RemoteID, boolean shouldPass) // throws TestRuleException
   {

      ABTObject   testConstraint = createConstraint( task, RemoteID, shouldPass );
      if (null == testConstraint)
      {
        return null;
      }
      constraintIntegrity(testConstraint, null, true);
      // Testing setting values for default properties (those that don't invoke field-level rules)
      propertyDefaults(testConstraint, true);
      // Retrieve constraint object property values (test onget)
      // Attempt to add to object set (onAdd)
      CurrentLog.LogDisplay(COMMENT,"Attempt ObjectSet manipulation directly - should not be allowed");
      ABTObjectSet TestConstraints = createObjectSet(OBJ_CONSTRAINT, true);
      addListMember(TestConstraints,testConstraint, false);
      add(TestConstraints,testConstraint, false);
      addNew(TestConstraints, false);
      // Attempt to remove from object set (onRemove)
      remove(TestConstraints,testConstraint, false);
      removeListMember(TestConstraints,testConstraint, false);
      // Attempt to clear an object set (onClear)
      clear(TestConstraints, false);
      clearListMember(TestConstraints, false);
      constraintIntegrity(testConstraint, null, true);

      return testConstraint;
   } // createandVerifyConstraint


   // This method will test basic object-level rules for the custfieldvalue object:
   // Creation (onInitialize)
   // TODO:  not currently done - Creation (setDefaultProperties)
   // Modification (onSet)
   // Retrieval (onGet (parameter ABTValue myValue)
   //            onGet (parameter int myIndex))
   // Addition to object set (onAdd)
   // Removal from Object set (onRemove)
   // Clear entire object set (onClear)
   // Delete object (onDelete)
   // SPECIAL TESTS:
   //       Test with object passed in hashtable parameter (currently not used)
   //       Test with null hashtable (should be fine)
   //       Test adding to objectset of deleted Project
   //       Test adding to objectset of deleted Task
   //       Test adding to objectset of wrong object
   //       Valid task whose project has been deleted
   //       All of these should be OK:
   //       Test duplicate same Project
   //       Test duplicate same Task
   //       Test different Project
   //       Test different Task, same Project
   //       Test different Task, different Project
   //       Test duplicate internal ID???
   //       After removal from object set, test getobjects and findobject via local ID
   public void testCustFieldValue() // throws TestRuleException
   {
      CurrentLog.LogDisplay(COMMENT,"Testing CustFieldValue object");
      // First, create the parent objects needed for CustFieldValues
      ABTObject    project     = createObject( OBJ_PROJECT, null, -1, true );
      ABTObject    project2     = createObject( OBJ_PROJECT, null, -1, true );
      ABTObject    deletedproject = createObject( OBJ_PROJECT, null, -1, true );
      ABTObject    task        = createTask( project, null, 10, true );
      ABTObject    task2       = createTask( project2, null, 11, true );
      ABTObject    task12       = createTask( project, null, 12, true );
      ABTObject    deletedtask  = createTask( project, null, 20, true );
 //     ABTObject    resource   = createResource(1, true);
      // Attempt to create CustFieldValue with task object (not used)
      CurrentLog.LogDisplay(COMMENT, "Attempt to create with Task object attached");
      ABTObject nullCustFieldValue = createCustFieldValue( task, 0, false);
      // Create and verify CustFieldValue object (should invoke oninitialize and
      // setdefaultproperties)
      CurrentLog.LogDisplay(COMMENT,"Create good CustFieldValue");
      // create custfieldvalue
      ABTObject custfieldvalue1 = createCustFieldValue( null, 100, true );
      // Add custfield object to Task
      CurrentLog.LogDisplay(COMMENT,"add good CustFieldValue to parent objectset");
      add( getObjectSet( task, OFD_CUSTFIELDVALUES, true ), custfieldvalue1, true );
      // again, should break
      CurrentLog.LogDisplay(COMMENT,"add SAME CustFieldValue to SAME parent objectset");
      add( getObjectSet( task, OFD_CUSTFIELDVALUES, true ), custfieldvalue1, false );
      // Add same custfield object to Project
      CurrentLog.LogDisplay(COMMENT,"add same CustFieldValue to OTHER parent objectset");
      add( getObjectSet( project, OFD_CUSTFIELDVALUES, true ), custfieldvalue1, false );
      // Add duplicate custfield object to Project - should break
      CurrentLog.LogDisplay(COMMENT,"add same CustFieldValue to SAME OTHER parent objectset");
      add( getObjectSet( project, OFD_CUSTFIELDVALUES, true ), custfieldvalue1, false );
      // Add same custfield object to Resource - should break
//      CurrentLog.LogDisplay(COMMENT,"add to Resource objectset");
//      add( getObjectSet( resource, OFD_NOTES, true ), custfieldvalue1, false );
      // Delete CustFieldValue (onDelete)
      if (custfieldvalue1 != null)
      {
          CurrentLog.LogDisplay(COMMENT,"Deleting first CustFieldValue - not allowed");
          if (true == deleteObject(custfieldvalue1,false))
          {
              CurrentLog.LogDisplay(FAIL,"Delete allowed");
          } else
          {
              CurrentLog.LogWrite(PASS,"Delete not allowed");
          }
      }
      // Attempt to create custfieldvalue, attach to task
      ABTObject custfieldvalue2 = createandVerifyCustFieldValue(task12, 101, true);
      // Attempt to create another CustFieldValue (same task)
      CurrentLog.LogDisplay(COMMENT,"Create and verify duplicate CustFieldValue - same task with different ID - should be OK");
      ABTObject custfieldvalue3 = createandVerifyCustFieldValue( task12, 102, true);
      CurrentLog.LogDisplay(COMMENT,"Create and verify other CustFieldValue - different task with different ID");
      ABTObject custfieldvalue4 = createandVerifyCustFieldValue( task2, 103, true);
      // Attempt to create with deleted Task
      deletedtask.delete(session_);
      CurrentLog.LogDisplay(COMMENT,"Create and verify CustFieldValue with deleted task as parent object");
      ABTObject custfieldvalue5 = createandVerifyCustFieldValue( deletedtask, 104, false);

   } // testCustFieldValue


   // This method will actually delete the object when testing onremove,
   // so the object will be deleted by the time it is returned to calling method
   public ABTObject createandVerifyCustFieldValue(ABTObject parentobject, int RemoteID, boolean shouldPass) // throws TestRuleException
   {

      ABTObject   testCustFieldValue = createCustFieldValue( parentobject, RemoteID, shouldPass );
      if (null == testCustFieldValue)
      {
        return null;
      }
      // Explicitly add to parent object
      CurrentLog.LogDisplay(COMMENT,"Add CustFieldValue to parent objectset");
      ABTObjectSet parentobjectset = getObjectSet( parentobject, OFD_CUSTFIELDVALUES, shouldPass );
      if (parentobjectset == null)
      {
        if (false == shouldPass)
        {
            CurrentLog.LogWrite(PASS,"parentobjectset null, should not pass");
        } else
        {
            CurrentLog.LogDisplay(FAIL,"parentobjectset null, should not be");
        }
        return null;
      }
      add( parentobjectset, testCustFieldValue, shouldPass );
      // Testing setting values for default properties (those that don't invoke field-level rules)
      propertyDefaults(testCustFieldValue, shouldPass );
      // Explicitly add duplicate to parent object
      CurrentLog.LogDisplay(COMMENT,"Add same CustFieldValue to parent object via add");
      add( parentobjectset, testCustFieldValue, false );
      CurrentLog.LogDisplay(COMMENT,"Add same CustFieldValue to parent object via addListMember");
      addListMember(parentobjectset, testCustFieldValue, false);
      ABTObject newCustFieldValue = addNew(parentobjectset, true);
      // Attempt to remove from object set (onRemove) - confirm that they are deleted
      remove(parentobjectset, testCustFieldValue, shouldPass);
      if (testCustFieldValue.isDeleted(session_))
      {
          CurrentLog.LogWrite(PASS,"Remove also deleted the object");
      } else
      {
          CurrentLog.LogDisplay(FAIL,"Remove DID NOT delete the object");
      }
      removeListMember(parentobjectset, newCustFieldValue, shouldPass);
      if (newCustFieldValue.isDeleted(session_))
      {
          CurrentLog.LogWrite(PASS,"RemovefromSet also deleted the object");
      } else
      {
          CurrentLog.LogDisplay(FAIL,"RemovefromSet DID NOT delete the object");
      }
      // Add afew more, then clear - confirm that they are deleted
      newCustFieldValue = addNew(parentobjectset, shouldPass);
      ABTObject newCustFieldValue2 = addNew(parentobjectset, shouldPass);
      // Attempt to clear an object set (onClear)
      clear(parentobjectset, shouldPass);
      clearListMember(parentobjectset, shouldPass);
      if (newCustFieldValue.isDeleted(session_))
      {
          CurrentLog.LogWrite(PASS,"Clear also deleted the object");
      } else
      {
          CurrentLog.LogDisplay(FAIL,"Clear DID NOT delete the object");
      }
      removeListMember(parentobjectset, newCustFieldValue, shouldPass);
      if (newCustFieldValue2.isDeleted(session_))
      {
          CurrentLog.LogWrite(PASS,"clearSet also deleted the object");
      } else
      {
          CurrentLog.LogDisplay(FAIL,"clearSet DID NOT delete the object");
      }
      // Retrieve custfieldvalue object property values (test onget)
      // Attempt to add new to object set (onAdd)
      CurrentLog.LogDisplay(COMMENT,"Attempt ObjectSet manipulation directly - with separate objectset, not parent - should be allowed");
      ABTObjectSet TestCustFieldValues = createObjectSet(OBJ_CUSTFIELDVALUE, true);
      newCustFieldValue = addNew(TestCustFieldValues, true);
      newCustFieldValue2 = addNew(TestCustFieldValues, true);
      ABTObject newCustFieldValue3 = addNew(TestCustFieldValues, true);
      ABTObject newCustFieldValue4 = addNew(TestCustFieldValues, true);
      // Attempt to remove from object set (onRemove)
      remove(TestCustFieldValues,newCustFieldValue, true);
      removeListMember(TestCustFieldValues,newCustFieldValue2, true);
      // Attempt to clear an object set (onClear)
      clear(TestCustFieldValues, true);
      clearListMember(TestCustFieldValues,true);
      return testCustFieldValue;

   } // createandVerifyCustFieldValue
*/
   // This method is a "surface" verification of the presence of
   // Field-level Business Rules, and of all other property attributes
   // in the Sanani object models.
   // The purpose is to compare to Zane Schaefer's object model document
   // (Excel spreadsheet).
   // Each object in the Project, Global, and Methodology object model
   // will be created in object space.
   // For each object, propertyDefaults(ABTObject) will be called, which will
   // perform default properties verification against a CSV of the spreadsheet.
   // KLUGE:  Default value verification is hardcoded within this method.
   // All other verification is performed automatically in propertyDefaults
   public void testFieldRules() // throws TestRuleException
   {
      CurrentLog.LogDisplay(COMMENT,"Testing Field Rules");

      // Special request from Zane:  Use CSV format to log failures, so must be separate from automatic "fail" log file
      try
      {
          PropertyFailLog = new LogFile("TestDiscrepancy.csv",false,false);
      } catch (Exception e)
      {
          CurrentLog.LogDisplay(FAIL,"Java Exception encountered creating property fail log, error = " + e);
      }

      // Read the property CSV file and load all data into vector
      try
      {
          ReadCSVFile("PropertyList.CSV");
      } catch (Exception e)
      {
          CurrentLog.LogDisplay(FAIL,"Java Exception encountered reading csv file, error = " + e);
      }

      // Populate the vector tying actual field type constants to Field Type descriptions
      // in CSV file.
      fieldTypeVector = new Vector(10,1);
      fieldTypeVector.addElement(new fieldType("Array",PROP_ARRAY));
      fieldTypeVector.addElement(new fieldType("Boolean",PROP_BOOLEAN));
      fieldTypeVector.addElement(new fieldType("Curve",PROP_BLOB));
      fieldTypeVector.addElement(new fieldType("Date",PROP_TIMESTAMP));
      fieldTypeVector.addElement(new fieldType("Double",PROP_DOUBLE));
      fieldTypeVector.addElement(new fieldType("Enum",PROP_SHORT));
      fieldTypeVector.addElement(new fieldType("Memo",PROP_STRING));
      fieldTypeVector.addElement(new fieldType("Short",PROP_SHORT));
      fieldTypeVector.addElement(new fieldType("Text",PROP_STRING));
      fieldTypeVector.addElement(new fieldType("Time",PROP_TIMESTAMP));
      // Same for extended field types
      extendedFieldTypeVector = new Vector(10,1);
      extendedFieldTypeVector.addElement(new fieldType("$",PROP_EXTTYPE_MONEY));
      extendedFieldTypeVector.addElement(new fieldType("%",PROP_EXTTYPE_PERCENT));
      extendedFieldTypeVector.addElement(new fieldType("PM",PROP_EXTTYPE_PM));
      extendedFieldTypeVector.addElement(new fieldType("Date",PROP_EXTTYPE_DATE));
      extendedFieldTypeVector.addElement(new fieldType("Memo",PROP_EXTTYPE_MEMO));
      extendedFieldTypeVector.addElement(new fieldType("Usg",PROP_EXTTYPE_RESUNIT));
//      extendedFieldTypeVector.addElement(new fieldType("Usg",PROP_EXTTYPE_RESAVAILUNIT));

      // Create all objects, and verify default values immediately after creation of
      // each object - Project, Global, and Methodology Models

      // Global Model
      CurrentLog.LogDisplay(COMMENT,"Create Global Model");
      ABTObject    site       = createSite(1, true);
//      space_.findObject(session_, site.getObjectType(), new ABTRemoteIDInteger(1));
      verifyValue(site,OFD_TRACKSCALE, new ABTInteger(2), "DEFAULT", true);
      ABTObject    adjrule    = createAdjRule(site, 1, true);
      ABTObject    calendar = createCalendar (site, 1, true);
      setValue(calendar, OFD_VALUE, new ABTCalendar(), true);
      setValue(site,OFD_CALENDAR,new ABTCalendar(),true);
      setValue(site,OFD_STDCALENDAR,calendar,true);
      ABTObject    chargecode = createChargeCode (site, 1, true);
      ABTObject    customfield = createCustomField(site, 1, true);
      ABTObject    customfield2 = createCustomField(site, 2, true);
      ABTObject    aggfield = createAggregateField (customfield, customfield2, 1, true);
      verifyValue(aggfield,OFD_WEIGHT,new ABTInteger(1),"DEFAULT", true);
      ABTObject    customenum = createCustomEnum (customfield, 1, true);
      ABTObject    estmodelglobal = createEstModelGlobal (site, 1, true);
      ABTObject    resource   = createResource(site, 1, true);
      setValue(resource,OFD_BASECALENDAR,calendar,true);
      setValue(resource,OFD_CALENDAR,new ABTCalendar(),true);
      verifyValue(resource,OFD_UNIT,new ABTInteger(0), "DEFAULT", true);
      verifyValue(resource,OFD_TRACKMODE,new ABTInteger(0), "DEFAULT", true);
      verifyValue(resource,OFD_AVAILUNIT,new ABTInteger(0), "DEFAULT", true);
      verifyValue(resource,OFD_TYPE, new ABTInteger(0), "DEFAULT", true);
      verifyValue(resource,OFD_RATE, new ABTInteger(1), "DEFAULT", true);
      verifyValue(resource,OFD_COUNT, new ABTInteger(1), "DEFAULT", true);
      setValue(resource,OFD_RATE, new ABTInteger(0), true);
      ABTObject    timeperiod = createTimePeriod (site, 1, true);
      ABTObject    typecode = createTypeCode (site, 1, true);

      // Project Model
      CurrentLog.LogDisplay(COMMENT,"Create Project Model");
      ABTObject    project     = createProject( 1, true );
      /* AVP Sanani Bug #605 - 11/20/98
      setValue(project,OFD_STARTIMPOSED, new ABTBoolean(true) , true);
      setValue(project,OFD_FINISHIMPOSED, new ABTBoolean(true) , true);
      setValue(project,OFD_FINISH, ABTDate.valueOf("11/24/98"), true);
      setValue(project,OFD_START, ABTDate.valueOf("11/25/98"), true);
      verifyValue(project,OFD_START,ABTDate.today(), "DEFAULT", true);
      verifyValue(project,OFD_FINISH, ABTDate.today(), "DEFAULT", true);
*/
/*  AVP PMW Bug #12742 - are decimals allowed in Budget?
*/
      setValue(project,OFD_BUDGET, ABTDouble.valueOf("12345678.34"), true);
      verifyValue(project, OFD_BUDGET, ABTDouble.valueOf("12345678.34"), true);
      verifyValue(project,OFD_FORMAT,new ABTInteger(0), "DEFAULT", true);
      verifyValue(project,OFD_VERSION, new ABTInteger(1), "DEFAULT", true);
      verifyValue(project,OFD_TRACKMODE,new ABTInteger(0), "DEFAULT", true);
      verifyValue(project,OFD_CPMTYPE,new ABTInteger(0), "DEFAULT", true);
      verifyValue(project,OFD_FISCALSTART, ABTDate.valueOf("1/1/98"), "DEFAULT", true);
      verifyValue(project,OFD_SIZEADJUST, new ABTInteger(0), "DEFAULT", true);
      verifyValue(project,OFD_SIZEADJUSTON, new ABTBoolean(false), "DEFAULT", true);
      verifyValue(project,OFD_PRIORITY, new ABTInteger(10), "DEFAULT", true);
      // AVP 11/10/98: These defaults will not be retrieved without OFD_ACTCURVE and OFD_ESTCURVE being set
//      verifyValue(project,OFD_FINISH, ABTDate.today(), "DEFAULT", true);
//      verifyValue(project,OFD_START, ABTDate.today(), "DEFAULT", true);
      ABTObject    team       = createTeamResource( project, resource, 1, true );
      verifyValue(team,OFD_ALLOCCURVE,new ABTInteger(100), "DEFAULT", true);
// AVP 11/20/98 - special test for Zane - does Sanani handle eachAvail curve correctly? Yes!
// Sanani Bug #607 - AvailStart and AvailFinish still required?
      setValue(team, OFD_AVAILSTART, ABTTime.valueOf("6/4/79 12:00 AM"), true);
      setValue(team, OFD_AVAILFINISH, ABTTime.valueOf("12/30/99 12:00 AM"), true);
/* YAZT - 12/2/98 - eachAvail with different Units of Measure
      setValue(resource, OFD_UNIT, new ABTShort(kHours), true);
      // Hours
      ABTValue eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), kHours, true);
//      ((ABTCurve)eachAvail).resetSegment(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      double firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      double secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      double thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      double fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      setValue(resource, OFD_UNIT, new ABTShort(kDays), true);
      // Days
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), kDays, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      setValue(resource, OFD_UNIT, new ABTShort(kCost), true);
      // Cost
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), kCost, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      // Quantity
      setValue(resource, OFD_UNIT, new ABTShort(kQuantity), true);
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), kQuantity, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      // Hours
      setValue(resource, OFD_UNIT, new ABTShort(kHours), true);
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), kHours, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      // Hours
      setValue(resource, OFD_UNIT, null, true);
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), -1, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      // Unspecified
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), -1, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
      // Days
      setValue(resource, OFD_UNIT, null, true);
      eachAvail = getValue(team,OFD_EACH_AVAIL, ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"), kDays, true);
      // Should be 1 working day
      firstSum = ((ABTCurve)eachAvail).getSum();
      // Should be 5 working days
      secondSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/15/98 12:00 AM"),ABTTime.valueOf("11/22/98 12:00 AM"));
      // Should be 1 working day
      thirdSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/17/98 12:00 AM"));
      // Should be 2 working days
      fourthSum = ((ABTCurve)eachAvail).getSum(ABTTime.valueOf("11/16/98 12:00 AM"),ABTTime.valueOf("11/18/98 12:00 AM"));
*/

      ABTObject    task        = createTask( project, null, null, 1, true );
      // AVP - 11/20/98 - Test PMW Bug #12948
/*      ABTValue testStart = getValue(task, OFD_START, true);
      ABTValue testFinish = getValue(task, OFD_FINISH, true);
      ABTValue duration = getValue(task, OFD_DURATION, true);
  //    setValue(task, OFD_DURATION, new ABTDouble(4.0), true);

//      setValue(task, OFD_START, ABTTime.valueOf("11/19/98 8:00 AM"), true);

      duration = getValue(task, OFD_DURATION, true);
      testStart = getValue(task, OFD_START, true);
      testFinish = getValue(task, OFD_FINISH, true);
*/
//      setValue(task, OFD_ISMILESTONE, new ABTBoolean(true), true);
/*
      ABTValue testStart = getValue(task, OFD_START, true);
      ABTValue duration = getValue(task, OFD_DURATION, true);
      ABTValue testFinish = getValue(task, OFD_FINISH, true);
*/
//      verifyValue(task, OFD_ISMILESTONE, new ABTBoolean(true), "TEST 12948", true);
//      verifyValue(task, OFD_ISTASK, new ABTBoolean(true), "TEST 12948", true);

 //special test for Zane - 11/5/98
/*
 // TEST START DURATION VARIANCE (Difference between BaseStart and Start)
      setValue(task, OFD_CALENDAR, calendar, true);
      setValue(task, OFD_BASESTART,ABTTime.valueOf("12/1/98 8:00 AM"),true);
      verifyValue(task,OFD_BASESTART,ABTTime.valueOf("12/1/98 8:00 AM"),"SPECIAL TEST 1", true);
      setValue(task, OFD_START,ABTTime.valueOf("12/2/98 8:00 AM"),true);
      verifyValue(task,OFD_START,ABTTime.valueOf("12/2/98 8:00 AM"),"SPECIAL TEST 1", true);
      verifyValue(task,OFD_START_VARIANCE,new ABTDouble(1.0),"SPECIAL TEST 1", true);
      // Have just set Start, so no Duration Variance or End Variance yet
      verifyValue(task,OFD_DURATION_VARIANCE,null,"SPECIAL TEST 1", true);
      verifyValue(task,OFD_END_VARIANCE,null,"SPECIAL TEST 1", true);
 // TEST FINISH DURATION VARIANCE (Difference between BaseFinish and Finish)
      setValue(task, OFD_BASEFINISH,ABTTime.valueOf("12/2/98 5:00 PM"),true);
      verifyValue(task,OFD_BASEFINISH,ABTTime.valueOf("12/2/98 5:00 PM"),"SPECIAL TEST 2", true);
      setValue(task, OFD_FINISH,ABTTime.valueOf("12/4/98 5:00 PM"), true);
      verifyValue(task,OFD_FINISH,ABTTime.valueOf("12/4/98 5:00 PM"),"SPECIAL TEST 2", true);
      verifyValue(task,OFD_START_VARIANCE,new ABTDouble(1.0),"SPECIAL TEST 2", true);
      verifyValue(task,OFD_DURATION_VARIANCE,null,"SPECIAL TEST 2", true);
      verifyValue(task,OFD_END_VARIANCE,new ABTDouble(2.0),"SPECIAL TEST 2", true);
// TEST DURATION VARIANCE (Difference between BaseDuration and Duration)
      setValue(task, OFD_BASEDURATION, new ABTDouble(3.0),true);
      setValue(task, OFD_DURATION, new ABTDouble(2.0),true);
      verifyValue(task,OFD_BASEDURATION, new ABTDouble(3.0), true);
      verifyValue(task,OFD_DURATION, new ABTDouble(2.0), true);
      verifyValue(task,OFD_DURATION_VARIANCE,new ABTDouble(1.0),"SPECIAL TEST 3", true);
      verifyValue(task,OFD_STATUS,new ABTInteger(0),"DEFAULT", true);
      verifyValue(task,OFD_ISEXTERNAL, new ABTBoolean(false), "DEFAULT", true);
      verifyValue(task,OFD_ISTASK, new ABTBoolean(true), "DEFAULT", true);
      verifyValue(task,OFD_WBSTYPE, new ABTInteger(-2), "DEFAULT", true);
      verifyValue(task,OFD_PCTCOMPLETE, new ABTInteger(0), "DEFAULT", true);
//      verifyValue(task,OFD_FINISH, ABTDate.today(), "DEFAULT", true);
//      verifyValue(task,OFD_START, ABTDate.today(), "DEFAULT", true);
*/
      // Default in spreadsheet is actually "?" - NOT 0
//      verifyValue(task,OFD_DURATION, new ABTInteger(0), "DEFAULT", true);
      ABTObject    task2 = createTask (project, null, null, 2, true);
      ABTObject    assignment  = createAssignment( task, resource, 1, true);
// AVP 12/02/98 - yet another test for Zane - can we set a curve to a double?
      setValue(task, OFD_START,ABTTime.valueOf("12/1/98 8:00 AM"), true);
      setValue(task, OFD_FINISH,ABTTime.valueOf("12/4/98 5:00 PM"), true);
      setValue(assignment,OFD_ESTCURVE,new ABTDouble(1.0), true);
      verifyValue(assignment,OFD_ESTCURVE,new ABTDouble(1.0),"SPECIAL TEST 12298", true);
      verifyValue(assignment,OFD_STATUS,new ABTInteger(0),"DEFAULT", true);
      verifyValue(assignment,OFD_ESTMAX,new ABTInteger(1),"DEFAULT", true);
      verifyValue(assignment,OFD_ESTPATTERN,new ABTInteger(2),"DEFAULT", true);
//      verifyValue(assignment,OFD_FINISH, ABTDate.today(), "DEFAULT", true);
//      verifyValue(assignment,OFD_START, ABTDate.today(), "DEFAULT", true);
      ABTObject    constraint  = createConstraint( task, 1, true);
      ABTObject    custfieldvalue  = createCustFieldValue( task, 1, true);
      ABTObject    deliverable  = createDeliverable( project, 1, true);
      ABTObject    dependency = createDependency (task, task2, 1, true);
      verifyValue(dependency,OFD_AMOUNT,new ABTInteger(0), "DEFAULT", true);
      verifyValue(dependency,OFD_AMOUNTTYPE,new ABTInteger(0), "DEFAULT", true);
      verifyValue(dependency,OFD_TYPE,new ABTInteger(0), "DEFAULT", true);
      ABTObject    estmodel  = createEstmodel( project, 1, true);
      ABTObject    estimate  = createTaskestimate( task, estmodel, 1, true);
      verifyValue(estimate,OFD_OVERRIDE, new ABTBoolean(false), "DEFAULT", true);
      verifyValue(estimate,OFD_VALUE, new ABTInteger(0), "DEFAULT", true);
      ABTObject    note  = createNote(1, true);
      verifyValue(note,OFD_CREATEDTIME,ABTTime.now(), "DEFAULT", true);
      ABTObject    subprojlink = createSubprojectlink (task, 1, true);
      verifyValue(subprojlink,OFD_INCLUDERES, new ABTBoolean(true), "DEFAULT", true);
      verifyValue(subprojlink,OFD_ISLOCKED, new ABTBoolean(false), "DEFAULT", true);
      verifyValue(subprojlink,OFD_ISREADONLY, new ABTBoolean(false), "DEFAULT", true);
      verifyValue(subprojlink,OFD_SHOWDETAIL, new ABTBoolean(true), "DEFAULT", true);
      verifyValue(subprojlink,OFD_SUMMARIZE, new ABTBoolean(false), "DEFAULT", true);

      // Methodology Model
      CurrentLog.LogDisplay(COMMENT,"Create Methodology Model");
      ABTObject    method = createMethod( 1, true );
      verifyValue(method,OFD_VERSION,new ABTInteger(1), "DEFAULT", true);
      ABTObject    MMtask = createMMTask( method, null, null, 1, true);
      verifyValue(MMtask,OFD_ISTASK, new ABTBoolean(true), "DEFAULT", true);
      // Default in spreadsheet is actually "?" - NOT 0
      // verifyValue(MMtask,OFD_DURATION, new ABTInteger(0), "DEFAULT", true);
      ABTObject    MMtask2 = createMMTask( method, null, null, 2, true);
      ABTObject    MMassignment = createMMAssignment( MMtask, resource, 1, true);
      ABTObject    MMdeliverable  = createMMDeliverable( method, 1, true);
      ABTObject    MMdependency = createMMDependency (MMtask, MMtask2, 1, true);
      verifyValue(MMdependency,OFD_AMOUNT,new ABTInteger(0), "DEFAULT", true);
      verifyValue(MMdependency,OFD_AMOUNTTYPE,new ABTInteger(0), "DEFAULT", true);
      verifyValue(MMdependency,OFD_TYPE,new ABTInteger(0), "DEFAULT", true);
      ABTObject    MMestimate  = createMMTaskestimate( MMtask, estmodelglobal, 1, true);
      ABTObject    MMpackage  = createPackage( method, new ABTBoolean(true), 1, true);
      verifyValue(MMpackage,OFD_HIDDEN,new ABTBoolean(false), "DEFAULT", true);
      ABTObject    MMpackagemember  = createPackageMember( MMtask, MMpackage, 1, true);
      ABTObject    MMpage  = createPage( method, 1, true);
      ABTObject    MMpagemember  = createPageMember( MMpage, customfield, 1, true);

      // Verify all properties of Project and Global Model objects, in alphabetical order
      // 10/29/98 AVP now verify all Methodology Model objects as well
      propertyDefaults(aggfield);
      propertyDefaults(adjrule);
      propertyDefaults(assignment);
      propertyDefaults(MMassignment);
      propertyDefaults(calendar);
      propertyDefaults(chargecode);
      propertyDefaults(constraint);
      propertyDefaults(customenum);
      propertyDefaults(custfieldvalue);
      propertyDefaults(customfield);
      propertyDefaults(deliverable);
      propertyDefaults(MMdeliverable);
      propertyDefaults(dependency);
      propertyDefaults(MMdependency);
      propertyDefaults(estimate);
      propertyDefaults(MMestimate);
      propertyDefaults(estmodel);
      propertyDefaults(estmodelglobal);
      propertyDefaults(note);
      propertyDefaults(method);
      propertyDefaults(MMpackage);
      propertyDefaults(MMpackagemember);
      propertyDefaults(MMpage);
      propertyDefaults(MMpagemember);
      propertyDefaults(project);
      propertyDefaults(resource);
      propertyDefaults(site);
      propertyDefaults(subprojlink);
      propertyDefaults(task);
      propertyDefaults(MMtask);
      propertyDefaults(team);
      propertyDefaults(timeperiod);
      propertyDefaults(typecode);


   } // testFieldRules


/*
   public void assignments() // throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null );
      ABTObject    resource1   = createResource( 1 );
      ABTObject    resource2   = createResource( 2 );
      ABTObject    resource3   = createResource( 3 );
      ABTObject    team1       = createTeamResource( project, resource1, 1 );
      ABTObject    team2       = createTeamResource( project, resource2, 2 );
      ABTObject    team3       = createTeamResource( project, resource3, 3 );

      ABTObjectSet teams       = getObjectSet( project, OFD_TEAMRESOURCES );

      ABTObject    task        = createTask( project, null, 10 );
// This will generate circular error, since value already set
//      setValue( project, OFD_FIRSTCHILDTASK, task );

      //
      // Set the name fields in each resource
      //
      setValue( resource1, OFD_NAME, new ABTString( "Resource 1" ) );
      setValue( resource2, OFD_NAME, new ABTString( "Resource 2" ) );
      setValue( resource3, OFD_NAME, new ABTString( "Resource 3" ) );

      ABTObject    assignment1 = createAssignment( task, resource1, 20 );
      ABTObject    assignment2 = createAssignment( task, resource2, 21 );
      ABTObject    assignment3 = createAssignment( task, resource3, 22 );

      // AVP - 9/4/98 - add Notes just for 1 Assignment
      ABTObject      note11 = createNote(11);
      ABTObject      note12 = createNote(12);
      ABTObject      note13 = createNote(13);
      addListMember( getObjectSet( assignment1, OFD_NOTES ), note11);
      addListMember( getObjectSet( assignment1, OFD_NOTES ), note12);
      addListMember( getObjectSet( assignment1, OFD_NOTES ), note13);

      //
      // Now delete one of the team resources
      //
//      resource1.delete( session_ );

      ABTObjectSet os = getObjectSet( task, OFD_ASSIGNMENTS );
      java.util.Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject obj = (ABTObject)e.nextElement();
      }

      projectIntegrity( project );
      ABTObjectSet NoteObjectSet = getObjectSet(assignment1, OFD_NOTES);
      verifyNotes( NoteObjectSet );
      // Delete Assignment to which Notes are attached
      NoteObjectSet.clear(session_);
      assignment1.delete(session_);
      // Attempt to explicitly delete Notes
      // 9/4/98 - AVP - not currently allowed
//      note11.delete(session_);
//      note12.delete(session_);
//      note13.delete(session_);
   //   projectIntegrity( project );
      verifyNotes( NoteObjectSet );
   }


   public void viewTeam( ABTObject team ) // throws TestRuleException
   {
      ABTObject resource = getObject( team, OFD_RESOURCE );
      ABTValue v = getValue( resource, OFD_NAME );
      String s = v.stringValue();
      int i = 0;
   }

   public void oneAssignmentMethod1() // throws TestRuleException
   {
      ABTObject    project     = createObject( OBJ_PROJECT, null, -1 );
      ABTObject    resource    = createObject( OBJ_RESOURCE, null, -1 );

      ABTHashtable taskreqs = new ABTHashtable();
      taskreqs.put(new ABTString( OFD_PROJECT), project );

      ABTObject task = createObject( OBJ_TASK, taskreqs, -1 );
      setValue( project, OFD_FIRSTCHILDTASK, task );

      ABTHashtable hash = new ABTHashtable();
      hash.put(new ABTString( OFD_PROJECT), project );
      hash.put(new ABTString( OFD_RESOURCE), resource );
      ABTObject team = createObject( OBJ_TEAM, hash, -1 );

      ABTHashtable assignmentParams = new ABTHashtable();
      assignmentParams.put(new ABTString( OFD_TASK), task );
      assignmentParams.put(new ABTString( OFD_RESOURCE), resource );
      ABTObject assignment  = createObject( OBJ_ASSIGNMENT, assignmentParams, -1 );

      projectIntegrity( project, null );
   }
  */
   public void projectIntegrity( ABTObject project, ABTObject callingObject, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         task;
      int               i, size;

      CurrentLog.LogWrite(COMMENT,"Verify Project Integrity");
      os = getObjectSet( project, OFD_SUBPROJECTLINKS, ShouldPass );
      Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject sublink = (ABTObject)e.nextElement();
         if (sublink != null)
         {
             ABTValue v = sublink.getValue( session_, OFD_ID, null );
             if( ABTError.isError( v ) )
                return;
         }
      }

      teamResources( project, ShouldPass );

      task = getObject( project, OFD_FIRSTCHILDTASK, ShouldPass );
      while( task != null )
      {
         taskIntegrity( task, null, project, ShouldPass );
         if (task != null)
         {
             if (!compareObjects(task,callingObject))
             {
                 task = getObject( task, OFD_NEXTTASK, ShouldPass );
             }
         }
      }
   }

   public void taskIntegrity( ABTObject task, ABTObject resource, ABTObject callingObject, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         assignment;
      int               size;

      CurrentLog.LogWrite(COMMENT,"Verify Task Integrity");
      os = getObjectSet( task, OFD_CONSTRAINTS, ShouldPass );
      Enumeration e = os.elements( session_ );
      while( e.hasMoreElements() )
      {
         ABTObject constraint = (ABTObject)e.nextElement();
         if (constraint != null)
         {
             ABTValue v = constraint.getValue( session_, OFD_ID, null );
             if( ABTError.isError( v ) )
                return;
         }
      }

      CurrentLog.LogDisplay(COMMENT, "Assignment resources" );

      os = getObjectSet( task, OFD_ASSIGNMENTS, ShouldPass );
      size = os.size( session_ );
      for (int i = 0; i < size; i++ )
      {
         assignment = (ABTObject)os.at( session_, i );
         // Avoid recursive functions, or testing null object
         if ((!compareObjects(assignment,callingObject)) && (assignment != null))
         {
            assignmentIntegrity( assignment, task, null, -1, ShouldPass );
         }
      }
   }

   public void assignmentIntegrity( ABTObject assignment, ABTObject task, ABTObject resource, int remoteID, boolean shouldPass ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTValue returnValue = null;

      CurrentLog.LogWrite(COMMENT,"Verify Assignment Integrity");
/* Oops - protected method - never mind!
      // VERIFY isvalid
      if (true == assignment.isValid())
        CurrentLog.LogWrite(PASS,"Assignment is valid");
      else
        CurrentLog.LogDisplay(FAIL,"Assignment is not valid");
*/
      // VERIFY onInitialize
      // verify parent objects have been set in correct properties
      ABTObject thisResource = getObject( assignment, OFD_RESOURCE, shouldPass );
      ABTObject thisTask = getObject( assignment, OFD_TASK, shouldPass );
      // If null or empty object, don't test it further
      if (thisResource != null)
      {
          if (resource != null)
          {
              if (compareObjects(thisResource,resource))
              {
                  if (true == shouldPass)
                      CurrentLog.LogWrite(PASS,"Resource as expected for assignment");
                  else
                      CurrentLog.LogDisplay(FAIL,"Resource did match, was not expected to");
    //          Avoid recursive functions
    //              resourceIntegrity( resource, task, assignment, ShouldPass );
              } else
              {
                  if (true == shouldPass)
                      CurrentLog.LogDisplay(FAIL,"Resource does not match for assignment");
                  else
                      CurrentLog.LogWrite(PASS,"Resource does not match, was not expected to");
              }
          }
      } else
      {
          if (true == shouldPass)
              CurrentLog.LogDisplay(FAIL,"resource = null");
          else
              CurrentLog.LogWrite(PASS,"resource = null, expected to fail");
      }
      // If null or empty object, don't test it further
      if (thisTask != null)
      {
          if (task != null)
          {
              if (compareObjects(thisTask,task))
              {
                  if (true == shouldPass)
                      CurrentLog.LogWrite(PASS,"Task as expected for assignment");
                  else
                      CurrentLog.LogDisplay(FAIL,"Task did match, was not expected to");
                  CurrentLog.LogWrite(PASS,"Task as expected for assignment");
    //          Avoid recursive functions
    //              taskIntegrity( task, resource, assignment, ShouldPass );
              } else
              {
                  if (true == shouldPass)
                      CurrentLog.LogDisplay(FAIL,"Task does not match for assignment");
                  else
                      CurrentLog.LogWrite(PASS,"Task does not match, was not expected to");
              }
              // verify child objectset has been set in correct property
              returnValue = getObjectSet( task, OFD_NOTES, shouldPass );
              // If null or empty objectset, don't test it further
              if (returnValue != null)
              {
                  os = (ABTObjectSet)returnValue;
                  noteIntegrity(os, shouldPass);
              }
          }
     } else {
          if (true == shouldPass)
              CurrentLog.LogDisplay(FAIL,"task = null");
          else
              CurrentLog.LogWrite(PASS,"task = null, expected to fail");
     }

   }

   public void constraintIntegrity( ABTObject constraint, ABTObject callingObject, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTValue returnValue = null;

      CurrentLog.LogWrite(COMMENT,"Verify CustFieldValue Integrity");
/* Oops - protected method - never mind!
      // VERIFY isvalid
      if (true == constraint.isValid())
        CurrentLog.LogWrite(PASS,"CustFieldValue is valid");
      else
        CurrentLog.LogDisplay(FAIL,"CustFieldValue is not valid");
*/
      // VERIFY onInitialize
      ABTObject task = getObject( constraint, OFD_TASK, ShouldPass );
      // If null or empty object, don't test it further
      if (task != null)
      {
          // Avoid recursive functions
          if (!compareObjects(task, callingObject))
          {
              taskIntegrity(task, null, constraint, ShouldPass);
          }
/*
          // verify child objectset has been set in correct property
          returnValue = getObjectSet( task, OFD_NOTES, ShouldPass );
          // If null or empty objectset, don't test it further
          if (returnValue != null)
          {
              os = (ABTObjectSet)returnValue;
              noteIntegrity(os, ShouldPass);
          }
*/
     }

   }

/* no parent/child objects to verify
   public void custFieldValueIntegrity( ABTObject custFieldValue, ABTObject callingObject, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTValue returnValue = null;

      CurrentLog.LogWrite(COMMENT,"Verify CustFieldValue Integrity");
      // VERIFY onInitialize
      ABTObject task = getObject( custFieldValue, OFD_TASK, ShouldPass );
      // If null or empty object, don't test it further
      if (task != null)
      {
          // Avoid recursive functions
          if (!compareObjects(task, callingObject))
          {
              taskIntegrity(task, custFieldValue, ShouldPass);
          }
     }

   }
*/

   // First overriden method - verify set and get for default properties
   // (Only non-internal fields)
   public boolean propertyDefaults( ABTObject TestObject, boolean ShouldPass)
   {
        ABTPropertySet
            ReturnProperties = null;
        ABTValue
            isUpdatable = null;

        CurrentLog.LogWrite(COMMENT,"Verify Default Properties for " + TestObject.getRule());
        ReturnProperties = TestObject.getProperties();
        if (null == ReturnProperties)
        {
            CurrentLog.LogDisplay(FAIL,"getProperties for " + TestObject + " returned null");
            return false;
        }  else if (ReturnProperties instanceof ABTPropertySet)
        {
            CurrentLog.LogWrite(PASS,"getProperties for " + TestObject + " returned ABTPropertySet");
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"getProperties did not return null or ABTPropertySet");
            return false;
        } // end if-else for TestObject.getProperties
        // Loop through all properties, testing onset/onget
        for (int PropertyPtr = 0; PropertyPtr < ReturnProperties.size(); PropertyPtr++)
        {
            ABTProperty
                ThisProperty = TestObject.getProperty(session_, PropertyPtr);
            // Verify that Property is not for internal use (Remote ID, Delete Flag, etc.)
            if (false == ThisProperty.isInternal())
            {
                int ThisType = ThisProperty.getType();
                ABTFieldRule ThisRule = ThisProperty.getFieldRule();
                CurrentLog.LogWrite(COMMENT,"Property " + ThisProperty.getName());
                // If this property has no field-level rules, and is not referencing a parent or child object/objectset,
                // test set/get with generic integer value
                if ((ThisRule instanceof ABTDefaultFieldRule) && (ThisType != PROP_OBJECT) && (ThisType != PROP_OBJECTSET))
                {
                    isUpdatable = ThisProperty.getPropertyKey(PROP_KUPDATABLE);
                    if (isUpdatable instanceof ABTBoolean)
                        if (true == isUpdatable.booleanValue())
                        {
                            setValue(TestObject,ThisProperty.getName(),new ABTInteger(PropertyPtr),true);
                            ABTValue ThisValue = getValue(TestObject,ThisProperty.getName(),true);
                            if (ThisValue.intValue() == PropertyPtr)
                            {
                                CurrentLog.LogWrite(PASS,"Property #" + PropertyPtr + " has correct value");
                            } else
                            {
                                CurrentLog.LogDisplay(FAIL,"Property #" + PropertyPtr + " returns getValue of " + ThisValue.intValue());
                            }
                            if (ThisProperty.getName().equals(OFD_ID))
                                CurrentLog.LogDisplay(COMMENT,"prID = " + ThisValue);
                        } // end if this property is updatable
                } // end if default field rule
            } // end if this property is not internal use
        } // end propertyset for loop

        return true;
   } // propertyDefaults(1)

   // Second overriden method
   // This method extracts all attributes for each property in
   // the specified object, then:
   // calls methods findProperty and verifyProperty to log discrepancies
   // (per Zane, discrepancies are logged to CSV file), for each property
   // ABTProperty attribute:     column header from Zane's CSV file:
   // getName                               API Name
   // getCaption                            UI Name
   // getType (int) and
   // getPropertyKey(extended property key) Type
   // isVirtual                             Virtual
   // isVisible                             Visible
   // isUpdateable                          Updateable
   // getPropertyKey(PROP_KEDITABLE)        Editable
   // getPropertyKey(PROP_KHIDDEN)          Hidden
   // isTransient                           Transient
   // getFieldRule                          onSet, onGet
   // After looping through all properties, all of those
   public boolean propertyDefaults( ABTObject testObject)
   {
        ABTPropertySet
            ReturnProperties = null;
        ABTProperty
            thisProperty = null;
        ABTValue
            editableValue = null,
            hiddenValue = null,
            enumValue = null;
        CSVrecord
            propertyValues = null;
        ABTSortedArray
            nameArray = null;
        Enumeration
            enum = null;
        boolean
            propertyFound = false;
        String
            thisPropertyObject = null;


        if (testObject == null)
        {
            CurrentLog.LogDisplay(FAIL,"Could not test null object");
            return false;
        }

        // Adjust for global objects ("abt.") vs. project objects ("pm.") vs. method objects ("mm.")
        // Append ";" to match delimited values in CSV file
        if (testObject.getRule().toString().startsWith("abt."))
            thisPropertyObject = testObject.getRule().toString().substring(4) + ";";
        else
            thisPropertyObject = testObject.getRule().toString().substring(3) + ";";
        // AVP KLUGE: Methodology Model objects,
        // Prefix with M- where duplicate object name in Project Model
        // (currently hardcoded as:  Assignment, Deliverable, Dependency, Task, TaskEstimate)
        // AVP 12/08/98: now is "M." instead of "M-"
        if ((testObject.getRule().toString().equals("mm.Assignment")) ||
            (testObject.getRule().toString().equals("mm.Deliverable")) ||
            (testObject.getRule().toString().equals("mm.Dependency")) ||
            (testObject.getRule().toString().equals("mm.Task")) ||
            (testObject.getRule().toString().equals("mm.TaskEstimate")))
        {
            thisPropertyObject = "M." + testObject.getRule().toString().substring(3) + ";";
        }

        try
        {
            PropertyLog = new LogFile(thisPropertyObject + "Properties",false,false);
        } catch (Exception e)
        {
            CurrentLog.LogDisplay(FAIL,"Could not open object properties log, exception: " + e);
            return false;
        }
        CurrentLog.LogDisplay(COMMENT,"Verify Default Properties for " + testObject.getRule());
        PropertyLog.LogWrite(COMMENT,"The following properties are set for " + testObject.getRule());
        ReturnProperties = testObject.getProperties();
        if (null == ReturnProperties)
        {
            CurrentLog.LogDisplay(FAIL,"getProperties for " + testObject + " returned null");
            return false;
        }  else if (ReturnProperties instanceof ABTPropertySet)
        {
            CurrentLog.LogWrite(PASS,"getProperties for " + testObject + " returned ABTPropertySet");
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"getProperties did not return null or ABTPropertySet");
            return false;
        } // end if-else for testObject.getProperties
        // Sort alphabetically by property name
        nameArray = new ABTSortedArray();
        for (int PropertyPtr = 0; PropertyPtr < ReturnProperties.size(); PropertyPtr++)
        {
            thisProperty = testObject.getProperty(session_, PropertyPtr);
            nameArray.add(new ABTString(thisProperty.getName()));
        }
        nameArray.sort();
        // Loop through all properties - sorted alpha by name
        Enumeration sortenum = nameArray.elements(new ABTDefaultComparator());
        int
            PropertyValue = 0;
        while (sortenum.hasMoreElements())
      //  for (int PropertyPtr = 0; PropertyPtr < ReturnProperties.size(); PropertyPtr++)
        {
            thisProperty = testObject.getProperty(session_, sortenum.nextElement().toString());
            propertyValues = new CSVrecord();
            propertyValues.propertyName = thisProperty.getName();
            propertyValues.propertyObject = thisPropertyObject;
            propertyValues.propertyTypeInt = thisProperty.getType();
            propertyValues.virtualFlag = thisProperty.isVirtual();
            propertyValues.visibleFlag = thisProperty.isVisible();
            propertyValues.updateableFlag = thisProperty.isUpdatable();
            // 10/28/98 AVP new attribute "Hidden" - extended property key like Editable
            // (defaults to false)
            propertyValues.hiddenFlag = false;
            hiddenValue = thisProperty.getPropertyKey(PROP_KHIDDEN);
            if (hiddenValue instanceof ABTBoolean)
               propertyValues.hiddenFlag = hiddenValue.booleanValue();
            propertyValues.internalFlag = thisProperty.isInternal();
            editableValue = thisProperty.getPropertyKey(PROP_KEDITABLE);
            // Default editable to true, unless extended property key set to false
            propertyValues.editableFlag = true;
            if (editableValue instanceof ABTBoolean)
               propertyValues.editableFlag = editableValue.booleanValue();
       //     editableFlag = thisProperty.isEditable();
            propertyValues.transientFlag = thisProperty.isTransient();
            propertyValues.propertyCaption = thisProperty.getCaption();
            propertyValues.propertyRule = thisProperty.getFieldRule();
            enumValue = thisProperty.getPropertyKey(PROP_KPOSSIBLEVALUES);
            if (enumValue instanceof ABTExtendedPropertyList)
                propertyValues.propertyEnums = (ABTExtendedPropertyList)enumValue;
            propertyValues.extMoneyFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_MONEY)));
            propertyValues.extPercentFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_PERCENT)));
            propertyValues.extPMFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_PM)));
            propertyValues.extMemoFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_MEMO)));
            propertyValues.extDateFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_DATE)));
            propertyValues.extResUnitFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_RESUNIT)));
            propertyValues.extResAvailFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_RESAVAILUNIT)));

            // Log all values for this property
            PropertyLog.LogWrite(COMMENT,"Property Name: " + propertyValues.propertyName + ", Caption: " + propertyValues.propertyCaption + ", Type: " + propertyValues.propertyTypeInt + ", Rule: " + propertyValues.propertyRule);
            PropertyLog.LogWrite(COMMENT,"Property " + propertyValues.propertyName + " Flags: Virtual: " + propertyValues.virtualFlag + ", Visible: " + propertyValues.visibleFlag + ", Update: " + propertyValues.updateableFlag + ", Edit: " + propertyValues.editableFlag);
            // Compare to vector of values from CSV file, to find match for this property and verify
            if ((propertyValues.propertyTypeInt != PROP_OBJECT) && (propertyValues.propertyTypeInt != PROP_OBJECTSET))
            {
                propertyFound = findProperty(propertyValues.propertyRule,propertyValues,testObject);
                // if match found in CSV file...
                if (true == propertyFound)
                {
                    PropertyLog.LogWrite(PASS,propertyValues.propertyName + " found in spreadsheet file");
                } else {
                    // Internal properties don't matter for this test
                    if (false == propertyValues.internalFlag)
                        PropertyFailLog.LogDisplay(thisPropertyObject + "," + propertyValues.propertyName + ",NOT IN CSV," + propertyValues.propertyTypeInt + "," + propertyValues.virtualFlag + "," + propertyValues.visibleFlag + "," + propertyValues.updateableFlag + "," + propertyValues.hiddenFlag + "," + propertyValues.editableFlag + "," + propertyValues.transientFlag + "," + (false == (propertyValues.propertyRule instanceof ABTDefaultFieldRule)) + "," + propertyValues.propertyCaption);
//                        PropertyFailLog.LogDisplay(thisPropertyObject + "," + propertyValues.propertyName + ",NOT IN CSV,");
                }
            } // if type != object or objectset
         } // end enum iteration

        // After all verification of properties, run through CSV vector again.
        // Verify that each property listed for this object in CSV file, has been found.
        enum = CSVVector.elements();
        while (enum.hasMoreElements())
        {
            propertyValues = (CSVrecord)enum.nextElement();
            if ((propertyValues.propertyObject.indexOf(thisPropertyObject) != -1)
                 || (propertyValues.propertyObject.indexOf("All") != -1 ) || (propertyValues.propertyObject.indexOf("all") != -1))
                if ((propertyValues.propertyTypeInt != PROP_OBJECT) && (propertyValues.propertyTypeInt != PROP_OBJECTSET))
                  if (false == propertyValues.foundFlag)
                    PropertyFailLog.LogDisplay(thisPropertyObject + "," + propertyValues.propertyName + ",NOT IN OBJECT,");
            propertyValues.foundFlag = false;
        } // end while enumerator

        return true;
   } // propertyDefaults(2)


   public boolean findProperty(ABTFieldRule propertyRule, CSVrecord propertyValues, ABTObject testObject)
   {
        Enumeration e =
            CSVVector.elements();
        CSVrecord
            thisCSVrecord = null;
        boolean
            foundFlag = false;

        while (e.hasMoreElements())
        {
            thisCSVrecord = (CSVrecord)e.nextElement();
            // Test for object name imbedded in list of objects (delimited with ";")
            // Of course, "all" means this property should be in each object
            if ((thisCSVrecord.propertyObject.indexOf(propertyValues.propertyObject) != -1)
                 || (thisCSVrecord.propertyObject.indexOf("All") != -1 ) || (thisCSVrecord.propertyObject.indexOf("all") != -1))
                if (true == thisCSVrecord.propertyName.equals(propertyValues.propertyName))
                {
                    foundFlag = true;
                    thisCSVrecord.foundFlag = true;
                    // AVP 10/8/98:  Per Hajo, do not test internal properties.  These only matter for object space, and are not part
                    // of data model testing.
                    if (false == propertyValues.internalFlag)
                    {
                        verifyProperty(thisCSVrecord,propertyValues,testObject);
                    }
                    break;
                }
        } // end while enumerator

        return foundFlag;
   } // findProperty

   public boolean verifyProperty(CSVrecord fromCSV, CSVrecord fromObject, ABTObject testObject)
   {
        Enumeration
            ft = fieldTypeVector.elements(),
            eft = extendedFieldTypeVector.elements(),
            enumKeys = null;
        fieldType
            thisFieldType = null;
        boolean
            thisExtendedConstant = false;
        StringTokenizer
            enumTokenList = null;
        ABTValue
            enumKey = null;
        ABTInteger
            PropertyMinimum = null,
            PropertyMaximum = null;


//            if (propertyValues.propertyType = " " + thisProperty.getType();
            if (fromCSV.virtualFlag == fromObject.virtualFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", virtual Flag is " + fromObject.virtualFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, Virtual flag in spreadsheet = " + fromCSV.virtualFlag + "  - in object = " + fromObject.virtualFlag);
            if (fromCSV.visibleFlag == fromObject.visibleFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", visible Flag is " + fromObject.visibleFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, Visible Flag in spreadsheet = " + fromCSV.visibleFlag + " - in object = " + fromObject.visibleFlag);
            if (fromCSV.updateableFlag == fromObject.updateableFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", updateable Flag is " + fromObject.updateableFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, Updateable Flag in spreadsheet = " + fromCSV.updateableFlag + "- in object = " + fromObject.updateableFlag);
            // AVP 10/8/98:  Per Hajo, internal flag testing should not apply.  Only those properties internal to the object space use this flag, so should not be used for testing Project Model.
/*
            if (fromCSV.internalFlag == fromObject.internalFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", internal Flag is " + fromObject.internalFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, Internal Flag in CSV = " + fromCSV.internalFlag + "- in object = " + fromObject.internalFlag);
*/
            // 10/28/98 AVP:  Add logic to test Hidden attribute
            if (fromCSV.hiddenFlag == fromObject.hiddenFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", hidden Flag is " + fromObject.hiddenFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, hidden Flag in spreadsheet = " + fromCSV.hiddenFlag + "- in object = " + fromObject.hiddenFlag);
            if (fromCSV.transientFlag == fromObject.transientFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", transient Flag is " + fromObject.transientFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, Transient Flag in spreadsheet = " + fromCSV.transientFlag + "- in object = " + fromObject.transientFlag);
            if (fromCSV.editableFlag == fromObject.editableFlag)
                PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", editable Flag is " + fromObject.editableFlag);
            else
                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FLAG, Editable Flag in spreadsheet = " + fromCSV.editableFlag + "- in object = " + fromObject.editableFlag);
            /* 10/28/98 AVP:  ONLY test for the absence of field rules when spreadsheet has specified "yes" to Set or Get.  Do NOT test for
               presence of field rule when Get and Set are "no".
               There may be other reasons that field rules are invoked besides set or get,
               and these discrepancies are not currently of interest. */

            // If this property has a default field rule...

            if (fromObject.propertyRule instanceof ABTDefaultFieldRule)
            {
                if ((true == fromCSV.onGet) || (true == fromCSV.onSet))
                    PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FIELD RULE, Property has default field rule but spreadsheet has onGet = " + fromCSV.onGet + " and onSet = " + fromCSV.onSet);
                else
                    PropertyLog.LogWrite(PASS,"Property " + fromCSV.propertyName + " has default field rule, and no requirement for onSet or onGet");
            } /*  10/28/98 AVP: else
            {
                if ((false == fromCSV.onGet) && (false == fromCSV.onSet))
                    PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FIELD RULE, Property has non-default field rule but CSV has 'No' for onSet and 'No' for onGet");
                else
                    PropertyLog.LogWrite(PASS,"Property " + fromCSV.propertyName + " has non-default field rule, onSet = " + (fromCSV.onSet) + ", onGet = " + (fromCSV.onGet));
            }
            */
            // Verify enums from CSV and object - taking different formats into account
            if ((fromCSV.propertyEnumString != null) && (fromCSV.propertyEnumString != ","))
                if (fromCSV.propertyEnumString.length() > 0)
                {
                    fromCSV.propertyEnums = convertStringtoList(fromCSV.propertyEnumString,":;",false);
                    // if object enum doesn't exist, stop right here with failure.
                    if (null == fromObject.propertyEnums)
                    {
                        PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",ENUM,spreadsheet: " + fromCSV.propertyEnums + "- NOT in object");
                    } else if (fromObject.propertyEnums.isEmpty())
                    {
                        PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",ENUM,spreadsheet: " + fromCSV.propertyEnums + "- NOT in object");
                    } else {
                        // Get object's property enum
//                        ABTExtendedPropertyList fromObjectExtendedPropertyList = convertStringtoList(fromObject.propertyEnums.substring(1),"=,}",true);
                        // Enumerate CSV keys
                        enumKeys = fromCSV.propertyEnums.keys();
                        // Verify all keys from CSV
                        while (true == enumKeys.hasMoreElements())
                        {
                            enumKey = (ABTValue)enumKeys.nextElement();
                            // If CSV key is NOT in object's property enum, stop here with failure
                            if (false == fromObject.propertyEnums.containsKey(enumKey))
                            {
                                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",ENUM,spreadsheet: Key = " + enumKey + " - Description = " + fromCSV.propertyEnums.get(enumKey) + " - not in object");
                            } else {
                                // if key exists in both CSV and object, verify key description matches
                                if (false == fromCSV.propertyEnums.get(enumKey).toString().trim().equals(fromObject.propertyEnums.get(enumKey).toString().trim()))
                                    PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",ENUM,spreadsheet: Key = " + enumKey + " - Description = " + fromCSV.propertyEnums.get(enumKey) + " - object = " + fromObject.propertyEnums.get(enumKey));
                            }
                        } // end while CSV has more elements
                        // Verify keys from Object, that they only contain keys that match CSV
                        // (no extra enum entries in object)
                        enumKeys = fromObject.propertyEnums.keys();
                        while (true == enumKeys.hasMoreElements())
                        {
                            enumKey = (ABTValue)enumKeys.nextElement();
                            // If object key is NOT in CSV's enum, log failure
                            if (false == fromCSV.propertyEnums.containsKey(enumKey))
                            {
                                PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",ENUM,object: Key = " + enumKey + " - Description = " + fromObject.propertyEnums.get(enumKey) + " - not in spreadsheet");
                            }
                        } // end while object enum has more elements
                    } // end if both CSV and Object enums contain elements
                } // end if any enums specified for this property in CSV
            // Verify Field Type
            // Find match on Field Type description in Field Type Vector
            while (ft.hasMoreElements())
            {
                thisFieldType = (fieldType)ft.nextElement();
                // If match Field Type description
                if (fromCSV.propertyType.startsWith(thisFieldType.Description))
                {
                    // Constant should match for Field Type description
                    if (fromObject.propertyTypeInt == thisFieldType.Constant)
                        PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", field type description is " + fromCSV.propertyType + ", constant is " + fromObject.propertyTypeInt);
                    else
                        PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",FIELD TYPE,spreadsheet: " + fromCSV.propertyType + "- in object: " + fromObject.propertyTypeInt);
                }
            }
            // Verify Extended Field Type
            // Field Description also relates to extended field type
            while (eft.hasMoreElements())
            {
                thisFieldType = (fieldType)eft.nextElement();
                // If match Field Type description
                if ((fromCSV.propertyType.startsWith(thisFieldType.Description)) || (fromCSV.propertyType.endsWith(thisFieldType.Description)))
                {
                    switch (thisFieldType.Constant)
                    {
                        case PROP_EXTTYPE_MONEY:
                            thisExtendedConstant = fromObject.extMoneyFlag;
                            break;
                        case PROP_EXTTYPE_PERCENT:
                            thisExtendedConstant = fromObject.extPercentFlag;
                            break;
                        case PROP_EXTTYPE_PM:
                            thisExtendedConstant = fromObject.extPMFlag;
                            break;
                        case PROP_EXTTYPE_MEMO:
                            thisExtendedConstant = fromObject.extMemoFlag;
                            break;
                        case PROP_EXTTYPE_DATE:
                            thisExtendedConstant = fromObject.extDateFlag;
                            break;
                        case PROP_EXTTYPE_RESUNIT:
                            thisExtendedConstant = fromObject.extResUnitFlag;
                            break;
                        case PROP_EXTTYPE_RESAVAILUNIT:
                            thisExtendedConstant = fromObject.extResAvailFlag;
                            break;
                    }
                    // Constant should match for Field Type description
                    if (true == thisExtendedConstant)
                        PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", field type description is " + fromCSV.propertyType + ", has extended property key");
                    else
                        PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",EXTENDED FIELD TYPE,spreadsheet = " + fromCSV.propertyType + "- no extended property key in object");
                }
            }
            // verify Caption
            if ((fromCSV.propertyCaption != null) && (fromCSV.propertyCaption != "") && (fromCSV.propertyCaption != ","))
            {
                if (fromCSV.propertyCaption.equals(fromObject.propertyCaption))
                    PropertyLog.LogWrite(PASS,"for Property " + fromCSV.propertyName + ", Caption is " + fromObject.propertyCaption);
                else
                    PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",CAPTION,spreadsheet = " + fromCSV.propertyCaption + "- in object = " + fromObject.propertyCaption);
            }
            // verify Min/Max
            if (fromCSV.propertyMinmax.length() > 0)
            {
                String
                    PropertyMin = null;

                // Get past ">"
                PropertyMin = fromCSV.propertyMinmax.substring(fromCSV.propertyMinmax.indexOf(">") + 1);
                // If max specified ("0/100")
                if (PropertyMin.indexOf("/") != -1)
                {
                    PropertyMinimum = new ABTInteger(new ABTString(PropertyMin.substring(0,PropertyMin.indexOf("/") + 1)));
                    PropertyMaximum = new ABTInteger(new ABTString(PropertyMin.substring(PropertyMin.indexOf("/") + 1)));
                } else {
                    PropertyMinimum = new ABTInteger(new ABTString(PropertyMin));
                }
                // try to break min/max
                setValue(testObject,fromObject.propertyName,PropertyMinimum,true);
                setValue(testObject,fromObject.propertyName,new ABTInteger(PropertyMinimum.intValue() - 1),false);
                verifyValue(testObject,fromObject.propertyName,PropertyMinimum,"MIN",true);
                if (PropertyMaximum != null)
                {
                    setValue(testObject,fromObject.propertyName,new ABTInteger(PropertyMaximum),true);
                    setValue(testObject,fromObject.propertyName,new ABTInteger(PropertyMaximum.intValue() + 1),false);
                    verifyValue(testObject,fromObject.propertyName,PropertyMaximum,"MAX",true);
                }
            }
            // verify Text length
            if (fromCSV.propertyType.indexOf("Text") != -1)
            {
                StringBuffer
                    strTextLength = null;
                ABTValue
                    textValue = null;
                ABTInteger
                    propertyLength = null;

                // load 0' KLUGE - don't know how to handle strings and stringbuffers correctly in Java
                // Extract number from "Text - nn"
                propertyLength = ABTInteger.valueOf(fromCSV.propertyType.substring(fromCSV.propertyType.indexOf("-") + 1).trim());
                // if no number specified after "text - ", don't test (should never be "text - 0")
                if (propertyLength.intValue() > 0)
                {
                    // try to break text length
                    // KLUGE:  Don't know how to do this in Java - fill it up length + 1
                    strTextLength = new StringBuffer();
                    while (strTextLength.length() < propertyLength.intValue() + 1)
                        strTextLength.append("x");
                    // Try to set to string that violates length
                    setValue(testObject,fromObject.propertyName,new ABTString(strTextLength.toString()),true);
                    // Verify that real value is correct length
                    textValue = getValue(testObject,fromObject.propertyName,true);
                    if (textValue.toString().length() > propertyLength.intValue())
                        PropertyFailLog.LogDisplay(fromObject.propertyObject + "," + fromCSV.propertyName + ",TEXT LENGTH,spreadsheet = " + propertyLength + " - not enforced for property");
                }
            }

            return true;
   } // verifyProperty

   ABTExtendedPropertyList convertStringtoList(String theseEnums, String Delimiters, boolean KeyFirst)
   {
        ABTExtendedPropertyList
            thisPropertyList = new ABTExtendedPropertyList();
        StringTokenizer
            enumTokenList = new StringTokenizer(theseEnums,Delimiters);
        ABTValue
            NextText = null;
        String
            NextKey = null;
        Integer
            KeyInt = null;
        while (enumTokenList.hasMoreTokens())
        {
            if (true == KeyFirst)
            {
                NextKey = enumTokenList.nextToken();
                if (enumTokenList.hasMoreTokens())
                    NextText = new ABTString(enumTokenList.nextToken());
                else
                    NextText = null;
            } else {
                NextText = new ABTString(enumTokenList.nextToken());
                if (enumTokenList.hasMoreTokens())
                    NextKey = enumTokenList.nextToken();
                else
                    NextKey = null;
            }
            if ((NextKey != null) && (NextText != null))
            {
                KeyInt = new Integer(NextKey.trim());
                thisPropertyList.add(KeyInt.intValue(),NextText);
            }
        }

        return thisPropertyList;
   } // convertStringtoList

   // This method reads all records in the CSV Properties file,
   // and loads each record into a Vector
   public boolean ReadCSVFile(String CSVFileName) throws Exception
   {
      ReadFile
          propertyCSV = null;
      CSVrecord
          propertyRecord = null;
      CSVVector = new Vector(100,1);
      try
      {
          propertyCSV = new ReadFile(CSVFileName);
      } catch (Exception e)
      {
          CurrentLog.LogDisplay(FAIL,"Could not open properties spreadsheet file, exception: " + e);
          return false;
      }

      // while there are records in the CSV Properties File,
      // read and load into Vector
      while ((propertyRecord = readCSVRecord(propertyCSV)) != null)
        CSVVector.addElement(propertyRecord);

      return true;
   } // ReadCSVFile



   // This method will read one row from an excel spreadsheet that has been saved
   // as an ASCII-text CSV file (comma-delimited), and loads string values into
   // object CSVRecord
   // AVP - 9/24/98 - KLUGE: Currently read hardcoded number of comma delimiters
   public CSVrecord readCSVRecord (ReadFile CSVFile) throws Exception
   {
        String
            readValue = null;
        CSVrecord
            CSVRecordObject = new CSVrecord();
        String
            propertyRead = null;

        // Read past first comma in CSV line
/*
        if (null == CSVFile.ReadFileToString(","))
            return false;
*/

        // Read each string value into object CSVRecordObject
        propertyRead = CSVFile.ReadFileToString(",");
        // 09/25/98 - AVP - strip out "pm" prefix
        // 12/08/98 - AVP - never mind, I strip it out in the spreadsheet
//        CSVRecordObject.propertyName = propertyRead.substring(propertyRead.indexOf("pm")+2);
        CSVRecordObject.propertyName = propertyRead.trim();
        if (null == CSVRecordObject.propertyName)
            return null;
        CSVRecordObject.propertyType = CSVFile.ReadFileToString(",");
        CSVRecordObject.propertyObject = CSVFile.ReadFileToString(",") + ";";
        CSVRecordObject.virtualFlag = readBooleanValue(CSVFile);
        CSVRecordObject.visibleFlag = readBooleanValue(CSVFile);
        CSVRecordObject.updateableFlag = readBooleanValue(CSVFile);
        CSVRecordObject.hiddenFlag = readBooleanValue(CSVFile);
        // 10/28/98 AVP:  Internal no longer included in spreadsheet
//        CSVRecordObject.internalFlag = readBooleanValue(CSVFile);
        CSVRecordObject.editableFlag = readBooleanValue(CSVFile);
        CSVRecordObject.transientFlag = readBooleanValue(CSVFile);
        CSVRecordObject.onGet = readBooleanValue(CSVFile);
        CSVRecordObject.onSet = readBooleanValue(CSVFile);
        CSVRecordObject.fieldRule = (CSVRecordObject.onGet) || (CSVRecordObject.onSet);
        CSVRecordObject.propertyCaption = CSVFile.ReadFileToString(",");
        CSVRecordObject.propertyDefault = CSVFile.ReadFileToString(",");
        CSVRecordObject.propertyMinmax = CSVFile.ReadFileToString(",");
        // Load enum string info into Extended Property List, for comparison to object
//        CSVRecordObject.propertyEnums = new ABTExtendedPropertyList();
        CSVRecordObject.propertyEnumString = CSVFile.ReadFileToString(",");

        return CSVRecordObject;

   } // readCSVRecord

   // This method reads 1 comma-delimited string from the CSV file,
  // and tests for the word "Yes" or "yes" - assuming true if "yes", false otherwise
   public boolean readBooleanValue(ReadFile CSVFile) throws Exception
   {
        String
            ReadString = null;
        boolean
            ReadFlag = false;

        ReadString = CSVFile.ReadFileToString(",");
        ReadFlag = ((ReadString.indexOf("Yes") != -1) || (ReadString.indexOf("yes") != -1));
        return (ReadFlag);
   }



/*
      addProperty( OFD_MODIFIED, OFD_MODIFIED_CAP, PROP_BOOLEAN, false, true, true, false, null, null, new ABTBoolean( false ) );
      addProperty( OFD_CREATEDBY, OFD_CREATEDBY_CAP, PROP_STRING, false, true, true, false, null, null, null );
      addProperty( OFD_CREATEDTIME, OFD_CREATEDTIME_CAP, PROP_STRING, false, true, true, false, null, null, null );
      addProperty( OFD_UPDATEDBY, OFD_UPDATEDBY_CAP, PROP_STRING, false, true, true, false, null, null, null );
      addProperty( OFD_UPDATEDTIME, OFD_UPDATEDTIME_CAP, PROP_STRING, false, true, true, false, null, null, null );
      addProperty( OFD_DELETEDBY, OFD_DELETEDBY_CAP, PROP_STRING, false, true, true, false, null, null, null );
      addProperty( OFD_DELETEDTIME, OFD_DELETEDTIME_CAP, PROP_STRING, false, true, true, false, null, null, null );
      addProperty( OFD_ID_FIELD, OFD_ID_FIELD_CAP, PROP_STRING, false, true, true, false, null, null, new ABTString( OFD_NAME ) );

      // VERIFY setDefaultProperties
      addProperty( OFD_BASEMAX, OFD_BASEMAX_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      addProperty( OFD_BASEPATTERN, OFD_BASEPATTERN_CAP, PROP_SHORT, false, true, true, false, null, null, null );
      addProperty( OFD_CALENDAR, OFD_CALENDAR_CAP, PROP_BLOB, true, true, true, false, null, FR_ASSIGNMENT_CALENDAR, null );
      addProperty( OFD_EACCURVE, OFD_EACCURVE_CAP, PROP_DOUBLE, true, true, true, false, null, FR_EACCURVE, null );
      addProperty( OFD_ESTMAX, OFD_ESTMAX_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      addProperty( OFD_ID, OFD_ID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_ISUNPLANNED, OFD_ISUNPLANNED_CAP, PROP_BOOLEAN, false, true, true, false, null, null, null );
      addProperty( OFD_WDM, OFD_WDM_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      addProperty( OFD_PENDSTATUS, OFD_PENDSTATUS_CAP, PROP_SHORT, false, true, true, false, null, null, null );
      addProperty( OFD_RESOURCEID, OFD_RESOURCEID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_STATUS, OFD_STATUS_CAP, PROP_SHORT, false, true, true, false, null, null, null );
      addProperty( OFD_TASKID, OFD_TASKID_CAP, PROP_LONG, false, true, true, false, null, null, null );
      addProperty( OFD_VARIANCECURVE, OFD_VARIANCECURVE_CAP, PROP_DOUBLE, true, true, true, false, null, FR_VARIANCECURVE, null );

      //
      // Custom Properties
      //
      addProperty( OFD_ASSIGN_EAC, OFD_ASSIGN_EAC_CAP, PROP_STRING, true, true, true, false, null, FR_ASSIGN_EAC, null );

      //
      // Properties with enumerated values.
      // The use of the back() method, below, demands that these properties be the last property added before the
      // back() method is utilized.
      //
      addProperty( OFD_ESTPATTERN, OFD_ESTPATTERN_CAP, PROP_SHORT, false, true, true, false, null, null, null );

      //Uniform:0
      //Fixed:1
      //Contour:2
      //Front:3
      //Back:4
      ABTExtendedPropertyList enumeratedValues = null;

      ABTProperty prop = (ABTProperty)getProperties().back();
      enumeratedValues = new ABTExtendedPropertyList();
      enumeratedValues.add( 0, new ABTString( "Uniform" ) );
      enumeratedValues.add( 1, new ABTString( "Fixed" ) );
      enumeratedValues.add( 2, new ABTString( "Contour" ) );
      enumeratedValues.add( 3, new ABTString( "Front" ) );
      enumeratedValues.add( 4, new ABTString( "Back" ) );
      prop.setPropertyKey( PROP_KPOSSIBLEVALUES, enumeratedValues );

      //
      // Properties with extended types
      //
      addProperty( OFD_ACTCURVE, OFD_ACTCURVE_CAP, PROP_BLOB, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_ACTSUM, OFD_ACTSUM_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_ACTTHRU, OFD_ACTTHRU_CAP, PROP_TIMESTAMP, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_DATE, new ABTBoolean(true));
      prop.setPropertyKey(PROP_EXTTYPE_PM,   new ABTBoolean(true));

      addProperty( OFD_BASECURVE, OFD_BASECURVE_CAP, PROP_BLOB, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_BASESUM, OFD_BASESUM_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_DOCUMENT, OFD_DOCUMENT_CAP, PROP_STRING, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_KMAXLEN, new ABTInteger(254));

      addProperty( OFD_ESTCURVE, OFD_ESTCURVE_CAP, PROP_BLOB, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_ESTSUM, OFD_ESTSUM_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_FINISH, OFD_FINISH_CAP, PROP_TIMESTAMP, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_DATE, new ABTBoolean(true));
      prop.setPropertyKey(PROP_EXTTYPE_PM,   new ABTBoolean(true));

      addProperty( OFD_MODTIME, OFD_MODTIME_CAP, PROP_TIMESTAMP, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_DATE, new ABTBoolean(true));

      addProperty( OFD_PENDACTSUM, OFD_PENDACTSUM_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_PENDESTSUM, OFD_PENDESTSUM_CAP, PROP_DOUBLE, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_RESUNIT, new ABTBoolean(true));

      addProperty( OFD_PENDFINISH, OFD_PENDFINISH_CAP, PROP_TIMESTAMP, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_DATE, new ABTBoolean(true));
      prop.setPropertyKey(PROP_EXTTYPE_PM,   new ABTBoolean(true));

      addProperty( OFD_PENDSTART, OFD_PENDSTART_CAP, PROP_TIMESTAMP, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_DATE, new ABTBoolean(true));

      addProperty( OFD_START, OFD_START_CAP, PROP_TIMESTAMP, false, true, true, false, null, null, null );
      prop = (ABTProperty)getProperties().back();
      prop.setPropertyKey(PROP_EXTTYPE_DATE, new ABTBoolean(true));

   }
*/
   public void noteIntegrity (ABTObjectSet NoteSet, boolean ShouldPass) // throws TestRuleException
   {
        ABTObject
            NoteObject = null;

        CurrentLog.LogWrite(COMMENT,"Verifying Notes");
        // If null or empty objectset, don't test it further
        if (NoteSet != null)
        {
            Enumeration e = NoteSet.elements( session_ );
            while( e.hasMoreElements() )
            {
                ABTObject note = (ABTObject)e.nextElement();
                // If null or empty object, don't test it further
                if (note != null)
                {
                    ABTValue v = note.getValue( session_, OFD_ID, null );
                    if (v != null)
                        if (true == checkError (v, ShouldPass))
                            return;
                }
            }
/*
            if (false  == NoteSet.isEmpty(session_))
            {
                for (int NotePtr = 0; NotePtr < NoteSet.size(session_); NotePtr++)
                {
                    NoteObject = (ABTObject)NoteSet.at(session_,NotePtr);
                    if (NoteObject != null)
                    {
                        CurrentLog.LogDisplay(COMMENT,getValue(NoteObject, OFD_ID));
                    } else
                    {
                        CurrentLog.LogDisplay(COMMENT,"NoteObject #" + (NotePtr+1) + " = null");
                    }
                } // NotePtr
            } else
            {
                CurrentLog.LogDisplay(COMMENT,"NoteSet empty");
            }
*/
        } else
        {
            CurrentLog.LogDisplay(COMMENT,"NoteSet null");
        } // if NoteSet = null

   } // noteIntegrity

   public void resourceIntegrity( ABTObject resource, ABTObject task, ABTObject callingObject, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         assignment;
      int               i, size;
      ABTValue          name;
      String            ResourceName = null;

      name = getValue( resource, OFD_NAME, ShouldPass );
      ResourceName = name.stringValue();
      CurrentLog.LogWrite(COMMENT,"Verify Resource Integrity: " + ((ResourceName != null) ? ResourceName : " "));

      os = getObjectSet( resource, OFD_ASSIGNMENTS, ShouldPass );
      size = os.size( session_ );
      for( i = 0; i < size; i++ )
      {
         assignment = (ABTObject)os.at( session_, i );
         // avoid recursive functions or testing null object
         if ((!compareObjects(assignment, callingObject))&& (assignment != null))
            assignmentIntegrity(assignment, task, resource, -1, ShouldPass);
      }
   }

   public void teamResources( ABTObject project, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObjectSet      os;
      ABTObject         team;
      int               i, size;

      CurrentLog.LogWrite(COMMENT, "Verify Team resources" );

      os = getObjectSet( project, OFD_TEAMRESOURCES, ShouldPass );
      size = os.size( session_ );
      for( i = 0; i < size; i++ )
      {
         team = (ABTObject)os.at( session_, i );
         // don't test null object
         if (team != null)
         {
             ABTObject resource = getObject( team, OFD_RESOURCE, ShouldPass );
             // don't test null object
             if (resource != null)
                 resourceIntegrity( resource, team, null, ShouldPass );
         }
      }
   }

   public Vector storeNotes(ABTObjectSet noteObjectSet)
   {
      Enumeration noteenum = noteObjectSet.elements(session_);
      // First, store assignment's notes in separate vector
      Vector noteVector = new Vector(10,1);
      while (noteenum.hasMoreElements())
      {
          noteVector.addElement(noteenum.nextElement());
      }

      return noteVector;
   }

   public boolean verifyNoteClear(ABTObjectSet noteObjectSet, Vector noteVector)
   {
      boolean
        isDeleted = true;

      if (noteObjectSet.isEmpty(session_))
      {
          CurrentLog.LogWrite(PASS,"Note object set cleared");
      } else {
          CurrentLog.LogDisplay(FAIL,"Note object set NOT cleared, size = " + noteObjectSet.size(session_));
      }
      Enumeration noteenum = noteVector.elements();
      while (noteenum.hasMoreElements())
      {
          if (((ABTObject)noteenum.nextElement()).isDeleted(session_))
          {
              CurrentLog.LogWrite(PASS,"Assignment Note deleted when object set cleared");
          } else {
              CurrentLog.LogDisplay(FAIL,"Assignment Note NOT deleted when object set cleared");
              isDeleted = false;
          }
      }

      return isDeleted;
   }

   public boolean compareObjects(Object Object1, Object Object2)
   {
       if ((Object1 == null) || (Object2 == null))
           return false;
       return (Object1.equals(Object2));
   } // compareObjects

   public static void main( String args[] )
   {

      TestRules app = new TestRules( args );
      app.run();



   }

}

// Object for 1 data row (1 record) from CSV file
class CSVrecord extends Object
{
    String
        propertyName = null,
        propertyType = null,
        propertyObject = null,
        propertyCaption = null,
        propertyDefault = null,
        propertyMinmax = null,
        propertyEnumString = null;
    ABTFieldRule
        propertyRule = null;
    ABTExtendedPropertyList        
        propertyEnums = null;
    int
        propertyTypeInt = 0;
    boolean
        virtualFlag = false,
        visibleFlag = false,
        updateableFlag = false,
        hiddenFlag = false,
        internalFlag = false,
        editableFlag = false,
        transientFlag = false,
        onGet = false,
        onSet = false,
        fieldRule = false,
        foundFlag = false,
        extMoneyFlag = false,
        extPercentFlag = false,
        extPMFlag = false,
        extMemoFlag = false,
        extDateFlag = false,
        extResUnitFlag = false,
        extResAvailFlag = false;

    CSVrecord()
    {
            propertyName = null;
            propertyType = null;
            propertyObject = null;
            propertyCaption = null;
            propertyDefault = null;
            propertyMinmax = null;
            propertyEnumString = null;
            propertyRule = null;
            propertyTypeInt = 0;
            virtualFlag = false;
            visibleFlag = false;
            updateableFlag = false;
            hiddenFlag = false;
            internalFlag = false;
            editableFlag = false;
            transientFlag = false;
            onGet = false;
            onSet = false;
            fieldRule = false;
            propertyEnums = null;
            foundFlag = false;
            extMoneyFlag = false;
            extPercentFlag = false;
            extPMFlag = false;
            extMemoFlag = false;
            extDateFlag = false;
            extResUnitFlag = false;
            extResAvailFlag = false;
    }
} // CSVrecord

// Object to relate Field Type descriptions (from CSV file) to Field Type constants
class fieldType extends Object
{
    String
        Description = null;
    int
        Constant = 0;

    fieldType()
    {
        Description = null;
        Constant = 0;
    }

    fieldType(String thisDescription, int thisConstant)
    {
        Description = thisDescription;
        Constant = thisConstant;
    }

} // fieldType
