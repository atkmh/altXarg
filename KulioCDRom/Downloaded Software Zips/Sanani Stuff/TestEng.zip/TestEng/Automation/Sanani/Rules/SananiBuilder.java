import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.objectModel.pm.*;
import com.abtcorp.io.PMWRepo.*;
import com.abtcorp.io.siterepo.*;
import java.util.Vector;
import java.text.MessageFormat;
import Sanani.Lib.*;
import TestLib.*;

/* AVP 10/29/98:  This code was originally used by Scott Ellis to test business rules.
I have kluged it to test data models (Project Model, Global Model, Methodology Model),
Task Movement, and other object-level business rules.
Methods added to SananiBuilder:
        add
        remove
        clear
        methods to create any missing objects
        verifyvalue
Error handling has been significantly changed:
Formerly threw exceptions when error encountered
Now logs PASS/FAIL based on result expectation (parameter shouldPass).
Other changes were made as noted.
*/
// AVP 12/08/98 - Team objects methods added
public class SananiBuilder implements com.abtcorp.idl.IABTPMRuleConstants,
                                      com.abtcorp.idl.IABTMMRuleConstants,
                                      com.abtcorp.idl.IABTDriverConstants,
                                      com.abtcorp.idl.IABTPropertyType,
                                      com.abtcorp.objectModel.team.IABTTWRuleConstants,
                                      ILogType
{
   protected String              repositoryName_ = "ABTRepository";
   protected String              projectExternalID_;
   protected ABTObjectSpace      space_;
   protected ABTUserSession      session_;
//   protected ABTPMWRepoDriver   driver_;
//   protected ABTIOSiteRepoDriver driver_;
   protected String              driver_;
   LogFile CurrentLog = null;
   LogFile PropertyLog = null;
   // Special request from Zane:  Use CSV format to log failures, so must be separate from automatic "fail" log file
   LogFile PropertyFailLog = null;
   Vector CSVVector = null;
   Vector fieldTypeVector = null;
   Vector extendedFieldTypeVector = null;

   public SananiBuilder()
   {
   }

   private void createDriver() // throws TestRuleException
   {
//      driver_ = new ABTPMWRepoDriver();
//      driver_.setSpace( space_ );
//      driver_.setUser( "admin" );
//      driver_.setUserSession( session_ );
//      if( !driver_.open() )
//         throw new TestRuleException( new ABTError( "TestRules",
//            "TestRules->createDriver", "Error", "Driver failed to open!" ) );

//      driver_ = new ABTIOSiteRepoDriver();
//      ABTHashtable hash = new ABTHashtable();
//      hash.put( KEY_REPONAME, repositoryName_ );
//      hash.put( KEY_PRODUCT, "Project Workbench" );
//      ABTValue v = driver_.open( space_, session_, hash );
//      if( ABTError.isError( v ) )
//         throw new TestRuleException( new ABTError( "TestRules",
//            "TestRules->createDriver", "Error", "Driver failed to open!" ) );
//      hash.put( KEY_TYPE, TYPE_SITE );
//      v = driver_.populate( space_, session_, hash );
//      if( ABTError.isError( v ) )
//         throw new TestRuleException( new ABTError( "TestRules",
//            "TestRules->createDriver", "Error", "Populate failed" ) );
   }

   // 10/23/98 AVP:  Now checks for MIN/MAX property keys
   // 10/30/98 AVP:  Now checks for text length property key
   public void setValue( ABTObject object, String propname, ABTValue value, boolean ShouldPass ) // throws TestRuleException
   {

      ABTProperty prop = object.getProperty(session_,propname);
      ABTValue minValue = prop.getPropertyKey(PROP_KMIN);
      ABTValue maxValue = prop.getPropertyKey(PROP_KMAX);
      ABTValue textLength = prop.getPropertyKey(PROP_KMAXLEN);
      // AVP 10/29/98 Enforce min, max and text length - emulate app developers
      if ((minValue != null) && (false == ABTError.isError(minValue)))
      {
          if (value.compareTo(minValue) == -1)
              value = minValue;
      }
      if ((maxValue != null) && (false == ABTError.isError(maxValue)))
      {
          if (value.compareTo(maxValue) == 1)
              value = maxValue;
      }
      if ((textLength != null) && (false == ABTError.isError(textLength)))
      {
          if (textLength.intValue() < value.toString().length())
          {
             StringBuffer valueBuffer = new StringBuffer(value.toString());
             valueBuffer.setLength(textLength.intValue());
             value = new ABTString(valueBuffer.toString());
          }
      }
      ABTValue err = object.setValue( session_, propname, value, null );
      checkError( err, ShouldPass );
/*  10/29/98 AVP:  My mistake! min/max NOT enforced by Sanani
      if ((minValue != null) && (false == ABTError.isError(minValue)))
      {
          if (value.intValue() < minValue.intValue())
          {
              if (true == ShouldPass)
                  CurrentLog.LogDisplay(FAIL,"setValue for " + propname + " to " + value + "was below minValue of " + minValue);
              else
                  CurrentLog.LogWrite(PASS,"setValue for " + propname + " to " + value + "was below minValue of " + minValue);
          }
      }
      if ((maxValue != null) && (false == ABTError.isError(maxValue)))
      {
          if (value.intValue() > maxValue.intValue())
          {
              if (true == ShouldPass)
                  CurrentLog.LogDisplay(FAIL,"setValue for " + propname + " to " + value + "was above maxValue of " + maxValue);
              else
                  CurrentLog.LogWrite(PASS,"setValue for " + propname + " to " + value + "was above maxValue of " + maxValue);
          }
      }
*/
   } // setValue

   public void setValue( ABTObject object, String propname, ABTValue value, boolean moveBranch, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = null;

      if (true == moveBranch)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByKey( new ABTInteger(kMOVEBRANCH), new ABTBoolean(true) );
      }
      ABTValue err = object.setValue( session_, propname, value, hash );
   }

   public ABTValue getValue( ABTObject object, String propname, ABTTime startTime, ABTTime finishTime, int unitOfMeasure, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = null;

      if ((startTime != null) && (finishTime != null))
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( kFROM_DATE, startTime );
          hash.putItemByString( kTO_DATE, finishTime );
      }
      if (unitOfMeasure != -1)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_UNIT, new ABTShort((short) unitOfMeasure));
      }
      ABTValue err = object.getValue( session_, propname, hash );
      checkError( err, ShouldPass);
      return err;
   }

   public ABTValue getValue( ABTObject object, String propname, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTValue err = object.getValue( session_, propname, null );
      checkError( err, ShouldPass);
      return err;
   }

   public ABTValue getValue( ABTObject object, int propnum, boolean shouldPass  ) // throws TestRuleException
   {
      ABTValue err = object.getValue( session_, propnum, null );
      checkError( err, shouldPass);
      return err;
   }

   // first overriden method:
   // this method gets a property value, and records in a CSV results file,
   // if shouldLog = true
   public ABTValue verifyValue( ABTObject object, String propname, boolean shouldLog ) // throws TestRuleException
   {
         ABTValue thisValue = getValue(object,propname,true);
         if (thisValue != null)
            if (false == thisValue.isEmpty(session_))
            {
                 String thisString = thisValue.stringValue();
/*                 Object[] arguments = {
                     new Double(thisValue.doubleValue())
                 };
                 String thisString = MessageFormat.format(" {0} ",arguments);
*/
                if (true == shouldLog)
                    PropertyFailLog.LogDisplay(object.getObjectType() + "," + propname + ",Value = " + thisString);
            } else {
                if (true == shouldLog)
                    PropertyFailLog.LogDisplay(object.getObjectType() + "," + propname + ",Value = null or empty");
            }

         return thisValue;
   } // verifyValue(1)

   // second overriden method:
   // this method actually verifies the value as well, via parameter valueString
   // and records in the special CSV results file (thus the need for parameter testName), any failures
   public ABTValue verifyValue( ABTObject object, String propname, ABTValue propValue, String testName, boolean shouldPass  ) // throws TestRuleException
   {
         // call first verifyvalue method without logging
         ABTValue thisValue = verifyValue(object,propname,false);
         // verify against valueString
         if (propValue != null)
         {
            if (null == thisValue)
            {
                if (true == shouldPass)
                     PropertyFailLog.LogDisplay(object.getObjectType() + "," + propname + "," + testName + ",Value should be = " + propValue + " - but is null");
                else
                     CurrentLog.LogWrite(PASS,object.getObjectType() + "," + propname + "," + testName + ",Value is null");
            } else if (propValue.equals(thisValue))
            {
                if (false == shouldPass)
                     PropertyFailLog.LogDisplay(object.getObjectType() + "," + propname + "," + testName + ",Value = " + propValue + "- but should be different");
                else
                     CurrentLog.LogWrite(PASS,object.getObjectType() + "," + propname + "," + testName + ",Value  = " + propValue);
            } else { // if not null, and not equal
                if (true == shouldPass)
                    if (null == propValue)
                         PropertyFailLog.LogDisplay(object.getObjectType() + "," + propname + "," + testName + ",Value should be = null -  but actual value = " + thisValue);
                    else
                         PropertyFailLog.LogDisplay(object.getObjectType() + "," + propname + "," + testName + ",Value should be = " + propValue + " -  but actual value = " + thisValue);
                else
                     CurrentLog.LogWrite(PASS,object.getObjectType() + "," + propname + "," + testName + ",Value  = " + propValue);
            }
         }

         return thisValue;
   } // verifyValue(2)

   // Third overridden method
   // this method verifies the value, via parameter valueString
   // and records results in a regular log file (not CSV)
   public ABTValue verifyValue( ABTObject object, String propname, ABTValue propValue, boolean shouldPass  ) // throws TestRuleException
   {
         // call first verifyvalue method without logging
         ABTValue thisValue = verifyValue(object,propname,false);
         // verify against valueString
         if (propValue != null)
         {
            if (null == thisValue)
            {
                if (true == shouldPass)
                     CurrentLog.LogDisplay(FAIL,object.getObjectType() + " - " + propname + ",Value is null");
                else
                     CurrentLog.LogWrite(PASS,object.getObjectType() + " - " + propname + ",Value is null");
            } else if (propValue.equals(thisValue))
            {
                if (false == shouldPass)
                     CurrentLog.LogDisplay(FAIL,object.getObjectType() + " - " + propname + ",Value  = " + propValue);
                else
                     CurrentLog.LogWrite(PASS,object.getObjectType() + " - " + propname + ",Value  = " + propValue);
            } else { // if not null, and not equal
                if (true == shouldPass)
                    if (null == propValue)
                         CurrentLog.LogDisplay(FAIL,object.getObjectType() + " - " + propname + ", Value should = null, but actually = " + thisValue);
                    else
                         CurrentLog.LogDisplay(FAIL,object.getObjectType() + " - " + propname + ",Value should = " + propValue + ", but actually = " + thisValue);
                else
                     CurrentLog.LogWrite(PASS,object.getObjectType() + " - " + propname + ",Value  = " + propValue);
            }
         }

         return thisValue;
   } // verifyValue(3)

   public void addListMember( ABTObjectSet set, ABTObject object, boolean ShouldPass ) // throws TestRuleException
   {
//      ABTValue err = set.add( session_, object );
      CurrentLog.LogWrite(COMMENT,"in addListMember");
      ABTValue err = set.addToSet( session_, object, false );
      checkError(err,ShouldPass);
   }

   public ABTObject add( ABTObjectSet set, ABTObject object, boolean shouldPass ) // throws TestRuleException
   {
      CurrentLog.LogWrite(COMMENT,"in add");
      ABTValue err = set.add( session_, object );
      if (true == checkError( err, shouldPass ))
      {
        return null;
      }
      return (ABTObject)err;
   }

   public ABTObject addNew( ABTObjectSet set, boolean ShouldPass ) // throws TestRuleException
   {
      CurrentLog.LogWrite(COMMENT,"in addNew");
//      ABTValue err = set.addToSet( session_, null, false );
      ABTValue err = set.addNew(session_);
      // AVP - 9/9/98 - if ABTError returned, do NOT cast to ABTObject
      if (true == checkError( err, ShouldPass ))
      {
        return null;
      }
      return (ABTObject)err;
   }

   public void remove( ABTObjectSet set, ABTObject object, boolean ShouldPass ) // throws TestRuleException
   {
      CurrentLog.LogWrite(COMMENT,"in remove");
//      ABTValue err = set.removeFromSet( session_, object, 0 );
      ABTValue err = set.remove(session_, object);
      checkError( err, ShouldPass );
   }

   public void removeListMember( ABTObjectSet set, ABTObject object, boolean ShouldPass ) // throws TestRuleException
   {
      CurrentLog.LogWrite(COMMENT,"in removeListMember");
      ABTValue err = set.removeFromSet( session_, object, 0 );
//      ABTValue err = set.remove(session_, object);
      checkError( err, ShouldPass );
   }

   public void clear( ABTObjectSet set, boolean ShouldPass ) // throws TestRuleException
   {
      CurrentLog.LogWrite(COMMENT,"in clear");
//      ABTValue err = set.removeFromSet( session_, object, 0 );
      ABTValue err = set.clear(session_);
      checkError( err, ShouldPass );
   }

   public void clearListMember( ABTObjectSet set, boolean ShouldPass ) // throws TestRuleException
   {
      CurrentLog.LogWrite(COMMENT,"in clearListMember");
      ABTValue err = set.clearSet( session_);
//      ABTValue err = set.remove(session_, object);
      checkError( err, ShouldPass );
   }

   // AVP - 9/9/98 - now returns true if error, false
   // (no longer catch/throw error exception)
   public boolean checkError( ABTValue value, boolean ShouldPass ) // throws TestRuleException
   {
      if (value == null)
      {
//         CurrentLog.LogWrite(COMMENT, "in checkerror, null value returned, shouldpass = " + ShouldPass);
         return true;
      }
      if (ABTEmpty.isEmpty(value))
      {
         CurrentLog.LogDisplay(FAIL, "in checkerror, empty value returned, shouldpass = " + ShouldPass);
         return true;
      }
      if( ABTError.isError( value ) )
      {
         if (true == ShouldPass)
         {
             CurrentLog.LogDisplay(FAIL, "Error encountered");
             CurrentLog.LogDisplay(FAIL, "Method = " + ((ABTError)value).getMethod() );
             CurrentLog.LogDisplay(FAIL, "Component = " + ((ABTError)value).getComponent() );
             CurrentLog.LogDisplay(FAIL, "Message = " + ((ABTError)value).getMessage() );
             CurrentLog.LogDisplay(FAIL, "Info = " + ((ABTError)value).getInfo());
         } else
         {
//             CurrentLog.LogWrite(PASS, "Error encountered");
//             CurrentLog.LogWrite(PASS, "Method = " + ((ABTError)value).getMethod() );
//             CurrentLog.LogWrite(PASS, "Message = " + ((ABTError)value).getMessage() );
//             CurrentLog.LogWrite(PASS, "Info = " + ((ABTError)value).getInfo() );
         }
         return true;
      } else
      {
         if (false == ShouldPass)
         {
             CurrentLog.LogDisplay(FAIL, "No Error encountered - should have been rejected");
         } else
         {
//             CurrentLog.LogWrite(PASS, "No Error encountered");
         }
      }


//         throw new TestRuleException( (ABTError)value );
        return false;
   }

   public void createObjectSpace() // throws TestRuleException
   {
      space_ = new ABTObjectSpace();
      session_ = space_.startSession( null );

//      createDriver();
   }

   public ABTObject createObject( String type, ABTHashtable h, int RemoteIDInteger, boolean ShouldPass ) // throws TestRuleException
   {
      ABTRemoteIDInteger
        SetRemoteID = null;

      if (RemoteIDInteger != -1)
        SetRemoteID = new ABTRemoteIDInteger(RemoteIDInteger);
      ABTValue v = space_.createObject( session_, type, SetRemoteID, h );

      // AVP - 9/9/98 - if ABTError returned, do NOT cast to ABTObject
      if (true == checkError( v, ShouldPass ))
      {
        return null;
      }
      return (ABTObject)v;
   }

   public ABTObjectSet createObjectSet( String type, boolean ShouldPass)
   {
      ABTValue v = space_.createObjectSet( session_, type);

      // AVP - 9/9/98 - if ABTError returned, do NOT cast to ABTObject
      if (true == checkError( v, ShouldPass ))
      {
        return null;
      }
      return (ABTObjectSet)v;
   }

   public ABTObject createAssignment( ABTObject task, ABTObject resource, int id, boolean ShouldPass ) // throws TestRuleException
   {
//      ABTHashtable hash = new ABTHashtable();
      ABTHashtable hash = null;

      if (task != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_TASK, task );
      }
      if (resource != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_RESOURCE, resource );
      }

      ABTObject assignment = createObject( OBJ_ASSIGNMENT, hash, id, ShouldPass );

      return assignment;
   }

   public ABTObject createConstraint( ABTObject task, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (task != null)
          hash.putItemByString( OFD_TASK, task );

      ABTObject constraint = createObject( OBJ_CONSTRAINT, hash, id, ShouldPass );
//      setValue( constraint, OFD_ID, new ABTInteger( id ), ShouldPass );

      return constraint;
   }

   public ABTObject createCustFieldValue( ABTObject testObject, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (testObject != null)
          hash.putItemByString( testObject.getObjectType(), testObject );

      ABTObject custfieldvalue = createObject( OBJ_CUSTFIELDVALUE, hash, id, ShouldPass  );
//      setValue( custfieldvalue, OFD_ID, new ABTInteger( id ), ShouldPass );

      return custfieldvalue;
   }

   public ABTObject createDeliverable( ABTObject project, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (project != null)
          hash.putItemByString( OFD_PROJECT, project );

      ABTObject deliverable = createObject( OBJ_DELIVERABLE, hash, id, ShouldPass  );
//      setValue( deliverable, OFD_ID, new ABTInteger( id ), ShouldPass );

      return deliverable;
   }

   public ABTObject createDependency( ABTObject prevtask, ABTObject succtask, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (prevtask != null)
          hash.putItemByString( OFD_PREDTASK, prevtask );
      if (succtask != null)
          hash.putItemByString( OFD_SUCCTASK, succtask );

      ABTObject dependency = createObject( OBJ_DEPENDENCY, hash, id, ShouldPass  );
//      setValue( dependency, OFD_ID, new ABTInteger( id ), ShouldPass );

      return dependency;
   }

   // 10/29/98 AVP:  for Project Model
   public ABTObject createEstmodel( ABTObject project, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (project != null)
          hash.putItemByString( OFD_PROJECT, project );

      ABTObject estmodel = createObject( OBJ_ESTIMATINGMODEL, hash, id, ShouldPass  );

      return estmodel;
   }

   public ABTObject createProject (int id, boolean ShouldPass  ) // throws TestRuleException
   {
    // Currently no parameters for creating project
      ABTHashtable hash = new ABTHashtable();

      ABTObject project = createObject( OBJ_PROJECT, hash, id, ShouldPass  );

      return project;
   }

   public ABTObject createSubprojectlink( ABTObject task, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (task != null)
          hash.putItemByString( OFD_TASK, task );

      ABTObject subprojectlink = createObject( OBJ_SUBPROJECTLINK, hash, id, ShouldPass  );

      return subprojectlink;
   } // createSubprojectlink

   // Global objects
   public ABTObject createSite( int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObject site = createObject( OBJ_SITE, null, id, ShouldPass  );
   //   setValue( resource, OFD_ID, new ABTInteger( id ), ShouldPass );

      return site;
   }

   public ABTObject createNote( int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTObject note = createObject( OBJ_NOTE, null, id, ShouldPass  );
//      setValue( note, OFD_ID, new ABTInteger( id ), ShouldPass );

      return note;
   }

   public ABTObject createResource( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject resource = createObject( OBJ_RESOURCE, hash, id, ShouldPass  );
   //   setValue( resource, OFD_ID, new ABTInteger( id ), ShouldPass );

      return resource;
   }

   public ABTObject createAdjRule( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject AdjRule = createObject( OBJ_ADJRULE, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return AdjRule;
   }

   public ABTObject createCustomField( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject CustomField = createObject( OBJ_CUSTOMFIELD, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return CustomField;
   }

   // 10/29/98 AVP:  for Global Estimating Model objects (from Global Model, instead of Project Model)
   public ABTObject createEstModelGlobal( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject EstModel = createObject( OBJ_ESTMODEL, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return EstModel;
   }

   public ABTObject createTimePeriod( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject TimePeriod = createObject( OBJ_TIMEPERIOD, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return TimePeriod;
   }

   public ABTObject createTypeCode( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject TypeCode = createObject( OBJ_TYPECODE, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return TypeCode;
   }

   public ABTObject createCalendar( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject Calendar = createObject( OBJ_CALENDAR, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return Calendar;
   }

   public ABTObject createAggregateField( ABTObject sourcefield, ABTObject targetfield, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (sourcefield != null)
          hash.putItemByString( OFD_SOURCEFIELD, sourcefield );
      if (targetfield != null)
          hash.putItemByString( OFD_TARGETFIELD, targetfield );
      ABTObject AggregateField = createObject( OBJ_AGGREGATEFIELD, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return AggregateField;
   }

   public ABTObject createChargeCode( ABTObject site, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (site != null)
          hash.putItemByString( OFD_SITE, site );
      ABTObject ChargeCode = createObject( OBJ_CHARGECODE, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return ChargeCode;
   }

   public ABTObject createCustomEnum( ABTObject customfield, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (customfield != null)
          hash.putItemByString( OFD_CUSTOMFIELD, customfield );
      ABTObject CustomEnum = createObject( OBJ_CUSTOMENUM, hash, id, ShouldPass  );
   //   setValue( adjRule, OFD_ID, new ABTInteger( id ), ShouldPass );

      return CustomEnum;
   }

   public ABTObject createTask( ABTObject project, Vector taskVector, ABTObject parentTask, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (project != null)
          hash.putItemByString( OFD_PROJECT, project );
      if( parentTask != null )
         hash.putItemByString( OFD_PARENTTASK, parentTask );

      ABTObject task = createObject( OBJ_TASK, hash, id, ShouldPass   );
      // Add to task vector
      if (taskVector != null)
      {
          taskVector.addElement(task);
      }

      setValue( task, OFD_ID, new ABTInteger( id ), ShouldPass  );

      return task;
   }

   public ABTObject createTaskestimate( ABTObject task, ABTObject estmodel, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (task != null)
          hash.putItemByString( OFD_TASK, task );
      if (estmodel != null)
          hash.putItemByString( OFD_ESTMODEL, estmodel );

      ABTObject taskestimate = createObject( OBJ_TASKESTIMATE, hash, id, ShouldPass  );
//      setValue( taskestimate, OFD_ID, new ABTInteger( id ), ShouldPass );

      return taskestimate;
   }

   public ABTObject createTeamResource( ABTObject project, ABTObject resource, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (project != null)
        hash.putItemByString( OFD_PROJECT, project );
      if (resource != null)
        hash.putItemByString( OFD_RESOURCE, resource );

      ABTObject team = createObject( OBJ_TEAM, hash, id, ShouldPass  );
//      setValue( team, OFD_ID, new ABTInteger( id ), ShouldPass );

      return team;
   }

   public ABTObjectSet findObject( String objectType, String criteria, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTValue v = space_.findObject( session_, objectType, criteria );
      // AVP - 9/9/98 - if ABTError returned, do NOT cast to ABTObject
      if (true == checkError( v, ShouldPass ))
      {
        return null;
      }
      return (ABTObjectSet)v;
   }

   public ABTObjectSet getObjectSet( ABTObject object, String objectSetName, boolean ShouldPass  )
      // throws TestRuleException
   {
      // AVP - 9/9/98 - if ABTObject already null, try no further
      if (object == null)
        return null;
      ABTValue err = object.getValue( session_, objectSetName, null);
      // AVP - 9/9/98 - if ABTError returned, do NOT cast to ABTObject
      if (true == checkError( err, ShouldPass ))
      {
        return null;
      }
      return (ABTObjectSet)err;
   }

   public ABTObject getObject( ABTObject object, String objectName, boolean ShouldPass )
      // throws TestRuleException
   {
      ABTValue err = object.getValue( session_, objectName, null );
      // AVP - 9/9/98 - if ABTError returned, do NOT cast to ABTObject
      if (true == checkError( err, ShouldPass ))
      {
        return null;
      }
      return (ABTObject)err;
   }

   public boolean deleteObject( ABTObject object, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTValue err = object.delete(session_);
      // Delete SHOULD return null
      if (err == null)
        return true;
      // Otherwise, check for error
      checkError( err, ShouldPass );
      return false;
   }

   // 10/29/98 AVP:  Added for all Methodology Model objects
   public ABTObject createMMAssignment( ABTObject task, ABTObject resource, int id, boolean ShouldPass ) // throws TestRuleException
   {
//      ABTHashtable hash = new ABTHashtable();
      ABTHashtable hash = null;

      if (task != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_TASK, task );
      }
      if (resource != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_RESOURCE, resource );
      }

      ABTObject assignment = createObject( OBJ_MM_ASSIGNMENT, hash, id, ShouldPass );

      return assignment;
   }

   public ABTObject createMMDeliverable( ABTObject method, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (method != null)
          hash.putItemByString( OFD_METHOD, method );

      ABTObject deliverable = createObject( OBJ_MM_DELIVERABLE, hash, id, ShouldPass  );
//      setValue( deliverable, OFD_ID, new ABTInteger( id ), ShouldPass );

      return deliverable;
   }

   public ABTObject createMMDependency( ABTObject prevtask, ABTObject succtask, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (prevtask != null)
          hash.putItemByString( OFD_PREDTASK, prevtask );
      if (succtask != null)
          hash.putItemByString( OFD_SUCCTASK, succtask );

      ABTObject dependency = createObject( OBJ_MM_DEPENDENCY, hash, id, ShouldPass  );
//      setValue( dependency, OFD_ID, new ABTInteger( id ), ShouldPass );

      return dependency;
   }

   public ABTObject createMethod (int id, boolean ShouldPass  ) // throws TestRuleException
   {
    // Currently no parameters for creating method
      ABTHashtable hash = new ABTHashtable();

      ABTObject method = createObject( OBJ_MM_METHOD, hash, id, ShouldPass  );

      return method;
   }

   public ABTObject createPackage( ABTObject method, ABTBoolean hidden, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (method != null)
          hash.putItemByString( OFD_METHOD, method );
      if( hidden != null )
         hash.putItemByString( OFD_HIDDEN, hidden );

      ABTObject Package = createObject( OBJ_MM_PACKAGE, hash, id, ShouldPass);

      return Package;
   }

   public ABTObject createPackageMember( ABTObject task, ABTObject Package, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if( task != null )
         hash.putItemByString( OFD_TASK, task );
      if (Package != null)
          hash.putItemByString( OFD_PACKAGE, Package );

      ABTObject packagemember = createObject( OBJ_MM_PACKAGEMEMBER, hash, id, ShouldPass);

      return packagemember;
   }

   public ABTObject createPage( ABTObject method, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (method != null)
          hash.putItemByString( OFD_METHOD, method );

      ABTObject page = createObject( OBJ_MM_PAGE, hash, id, ShouldPass);

      return page;
   }

   public ABTObject createPageMember( ABTObject page, ABTObject customfield, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (page != null)
          hash.putItemByString( OFD_PAGE, page );
      if( customfield != null )
         hash.putItemByString( OFD_CUSTOMFIELD, customfield );

      ABTObject pagemember = createObject( OBJ_MM_PAGEMEMBER, hash, id, ShouldPass);

      return pagemember;
   }

   public ABTObject createMMTask( ABTObject method, Vector taskVector, ABTObject parentTask, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (method != null)
          hash.putItemByString( OFD_METHOD, method );
      if( parentTask != null )
         hash.putItemByString( OFD_PARENTTASK, parentTask );

      ABTObject task = createObject( OBJ_MM_TASK, hash, id, ShouldPass   );
      // Add to task vector
      if (taskVector != null)
      {
          taskVector.addElement(task);
      }

 //     setValue( task, OFD_ID, new ABTInteger( id ), ShouldPass  );

      return task;
   }

   public ABTObject createMMTaskestimate( ABTObject task, ABTObject estmodel, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (task != null)
          hash.putItemByString( OFD_TASK, task );
      if (estmodel != null)
          hash.putItemByString( OFD_ESTMODEL, estmodel );

      ABTObject taskestimate = createObject( OBJ_MM_TASKESTIMATE, hash, id, ShouldPass  );
//      setValue( taskestimate, OFD_ID, new ABTInteger( id ), ShouldPass );

      return taskestimate;
   }

   // 12/08/98 AVP:  Added for all Team Model objects

   public ABTObject createTWAssignment( ABTObject task, ABTObject resource, int id, boolean ShouldPass ) // throws TestRuleException
   {
//      ABTHashtable hash = new ABTHashtable();
      ABTHashtable hash = null;

      if (task != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_TASK, task );
      }
      if (resource != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.putItemByString( OFD_RESOURCE, resource );
      }

      ABTObject assignment = createObject( OBJ_TW_ASSIGNMENT, hash, id, ShouldPass );

      return assignment;
   } // createTWAssignment

   public ABTObject createTWNote( ABTValue parenttype, ABTValue parentid, int id, boolean ShouldPass ) // throws TestRuleException
   {
      ABTHashtable hash = null;

      if (parenttype != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.put(new ABTString(PARENT_TYPE), parenttype);
      }
      if (parentid != null)
      {
          if (null == hash)
              hash = new ABTHashtable();
          hash.put(new ABTString(PARENT_ID), parentid );
      }
      ABTObject note = createObject( OBJ_TW_NOTE, hash, id, ShouldPass  );
//      setValue( note, OFD_ID, new ABTInteger( id ), ShouldPass );

      return note;
   } // createTWNote

   public ABTObject createTWTask( ABTObject project, ABTObject parentTask, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (project != null)
          hash.putItemByString(OFD_PROJECT, project );
/*
      if (parentTask != null )
         hash.putItemByString(OFD_PARENTTASK, parentTask );
*/

      ABTObject task = createObject( OBJ_TW_TASK, hash, id, ShouldPass   );

 //     setValue( task, OFD_ID, new ABTInteger( id ), ShouldPass  );

      return task;
   } // createTWTask

   public ABTObject createTWTimeSheet( ABTObject resource, ABTObject timeperiod, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (resource != null)
          hash.putItemByString( FLD_TW_RESOURCE, resource );
      if (timeperiod != null )
         hash.putItemByString( FLD_TW_TIMEPERIOD, timeperiod );

      ABTObject timesheet = createObject( OBJ_TW_TIMESHEET, hash, id, ShouldPass);

      return timesheet;
   } // createTWTimeSheet

   public ABTObject createTWTimeEntry( ABTObject assignment, int id, boolean ShouldPass  ) // throws TestRuleException
   {
      ABTHashtable hash = new ABTHashtable();

      if (assignment != null)
          hash.putItemByString( FLD_TW_ASSIGNMENT, assignment );

      ABTObject timeentry = createObject( OBJ_TW_TIMEENTRY, hash, id, ShouldPass);

      return timeentry;
   } // createTWTimeEntry

}


