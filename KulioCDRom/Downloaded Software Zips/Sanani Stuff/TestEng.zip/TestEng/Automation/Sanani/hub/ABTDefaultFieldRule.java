
package com.abtcorp.hub;

/*
 * ABTDefaultFieldRule.java 03/10/98
 *
 * Copyright (c) 1998 ABT Corporation All Rights Reserved.
 */


 /*
  * HISTORY:
  *
  * Date        Author          Description
  * 05-09-98	HJB		Initial Design
  *
  *
  * TO DO:
  *
  * 1-  complete implementation
  * 2-
  */

import  java.io.Serializable;
import com.abtcorp.core.*;

/**
 * ABTDefaultFieldRule is the base class allowing common handling of all business rules
 * Depending on the type of the property only a subset of the
 * provided functions are triggered. See the function header
 * for appicable property types
 *
 *
 * @version	1.0
 * @author      Hajo Birthelmer
 * @see         com.abtcorp.hub.ABTRule
 */

public class ABTDefaultFieldRule extends ABTFieldRule implements Serializable,Cloneable
{

//+++++++++++++++
// Getters
//+++++++++++++++

  /**
   * Default onGet, which just returns the passed in value unmodified
   * VALID FOR ALL property types
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param myValue - the value currently available
   * @param parameters - list of parameters and (field/app specific)
   * @return ABTValue - check for ABTError....
   */
  protected ABTValue onGet (ABTUserSession session,ABTObject parent, ABTProperty property, ABTValue myValue, ABTHashtable parameters )
  {
/*      if (parameters != null)
          parameters.put(new ABTString("!Default!"),new ABTString("!Default!"));
*/
      if (property instanceof ABTTestProperty)
          ((ABTTestProperty)property).isDefaultGet = true;
      return myValue;
  }


//+++++++++++++++
// validators
//+++++++++++++++
  /**
   * Default 'would this be a valid value?'- returns true
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param myValue - the value currently available
   * @param parameters - list of parameters and (field/app specific)
   * @return ABTValue - (ABTBoolean or ABTError)
   */
  protected ABTValue isValid (ABTUserSession session,ABTObject parent, ABTValue myValue, ABTHashtable parameters)
  {
/*
     if (parameters != null)
         parameters.put(new ABTString("!Default!"),new ABTString("!Default!"));
*/
    if (myValue instanceof ABTTestProperty)
        ((ABTTestProperty)myValue).isDefaultValid = true;
     return ABTBoolean.True();
  }


//+++++++++++++++
// validators
//+++++++++++++++
  /**
   * Modification/Verification of property keys
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param myProperty - my ABTProperty
   * @param key - the key in the property (e.g. PROP_KVISIBLE)
   * @param defaultValue - the default for the property key
   * @return ABTValue - the default unmodified, some modified ABTValue or ABTError
   * @see com.abtcorp.IABTPROPERTYYPES
   */
  protected ABTValue onPropertyKey (ABTUserSession session,ABTObject parent, ABTProperty myProperty, int key, ABTValue defaultValue)
  {
    if (myProperty instanceof ABTTestProperty)
        ((ABTTestProperty)myProperty).isDefaultPropertyKey = true;
     return defaultValue;
  }



//+++++++++++++++
// Setters / modifiers
//+++++++++++++++


  /**
   * Default onInitialize for setting /modifying additional values
   * @param session - the current user session handle
   * @param object - ABTObject to be initialized
   * @param property - property to be set
   * @param myValue - the current default value
   * @param parameters - list of required parameters
   * @return ABTValue - check for ABTError....
   */
  protected ABTValue onInitialize ( ABTUserSession session,ABTObject object, ABTProperty property,ABTValue myValue, ABTHashtable requiredParameters)

  {
/*
     if (requiredParameters != null)
         requiredParameters.put(new ABTString("!Default!"),new ABTString("!Default!"));
*/
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultInitialize = true;
     return myValue;
  }


  /**
   * Default onSet for modification of a position within an object
   * @param session - the current user session handle
   * @param parent - my ABTObject container (e.g. Task, Project etc.)
   * @param myValue - the value currently available i.e. the ABTObject at this position
   * @param newValue - the new value, i.e. the ABTObject to be placed instead
   * @param parameters - list of parameters and (field/app specific)
   * @return ABTValue - check for ABTError....
   */
  protected ABTValue onSet (ABTUserSession session,ABTObject parent, ABTProperty property,  ABTValue myValue, ABTValue newValue, ABTHashtable parameters)
  {
/*
     if (parameters != null)
         parameters.put(new ABTString("!Default!"),new ABTString("!Default!"));
*/
//     isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultSet = true;
    return write(session,parent,property,myValue,newValue,false);
  }


// NOTIFICATIONS




  /**
   * Notification of an add operation to an objectset stored in this property
   * if used set notifyAdd in rule constructor  to true
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param property - practically this one here
   * @param child - the objectset currently referenced in this property
   * @param newValue - the new value added to this property
   * @param existing - true if the passed in new Value is an existing ABTObject
   *  , false if it was initialized to default values
   * @return null if allowed  or ABTError if rejected
   */
  protected ABTError notifyReferenceAdd (ABTUserSession session,
                                         ABTObject parent,
                                         ABTProperty property,
                                         ABTObjectSet child,
                                         ABTValue newValue,
                                         boolean existing,
                                         boolean dirty)
  {
//     isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultNotifyReferenceAdd = true;
     return null;
  }


  /**
   * Notification of a remove operation in an objectset stored in this property
   * if used set notifyRemove in rule constructor to true
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param property - practically this one here
   * @param child - the objectset currently referenced in this property
   * @param removedValue - the new value added to this property
   * @return null if allowed  or ABTError if rejected
   */
  protected ABTError notifyReferenceRemove (ABTUserSession session,ABTObject parent, ABTProperty property, ABTObjectSet child,  ABTValue removedValue, boolean dirty)
  {
//     isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultNotifyReferenceRemove = true;
     return null;
  }


  /**
   * Notification of a remove operation in an objectset stored in this property
   * if used set notifyClear in rule constructor to true
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param property - practically this one here
   * @param child - the objectset currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
  protected ABTError notifyReferenceClear (ABTUserSession session,ABTObject parent, ABTProperty property, ABTObjectSet child, boolean dirty)
  {
//     isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultNotifyReferenceClear = true;
     return null;
  }




  /**
   * Notification of a set operation in an element of the objectset stored in this property
   * if used set notifyChildSet in rule constructor to true
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param property - practically this one here
   * @param childSet - the objectset currently referenced in this property
   * @param child - the object in the childset which was modified
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
  protected ABTError notifyReferenceChildSet (ABTUserSession session,ABTObject parent, ABTProperty property, ABTObjectSet childSet,  ABTObject child, ABTProperty childProperty, ABTValue oldValue, ABTValue newValue, boolean dirty )
  {
//     isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultNotifyReferenceChild = true;
     return null;
  }

  /**
   * Notification of a set operation in an element of the objectset stored in this property
   * if used set  notifySet in rule constructor to true
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param property - practically this one here
   * @param child - the object currently referenced in this property
   * @param childProperty - the property modified
   * @param oldValue - the old value in the child property
   * @param newValue - the new value in the child property
   * @return null if allowed  or ABTError if rejected
   */
  protected ABTError notifyReferenceSet (ABTUserSession session,ABTObject parent, ABTProperty property, ABTObject child,  ABTProperty childProperty, ABTValue oldValue, ABTValue newValue, boolean dirty )
  {
//     isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultNotifyReferenceSet = true;
     return null;
  }

  /**
   * Notification of a delete operation on an object referenced in this property
   * @param parent - my Rule container (e.g. Task, Project etc.)
   * @param child - the object currently referenced in this property
   * @return null if allowed  or ABTError if rejected
   */
   protected ABTError notifyReferenceDelete (ABTUserSession session, ABTObject parent, ABTProperty property, ABTObject child, boolean dirty)
   {
//      isDefault = true;
     if (property instanceof ABTTestProperty)
         ((ABTTestProperty)property).isDefaultNotifyReferenceDelete = true;
      return null;
   }


}
