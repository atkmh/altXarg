package com.abtcorp.hub;

// A special extension of ABTProperty, used by Test Engineering to
// track which field-level rules are invoked by ABTDefaultFieldRule, which are unique

// 12/11/98 AVP:  added this logic to determine which
class ABTTestProperty extends ABTProperty
{
    public boolean
        isDefaultInitialize = false,
        isDefaultGet = false,
        isDefaultSet = false,
        isDefaultPropertyKey = false,
        isDefaultValid = false,
        isDefaultNotifyReferenceAdd = false,
        isDefaultNotifyReferenceRemove = false,
        isDefaultNotifyReferenceClear = false,
        isDefaultNotifyReferenceSet = false,
        isDefaultNotifyReferenceChild = false,
        isDefaultNotifyReferenceDelete = false;
        

    public ABTTestProperty( String name_, String caption_, int type_)
    {
        // construct ABTProperty
	    super(name_, caption_, type_);
    } // constructor

} // ABTTestProperty
