package com.abtcorp.objectModel;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;

// The purpose is to create a generic object pre-populated with default properties,
// for low-level mechanical testing of ObjectSpace API
// There are no actual rules invoked for this object, no Rule methods overridden
// except SetDefault
// "Full" Object 2 of 2
public class TestFullObject2 extends com.abtcorp.hub.ABTRule
{
    public TestFullObject2()
    {
      super();
    }

    protected void setDefaultProperties()
    {
        for (int NameCtr = 0, CaptionCtr = 0; NameCtr < 200; NameCtr++, CaptionCtr++)    
            addProperty("Name" + NameCtr,"Caption" + CaptionCtr,PROP_INT,false,true,true,false,null,null,null);
    } // SetDefaultProperties

} // TestFullObject2






