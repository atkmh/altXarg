import com.abtcorp.core.*;
import com.abtcorp.hub.*;

// In this object, we will override all exposed methods in ABTRule
public class TestEmptyObject extends com.abtcorp.hub.ABTRule
{
    public TestEmptyObject()
    {
      super();
    }

//                                 String name_,
//                                 int type_,
//                                 boolean virtual_,
//                                 boolean visible_,
//                                 boolean updatable_,
//                                 String referenceType,
//                                 String propertyRule
    protected void setDefaultProperties()
    {
        // Start with empty setDefaultProperties
   }

} // TestEmptyObject






