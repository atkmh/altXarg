import java.io.*;
import java.util.Date;

public class LogFile extends Object implements LogType
{
	private FileOutputStream CFileOut;
	private FileOutputStream FailFileOut = null;
	//private DataOutputStream DataFileOut; 
	private PrintStream DataFileOut;
	private PrintStream DataFailFileOut = null;
	private int 
	    TotalFailures = 0,
	    TotalPass = 0;
	
	public LogFile(String strFileName, boolean VerifyExistence, boolean LogFailure) throws IOException
	{
		File file = new File(strFileName + ".log");
		File FailFile = new File(strFileName + "FAIL" + ".log");
        FailFileOut = null;		    
        TotalFailures = 0;
        TotalPass = 0;
		
		String msg;
		
		//Check if the file exists
   		if (file.exists())
    	    msg = strFileName+" already exists and will be overwritten when you press ENTER!"; 
        else		    
            msg = "";
    	
	   	if (msg != "")
        {
            if (VerifyExistence) {
    		    System.out.println(msg);
        	    System.in.read();
            } // end if VerifyExistence        	    
	   		file.delete();
        }
		//Check if the fail file exists
   		if (FailFile.exists())
    	    msg = strFileName+" already exists and will be overwritten when you press ENTER!"; 
        else		    
            msg = "";
    	
	   	if (msg != "")
        {
            if (VerifyExistence) {
    		    System.out.println(msg);
        	    System.in.read();
            } // end if VerifyExistence        	    
	   		FailFile.delete();
        }
		CFileOut = new FileOutputStream(file);
		if (LogFailure)
    		FailFileOut = new FileOutputStream(FailFile);
		//DataFileOut = new DataOutputStream(CFileOut);
		DataFileOut = new PrintStream(CFileOut);
		if (LogFailure) 
    		DataFailFileOut = new PrintStream(FailFileOut);
	 }

	 public void LogDisplay(int intLogType, String strMsg) {
	    System.out.println(TranslateLogType(intLogType) + ": " + strMsg);
	    LogWrite(intLogType, strMsg);
     } // LogDisplay 
     
	 public void LogWrite(int intLogType, String strMsg)
	 {
	    Date CurrentTime = new Date();
		String strFinalMsg = CurrentTime.toLocaleString()+":"+TranslateLogType(intLogType)+":"+" "+strMsg;
		if (intLogType == LogType.FAIL)
		    TotalFailures++;
		if (intLogType == LogType.PASS)
		    TotalPass++;
	//	try {  
			//DataFileOut.writeBytes(strFinalMsg);
			DataFileOut.println(strFinalMsg);
			if (intLogType == LogType.FAIL) 
    			if (FailFileOut != null) 
        			DataFailFileOut.println(strFinalMsg);
			//DataFileOut.println();
      //  } catch (IOException e) {
	//		System.out.println("ERROR: Cannot write to a file.");
//        } 
	 } 
	 
	 public void LogTotals()
	 {
	    LogDisplay(COMMENT,"Totals so far: FAIL = " + TotalFailures + ", PASS = " + TotalPass);
     } // LogTotals	    
	 
     private String TranslateLogType(int intLogType)
     {
		 switch (intLogType)
         {
			 case LogType.COMMENT: return "COMMENT";
		     case LogType.DEBUG:   return "DEBUG";
			 case LogType.FAIL:    return "FAIL";
			 case LogType.PASS:    return "PASS";
			 default: return "Undefined message type!";		  
         }
     }

	protected void finalize()
	{
		try{ 
			CFileOut.close();          
			if (FailFileOut != null) {
			    FailFileOut.close();
            }			    
		} catch (IOException e){
			System.out.println("ERROR: Cannot close the LOG file.");
		}
	}
}
		 
		     		 


	  	 	  
			     
		  


