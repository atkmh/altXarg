package com.abtcorp.objectModel;
import com.abtcorp.core.*;
import com.abtcorp.hub.*;
// The purpose is to create a generic "empty" object (except for default property
// added in super constructor), for low-level mechanical testing of
// ObjectSpace API
// There are no actual rules invoked for this object, no Rule methods overridden
// (other than empty SetDefault below)
// Empty Object 2 of 2
public class TestEmptyObject2 extends com.abtcorp.hub.ABTRule
{
    public TestEmptyObject2()
    {
      super();
    }

    protected void setDefaultProperties()
    {
        // Start with empty setDefaultProperties
   }

} // TestEmptyObject2






