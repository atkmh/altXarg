import java.io.*;

public class ReadFile extends Object 
{
	private FileInputStream CFileIn;
	private String FileName;
	private int ReadValue = ' ';

	public ReadFile(String strFileName) throws IOException 
	{
	    FileName = strFileName;
	    CFileIn = null;
		CFileIn = new FileInputStream(strFileName);
		ReadValue = ' ';
    } //ReadFile constructor

    // Read this file up until a specified string StopString is reached
    // (read to end of the specified StopString)
    public boolean ReadFileTo(String StopString) throws IOException 
    {
        int
            CompareCtr = 0;

        do  {  
            // if we've read to end of StopString, with perfect match,
            // stop now, and return success
            if (CompareCtr >= StopString.length()) 
                return true;
            if ((char)ReadValue == StopString.charAt(CompareCtr))
                CompareCtr++;
            else
                CompareCtr = 0;
        } while ((ReadValue = CFileIn.read()) != -1); // end while read() 
        // Never read the full StopString, so return failure
        return false;
    } // ReadFileTo

    // read to StrongString (as in ReadFileTo above)
    // store all bytes (up until StopString) into a String Buffer 
    // then return String Buffer as String
    public String ReadFileToString(String StopString) throws IOException 
    {
        StringBuffer StoreString = new StringBuffer(0);
        int
            CompareCtr = 0;

       do  { // while reading valid byte from file
            // if we've read to end of StopString, with perfect match,
            // stop now and return String Buffer of all bytes read
            // before StopString
            if (CompareCtr >= StopString.length()) {
                // remove StopString from this buffer
                StoreString.setLength(StoreString.length() - CompareCtr);
                return (new String(StoreString));
            }                
            StoreString.append((char)ReadValue);
            if ((char)ReadValue == StopString.charAt(CompareCtr))
                CompareCtr++;
            else 
                CompareCtr = 0;
        }  while ((ReadValue = CFileIn.read()) != -1); // end while read()
        return null;
    } // ReadFileToString

	protected void finalize()
	{
        if (CFileIn != null)
            try {
    			CFileIn.close();
    		} catch (IOException e){
    			System.out.println("ERROR: Cannot close the file " + FileName);
    		}
	} // finalize
} // ReadFile









