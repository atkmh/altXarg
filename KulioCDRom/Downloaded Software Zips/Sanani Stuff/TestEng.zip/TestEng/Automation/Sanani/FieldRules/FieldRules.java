import com.abtcorp.core.*;
import com.abtcorp.hub.*;
import com.abtcorp.blob.*;
import com.abtcorp.objectModel.pm.*;
import com.abtcorp.io.PMWRepo.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.lang.Math;
import java.text.MessageFormat;

import com.objectspace.jgl.ArrayIterator;
import Sanani.Lib.*;
import TestLib.*;


/* AVP 12/14/98 - This is lifted from TestRules - which actually ended up testing all of the 
ABT,PM,MM properties and the PRESENCE of Field Rules in those Properties.
This class attempts to test actual Field Rule functionality within ABT and PM.
*/
public class FieldRules extends SananiBuilder
{
   // Generic Time Stamp modules to be used for testing certain field rules,
   // rather than passing them as arguments through all of the methods
   // TODO AVP 12/31/98:  Not yet fully generic - must equal 5 working days
   // Sunday midnight - Sunday midnight (2nd and 3rd days must be workdays)
   ABTTime
      testStart = null,
      testFinish = null;
      
   public FieldRules( String[] args )
   {
      if( args != null && args.length > 0 )
      {
         repositoryName_ = args[0];

         if( args.length > 1 )
            projectExternalID_ = args[1];
      }
   }

   private ABTValue populate() // throws TestRuleException
   {
      return null;
   }

   public void run()
   {

      try
      {
          // 9/9/98 - AVP - create Log object
          CurrentLog = new LogFile("TestFieldRules",false,true);
          CurrentLog.LogDisplay(COMMENT, "FieldRules starting..." );
          createObjectSpace();

         testFieldRules();
      }
      catch( Exception e )
      {
         CurrentLog.LogDisplay(COMMENT, "Exception caught... printing stack trace..." );
         e.printStackTrace();
      }

      CurrentLog.LogDisplay(COMMENT, "FieldRules ended." );
   }

   public void testFieldRules() // throws TestRuleException
   {
      CurrentLog.LogDisplay(COMMENT,"Testing Field Rules");

      // Special request from Zane:  Use CSV format to log failures, so must be separate from automatic "fail" log file
      try
      {
          PropertyFailLog = new LogFile("TestDiscrepancy.csv",false,false);
      } catch (Exception e)
      {
          CurrentLog.LogDisplay(FAIL,"Java Exception encountered creating property fail log, error = " + e);
      }

      // Create required objects, then set values needed for field rules testing
      // Project, Global, and Methodology Models

      // Global Model - site, resource, calendar (reference calendar object in all appropriate fields)
      CurrentLog.LogDisplay(COMMENT,"Create Global Model");
      ABTObject    site       = createSite(1, true);
      ABTObject    calendar = createCalendar (site, 1, true);
      setValue(calendar, OFD_VALUE, new ABTCalendar(), true);
      setValue(site,OFD_CALENDAR,new ABTCalendar(),true);
      setValue(site,OFD_STDCALENDAR,calendar,true);
      ABTObject    resource   = createResource(site, 1, true);
      setValue(resource,OFD_BASECALENDAR,calendar,true);
      setValue(resource,OFD_CALENDAR,new ABTCalendar(),true);

      // Project Model - project, team, task, assignment (reference same calendar object)
      CurrentLog.LogDisplay(COMMENT,"Create Project Model");
      ABTObject    project     = createProject( 1, true );
      ABTObject    team       = createTeamResource( project, resource, 1, true );
      ABTObject    task        = createTask( project, null, null, 1, true );
      setValue(task, OFD_CALENDAR, calendar, true);
      ABTObject    assignment  = createAssignment( task, resource, 1, true);
      setValue(assignment, OFD_CALENDAR, calendar, true);
      
      // Set special values for field rules testing
      // set Rate to 1.0 to start
      setValue(resource,OFD_RATE, new ABTDouble(1.0), true);
      // Percent Complete at 25%
      setValue(task, OFD_PCTCOMPLETE, new ABTDouble(.25), true);
      // verify all date variance field rules
      testVariance(task,
                   ABTTime.valueOf("12/1/98 8:00 AM"), // start
                   ABTTime.valueOf("12/7/98 5:00 PM"), // finish
                   ABTTime.valueOf("12/2/98 8:00 AM"), // base start
                   ABTTime.valueOf("12/9/98 5:00 PM"), // base finish
                   ABTTime.valueOf("12/21/98 5:00 PM"), // late finish
                   5,  // duration 
                   6,   // base duration 
                   1,   // 1 working day baseStart - Start
                   2,    // 2 working days baseFinish - Finish
                   10    // 10 working days lateFinish - Finish
                   );
      // Special test - verify Percent Expended when no curves yet set
      verifyPercentExpended(task,null,null);
      // Set Curves - Actual, Est, Base - all value curves
      ABTCurve actCurve = 
          setCurveValue(assignment,
              OFD_ACTCURVE,
              ABTTime.valueOf("12/14/98 8:00 AM"), 
              ABTTime.valueOf("12/20/98 5:00 PM"), 
              20.0 // how many hours?
              ); 
      // Special test - verify Percent Expended when estCurve not yet set              
      verifyPercentExpended(task,actCurve,actCurve);
      ABTCurve estCurve = 
          setCurveValue(assignment,
              OFD_ESTCURVE,
              ABTTime.valueOf("12/21/98 8:00 AM"), 
              ABTTime.valueOf("12/26/98 5:00 PM"), 
              40.0 // how many hours?
              ); 
      ABTCurve baseCurve = 
          setCurveValue(assignment,
              OFD_BASECURVE,
              ABTTime.valueOf("12/3/98 8:00 AM"), 
              ABTTime.valueOf("12/22/98 5:00 PM"), 
              30.0 // how many hours?
              ); 
      // set As Of Date to end of Act Curve 
      setValue(project,OFD_ASOF,ABTTime.valueOf("12/20/98 8:00 AM"), true);
      // verify all "EV" field rules 
      testEV(task, 30.0, 20.0, 40.0);                 
      
      // verify all "ASS" (Assignment) field rules
      testAssignment(project,team,task,assignment);
      
      // Verify AVAIL Field Rules
      testAvail(resource,
                team,
                project,
                task
                );
/*                
       // Test DOH/DOT Field Rules
       // First test the DOT.onSet, which will reset DOH
       // CORRECT - with current dates, 1 day apart 
       testDOT(resource,
              ABTTime.valueOf("12/1/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/2/98 5:00 PM")  // DOT
              ); 
       // CORRECT - With current dates, same day, 1 start of day, 1 end of day
       testDOT(resource,
              ABTTime.valueOf("12/3/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/3/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT (DOH end of day, DOT start of day)
       testDOT(resource,
              ABTTime.valueOf("12/5/98 5:00 PM"), // DOH
              ABTTime.valueOf("12/4/98 8:00 AM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT (DOH start of day, DOT end of day)
       testDOT(resource,
              ABTTime.valueOf("12/7/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/6/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT (same day - DOH start of day, DOT end of day)
       testDOT(resource,
              ABTTime.valueOf("12/8/98 5:00 PM"), // DOH
              ABTTime.valueOf("12/8/98 8:00 AM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT - different months
       testDOT(resource,
              ABTTime.valueOf("12/9/98 8:00 AM"), // DOH
              ABTTime.valueOf("11/9/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT - different years
       testDOT(resource,
              ABTTime.valueOf("12/10/99 8:00 AM"), // DOH
              ABTTime.valueOf("12/10/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT - Y2K
       testDOT(resource,
              ABTTime.valueOf("12/11/01 8:00 AM"), // DOH
              ABTTime.valueOf("12/11/98 5:00 PM")  // DOT
              ); 
       // CORRECT/INCORRECT??? - With current dates, same day, SAME values, (both start of day)
       testDOT(resource,
              ABTTime.valueOf("12/14/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/14/98 8:00 AM")  // DOT
              ); 
       // Now test the DOH.onset, which will reset DOT        
       // CORRECT - with current dates, 1 day apart 
       testDOH(resource,
              ABTTime.valueOf("12/1/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/2/98 5:00 PM")  // DOT
              ); 
       // CORRECT - With current dates, same day, 1 start of day, 1 end of day
       testDOH(resource,
              ABTTime.valueOf("12/3/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/3/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT (DOH end of day, DOT start of day)
       testDOH(resource,
              ABTTime.valueOf("12/5/98 5:00 PM"), // DOH
              ABTTime.valueOf("12/4/98 8:00 AM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT (DOH start of day, DOT end of day)
       testDOH(resource,
              ABTTime.valueOf("12/7/98 8:00 AM"), // DOH
              ABTTime.valueOf("12/6/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT (same day - DOH start of day, DOT end of day)
       testDOH(resource,
              ABTTime.valueOf("12/8/98 5:00 PM"), // DOH
              ABTTime.valueOf("12/8/98 8:00 AM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT - different months
       testDOH(resource,
              ABTTime.valueOf("12/9/98 8:00 AM"), // DOH
              ABTTime.valueOf("11/9/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT - different years
       testDOH(resource,
              ABTTime.valueOf("12/10/99 8:00 AM"), // DOH
              ABTTime.valueOf("12/10/98 5:00 PM")  // DOT
              ); 
       // INCORRECT - DOH later than DOT - Y2K
       testDOH(resource,
              ABTTime.valueOf("12/11/01 8:00 AM"), // DOH
              ABTTime.valueOf("12/11/98 5:00 PM")  // DOT
              ); 
       // CORRECT/INCORRECT??? - With current dates, same day, SAME values, (both end of day)
       testDOH(resource,
              ABTTime.valueOf("12/14/98 5:00 PM"), // DOH
              ABTTime.valueOf("12/14/98 5:00 PM")  // DOT
              ); 
       // PRI (priority) field rules       
       testPriority(project, task);
       ABTObject    constraint  = createConstraint( task, 1, true);
       
       // CNST (constraint) field rules
       testConstraint(constraint);
       
       // PKG (Package) field rules
       ABTObject    method = createMethod( 1, true );
       verifyValue(method,OFD_VERSION,new ABTInteger(1), "DEFAULT", true);
       ABTObject mmPackage  = createPackage( method, new ABTBoolean(true), 1, true);
       testPackage(mmPackage);
       mmPackage  = createPackage( method, new ABTBoolean(false), 2, true);
       testPackage(mmPackage);
       // try to create package without hidden property - should fail
       mmPackage  = createPackage( method, null, 3, false);
       
       // PRJ (Project) field rules
       testProject(project);
*/       
       
   } // testFieldRules


   // This method tests DOT.onset in Resource
   // DOH is set first, then DOT, which causes DOH to be adjusted
   // General rule:  DOH must be <= DOT (they can be equal)
   boolean testDOT (ABTObject resource, ABTTime testDOH, ABTTime testDOT)
   {
       setValue(resource,OFD_DOH,testDOH,true); 
       setValue(resource,OFD_DOT,testDOT,true); 
       // If incorrect, DOT set to DOH
       if (testDOH.getJulian() > testDOT.getJulian())
       {
           verifyValue(resource,OFD_DOH,testDOT,null,null,"Test DOT Field Rules",true);
           verifyValue(resource,OFD_DOT,testDOT,null,null,"Test DOT Field Rules",true);
       } else {
           verifyValue(resource,OFD_DOH,testDOH,null,null,"Test DOT Field Rules",true);
           verifyValue(resource,OFD_DOT,testDOT,null,null,"Test DOT Field Rules",true);
       } 
       
       return true;
   } // testDOT 

   // This method tests DOH.onset in Resource
   // DOT is set first, then DOH, which causes DOT to be adjusted
   // General rule:  DOH must be <= DOT (they can be equal)
   boolean testDOH (ABTObject resource, ABTTime testDOH, ABTTime testDOT)
   {
       setValue(resource,OFD_DOT,testDOT,true); 
       setValue(resource,OFD_DOH,testDOH,true); 
       // If incorrect, DOH set to DOT
       if (testDOH.getJulian() > testDOT.getJulian())
       {
           verifyValue(resource,OFD_DOH,testDOH,null,null,"Test DOH Field Rules",true);
           verifyValue(resource,OFD_DOT,testDOH,null,null,"Test DOH Field Rules",true);
       } else {
           verifyValue(resource,OFD_DOH,testDOH,null,null,"Test DOH Field Rules",true);
           verifyValue(resource,OFD_DOT,testDOT,null,null,"Test DOH Field Rules",true);
       } 
       
       return true;
   } // testDOH 

   // This method tests the Priority properties of the Task and Project objects
   boolean testPriority (ABTObject project, ABTObject task)
   {
       // Since I have not yet set Priority and Project level,
       // isPrioritySet should return false
       // onGet rule should return project default of 10 for both Project and Task
       verifyPriority(project,
                      task,
                      10, // project priority - should read "up" to Project default
                      10, // task priority
                      false // isPrioritySet for task
                      );
       // Now set Project level Priority to a valid value
       // isPrioritySet should return false, since Task priority has not been set
       // onGet rule should return project and task priority of 8 
       setValue(project,OFD_PRIORITY,new ABTShort((short)8), true);
       verifyPriority(project,
                      task,
                      8, // project priority 
                      8, // task priority - should read "up" to Project value
                      false // isPrioritySet for task
                      );
       // Now set task Priority to SAME value (but separate onSet)
       // isPrioritySet should return true, since Task priority has been set
       // onGet rule should return project priority of 8 and Task priority of 8
       setValue(task,OFD_PRIORITY,new ABTShort((short)8),true);
       verifyPriority(project,
                      task,
                      8, // project priority 
                      8, // task priority - same value, set separately
                      true // isPrioritySet for task
                      );
       // Now set task level Priority to a separate valid value
       // isPrioritySet should return true, since Task priority has been set
       // onGet rule should return project priority of 8 and Task priority of 18
       setValue(task,OFD_PRIORITY,new ABTShort((short)18), true);
       verifyPriority(project,
                      task,
                      8, // project priority 
                      18, // task priority - separate value now
                      true // isPrioritySet for task
                      );
       // Now set project level Priority to null
       // isPrioritySet should return true, since Task priority has been set
       // onGet rule should return project priority of 10 (default) and Task priority of 18
       project.setValue(session_,OFD_PRIORITY,null);
       verifyPriority(project,
                      task,
                      10, // project priority 
                      18, // task priority - separate value now
                      true // isPrioritySet for task
                      );
        
       return true; 
   } // testPriority 
   
   // This method verifies the task and object Priority properties (onGet rule), and
   // isPrioritySet flag for the task
   boolean verifyPriority (ABTObject project, ABTObject task, int projectPriority, int taskPriority, boolean prioritySet)
   {
       verifyValue(task,OFD_IS_PRIORITY_SET,new ABTBoolean(prioritySet),null,null,"VERIFY PRIORITY",true);
       verifyValue(task,OFD_PRIORITY,new ABTShort((short)taskPriority),null,null,"VERIFY PRIORITY",true);
       verifyValue(project,OFD_PRIORITY,new ABTShort((short)projectPriority),null,null,"VERIFY PRIORITY",true);
       
       return true;
   } // verifyPriority 
   

   // This method verifies the constraint field rules 
   // Currently testing Constraint.Time Property Key 
   // Extended Property Key PM is TRUE if:
   // Constraint.Type = (3 - "finish no earlier than", 
   //                    4 - "finish no later than", 
   //                    5 - "must finish on")
   // Extended Property Key PM is FALSE if:
   // Constraint.Type = (1 - "as late as possible",
   //                    2 - "as early as possible",
   //                    6 - "must start on",
   //                    7 - "start no earlier than",
   //                    8 - "start no later than")
   boolean testConstraint(ABTObject constraint)
   {
        // If Constraint Type is NOT yet set, should return default of 7,
        // so Constraint.Time should NOT be end of day
        verifyConstraint(constraint, false);
        // If Constraint Type is set to 3,
        // Constraint.Time SHOULD be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(3), true);
        verifyConstraint(constraint, true);
        // If Constraint Type is set to 1,
        // Constraint.Time SHOULD NOT be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(1), true);
        verifyConstraint(constraint, false);
        // If Constraint Type is set to 5,
        // Constraint.Time SHOULD be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(5), true);
        verifyConstraint(constraint, true);
        // If Constraint Type is set to 4,
        // Constraint.Time SHOULD be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(4), true);
        verifyConstraint(constraint, true);
        // If Constraint Type is set to 4 again,
        // Constraint.Time SHOULD be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(4), true);
        verifyConstraint(constraint, true);
        // If Constraint Type is set to null,
        // Constraint.Time SHOULD NOT be end of day
        constraint.setValue(session_, OFD_TYPE, null, null);
        verifyConstraint(constraint, false);
        // If Constraint Type is set to 3,
        // Constraint.Time SHOULD be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(3), true);
        verifyConstraint(constraint, true);
        // If Constraint Type is set to 10 (outside of range),
        // Constraint.Time SHOULD NOT be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(10), true);
        verifyConstraint(constraint, false);
        // If Constraint Type is set to 8, 
        // Constraint.Time SHOULD NOT be end of day
        setValue(constraint, OFD_TYPE, new ABTInteger(8), true);
        verifyConstraint(constraint, false);
        
        return true;    
   } // testConstraint 
   
   boolean verifyConstraint(ABTObject constraint, boolean shouldPM)
   {
/*       ABTProperty
           timeProperty = null;
*/           
       ABTValue
           extPMFlag = null;
            
//       timeProperty = constraint.getProperty(session_,OFD_TIME);
       extPMFlag = constraint.getPropertyKey(session_,OFD_TIME, PROP_EXTTYPE_PM);
  //     extPMFlag = timeProperty.getPropertyKey(PROP_EXTTYPE_PM);
       // if no setting on Property Key
       if (ABTError.isError(extPMFlag)) 
       {
           checkError(extPMFlag,true);
           return false;
       }    
       if (extPMFlag instanceof ABTBoolean)
       {
           if (extPMFlag.booleanValue() == shouldPM) 
           {
               CurrentLog.LogWrite(PASS,constraint.getObjectType() + "Extended Property Key - PM - returns " + extPMFlag + "correctly");
               return true;
           } else {
               CurrentLog.LogDisplay(FAIL,constraint.getObjectType() + "Extended Property Key - PM - returns " + extPMFlag + " - " + shouldPM + " was expected");
               return false;
           }                
       }            
       
       // Wasn't ABTBoolean, so must be wrong
       CurrentLog.LogDisplay(FAIL,constraint.getObjectType() + "Extended Property Key - PM - returns non-ABTBoolean");
       return false;
   } // verifyConstraint
   
   // This method verifies the package field rules 
   // Currently testing Package.Hidden reset rule
   // Hidden property (boolean) is set when Package is created
   // After package is created, Hidden can NOT be reset
   boolean testPackage(ABTObject mmPackage)
   {
        // Try setting to false - should NOT be accepted
        verifyPackage(mmPackage, false);
        // Try setting to true - should NOT be accepted
        verifyPackage(mmPackage, true);
        // Try setting to false again - should NOT be accepted
        verifyPackage(mmPackage, false);

        return true;    
   } // testPackage
   
   boolean verifyPackage(ABTObject mmPackage, boolean hiddenSetValue)
   {
       ABTValue
           hiddenValue = null;

       // first, retrieve original value
       hiddenValue = getValue(mmPackage,OFD_HIDDEN,true);
       // Attempt to set to the passed value - should ALWAYS fail
       setValue(mmPackage,OFD_HIDDEN,new ABTBoolean(hiddenSetValue), false);
       // verify original value still there
       verifyValue(mmPackage, OFD_HIDDEN, hiddenValue, null,null,"PACKAGE HIDDEN PROPERTY", true);
       // attempt to set to null - should ALWAYS fail
       setValue(mmPackage,OFD_HIDDEN,null,false);
       // verify original value still there
       verifyValue(mmPackage, OFD_HIDDEN, hiddenValue, null,null,"PACKAGE HIDDEN PROPERTY", true);
       
       return true;
   } // verifyPackage
   
   // This method verifies the "Project" field rules
   // Currently testing Project.isApproved and Project.isClosed
   // Both are virtual properties, who return true when 
   // pmApprovedTime or pmClosedTime is not null
   // TODO - Closed Time
   boolean testProject(ABTObject project)
   {
        // Verify isApproved is false BEFORE setting any Approved Time value
        verifyApprovedTime(project,null);
        // Set Approved Time to workday - start of day - isApproved should be TRUE
        verifyApprovedTime(project,ABTTime.valueOf("12/1/98 8:00 AM"));
        // Set approved time to a value - non-workday - isApproved should be TRUE
        verifyApprovedTime(project, ABTTime.valueOf("12/6/98 8:00 AM"));
        // Set approved time to a non-start of day value - isApproved should be TRUE
        verifyApprovedTime(project, ABTTime.now());
        // Set approved time to null - isApproved should be FALSE
        setValue(project,OFD_APPROVEDTIME, null, true);
        verifyApprovedTime(project, null);
        // Set approved time to a value - workday - end of day - isApproved should be TRUE
        verifyApprovedTime(project, ABTTime.valueOf("12/1/98 5:00 PM"));
        // Verify isClosed is false BEFORE setting any Closed Time value
        verifyClosedTime(project,null);
        // Set Closed Time to workday - start of day - isClosed should be TRUE
        verifyClosedTime(project,ABTTime.valueOf("12/1/98 8:00 AM"));
        // Set Closed time to a value - non-workday - isClosed should be TRUE
        verifyClosedTime(project, ABTTime.valueOf("12/6/98 8:00 AM"));
        // Set Closed time to a non-start of day value - isClosed should be TRUE
        verifyClosedTime(project, ABTTime.now());
        // Set Closed time to null - isClosed should be FALSE
        setValue(project,OFD_CLOSEDTIME, null, true);
        verifyClosedTime(project, null);
        // Set Closed time to a value - workday - end of day - isClosed should be TRUE
        verifyClosedTime(project, ABTTime.valueOf("12/1/98 5:00 PM"));
        
        return true;    
   } // testProject
   
   boolean verifyApprovedTime(ABTObject project, ABTTime setTimeValue)
   {
      // Set to passed value - should pass 
       if (setTimeValue != null)
           setValue(project,OFD_APPROVEDTIME,setTimeValue, true);
       // verify flag based on null Approved Time
       if (setTimeValue != null)
       {
           verifyValue(project, OFD_ISAPPROVED, new ABTBoolean(true), null,null,"PROJECT ISAPPROVED PROPERTY", true);
       } else {
           verifyValue(project, OFD_ISAPPROVED, new ABTBoolean(false), null,null,"PROJECT ISAPPROVED PROPERTY", true);
       } 
       
       return true;
   } // verifyApprovedTime

   boolean verifyClosedTime(ABTObject project, ABTTime setTimeValue)
   {
      // Set to passed value - should pass 
       if (setTimeValue != null)
           setValue(project,OFD_CLOSEDTIME,setTimeValue, true);
       // verify flag based on null Closed Time
       if (setTimeValue != null)
       {
           verifyValue(project, OFD_ISCLOSED, new ABTBoolean(true), null,null,"PROJECT ISCLOSED PROPERTY", true);
       } else {
           verifyValue(project, OFD_ISCLOSED, new ABTBoolean(false), null,null,"PROJECT ISCLOSED PROPERTY", true);
       } 
       
       return true;
   } // verifyClosedTime
   
   // This method tests all of the values that have been defined as "EV" - Calculations on Curves
   // Specifically, testing onGet for the Task properties:
   //       ActualPctSpent
   //       ACWP
   //       AV
   //       BAC
   //       BCWP
   //       BCWS
   //       CPI
   //       CV
   //       CVI
   //       EAC
   //       PerformancePctComplete
   //       SchedulePctComplete
   //       SPI
   //       SV
   //       SVI
   //       VAC
   // Before calling this method, the following steps MUST be performed:
   //       Create site object
   //       Create resource object
   //       Create project object
   //       Create task object for that project
   //       Create assignment object for the created task and resource
   //       Set OFD_CALENDAR properties for all of the above objects, to a valid ABTCalendar
   // The following variation steps CAN be performed before each call to this method:
   //       Set task.estCurve (OFD_ESTCURVE), task.actCurve (OFD_ACTCURVE), and task.baseCurve (OFD_BASECURVE)
   //       to different ABTCurves
   //       Set resource.rate (OFD_RATE) to different values (ABTDouble or ABTInteger)
   //       Set project As Of Date (OFD_ASOF) to different date/time stamps (ABTTime)
   //       Set task pct complete (OFD_PCTCOMPLETE) to different values (double - decimal value)
   // If curves have been set, pass "should be" values as parameters:
   //       double baseTotalUsage   - Baseline Total Usage (per basecurve value)
   //       double actTotalUsage    - Actual Total Usage (per actcurve value)
   //       double estTotalUsage    - Estimated Total Usage (perestcurve value)
   boolean testEV(ABTObject task, double baseTotalUsage, double actTotalUsage, double estTotalUsage)
   {
          ABTValue testActpctspent = getValue (task, OFD_ACTUAL_PCT_SPENT, true);
          ABTValue testACWP = getValue( task, OFD_ACWP, true);
          ABTValue testAV = getValue( task, OFD_AV, true);
          ABTValue testBAC = getValue( task, OFD_BAC, true);
          ABTValue testBCWP = getValue( task, OFD_BCWP, true);
          ABTValue testBCWS = getValue( task, OFD_BCWS, true);
          ABTValue testCPI = getValue( task, OFD_CPI, true);
          ABTValue testCV = getValue( task, OFD_CV, true);
          ABTValue testCVI = getValue( task, OFD_CVI, true);
          ABTValue testEAC = getValue( task, OFD_EAC, true);
          ABTValue testPerformancePctComplete = getValue( task, OFD_PERFORMANCE_PCT_COMPLETE, true);
          ABTValue testSchedulePctComplete = getValue( task, OFD_SCHEDULE_PCT_COMPLETE, true);
          ABTValue testSPI = getValue( task, OFD_SPI, true);
          ABTValue testSV = getValue( task, OFD_SV, true);
          ABTValue testSVI = getValue( task, OFD_SVI, true);
          ABTValue testVAC = getValue( task, OFD_VAC, true);
          
          return true;
   } // testEV 
 
   // This method tests all Date variance field rules
   // Specifically, testing onGet for the Task properties:
   //       DurationVariance
   //       EndVariance
   //       EndVsLateEnd
   //       StartVariance
   //       
   boolean testVariance (ABTObject task, 
                         ABTTime start,
                         ABTTime finish,
                         ABTTime baseStart, 
                         ABTTime baseFinish, 
                         ABTTime lateFinish,
                         double duration,
                         double baseDuration,
                         double startDiff,
                         double finishDiff,
                         double lateDiff)
   {
          // SET TASK VALUES
          setValue(task, OFD_START, start, true);
          setValue(task, OFD_FINISH, finish, true);
          setValue(task, OFD_BASESTART, baseStart, true);
          setValue(task, OFD_BASEFINISH, baseFinish, true);
          setValue(task, OFD_LATEFINISH, lateFinish, true);
          setValue(task, OFD_DURATION, new ABTDouble(duration), true);
          setValue(task, OFD_BASEDURATION, new ABTDouble(baseDuration), true);
          verifyValue(task, OFD_START, start, null,null,"Test Variance Field Rules", true);
          verifyValue(task, OFD_FINISH, finish, null,null,"Test Variance Field Rules", true);
          verifyValue(task, OFD_BASESTART, baseStart, null,null,"Test Variance Field Rules", true);
          verifyValue(task, OFD_BASEFINISH, baseFinish, null,null,"Test Variance Field Rules", true);
          verifyValue(task, OFD_LATEFINISH, lateFinish, null,null,"Test Variance Field Rules", true);
          verifyValue(task, OFD_DURATION, new ABTDouble(duration), null,null,"Test Variance Field Rules", true);
          verifyValue(task, OFD_BASEDURATION, new ABTDouble(baseDuration), null,null,"Test Variance Field Rules", true);
          // Verify Variance fields
          verifyValue(task,OFD_START_VARIANCE,new ABTDouble(startDiff),null,null,"Test Variance Field Rules", true);
          verifyValue(task,OFD_END_VARIANCE,new ABTDouble(finishDiff),null,null,"Test Variance Field Rules", true);
          verifyValue(task,OFD_DURATION_VARIANCE,new ABTDouble(baseDuration - duration),null,null,"Test Variance Field Rules", true);
          verifyValue(task,OFD_END_VS_LATE_END,new ABTDouble(lateDiff),null,null,"Test Variance Field Rules", true);
          
      return true;          
   } // testVariance

   
   boolean testAssignment(ABTObject project, ABTObject team, ABTObject task, ABTObject assignment)
   {
      // Set the assignment curves - all value curves
      ABTCurve actCurve = 
          setCurveValue(assignment,
              OFD_ACTCURVE,
              ABTTime.valueOf("12/14/98 8:00 AM"), 
              ABTTime.valueOf("12/20/98 5:00 PM"), 
              20.0  // how many hours?
              ); 
      ABTCurve estCurve = 
          setCurveValue(assignment,
              OFD_ESTCURVE,
              ABTTime.valueOf("12/21/98 8:00 AM"), 
              ABTTime.valueOf("12/26/98 5:00 PM"), 
              40.0 // how many hours?
              ); 
      ABTCurve baseCurve = 
          setCurveValue(assignment,
              OFD_BASECURVE,
              ABTTime.valueOf("12/3/98 8:00 AM"), 
              ABTTime.valueOf("12/22/98 5:00 PM"), 
              30.0  // how many hours?
              ); 
              
       // For parent-child settings, create a child Task
       ABTObject    task2        = createTask( project, null, null, 2, true );
       // Verify pm.fr.ActCurve/EstCurve/BaseCurve.onPropertyKey rules
       CurrentLog.LogDisplay(COMMENT,"Verifying onPropertyKey rules");
       verifyAssignmentPropertyKeys(assignment,task2);
       // Verify pm.fr.AggregateCurve field rule implementations       
       verifyAggregate(assignment,actCurve,estCurve,baseCurve);
       verifyAggregate(task,actCurve,estCurve,baseCurve);
       verifyAggregate(team,actCurve,estCurve,baseCurve);
       // Only project baseCurve uses pm.fr.AggregateCurve
       verifyAggregate(project,null,null,baseCurve);
       // Verify pm.fr.AggregateTeamCurve field rule implementations    
       ABTValue resource = getValue(team,OFD_RESOURCE,true);
       if ((resource != null) && (resource instanceof ABTObject))
           verifyTeamAggregate(project,(ABTObject)resource,actCurve,estCurve,baseCurve);
           
       // Verify pm.fr.MinActualsThru and pm.fr.MaxActualsThru
       // AVP 12/23/98 - actCurve.onSet rule not yet invoked, therefore
       // Actuals Thru date not yet set automatically
       // Set explicitly here
       // Set to correct value (end of Actuals Curve)
       setValue(assignment,OFD_ACTTHRU,actCurve.getFinish(),true);
       // Verify that end actCurve.getFinish() is returned for min/max, both objects
       verifyActualsThru(task,actCurve.getFinish(),actCurve.getFinish());
       verifyActualsThru(project,actCurve.getFinish(),actCurve.getFinish());
       // Set to INCORRECT value (start of Actuals Curve)
       setValue(assignment,OFD_ACTTHRU,actCurve.getStart(),true);
       // Verify that end actCurve.getFinish() is returned for min/max, both objects
       verifyActualsThru(task,actCurve.getFinish(),actCurve.getFinish());
       verifyActualsThru(project,actCurve.getFinish(),actCurve.getFinish());
       // Set to CORRECT value (start of Est Curve)
       setValue(assignment,OFD_ACTTHRU,estCurve.getStart(),true);
       // Verify that end actCurve.getFinish() is returned for min/max, both objects
       verifyActualsThru(task,estCurve.getStart(),estCurve.getStart());
       verifyActualsThru(project,estCurve.getStart(),estCurve.getStart());
       // Set to INCORRECT value (end of Est Curve)
       setValue(assignment,OFD_ACTTHRU,estCurve.getFinish(),true);
       // Verify that end actCurve.getFinish() is returned for min/max, both objects
       verifyActualsThru(task,estCurve.getStart(),estCurve.getStart());
       verifyActualsThru(project,estCurve.getStart(),estCurve.getStart());

       // set pm.fr.PercentExpended
       ABTValue EACCurve = getValue(task,OFD_EACCURVE,true);
       if ((EACCurve != null) && (EACCurve instanceof ABTCurve))
       {
           verifyPercentExpended(task,actCurve,(ABTCurve)EACCurve);
       } else {
           verifyPercentExpended(task,actCurve,null);
       }           
       
       return true;
   } // testAssignment 

   // Testing pm.fr.Assignment.ActCurve/BaseCurve/EstCurve/onPropertyKey
   // Rules are:
   // 1. If Project TrackMode is "none" (0) OR Resource TrackMode is "none" (0)
   // updateable property key for ActCurve should return true, and should be enforced in Sanani
   // otherwise, updateable should be false
   // 2. If a Task object is a Milestone (OFD_ISMILESTONE is true)
   // editable property key for ActCurve,BaseCurve,EstCurve should return false
   // 3. If a Task object has children (OFD_PARENTTASK another task object, not project)
   // editable property key for ActCurve,BaseCurve,EstCurve should return false
   // Parameters:
   //   ABTObject assignment - the assignment object to manipulate
   //   ABTObject childTask - a task object that can be used as a child of the 
   //                         assignment's task object
   boolean verifyAssignmentPropertyKeys(ABTObject assignment, ABTObject childTask)
   {
       ABTValue
           testActCurveEditable = null,
           testEstCurveEditable = null,
           testBaseCurveEditable = null,
           testActCurveUpdateable = null,
           testEstCurveUpdateable = null,
           testBaseCurveUpdateable = null,
           testResourceValue = null,
           testTaskValue = null,
           testProjectValue = null;
       ABTObject            
           testResource = null,
           testTask = null,
           testProject = null;
       ABTValue
           testUpdateable = null,
           testEditable = null;
            
       testResourceValue = getValue(assignment,OFD_RESOURCE,true);
       testTaskValue = getValue(assignment,OFD_TASK,true);
       // If assignment object does not reference resource and task objects correctly,
       // we cannot continue testing
       if ((null == testResourceValue) || (null == testTaskValue) || (!(testResourceValue instanceof ABTObject))
           || (!(testTaskValue instanceof ABTObject)))
       {           
           CurrentLog.LogDisplay(FAIL,"assignment object does not reference task and resource object correctly");
           return false;
       }           
       testTask = (ABTObject)testTaskValue;
       testResource = (ABTObject)testResourceValue;
       testProjectValue = getValue(testTask,OFD_PROJECT,true);
       // Test for valid project object reference in task object
       if ((null == testProjectValue) || (!(testProjectValue instanceof ABTObject)))
       {           
           CurrentLog.LogDisplay(FAIL,"task object does not reference project object correctly");
           return false;
       }           
       testProject = (ABTObject)testProjectValue;
       
       // Test actCurve and actThru updateable extended property key, based on TrackMode
       // If Project TrackMode is "none" OR Resource TrackMode is "none" (currently 0),
       // updateable should be true
       // OTHERWISE, updateable should be false
       // set both to "none" (actCurve should be updateable)
       CurrentLog.LogDisplay(COMMENT,"Verifying TrackMode / Updateable rule");
       setValue(testProject,OFD_TRACKMODE,new ABTShort((short)0),true);
       setValue(testResource,OFD_TRACKMODE,new ABTShort((short)0),true);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, true);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, true);
       // set Project Track Mode to non-"none" (actCurve should still be updateable)
       setValue(testProject,OFD_TRACKMODE,new ABTShort((short)1),true);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, true);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, true);
       // set Resource Track Mode to non-"none" (actCurve should now NOT be updateable)
       setValue(testResource,OFD_TRACKMODE,new ABTShort((short)1),true);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, false);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, false);
       // set Project Track Mode back to  "none" (actCurve should now be updateable)
       setValue(testProject,OFD_TRACKMODE,new ABTShort((short)1),true);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, true);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, true);
       // set Resource Track Mode to other non-"none" (actCurve should still be updateable)
       setValue(testResource,OFD_TRACKMODE,new ABTShort((short)2),true);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, true);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, true);
       // set Project Track Mode to other non-"none" (actCurve should now NOT be updateable)
       setValue(testProject,OFD_TRACKMODE,new ABTShort((short)2),true);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, false);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, false);

       // Test Task isMilestone rule 
       // (if Milestone, actCurve, estCurve, baseCurve should NOT be editable)
       // default isMilestone should be false
       CurrentLog.LogDisplay(COMMENT,"Verifying Milestone / Editable / Updateable / Visible rule");
       verifyCurvePropertyKeys(assignment, true);
       // set isMilestone to true
       setValue(testTask,OFD_ISMILESTONE,new ABTBoolean(true), true);
       verifyCurvePropertyKeys(assignment, false);
       // set isMilestone to false
       setValue(testTask,OFD_ISMILESTONE,new ABTBoolean(false), true);
       verifyCurvePropertyKeys(assignment, true);

       // Test Task Children rule 
       // (if Task is parent, actCurve, estCurve, baseCurve should NOT be editable)
       // default Task has no children
       CurrentLog.LogDisplay(COMMENT,"Verifying Parent Task / Editable / Updateable / Visible rule");
       verifyCurvePropertyKeys(assignment, true);
       // set childTask to firstchild of this Task (is parent, curves should not be editable)
       setValue(testTask,OFD_FIRSTCHILDTASK,childTask, true);
       verifyCurvePropertyKeys(assignment, false);
       // set childTask to sibling of this Task (no longer parent, curves should be editable)
       setValue(testTask,OFD_ISMILESTONE,new ABTBoolean(false), true);
       verifyCurvePropertyKeys(assignment, true);
       
       return true; 
   } //  verifyAssignmentPropertyKeys


   // This method verifies specific (hardcoded) extended property keys
   // for various ABTCurve and ABTTime properties in assignment object
   boolean verifyCurvePropertyKeys(ABTObject assignment, boolean keyValue)
   {
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KEDITABLE, keyValue);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KEDITABLE, keyValue);
       verifyBooleanKey(assignment, OFD_ESTCURVE, PROP_KEDITABLE, keyValue);
       verifyBooleanKey(assignment, OFD_BASECURVE, PROP_KEDITABLE, keyValue);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KUPDATABLE, keyValue);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KUPDATABLE, keyValue);
       verifyBooleanKey(assignment, OFD_ESTCURVE, PROP_KUPDATABLE, keyValue);
       verifyBooleanKey(assignment, OFD_BASECURVE, PROP_KUPDATABLE, keyValue);
       verifyBooleanKey(assignment, OFD_ACTCURVE, PROP_KVISIBLE, keyValue);
       verifyBooleanKey(assignment, OFD_ACTTHRU, PROP_KVISIBLE, keyValue);
       verifyBooleanKey(assignment, OFD_ESTCURVE, PROP_KVISIBLE, keyValue);
       verifyBooleanKey(assignment, OFD_BASECURVE, PROP_KVISIBLE, keyValue);
       
       return true;
   } // verifyCurvePropertyKeys
   
   // Testing pm.fr.AggregateCurve field rule
   // Verifies that object returns correct aggregate curves,
   // (actual, base, estimate)
   // and correct calculated curve (EAC)
   // based on the actCurve, baseCurve, and estCurve parameters
   boolean verifyAggregate(ABTObject object, ABTValue actCurve, ABTValue estCurve, ABTValue baseCurve)
   {
       ABTValue // temp curves used to verify EACCurve
           testActCurve = null,
           testEstCurve = null;
       ABTCurve           
           testEACCurve = null;
           
       // Verify onGet returns correct aggregate of curves
       if (actCurve != null)
           testActCurve = verifyValue(object,OFD_ACTCURVE,actCurve,null,null,"Verify Aggregate Curves", true);
       if (estCurve != null)    
           testEstCurve = verifyValue(object,OFD_ESTCURVE,estCurve,null,null,"Verify Aggregate Curves", true);
       if (baseCurve != null)    
           verifyValue(object,OFD_BASECURVE,baseCurve,null,null,"Verify Aggregate Curves", true);
       // Verify onGet returns correct calculated curves
       if ((actCurve != null) && (estCurve != null))
       {
           testEACCurve = new ABTCurve();
           if ((testActCurve != null) && (testActCurve instanceof ABTCurve))
               testEACCurve.addCurve((ABTCurve)testActCurve);
           if ((testEstCurve != null) && (testEstCurve instanceof ABTCurve))
               testEACCurve.addCurve((ABTCurve)testEstCurve);
           verifyValue(object,OFD_EACCURVE,testEACCurve,null,null,"Verify Aggregate Curves", true);
       }            
       
       return true;
   } // verifyAggregate

   // Testing pm.fr.AggregateTeamCurve field rule
   // Verifies that object returns correct aggregate curves,
   // (actual, base, estimate)
   // and correct calculated curve (EAC)
   // based on the actCurve, baseCurve, and estCurve parameters
   boolean verifyTeamAggregate(ABTObject object, ABTObject resource, ABTValue actCurve, ABTValue estCurve, ABTValue baseCurve)
   {
       ABTValue // temp curves used to verify EACCurve
           testActCurve = null,
           testEstCurve = null;
       ABTCurve           
           testEACCurve = null;
           
       // Verify onGet returns correct aggregate of curves
       testActCurve = verifyValue(object,OFD_ACTCURVE,actCurve,OFD_RESOURCE,resource,"Verify Aggregate Curves", true);
       testEstCurve = verifyValue(object,OFD_ESTCURVE,estCurve,OFD_RESOURCE,resource,"Verify Aggregate Curves", true);
       testEACCurve = new ABTCurve();
       if ((testActCurve != null) && (testActCurve instanceof ABTCurve))
           testEACCurve.addCurve((ABTCurve)testActCurve);
       if ((testEstCurve != null) && (testEstCurve instanceof ABTCurve))
           testEACCurve.addCurve((ABTCurve)testEstCurve);
       verifyValue(object,OFD_EACCURVE,testEACCurve,OFD_RESOURCE,resource,"Verify Aggregate Curves", true);
       
       return true;
   } // verifyTeamAggregate
   
   // Testing pm.fr.MinActualsThru and pm.fr.MaxActualsThru field rule
   // Verifies that object returns correct MinActualsThru and MaxActualsThru values
   boolean verifyActualsThru(ABTObject object, ABTTime minDate, ABTTime maxDate)
   {
       verifyValue(object, OFD_MIN_ACTUALS_THRU, minDate, null, null, "Verify Actuals Thru",true);
       verifyValue(object, OFD_MAX_ACTUALS_THRU, maxDate, null, null, "Verify Actuals Thru",true);
       
       return true;
   } // verifyActualsThru
   
   // Testing pm.fr.PercentExpended field rule
   // Verifies that object returns correct calculated percentage (decimal value)
   // based on the formula: actCurve.sum() / EACCurve.sum()
   boolean verifyPercentExpended(ABTObject object, ABTCurve actCurve, ABTCurve EACCurve)
   {
       ABTDouble
           testPercentExpended = null;
           
       // Verify onGet returns correct calculated sum
       if ((actCurve == null) || (EACCurve == null))
       {
           testPercentExpended = new ABTDouble(0.0);
       } else {    
           if ((0 == actCurve.getSum()) || (0 == EACCurve.getSum()))
           {
               testPercentExpended = new ABTDouble(0.0);
           } else {                
               testPercentExpended = new ABTDouble(actCurve.getSum() / EACCurve.getSum());
           }                
       }            
       // Verify against onGet
       verifyValue(object,OFD_PCTEXPENDED,testPercentExpended,null,null,"Verify Percent Expended", true);
       
       return true;
   } // verifyPercentExpended
   
   // This method tests the "Avail" field rules
   // Availability and Allocation curves and other properties
   // from project, resource, team and task objects are verified
   boolean testAvail(ABTObject resource, ABTObject team, ABTObject project, ABTObject task)
   {
       // set global Time Stamp objects - to be used in eachAvail.onGet
       testStart = ABTTime.valueOf("11/15/98 12:00 AM");
       testFinish = ABTTime.valueOf("11/22/98 12:00 AM");
       // Test eachAvail field rules directly (NOT testing Team.Availability)
       // Team.eachAvail (pm.fr.eachAvail)
/*
       testEachAvail(resource,team,false);
       // Project.eachAvail (pm.fr.ProjectEachAvail)
       testEachAvail(resource,project,false);
       // Test pm.fr.Availability field rules - eachAvail * Resource Count
       // Try with different Counts
       setValue(resource,OFD_COUNT,new ABTDouble(1.0), true);
       // Team.Availability
       testEachAvail(resource,team,true);
       // Project.Availability (pm.fr.ProjectAvailability)
       testEachAvail(resource,project,true);
       setValue(resource,OFD_COUNT,new ABTDouble(2.5), true);
       // Team.Availability
       testEachAvail(resource,team,true);
       // Project.Availability (pm.fr.ProjectAvailability)
       testEachAvail(resource,project,true);
       setValue(resource,OFD_COUNT,new ABTDouble(100.0), true);
       // Team.Availability
       testEachAvail(resource,team,true);
       // Project.Availability (pm.fr.ProjectAvailability)
       testEachAvail(resource,project,true);
       setValue(resource,OFD_COUNT,new ABTDouble(1.0), true);
       // Team.Availability
       testEachAvail(resource,team,true);
       // Project.Availability (pm.fr.ProjectAvailability)
       testEachAvail(resource,project,true);
       // Test pm.fr.TeamAvailability - sets Team.availStart and Team.availFinish
       // Also tests pm.fr.AggregateTeamStartFinish
       CurrentLog.LogDisplay(COMMENT,"Setting start and finish avail to outside eachAvail.onGet window");
       testTeamAvailability(team,
                            ABTTime.valueOf("1/1/98 8:00 AM"), // start 
                            ABTTime.valueOf("12/31/98 5:00 PM") // finish
                            );
       // Now that availStart and availFinish are set,
       // retest pm.fr.Availability - should be unaffected
       setValue(resource,OFD_COUNT,new ABTDouble(1.0), true);
       // Team.Availability
       testEachAvail(resource,team,true);
       // Project.Availability (pm.fr.ProjectAvailability)
       testEachAvail(resource,project,true);
       // Test pm.fr.TeamAvailability - sets Team.availStart and Team.availFinish
       // to narrower window - 3 working days
       // Also tests pm.fr.AggregateTeamStartFinish
       CurrentLog.LogDisplay(COMMENT,"Setting start and finish avail to 3 days within eachAvail.onGet window");
       testTeamAvailability(team,
                            ABTTime.valueOf("11/16/98 12:00 AM"), // start 
                            ABTTime.valueOf("11/19/98 12:00 AM") // finish
                            );
       // Now that availStart and availFinish are set,
       // retest pm.fr.Availability - should be unaffected
       setValue(resource,OFD_COUNT,new ABTDouble(1.0), true);
       // Team.Availability
       testEachAvail(resource,team,true);
       // Project.Availability (pm.fr.ProjectAvailability)
       testEachAvail(resource,project,true);
       // Test pm.fr.UnusedAvailability: (Team.TeamAvailability - Team.EACCurve)
       // Also test pm.fr.ProjectUnusedAvailability with OFD_RESOURCE parameter
       // (Project.Availability - Project.EACCurve)
       CurrentLog.LogDisplay(COMMENT,"Verifying unused availability");
       verifyUnusedAvailability(team,null);
       verifyUnusedAvailability(project,resource);
       // Test pm.fr.VariableAvail - boolean 
       CurrentLog.LogDisplay(COMMENT,"Testing VariableAvail");
       testVariableAvail(team);
       // Test abt.fr.ResourceAvailCurve 
       // also test impact upon eachAvail.onGet and Project Availability
       CurrentLog.LogDisplay(COMMENT,"Testing ResourceAvailCurve");
       testRateCurve(resource,OFD_AVAILCURVE,resource,team,project);
*/       
       // Test pm.fr.TeamAllocCurve
       // also test impact upon eachAvail.onGet and Project Availability
       CurrentLog.LogDisplay(COMMENT,"Testing TeamAllocCurve");
       testRateCurve(team,OFD_ALLOCCURVE,resource,team,project);
       
       return true;
   } // testAvail 

   // First overriden method
   // Calls second overriden method assuming 100% availability across eachAvail.onGet
   // (default allocCurve and availCurve)
   boolean testEachAvail(ABTObject resource, ABTObject team, boolean testAvail)
   {
       boolean
           eachAvailReturn = false;
           
       eachAvailReturn =
           testEachAvail(
                resource,
                team,
                1.0,
                testAvail
                );
                
        return eachAvailReturn;                
   } // testEachAvail(1)

   // Second overriden method
   // This method tests pm.fr.eachAvail field rules 
   // directly on via Team.Availability 
   // for all resource Availability Units (Hours, Days, Cost, Quantity)
   // calling local method verifyEachAvail
   // Parameters:
   // ABTObject resource - resource object to be manipulated
   // ABTObject team - team object to be manipulated
   // double availPct - percentage as decimal
   // boolean testAvail - should we test Team.Availability (true),
   //                     or merely test eachAvail.onGet directly (false)
   boolean testEachAvail(ABTObject resource, ABTObject team, double availPct, boolean testAvail)
   {

      // Test by setting Resource Avail Unit, and passing same Avail Unit as argument 
      // to eachAvail.onGet
      verifyEachAvail(
                resource, // resource object
                team, // team object
                kHours, // constant for Hours Avail Unit
                kHours, // constant for Hours Avail Parameter
                availPct, // default 100% if alloc and avail curves not set
                testAvail // are we testing team.availability?
                ); 
      verifyEachAvail(
                resource,
                team,
                kDays,
                kDays,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      // Test Cost with different Rates
      setValue(
                resource,
                OFD_RATE,
                new ABTDouble(1.0),
                true
                );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      setValue(
                resource,
                OFD_RATE,
                new ABTDouble(2.5),
                true
                );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      setValue(
                resource,
                OFD_RATE,
                new ABTDouble(0.0),
                true
              );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      setValue(resource,
               OFD_RATE,
               new ABTDouble(1.0),
               true
               );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kQuantity,
                kQuantity,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kHours,
                kHours,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      // Test by setting Resource Avail Unit, and passing DIFFERENT Avail Unit
      // as argument to eachAvail.onGet
      verifyEachAvail(
                resource,
                team,
                kDays,
                kHours,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kDays,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kDays,
                kQuantity,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kHours,
                kDays,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kHours,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kHours,
                kQuantity,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kHours,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kDays,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kCost,
                kQuantity,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kQuantity,
                kHours,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kQuantity,
                kDays,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      verifyEachAvail(
                resource,
                team,
                kQuantity,
                kCost,
                availPct, // default 100% if alloc and avail curves not set
                testAvail
                );
      
      return true;
   } // testEachAvail (2)

   // First overridden method
   // When default 100% alloc and avail
   // This method calls second verifyEachAvail method,
   // assuming alloc and avail curves which impact eachAvail.onGet,
   // are default 1.0 (100%)
   boolean verifyEachAvail(ABTObject resource, ABTObject team, short availUnit, short availParameter, boolean testAvail)
   {
       boolean
          eachAvailReturn = false;
          
       eachAvailReturn = 
                verifyEachAvail
                    (resource,
                     team,
                     availUnit,
                     availParameter,
                     1.0, // total percentage availability (alloc * avail)
                     testAvail
                     );
       
       return eachAvailReturn;
   } // verifyEachAvail(1)
   
   // This method is used to test pm.fr.eachAvail OR pm.fr.Availability, 
   // based on param testAvail
   // pm.fr.Availability is essentially eachAvail * (resource.OFD_COUNT)
   // This method assumes default Resource Calendar of 8-hour workdays, 5-day workweek
   // This method assume allocCurve and availCurve (team or project) are
   // larger window than eachAvail params - in other words, level percentage through 
   // entire availability window
   // This method assume that Team.startAvail and Team.finishAvail, if set, are both
   // on workdays
   // For 1 resource Availability Unit, run the following methodology:
   // 1. Set the team's resource to the Availability Unit specified by availUnit
   // 2. Test team.eachAvail.onGet with parameters: hardcoded start and finish Availability dates, 
   //    and availParameter - via team.eachAvail.onGet, or via team.Availability.onGet
   // 3. Test various getSum start and finish dates and verify results
   // eachAvail.onGet Rules (when Availability Unit and Availability Parameter differ):
   //    Days parameter will return value if Avail Unit is Days or Hours, otherwise null
   //    Hours parameter will return value if Avail Unit is Days or Hours, otherwise null
   //    Cost parametr will return value unconditionally, * Rate
   //    Quantity parameter will return value if Avail Unit is Quantity, otherwise null
   // Parameters:
   //     ABTObject resource - resource object to be set for Avail Unit
   //     ABTObject team - team object to be used for eachAvail.onGet
   //     short availUnit - constant representing Availability Unit for resource OFD_AVAILUNIT
   //     short availParameter - constant representing Availability Unit to be passed 
   //                            in eachAvail.onGet parameters
   //     double availPct - percentage of availability as a decimal 
   //     boolean testAvail - if true, we are testing pm.fr.Availability
   //                         if false, we are testing pm.fr.eachAvail directly
   // TODO AVP 12/31/98:  Although start and finish date parameters for eachAvail.onGet 
   //       are now set globally, this method still assumes they will equal 5 working Days
   //       (Sunday midnight - Sunday Midnight, base Calendar)
   //       Must change to actually calculate difference in workdays between global start and finish
   //       Do not want to do that until curve/calendar problems are cleaned up
   // Also, team.AvailStart and team.AvailFinish, if set, MUST start and end on workdays
   // Currently, allocCurve and availCurve must be larger window than eachAvail params
   //       Change to take into account smaller alloc or avail window
   boolean verifyEachAvail(ABTObject resource, ABTObject team, short availUnit, short availParameter, double availPct, boolean testAvail)
   {
      double
          testSum = 0.0,
          workDay = 0.0,
          resourceRate = 1.0, // default Resource Rate
          resourceCount = 1.0, // default Resource Count
          hoursPerDay = 8.0; // currently default, could be passed as parameter or based on calendar
      String
          unitDisplay = null,
          paramDisplay = null;
      ABTValue
          resourceRateValue = null,
          resourceCountValue = null,
          teamAvailStartValue = null,
          teamAvailFinishValue = null;
      double // calculate availability window of resource on a team, based on availstart and availfinish
          teamAvailStartDays = 0.0,
          teamAvailFinishDays = 99999.0 * ABTTime.SecondsPerDay, // Set to maximum, so will be outside start/finish window
          teamAvailDays = 99999.0 * ABTTime.SecondsPerDay; 
      
      // Get the Resource Rate for Cost values
      resourceRateValue = getValue(resource,OFD_RATE,true); 
      if (resourceRateValue instanceof ABTDouble)
          resourceRate = resourceRateValue.doubleValue();
          
      // Determine conversion based on eachAvail.onGet Availability parameter 
      switch (availParameter)
      {
          case kHours:
              workDay = hoursPerDay; // Hours
              paramDisplay = "Hours";
              break;
          case kDays:
              workDay = 1.0; // Days
              paramDisplay = "Days";
              break;
          case kQuantity:
              workDay = hoursPerDay * 3600.0; // Seconds
              paramDisplay = "Quantity";
              break;
          case kCost:
              workDay = hoursPerDay * 3600.0 * resourceRate; // Seconds
              paramDisplay = "Cost";
              break;
          default:
              workDay = hoursPerDay; // Hours
              paramDisplay = "Hours";
              break;
      } // end switch on availParamater
      // Display value for Resource Availability Unit 
      switch (availUnit)
      {
          case kHours:
              unitDisplay = "Hours";
              break;
          case kDays:
              unitDisplay = "Days";
              break;
          case kQuantity:
              unitDisplay = "Quantity";
              break;
          case kCost:
              unitDisplay = "Cost";
              break;
          default:
              unitDisplay = "Hours";
              break;
      } // end switch on availUnit              

      CurrentLog.LogDisplay(COMMENT,"Testing eachAvail with Availability Unit of " + unitDisplay + " and Avail Parameter of " + paramDisplay + " and Resource Rate of " + resourceRate);
      
      // Parameter testAvail determines whether to test Team.Availability
      // If true, we are multiplying returned curve value by Resource.OFD_COUNT
      // Therefore, all getSum values should be multiplied by count
      if (true == testAvail)
      {
          resourceCountValue = getValue(resource,OFD_COUNT,true);
          if (resourceCountValue instanceof ABTDouble)
              resourceCount = resourceCountValue.doubleValue();
          workDay *= resourceCount;
      }          

      // multiply by availability percent (hardcoded now, instead of using alloccurve and
      // availcurve getrate directly)
      workDay *= availPct;
      
      // get Resource Availability window
      teamAvailStartValue = getValue(team,OFD_AVAILSTART,OFD_RESOURCE,resource,true);
      teamAvailFinishValue = getValue(team,OFD_AVAILFINISH,OFD_RESOURCE,resource,true);
      // teamAvailStartDays should equal later of: Team.AvailStart and global testStart
      if ((teamAvailStartValue != null) && (teamAvailStartValue instanceof ABTTime))
      {
          teamAvailStartDays = Math.max(((ABTTime)teamAvailStartValue).getJulian(),testStart.getJulian());
      }        
      if ((teamAvailFinishValue != null) && (teamAvailFinishValue instanceof ABTTime))
      {
          teamAvailFinishDays = Math.min(((ABTTime)teamAvailFinishValue).getJulian(),testFinish.getJulian());
      }  
      // Number of workdays that team member is available
      // WITHIN start/finish window
      teamAvailDays = teamAvailFinishDays - teamAvailStartDays;
          
      // Set Resource Unit as Specified
      setValue(resource, OFD_UNIT, new ABTShort(availUnit), true);
      verifyValue(resource, OFD_UNIT, new ABTShort(availUnit), null, null, "Testing eachAvail", true);
      // Start/Finish - set as global objects
      ABTValue eachAvail = getValue(
                    team, // team object
                    (testAvail) ? OFD_AVAILABILITY : OFD_EACH_AVAIL,  // property to test
                    testStart, // use global object here so it can be set outside of the method
                    testFinish, // use global object here so it can be set outside of the method
                    availParameter, // Avail Unit parameter
                    resource, // Resource parameter
                    true // yes, this should work!
                    );
      // If null is returned, test for combos that SHOULD return null:
      // If Avail Unit is Quantity, and Avail Parameter is NOT Quantity, or vice versa
      // If Avail Parameter is Days or Hours, and Avail Unit is NOT Days or Hours
      // If Avail Unit is Days or Hours, and Avail Parameter is NOT Days or Hours
      if (null == eachAvail)
      {
          if (
              (((availUnit == kQuantity) || (availParameter == kQuantity)) && (availUnit != availParameter)) ||
              ((availUnit != kHours) && (availUnit != kDays) && ((availParameter == kHours) || (availParameter == kDays))) ||
              ((availParameter != kHours) && (availParameter != kDays) && ((availUnit == kHours) || (availUnit == kDays)))
             ) 
          {
              CurrentLog.LogWrite(PASS,"eachAvail returned null correctly");
              return true;
          } else {    
              CurrentLog.LogDisplay(FAIL,"eachAvail returned null");
              return false;
          }          
      } // end if eachAvail returned null           
      
      // if error encountered, or wrong object type, we can't test this further.
      if (!(eachAvail instanceof ABTCurve))
      {
          CurrentLog.LogDisplay(FAIL,"eachAvail did not return ABTCurve");
          return false;
      }           
      
      // getSum with no arguments should default to entire specified eachAvail curve - 5 working days
      verifySum((ABTCurve)eachAvail,null,null,Math.min(5.0,teamAvailDays) * workDay);
      // Same arguments as eachAvail parameters - 5 working days 
      verifySum((ABTCurve)eachAvail,testStart,testFinish,Math.min(5.0,teamAvailDays) * workDay);
      // Start and Finish within eachAvail parameters - 1 working day 
      // Account for team.AvailStart - team.AvailFinish
      testSum = calculateAvailWindow(testStart.add(ABTTime.SecondsPerDay * 1).getJulian(),
                                     testStart.add(ABTTime.SecondsPerDay * 2).getJulian(),
                                     teamAvailStartDays,
                                     teamAvailFinishDays
                                     );
      verifySum((ABTCurve)eachAvail,
                testStart.add(ABTTime.SecondsPerDay * 1),
                testStart.add(ABTTime.SecondsPerDay * 2),
                testSum * workDay 
                );
      // Start and Finish within eachAvail parameters - using AM/PM - 1 working day 
      // Account for team.AvailStart - team.AvailFinish
      testSum = calculateAvailWindow(testStart.add(ABTTime.SecondsPerDay + 8 * 3600).getJulian(), // 8:00 AM
                                     testStart.add(ABTTime.SecondsPerDay + 17 * 3600).getJulian(), // 5:00 PM
                                     teamAvailStartDays,
                                     teamAvailFinishDays
                                     );
      // KLUGE:  If greater than or equal to 9.0 hours, assume normal working day                               
      if (testSum >= .375)                               
          testSum = 1.0;
      verifySum((ABTCurve)eachAvail,
               testStart.add(ABTTime.SecondsPerDay + 8 * 3600), // 8:00 AM
               testStart.add(ABTTime.SecondsPerDay + 17 * 3600), // 5:00 PM
               testSum * workDay
               );
      // Start and Finish within eachAvail parameters - 2 working days 
      // Account for Team.availStart and Team.availFinish
      testSum = calculateAvailWindow(testStart.add(ABTTime.SecondsPerDay * 2).getJulian(),
                                     testStart.add(ABTTime.SecondsPerDay * 3).getJulian(),
                                     teamAvailStartDays,
                                     teamAvailFinishDays
                                     );
      verifySum((ABTCurve)eachAvail,
                testStart.add(ABTTime.SecondsPerDay * 2),
                testStart.add(ABTTime.SecondsPerDay * 3),
                testSum * workDay
                );
          
/* AVP 12/30/98 - ILLEGAL TO TRY GETSUM WITH PARAMATERS OUTSIDE OF ORIGINAL ONGET PARAMETERS
      // Start within eachAvail parameters, Finish AFTER - 2 working days 
      testSum = ((ABTCurve)eachAvail).getSum(
                    ABTTime.valueOf("11/20/98 12:00 AM"),
                    ABTTime.valueOf("11/24/98 12:00 AM")
                    );
      if (testSum == 2.0 * workDay)
          CurrentLog.LogWrite(PASS,"getSum returns 2 working days");
      else          
          CurrentLog.LogDisplay(FAIL,"getSum expected to return 2 working days - instead returns " + testSum);
      // Start BEFORE eachAvail parameters, Finish within - 2 working days 
      testSum = ((ABTCurve)eachAvail).getSum(
                ABTTime.valueOf("11/12/98 12:00 AM"),
                ABTTime.valueOf("11/16/98 12:00 AM")
                );
      if (testSum == 2.0 * workDay)
          CurrentLog.LogWrite(PASS,"getSum returns 2 working days");
      else          
          CurrentLog.LogDisplay(FAIL,"getSum expected to return 2 working days - instead returns " + testSum);
      // Start and Finish BEFORE eachAvail parameters - 2 working days 
      testSum = ((ABTCurve)eachAvail).getSum(
                ABTTime.valueOf("11/10/98 12:00 AM"),
                ABTTime.valueOf("11/16/98 12:00 AM")
                );
      if (testSum == 2.0 * workDay)
          CurrentLog.LogWrite(PASS,"getSum returns 2 working days");
      else          
          CurrentLog.LogDisplay(FAIL,"getSum expected to return 2 working days - instead returns " + testSum);
      // Start and Finish AFTER eachAvail parameters - 2 working days 
      testSum = ((ABTCurve)eachAvail).getSum(
                ABTTime.valueOf("11/24/98 12:00 AM"),
                ABTTime.valueOf("11/26/98 12:00 AM")
                );
      if (testSum == 2.0 * workDay)
          CurrentLog.LogWrite(PASS,"getSum returns 2 working days");
      else          
          CurrentLog.LogDisplay(FAIL,"getSum expected to return 2 working days - instead returns " + testSum);
*/
      return true;
   } // verifyEachAvail 

   // This method verifies pm.fr.TeamAvailability field rule
   // currently used by Team.AvailStart and Team.AvailFinish
   // This method also verifies pm.fr.AggregateTeamStartFinish.onGet
   // currently used by Project.AvailStart and Project.AvailFinish
   boolean testTeamAvailability(ABTObject team, ABTTime testStart, ABTTime testFinish)
   {
       ABTValue
           availStart = null,
           availFinish = null,
           testProjectValue = null,
           testResourceValue = null;
       ABTObject
           testResource = null,
           testProject = null;
    
       // get project and resource references
       testProjectValue = getValue(team,OFD_PROJECT,true);
       if ((testProjectValue == null) || (!(testProjectValue instanceof ABTObject)))
       {
           CurrentLog.LogDisplay(FAIL,"team object does not contain project reference - testTeamAvailability");     
           return false;
       } 
       testProject = (ABTObject)testProjectValue;
       testResourceValue = getValue(team,OFD_RESOURCE,true);
       if ((testResourceValue == null) || (!(testResourceValue instanceof ABTObject)))
       {
           CurrentLog.LogDisplay(FAIL,"team object does not contain resource reference - testTeamAvailability");     
           return false;
       } 
       testResource = (ABTObject)testResourceValue;
       
       // set and verify dummy start
       setValue(team,OFD_AVAILSTART,ABTTime.valueOf("1/1/98 8:00 AM"),true);
       verifyValue(
                    team,
                    OFD_AVAILSTART,
                    ABTTime.valueOf("1/1/98 8:00 AM"),
                    null,
                    null,
                    "Testing Team Start/Finish",
                    true);
       // verify at Project level as well             
       verifyValue(
                    testProject,
                    OFD_AVAILSTART,
                    ABTTime.valueOf("1/1/98 8:00 AM"),
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",
                    true);
       // set and verify dummy finish
       setValue(team,OFD_AVAILFINISH,ABTTime.valueOf("12/31/99 5:00 PM"),true);
       verifyValue(
                    team,
                    OFD_AVAILFINISH,
                    ABTTime.valueOf("12/31/99 5:00 PM"),
                    null,
                    null,
                    "Testing Team Start/Finish",
                    true
                    );
       verifyValue(
                    testProject,
                    OFD_AVAILFINISH,
                    ABTTime.valueOf("12/31/99 5:00 PM"),
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",
                    true
                    );
       // set finish before start - should not be allowed?
       setValue(team,OFD_AVAILFINISH,ABTTime.valueOf("1/1/97 5:00 PM"),true);
       verifyValue(
                    team,
                    OFD_AVAILFINISH,
                    ABTTime.valueOf("1/1/98 8:00 AM"),
                    null,
                    null,
                    "Testing Team Start/Finish",
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILFINISH,
                    ABTTime.valueOf("1/1/98 8:00 AM"),
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",
                    true);
       // set and verify finish
       setValue(team,OFD_AVAILFINISH,ABTTime.valueOf("12/31/00 5:00 PM"),true);
       verifyValue(
                    team,
                    OFD_AVAILFINISH,
                    ABTTime.valueOf("12/31/00 5:00 PM"),
                    null,
                    null,
                    "Testing Team Start/Finish",                    
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILFINISH,
                    ABTTime.valueOf("12/31/00 5:00 PM"),
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",                    
                    true);
       // set start after finish - should not be allowed?                    
       setValue(team,OFD_AVAILSTART,ABTTime.valueOf("12/31/01 8:00 AM"),true);
       verifyValue(
                    team,
                    OFD_AVAILSTART,
                    ABTTime.valueOf("12/31/00 5:00 PM"),
                    null,
                    null,
                    "Testing Team Start/Finish",                    
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILSTART,
                    ABTTime.valueOf("12/31/00 5:00 PM"),
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",                    
                    true);
                    
       // set both to null
       setValue(team,OFD_AVAILSTART,null,true);
       verifyValue(
                    team,
                    OFD_AVAILSTART,
                    null,
                    null,
                    null,
                    "Testing Team Start/Finish",                    
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILSTART,
                    null,
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",                    
                    true);
       setValue(team,OFD_AVAILFINISH,null,true);
       verifyValue(
                    team,
                    OFD_AVAILFINISH,
                    null,
                    null,
                    null,
                    "Testing Team Start/Finish",                    
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILFINISH,
                    null,
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",                    
                    true);
       // set both to specified parameters
       setValue(team,OFD_AVAILSTART,testStart,true);
       verifyValue(
                    team,
                    OFD_AVAILSTART,
                    testStart,
                    null,
                    null,
                    "Testing Team Start/Finish",                    
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILSTART,
                    testStart,
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",                    
                    true);
       setValue(team,OFD_AVAILFINISH,testFinish,true);
       verifyValue(
                    team,
                    OFD_AVAILFINISH,
                    testFinish,
                    null,
                    null,
                    "Testing Team Start/Finish",                    
                    true);
       verifyValue(
                    testProject,
                    OFD_AVAILFINISH,
                    testFinish,
                    OFD_RESOURCE,
                    testResource,
                    "Testing Team Start/Finish",                    
                    true);

       return true;

   } // testTeamAvailability

   // This method calculate Availability Window based on the following parameters:
   // double startWindow - number of julian days (decimal) of first second of window
   // double finishWindow - number of julian days (decimal) of last second of window
   // double availStart - number of julian days (decimal) of first second that resource is available 
   // double availFinish - number of julian days (decimal) of last second that resource is available 
   // Returns:
   // double testSum calculated window in number of julian days
   double calculateAvailWindow(double startWindow, double finishWindow, double availStart, double availFinish)
   {
       double
           testSum = 0.0;
           
      // If start and finish params are NOT both later or earlier than availStart/availFinish
      // then we can calculate window
      if ((finishWindow > availStart) &&
          (startWindow < availFinish))
      {
          testSum = Math.min(finishWindow,availFinish) -
                    Math.max(startWindow,availStart);
      }                    

      return testSum;
   } // calculateAvailWindow
   
   // This method call getSum for the ABTCurve parameter, and verifies the returned value
   // Parameters:
   //    ABTCurve curveValue - curve object (already created) on which to call getSum
   //    ABTTime startParam -  Time Stamp for getSum start date argument
   //    ABTTime finishParam -  Time Stamp for getSum  finish date argument
   //    double sumValue - expected return value from getSum
   // Returns:
   //    true if getSum return value equals sumValue
   //    false if getSum return value NOT equal sumValue
   boolean verifySum(ABTCurve curveValue, ABTTime startParam, ABTTime finishParam, double sumValue)
   {
      double
          testSum = 0.0;
      
      if ((startParam == null) && (finishParam == null))
      {
          testSum = curveValue.getSum();
      } else {                       
          testSum = curveValue.getSum(
                        startParam,
                        finishParam
                        );
      }                        
      if (testSum == sumValue)
      {
          CurrentLog.LogWrite(PASS,
                              "getSum with parameters " + ((startParam != null) ? startParam.toString() : "null ") + 
                              " - " + ((finishParam != null) ? finishParam.toString() : "null ") + " returns " + 
                              sumValue);
      } else {         
          CurrentLog.LogDisplay(FAIL,
                              "getSum with parameters " + ((startParam != null) ? startParam.toString() : "null ") + 
                              " - " + ((finishParam != null) ? finishParam.toString() : "null ") + " should return " + 
                              sumValue + " - instead returns " + testSum);
          return false;                    
      }                              
    
       return true;
   } // verifySum 
   
   // This method verifies pm.fr.UnusedAvailability field rule
   // currently used by Team.UnusedAvailability
   // Can also test pm.fr.ProjectUnusedAvailability, which when passed correct OFD_RESOURCE
   // parameter during onGet, should return value equal to ProjectAvailability - Project.EACCurve
   // Formula should be:  UnusedAvailability = TeamAvailability - Team.EACCurve
   // TeamAvailability formula is:  eachAvail * Resource.Count
   // EACCurve formula is:  actCurve + estCurve
   // So, formula is:  
   // UnusedAvailability = (Team.eachAvail * Resource.Count) - (Team.ActCurve + Team.EstCurve)
   // Parameters:
   // ABTObject Team
   boolean verifyUnusedAvailability(ABTObject team, ABTObject resource)
   {
       ABTValue
           teamAvailabilityValue = null,
           EACCurveValue = null;
       ABTCurve
           teamAvailability = null,
           EACCurve = null,
           testUnusedAvailability = null;

       // get Team/Project Availability curve    
       teamAvailabilityValue = getValue(team,OFD_AVAILABILITY,OFD_RESOURCE,resource,true);
       if ((teamAvailabilityValue != null) && ((teamAvailabilityValue instanceof ABTCurve)))
           teamAvailability = (ABTCurve)teamAvailabilityValue;           
           
       // get Team/Project EACCurve
       EACCurveValue = getValue(team,OFD_EACCURVE,OFD_RESOURCE,resource,true);
       if ((EACCurveValue != null) && ((EACCurveValue instanceof ABTCurve)))
           EACCurve = (ABTCurve)EACCurveValue;           
           
       // Verify onGet returns correct calculated curve
       testUnusedAvailability = new ABTCurve();
       if (teamAvailability != null)
           testUnusedAvailability = (ABTCurve)(Object)teamAvailability.clone();
       if (EACCurve != null)
           testUnusedAvailability.subCurve(EACCurve);
       verifyValue(team,
                   OFD_UNUSED_AVAILABILITY,
                   testUnusedAvailability,
                   OFD_RESOURCE,
                   resource,
                   "Verify Unused Availability", 
                   true
                   );

       return true;
   } // verifyUnusedAvailability

   // This method tests the pm.fr.VariableAvail field rule under different conditions
   // by calling local method verifyVariableAvail
   // Parameters:
   //     ABTObject team - reference to previously created Team object
   boolean testVariableAvail(ABTObject team)
   {
       ABTValue
           testResourceValue = null,
           testBaseCalendarValue = null;
       ABTObject
           testResource = null;
       ABTCalendar    
           testNewCalendar = null,
           testBaseCalendar = null;
	   ABTShiftList specialHolidays[] = {
	       ABTShiftList.HOLIDAY   // SUNDAY
       };
           
       // get Resource object reference
       testResourceValue = getValue(team,OFD_RESOURCE,true);
       // If team object does not correctly reference resource object, we cannot continue testing
       if ((null == testResourceValue) || (!(testResourceValue instanceof ABTObject)))
       {           
           CurrentLog.LogDisplay(FAIL,"team object does not reference resource object correctly");
           return false;
       }           
       testResource = (ABTObject)testResourceValue;
       
       // get Resource Base Calendar
       testBaseCalendarValue = getValue(testResource,OFD_BASECALENDAR,true);
       // If resource object does not correctly reference base calendar object, we cannot continue testing
       if ((null == testBaseCalendarValue) || (!(testBaseCalendarValue instanceof ABTObject)))
       {           
           CurrentLog.LogDisplay(FAIL,"resource object does not reference base calendar object correctly");
           return false;
       }           
       testBaseCalendar = (ABTCalendar)getValue((ABTObject)testBaseCalendarValue,OFD_VALUE,true);

       // Set Team Calendar equal to Resource Base Calendar
       setValue(testResource,OFD_CALENDAR,testBaseCalendar,true);
//       verifyValue(testResource,OFD_CALENDAR,testBaseCalendar,null,null,"Testing Variable Avail",true);
       // VariableAvail should return false
       verifyVariableAvail(team);
       // Set Team Calendar equal to new Calendar (same as Base Calendar)
       testNewCalendar = new ABTCalendar();
       setValue(testResource,OFD_CALENDAR,testNewCalendar,true);
//       verifyValue(testResource,OFD_CALENDAR,testNewCalendar,null,null,"Testing Variable Avail",true);
       // VariableAvail should return false
       verifyVariableAvail(team);
       // Set Team Calendar equal to new Calendar (different from Base Calendar) 
       // Give this Resource 1 year sabbatical, Tuesdays only
       testNewCalendar.setShifts(3,ABTShiftList.HOLIDAY);
       setValue(testResource,OFD_CALENDAR,testNewCalendar,true);
//       verifyValue(testResource,OFD_CALENDAR,testNewCalendar,null,null,"Testing Variable Avail",true);
       // VariableAvail should return true
       verifyVariableAvail(team);
       
       return true;
   } // testVariableAvail

   // This method verifies pm.fr.VariableAvail field rule
   // currently used by Team.VariableAvail
   // Returns ABTBoolean(true) if:
   // team's calendar is not equal to resource's base calendar
   // OR
   // Team.AllocCurve is not default
   // Otherwise, returns ABTBoolean(false)
   // Parameters:
   // ABTObject Team
   boolean verifyVariableAvail(ABTObject team)
   {
       ABTValue
           testResourceValue = null,
           testBaseCalendarValue = null,
           testTeamCalendarValue = null,
           testTeamAllocCurveValue = null;
       ABTObject
           testResource = null;
       ABTCalendar    
           testTeamCalendar = null,
           testBaseCalendar = null;
       ABTCurve           
           testTeamAllocCurve = null;
       boolean
           testVariableAvail = false;
           
       // get Resource object reference
       testResourceValue = getValue(team,OFD_RESOURCE,true);
       // If team object does not correctly reference resource object, we cannot continue testing
       if ((null == testResourceValue) || (!(testResourceValue instanceof ABTObject)))
       {           
           CurrentLog.LogDisplay(FAIL,"team object does not reference resource object correctly");
           return false;
       }           
       testResource = (ABTObject)testResourceValue;
       
       // get Resource Base Calendar
       testBaseCalendarValue = getValue(testResource,OFD_BASECALENDAR,true);
       // If resource object does not correctly reference base calendar object, we cannot continue testing
       if ((null == testBaseCalendarValue) || (!(testBaseCalendarValue instanceof ABTObject)))
       {           
           CurrentLog.LogDisplay(FAIL,"resource object does not reference base calendar object correctly");
           return false;
       }           
       testBaseCalendar = (ABTCalendar)getValue((ABTObject)testBaseCalendarValue,OFD_VALUE,true);

       // get Team Calendar
       testTeamCalendarValue = getValue(team,OFD_CALENDAR,true);
       // If team object does not correctly reference calendar object, we cannot continue testing
       if ((null == testTeamCalendarValue) || (!(testTeamCalendarValue instanceof ABTCalendar)))
       {           
           CurrentLog.LogDisplay(FAIL,"team object does not reference calendar object correctly");
           return false;
       }           
       testTeamCalendar = (ABTCalendar)testTeamCalendarValue;

       // get Team AllocCurve
       testTeamAllocCurveValue = getValue(team,OFD_ALLOCCURVE,true);
       if ((null != testTeamAllocCurveValue) && (testTeamAllocCurveValue instanceof ABTCurve))
           testTeamAllocCurve = (ABTCurve)testTeamAllocCurveValue;

       // Verify onGet returns correct calculated boolean
       testVariableAvail = (!testTeamCalendar.equals(testBaseCalendar));
       verifyValue(team,OFD_VARIABLE_AVAIL,new ABTBoolean(testVariableAvail),null,null,"Verify Variable Avail", true);

       return true;
   } // verifyVariableAvail
   
   // This method tests Rate Curves that impact eachAvail.onGet:
   // abt.fr.ResourceAvailCurve  (resource.AvailCurve)
   // pm.fr.TeamAllocCurve (team.AllocCurve)
   // and impact upon pm.fr.eachAvail and pm.fr.ProjectAvailability
   // Basically, the testProperty can be to any valid Rate Curve 
   // and should be retrieved by onGet
   // Parameters team and project are passed for eachAvail and Project Availability verification
   boolean testRateCurve(ABTObject testObject, String testProperty, ABTObject resource, ABTObject team, ABTObject project)
   {
      ABTValue
          resourceRateValue = null;
      ABTCurve 
          availCurve = null;
      double
          resourceRate = 0.0;

      // test #1 - verify curve with starting (default) rate and segment rate
      // both equal to 100%
      CurrentLog.LogDisplay(COMMENT,"Testing 100% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    1.0, // starting (default) rate
                    1.0 // rate for setSegment
                    );
      // verify impact upon team.eachAvail.onGet and project.availability.onGet              
      testEachAvail(resource,team,1.0, true);              
      testEachAvail(resource,project,1.0, true);              
                    
      // test #2 - verify curve with starting (default) rate and segment rate
      // both equal to 50%
      CurrentLog.LogDisplay(COMMENT,"Testing 50% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    .5, // starting (default) rate
                    .5 // rate for setSegment
                    );
      testEachAvail(resource,team,.5, true);              
      testEachAvail(resource,project,.5, true);              
      
      // test #3 - verify curve with starting (default) rate of 100% 
      // and segment rate of 50%
      CurrentLog.LogDisplay(COMMENT,"Testing 100% default / 50% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    1.0, // starting (default) rate
                    .5 // rate for setSegment
                    );
      testEachAvail(resource,team,.5, true);              
      testEachAvail(resource,project,.5, true);              
        
      // test #4 - verify curve with starting (default) rate and segment rate
      // both equal to 150%
      CurrentLog.LogDisplay(COMMENT,"Testing 150% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    1.5, // starting (default) rate
                    1.5 // rate for setSegment
                    );
      testEachAvail(resource,team,1.5, true);              
      testEachAvail(resource,project,1.5, true);              

      // test #5 - verify curve with starting (default) rate of 100% 
      // and segment rate of 0%
      CurrentLog.LogDisplay(COMMENT,"Testing 100% default / 0% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    1.0, // starting (default) rate
                    .0 // rate for setSegment
                    );
      testEachAvail(resource,team,.0, true);              
      testEachAvail(resource,project,.0, true);              
                    
      // test #6 - verify curve with starting (default) rate of 200% 
      // and segment rate of 100%
      CurrentLog.LogDisplay(COMMENT,"Testing 200% default / 100% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    2.0, // starting (default) rate
                    1.0 // rate for setSegment
                    );
      testEachAvail(resource,team,1.0, true);              
      testEachAvail(resource,project,1.0, true);              
      
      // test #7 - verify curve with starting (default) rate of 50% 
      // and segment rate of 125.5%
      CurrentLog.LogDisplay(COMMENT,"Testing 125.5% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    1.255, // starting (default) rate
                    1.255 // rate for setSegment
                    );
      testEachAvail(resource,team,1.255, true);              
      testEachAvail(resource,project,1.255, true);              
      
      // test #8 - verify curve with starting (default) rate of 50% 
      // and segment rate of 100%
      CurrentLog.LogDisplay(COMMENT,"Testing 50% default / 100% Allocation/Availability");
      verifyRateCurve(
                    testObject,                    
                    testProperty,
                    ABTTime.valueOf("1/1/97 8:00 AM"), // available 3 full years
                    ABTTime.valueOf("12/31/99 5:00 PM"), 
                    .50, // starting (default) rate
                    1.0 // rate for setSegment
                    );
      testEachAvail(resource,team,1.0, true);              
      testEachAvail(resource,project,1.0, true);              

                    
      // set resource availcurve back to default - 100%, no segments
      CurrentLog.LogDisplay(COMMENT,"Testing default Allocation/Availability");
      setValue(testObject,
               testProperty,
               new ABTCurve(ABTCurve.RATECURVE,1.0),
               true
               );
      testEachAvail(resource,team,true);              
      testEachAvail(resource,project,true);              
      
      return true;  
   } // testRateCurve

   // This method sets and verifies any Rate Curve 
   // This method calls Lib.setCurveValue which:
   // creates the actual ABTCurve object of type RATECURVE, 
   // sets it to the resource object's testProperty property
   // Then calls Lib.verifyValue which:
   // verifies the curve value in the property via onGet
   // Parameters:
   //       ABTObject testObject - object to set
   //       String testProperty - property name to be set
   //       ABTTime startDate - starting date for setSegment
   //       ABTTime endtDate - ending date for setSegment
   //       double startingRate - default rate when creating ABTCurve
   //       double segmentRate - rate used in setSegment
   boolean verifyRateCurve(ABTObject testObject, String testProperty, ABTTime startDate, ABTTime endDate, double startingRate, double segmentRate)
   {
       ABTCurve
           availCurve = null;
       
      availCurve = setCurveValue(
                    testObject,
                    testProperty,
                    startDate,
                    endDate,
                    startingRate, // starting (default) rate
                    segmentRate, // rate for setsegment
                    ABTCurve.RATECURVE
                    ); 
      // onGet should return value just used in onSet              
      verifyValue(
                testObject,
                testProperty,
                availCurve, 
                null, // no parameters for onGet
                null,
                "Testing Resource Avail Curve", 
                true); 
                
      return true;          
   } // verifyRateCurve 
   
   public static void main( String args[] )
   {

      FieldRules app = new FieldRules( args );
      app.run();
   }

} // FieldRules   

// Object to relate Field Type descriptions (from CSV file) to Field Type constants
class fieldType extends Object
{
    String
        Description = null;
    int
        Constant = 0;

    fieldType()
    {
        Description = null;
        Constant = 0;
    }

    fieldType(String thisDescription, int thisConstant)
    {
        Description = thisDescription;
        Constant = thisConstant;
    }

} // fieldType
