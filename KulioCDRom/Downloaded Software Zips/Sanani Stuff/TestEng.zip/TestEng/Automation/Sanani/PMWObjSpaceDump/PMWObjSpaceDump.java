
import java.util.Enumeration;
import java.io.*;
import com.abtcorp.io.*;
import com.abtcorp.io.server.*;
import com.abtcorp.io.PMWRepo.*;
import com.abtcorp.io.siterepo.*;
import com.abtcorp.ObjectModel.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.blob.ABTCalendar;
import com.abtcorp.blob.ABTCurve;
import com.abtcorp.repository.*;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;
import com.abtcorp.idl.IABTPropertyType;
// AVP 11/19/98 
// LogFile capability
import TestLib.*;
// Sanani Builder - to create objects within objectspace
import Sanani.Lib.SananiBuilder;

// AVP 11/19/98:  Now extend this class from SananiBuilder,
// an object built by Scott Ellis and myself which contains
// methodology for creating and populating objects within objectspace
// (with no read from Repo first)
public class PMWObjSpaceDump extends SananiBuilder implements IABTDriverConstants, IABTPMRuleConstants, IABTPMWRepoConstants, IABTPropertyType, ABTNames
{
   private String repositoryName_;
   private String projectExternalID_;
   /* AVP 11/19/98 - now using SananiBuilder space_ and session_ variables
   private ABTObjectSpace space_;
   private ABTUserSession usersession_;
*/   
   private ABTPMWRepoDriver driver_;
   private ABTSiteRepoDriver siteDriver_;
   private ABTObjectSet oSet_;
   private ABTObject site_;
   private String productName_;
   private PrintWriter pStr = null;
   private boolean outToFile_;
   private String outputFileName_ = null;
   private boolean badProjPopulate_;

   public  PMWObjSpaceDump(String[] args)

   {
      repositoryName_ = "ann";
      projectExternalID_ = "2";
      productName_ = "ABT Workbench";
      outputFileName_ = null;
      outToFile_ = false;
      badProjPopulate_ = false;
      // AVP - 11/19/98 - add diagnostic log capability
      try {
          CurrentLog = new LogFile("TestRepoDriver",false,true);
      }
      catch( Exception e )
      {
         System.out.println( "Exception caught... printing stack trace..." );
         e.printStackTrace();
      }
      

        if (args.length == 0){
            System.out.println("No repository name entered");
            System.exit(1);
        }
        else {repositoryName_ = args[0];}

         if (args.length == 1){
            System.out.println("No project external ID entered");
            System.exit(1);
         }
         else {projectExternalID_ = args[1];}

         if (args.length > 2) {
            outToFile_ = true;
            outputFileName_ = args[2];
         }



/*     if (args != null && args.length > 0) {
         repositoryName_ = args[0];

         if (args.length > 1) {
            projectExternalID_ = args[1];
         }
             if (args.length > 2) {
                outToFile_ = true;
                outputFileName_ = args[2];
             }


      }
*/
   }

   public void run()
   {
      try
      {

         System.out.println("PMWObjSpaceDump starting...");
        if (outputFileName_ != null) {
            System.out.println("Opening output file.");
            pStr = new PrintWriter(new BufferedOutputStream(new FileOutputStream(outputFileName_)));
        }
         space_ = new ABTObjectSpace();
         driver_ = new ABTPMWRepoDriver();
         driver_.setSpace(space_);
         session_ = space_.startSession(null);
         driver_.setUserSession(session_);
         populateSite();
         openRepo(driver_);
         unlockProject();
         displayRepositories();
         displayProjects();
         populateProject();
         displayTaskHierarchy();
  //       newProject("NEW1");
// Save project back to repository.

         if (!badProjPopulate_)
         {
           saveProject(null);
         }            
         
         closeRepo(driver_);
         closeRepo(siteDriver_);
                if (pStr != null) {
                    System.out.println("closing output file.");
                    pStr.close();
                }
                else
                    System.out.println("Output sent to screen");


         System.out.println("PMWObjSpaceDump ended.");
      }

      catch (IOException e)
      {
            System.err.println("Caught IOException: " + e.getMessage());
      }

      catch (ABTException e)
      {
         e.printStackTrace();
      }

   }


   private void unlockProject()
   {
      ABTHashtable args = new ABTHashtable();

      args.putItemByString(KEY_COMMAND,  new ABTString(CMD_UNLOCK));
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_LOCKTYPE, new ABTString(LCK_IMPORTEXPORT));
      args.putItemByString(KEY_EXTID,    new ABTString(projectExternalID_));

      ABTValue val = driver_.execute(space_, session_, args);
      if (ABTError.isError(val))
         System.out.println(((ABTError)val).getMessage());
       else
         System.out.println("Lock successfully released (or lock not held in the first place!)");

   }

   private void displayTaskHierarchy() throws ABTException
   {
        System.out.println("* * * * Task Hierarchy Display * * * *");
      ABTObject projObj = (ABTObject) oSet_.at(session_, 0);
      String projName = projObj.getValue(session_, OFD_NAME).toString();
        System.out.println(projName);
      ABTValue v = projObj.getValue(session_, OFD_WBSSEQUENCE);
      if ( ABTValue.isNull( v ) )
         throw new ABTException( "Can't get WBSSequence!" );
      ABTArray WBSTaskArray = (ABTArray) v;
      int size = WBSTaskArray.size();
      for (int i = 0; i < size; i++)
      {
         ABTObject taskObj = (ABTObject) WBSTaskArray.at(i);
         int WBSLevel = taskObj.getValue(session_, OFD_WBSLEVEL).intValue();
         String indentation = getIndentation(WBSLevel);
         String taskName = taskObj.getValue(session_, OFD_NAME).toString();
         if (taskName.length() == 0)
            taskName = "(Unknown task name)";
           System.out.println(indentation + taskName.toString());
      }
   }

   private String getIndentation(int WBSLevel)
   {
      StringBuffer sb = new StringBuffer(5*WBSLevel); // allow enough room for all spaces

      for (int i = 0; i < WBSLevel; i++)
         sb.append("     ");     // allow 5 blanks for each indentation level
      return sb.toString();
   }


   private void populateSite() throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
      siteDriver_ = new ABTSiteRepoDriver();
      siteDriver_.setSpace(space_);
      siteDriver_.setUserSession(session_);
      openRepo(siteDriver_);
      ABTValue val = siteDriver_.populate(space_, session_, args);
      if (ABTError.isError( val ) )
         throw new ABTException((ABTError) val);
      if (val instanceof ABTObject )
      {
         site_ = (ABTObject) val;
      }
      else
         throw new ABTException("Site populate() failed and did not return a site object!");
   }
   


   private void populateProject()
   {
        try
        {
         ABTHashtable args = new ABTHashtable();

			// Ask the Repository driver to populate the object space with a
			// project and its tasks.  The driver's populate() method will return
			// an ABTValue objectset containing ABTProject objects and associated
			// ABTTask objects.

			args.clear();
/*			for (int pass = 1; pass < 3; pass++)
			{
			   System.out.println("Beginning pass " + pass + " of populating an object space.");
*/
//read in a project from repo

			   args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_PROJECT));
			   args.put(new ABTString(KEY_EXTID), new ABTString(projectExternalID_));
			   args.put(new ABTString(KEY_LOCK), new ABTBoolean(true));

			   ABTValue os = driver_.populate(space_, session_, args);
            if (ABTError.isError(os)){
                 processError((ABTError)os);
                 badProjPopulate_ = true;
                 throw new ABTException("Project populate() failed. Check for valid external project ID...");
            }
            
            if (os instanceof ABTObjectSet)
            {
               oSet_ = (ABTObjectSet) os;
                   System.out.println("This project object set contains " + oSet_.size(session_) + " objects.");
                   System.out.println("Scanning project objects in object set...");
               for (int i = 0; i < oSet_.size(session_); i++)
               {
//PROJECTS

                  ABTObject object = (ABTObject) oSet_.at(session_, i);
                  if (outToFile_)
                      propertyPrint(object,"PROJECT");
                  else
                      propertyScreen(object,"PROJECT");
                  ABTValue val;

                  val = object.getValue(session_, OFD_VERSION);
                  if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                  System.out.println("The project's version number is " + val);

                  val = object.getValue(session_, OFD_ISOPEN);
                  if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                  System.out.println("The project's isOpen flag is set to '" + val.booleanValue() + "' (" + val.intValue() + ")");
/*
//optional code to test changing a value in the object space and saving back to repository

//                         object.setValue(session_, OFD_USERTEXT1, new ABTString("text1"));

//                         object.setValue(session_, OFD_USERTEXT2, new ABTString("text2"));

//                         System.out.println("The project's usertext1 and 2 have been set.");

*/
//TEAM
               val = object.getValue(session_, OFD_TEAMRESOURCES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                  System.out.println(" The number of teams is " + ((ABTObjectSet)val).size(session_));

         	       ABTObjectSet teamoset = (ABTObjectSet) val;
                   if (teamoset.size(session_) > 0)
                   {

                        for (int j = 0; j < teamoset.size(session_); j++)
                        {
                            ABTObject teamObj = (ABTObject) teamoset.at(session_, j);
                          if (outToFile_)
                              propertyPrint(teamObj,"TEAM "+ j);
                          else
                              propertyScreen(teamObj,"TEAM " + j);



//RESOURCES (within TEAMS)

                           ABTObject resObj = (ABTObject) teamObj.getValue(session_, OFD_RESOURCE);
                     	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());

                              if (outToFile_)
                                  propertyPrint(resObj,"RESOURCE " + j);
                              else
                                propertyScreen(resObj,"RESOURCE " + j);


                        }//end for, team
                   }//end if, team
//                  ABTObjectSet assObjects = (ABTObjectSet) object.getValue(session_, OFD_ALLASSIGNMENTS);
//            	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());

//                  System.out.println("The number of assignments read for this project is " + assObjects.size(session_));

//ESTIMATING MODEL

               val = object.getValue(session_, OFD_ESTMODELS);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println(" The number of estimating models is " + ((ABTObjectSet)val).size(session_));

         	       ABTObjectSet estmodoset = (ABTObjectSet) val;

                   if (estmodoset.size(session_) > 0)
                   {

                   for (int j = 0; j < estmodoset.size(session_); j++)
                        {
                            ABTObject estmodObj = (ABTObject) estmodoset.at(session_, j);
                            if (outToFile_)
                                propertyPrint(estmodObj,"ESTIMATING MODEL " + j);
                            else
                              propertyScreen(estmodObj,"ESTIMATING MODEL " + j);

                   }//end for, est model

                }//end if estimating model
                  int childTaskCount = getChildTaskCount(object);
                  System.out.println("The number of tasks whose parent is the project is " +  childTaskCount);

//PROJECT NOTES
               val = object.getValue(session_, OFD_NOTES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
//               System.out.println(" The number of notes is " + ((ABTObjectSet)val).size(session_));

         	       ABTObjectSet noteoset = (ABTObjectSet) val;

                   if (noteoset.size(session_) > 0)
                   {
                        for (int j = 0; j < noteoset.size(session_); j++)
                        {
                           ABTObject noteObj = (ABTObject) noteoset.at(session_, j);
                           if (outToFile_)
                               propertyPrint(noteObj,"PROJECT NOTES " + j);
                           else
                             propertyScreen(noteObj,"PROJECT NOTES " + j);


                        }
                   }

//CUSTOM FIELD VALUES
               val = object.getValue(session_, OFD_CUSTFIELDVALUES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println(" The number of custom field values is " + ((ABTObjectSet)val).size(session_));

         	       ABTObjectSet custoset = (ABTObjectSet) val;
                   if (custoset.size(session_) > 0){
                        for (int j = 0; j < custoset.size(session_); j++)
                        {
                            ABTObject custObj = (ABTObject) custoset.at(session_, j);
                           if (outToFile_)
                               propertyPrint(custObj,"CUSTOM FIELD VALUE " + j);
                          else
                             propertyScreen(custObj,"CUSTOM FIELD VALUE " + j);

                        }
                   }

//ALL DELIVERABLES
               val = object.getValue(session_, OFD_ALLDELIVERABLES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
//               System.out.println(" The number of deliverables for project is " + ((ABTObjectSet)val).size(session_));

       	       ABTObjectSet delivoset = (ABTObjectSet) val;
               if (delivoset.size(session_) > 0){
                   for (int j = 0; j < delivoset.size(session_); j++)
                      {
                         ABTObject delivObject = (ABTObject) delivoset.at(session_, j);
                           if (outToFile_)
                               propertyPrint(delivObject,"DELIVERABLE " + j);
                           else
                             propertyScreen(delivObject,"DELIVERABLE " + j);

                      }
               }

//SUBPROJECT
               val = object.getValue(session_, OFD_SUBPROJECTLINKS);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
//               System.out.println(" The number of subprojects is " + ((ABTObjectSet)val).size(session_));

         	       ABTObjectSet subprjoset = (ABTObjectSet) val;
                   ABTObject subprjObj;
                   if (subprjoset.size(session_) > 0)
                   {
                      for (int j = 0; j < subprjoset.size(session_); j++)
                        {
                            subprjObj = (ABTObject) subprjoset.at(session_, j);
                           if (outToFile_)
                               propertyPrint(subprjObj,"SUBPROJECT " + j);
                           else
                             propertyScreen(subprjObj,"SUBPROJECT " + j);

                        }
                   }

//TASK
                  System.out.println("Scanning task objects for this project...");

                  val = object.getValue(session_, OFD_ALLTASKS);
            	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
            	   ABTObjectSet taskoset = (ABTObjectSet) val;

                  if (taskoset.size(session_) > 0)
                  {
                  for (int j = 0; j < taskoset.size(session_); j++)
                  {

                        ABTObject taskObj = (ABTObject) taskoset.at(session_, j);
                           if (outToFile_)
                               propertyPrint(taskObj,"TASK " + j);
                          else
                              propertyScreen(taskObj,"TASK " + j);


//set a new task name (setValue)
/*                         ABTValue prName = taskObj.getValue(session_, OFD_NAME);
                     	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                         taskObj.setValue(session_, OFD_NAME, new ABTString(prName.toString() + "x"));
                         System.out.println("The new value of this task's name is " + prName.toString());
*/
//DEPENDENCIES (within TASKS)

//Pred Dependencies
                   ABTValue predVal = taskObj.getValue(session_, OFD_PREDDEPENDENCIES);
                   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (predVal instanceof ABTObjectSet)
                     System.out.println(" The number of predecessor dependencies is " +((ABTObjectSet) predVal).size(session_));

         	       ABTObjectSet predoset = (ABTObjectSet) predVal;
                   if (predoset.size(session_) > 0)
                   {

                        for (int k = 0; k < predoset.size(session_); k++)
                        {
                            ABTObject predObj = (ABTObject) predoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(predObj,"PREDECESSOR DEPENDENCY " + k + " within TASK " + j);
                           else
                             propertyScreen(predObj,"PREDECESSOR DEPENDENCY " + k + " within TASK " + j);


                        }//end for, pred depend
                   }//end if, pred depend

//Succ Dependencies
                   ABTValue succDependencies = taskObj.getValue(session_, OFD_SUCCDEPENDENCIES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (succDependencies instanceof ABTObjectSet)
                      System.out.println(" The number of successor dependencies is " +((ABTObjectSet) succDependencies).size(session_));

         	       ABTObjectSet succoset = (ABTObjectSet) succDependencies;

                   if (succoset.size(session_) > 0)
                   {

                        for (int k = 0; k < succoset.size(session_); k++)
                        {
                            ABTObject succObj = (ABTObject) succoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(succObj,"SUCCESSOR DEPENDENCY " + k + " within TASK " + j);
                           else
                             propertyScreen(succObj,"SUCCESSOR DEPENDENCY " + k+ " within TASK " + j);


                        }//end for
                   }//end if

//TASK NOTES (within TASKS)

                   ABTValue tNotes = taskObj.getValue(session_, OFD_NOTES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (tNotes instanceof ABTObjectSet)
                     System.out.println(" The number of task notes is " +((ABTObjectSet) tNotes).size(session_));

         	       ABTObjectSet tNotesoset = (ABTObjectSet) tNotes;

                   if (tNotesoset.size(session_) > 0)
                   {

                        for (int k = 0; k < tNotesoset.size(session_); k++)
                        {
                            ABTObject tNoteObj = (ABTObject) tNotesoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(tNoteObj,"TASK NOTE" + k + " within TASK " + j);
                           else
                             propertyScreen(tNoteObj,"TASK NOTE " + k + " within TASK " + j);


                        }//end for
                   }//end if

//TASK ESTIMATES (within TASKS)

                   ABTValue tTaskEst = taskObj.getValue(session_, OFD_TASKESTIMATES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (tTaskEst instanceof ABTObjectSet)
                     System.out.println(" The number of task estimates is " +((ABTObjectSet) tTaskEst).size(session_));

         	       ABTObjectSet tTaskEstoset = (ABTObjectSet) tTaskEst;

                       if (tTaskEstoset.size(session_) > 0)
                       {

                            for (int k = 0; k < tTaskEstoset.size(session_); k++)
                            {
                                ABTObject tNoteObj = (ABTObject) tTaskEstoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(tNoteObj,"TASK ESTIMATE" + k+ " within TASK " + j);
                           else
                             propertyScreen(tNoteObj,"TASK ESTIMATE " + k+ " within TASK " + j);


                            }//end for
                       }//end if


//DELIVERABLES (within TASKS)
                   ABTValue delivVal = taskObj.getValue(session_, OFD_DELIVERABLES);
               	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (delivVal instanceof ABTObjectSet)
                      System.out.println(" The number of deliverables read for this task is " + ((ABTObjectSet)delivVal).size(session_));
         	       ABTObjectSet Tdelivoset = (ABTObjectSet) delivVal;

                   if (Tdelivoset.size(session_) > 0)
                   {

                        for (int k = 0; k < Tdelivoset.size(session_); k++)
                        {
                            ABTObject TdelivObj = (ABTObject) Tdelivoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(TdelivObj,"DELIVERABLE " + k+ " within TASK " + j);
                           else
                             propertyScreen(TdelivObj,"DELIVERABLE " + k+ " within TASK " + j);


                        }//end for, deliverables
                  }//end if, deliverables

//ASSIGNMENTS (within TASKS)
                   ABTValue assVal = taskObj.getValue(session_, OFD_ASSIGNMENTS);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (assVal instanceof ABTObjectSet)
                      System.out.println(" The number of assignments read for this task is " + ((ABTObjectSet)assVal).size(session_));

         	       ABTObjectSet assoset = (ABTObjectSet) assVal;
                   if (assoset.size(session_) > 0)
                   {

                        for (int k = 0; k < assoset.size(session_); k++)
                        {
                            ABTObject assObj = (ABTObject) assoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(assObj,"ASSIGNMENT " + k+ " within TASK " + j);
                           else
                             propertyScreen(assObj,"ASSIGNMENT " + k+ " within TASK " + j);

//NOTES (within ASSIGNMENTS)
                           ABTValue noteinassval = assObj.getValue(session_, OFD_NOTES);
                     	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                           if (noteinassval instanceof ABTObjectSet)
                             System.out.println(" The number of notes for this assignment is " + ((ABTObjectSet)noteinassval).size(session_));

                 	       ABTObjectSet noteassoset = (ABTObjectSet) noteinassval;
                           if (noteassoset.size(session_) > 0)
                           {

                                for (int m = 0; m < noteassoset.size(session_); m++)
                                {
                                    ABTObject noteassObj = (ABTObject) noteassoset.at(session_, m);
                                   if (outToFile_)
                                       propertyPrint(noteassObj,"NOTE " + m + " within TASK " + j + "and ASSIGNMENT " + k);
                                   else
                                     propertyScreen(noteassObj,"ASSIGNMENT " + m + " within TASK " + j + "and ASSIGNMENT " + k);

                                }//end for, notes

                           }//end if, notes

                        }//end for, assignments

                   }//end if, assignments


//CONSTRAINTS (within TASKS)
                   ABTValue conVal = taskObj.getValue(session_, OFD_CONSTRAINTS);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (conVal instanceof ABTObjectSet)
                      System.out.println(" The number of constraints read for this task is " + ((ABTObjectSet)conVal).size(session_));
         	       ABTObjectSet conoset = (ABTObjectSet) conVal;

                   if (conoset.size(session_) > 0)
                   {

                        for (int k = 0; k < conoset.size(session_); k++)
                        {
                            ABTObject conObj = (ABTObject) conoset.at(session_, k);
                           if (outToFile_)
                               propertyPrint(conObj,"CONSTRAINT " + k + " within TASK " + j);
                           else
                             propertyScreen(conObj,"CONSTRAINT " + k+ " within TASK " + j);


                        }
                  }

//CUSTOM FIELD VALUES (within task)

                   ABTValue custFldVal = taskObj.getValue(session_, OFD_TASKESTIMATES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (custFldVal instanceof ABTObjectSet)
                      System.out.println(" The number of custom field values read for this task is " + ((ABTObjectSet)custFldVal).size(session_));
         	       ABTObjectSet Tcustoset = (ABTObjectSet) custFldVal;

                   if (Tcustoset.size(session_) > 0){
                        for (int k = 0; k < Tcustoset.size(session_); k++)
                        {
                            ABTObject custObj = (ABTObject) Tcustoset.at(session_, k);

                               if (outToFile_)
                                   propertyPrint(custObj,"CUSTOM FIELD VALUE " + k + " within TASK " + j);
                              else
                                 propertyScreen(custObj,"CUSTOM FIELD VALUE (within TASK) " + k + " within TASK " + j);

                        }//end for, custom field values
                   }//end if, custom field values

               } //end "for" of tasks  loop (i.e. for each task...)
               }//end "if" of tasks
          else
             System.out.println("There are no tasks for this project.");







               }//end for, projects
               }//end if, projects
        }//end try of populateProject
        catch (Exception e)
        {
           System.out.println("Exception caught...printing stack trace...");
           e.printStackTrace();
        }//end catch of populateProject
        finally
        {
        }
   }//end projectPopulate




   public static void main(String args[])
   {
      PMWObjSpaceDump app = new PMWObjSpaceDump(args);
      app.run();
   }

   private void displayRepositories()
   {
      ABTHashtable args = new ABTHashtable();
      args.put(new ABTString(KEY_COMMAND), new ABTString(CMD_LIST));
      args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_REPOSITORY));
      ABTValue val = driver_.execute(space_, session_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         return;
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of Repositories on the currently-connected server:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
            System.out.println(e.nextElement());
      }
        System.out.println(" ");
   }


   private void openRepo(ABTRepositoryDriver driver) throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_USERNAME, new ABTString("annp"));
      args.putItemByString(KEY_PASSWORD, new ABTString(""));

      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_PRODUCT, new ABTString(productName_));
//      if (driver.open(space_, session_, args) != null ) throw new ABTException("Driver failed to open!");   

      ABTValue err =driver.open(space_, session_, args);
      if (err != null ) 
        processError((ABTError)err);

   }   
   private void closeRepo(ABTRepositoryDriver driver)
   {
      if (driver != null)
         driver.close(space_, session_, null);
   }

private void displayProjects()
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_COMMAND, new ABTString(CMD_LIST));
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_PROJECT));
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));

      ABTValue val = driver_.execute(space_, session_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         System.exit(1);
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of projects on the currently-connected Repository:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
         System.out.println(e.nextElement());
      }
      System.out.println(" ");
   }


   private int getChildTaskCount(ABTObject obj)
   {
      ABTValue task = obj.getValue(session_, OFD_FIRSTCHILDTASK);
      if (task == null || ABTError.isError(task) || task instanceof ABTEmpty)
         return 0;
      ABTValue lastTask = obj.getValue(session_, OFD_LASTCHILDTASK);
      if (task == null || ABTError.isError(lastTask) || lastTask instanceof ABTEmpty)
         return 0;

      int count = 1;
      while (task != lastTask)
      {
         count++;
         task = ((ABTObject)task).getValue(session_, OFD_NEXTTASK);
      }

      return count;
   }//end getChildTaskCount


      private void propertyScreen(ABTObject obj, String objType) throws ABTException
   {
          ABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.elements();
          System.out.println("\n\n" + objType + ":");
          for (int Count = 0; Count < Props.size(); Count++)
          {

              ABTProperty pass =   (ABTProperty) e.nextElement();
              if (!pass.isVisible()) continue;
              String Caption = pass.getCaption();
              String Name = pass.getName();
//handle project aggregates--can't do the usual getValue() with them              
              int propType = pass.getType();
              if (objType =="PROJECT" && (propType == PROP_BLOB || propType == PROP_TIMESTAMP))
              {
                        String one_;
                        String blob = "|Blob|";
                        String time = "|Timestamp|";
                        if (Name == "EACCurve"){
                            checkAggregations(obj, OFD_EACCURVE,Caption,Name,blob);

                        }
                        if (Name == "VarianceCurve"){
                            checkAggregations(obj, OFD_VARIANCECURVE,Caption,Name,blob);

                        }
                        if (Name == "ActCurve"){
                            checkAggregations(obj, OFD_ACTCURVE,Caption,Name,blob);

                        }
                        if (Name == "EstCurve"){
                            checkAggregations(obj, OFD_ESTCURVE,Caption,Name,blob);

                        }
                        if (Name == "Availability"){
                            checkAggregations(obj, OFD_AVAILABILITY,Caption,Name,blob);

                        }
                        if (Name == "AllocCurve"){
                            checkAggregations(obj, OFD_ALLOCCURVE,Caption,Name,blob);

                        }
                        if (Name == "EachAvail"){
                            checkAggregations(obj, OFD_EACH_AVAIL,Caption,Name,blob);

                        }
                        if (Name == "EACCurve"){
                            checkAggregations(obj, OFD_EACCURVE,Caption,Name,blob);

                        }
                        if (Name == "AvailStart"){
                            checkAggregations(obj, OFD_AVAILSTART,Caption,Name,blob);

                        }
                        if (Name == "AvailFinish"){
                            checkAggregations(obj, OFD_AVAILFINISH,Caption,Name,blob);

                        }
              }
              else{
              

              ABTValue  one_ = obj.getValue(session_, Name);

              if (ABTError.isError(one_)){
                System.out.println("Property name in error: "+ Name);
                processError((ABTError) one_);
                continue;
              }//end if
              else {
                if (ABTValue.isNull(one_)){
                    System.out.println(Name + "|" + Caption + "|empty/null|");                    continue;
                }
              }//end else
//              System.out.println(Caption + "            " + Name + ": " +  one_);


            switch (propType)

              {
                case PROP_INT:
                       System.out.println(Caption + "|" + Name + "|" +  one_ +"|Integer|" + one_.intValue() + "\n" );
                       break;
                    case PROP_STRING:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|String|" + one_.stringValue()+ "\n");
                       break;
                    case PROP_OBJECT:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Object|\n");
                       break;
                    case PROP_OBJECTSET:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|ObjectSet|\n");
                       break;
                    case PROP_LONG:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Long|"+ one_.intValue()+ "\n");
                       break;
                    case PROP_BOOLEAN:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Boolean|"+ one_.booleanValue()+ "\n");
                       break;
                    case PROP_DOUBLE:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Double|" + one_.doubleValue()+ "\n");
                       break;
                    case PROP_DATE:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Date|\n");
                       break;
                    case PROP_TIME:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Time|" + one_.timeValue()+ "\n");
                       break;
                    case PROP_TIMESTAMP:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|TimeStamp|\n");
                       break;
                    case PROP_BLOB:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Blob|\n");
                       break;
                    case PROP_SHORT:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Short|" + one_.shortValue() + "\n");
                       break;
                    case PROP_ID:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Remote ID|\n");
                        break;
                    case PROP_UNKNOWN:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Unknown|\n");

                    default:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Default|\n");
                       break;
               }//end switch
              }
      }//end for
   }//end propertyScreen


   private void propertyPrint(ABTObject obj, String objType) throws ABTException
   {
          
          ABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.elements();
          pStr.println("\n\n" + objType + ":");
          for (int Count = 0; Count < Props.size(); Count++)
          {

              ABTProperty pass =   (ABTProperty) e.nextElement();
              if (!pass.isVisible()) continue;
              String Caption = pass.getCaption();
              String Name = pass.getName();
              
//handle project aggregates--can't do the usual getValue() with them              
              int propType = pass.getType();
              if (objType =="PROJECT" && (propType == PROP_BLOB || propType == PROP_TIMESTAMP))
              {
                        String one_;
                        String blob = "|Blob|";
                        String time = "|Timestamp|";
                        if (Name == "EACCurve"){
                            checkAggregations(obj, OFD_EACCURVE,Caption,Name,blob);

                        }
                        if (Name == "VarianceCurve"){
                            checkAggregations(obj, OFD_VARIANCECURVE,Caption,Name,blob);

                        }
                        if (Name == "ActCurve"){
                            checkAggregations(obj, OFD_ACTCURVE,Caption,Name,blob);

                        }
                        if (Name == "EstCurve"){
                            checkAggregations(obj, OFD_ESTCURVE,Caption,Name,blob);

                        }
                        if (Name == "Availability"){
                            checkAggregations(obj, OFD_AVAILABILITY,Caption,Name,blob);

                        }
                        if (Name == "AllocCurve"){
                            checkAggregations(obj, OFD_ALLOCCURVE,Caption,Name,blob);

                        }
                        if (Name == "EachAvail"){
                            checkAggregations(obj, OFD_EACH_AVAIL,Caption,Name,blob);

                        }
                        if (Name == "EACCurve"){
                            checkAggregations(obj, OFD_EACCURVE,Caption,Name,blob);

                        }
                        if (Name == "AvailStart"){
                            checkAggregations(obj, OFD_AVAILSTART,Caption,Name,time);

                        }
                        if (Name == "AvailFinish"){
                            checkAggregations(obj, OFD_AVAILFINISH,Caption,Name,time);

                        }
              }
              else{
              
                  ABTValue  one_ = obj.getValue(session_, Name);
                  if (ABTError.isError(one_)){
                    pStr.println("Property name in error: "+ Name + "Type = " + propType);
                    processErrorToFile((ABTError) one_);
                    continue;
                  }//end if
                  else
                  {
                    if (ABTValue.isNull(one_)){
                        pStr.println(Name + "|" + Caption + "|empty/null|");                    continue;
                    }
                  }//end else


                switch (propType)

                  {
                    case PROP_INT:
                           pStr.println(Caption + "|" + Name + "|" +  one_ +"|Integer|" + one_.intValue());
                           break;
                        case PROP_STRING:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|String|" + one_.stringValue());
                           break;
                        case PROP_OBJECT:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Object|");
                           break;
                        case PROP_OBJECTSET:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|ObjectSet|");
                           break;
                        case PROP_LONG:
                         pStr.println(Caption + "|" + Name + "|" + one_ + "|Long|"+ one_.intValue());
                           break;
                        case PROP_BOOLEAN:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Boolean|"+ one_.booleanValue());
                           break;
                        case PROP_DOUBLE:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Double|" + one_.doubleValue());
                           break;
                        case PROP_DATE:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Date|");
                           break;
                        case PROP_TIME:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Time|" + one_.timeValue());
                           break;
                        case PROP_TIMESTAMP:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|TimeStamp|");
                           break;
                        case PROP_BLOB:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Blob|");
                           break;
                        case PROP_SHORT:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Short|" + one_.shortValue());
                           break;
                        case PROP_ID:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Remote ID|");
                            break;
                        case PROP_UNKNOWN:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Unknown|");

                        default:
                         pStr.println(Caption + "|" + Name + "|" +  one_ + "|Default|");
                           break;
                    }//end switch
        }//end else (for properties with normal getValue() handling)
      }//end for
   } //end propertyPrint

   private void checkAggregations(ABTObject proj, String aggName, String cap, String name, String type) throws ABTException
   {
   
      ABTValue val;
      
      val = proj.getValue(session_, OFD_MASTER_TEAM);
      if (ABTError.isError( val ))
         throw new ABTException(((ABTError)val).getMessage());
      
      //val = proj.getValue(session_, OFD_TEAMRESOURCES);
      
      ABTHashtable args = new ABTHashtable();
      Enumeration e = ((ABTSortedArray)val).elements();
      if (!e.hasMoreElements()){
        System.out.println(aggName + " not there. No teams for this project");
        return;
      }
   

      while (e.hasMoreElements())
      {
         //ABTObject team = (ABTObject) e.nextElement();
         //ABTObject resource = (ABTObject) team.getValue(session_, OFD_RESOURCE);
         ABTObject resource = (ABTObject) e.nextElement();
         String rName = resource.getValue(session_, OFD_NAME).toString();
         args.clear();
         args.putItemByString(OFD_RESOURCE, resource);
         args.putItemByString(OFD_UNIT, new ABTShort( kHours ));
         args.putItemByString(kFROM_DATE, ABTDate.today());
         args.putItemByString(kTO_DATE, ABTDate.today());

         if (outToFile_)
           pStr.println("Aggregating property '" + aggName + "' over resource '" + rName + "'");
         else
           System.out.println("Aggregating property '" + aggName + "' over resource '" + rName + "'");         
         val = proj.getValue(session_, aggName, args);  // e.g., OFD_ALLOCCURVE
         if (ABTError.isError( val ))
            throw new ABTException((ABTError)val);
         if ( !(val instanceof ABTCurve) && !(val instanceof ABTTime) && !(val instanceof ABTBoolean) && !(ABTValue.isNull(val)) )
            throw new ABTException("Oops! Aggregation is not an ABTCurve or an ABTTime!");

            
            if (val != null){
              if (outToFile_)
                pStr.println(cap + "|" + name + "|" +  val.toString() + type);
              else
                System.out.println(cap + "|" + name + "|" +  val.toString() + type);
              
            }
            else {
              if (outToFile_)
                 pStr.println(cap + "|" + name + "|" +  "returned null" + type);
              else
                 System.out.println(cap + "|" + name + "|" +  "returned null" + type);
              }
         

      }
   }

   private void processError(ABTError err)
   {
      System.out.println("ERROR OCCURRED!!!");
      if (err.getCode() > 0)
      System.out.println("  Code: " + err.getCode());
      if (err.getComponent() != null)
      System.out.println("  Component: " + err.getComponent());
      if (err.getMethod() != null)
      System.out.println("  Module: " + err.getMethod());
      if (err.getMessage() != null)
      System.out.println("  Message: " + err.getMessage());
      if (err.getInfo() != null)
      System.out.println("  Info: " + err.getInfo().toString());
   }//end processError

   private void processErrorToFile(ABTError err)
   {
      pStr.println("ERROR OCCURRED!!!");
      if (err.getCode() > 0)
      pStr.println("  Code: " + err.getCode());
      if (err.getComponent() != null)
      pStr.println("  Component: " + err.getComponent());
      if (err.getMethod() != null)
      pStr.println("  Module: " + err.getMethod());
      if (err.getMessage() != null)
      pStr.println("  Message: " + err.getMessage());
      if (err.getInfo() != null)
      pStr.println("  Info: " + err.getInfo().toString());
   }//end processErrorToFile

   // AVP - 11/19/98 - added today 
   // This method will create a all needed Site objects,
   // and a project object with all properties set as needed
   // to be saved back to Repo
   private void newProject(String extID)
   {
        ABTObjectSet
            newProjectSet = createObjectSet(OBJ_PROJECT,true);
            
      // Create Site objects needed
      /*
      System.out.println("Creating Site Objects");
      ABTObject    site       = createSite(1, true);
      ABTObject    calendar = createCalendar (site, 1, true);
      // Must have calendar set
      setValue(site,OFD_CALENDAR,new ABTCalendar(),true);
      */      
      // Project Model
      System.out.println("Creating Project Object");
      ABTObject    project     = createProject( 1, true );
      // If not created cleanly, set flag so it won't be saved
      if (null == project)
      {
          badProjPopulate_ = true;
          return;
      }          
      // Set external id to unique value as provided
      if (extID != null)
          setValue(project,OFD_EXTERNALID,new ABTString(extID),true);
      // Add Project to objectset
      add(newProjectSet,project,true);
      oSet_ = newProjectSet;
      badProjPopulate_ = false;
   } // newProject 


   private void saveProject(String extID)
   {
      try
      {
         System.out.println("Beginning save back to repository.");
         ABTHashtable args = new ABTHashtable();
         args.clear();
         args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_PROJECT));
         args.put(new ABTString(KEY_SOURCE), oSet_);
         args.put(new ABTString(KEY_UNLOCK), new ABTBoolean(true));
         if (extID != null)
         {
            args.put(new ABTString(KEY_SUBTYPE), new ABTString(SUBTYPE_SAVEAS));
            args.put(new ABTString(KEY_EXTID), new ABTString(extID));
         }
         ABTValue val = null;
         val = driver_.save(space_, session_, args); // Save it back.
         if (val == null)
            System.out.println("Ended successful save back to repository.");
         else if (val instanceof ABTError)
            System.out.println("Save Error: " + ((ABTError)val).getMessage());
      }//end try
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
      }

   }//saveProject end
}
