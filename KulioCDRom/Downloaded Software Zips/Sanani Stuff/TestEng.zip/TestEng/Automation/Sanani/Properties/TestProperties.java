import java.util.*;

import com.abtcorp.hub.*;
// import com.abtcorp.hub.ABTTestProperty;
import com.abtcorp.core.*;
import com.abtcorp.blob.*;
import com.abtcorp.objectModel.abt.*;
import com.abtcorp.objectModel.pm.*;
import com.abtcorp.objectModel.mm.*;
import com.abtcorp.objectModel.team.*;
import com.abtcorp.objectModel.publisher.*;
import com.abtcorp.io.PMWRepo.*;

import com.objectspace.jgl.ArrayIterator;
import Sanani.Lib.*;
import TestLib.*;

/* AVP 12/02/98:  This code was lifted from "TestRules" object then modified.
This object is extended from the SananiBuilder object, originally built by Scott Ellis
for rules testing, and enhanced by moi.
The purpose of TestProperties is to provide a list of all object properties in Sanani
by creating each object and logging all attributes of each property to a CSV file.
The second purpose is to list all properties, and map each property to the appropriate field 
in PVision 5.0.  This is accomplished using the same methodology described above for Sanani,
while also reading the prSystem.DML file from PVision 5.0, and matching PVision field names 
to object property names.  (The table - to - object matching is hardcoded).
*/         
// AVP 12/08/98:  Added Team Object Model
// AVP 12/09/98:  Added Publisher Object Model
// AVP 12/10/98:  Changed from reading prData.DML to prSystem.DML - using data dictionary
// in prSystem.DML allows us to reference calculated (virtual) PVision fields, and more 
// details such as Caption
public class TestProperties extends SananiBuilder implements RuleConstants
{
   LogFile
       PropertyListLog = null;
   Vector   
       DMLVector = null;
   // CONSTANTS FOR BIT-MAPPING WHICH PRODUCTS USE WHICH OBJECTS/TABLES    
   // AND READ/WRITE FLAGS
   int
       CONNECT = 1, // bitmap 1-bit 
       PLANNER = 2, // bitmap 2-bit
       PUBLISHER = 4, // bitmap 4-bit
       TEAM = 8, // bitmap 8-bit
       WORKBENCH = 16, // bitmap 16-bit
       READ = 1, // bitmap 1-bit
       WRITE = 2; // bitmap 2-bit
   // Are we running to list Sanani properties or to map to Repository?
   boolean
       DATAMAP = true;     
       
   public void run()
   {

      try
      {
          // 9/9/98 - AVP - create Log object
          CurrentLog = new LogFile("TestProperties",false,true);
          CurrentLog.LogDisplay(COMMENT, "TestProperties starting..." );
          createObjectSpace();
          listProperties();
      }
      catch( Exception e )
      {
         CurrentLog.LogDisplay(COMMENT, "Exception caught... printing stack trace..." );
         e.printStackTrace();
      }

      CurrentLog.LogDisplay(COMMENT, "TestProperties ended." );
   }

   // This method creates each object (hardcoded), for each Object Model
   // Global, Project, Methodology
   // As each object is created, all default properties of the object are listed
   // via method listObjectProperties
   public void listProperties() 
   {
      CurrentLog.LogDisplay(COMMENT,"Testing all Object Properties");
      
      // Special request from Zane:  Use CSV format to log failures, so must be separate from automatic "fail" log file
      try 
      {
          PropertyListLog = new LogFile(((DATAMAP) ? "OSPVDataMap.csv" : "OSPropertyList.csv"),false,false);
      } catch (Exception e)
      {
          CurrentLog.LogDisplay(FAIL,"Java Exception encountered creating property list csv, error = " + e);
          return;
      }

      // Log Column titles based on whether mapping object model to Pvision, or merely listing
      // object model.
      if (true == DATAMAP)
      {
          PropertyListLog.LogDisplay("OBJECT NAME:" + "," + "PROPERTY NAME:" + "," + "CAPTION:" + "," + "FIELD TYPE:" + "," + "FIELD LENGTH:" + "," + "REPO TABLE NAME:" + "," + "REPO NAME:" + "," + "REPO CAPTION:" + "," + "REPO TYPE:" + "," + "REPO LENGTH:" + "," + "CONNECT:" + "," + "PLANNER:" + "," + "PUBLISHER:" + "," + "TEAM:" + "," + "WORKBENCH:" + "," + "READ:" + "," + "WRITE:");
      } else {
//          PropertyListLog.LogDisplay("OBJECT NAME:" + "," + "PROPERTY NAME:" + "," + "CAPTION:" + "," + "FIELD RULE?" + "," + "FIELD TYPE:" + "," + "LENGTH:" + "," + "VIRTUAL:" + "," + "VISIBLE:" + "," + "UPDATEABLE:" + "," + "HIDDEN:" + "," + "EDITABLE:" + "," + "TRANSIENT:" + "," + "CONNECT:" + "," + "PLANNER:" + "," + "PUBLISHER:" + "," + "TEAM:" + "," + "WORKBENCH:");
          PropertyListLog.LogDisplay("OBJECT NAME:" + "," + "PROPERTY NAME:" + "," + "FIELD RULE:" + "," + "INITIALIZE:" + "," + "GET:" + "," + "SET:" + "," + "PROP KEY:" /*+ "," + "VALID:"*/);
      }            
      // Populate the vector tying actual field type constants to Field Type descriptions
      // in CSV file.
      fieldTypeVector = new Vector(12,1);
      fieldTypeVector.addElement(new fieldType("Array",PROP_ARRAY)); 
      fieldTypeVector.addElement(new fieldType("Boolean",PROP_BOOLEAN)); 
      fieldTypeVector.addElement(new fieldType("Curve",PROP_BLOB)); 
      fieldTypeVector.addElement(new fieldType("Date",PROP_TIMESTAMP)); 
      fieldTypeVector.addElement(new fieldType("Double",PROP_DOUBLE)); 
      fieldTypeVector.addElement(new fieldType("Long",PROP_LONG)); 
      fieldTypeVector.addElement(new fieldType("Short",PROP_SHORT)); 
      fieldTypeVector.addElement(new fieldType("Text",PROP_STRING)); 
      fieldTypeVector.addElement(new fieldType("Date",PROP_DATE)); 
      fieldTypeVector.addElement(new fieldType("TimeStamp",PROP_TIMESTAMP)); 
      fieldTypeVector.addElement(new fieldType("UnKnown",PROP_UNKNOWN)); 
      fieldTypeVector.addElement(new fieldType("Object Reference",PROP_OBJECT)); 
      fieldTypeVector.addElement(new fieldType("Object Set Reference",PROP_OBJECTSET)); 
      fieldTypeVector.addElement(new fieldType("Sanani ID",PROP_ID)); 
      // Same for extended field types
      extendedFieldTypeVector = new Vector(10,1);
      extendedFieldTypeVector.addElement(new fieldType("$",PROP_EXTTYPE_MONEY)); 
      extendedFieldTypeVector.addElement(new fieldType("%",PROP_EXTTYPE_PERCENT)); 
      extendedFieldTypeVector.addElement(new fieldType("PM",PROP_EXTTYPE_PM)); 
      extendedFieldTypeVector.addElement(new fieldType("Date",PROP_EXTTYPE_DATE)); 
      extendedFieldTypeVector.addElement(new fieldType("Memo",PROP_EXTTYPE_MEMO)); 
      extendedFieldTypeVector.addElement(new fieldType("Usg",PROP_EXTTYPE_RESUNIT)); 

      // Create all objects, and list all properties in each object 
      // - Project, Global, and Methodology Models
      
      // Global Model
      CurrentLog.LogDisplay(COMMENT,"Create Global Model");
      ABTObject    site       = createSite(1, true);
      ABTObject    adjrule    = createAdjRule(site, 1, true);
      ABTObject    calendar = createCalendar (site, 1, true);
      setValue(site,OFD_CALENDAR,new ABTCalendar(),true);
      setValue(site,OFD_STDCALENDAR,calendar,true);
      ABTObject    chargecode = createChargeCode (site, 1, true);
      ABTObject    customfield = createCustomField(site, 1, true);
      ABTObject    customfield2 = createCustomField(site, 2, true);
      ABTObject    aggfield = createAggregateField (customfield, customfield2, 1, true);
      ABTObject    customenum = createCustomEnum (customfield, 1, true);
      ABTObject    estmodelglobal = createEstModelGlobal (site, 1, true);
      ABTObject    resource   = createResource(site, 1, true);
      ABTObject    timeperiod = createTimePeriod (site, 1, true);
      ABTObject    typecode = createTypeCode (site, 1, true);
  
      // Project Model
      CurrentLog.LogDisplay(COMMENT,"Create Project Model");
      ABTObject    project     = createProject( 1, true );
      ABTObject    team       = createTeamResource( project, resource, 1, true );
      ABTObject    task        = createTask( project, null, null, 1, true );
      ABTObject    task2        = createTask( project, null, null, 2, true );
      ABTObject    assignment  = createAssignment( task, resource, 1, true);
      ABTObject    constraint  = createConstraint( task, 1, true);
      ABTObject    custfieldvalue  = createCustFieldValue( task, 1, true);
      ABTObject    deliverable  = createDeliverable( project, 1, true);
      ABTObject    dependency = createDependency (task, task2, 1, true);
      ABTObject    estmodel  = createEstmodel( project, 1, true);
      ABTObject    estimate  = createTaskestimate( task, estmodel, 1, true);
      ABTObject    note  = createNote(1, true);
      ABTObject    subprojlink = createSubprojectlink (task, 1, true);
      
      // Team Model
      CurrentLog.LogDisplay(COMMENT,"Create Team Model");
      ABTObject     TWSite = createObject(OBJ_TW_SITE,null,1,true);
      ABTObject     TWUser = createObject(OBJ_TW_USER,null,1,true);
      ABTObject     TWTypeCode = createObject(OBJ_TW_TYPECODE,null,1,true);
      ABTObject     TWChargeCode = createObject(OBJ_TW_CHARGECODE,null,1,true);
      ABTObject     TWTimePeriod = createObject(OBJ_TW_TIMEPERIOD,null,1,true);
      setValue(TWTimePeriod,FLD_TW_START,ABTTime.valueOf("12/06/98 12:00 AM"),true);
      setValue(TWTimePeriod,FLD_TW_FINISH,ABTTime.valueOf("12/13/98 5:00 PM"),true);
      ABTObject     TWProject = createObject(OBJ_TW_PROJECT,null,1,true);
      ABTObject     TWResource = createObject(OBJ_TW_RESOURCE,null,1,true);
      ABTObject     TWTask = createTWTask( project, null, 1, true );
      ABTObject     TWAssignment = createTWAssignment( TWTask, TWResource, 1, true );
      ABTObject     TWNote  = createTWNote(new ABTString(OBJ_TW_TASK), getValue(TWTask, OFD_ID,true), 1, true);
      ABTObject     TWTimeSheet  = createTWTimeSheet(TWResource, TWTimePeriod, 1, true);
      ABTObject     TWTimeEntry  = createTWTimeEntry(TWAssignment, 1, true);

      // Methodology Model
      CurrentLog.LogDisplay(COMMENT,"Create Methodology Model");
      ABTObject    method = createMethod( 1, true );
      ABTObject    MMtask = createMMTask( method, null, null, 1, true);
      ABTObject    MMtask2 = createMMTask( method, null, null, 2, true);
      ABTObject    MMassignment = createMMAssignment( MMtask, resource, 1, true);
      ABTObject    MMdeliverable  = createMMDeliverable( method, 1, true);
      ABTObject    MMdependency = createMMDependency (MMtask, MMtask2, 1, true);
      ABTObject    MMestimate  = createMMTaskestimate( MMtask, estmodelglobal, 1, true);
      ABTObject    MMpackage  = createPackage( method, new ABTBoolean(true), 1, true);
      ABTObject    MMpackagemember  = createPackageMember( MMtask, MMpackage, 1, true);
      ABTObject    MMpage  = createPage( method, 1, true);
      ABTObject    MMpagemember  = createPageMember( MMpage, customfield, 1, true);

      // Publisher Model
      CurrentLog.LogDisplay(COMMENT,"Create Publisher Model");
      ABTObject    pubSite     = createObject(ABT_PUB_SITE, null, 1, true );
      ABTObject    pubProject  = createObject(ABT_PUB_VIEW_PROJECT, null, 1, true );
      ABTObject    pubTask  = createObject(ABT_PUB_VIEW_TASK, null, 1, true );
      ABTObject    pubAssignment  = createObject(ABT_PUB_VIEW_ASSIGNMENT, null, 1, true );

      // list all properties of each object (in alphabetical order)
      listObjectProperties(aggfield,"MRAggregateField",PLANNER,READ|WRITE);
      listObjectProperties(adjrule,"MRAdjRule",PLANNER,READ|WRITE);
      listObjectProperties(assignment,"PRAssignment",WORKBENCH,READ|WRITE);
//      listObjectProperties(TWAssignment,"PRAssignment",TEAM|CONNECT,READ|WRITE);
      listObjectProperties(pubAssignment,"PRAssignment",PUBLISHER,READ);
      listObjectProperties(MMassignment,"MRAssignment",PLANNER,READ|WRITE);
      listObjectProperties(calendar,"PRCalendar",PLANNER|WORKBENCH,READ);
      if (false == DATAMAP)
      {
          listObjectProperties(chargecode,"PRChargeCode",PLANNER|WORKBENCH,READ);      
      }            
//      listObjectProperties(TWChargeCode,"PRChargeCode",TEAM|CONNECT,READ);      
      listObjectProperties(constraint,"PRConstraint",WORKBENCH,READ|WRITE);
      listObjectProperties(customenum,"MRCustomEnum",PLANNER,READ|WRITE);
      if (false == DATAMAP)
      {
          listObjectProperties(custfieldvalue,"PRCustFieldValue",WORKBENCH,READ|WRITE);
      }            
      listObjectProperties(customfield,"MRCustomField",PLANNER,READ|WRITE);
      listObjectProperties(deliverable,"PRDeliverable",WORKBENCH,READ);
      listObjectProperties(MMdeliverable,"MRDeliverable",PLANNER,READ|WRITE);
      listObjectProperties(dependency,"PRDependency",WORKBENCH,READ|WRITE);
      listObjectProperties(MMdependency,"MRDependency",PLANNER,READ|WRITE);
      if (false == DATAMAP)
      {
          listObjectProperties(estimate,"PREstimate",WORKBENCH,READ|WRITE);
      }            
      listObjectProperties(MMestimate,"MREstimate",PLANNER,READ|WRITE);
      listObjectProperties(estmodel,"PREstModel",PLANNER,READ|WRITE);
      listObjectProperties(estmodelglobal,"MREstModel",PLANNER,READ|WRITE);      
      listObjectProperties(note,"PRNote",WORKBENCH,READ|WRITE);
//      listObjectProperties(TWNote,"PRNote",TEAM|CONNECT,READ|WRITE);
      listObjectProperties(method,"MRMethod",PLANNER,READ|WRITE);
      listObjectProperties(MMpackage,"MRPackage",PLANNER,READ|WRITE);
      listObjectProperties(MMpackagemember,"MRPackageContent",PLANNER,READ|WRITE);
      listObjectProperties(MMpage,"MRPage",PLANNER,READ|WRITE);
      listObjectProperties(MMpagemember,"MRPageContent",PLANNER,READ|WRITE);
      listObjectProperties(project,"PRProject",PLANNER|WORKBENCH,READ|WRITE);
//      listObjectProperties(TWProject,"PRProject",TEAM|CONNECT,READ|WRITE);
      listObjectProperties(pubProject,"PRProject",PUBLISHER,READ);
      listObjectProperties(resource,"PRResource",PLANNER|WORKBENCH,READ);
//      listObjectProperties(TWResource,"PRResource",TEAM|CONNECT,READ);
      listObjectProperties(site,"PRSite",PLANNER|WORKBENCH,READ);
//      listObjectProperties(TWSite,"PRSite",TEAM|CONNECT,READ);
      listObjectProperties(pubSite,"PRSite",PUBLISHER,READ);
      listObjectProperties(subprojlink,"PRSubproject",PLANNER|WORKBENCH,READ|WRITE);
      listObjectProperties(task,"PRTask",WORKBENCH,READ|WRITE);
      listObjectProperties(MMtask,"MRTask",PLANNER,READ|WRITE);
//      listObjectProperties(TWSite,"PRSite",TEAM|CONNECT,READ|WRITE);
//      listObjectProperties(TWTask,"PRTask",TEAM|CONNECT,READ|WRITE);
      listObjectProperties(pubTask,"PRTask",PUBLISHER,READ);
//      listObjectProperties(TWTimeEntry,"PRTimeEntry",TEAM|CONNECT,READ|WRITE);
//      listObjectProperties(TWTimePeriod,"PRTimePeriod",TEAM|CONNECT,READ);
//      listObjectProperties(TWTimeSheet,"PRTimeSheet",TEAM|CONNECT,READ|WRITE);
      listObjectProperties(team,"PRTeam",PLANNER|WORKBENCH,READ|WRITE);
      listObjectProperties(timeperiod,"PRTimePeriod",WORKBENCH,READ);      
      if (false == DATAMAP)
      {
          listObjectProperties(typecode,"PRTypeCode",PLANNER|WORKBENCH,READ);      
      }            
      listObjectProperties(TWTypeCode,"PRTypeCode",TEAM,READ);      
//      listObjectProperties(TWUser,"PRUser");      
   } // listProperties

   // This method extracts all attributes for each property in
   // the specified object, then lists the attributes for each property
   // in the spreadsheet file
   public boolean listObjectProperties( ABTObject testObject, String repoTable, int productUsage, int readWriteFlag)
   {
        ABTPropertySet    
            ReturnProperties = null;
//        ABTTestProperty 
//            thisProperty = null;
        ABTProperty
            thisProperty = null;
        ABTValue            
            editableValue = null,
            hiddenValue = null;
        ABTSortedArray
            nameArray = null;
        objectProperty
            propertyValues = null;
        Enumeration
            ft = null,
            dml = null;
        fieldType
            thisFieldType = null;
        String
            fieldTypeDescription = null;
        Enumeration
            enum = null;
        boolean
            propertyFound = false;
        String
            thisPropertyObject = null,
            displayFieldRule = null,
            displayPropertyLength = null;
        DMLRecord
            thisDMLRecord = null,
            displayDMLRecord = null;
 
        CurrentLog.LogDisplay(COMMENT,"List Properties for " + testObject.getRule());
        if (testObject == null)
        {
            CurrentLog.LogDisplay(FAIL,"Could not test null object");
            return false;
        }            
        
        /* Removed this logic - will now include the prefix, so we can tell which object model is which
        // Adjust for global objects ("abt.") vs. project objects ("pm.") vs. method objects ("mm.")
        // AVP 12/08/98 vs. team objects ("team.")
        if (testObject.getRule().toString().startsWith("abt."))
            thisPropertyObject = testObject.getRule().toString().substring(4);
        else if (testObject.getRule().toString().startsWith("team."))
            thisPropertyObject = testObject.getRule().toString().substring(5);
        else            
            thisPropertyObject = testObject.getRule().toString().substring(3);
        */
        // AVP 12/10/98 - KLUGE Publisher Rule string is different - remove "com.abtcorp.objectModel"
        thisPropertyObject = testObject.getRule().toString();                
        String publisherTestString = "publisher.";
        if (thisPropertyObject.indexOf(publisherTestString) != -1)
        {
            thisPropertyObject = "pub." + thisPropertyObject.substring(thisPropertyObject.indexOf(publisherTestString) + publisherTestString.length());
        }            
        // If mapping data,
        // Read the PVision DML file and load all matching table entries into a vector
        // 12/10/98 AVP:  Changed to prSystem.DML for more detailed data dictionary
        if (DATAMAP)
        {
            try
            {
                ReadDMLFile("prSystem.DML",repoTable);
            } catch (Exception e)
            {
                CurrentLog.LogDisplay(FAIL,"Java Exception encountered reading DML file, error = " + e);
//                return false;
            }
        } // end if DATAMAP           
        ReturnProperties = testObject.getProperties();
        if (null == ReturnProperties)
        {
            CurrentLog.LogDisplay(FAIL,"getProperties for " + testObject + " returned null");
            return false;
        }  else if (ReturnProperties instanceof ABTPropertySet)
        {
            CurrentLog.LogWrite(PASS,"getProperties for " + testObject + " returned ABTPropertySet");
        } else // default else
        {
            CurrentLog.LogDisplay(FAIL,"getProperties did not return null or ABTPropertySet");
            return false;
        } // end if-else for testObject.getProperties
        // Sort alphabetically by property name
        nameArray = new ABTSortedArray();
        for (int PropertyPtr = 0; PropertyPtr < ReturnProperties.size(); PropertyPtr++)
        {
            thisProperty = testObject.getProperty(session_, PropertyPtr);
            nameArray.add(new ABTString(thisProperty.getName()));
        }            
        nameArray.sort();
        // Loop through all properties - sorted alpha by name
        Enumeration sortenum = nameArray.elements(new ABTDefaultComparator());        
        int
            PropertyValue = 0;
        while (sortenum.hasMoreElements())
        {
            thisProperty = testObject.getProperty(session_, sortenum.nextElement().toString());
            propertyValues = new objectProperty();
            propertyValues.propertyName = thisProperty.getName();
            // AVP 12/10/98 KLUGE - Publisher still prefixes "abt." in property names
            // we remove it here
            if (propertyValues.propertyName.startsWith("abt"))
            {
                propertyValues.propertyName = thisProperty.getName().substring(3);
            }                
            propertyValues.propertyObject = thisPropertyObject;
            propertyValues.propertyTypeInt = thisProperty.getType();
            // Verify Field Type
            // Find match on Field Type description in Field Type Vector
            fieldTypeDescription = " ";
            ft = fieldTypeVector.elements();            
            while (ft.hasMoreElements())
            {
                thisFieldType = (fieldType)ft.nextElement();
                // Constant should match for Field Type description
                if (propertyValues.propertyTypeInt == thisFieldType.Constant)
                {
                    fieldTypeDescription = thisFieldType.Description;
                    break;
                }                    
            }
            propertyValues.virtualFlag = thisProperty.isVirtual();
            propertyValues.visibleFlag = thisProperty.isVisible();
            propertyValues.updateableFlag = thisProperty.isUpdatable();
            propertyValues.hiddenFlag = false;
            hiddenValue = thisProperty.getPropertyKey(PROP_KHIDDEN);
            if (hiddenValue instanceof ABTBoolean)
               propertyValues.hiddenFlag = hiddenValue.booleanValue();
            propertyValues.internalFlag = thisProperty.isInternal();
            editableValue = thisProperty.getPropertyKey(PROP_KEDITABLE);
            // Default editable to true, unless extended property key set to false
            propertyValues.editableFlag = true;
            if (editableValue instanceof ABTBoolean)
               propertyValues.editableFlag = editableValue.booleanValue();
            propertyValues.transientFlag = thisProperty.isTransient();
            propertyValues.propertyCaption = thisProperty.getCaption();
            propertyValues.propertyRule = thisProperty.getFieldRule();
            String rulePrefix = "com.abtcorp.objectModel.";
            displayFieldRule = propertyValues.propertyRule.toString().substring(rulePrefix.length()); 
            displayFieldRule = displayFieldRule.substring(0,displayFieldRule.indexOf("@"));
            // Does this property have a non-default field rule?
            if (propertyValues.propertyRule instanceof ABTDefaultFieldRule) 
            {
                propertyValues.fieldRule = false;
            } else {               
                propertyValues.fieldRule = true;
            }                    
            propertyValues.propertyEnums = thisProperty.getPropertyKey(PROP_KPOSSIBLEVALUES).toString();
            ABTValue propertyLength = thisProperty.getPropertyKey(PROP_KMAXLEN);
            propertyValues.propertyLength = 0;
            displayPropertyLength = " ";
            if (propertyLength instanceof ABTInteger) {
//                propertyValues.propertyLength = thisProperty.getPropertyKey(PROP_KMAXLEN).intValue();
                displayPropertyLength = thisProperty.getPropertyKey(PROP_KMAXLEN).stringValue();
            }                
            propertyValues.extMoneyFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_MONEY)));
            propertyValues.extPercentFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_PERCENT)));
            propertyValues.extPMFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_PM)));
            propertyValues.extMemoFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_MEMO)));
            propertyValues.extDateFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_DATE)));
            propertyValues.extResUnitFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_RESUNIT)));
            propertyValues.extResAvailFlag = (false == ABTError.isError(thisProperty.getPropertyKey(PROP_EXTTYPE_RESAVAILUNIT)));
            // If mapping Sanani object model to PVision, list object property and corresponding field in PVision
            // If merely listing Sanani object properties, list all attributes of this property
            displayDMLRecord = new DMLRecord("None","None","None"," ");
            if (DATAMAP)
            {
                // For data mapping purposes, we don't list fields that are "Sanani only"
                // (internal fields, or those referencing objects or objectsets)
                if ((false == propertyValues.internalFlag) && (propertyValues.propertyTypeInt != PROP_OBJECT) && (propertyValues.propertyTypeInt != PROP_OBJECTSET))
                {
                    dml = DMLVector.elements();            
                    while (dml.hasMoreElements())
                    {
                        thisDMLRecord = (DMLRecord)dml.nextElement();
                        // Constant should match for Field Type description
                        if (propertyValues.propertyName.equals(thisDMLRecord.fieldName.substring(2)))
                        {
                            displayDMLRecord = thisDMLRecord;
                            break;
                        } 
                    }
                    PropertyListLog.LogDisplay(thisPropertyObject + "," + 
                                               propertyValues.propertyName + "," + 
                                               propertyValues.propertyCaption + "," + 
                                               fieldTypeDescription + "," +
                                               displayPropertyLength + "," +
                                               repoTable + "," + 
                                               displayDMLRecord.fieldName + "," + 
                                               displayDMLRecord.fieldCaption + "," + 
                                               displayDMLRecord.fieldType + "," + 
                                               displayDMLRecord.fieldLength + "," + 
/* Connect uses this? */                       ((CONNECT == (productUsage & CONNECT)) ? "YES" : " ") + "," +
/* Planner uses this? */                       ((PLANNER == (productUsage & PLANNER)) ? "YES" : " ") + "," +
/* Publisher uses this? */                     ((PUBLISHER == (productUsage & PUBLISHER)) ? "YES" : " ") + "," +
/* Team uses this? */                          ((TEAM == (productUsage & TEAM)) ? "YES" : " ") + "," +
/* Workbench uses this? */                     ((WORKBENCH == (productUsage & WORKBENCH)) ? "YES" : " ") + "," +
/* Read? */                                    ((READ == (readWriteFlag & READ)) ? "YES" : " ") + "," +
/* Write? */                                   ((WRITE == (readWriteFlag & WRITE)) ? "YES" : " ")
                                               );
/* 12/09/98 AVP:  Now using bit-mapped int argument to determine this - no longer assuming based
on object model 
                                               (((thisPropertyObject.startsWith("abt.")) || 
                                                 (thisPropertyObject.startsWith("pm."))) ? "YES" : " ")
*/                                                 
                } // end if not internal field                                               
            } else { // end if data mapping
   // AVP 12/11/98:  Determine which field-level rule activities are default
            if (true == propertyValues.fieldRule) 
            {
                try {
                    setValue(testObject,propertyValues.propertyName,new ABTString ("BOGUS"),true);
                } catch (Exception e) {
                }    
                try {
                    getValue(testObject,propertyValues.propertyName,true);
                } catch (Exception e) {
                }    
                PropertyListLog.LogDisplay(thisPropertyObject + "," + 
                                           propertyValues.propertyName + "," + 
//                                           propertyValues.propertyCaption + "," + 
                                           displayFieldRule //+ "," +
/*                                           
                                            !(thisProperty.isDefaultInitialize) +  ","  +
                                            !(thisProperty.isDefaultGet) +  ","  +
                                            !(thisProperty.isDefaultSet) +  ","  +
                                            !(thisProperty.isDefaultPropertyKey) // +  ","  +
*/                                            
//                                            thisProperty.isDefaultValid
/*        
        thisProperty.isDefaultNotifyReferenceAdd +  ","  +
        thisProperty.isDefaultNotifyReferenceRemove +  ","  +
        thisProperty.isDefaultNotifyReferenceClear +  ","  +
        thisProperty.isDefaultNotifyReferenceSet +  ","  +
        thisProperty.isDefaultNotifyReferenceChild +  ","  +
        thisProperty.isDefaultNotifyReferenceDelete
*/        
//                                           (propertyValues.fieldRule ? "YES" : " ")
//                                           fieldTypeDescription + "," + 
//                                           displayPropertyLength + "," +
//                                           propertyValues.virtualFlag + "," + 
//                                           propertyValues.visibleFlag + "," + 
//                                           propertyValues.updateableFlag + "," + 
//                                           propertyValues.hiddenFlag + "," + 
//                                           propertyValues.editableFlag + "," + 
//                                           propertyValues.transientFlag + "," +
// /* Connect uses this? */                   ((CONNECT == (productUsage & CONNECT)) ? "YES" : " ") + "," +
// /* Planner uses this? */                   ((PLANNER == (productUsage & PLANNER)) ? "YES" : " ") + "," +
// /* Publisher uses this? */                 ((PUBLISHER == (productUsage & PUBLISHER)) ? "YES" : " ") + "," +
// /* Team uses this? */                      ((TEAM == (productUsage & TEAM)) ? "YES" : " ") + "," +
// /* Workbench uses this? */                 ((WORKBENCH == (productUsage & WORKBENCH)) ? "YES" : " ")
                                           );
                }                                           
            }                
        } // end while looping through properties enum            

        return true;
   } // listObjectProperties

    public boolean ReadDMLFile(String DMLFileName, String PVisionTableName) throws Exception
    {
       ReadFile
           PVisionFile = null;
           
       try
       {
           PVisionFile = new ReadFile(DMLFileName);
       } catch (Exception e)
       {
           CurrentLog.LogDisplay(FAIL,"Could not open PVision DML file " + DMLFileName + ", exception: " + e);
           return false;
       }

       // Instantiate the Vector
       DMLVector = new Vector(10,1);
       // Advance to the correct PVision Table name section in DML File
       // AVP 12/10/98 - changed for prSystem.DML 
//       if (PVisionFile.ReadFileToString("[" + PVisionTableName + "]") != null)
       if (PVisionFile.ReadFileToString("[" + PVisionTableName + ".Fields]") != null)
       {
           // Read past first "pr"
           PVisionFile.ReadFileToString("pr");
           // Read each field for this Table
           while (true == readDMLRecord(PVisionFile));
       }
       
       return true;
    } // ReadDMLFile

    // This method will read one row from a DML file (currently prSystem.DML)
    // into a DMLRecord object, assuming the following format:
    // prFieldName=Caption,Type,Field Length (blank when not Text type)
    // ("pr" is stripped off before reading into DMLRecord)
    public boolean readDMLRecord (ReadFile DMLFile) throws Exception
    {
        DMLRecord
            DMLRecordObject = new DMLRecord();
        String
            propertyRead = null;
        boolean 
            moreRecords = true;
        
         // Read field name (up to "=")
         propertyRead = DMLFile.ReadFileToString("=");
         if (null == propertyRead)
            return false;
         DMLRecordObject.fieldName = "pr" + propertyRead;   
         // Read Caption
         DMLRecordObject.fieldCaption = DMLFile.ReadFileToString(",");
         // Read Type
         DMLRecordObject.fieldType = DMLFile.ReadFileToString(",");
         // Read field length (non-blank when type Text)
         DMLRecordObject.fieldLength = DMLFile.ReadFileToString(",");
         // Add to vector
         DMLVector.addElement(DMLRecordObject); 

         // Read past other commas in this field, to beginning of next field 
         for (int commaPtr = 0; commaPtr < 3; commaPtr++)
         {
             propertyRead = DMLFile.ReadFileToString(",");
         }             
         propertyRead = DMLFile.ReadFileToString("pr");
         // If we have finished this table, we will encounter a new table
         // name with brackets 
         moreRecords = (propertyRead.indexOf("[") == -1);
         return moreRecords;

   } // readDMLRecord

/* AVP 12/10/98 - changed to prSystem.DML - no longer read prData.DML
    // This method will read one row from a DML file (currently prData.DML)
    // into a DMLRecord object, assuming the following format:
    // prFieldName = fieldType(fieldLength)
    // ("pr" is stripped off before reading into DMLRecord)
    public boolean readDMLRecord (ReadFile DMLFile) throws Exception
    {
        DMLRecord
            DMLRecordObject = new DMLRecord();
        String
            propertyRead = null;
        boolean 
            moreRecords = true;
        
         // Read field name (up to "=")
         propertyRead = DMLFile.ReadFileToString("=");
         if (null == propertyRead)
            return false;
         DMLRecordObject.fieldName = "pr" + propertyRead;   
         propertyRead = DMLFile.ReadFileToString("pr");
         moreRecords = (propertyRead.indexOf("[") == -1);
//         DMLRecordObject.fieldType = DMLFile.ReadFileToString("pr");
         // If Text Field, parse format "Text(nn)" 
         // Type = "Text",  Length = "nn"
         // Any other field, trim away CR/LF, and if last Record, 
         // trim away reference to next table name
         DMLRecordObject.fieldLength = " ";
         if (propertyRead.indexOf("(") != -1)
         {
            DMLRecordObject.fieldType = propertyRead.substring
                                        (0,propertyRead.indexOf("("));
            DMLRecordObject.fieldLength = propertyRead.substring
                                (propertyRead.indexOf("(")+1,
                                 propertyRead.indexOf(")"));
                             //    DMLRecordObject.fieldType.indexOf("("));
         } else {
            if (true == moreRecords)
            {
                DMLRecordObject.fieldType = propertyRead.trim();
            } else {
                DMLRecordObject.fieldType = propertyRead.substring
                                            (0,propertyRead.indexOf("[")).trim();
            }                
         }   
         // Add to DML Vector
         DMLVector.addElement(DMLRecordObject); 

         return moreRecords;

   } // readDMLRecord
*/   
   
   public static void main( String args[] )
   {
    
      TestProperties app = new TestProperties();
      app.run();
   } // main
   
} // TestProperties

// Object for 1 record from prSystem.DML file ("fieldname=type(length)")
class DMLRecord extends Object
{
  String
    fieldName = null,
    fieldCaption = null,
    fieldType = null,
    fieldLength = null;
    
    
  DMLRecord()
  {
      fieldName = null;
      fieldCaption = null;
      fieldType = null;
      fieldLength = null;
  }  
  
  DMLRecord(String thisfieldName, String thisfieldCaption, String thisfieldType, String thisfieldLength)
  {
      fieldName = thisfieldName;
      fieldCaption = thisfieldCaption;
      fieldType = thisfieldType;
      fieldLength = thisfieldLength;
  }  
  
} // DMLRecord    

// Object for 1 Sanani Object Property (all attributes for 1 property)
class objectProperty extends Object
{
    String
        propertyName = null,
        propertyType = null,
        propertyObject = null,
        propertyCaption = null,
        propertyDefault = null,
        propertyMinmax = null,
        propertyEnums = null;
    ABTFieldRule                
        propertyRule = null;
    int
        propertyTypeInt = 0,
        propertyLength = 0;
    boolean 
        virtualFlag = false,
        visibleFlag = false,
        updateableFlag = false,
        hiddenFlag = false,
        internalFlag = false,
        editableFlag = false,
        transientFlag = false,
        onGet = false,
        onSet = false,
        fieldRule = false,
        foundFlag = false,
        extMoneyFlag = false,
        extPercentFlag = false,
        extPMFlag = false,
        extMemoFlag = false,
        extDateFlag = false,
        extResUnitFlag = false,
        extResAvailFlag = false;
        
    objectProperty()
    {
            propertyName = null;
            propertyType = null;
            propertyObject = null;
            propertyCaption = null;
            propertyDefault = null;
            propertyMinmax = null;
            propertyEnums = null;
            propertyRule = null;
            propertyTypeInt = 0;
            propertyLength = 0;
            virtualFlag = false;
            visibleFlag = false;
            updateableFlag = false;
            hiddenFlag = false;
            internalFlag = false;
            editableFlag = false;
            transientFlag = false;
            onGet = false;
            onSet = false;
            fieldRule = false;
            foundFlag = false;
            extMoneyFlag = false;
            extPercentFlag = false;
            extPMFlag = false;
            extMemoFlag = false;
            extDateFlag = false;
            extResUnitFlag = false;
            extResAvailFlag = false;
    }    
} // objectProperty        

// Object to relate Field Type descriptions (from CSV file) to Field Type constants
class fieldType extends Object
{
    String
        Description = null;
    int
        Constant = 0;
        
    fieldType()
    {
        Description = null;
        Constant = 0;
    }    

    fieldType(String thisDescription, int thisConstant)
    {
        Description = thisDescription;
        Constant = thisConstant;
    }    

} // fieldType
