
import java.util.Enumeration;
import java.io.*;
import com.abtcorp.io.*;
import com.abtcorp.io.server.*;
import com.abtcorp.io.PMWRepo.*;
import com.abtcorp.io.siterepo.*;
import com.abtcorp.hub.*;
import com.abtcorp.core.*;
import com.abtcorp.repository.*;
import com.abtcorp.idl.IABTPMRuleConstants;
import com.abtcorp.idl.IABTDriverConstants;
import com.abtcorp.idl.IABTPropertyType;


public class PMWObjSpaceDump implements IABTDriverConstants, IABTPMRuleConstants, IABTPMWRepoConstants, IABTPropertyType, ABTNames
{
   private String repositoryName_;
   private String projectExternalID_;
   private ABTObjectSpace space_;
   private ABTUserSession userSession_;
   private ABTPMWRepoDriver driver_;
   private ABTSiteRepoDriver siteDriver_;
   private ABTObjectSet oSet_;
   private ABTObject site_;
   private String productName_;
   private PrintWriter pStr = null;
   private boolean outToFile_;
   private String outputFileName_ = null;
   private boolean badProjPopulate_;

   public  PMWObjSpaceDump(String[] args)

   {
      repositoryName_ = "ann";
      projectExternalID_ = "TestThis";
      productName_ = "Test This Project";
      outputFileName_ = null;
      outToFile_ = false;
      badProjPopulate_ = false;

        if (args.length == 0){
            System.out.println("No repository name entered");
            System.exit(1);
        }
        else {repositoryName_ = args[0];}

         if (args.length == 1){
            System.out.println("No project external ID entered");
            System.exit(1);
         }
         else {projectExternalID_ = args[1];}

         if (args.length > 2) {
            outToFile_ = true;
            outputFileName_ = args[2];
         }



/*     if (args != null && args.length > 0) {
         repositoryName_ = args[0];

         if (args.length > 1) {
            projectExternalID_ = args[1];
         }
             if (args.length > 2) {
                outToFile_ = true;
                outputFileName_ = args[2];
             }


      }
*/
   }

   public void run()
   {
      try
      {

         System.out.println("PMWObjSpaceDump starting...");
        if (outputFileName_ != null) {
            System.out.println("Opening output file.");
            pStr = new PrintWriter(new BufferedOutputStream(new FileOutputStream(outputFileName_)));
        }
         space_ = new ABTObjectSpace();
         driver_ = new ABTPMWRepoDriver();
         driver_.setSpace(space_);
         userSession_ = space_.startSession(null);
         driver_.setUserSession(userSession_);
         populateSite();
         openRepo(driver_);
         unlockProject();
         displayRepositories();
         displayProjects();
         populateProject();
//         displayTaskHierarchy();

// Save project back to repository.

         if (!badProjPopulate_)
            saveProject("Test This");
         
         closeRepo(driver_);
         closeRepo(siteDriver_);
                if (pStr != null) {
                    System.out.println("closing output file.");
                    pStr.close();
                }
                else
                    System.out.println("Output sent to screen");


         System.out.println("PMWObjSpaceDump ended.");
      }

      catch (IOException e)
      {
            System.err.println("Caught IOException: " + e.getMessage());
      }

      catch (ABTException e)
      {
         e.printStackTrace();
      }

   }


   private void unlockProject()
   {
      ABTHashtable args = new ABTHashtable();

      args.putItemByString(KEY_COMMAND,  new ABTString(CMD_UNLOCK));
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_LOCKTYPE, new ABTString(LCK_IMPORTEXPORT));
      args.putItemByString(KEY_EXTID,    new ABTString(projectExternalID_));

      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
         System.out.println(((ABTError)val).getMessage());
       else
         System.out.println("Lock successfully released (or lock not held in the first place!)");

   }

   private void displayTaskHierarchy() throws ABTException
   {
        System.out.println("* * * * Task Hierarchy Display * * * *");
      ABTObject projObj = (ABTObject) oSet_.at(userSession_, 0);
      String projName = projObj.getValue(userSession_, OFD_NAME).toString();
        System.out.println(projName);
      ABTValue v = projObj.getValue(userSession_, OFD_WBSSEQUENCE);
      if ( ABTValue.isNull( v ) )
         throw new ABTException( "Can't get WBSSequence!" );
      ABTArray WBSTaskArray = (ABTArray) v;
      int size = WBSTaskArray.size();
      for (int i = 0; i < size; i++)
      {
         ABTObject taskObj = (ABTObject) WBSTaskArray.at(i);
         int WBSLevel = taskObj.getValue(userSession_, OFD_WBSLEVEL).intValue();
         String indentation = getIndentation(WBSLevel);
         String taskName = taskObj.getValue(userSession_, OFD_NAME).toString();
         if (taskName.length() == 0)
            taskName = "(Unknown task name)";
           System.out.println(indentation + taskName.toString());
      }
   }

   private String getIndentation(int WBSLevel)
   {
      StringBuffer sb = new StringBuffer(5*WBSLevel); // allow enough room for all spaces

      for (int i = 0; i < WBSLevel; i++)
         sb.append("     ");     // allow 5 blanks for each indentation level
      return sb.toString();
   }


   private void populateSite() throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_ALL));
      siteDriver_ = new ABTSiteRepoDriver();
      siteDriver_.setSpace(space_);
      siteDriver_.setUserSession(userSession_);
      openRepo(siteDriver_);
      ABTValue val = siteDriver_.populate(space_, userSession_, args);
      if (ABTError.isError( val ) )
         throw new ABTException((ABTError) val);
      if (val instanceof ABTObject )
      {
         site_ = (ABTObject) val;
      }
      else
         throw new ABTException("Site populate() failed and did not return a site object!");
   }
   


   private void populateProject()
   {
        try
        {
         ABTHashtable args = new ABTHashtable();

			// Ask the Repository driver to populate the object space with a
			// project and its tasks.  The driver's populate() method will return
			// an ABTValue objectset containing ABTProject objects and associated
			// ABTTask objects.

			args.clear();
/*			for (int pass = 1; pass < 3; pass++)
			{
			   System.out.println("Beginning pass " + pass + " of populating an object space.");
*/
//read in a project from repo
			   args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_PROJECT));
			   args.put(new ABTString(KEY_EXTID), new ABTString(projectExternalID_));
			   args.put(new ABTString(KEY_LOCK), new ABTBoolean(true));

			   ABTValue os = driver_.populate(space_, userSession_, args);
            if (ABTError.isError(os)){
                 badProjPopulate_ = true;
                 throw new ABTException("Project populate() failed. Check for valid external project ID...");
            }
            if (os instanceof ABTObjectSet)
            {
               oSet_ = (ABTObjectSet) os;
                   System.out.println("This project object set contains " + oSet_.size(userSession_) + " objects.");
                   System.out.println("Scanning project objects in object set...");
               for (int i = 0; i < oSet_.size(userSession_); i++)
               {
//PROJECTS

                  ABTObject object = (ABTObject) oSet_.at(userSession_, i);
                  if (outToFile_)
                      propertyPrint(object,"PROJECT "+ i);
                  else
                      propertyScreen(object,"PROJECTS " + i);
                  ABTValue val;

                  val = object.getValue(userSession_, OFD_VERSION);
                  if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                  System.out.println("The project's version number is " + val);

                  val = object.getValue(userSession_, OFD_ISOPEN);
                  if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                  System.out.println("The project's isOpen flag is set to '" + val.booleanValue() + "' (" + val.intValue() + ")");
/*
//optional code to test changing a value in the object space and saving back to repository

//                         object.setValue(userSession_, OFD_USERTEXT1, new ABTString("text1"));

//                         object.setValue(userSession_, OFD_USERTEXT2, new ABTString("text2"));

//                         System.out.println("The project's usertext1 and 2 have been set.");

*/
//TEAM
               val = object.getValue(userSession_, OFD_TEAMRESOURCES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                  System.out.println(" The number of teams is " + ((ABTObjectSet)val).size(userSession_));

         	       ABTObjectSet teamoset = (ABTObjectSet) val;
                   if (teamoset.size(userSession_) > 0)
                   {

                        for (int j = 0; j < teamoset.size(userSession_); j++)
                        {
                            ABTObject teamObj = (ABTObject) teamoset.at(userSession_, j);
                          if (outToFile_)
                              propertyPrint(teamObj,"TEAM "+ j);
                          else
                              propertyScreen(teamObj,"TEAM " + j);



//RESOURCES (within TEAMS)

                           ABTObject resObj = (ABTObject) teamObj.getValue(userSession_, OFD_RESOURCE);
                     	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());

                              if (outToFile_)
                                  propertyPrint(resObj,"RESOURCE " + j);
                              else
                                propertyScreen(resObj,"RESOURCE " + j);


                        }//end for, team
                   }//end if, team
//                  ABTObjectSet assObjects = (ABTObjectSet) object.getValue(userSession_, OFD_ALLASSIGNMENTS);
//            	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());

//                  System.out.println("The number of assignments read for this project is " + assObjects.size(userSession_));

//ESTIMATING MODEL

               val = object.getValue(userSession_, OFD_ESTMODELS);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println(" The number of estimating models is " + ((ABTObjectSet)val).size(userSession_));

         	       ABTObjectSet estmodoset = (ABTObjectSet) val;

                   if (estmodoset.size(userSession_) > 0)
                   {

                   for (int j = 0; j < estmodoset.size(userSession_); j++)
                        {
                            ABTObject estmodObj = (ABTObject) estmodoset.at(userSession_, j);
                            if (outToFile_)
                                propertyPrint(estmodObj,"ESTIMATING MODEL " + j);
                            else
                              propertyScreen(estmodObj,"ESTIMATING MODEL " + j);

                   }//end for, est model

                }//end if estimating model
                  int childTaskCount = getChildTaskCount(object);
                  System.out.println("The number of tasks whose parent is the project is " +  childTaskCount);

//PROJECT NOTES
               val = object.getValue(userSession_, OFD_NOTES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
//               System.out.println(" The number of notes is " + ((ABTObjectSet)val).size(userSession_));

         	       ABTObjectSet noteoset = (ABTObjectSet) val;

                   if (noteoset.size(userSession_) > 0)
                   {
                        for (int j = 0; j < noteoset.size(userSession_); j++)
                        {
                           ABTObject noteObj = (ABTObject) noteoset.at(userSession_, j);
                           if (outToFile_)
                               propertyPrint(noteObj,"PROJECT NOTES " + j);
                           else
                             propertyScreen(noteObj,"PROJECT NOTES " + j);


                        }
                   }

//CUSTOM FIELD VALUES
               val = object.getValue(userSession_, OFD_CUSTFIELDVALUES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
               System.out.println(" The number of custom field values is " + ((ABTObjectSet)val).size(userSession_));

         	       ABTObjectSet custoset = (ABTObjectSet) val;
                   if (custoset.size(userSession_) > 0){
                        for (int j = 0; j < custoset.size(userSession_); j++)
                        {
                            ABTObject custObj = (ABTObject) custoset.at(userSession_, j);
                           if (outToFile_)
                               propertyPrint(custObj,"CUSTOM FIELD VALUE " + j);
                          else
                             propertyScreen(custObj,"CUSTOM FIELD VALUE " + j);

                        }
                   }

//ALL DELIVERABLES
               val = object.getValue(userSession_, OFD_ALLDELIVERABLES);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
//               System.out.println(" The number of deliverables for project is " + ((ABTObjectSet)val).size(userSession_));

       	       ABTObjectSet delivoset = (ABTObjectSet) val;
               if (delivoset.size(userSession_) > 0){
                   for (int j = 0; j < delivoset.size(userSession_); j++)
                      {
                         ABTObject delivObject = (ABTObject) delivoset.at(userSession_, j);
                           if (outToFile_)
                               propertyPrint(delivObject,"DELIVERABLE " + j);
                           else
                             propertyScreen(delivObject,"DELIVERABLE " + j);

                      }
               }

//SUBPROJECT
               val = object.getValue(userSession_, OFD_SUBPROJECTLINKS);
         	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
//               System.out.println(" The number of subprojects is " + ((ABTObjectSet)val).size(userSession_));

         	       ABTObjectSet subprjoset = (ABTObjectSet) val;
                   ABTObject subprjObj;
                   if (subprjoset.size(userSession_) > 0)
                   {
                      for (int j = 0; j < subprjoset.size(userSession_); j++)
                        {
                            subprjObj = (ABTObject) subprjoset.at(userSession_, j);
                           if (outToFile_)
                               propertyPrint(subprjObj,"SUBPROJECT " + j);
                           else
                             propertyScreen(subprjObj,"SUBPROJECT " + j);

                        }
                   }

//TASK
                  System.out.println("Scanning task objects for this project...");

                  val = object.getValue(userSession_, OFD_ALLTASKS);
            	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
            	   ABTObjectSet taskoset = (ABTObjectSet) val;

                  if (taskoset.size(userSession_) > 0)
                  {
                  for (int j = 0; j < taskoset.size(userSession_); j++)
                  {

                        ABTObject taskObj = (ABTObject) taskoset.at(userSession_, j);
                           if (outToFile_)
                               propertyPrint(taskObj,"TASK " + j);
                          else
                              propertyScreen(taskObj,"TASK " + j);


//set a new task name (setValue)
/*                         ABTValue prName = taskObj.getValue(userSession_, OFD_NAME);
                     	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                         taskObj.setValue(userSession_, OFD_NAME, new ABTString(prName.toString() + "x"));
                         System.out.println("The new value of this task's name is " + prName.toString());
*/
//DEPENDENCIES (within TASKS)

//Pred Dependencies
                   ABTValue predVal = taskObj.getValue(userSession_, OFD_PREDDEPENDENCIES);
                   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (predVal instanceof ABTObjectSet)
                     System.out.println(" The number of predecessor dependencies is " +((ABTObjectSet) predVal).size(userSession_));

         	       ABTObjectSet predoset = (ABTObjectSet) predVal;
                   if (predoset.size(userSession_) > 0)
                   {

                        for (int k = 0; k < predoset.size(userSession_); k++)
                        {
                            ABTObject predObj = (ABTObject) predoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(predObj,"PREDECESSOR DEPENDENCY " + k + " within TASK " + j);
                           else
                             propertyScreen(predObj,"PREDECESSOR DEPENDENCY " + k + " within TASK " + j);


                        }//end for, pred depend
                   }//end if, pred depend

//Succ Dependencies
                   ABTValue succDependencies = taskObj.getValue(userSession_, OFD_SUCCDEPENDENCIES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (succDependencies instanceof ABTObjectSet)
                      System.out.println(" The number of successor dependencies is " +((ABTObjectSet) succDependencies).size(userSession_));

         	       ABTObjectSet succoset = (ABTObjectSet) succDependencies;

                   if (succoset.size(userSession_) > 0)
                   {

                        for (int k = 0; k < succoset.size(userSession_); k++)
                        {
                            ABTObject succObj = (ABTObject) succoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(succObj,"SUCCESSOR DEPENDENCY " + k + " within TASK " + j);
                           else
                             propertyScreen(succObj,"SUCCESSOR DEPENDENCY " + k+ " within TASK " + j);


                        }//end for
                   }//end if

//TASK NOTES (within TASKS)

                   ABTValue tNotes = taskObj.getValue(userSession_, OFD_NOTES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (tNotes instanceof ABTObjectSet)
                     System.out.println(" The number of task notes is " +((ABTObjectSet) tNotes).size(userSession_));

         	       ABTObjectSet tNotesoset = (ABTObjectSet) tNotes;

                   if (tNotesoset.size(userSession_) > 0)
                   {

                        for (int k = 0; k < tNotesoset.size(userSession_); k++)
                        {
                            ABTObject tNoteObj = (ABTObject) tNotesoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(tNoteObj,"TASK NOTE" + k + " within TASK " + j);
                           else
                             propertyScreen(tNoteObj,"TASK NOTE " + k + " within TASK " + j);


                        }//end for
                   }//end if

//TASK ESTIMATES (within TASKS)

                   ABTValue tTaskEst = taskObj.getValue(userSession_, OFD_TASKESTIMATES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (tTaskEst instanceof ABTObjectSet)
                     System.out.println(" The number of task estimates is " +((ABTObjectSet) tTaskEst).size(userSession_));

         	       ABTObjectSet tTaskEstoset = (ABTObjectSet) tTaskEst;

                       if (tTaskEstoset.size(userSession_) > 0)
                       {

                            for (int k = 0; k < tTaskEstoset.size(userSession_); k++)
                            {
                                ABTObject tNoteObj = (ABTObject) tTaskEstoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(tNoteObj,"TASK ESTIMATE" + k+ " within TASK " + j);
                           else
                             propertyScreen(tNoteObj,"TASK ESTIMATE " + k+ " within TASK " + j);


                            }//end for
                       }//end if


//DELIVERABLES (within TASKS)
                   ABTValue delivVal = taskObj.getValue(userSession_, OFD_DELIVERABLES);
               	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (delivVal instanceof ABTObjectSet)
                      System.out.println(" The number of deliverables read for this task is " + ((ABTObjectSet)delivVal).size(userSession_));
         	       ABTObjectSet Tdelivoset = (ABTObjectSet) delivVal;

                   if (Tdelivoset.size(userSession_) > 0)
                   {

                        for (int k = 0; k < Tdelivoset.size(userSession_); k++)
                        {
                            ABTObject TdelivObj = (ABTObject) Tdelivoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(TdelivObj,"DELIVERABLE " + k+ " within TASK " + j);
                           else
                             propertyScreen(TdelivObj,"DELIVERABLE " + k+ " within TASK " + j);


                        }//end for, deliverables
                  }//end if, deliverables

//ASSIGNMENTS (within TASKS)
                   ABTValue assVal = taskObj.getValue(userSession_, OFD_ASSIGNMENTS);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (assVal instanceof ABTObjectSet)
                      System.out.println(" The number of assignments read for this task is " + ((ABTObjectSet)assVal).size(userSession_));

         	       ABTObjectSet assoset = (ABTObjectSet) assVal;
                   if (assoset.size(userSession_) > 0)
                   {

                        for (int k = 0; k < assoset.size(userSession_); k++)
                        {
                            ABTObject assObj = (ABTObject) assoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(assObj,"ASSIGNMENT " + k+ " within TASK " + j);
                           else
                             propertyScreen(assObj,"ASSIGNMENT " + k+ " within TASK " + j);

//NOTES (within ASSIGNMENTS)
                           ABTValue noteinassval = assObj.getValue(userSession_, OFD_NOTES);
                     	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                           if (noteinassval instanceof ABTObjectSet)
                             System.out.println(" The number of notes for this assignment is " + ((ABTObjectSet)noteinassval).size(userSession_));

                 	       ABTObjectSet noteassoset = (ABTObjectSet) noteinassval;
                           if (noteassoset.size(userSession_) > 0)
                           {

                                for (int m = 0; m < noteassoset.size(userSession_); m++)
                                {
                                    ABTObject noteassObj = (ABTObject) noteassoset.at(userSession_, m);
                                   if (outToFile_)
                                       propertyPrint(noteassObj,"NOTE " + m + " within TASK " + j + "and ASSIGNMENT " + k);
                                   else
                                     propertyScreen(noteassObj,"ASSIGNMENT " + m + " within TASK " + j + "and ASSIGNMENT " + k);

                                }//end for, notes

                           }//end if, notes

                        }//end for, assignments

                   }//end if, assignments


//CONSTRAINTS (within TASKS)
                   ABTValue conVal = taskObj.getValue(userSession_, OFD_CONSTRAINTS);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (conVal instanceof ABTObjectSet)
                      System.out.println(" The number of constraints read for this task is " + ((ABTObjectSet)conVal).size(userSession_));
         	       ABTObjectSet conoset = (ABTObjectSet) conVal;

                   if (conoset.size(userSession_) > 0)
                   {

                        for (int k = 0; k < conoset.size(userSession_); k++)
                        {
                            ABTObject conObj = (ABTObject) conoset.at(userSession_, k);
                           if (outToFile_)
                               propertyPrint(conObj,"CONSTRAINT " + k + " within TASK " + j);
                           else
                             propertyScreen(conObj,"CONSTRAINT " + k+ " within TASK " + j);


                        }
                  }

//CUSTOM FIELD VALUES (within task)

                   ABTValue custFldVal = taskObj.getValue(userSession_, OFD_TASKESTIMATES);
             	   if (ABTError.isError(val)) throw new ABTException(((ABTError)val).getMessage());
                   if (custFldVal instanceof ABTObjectSet)
                      System.out.println(" The number of custom field values read for this task is " + ((ABTObjectSet)custFldVal).size(userSession_));
         	       ABTObjectSet Tcustoset = (ABTObjectSet) custFldVal;

                   if (Tcustoset.size(userSession_) > 0){
                        for (int k = 0; k < Tcustoset.size(userSession_); k++)
                        {
                            ABTObject custObj = (ABTObject) Tcustoset.at(userSession_, k);

                               if (outToFile_)
                                   propertyPrint(custObj,"CUSTOM FIELD VALUE " + k + " within TASK " + j);
                              else
                                 propertyScreen(custObj,"CUSTOM FIELD VALUE (within TASK) " + k + " within TASK " + j);

                        }//end for, custom field values
                   }//end if, custom field values

               } //end "for" of tasks  loop (i.e. for each task...)
               }//end "if" of tasks
          else
             System.out.println("There are no tasks for this project.");







               }//end for, projects
               }//end if, projects
        }//end try of populateProject
        catch (Exception e)
        {
           System.out.println("Exception caught...printing stack trace...");
           e.printStackTrace();
        }//end catch of populateProject
        finally
        {
        }
   }//end projectPopulate




   public static void main(String args[])
   {
      PMWObjSpaceDump app = new PMWObjSpaceDump(args);
      app.run();
   }

   private void displayRepositories()
   {
      ABTHashtable args = new ABTHashtable();
      args.put(new ABTString(KEY_COMMAND), new ABTString(CMD_LIST));
      args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_REPOSITORY));
      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         return;
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of Repositories on the currently-connected server:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
            System.out.println(e.nextElement());
      }
        System.out.println(" ");
   }


   private void openRepo(ABTRepositoryDriver driver) throws ABTException
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_USERNAME, new ABTString("annp"));
      args.putItemByString(KEY_PASSWORD, new ABTString(""));

      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));
      args.putItemByString(KEY_PRODUCT, new ABTString(productName_));
      if (driver.open(space_, userSession_, args) != null ) throw new ABTException("Driver failed to open!");
   }

   private void closeRepo(ABTRepositoryDriver driver)
   {
      if (driver != null)
         driver.close(space_, userSession_, null);
   }

private void displayProjects()
   {
      ABTHashtable args = new ABTHashtable();
      args.putItemByString(KEY_COMMAND, new ABTString(CMD_LIST));
      args.putItemByString(KEY_TYPE, new ABTString(TYPE_PROJECT));
      args.putItemByString(KEY_REPONAME, new ABTString(repositoryName_));

      ABTValue val = driver_.execute(space_, userSession_, args);
      if (ABTError.isError(val))
      {
         System.out.println(((ABTError)val).getMessage());
         System.exit(1);
      }
      ABTHashtable ht = (ABTHashtable) val;

      System.out.println("List of projects on the currently-connected Repository:");
      for (Enumeration e = ht.elements(); e.hasMoreElements();)
      {
         System.out.println(e.nextElement());
      }
      System.out.println(" ");
   }


   private int getChildTaskCount(ABTObject obj)
   {
      ABTValue task = obj.getValue(userSession_, OFD_FIRSTCHILDTASK);
      if (task == null || ABTError.isError(task) || task instanceof ABTEmpty)
         return 0;
      ABTValue lastTask = obj.getValue(userSession_, OFD_LASTCHILDTASK);
      if (task == null || ABTError.isError(lastTask) || lastTask instanceof ABTEmpty)
         return 0;

      int count = 1;
      while (task != lastTask)
      {
         count++;
         task = ((ABTObject)task).getValue(userSession_, OFD_NEXTTASK);
      }

      return count;
   }//end getChildTaskCount

   private void propertyScreen(ABTObject obj, String objType) throws ABTException
   {
          ABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.elements();
          System.out.println("\n\n" + objType + ":");
          for (int Count = 0; Count < Props.size(); Count++)
          {

              ABTProperty pass =   (ABTProperty) e.nextElement();
              String Caption = pass.getCaption();
              String Name = pass.getName();
//temp   these fields cause class cast exception-- cause as yet unknown


//              if (Name == "MaxActualsThru") continue;
              if (Name == "MinActualsThru") continue;
              if (Name == "EstInActualsPeriod") continue;

//temp end
              ABTValue  one_ = obj.getValue(userSession_, Name);

              if (ABTError.isError(one_)){
                System.out.println("Property name in error: "+ Name);
                processError((ABTError) one_);
                continue;
              }//end if
              else {
                if (ABTValue.isNull(one_)){
                    System.out.println(Name + "|" + Caption + "|empty/null|");                    continue;
                }
              }//end else
//              System.out.println(Caption + "            " + Name + ": " +  one_);
            int propType = pass.getType();

            switch (propType)

              {
                case PROP_INT:
                       System.out.println(Caption + "|" + Name + "|" +  one_ +"|Integer|" + one_.intValue() + "\n" );
                       break;
                    case PROP_STRING:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|String|" + one_.stringValue()+ "\n");
                       break;
                    case PROP_OBJECT:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Object|\n");
                       break;
                    case PROP_OBJECTSET:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|ObjectSet|\n");
                       break;
                    case PROP_LONG:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Long|"+ one_.intValue()+ "\n");
                       break;
                    case PROP_BOOLEAN:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Boolean|"+ one_.booleanValue()+ "\n");
                       break;
                    case PROP_DOUBLE:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Double|" + one_.doubleValue()+ "\n");
                       break;
                    case PROP_DATE:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Date|\n");
                       break;
                    case PROP_TIME:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Time|" + one_.timeValue()+ "\n");
                       break;
                    case PROP_TIMESTAMP:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|TimeStamp|\n");
                       break;
                    case PROP_BLOB:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Blob|\n");
                       break;
                    case PROP_SHORT:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Short|" + one_.shortValue() + "\n");
                       break;
                    case PROP_ID:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Remote ID|\n");
                        break;
                    case PROP_UNKNOWN:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Unknown|\n");

                    default:
                     System.out.println(Caption + "|" + Name + "|" +  one_ + "|Default|\n");
                       break;
               }//end switch

      }//end for
   }//end propertyScreen


   private void propertyPrint(ABTObject obj, String objType) throws ABTException
   {
          ABTPropertySet Props = obj.getProperties();
          Enumeration e =  Props.elements();
          pStr.println("\n\n" + objType + ":");
          for (int Count = 0; Count < Props.size(); Count++)
          {

              ABTProperty pass =   (ABTProperty) e.nextElement();
              String Caption = pass.getCaption();
              String Name = pass.getName();
//temp   these fields cause class cast exception-- cause as yet unknown
              if (Name == "MaxActualsThru") continue;
              if (Name == "MinActualsThru") continue;
              if (Name == "EstInActualsPeriod") continue;
//temp end
              ABTValue  one_ = obj.getValue(userSession_, Name);
              if (ABTError.isError(one_)){
                pStr.println("Property name in error: "+ Name);
                processErrorToFile((ABTError) one_);
                continue;
              }//end if
              else
              {
                if (ABTValue.isNull(one_)){
                    pStr.println(Name + "|" + Caption + "|empty/null|");                    continue;
                }
              }//end else

            int propType = pass.getType();

            switch (propType)

              {
                case PROP_INT:
                       pStr.println(Caption + "|" + Name + "|" +  one_ +"|Integer|" + one_.intValue());
                       break;
                    case PROP_STRING:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|String|" + one_.stringValue());
                       break;
                    case PROP_OBJECT:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Object|");
                       break;
                    case PROP_OBJECTSET:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|ObjectSet|");
                       break;
                    case PROP_LONG:
                     pStr.println(Caption + "|" + Name + "|" + one_ + "|Long|"+ one_.intValue());
                       break;
                    case PROP_BOOLEAN:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Boolean|"+ one_.booleanValue());
                       break;
                    case PROP_DOUBLE:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Double|" + one_.doubleValue());
                       break;
                    case PROP_DATE:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Date|");
                       break;
                    case PROP_TIME:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Time|" + one_.timeValue());
                       break;
                    case PROP_TIMESTAMP:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|TimeStamp|");
                       break;
                    case PROP_BLOB:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Blob|");
                       break;
                    case PROP_SHORT:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Short|" + one_.shortValue());
                       break;
                    case PROP_ID:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Remote ID|");
                        break;
                    case PROP_UNKNOWN:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Unknown|");

                    default:
                     pStr.println(Caption + "|" + Name + "|" +  one_ + "|Default|");
                       break;
               }//end switch

      }//end for
   } //end propertyPrint


   private void processError(ABTError err)
   {
      System.out.println("ERROR OCCURRED!!!");
      if (err.getCode() > 0)
      System.out.println("  Code: " + err.getCode());
      if (err.getComponent() != null)
      System.out.println("  Component: " + err.getComponent());
      if (err.getMethod() != null)
      System.out.println("  Module: " + err.getMethod());
      if (err.getMessage() != null)
      System.out.println("  Message: " + err.getMessage());
      if (err.getInfo() != null)
      System.out.println("  Info: " + err.getInfo().toString());
   }//end processError

   private void processErrorToFile(ABTError err)
   {
      pStr.println("ERROR OCCURRED!!!");
      if (err.getCode() > 0)
      pStr.println("  Code: " + err.getCode());
      if (err.getComponent() != null)
      pStr.println("  Component: " + err.getComponent());
      if (err.getMethod() != null)
      pStr.println("  Module: " + err.getMethod());
      if (err.getMessage() != null)
      pStr.println("  Message: " + err.getMessage());
      if (err.getInfo() != null)
      pStr.println("  Info: " + err.getInfo().toString());
   }//end processErrorToFile



   private void saveProject(String extID)
   {
      try
      {
         System.out.println("Beginning save back to repository.");
         ABTHashtable args = new ABTHashtable();
         args.clear();
         args.put(new ABTString(KEY_TYPE), new ABTString(TYPE_PROJECT));
         args.put(new ABTString(KEY_SOURCE), oSet_);
         args.put(new ABTString(KEY_UNLOCK), new ABTBoolean(true));
         if (extID != null)
         {
            args.put(new ABTString(KEY_SUBTYPE), new ABTString(SUBTYPE_SAVEAS));
            args.put(new ABTString(KEY_EXTID), new ABTString(extID));
         }
         ABTValue val = null;
         val = driver_.save(space_, userSession_, args); // Save it back.
         if (val == null)
            System.out.println("Ended successful save back to repository.");
         else if (val instanceof ABTError)
            System.out.println("Save Error: " + ((ABTError)val).getMessage());
      }//end try
      catch (Exception e)
      {
         System.out.println("Exception caught...printing stack trace...");
         e.printStackTrace();
      }
      finally
      {
      }

   }//saveProject end
}
