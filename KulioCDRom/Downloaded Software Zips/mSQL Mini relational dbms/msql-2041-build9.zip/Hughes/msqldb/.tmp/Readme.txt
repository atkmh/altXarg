An empty file to cause this directory to be added to the archive!
