# Generated automatically from site.mm.in by configure.
#
# Site specific configuration
#


COMPILER= gcc
INST_DIR= /usr/local/Hughes
HAVE_DYNAMIC= -DHAVE_DYNAMIC
CC_ONLY_FLAGS=
LINK_ONLY_FLAGS=


#
# Things below here shouldn't need to be changed
#
CC= $(COMPILER) $(CC_ONLY_FLAGS)
LINK= $(COMPILER) $(LINK_ONLY_FLAGS)
CPP= gcc -E
RANLIB= ranlib

YACC= bison -y

SIGLIST= 
DIRENT= -DHAVE_DIRENT_H -DHAVE_DIRENT
MMAP= -DHAVE_MMAP
U_INT= -DHAVE_U_INT
SSIZE_T= -DHAVE_SSIZE_T
BITTYPES= 
SYS_ERR= 
TARGET= CYGWIN32_95-4.0-i586
WORKING_RLIMIT= 

# Extra libraries if required
EXTRA_LIB= 

# Any other CFlags required
EXTRA_CFLAGS= -DHAVE_CONFIG_H $(SSIZE_T) $(U_INT) $(BITTYPES)

# Directory for pid file
PID_DIR= 

CFLAGS= -O -I$(TOP)/ $(EXTRA_CFLAGS)
LDLIBS= -L$(TOP)/lib $(EXTRA_LIB)
