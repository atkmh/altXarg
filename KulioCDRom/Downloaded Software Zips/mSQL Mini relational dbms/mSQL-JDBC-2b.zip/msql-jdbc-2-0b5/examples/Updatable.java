/* $Id: Updatable.java,v 2.1 1999/01/20 20:49:57 borg Exp $ */
import java.sql.*;
import java.util.*;

/**
 * Last modified $Date: 1999/01/20 20:49:57 $
 * @version $Revision: 2.1 $
 */
public class Updatable {
    public static void main(String argv[]) {
	try {
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Properties p = new Properties();
	    Connection con;
	    Statement stmt;
	    ResultSet rs;
	    
	    p.put("user", "borg");
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    con = DriverManager.getConnection(url, "borg", "");
	    stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
				       ResultSet.CONCUR_UPDATABLE);
	    rs = stmt.executeQuery("SELECT test_id, test_int " +
				   "FROM test " +
				   "WHERE test_int <> NULL " +
				   "ORDER BY test_id");
	    System.out.println("Got results:");
	    while( rs.next() ) {
		int id = rs.getInt(1);
		int val = rs.getInt(2);
		
		System.out.println("\tID #" + id + " is currently " + val +
				   ", setting it to " + (++val) + ".");
		rs.updateInt(2, val);
		rs.updateRow();
	    }		
	    con.close();
	    System.out.println("Done.");
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
  
