/* $Id: DateTest.java,v 2.2 1999/01/20 20:49:53 borg Exp $ */
import java.net.URL;
import java.sql.*;

/**
 * This example demonstates the use of the mSQL date type.
 * <BR>
 * Last modified $Date: 1999/01/20 20:49:53 $
 * @version $Revision: 2.2 $
 */
public class DateTest {
    public static void main(String argv[]) {
	try {
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Connection con = DriverManager.getConnection(url, "borg", "");
	    Statement stmt = con.createStatement();
	    ResultSet rs =
		stmt.executeQuery("SELECT test_id, test_date from test " +
				  "WHERE test_date <> NULL " +
				  "ORDER BY test_id");
	    
	    System.out.println("Got results:");
	    while(rs.next()) {
		int a = rs.getInt(1);
		Date d = rs.getDate(2);
		
		System.out.print(" key= " + a);
		System.out.print(" date= " + d);
		System.out.print("\n");
	    }
	    con.close();
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
  
