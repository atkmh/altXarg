1999-01-29  George Reese  <borg@carthage>

	* RowSetEventSupport.java: Added this class to provide RowSetEvent
	support for the ImaginaryRowSet class.

	* ImaginaryRowSet.java: Added this database-independent class for
	row set support. You can now use this class in coordination with
	the JDBC Standard Extension API too get row set functionality with
	any JDBC driver, not just mSQL-JDBC.

