/*
**      lite_priv.h - 
**
**
** Copyright (c) 1996,97  Hughes Technologies Pty Ltd
**
** Permission to use, copy, and distribute for non-commercial purposes,
** is hereby granted without fee, providing that the above copyright
** notice appear in all copies and that both the copyright notice and this
** permission notice appear in supporting documentation.
**
** This software is provided "as is" without any expressed or implied warranty.
**
**
*/



#if defined(_OS_OS2) || defined(_OS_WIN32)

extern RUNERRORFN         runError;
extern PARSEERRORFN       parseError;
extern YYLEXFN            yylex;
extern YYERRORFN          yyerror;
extern int*               yylineno;
extern CHECKCONTENTTYPEFN checkContentType;

#endif
