

typedef struct code_s {
	int	op;
	char	*arg1,
		*arg2;
	int	rangeStart,
		rangeEnd;
	struct code_s *next;
} code_t;


#define	OP_HTML		1
#define	OP_CONNECT	2
#define OP_DATABASE	3
#define OP_QUERY	4
