/*
** Mini SQL version details
*/

#define PROTOCOL_VERSION 	23
#define	DB_VERSION		20

#if defined(_OS_OS2)
#  define SERVER_VERSION  	"2.0.10 - " TARGET
#else
#  define SERVER_VERSION  	"2.0.10"
#endif
