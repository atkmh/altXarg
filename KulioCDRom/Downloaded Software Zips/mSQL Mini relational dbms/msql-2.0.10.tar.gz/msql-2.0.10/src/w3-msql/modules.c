
/*#define STATIC_GRAPH_LIB*/
/*#define STATIC_SNMP_LIB*/


#include <stdio.h>
#include "lite.h"

#include "mod_std.h"
#include "mod_msql.h"

#ifdef STATIC_GRAPH_LIB
#  include "/disk2/Development/msql/lite_modules/mod_graph_V1.0/mod_graph.h"
#endif
#ifdef STATIC_SNMP_LIB
#  include "/disk2/Development/msql/lite_modules/mod_snmp_V1.2/mod_snmp.h"
#endif

void initModules()
{
	addExterns(std_efuncts);
	addExterns(msql_efuncts);

#ifdef STATIC_GRAPH_LIB
	addExterns(graph_efuncts);
	init_mod();
#endif
#ifdef STATIC_SNMP_LIB
	addExterns(snmp_efuncts);
	init_mod();
#endif

	initStandardModule();
	initMsqlModule();
}
