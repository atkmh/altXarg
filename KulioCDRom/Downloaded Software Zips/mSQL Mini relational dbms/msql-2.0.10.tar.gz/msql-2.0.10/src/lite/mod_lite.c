/*
**      mod_lite.c       -  Anything specific to Lite
**
**
** Copyright (c) 1995-96  Hughes Technologies Pty Ltd
**
** Permission to use, copy, and distribute for non-commercial purposes,
** is hereby granted without fee, providing that the above copyright
** notice appear in all copies and that both the copyright notice and this
** permission notice appear in supporting documentation.
**
** The software may be modified for your own purposes, but modified versions
** may not be distributed.
**
** This software is provided "as is" without any expressed or implied warranty.
**
*/


#include <stdio.h>
#include <errno.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <fcntl.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>

#include "lite.h"
#include "regexp/regexp.h"

#include <time.h>


void doFatal(params)
	plist_t	*params;
{
        printf("\n%s\n",params->sym->val);
        printf("Error at line %d\n\n",simGetLineNum());
        exit(1);
}

void doUrlEncode(params)
        plist_t *params;
{
}


void doHttpAuth(params)
        plist_t *params;
{
}

void doForceHttpAuth(params)
        plist_t *params;
{
}


void doAddHttpHeader(params)
        plist_t *params;
{
}

void doSetHttpResponse(params)
        plist_t *params;
{
}
