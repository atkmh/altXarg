
#include <stdio.h>
#include "lite.h"

#include "mod_std.h"
#include "mod_msql.h"


void initModules()
{
	addExterns(std_efuncts);
	addExterns(msql_efuncts);

	initStandardModule();
	initMsqlModule();
}
