#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>

main()
{
	int	foo;

	foo = RLIMIT_NOFILE;
}

