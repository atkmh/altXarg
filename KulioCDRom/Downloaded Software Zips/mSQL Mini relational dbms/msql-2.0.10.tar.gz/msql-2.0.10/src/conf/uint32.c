#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


main()
{
	u_int32_t foo;

	foo = 1;
}
