#!/bin/sh

. $MACRO_DIR/makegen/makegen.cf

src=$1
shift
comment=$*
outfile=`echo $src | sed "s/\.y\$/.c/"`
obj=`echo $src | sed "s/\.y\$/.o/"`

echo	"$outfile : $src"
echo	"	@echo \"$comment\""
echo	'	$(YACC) $(YACC_FLAGS)'" $src"
echo	"	mv y.tab.c $outfile"
echo
echo	"$obj : $outfile"
echo	'	$(CC) $(CC_FLAGS) -o '$obj' -c $(SOURCE_DIR)/'$outfile
echo
echo	"clean ::"
echo	"	rm -f $outfile y.tab.*"
echo
