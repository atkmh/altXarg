
// The Fruit class overrides Show()
 
#include "produce.h"

#ifndef _FRUIT_

#define _FRUIT_



class CDessert
{
	CDessert();

};


class CFruit: public CProduce {

public:
	CFruit();	// constructors
	CFruit(char *n, char *c, int a, int pr );

	// display results
	virtual void Show(void);

};

#endif

class CApple: public CFruit, CDessert {

	CApple();	// constructors
	CApple(char *n, char *c, int a, int pr );

};


class CPeach: public CFruit, CDessert {

	CPeach();	// constructors
	CPeach(char *n, char *c, int a, int pr );

};


class CPear: public CFruit {

	CPear();	// constructors
	CPear(char *n, char *c, int a, int pr );

};


class COrange: public CFruit {

	COrange();	// constructors
	COrange(char *n, char *c, int a, int pr );

};


class CMacintosh : CApple
{
	CMacintosh ();
};

class CDelicious : CApple
{
	CDelicious ();
};

class CJonathan : CApple
{
	CJonathan ();
};


class CNavel :COrange {

	CNavel();
};

class CJuice : COrange {

	CJuice();
};
