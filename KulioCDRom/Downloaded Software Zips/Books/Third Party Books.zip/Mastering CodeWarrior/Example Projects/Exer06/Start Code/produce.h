// Thanks to Ron Liechty


// General Base Class defines two functions, List and Show
// List is declared and defined in this class.
// Show is a pure virtual function and must be overriden
// in subclasses.

#ifndef _PRODUCE_

#define _PRODUCE_

class CProduce { 	

public :
	CProduce();  // default constructor
	CProduce( char *n, char *c, int a, int pr);

	// List for dynamic allocation
	virtual	void List(char *n, char *c, int a, int pr );

	// display results
	virtual void Show(void) = 0;
	
protected:
	char   sName[20];	// data members
	char   sColor[20];
	int    amt;	
	int    price;

};

# endif