/*
	Written by James E. Trudeau and
	Copyright  1993-94 Nebula, Inc.
	All Rights Reserved
	
	eclipse.c contains routines for determining the date of
	solar or lunar eclipses
	
*/

#include	"eclipse.h"


/*****************************************************************/
/* NextSolarEclipse */ 
/*****************************************************************/
/*
	Meeus, Astronomical Algorithms, Chapter 52 p. 349 ff
	
	determine moment of next solar eclipse
	
	Requires: value of T at which to begin search (centuries from epoch)
	
	Receives: long value, 1 = forward, -1 = backward search
	          value of T for starting point of search
	          pointer to EclipseData to return information;
	
	Changes: nothing
	
	Returns: nothing
	
	Note: accuracy of calculated moment of maximum eclipse is about 1 minute
	      for years 1951-2050.
	
*/

void	NextSolarEclipse (lumFlt T, long step, EclipseData *theData)

{
	lumFlt	JDE;	/* julian date of eclipse */
	lumFlt	k;
	lumFlt	F;
	lumFlt	gamma, u;
	lumFlt	magnitude = 0;
	long	type = NONE;
	

/* calculate lunation and approximate value of T */
	
	/* k is lunation number for starting date */
	/* value 12.3685 is mean number of lunations/year */
	
	k = floor (T * 100 * 12.3685);	/* formula 47.2 */
	
/* prepare for loop, we add or subtract 1 before looping */
	k -= step;
	
	do	/* fine search */
	{
		do	/* coarse search */
		{
			k += step;	/* step forward or backward */
			
			T = k/1236.85;	/* formula 47.3  */
		
	/* calculate mean value for this lunation, formula 47.1 */
	
			JDE = 2451550.09765 + 29.530588853 * k + 
		          T * T * (0.0001337 + T * (-0.000000150 + T * 0.00000000073));
	          
	/* calculate moon angles, do F first to see if we have an eclipse */
		/* moon's argument of latitude, formula 47.6 */
			F = RadianRange((160.7108 + 390.67050274 * k +
		     	 T * T * (0.0107438 + T * (0.00001239 - T * .000000058))) * kDegToRad);
		     
		}	while (fabs(sin(F) > .36));

/* when sin(F) < .36, we may have some sort of eclipse */
/* calculate eclipse data for this moment (gamma and u) and check */	
		
		CalcEclipseData (F, k, T, &JDE, &gamma, &u, SOLAR);	/* ignore return value, not used */

	
	} while ( gamma > (1.5433 + u));  /* when gamma < this value we really have eclipse */
	

	if ( gamma < .9972)
	{
		if (u < 0)
		{
			type = TOTAL;
		}
		
		else if (u > .0047)
		{
			type = ANNULAR;
		}
		else if (u < 0.00464 * sqrt (1 - gamma * gamma))
		{
	     	type = ANNULAR_TOTAL;
	    }
	    else
	    { 
	        type = ANNULAR;
		}
	}
	else if (gamma < .9972 + fabs(u))
	{
		type = NOT_CENTRAL;
	}
	else
	{
		type = PARTIAL;
		magnitude = (1.5433 + u - gamma)/(0.5461 + u + u);
	}
	
	theData->type = type;
	theData->magnitude = magnitude;
	theData->JDE = JDE;
	theData->totalitySemiDuration = 0;
	theData->partialSemiDuration = 0;
	theData->penumbralSemiDuration = 0;
}



/*****************************************************************/
/* NextLunarEclipse */
/*****************************************************************/
/*
	Meeus, Astronomical Algorithms, Chapter 52 p. 349 ff
	
	determine moment of next lunar eclipse
	
	Requires: value of T at which to begin search (centuries from epoch)
	
	Receives: long value, 1 or -1, indicating forward or backward search
	          value of T for starting point of search
	
	Changes: nothing
	
	Returns: nothing
	
	Note: accuracy of calculated moment of maximum eclipse is about 1 minute
	      for years 1951-2050.
	
*/



void	NextLunarEclipse (lumFlt T, long step, EclipseData *theData)

{
	lumFlt	JDE;	/* julian date of eclipse */
	lumFlt	k;
	lumFlt	F, Mprime;
	lumFlt	gamma, u;
	lumFlt	totalDuration, partialDuration, penumbralDuration;
	lumFlt	n, H, P;
	lumFlt	magnitude = 0;
	long	type = NONE;
	

	totalDuration = partialDuration = penumbralDuration = 0;
	
/* calculate lunation and approximate value of T */
	
	/* k is lunation number for starting date */
	/* value 12.3685 is mean number of lunations/year */
	
	k = floor (T * 100 * 12.3685) + .5;	/* formula 47.2 */
	
/* prepare for loop, we add or subtract 1 before looping */
	k -= step;
		
	do	/* fine search */
	{
		do	/* coarse search */
		{
			k += step;	/* step forward or backward */
			
			T = k/1236.85;	/* formula 47.3  */
		
	/* calculate mean value for this lunation, formula 47.1 */
	
			JDE = 2451550.09765 + 29.530588853 * k + 
		          T * T * (0.0001337 + T * (-0.000000150 + T * 0.00000000073));
	          
	/* calculate moon angles, do F first to see if we have an eclipse */
		/* moon's argument of latitude, formula 47.6 */
			F = (160.7108 + 390.67050274 * k +
		     	 T * T * (0.0107438 + T * (0.00001239 - T * .000000058))) * kDegToRad;
		     
		}	while (fabs(sin(F) > .36));

/* when sin(F) < .36, we MAY have some sort of eclipse */
/* calculate eclipse data for this moment (gamma and u) and check */	
	
		Mprime = CalcEclipseData (F, k, T, &JDE, &gamma, &u, LUNAR);

/* values to calculate duration of eclipse */
		n = 0.5458 + 0.0400 * cos(Mprime);
		H = 1.5573 + u;
		if (H > gamma)
		{
			penumbralDuration = 60/n * sqrt(H*H - gamma * gamma);
		}
/* look to see if it's umbral */		
		magnitude = (1.0128 - u - gamma)/0.5450;
		
		if (magnitude > 0)	/* umbral eclipse */
		{
			P = 1.0128 - u;
			T = 0.4678 - u;
			if (P > gamma)	/* partial umbral */
			{
				type = PARTIAL;
				partialDuration = 60/n * sqrt(P * P - gamma * gamma);
			}
			if (T > gamma)	/* total umbral */
			{
				type = TOTAL;
				totalDuration = 60/n * sqrt(T*T - gamma * gamma);
			}
		}

/* if not umbral, look for penumbral */
		else
		{
			magnitude = (1.5573 + u - gamma)/0.5450;
			if (magnitude > 0)
			{
				type = PENUMBRAL;
			}
		}

	} while (magnitude <= 0 );  
	
	theData->type = type;
	theData->magnitude = magnitude;
	theData->JDE = JDE;
	theData->totalitySemiDuration = totalDuration;
	theData->partialSemiDuration = partialDuration;
	theData->penumbralSemiDuration = penumbralDuration;
}


/*****************************************************************/
/* CalcEclipseData */
/*****************************************************************/

/*
	Calculate values for the possible eclipse.
	
	Returns value of Mprime for lunar eclipse testing
	provides values of gamma and u as per Meeus to determine if there
	is an eclipse and the nature of the eclipse.
	
	Requires: moon's argument of latitude,
	          which lunation to perform
	          value of T for this moment
	          julian date for this moment (dynamical time)
	          
	Receives: value F of moon's argument of latitude,
	          value k for which lunation to perform
	          value of T for this moment
	          pointer to JDE
	          pointer to gamma
	          pointer to u
	          long value indicating SOLAR or LUNAR calculation
	
	Changes: nothing
	
	Returns: value of Mprime, moon's mean anomaly
	          
*/



lumFlt	CalcEclipseData (lumFlt F, lumFlt k, lumFlt T, lumFlt *JDE, 
                         lumFlt *gamma, lumFlt *u, long type)
{
	lumFlt	M, Mprime, Omega, E;	/* required angles */
	lumFlt	F1, A1;					/* more angles */
	lumFlt	P, Q, W;				/* yet more angles */
	
	/* sun's mean anomaly, formula 47.4 */
	M = RadianRange((2.5534 + 29.10535669 * k -
	     T * T * (.0000218 - T * .00000011)) * kDegToRad);
	
	/* moon's mean anomaly, formula 47.5 */
	Mprime = RadianRange((201.5643 + 385.81693528 * k +
	          T * T * (0.0107438 + T * (.00001239 - T * .000000058))) * kDegToRad);
	
	/* moon's ascending node, formula 47.7 */
	Omega = RadianRange((124.7746 - 1.56375580 * k +
	         T * T * (.0020691 + T * .00000215)) * kDegToRad);

	/* eccentricity of the earth's orbit, formula 45.6 */	
	E = 1 - T * (0.002516 + T * 0.0000074); 

    F1 = F - 0.02665 * kDegToRad * sin(Omega);
    A1 = RadianRange((299.77 + 0.107408 * k -  0.009173 * T * T) * kDegToRad);

	/* formula 52.1 */
	if (type == SOLAR)
	{
    	*JDE += - 0.4075 * sin(Mprime) 
        	    + 0.1721 * E * sin(M);
    }
    else	/* doing a lunar eclipse */
    {
    	*JDE += - 0.4065 * sin(Mprime) 
        	    + 0.1727 * E * sin(M);    
    }
            
    *JDE += + 0.0161 * sin(Mprime + Mprime);
    *JDE +=	- 0.0097 * sin(F1 + F1);
    *JDE += + 0.0073 * E * sin(Mprime - M);
    *JDE += - 0.0050 * E * sin(Mprime + M);
    *JDE += - 0.0023 * sin(Mprime - F1 - F1);
    *JDE += + 0.0021 * E * sin(M + M);
    *JDE += + 0.0012 * sin(Mprime + F1 + F1);
    *JDE += + 0.0006 * E * sin(Mprime + Mprime + M);
    *JDE += - 0.0004 * sin(3 * Mprime);
    *JDE += - 0.0003 * E * sin(M + F1 + F1);
    *JDE += + 0.0003 * sin(A1);
    *JDE += - 0.0002 * E * sin(M - F1 - F1);
    *JDE += - 0.0002 * E * sin(Mprime + Mprime - M);
    *JDE += - 0.0002 * sin(Omega);

/* calculate P & Q */
    P =  + 0.2070 * E * sin(M);
    P += + 0.0024 * E * sin(M + M);
    P += - 0.0392 * sin(Mprime);
    P += + 0.0116 * sin(Mprime + Mprime);
    P += - 0.0073 * E * sin(Mprime + M);
    P += + 0.0067 * E * sin(Mprime - M);
    P += + 0.0118 * sin(F1 + F1);

    Q =  + 5.2207 - 0.0048 * E * cos(M);
    Q += + 0.0020 * E * cos(M + M);
    Q += - 0.3299 * cos(Mprime);
    Q += - 0.0060 * E * cos(Mprime + M);
    Q += + 0.0041 * E * cos(Mprime - M);
      
	W = fabs (cos (F1));

	*gamma = fabs((P * cos (F1) + Q * sin (F1)) * (1 - 0.0048 * W));
    
    *u =  + 0.0059 + 0.0046 * E * cos(M);
    *u += - 0.0182 * cos(Mprime);
    *u += + 0.0004 * cos(Mprime + Mprime);
    *u += - 0.0005 * cos(Mprime + M);
     
    return Mprime;
}