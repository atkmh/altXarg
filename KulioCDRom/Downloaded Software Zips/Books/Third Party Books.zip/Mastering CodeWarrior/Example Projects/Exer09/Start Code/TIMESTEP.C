/*
	timestep.c
	
	Written by James E. Trudeau and
	Copyright  1993-94 Nebula, Inc.
	All Rights Reserved

	timestep.c contains routines for stepping through time
	at various rates.
	
	If you want to step at any value through time, call StepFracDays().
	Pass a lumFlt value for the day and fraction of day you wish to step.
	These values can be positive to advance, or negative to retreat.
	StepFracDays() requires a universal Moment. All other routines
	work with either a standard or universal Moment.
	
	If you want to step a whole number of days, call StepDays(). You
	can pass a positive or negative value for the number of days to 
	step. For example, to step by one week, call StepDays() with the
	value of 7 to advance seven days, or -7 to retreat seven days.
	
	Use StepTime() when the step is < 24 hours in either direction.
	
	If you are advancing one day, month, or year, you can call NextDay(),
	NextMonth(), or NextYear().
	
	If you are retreating one day, month, or year, call PreviousDay(),
	PreviousMonth(), or PreviousYear().
	
	Performance note: the StepTime(), Next(), and Previous() routines
	are extremely fast. The StepFracDays() routine is about 100
	times slower than NextDay(), 400 times slower than PreviousDay().
	Even still, on a Macintosh Quadra 700 10,000 calls to the 
	StepFracDays() routine require < 8 seconds.

*/

#include	"timestep.h"

/*****************************************************************/
/*   StepFracDays  */
/*****************************************************************/

/*
	Requires: universal time moment
              number of days to advance or retreat
    
    Receives: pointer to a universal time Moment
              value by which to step
              
	Changes: values in Moment structure
    
    Returns: nothing
              
    Note! This is the only time advancement routine that requires
          a universal time.
    Note! You can advance or retreat (negative values are acceptable)
          And you can step by a fractional value as well, like 1.5 days
*/

void	StepFracDays (Moment *theTime, lumFlt numberDays)
{	
	lumFlt julianDate = UniversalToJulian(theTime) + numberDays;
	
	if (julianDate < 0)	/* not allowed */
	{
		julianDate = 0;
	}
	
	JulianToUniversal (julianDate, theTime);
}


/*****************************************************************/
/* StepDays */
/*****************************************************************/
/*
	Change date by any number of whole days. In practice you should
	limit this to relatively small numbers because it simply loops
	through calls to NextDay() or PreviousDay(). However, both those
	routines are very fast. StepDays() is intended to periods of up
	to 30 days (like 7 days for stepping a week, 14 days to step two
	weeks, 30 days to step an even increment of 30 days, etc.
	
	The calls to NextDay()/PreviousDay() provide all the calendar date
	error controls. If you step across the October 1582 illegal dates,
	you get the correct number of days in between. Example, if you start
	on 10/2/1582 and step 7 days, the resulting date is 7 days later on
	10/19/1582.
	
	Requires: a Moment structure
	          number of days to step, whole days, + or -
	          
	Receives: pointer to a Moment structure
	          short value for # of days to step
	          
	Changes: values in Moment structure
	
	Returns: nothing
*/

void StepDays (Moment *theTime, short numberDays)
{	

	if(numberDays > 0)
	{
		while(numberDays--)
		{
			NextDay(theTime);
		}
	}
	else if (numberDays < 0)
	{
		while(numberDays++)
		{
			PreviousDay(theTime);
		}
	}

}


/*****************************************************************/
/*   StepTime
/*****************************************************************/
/*
	Step the time field of a Moment record (in either direction)
	Keeps time in range 0 to < 24 hours. This routine assumes that
	the range in the time field is already in that range.
	
	The timeStep parameter is a value of hours and fractional hours
	(e.g. 4.3 = 4 hours, 18 minutes). It must be in range 
	  
	   -24 < timeStep < 24

	If you want to step 24 hours, use NextDay() or PreviousDay().
	
	This routine advances or retreats date correctly in all
	circumstances. It always sets the correct calendar date.
	             
	Requires: a Moment record (standard or universal)
	          the amount of time to step, positive or negative
	
	Receives: a pointer to the Moment structure
	          the value by which to step the time
		
	Changes: contents of Moment structure
	
	Returns: nothing
*/

void	StepTime (Moment *theTime, lumFlt timeStep)

{
	
	theTime->time += timeStep;
	
	if (theTime->time >= 24)
	{
		theTime->time -= 24;	/* keep in range */
		NextDay (theTime);		/* checks for bad date */
	}

	else if (theTime->time < 0)
	{
		theTime->time += 24;
		PreviousDay (theTime);
	}
	else
	{
		BadDate(theTime);	/* make sure time isn't too early */
	}

	TimeToHMS(theTime);		/* set the h,m,s fields */

}	/*  end of TimeRange  */




/*****************************************************************/
/*   NextDay () -- increment day, also month & year if necessary */
/*****************************************************************/
/*
	Sets calendar date to the next day.
	
	Requires: a Moment structure with time in question
	
	Receives: pointer to Moment in need of incrementing
	
	Adjusts the date, also does month and year if necessary
	
	Changes: contents of Moment.
	
	Returns: nothing
*/

void	NextDay (Moment *theTime)

{

	theTime->day += 1;	/* next day */
	
	if (theTime->day > GetMaxDays (theTime->month, theTime->year))	/* out of this month */
	{	
		NextMonth(theTime, kFirstDay);	/*  then it's first day next month  */
	}	

/* make sure we still have a legal date */
	if (BadDate(theTime))
	{
		theTime->day = 15;	/* 10/5-14/1582 did not exist in Gregorian calendar */
	}

	return;
}


/*****************************************************************/
/*    PreviousDay  */
/*****************************************************************/

/*
	Sets calendar date to the previous day.
	
	Requires: a Moment structure with time in question.
	
	Receives: pointer to Moment in need of decrementing
	
	Adjusts the date, also does month and year if necessary
	
	Changes: contents of Moment
	
	Returns: nothing
*/
void	PreviousDay (Moment *theTime)

{		
	theTime->day -= 1;
	
	if(!theTime->day)	/* if day is zero, go to last day, previous month */
	{
		PreviousMonth(theTime, kLastDay);
	}

/* make sure we still have a legal date */
	if (BadDate(theTime))
	{
		theTime->day = 4;	/* 10/5-14/1582 did not exist in Gregorian calendar */
	}

	return;
}


/*****************************************************************/
/* NextMonth() */ 
/*****************************************************************/

/*
	A month is not a standard number of days, and this can cause
	problems stepping through time month by month. When increasing
	or decreasing by a month, the date may become illegal. For
	example, you may decide to call this routine a number of times
	in sequence so the user can step through planetary positions on
	a monthly basis. If the user starts from Jan 30, Feb. 30 does
	not exist.
		
	NextMonth() and PreviousMonth() have a strategy for keeping the 
	day of the month accurate however you step through the months.

	If the user starts on days 1-28, no problem. Pass kCurrentDay as
	the desired day, because every month has numbers 1-28. You can
	also pass the actual day (i.e. a value from 1-28) and you get
	the same end result. However the constant kCurrentDay (value zero)
	is a little more efficient.
	
	If the user starts on the 29th or 30th, pass k29 or k30. You will
	always get either the actual day (29 or 30) or the last day of the
	month in February (28 or 29). On the next step into March you will
	once again get the correct date, either March 29 or 30.
	
	If the user starts on the 31st of a month, pass kLastDay as the.
	desired day. You will always get the last day of the month.

	If you look at the definitions for these constants, you'll see that
	they match the actual value of the day itself. So it's easy to
	remember what to pass. If you are stepping through a series of
	months, when you call either NextMonth() or PreviousMonth(),
	simply pass the value for the original starting date of the step.
	
	Sets calendar month to the next month.
	
	Requires: a Moment structure with time in question
	          a short value indicating what day we want
	          	
	Receives: pointer to Moment in need of incrementing
	          short value indicating what day we want
	
	Adjusts the month, and year if necessary
	
	Changes: contents of Moment
	
	Returns: nothing
*/

void NextMonth (Moment *theTime, short whatDay)
{
	theTime->month += 1;		/* increment the month */
	if(theTime->month>12)		/* must be a new year, too */
	{
		theTime->month = 1;	/* gotta be January */
		theTime->year++;
	}

/* now consider what day to set */
	SetDay(theTime, whatDay);

/* make sure the date is legal */
	if(BadDate(theTime))
	{
		theTime->day = 15;	/* 10/5-14/1582 did not exist in Gregorian calendar */
	}	
}


/*****************************************************************/
/* PreviousMonth() */ 
/*****************************************************************/

/*
	Sets calendar month to the previous month.
	
	Requires: a Moment structure with time in question
	          a short value indicating what day to set
	
	Receives: pointer to Moment in need of decrementing
	          a short value indicating what day we want
	
	Adjusts the month and year if necessary
	
	Changes: contents of Moment
	
	Returns: nothing
*/

void PreviousMonth (Moment *theTime, short whatDay)
{
	
	theTime->month -= 1;		/* decrement the month */
	if(!theTime->month)			/* must be a new year, too */
	{
		theTime->month = 12;	/* gotta be December */
		theTime->year--;
	}

/* now consider what day to set */
	SetDay(theTime, whatDay);
	
/* make sure the date is legal */
	if(BadDate(theTime))
	{
		theTime->day = 4;	/* 10/5-14/1582 did not exist in Gregorian calendar */
	}	
}



/*****************************************************************/
/* NextYear */ 
/*****************************************************************/
/*
	advance date by one year
	
	If perchance the user happens to start a yearly step on Feb. 29,
	we end up switching to Feb 28 for simplicity.
*/

void	NextYear (Moment *theTime)
{
	theTime->year++;
	
	if (theTime->day == 29 && theTime->month == 2)
	{
		theTime->day = 28;	/* guaranteed legal date */
	}

/* make sure the date is legal */
	else if(BadDate(theTime))
	{
		theTime->day = 15;	/* 10/5-14/1582 did not exist in Gregorian calendar */
	}	
}



/*****************************************************************/
/* PreviousYear */ 
/*****************************************************************/
/*
	retreat date by one year
*/

void	PreviousYear (Moment *theTime)
{
	theTime->year--;
	
	if (theTime->day == 29 && theTime->month == 2)
	{
		theTime->day = 28;	/* guaranteed legal date */
	}

/* make sure the date is legal */
	else if(BadDate(theTime))
	{
		theTime->day = 4;	/* 10/5-14/1582 did not exist in Gregorian calendar */
	}	
}



/*****************************************************************/
/* SetDay */ 
/*****************************************************************/

/*
	You never call SetDay() directly. This is an internal routine
	used by NextMonth() and PreviousMonth().
	
*/

void SetDay (Moment *theTime, short whatDay)
{
	short maxDay = GetMaxDays (theTime->month, theTime->year);
	
	switch (whatDay)
	{
		case kCurrentDay:
			if (theTime->day > maxDay)
			{
				theTime->day = maxDay;	
			}
			break;
		
		case kLastDay:
			theTime->day = maxDay;
			break;
			
		case kFirstDay:
			theTime->day = 1;
			break;
			
		case k29:
		case k30:
			if (maxDay < whatDay)
			{
				theTime->day = maxDay;
			}
			else
			{
				theTime->day = whatDay;
			}
			break;
			
		default:	/* do nothing for other days */
			break;
	}
}


/*****************************************************************/
/*   GetMaxDays
/*****************************************************************/
/*
	Utility routine that tells you max # of days in any month
	
	Requires: a month and year
	
	Receives: month in question
	          year in question
	          
	Changes: nothing
	
	Returns: short value for # of days in that month
*/

short	GetMaxDays (short month, short year)

{
	short	maxDays = 31;	/* default value */

	switch (month)
	{	
		case 4:
		case 6:
		case 9:
		case 11:
			maxDays = 30;
			break;
			
		case 2:
			if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
				maxDays = 29;	/*   if it's a leap year  */
			else
				maxDays = 28;
			break;
		
	}	/*  end switch  */

	return maxDays;
}


/*****************************************************************/
/* BadDate */ 
/*****************************************************************/

/*
	examine date in time record for two faults: too early or
	Oct. 5-14 1582, inclusive.
	
	If date too early, set it to earliest date. Return no error.
	This limits program to earliest date, Jan 1, -4712 (which, because
	this library uses year zero, is equivalent to 1/1/4713 BC Gregorian.
	
	Strictly speaking, you should use this with a universal time, because
	a standard time may pass this test, but when converted to universal
	will fail. However, in practice you can use this routine on either
	standard or universal times for any date from 1/2/-4712 on up.
	
	If date is in Oct. 1582, return error. Calling routine will
	know whether to set date to 4 or 15 Oct, 1582. Depends what
	direction we're going in.
	
	Requires: a Moment
	
	Receives: pointer to a Moment
	
	Changes: Will change values in moment only if moment is too soon
	
	Returns: short value, true (non-zero) = bad date
*/

short BadDate (Moment *theTime)
{

	if (theTime->year == 1582 && theTime->month == 10
	          && theTime->day > 4 && theTime->day < 15)
	{
		return 1;
	}
	
	if( theTime->year < -4712 || 
	   (theTime->year == -4712 && theTime->month == 1 &&
	    theTime->day == 1 && theTime->time < 12.0))
	{
		theTime->year = -4712;
		theTime->month = 1;
		theTime->day = 1;
		theTime->hour = 12;
		theTime->minute = 0;
		theTime->second = 0;
		theTime->time = 12.0;
	}
	if (theTime->year > 12000)
	{
		theTime->year = 12000;
		theTime->month = 12;
		theTime->day = 31;
		theTime->hour = 23;
		theTime->minute = 59;
		theTime->second = 59;
		HMSToTime(theTime);
	
	}
	return 0;
}


/*****************************************************************/
/* HMSToTime */
/*****************************************************************/
/*
	Sets time field of Moment record to lumFlt value based on
	the hour, minute, second fields of the same record.
	
	Result is always in range 0-23.99 hours
	
	Requires: Moment in question
	
	Receives: pointer to Moment
	
	Uses internal fields to calculate value
	
	Changes: the time field of the Moment, no other changes
	
	Returns: nothing
*/

void HMSToTime	(Moment *theTime)
{
	theTime->time = (lumFlt) theTime->hour + 
	                theTime->minute/60.0 +
	                theTime->second/3600.0;
}


/*****************************************************************/
/*   TimeToHMS */
/*****************************************************************/

/*
	Set the values of the hour, minute, second fields of Moment structure
	based on value in the time field. This is the converse of the
	HMSToTime() routine.
	
	Requires: the time field in Moment in range 0-23.9999 hours

	Receives: pointer to Moment record being set
		
	Changes: the hour, minute, second values in the Moment record
	
	Note! Advances date if rounding puts it to the next day

*/

void	TimeToHMS	(Moment *theTime)

{
	short	hour, minute, second;
	lumFlt	currentTime;
		
	currentTime = theTime->time;
	
	hour = (short) currentTime;
	currentTime = (currentTime - hour) * 60;

	minute = (short) currentTime;
	second = (short)((currentTime - minute) * 60 + .5);

	if (second == 60)
	{	/* add a minute */
		second = 0;
		minute +=1;
		if (minute == 60)
		{	/*add an hour */
			minute = 0;
			hour += 1;
			if (hour == 24)
			{	/*add a day */
				hour = 0;
				NextDay(theTime);
	}	}	}

	theTime->hour = hour;
	theTime->minute = minute;
	theTime->second = second;
}
	

/*****************************************************************/
/* HMSToFractional */ 
/*****************************************************************/
/*
	Convert hours, minutes, seconds into the fraction of a day
	
	This routine is not actually used anywhere in the library per se.
	It is provided to keep symmetry in the conversion routines, and
	because it may be of some use to you in some circumstances.
	
	Requires: a Moment
	
	Receives: a pointer to a Moment
	
	Changes: nothing
	
	Returns: lumFlt value (range 0 to < 1)
*/

lumFlt	HMSToFractional (Moment *theTime)
{
	return ( (theTime->hour + theTime->minute/60.0 + theTime->second/3600.0)/24.0);
}



/*****************************************************************/
/*  FractionalToHMS - convert decimal fraction to hour, minute, second
/*****************************************************************/

/*
	Converts a decimal part of a day into hour, minute, second
	
	Requires: value of fracDay in range 0 to < 1
	
	Receives: the actual fraction of a day, fracDay, range 0-.9999
	          pointer to a Moment structure

	Changes: the hour, minute, second values in the Moment record
	rounds them to the nearest second

	Returns: a short indicating whether the day must advance
	(i.e. the rounding rounded up to 24 hours, zero minutes, zero seconds)
	return TRUE (!0) if advancing a day, false if not
*/

short	FractionalToHMS	(lumFlt fracDay, Moment *theMoment)

{
	short	result = 0;	/* false */
	short	hour, minute, second;
	
	fracDay *= 24;
	hour = (short) fracDay;
	fracDay = (fracDay - hour) * 60;

	minute = (short) fracDay;
	second = (short)((fracDay - minute) * 60 + .5);

	if (second == 60)
	{	/* add a minute */
		second = 0;
		minute +=1;
		if (minute == 60)
		{	/*add an hour */
			minute = 0;
			hour += 1;
			if (hour == 24)
			{	/*add a day - return TRUE, adding done by calling routine */
				hour = 0;
				result = 1;	/* true */
	}	}	}

	theMoment->hour = hour;
	theMoment->minute = minute;
	theMoment->second = second;

	return result;
}