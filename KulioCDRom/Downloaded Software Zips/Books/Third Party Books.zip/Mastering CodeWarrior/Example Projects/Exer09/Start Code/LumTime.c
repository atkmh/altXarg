/*
	Time.c
	
	Written by James E. Trudeau and
	Copyright  1993-94 Nebula, Inc.
	All Rights Reserved

	Time.c contains time calculation and conversion routines	
*/



#include	"lumtime.h"
#include	"timestep.h"

/*****************************************************************/
/* DATA */
/*****************************************************************/


/*
	Values used to calculate difference between universal and 
	dynamical time, a value known as deltaT.

    values in tenths of seconds for years 1620-2000, 2yr. intervals

*/

const short gDeltaT[191] =
{
 1240, 1150, 1060, 980, 910, 850, 790, 740, 700, 650, 
  620, 580, 550, 530, 500, 480, 460, 440, 420, 400, 
  370, 350, 330, 310, 280, 260, 240, 220, 200, 180, 
  160, 140, 130, 120, 110, 100,  90,  90,  90,  90, 
   90,  90,  90,  90, 100, 100, 100, 100, 100, 110, 
  110, 110, 110, 110, 110, 110, 110, 120, 120, 120,
  120, 120, 130, 130, 130, 130, 140, 140, 140, 150,
  150, 150, 150, 160, 160, 160, 160, 160, 170, 170,
  170, 170, 170, 170, 170, 170, 160, 160, 150, 140,
  137, 131, 127, 125, 125, 125, 125, 125, 125, 123,
  120, 114, 106,  96,  86,  75,  66,  60,  57,  56, 
   57,  59,  62,  65,  68,  71,  73,  75,  77,  78,
   79,  75,  64,  54,  29,  16, -10, -27, -36, -47,
  -54, -52, -55, -56, -58, -59, -62, -64, -61, -47,
  -27,   0,  26,  54,  77, 105, 134, 160, 182, 202,
  212, 224, 235, 239, 243, 240, 239, 239, 237, 240,
  243, 253, 262, 273, 282, 291, 300, 307, 314, 322,
  331, 340, 350, 365, 383, 402, 422, 445, 465, 485,
  505, 522, 538, 549, 558, 569, 581, 593, 605, 617, 630
};


/*****************************************************************/
/* ROUTINES */
/*****************************************************************/


/*****************************************************************/
/* TFromUniversal */
/*****************************************************************/
/*
	Handler to call all routines nececessary to get T from
	universal time.

	Requires: a BasicData structure, with correct universal time
	
	Receives: pointer to a BasicData structure
	
	Changes: the value of T in BasicData structure
	         BasicData remains otherwise unaffected
	
	Returns: nothing	
*/

void	TFromUniversal		(BasicData *theFacts)
{
	lumFlt	jDate;			/* Julian date (universal time) */
	lumFlt	dDate;			/* dynamical date */
	
	Moment	*universalTime = &(theFacts->universalTime);
	
	jDate = UniversalToJulian(universalTime);

	dDate = jDate + CalcDeltaT(universalTime, jDate); 
	
	theFacts->universalT = JulianToT(jDate);
	theFacts->T = JulianToT(dDate);

}


/*****************************************************************/
/* UniversalFromT */
/*****************************************************************/
/*
	Handler to call routines to convert from a T to a universal time.
	This is the converse of TFromUniversal().
	
	Requires: BasicData structure with T correctly set
	
	Receives: pointer to BasicData structure
	
	Changes: BasicData->universalTime
	
	Returns: nothing

*/

void	UniversalFromT (BasicData *theFacts)

{
	lumFlt 	jDate, dDate;
	lumFlt	T = theFacts->T;

	Moment	*universalTime = &(theFacts->universalTime);
	
	dDate = TToJulian (T);
	JulianToUniversal (dDate, universalTime);
	jDate = dDate - CalcDeltaT(universalTime, dDate);

/*
	 ignore the fact that we're actually calculating deltaT for a moment
	 just a tad later than we should, difference is trivial
*/

	JulianToUniversal (jDate, universalTime);	/* no way around calling it twice */
	
}



/*****************************************************************/
/* StandardToUniversal */
/*****************************************************************/

/*
	Convert a STANDARD time to a universal time. You must correct for
	daylight savings time if necessary before calling this routine.
	
	Requires: a fully initialized Moment structure with standard time
	          Moment must have correct time zone and lumFlt value for time
	
	Receives: pointer to existing standard time Moment
	          pointer to universal time Moment to be initialized
	
	Changes: values in ut structure
	
	Returns: nothing
*/

void	StandardToUniversal	(Moment *standard, Moment *ut)
{	

	*ut = *standard;	/* for starters, memberwise initialization */

	ut->zone = 0;		/* initialize zone to zero for UT */
				
	StepTime(ut, standard->zone);	/* adjust time */
	

}

/*****************************************************************/
/* UniversalToStandard */
/*****************************************************************/

/*
	Convert a universal time to STANDARD time. This is the converse of
	StandardToUniversal().
	
	Requires: a fully initialized Moment structure with universal time
	          a Moment structure to receive the standard time. This must
	          have the time zone correction set correctly.
	       	
	Receives: pointer to existing universal time record
	          pointer to standard time Moment to be initialized

	NOTE!!!	Standard time must have correct time zone in place already
	
	Changes: values in standard Moment structure
	
	Returns: nothing	
*/

void	UniversalToStandard	(Moment *ut, Moment *standard)
{	

	lumFlt timeZone;
	
	timeZone = standard->zone;	/* preserve this value!!! */
	*standard = *ut;			/* wipes time zone!!! */
	standard->zone = timeZone;	/* restore time zone */		
	
	StepTime(standard, -timeZone);	/* adjust time */
	

}



/*****************************************************************/
/* UniversalToJulian */
/*****************************************************************/

/*
	Convert a universal gregorian Moment to a Julian date
	Julian date is of the form nnnn.nnnn where the integer is the whole
	number of days and the decimal is the fractional day (range 0-.999).
	Algorithm from Astronomical Algorithms by Meeus.
	
	For Julian dates, need only keep the lumFlt value. No need for month, day,
	year, hour, minute, second. So this routine calculates and returns the lumFlt.

	Note! this routine requires that the Moment be filtered for correctness.
	      Date must be a real date: No February 30 allowed.
	      Date must not be between Oct. 4 and 15, 1582. Dates from 10/5/1582 to
	        10/14/1582 inclusive result in Julian dates for the Gregorian date
	        11 days later.
	      Date must not be too early. We cannot use Julian dates less than zero.
	      Minimum calendar universal date is: Jan 1, 4713 BC, at noon.
	      
	      In fact that means the earliest date is 1/1/-4712. See note below
	      for explanation of year zero.

	
	IMPORTANT NOTE!!! The astronomy library assumes that the user IS
	    using the year zero. In normal calendar use, there is no year
	    zero, we go from 1 BC to 1AD.
	    
	    However, this algorithm DOES use the year zero to allow for a 
	    mathematically consistent progression of days.
	    
	    This means that if you have a Gregorian calendar BC date, you should
	    add one year to it to get the correct Julian date.
	    
	    Example: In the calendar, May 13, 452 BC should be passed to this
	    routine as 05 for month, 15 for day, and -451 for year. Note that
	    leap years are therefore calendar years like -5, -9, -13 because
	    in here those years are -4, -8, 12.
	    	    
	    You can deal with this two ways. First, in any application you
	    create using this library, clearly inform the user about the
	    year zero problem and how you handle it. If you require the user
	    to enter dates based on year zero, you require the user to adjust
	    the BC date. In that case, when the user enters 4BC she means 4BC
	    when there is a year zero, (the equivalent of 5BC Gregorian.
	    
	    Or you can automatically convert any BC date the user provides
	    by adding one before calling any library routines, and then subtracting
	    one from the result if the year is <= 0. Then the user can use
	    calendar dates. However, in this approach Feb. 29, 5 BC is a
	    legal date and Feb 29, 4 BC is not.

	Requires: a Moment structure with the correct universal time.
	
	Receives: pointer to a Moment record with the correct universal time

	Changes: nothing
	
	Returns a lumFlt for the precise Julian date
	
*/

lumFlt	UniversalToJulian	(Moment *theUTDate)
{

	short	year, month;
	lumFlt	day;
	lumFlt	julianDay;
	short	A;
	short	B = 0;	/*  default for non-Gregorian calendar  */
	
	year  = theUTDate->year;
	month = theUTDate->month;  
	day  = (lumFlt) theUTDate->day + theUTDate->time/24;

	if (month < 3)
	{
		year --;
		month +=12;
	}
	
	if (year > 1582  || (year == 1582 && month > 10) ||
		 (year == 1582 && month == 10 && day >= 15))	    
	{	/*  if date is on or after Oct. 15, 1582, Gregorian calendar */
		A = (short) (year/100);
		B = (short) (2 - A + (short)(A/4));
	}
	
	
	julianDay = (long)(365.25 * (year + 4716)) +
	            (long)(30.6001 * (month + 1)) +
	            day + B - 1524.5;	

	return julianDay;
	
}	/*  end of UniversalToJulian  */



/*****************************************************************/
/* JulianToUniversal */
/*****************************************************************/
/*  
	Converts a given Julian date to the corresponding calendar date
	in universal time. Algorithm from Astronomical Algorithms by Meeus.
	
	This routine is the converse of UiversalToJulian().
	
	Julian days begin at noon UT. This routine sets the correct
	calendar date. i.e. if Julian date is >nnn.5 (midnight) the
	next date is returned.
	
	Routine correctly converts Julian day to 10/4/1582 and then
	10/15/1582. i.e. routine does not return dates that did not
	exist in the Gregorian calendar, but does use year zero.
	
	Rounds second to nearest value, updates minute, hour, day, month,
	year correctly if rounding the second affects higher values.
	
	Requires: a Julian date >= 0.
	   
	Receives: the precise Julian date
	          a pointer to a Moment record

	Changes: all values in the Moment record: year, month, day, hour,
	   minute, and second, and time. Result is a universal Moment.
	   
	Returns: nothing
	
*/

void	JulianToUniversal (lumFlt jDate, Moment *theMoment)
{
	long	alpha,A,B,C,D,E,Z;
	lumFlt	fracDay;

	jDate += .5;			/* correct for Julian day starting at noon */
	Z = (long) jDate;		/* integer part */
	fracDay = jDate - Z;	/* fractional part of day; */
	
/*
	note, the FractionalToHMS() routine sets the hour, minute, second fields
	of the Moment, returns TRUE if rounding to the nearest second
	results in advancing to a new day
*/
/*  determine hour, minute and second first, for rounding  */
	if (FractionalToHMS (fracDay, theMoment))
	{
		Z +=1;
	}

/*  determine calendar date  */		
    if (Z >= 2299161)
	{
		alpha = (long)((Z - 1867216.25)/36524.25);
		A = Z + 1 + alpha - (long)(alpha/4);
	}
	else
	{
		A = Z;
	}

	B = A + 1524;
	C = (long) ((B-122.1)/365.25);
	D = (long) (365.25 * C);
	E = (long) ((B-D)/30.6001);
	
	theMoment->day   = B - D - (short) (30.6001 * E);
	theMoment->month = (E <= 13) ? E - 1 : E - 13;
	theMoment->year  = (theMoment->month >=3) ? C - 4716 : C - 4715;
	
	HMSToTime(theMoment);

}


/*****************************************************************/
/*  CalcDeltaT - calculate change for dynamical time for UT moment
/*****************************************************************/

/*
	Determines value of deltaT - the difference between universal
	time and dynamical time.
	Uses various algorithms from Astronomical Algorithms by Meeus.
	
	Algorithm for calculating deltaT depends on what year we're talking
	about.
	
	Requires: Julian date based on a universal time
	          the corresponding Moment structure in universal time

	Receives: pointer to Moment for universal time
	          the Julian date
	          
	Changes: nothing
	
	Returns: lumFlt value for deltaT. Returned value is a fraction
	of a day by which to adjust the initial time.
	
*/

lumFlt	CalcDeltaT	(Moment *theMoment, lumFlt jDate)
{
	lumFlt	T;			/* centuries from epoch 2000.0 Julian (not dynamical) */
	lumFlt	deltaT;		/* seconds diff betwen UT and DT */
	lumFlt	year;
	short	index;
	
	T = JulianToT(jDate);	/* centuries from epoch in Julian, not dynamical */
	
/* before 948 AD */
	if (theMoment->year < 948)
	{
		deltaT = 2715.6 + T * (573.36 + T * 46.5);
	}

/* 948-1619 AD	 */
	else if (theMoment-> year < 1620)
	{
		deltaT = 50.6 + T * (67.5 + T * 22.5);
	}
	
/* 1620-1999 */
	else if (theMoment->year < 2000)
	{	/* use table of known values */
		/* values in table are in seconds * 10 so we can use shorts */

		year = (2000 + T * 100 - 1620); 	/* range 0-379.99 */
		index = (short) (year/2);			/* range 0-189 */
		
		deltaT = gDeltaT[index+1] - gDeltaT[index];  /*change in two years */
		deltaT = (gDeltaT[index] + (year - index * 2) * deltaT) * .1; 		
	}

/* year 2000 AD and on	 */
	else
	{	/* based on formula for 948-1600, strictly a guess */
		/* advances 67.5 seconds/century + 22.5 seconds/century squared */
		deltaT = 63.0 + 67.5 * T + 22.5 * T * T;
	}

	return deltaT/86400.0;	/* fraction of a day */
}


/*****************************************************************/
/*  JulianToT - calculate centuries from epoch 2000.0
/*****************************************************************/

/*
	In the astronomy library most calculations use the value of T.
	T is the number of Julian centuries from epoch Jan 1 2000 at noon.
	Usually this is in dynamical time, but could be universal time.
	Universal time is used for sidereal time calculations.
	
	Requires: Julian date (including fraction of day for time)
	
	Receives: precise Julian date (usually in dynamical time)
	
	Changes: nothing
	
	Returns: lumFlt value for precise T
*/


lumFlt	JulianToT	(lumFlt jDate)
{
	return (jDate - kEpoch)/36525;
}


/*****************************************************************/
/* TToJulian */
/*****************************************************************/

/*
	Get Julian date from the value of T. This is the converse of
	JulianToT().
	
	Requires: the value of T
	
	Receives: T in Julian centuries
	
	Changes: nothing
	
	Returns: Julian Epehemris date (i.e. dynamical Jdate)
*/

lumFlt 	TToJulian (lumFlt T)
{
	return T * 36525 + kEpoch;
}
