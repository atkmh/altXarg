/*
	Written by James E. Trudeau and
	Copyright  1993-94 Nebula, Inc.
	All Rights Reserved
	
	Various math routines for astronomy framework
*/


#include	"utility.h"

/*****************************************************************/
/* R O U T I N E S */
/*****************************************************************/


/*****************************************************************/
/*  RadianRange - keep angle in radians in range 0 to < 2pi
/*****************************************************************/

lumFlt	RadianRange (lumFlt angle)
{
	angle -= (long) (angle/kTwoPi) * kTwoPi;
	if (angle < 0) angle += kTwoPi;
	return (angle);
}


/*****************************************************************/
/*  DegreeRange - keep angle in degrees in range 0 < 360
/*****************************************************************/

lumFlt	DegreeRange	(lumFlt angle)
{
	
	angle -= (long) (angle/360) * 360;
	if (angle <0) angle += 360;
	return angle;
}


/*****************************************************************/
/*  PiRange - keep an angle in radians in range -pi to + pi
/*****************************************************************/

lumFlt	PiRange (lumFlt angle)
{
	if (angle < -kPi)
		return (angle + kTwoPi);
	if (angle > kPi)
		angle -= kTwoPi;
	return angle;
}


/*****************************************************************/
/*  Modulo - does modulo division on lumFlt variables, returns integer part
/*****************************************************************/

lumFlt Modulo (lumFlt value, short divisor)
{
	value -= (long) (value/divisor) * divisor;
	if (value < 0) value += divisor;
	return value;
}	/*  returns value range 0 to < divisor  */
