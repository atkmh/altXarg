/*
	Written by James E. Trudeau and
	Copyright  1993-94 Nebula, Inc.
	All Rights Reserved

	6/6/94

*/

#ifndef _TIME_
#define _TIME_



#include	"luminary.h"


/*****************************************************************/
/* PROTOTYPES */
/*****************************************************************/

void	TFromUniversal		(BasicData *theFacts);
void	UniversalFromT	 	(BasicData *theFacts);

void	StandardToUniversal	(Moment *std, Moment *ut);
void	UniversalToStandard	(Moment *ut, Moment *standard);

lumFlt	UniversalToJulian	(Moment *ut);
void	JulianToUniversal 	(lumFlt julian, Moment *ut);

lumFlt	CalcDeltaT			(Moment *ut, lumFlt jDate);
lumFlt	JulianToT			(lumFlt jDate);
lumFlt 	TToJulian			(lumFlt T);

#endif