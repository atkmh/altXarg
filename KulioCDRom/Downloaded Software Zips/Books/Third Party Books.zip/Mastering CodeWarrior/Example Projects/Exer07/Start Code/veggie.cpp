# include <stdio.h>
# include "veggie.h"


CVeggie::CVeggie ()
{
}


CVeggie::CVeggie(char *n, char *c, int a, int pr ) 
: CProduce( n, c, a, pr)
{

} 



void CVeggie::Show(void)
{
	printf ("The Vegetable is called %s and its color is %s.\n", sName, sColor);
	printf ("We have %d on hand at $%d.00 per pound.\n\n", amt,price);
}


