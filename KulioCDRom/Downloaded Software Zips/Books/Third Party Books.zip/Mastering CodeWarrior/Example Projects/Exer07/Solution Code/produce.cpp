// #include <string.h>
// #include "produce.h"

// default constructor

CProduce::CProduce ()
{

}


// initializing constructor
CProduce::CProduce (char *n, char *c, int a, int pr)
{
	strcpy(sName,n);
	strcpy(sColor,c);
	amt = a;
	price = pr;
}


// List for dynamic allocation
void
CProduce::List(char *n, char *c, int a, int pr )
{ 
	strcpy(sName,n);
	strcpy(sColor,c);
	amt = a;
	price = pr;
}
