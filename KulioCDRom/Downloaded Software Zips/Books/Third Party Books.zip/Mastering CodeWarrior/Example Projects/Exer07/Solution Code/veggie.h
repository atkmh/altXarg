// #include "produce.h"


#ifndef _VEGGIE_

#define _VEGGIE_

// The Veggie class overrides Show


class CVeggie: public CProduce {

public:
	CVeggie();	// constructors
	CVeggie (char *n, char *c, int a, int pr );

	// display results
	virtual void Show(void);

};

class CLettuce: public CVeggie {

	CLettuce();	// constructors
	CLettuce(char *n, char *c, int a, int pr );

};


class CPea: public CVeggie {

	CPea();	// constructors
	CPea(char *n, char *c, int a, int pr );

};


class CBean: public CVeggie {

	CBean();	// constructors
	CBean(char *n, char *c, int a, int pr );

};


class CCorn: public CVeggie {

	CCorn();	// constructors
	CCorn(char *n, char *c, int a, int pr );

};



#endif