// The fruit class inherits from CProduce and overrides
// the Show() behavior

// #include <stdio.h>
// #include "fruit.h"

CDessert::CDessert ()
{
}

CFruit::CFruit ()
{
}


CFruit::CFruit(char *n, char *c, int a, int pr ) 
: CProduce( n, c, a, pr)
{

} 


void CFruit::Show(void)
{
	printf ("The fruit is called %s and its color is %s.\n", sName, sColor);
	printf ("We have %d on hand at $%d.00 per pound.\n\n", amt,price);
}
