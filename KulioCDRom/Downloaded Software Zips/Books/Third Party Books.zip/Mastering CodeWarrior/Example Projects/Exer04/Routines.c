/**************************************************
File: Routines.c
Author: Jim Trudeau
Date: 10/31/96 - BOO!

Rev history: 
**************************************************/

// prototypes for the routines in this file
#include "Routines.h"

// for printf calls
#include <stdio.h>
 


/*
	PrintLineTwo - displays another line in the
	console window.
*/

void PrintLineTwo (void)
{
	printf ("I'm printing in a subroutine.\n");	
}

/*
	PrintRepeater - print several lines in the
	console window.
*/

void PrintRepeater (void)
{
	short n;
	
	for (n = 1; n <= 5; n++)
	{
		printf ("I'm printing in a loop, iteration %d\n", n);
	
	}
}

/*
	IdleAwayTheTime - a loop that does nothing
*/

void IdleAwayTheTime ()
{
	short n;
	
	for (n = 0; n <1000; n++)
	{
		// do nothing
	}
}