#include <stdlib.h>
#include <stdio.h>
#include "cdFiler.h"

/*********************************************> WriteFile <*/
void	WriteFile( void )
{
	FILE			*fp;
	struct CDInfo	*infoPtr;
	int				num;
	
	if ( gFirstPtr == NULL )
		return;
	
	if ( ( fp = fopen( kCDFileName, "w" ) ) == NULL )
	{
		printf( "***ERROR: Could not write CD file!" );
		return;
	}
	
	for ( infoPtr=gFirstPtr; infoPtr!=NULL; infoPtr=infoPtr->next )
	{
		fprintf( fp, "%s\n", infoPtr->artist );
		fprintf( fp, "%s\n", infoPtr->title );

		num = infoPtr->rating;
		fprintf( fp, "%d\n", num );
	}
	
	fclose( fp );
}


/*********************************************> ReadFile <*/
void	ReadFile( void )
{
	FILE			*fp;
	struct CDInfo	*infoPtr;
	int				i;
	
	if ( ( fp = fopen( kCDFileName, "r" ) ) == NULL )
	{
		printf( "***ERROR: Could not read CD file!" );
		return;
	}
	
	do
	{
		infoPtr = malloc( sizeof( struct CDInfo ) );
		
		if ( infoPtr == NULL )
		{
			printf( "Out of memory!!!  Goodbye!\n" );
			exit( 0 );
		}
	}
	while ( ReadStructFromFile( fp, infoPtr ) );
	
	fclose( fp );
	free( infoPtr );
}


/************************************> ReadStructFromFile <*/
char	ReadStructFromFile( FILE *fp, struct CDInfo *infoPtr )
{
	int		num;
	
	if ( fscanf( fp, "%[^\n]\n", infoPtr->artist ) != EOF )
	{
		if ( fscanf( fp, "%[^\n]\n", infoPtr->title ) == EOF )
		{
			printf( "Missing CD title!\n" );
			return false;
		}
		else if ( fscanf( fp, "%d\n", &num ) == EOF )
		{
			printf( "Missing CD rating!\n" );
			return false;
		}
		else
		{
			infoPtr->rating = num;
			AddToList( infoPtr );
			return true;
		}
	}
	else
		return false;
}
