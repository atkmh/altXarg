#include <stdlib.h>
#include <stdio.h>
#include "cdFiler.h"


/***********************/
/* Global Definitions */
/***********************/
struct CDInfo	*gFirstPtr, *gLastPtr;


/**************************************************> main <*/
int	main( void )
{
	char			command;
	
	gFirstPtr = NULL;
	gLastPtr = NULL;
	
	ReadFile();
	
	while ( (command = GetCommand() ) != 'q' )
	{
		switch( command )
		{
			case 'n':
				AddToList( ReadStruct() );
				break;
			case 'l':
				ListCDs();
				break;
		}
	}
	
	WriteFile();
	
	printf( "Goodbye..." );

	return 0;
}


/*******************************************> GetCommand <*/
char	GetCommand( void )
{
	char	command;
	
	do 
	{
		printf( "Enter command (q=quit, n=new, l=list):  " );
		scanf( "%c", &command );
		Flush();
	}
	while ( (command != 'q') && (command != 'n')
					&& (command != 'l') );
	
	printf( "\n----------\n" );
	return( command );
}


/*******************************************> ReadStruct <*/
struct CDInfo	*ReadStruct( void )
{
	struct CDInfo	*infoPtr;
	int				num;
	
	infoPtr = malloc( sizeof( struct CDInfo ) );
	
	if ( infoPtr == NULL )
	{
		printf( "Out of memory!!!  Goodbye!\n" );
		exit( 0 );
	}
	
	printf( "Enter Artist's Name:  " );
	gets( infoPtr->artist );
	
	printf( "Enter CD Title:  " );
	gets( infoPtr->title );
	
	do
	{
		printf( "Enter CD Rating (1-10):  " );
		scanf( "%d", &num );
		Flush();
	}
	while ( ( num < 1 ) || ( num > 10 ) );
	
	infoPtr->rating = num;
	
	printf( "\n----------\n" );
	
	return( infoPtr );
}


/*******************************************> AddToList <*/
void	AddToList( struct CDInfo *curPtr )
{
	if ( gFirstPtr == NULL )
		gFirstPtr = curPtr;
	else
		gLastPtr->next = curPtr;
	
	gLastPtr = curPtr;
	curPtr->next = NULL;
}


/*******************************************> ListCDs <*/
void	ListCDs( void )
{
	struct CDInfo	*curPtr;
	
	if ( gFirstPtr == NULL )
	{
		printf( "No CDs have been entered yet...\n" );
		printf( "\n----------\n" );
	}
	else
	{
		for ( curPtr=gFirstPtr; curPtr!=NULL; curPtr = curPtr->next )
		{
			printf( "Artist:  %s\n", curPtr->artist );
			printf( "Title:   %s\n", curPtr->title );
			printf( "Rating:  %d\n", curPtr->rating );
	
			printf( "\n----------\n" );
		}
	}
}


/*******************************************> Flush <*/
void	Flush( void )
{
	while ( getchar() != '\n' )
		;
}