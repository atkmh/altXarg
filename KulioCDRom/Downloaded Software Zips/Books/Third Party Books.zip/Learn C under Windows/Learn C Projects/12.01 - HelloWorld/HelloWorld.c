#include <windows.h>

LRESULT CALLBACK WndProc (HWND hWnd, UINT iMessage, 
				WPARAM wParam, LPARAM lParam);

//**************************************************************
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
				LPSTR lpCmdLine, int nCmdShow)
{
     static char szAppName[] = "HelloWorld";
     HWND        hWnd ;
     MSG         message ;
     WNDCLASSEX  wndclass ;

     wndclass.cbSize        = sizeof (wndclass);
     wndclass.style         = CS_HREDRAW | CS_VREDRAW;
     wndclass.lpfnWndProc   = WndProc;
     wndclass.cbClsExtra    = 0;
     wndclass.cbWndExtra    = 0;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
     wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
     wndclass.hbrBackground = (HBRUSH)GetStockObject (WHITE_BRUSH);
     wndclass.lpszMenuName  = NULL;
     wndclass.lpszClassName = szAppName;
     wndclass.hIconSm       = LoadIcon (NULL, IDI_APPLICATION);

     RegisterClassEx (&wndclass);

     hWnd = CreateWindow (szAppName,         // class name
                   "Hello World",            // caption
                    WS_OVERLAPPEDWINDOW,     // style
                    CW_USEDEFAULT,           // x position
                    CW_USEDEFAULT,           // y position
                    CW_USEDEFAULT,           // x size
                    CW_USEDEFAULT,           // y size
                    NULL,                    // parent window handle
                    NULL,                    // window menu handle
                    hInstance,               // program instance handle
                    NULL) ;                  // creation parameters

     ShowWindow(hWnd, nCmdShow);
     UpdateWindow(hWnd);

     while ( GetMessage(&message, NULL, 0, 0) )
     {
          TranslateMessage(&message);
          DispatchMessage(&message);
     }
     
     return message.wParam;
}

//**************************************************************
LRESULT CALLBACK WndProc (HWND hWnd, UINT iMessage, 
				WPARAM wParam, LPARAM lParam)
{
     HDC         hdc;
     PAINTSTRUCT ps;
     RECT        rect;

     switch ( iMessage )
          {
          case WM_CREATE:
               return 0;

          case WM_PAINT :
	           hdc = BeginPaint( hWnd, &ps );

               GetClientRect( hWnd, &rect );

               DrawText(hdc, "Hello World", -1, &rect,
                   DT_SINGLELINE | DT_CENTER | DT_VCENTER);

	       EndPaint(hWnd, &ps);
               return 0;

          case WM_DESTROY:
               PostQuitMessage(0);
               return 0;
          }

     return DefWindowProc( hWnd, iMessage, wParam, lParam );
}
