#include <stdio.h>

#define true 1
#define false 0

#define kMaxCDs				300
#define kMaxArtistLength	50


/***********************/
/* Function Prototypes */
/***********************/
void	ReadLine( char *line );
void	Flush( void );
void	PrintArtists( short numArtists, 
			char artist[][ kMaxArtistLength + 1 ] );


/**************************************************> main <*/
int	main( void )
{
	char	artist[ kMaxCDs ][ kMaxArtistLength + 1 ];
	short	numArtists;
	char	doneReading;
	
	printf( "The artist array takes up %ld bytes of memory.\n\n", 
				sizeof( artist ) );
	
	doneReading = false;
	numArtists = 0;
	
	while ( ! doneReading )
	{
		printf( "Artist #%d (return to exit): ", numArtists+1 );
		ReadLine( artist[ numArtists ] );
		
		if ( artist[numArtists][0] == '\0' )
			doneReading = true;
		else
			numArtists++;
	}
	
	printf( "----\n" );
	
	PrintArtists( numArtists, artist );
	
	return 0;
}


/**************************************************> ReadLine <*/
void	ReadLine( char *line )
{
	char 	c;
	short	numCharsRead;
	
	numCharsRead = 0;
	
	while ( ((c = getchar()) != '\n') &&
		(++numCharsRead <= kMaxArtistLength))
	{
		*line = c;
		line++;
	}
	
	*line = 0;
	
	if ( numCharsRead > kMaxArtistLength )
		Flush();
}


/**************************************************> Flush <*/
void	Flush( void )
{
	while ( getchar() != '\n' )
		;
}


/**************************************************> PrintArtists <*/
void	PrintArtists( short numArtists,
			char artist[][ kMaxArtistLength + 1 ] )
{
	short	i;
	
	if ( numArtists <= 0 )
	{
		printf( "No artists to report.\n" );
		return;
	}
	else
	{
		for ( i=0; i<numArtists; i++ )
			printf( "Artist #%d: %s\n",
				i+1, artist[i] );
	}
}
