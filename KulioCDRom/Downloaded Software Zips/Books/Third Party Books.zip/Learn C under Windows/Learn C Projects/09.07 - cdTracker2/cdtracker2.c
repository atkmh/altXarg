#include <stdlib.h>
#include <stdio.h>
#include "cdTracker2.h"


/**************************************************> main <*/
int	main( void )
{
	char			command;
	
	gFirstPtr = NULL;
	gLastPtr = NULL;
	
	while ( (command = GetCommand() ) != 'q' )
	{
		switch( command )
		{
			case 'n':
				AddToList( ReadStruct() );
				break;
			case 'l':
				ListCDs();
				break;
		}
	}
	
	printf( "Goodbye..." );
	
	return 0;
}


/*******************************************> GetCommand <*/
char	GetCommand( void )
{
	char	command;
	
	do 
	{
		printf( "Enter command (q=quit, n=new, l=list):  " );
		scanf( "%c", &command );
		Flush();
	}
	while ( (command != 'q') && (command != 'n')
					&& (command != 'l') );
	
	printf( "\n----------\n" );
	return( command );
}


/*******************************************> ReadStruct <*/
struct CDInfo	*ReadStruct( void )
{
	struct CDInfo	*infoPtr;
	int				num;
	
	infoPtr = malloc( sizeof( struct CDInfo ) );
	
	if ( infoPtr == NULL )
	{
		printf( "Out of memory!!!  Goodbye!\n" );
		exit( 0 );
	}
	
	printf( "Enter Artist's Name:  " );
	gets( infoPtr->artist );
	
	printf( "Enter CD Title:  " );
	gets( infoPtr->title );
	
	do
	{
		printf( "Enter CD Rating (1-10):  " );
		scanf( "%d", &num );
		Flush();
	}
	while ( ( num < 1 ) || ( num > 10 ) );
	
	infoPtr->rating = num;
	
	printf( "\n----------\n" );
	
	return( infoPtr );
}


/*******************************************> AddToList <*/
void	AddToList( struct CDInfo *curPtr )
{
	struct CDInfo	*beforePtr;
	
/*	First check to see if the list is empty */
	if ( gFirstPtr == NULL )
		InsertInList( NULL, curPtr );
	else if ( curPtr->rating <= gFirstPtr->rating )
/*	Next check to see if curPtr should be the new first item */
		InsertInList( NULL, curPtr );
	else
/*	Walk through the list till you find the first rating higher than us */
	{
		beforePtr = gFirstPtr;
		
		while ( (beforePtr->next != NULL) &&
			(beforePtr->next->rating < curPtr->rating) )
		{
			beforePtr = beforePtr->next;
		}
		InsertInList( beforePtr, curPtr );
	}
}


/*******************************************> InsertInList <*/
void	InsertInList( struct CDInfo *afterMeCDPtr, struct CDInfo *newCDPtr )
{
	if ( afterMeCDPtr == NULL )
/* This means we want to insert the new one as the first in the list */
	{
		newCDPtr->next = gFirstPtr;
		gFirstPtr = newCDPtr;
		if ( gLastPtr == NULL )
			gLastPtr = newCDPtr;
	}
	else if ( afterMeCDPtr == gLastPtr )
/* This means we want to insert the new one as the last in the list */
	{
		gLastPtr->next = newCDPtr;
		newCDPtr->next = NULL;
		gLastPtr = newCDPtr;
	}
	else
	{
		newCDPtr->next = afterMeCDPtr->next;
		afterMeCDPtr->next = newCDPtr;
	}
		
}


/*******************************************> ListCDs <*/
void	ListCDs( void )
{
	struct CDInfo	*curPtr;
	
	if ( gFirstPtr == NULL )
	{
		printf( "No CDs have been entered yet...\n" );
		printf( "\n----------\n" );
	}
	else
	{
		for ( curPtr=gFirstPtr; curPtr!=NULL; curPtr = curPtr->next )
		{
			printf( "Artist:  %s\n", curPtr->artist );
			printf( "Title:   %s\n", curPtr->title );
			printf( "Rating:  %d\n", curPtr->rating );
	
			printf( "\n----------\n" );
		}
	}
}


/*******************************************> Flush <*/
void	Flush( void )
{
	while ( getchar() != '\n' )
		;
}