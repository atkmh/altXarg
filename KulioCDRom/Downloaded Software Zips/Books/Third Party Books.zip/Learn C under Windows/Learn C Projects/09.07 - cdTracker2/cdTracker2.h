/***********/
/* Defines */
/***********/
#define kMaxCDs				300
#define kMaxArtistLength	50
#define kMaxTitleLength		50


/***********************/
/* Struct Declarations */
/***********************/
struct CDInfo
{
	char			rating;
	char			artist[ kMaxArtistLength + 1 ];
	char			title[ kMaxTitleLength + 1 ];
	struct CDInfo	*next;
} *gFirstPtr, *gLastPtr;


/***********************/
/* Function Prototypes */
/***********************/
char			GetCommand( void );
struct CDInfo	*ReadStruct( void );
void			AddToList( struct CDInfo *curPtr );
void			InsertInList( struct CDInfo *afterMeCDPtr, struct CDInfo *newCDPtr );
void			ListCDs( void );
void			Flush( void );