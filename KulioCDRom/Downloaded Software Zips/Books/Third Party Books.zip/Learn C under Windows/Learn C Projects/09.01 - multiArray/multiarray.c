#include <stdio.h>

#define true 1
#define false 0

#define kMaxCDs				300
#define kMaxArtistLength	50


/***********************/
/* Function Prototypes */
/***********************/
void	PrintArtists( short numArtists, 
			char artist[][ kMaxArtistLength + 1 ] );


/**************************************************> main <*/
int	main( void )
{
	char	artist[ kMaxCDs ][ kMaxArtistLength + 1 ];
	short	numArtists;
	char	doneReading, *result;
	
	printf( "The artist array takes up %ld bytes of memory.\n\n", 
				sizeof( artist ) );
	
	doneReading = false;
	numArtists = 0;
	
	while ( ! doneReading )
	{
		printf( "Artist #%d (return to exit): ", numArtists+1 );
		result = gets( artist[ numArtists ] );
		
		if ( (result == NULL) ||
			(result[0] == '\0') )
			doneReading = true;
		else
			numArtists++;
	}
	
	printf( "----\n" );
	
	PrintArtists( numArtists, artist );

	return 0;
}


/**************************************************> PrintArtists <*/
void	PrintArtists( short numArtists,
			char artist[][ kMaxArtistLength + 1 ] )
{
	short	i;
	
	if ( numArtists <= 0 )
		printf( "No artists to report.\n" );
	else
	{
		for ( i=0; i<numArtists; i++ )
			printf( "Artist #%d: %s\n",
				i+1, artist[i] );
	}
}
