#include <stdlib.h>
#include <stdio.h>
#include "cdFiler2.h"

#define true 1
#define false 0

/*********************************************> WriteFile <*/
void	WriteFile( void )
{
	FILE			*fp;
	struct CDInfo	*infoPtr;
	int				num;
	
	if ( gFirstPtr == NULL )
		return;
	
	if ( ( fp = fopen( kCDFileName, "w" ) ) == NULL )
	{
		printf( "***ERROR: Could not write CD file!" );
		return;
	}
	
	for ( infoPtr=gFirstPtr; infoPtr!=NULL; infoPtr=infoPtr->next )
	{
		fprintf( fp, "%s\n", infoPtr->artist );
		fprintf( fp, "%s\n", infoPtr->title );

		num = infoPtr->rating;
		fprintf( fp, "%d\n", num );
	}
	
	fclose( fp );
}


/*********************************************> ReadFile <*/
void	ReadFile( void )
{
	FILE			*fp;
	struct CDInfo	*infoPtr;
	
	if ( ( fp = fopen( kCDFileName, "r" ) ) == NULL )
	{
		printf( "***ERROR: Could not read CD file!" );
		return;
	}
	
	do
	{
		infoPtr = malloc( sizeof( struct CDInfo ) );
		
		if ( infoPtr == NULL )
		{
			printf( "Out of memory!!!  Goodbye!\n" );
			exit( 0 );
		}
	}
	while ( ReadStructFromFile( fp, infoPtr ) );
	
	fclose( fp );
	free( infoPtr );
}


/************************************> ReadStructFromFile <*/
char	ReadStructFromFile( FILE *fp, struct CDInfo *infoPtr )
{
	int		num;
	char	line[ kMaxLineLength ];
	
	ZeroLine( line );
	if ( fscanf( fp, "%[^\n]\n", line ) != EOF )
	{
		infoPtr->artist = MallocAndCopy( line );
		ZeroLine( line );
		
		if ( fscanf( fp, "%[^\n]\n", line ) == EOF )
		{
			printf( "Missing CD title!\n" );
			return false;
		}
		else
		{
			infoPtr->title = MallocAndCopy( line );
			
			if ( fscanf( fp, "%d\n", &num ) == EOF )
			{
				printf( "Missing CD rating!\n" );
				return false;
			}
			else
			{
				infoPtr->rating = num;
				AddToList( infoPtr );
				return true;
			}
		}
	}
	else
		return false;
}
