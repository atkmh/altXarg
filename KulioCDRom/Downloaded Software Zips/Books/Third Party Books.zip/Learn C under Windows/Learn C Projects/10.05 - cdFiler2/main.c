#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "cdFiler2.h"


/***********************/
/* Global Definitions */
/***********************/
struct CDInfo	*gFirstPtr, *gLastPtr;


/**************************************************> main <*/
int	main( void )
{
	char			command;
	
	gFirstPtr = NULL;
	gLastPtr = NULL;
	
	ReadFile();
	
	while ( (command = GetCommand() ) != 'q' )
	{
		switch( command )
		{
			case 'n':
				AddToList( ReadStruct() );
				break;
			case 'l':
				ListCDs();
				break;
		}
	}
	
	WriteFile();
	
	printf( "Goodbye..." );
	
	return 0;
}


/*******************************************> GetCommand <*/
char	GetCommand( void )
{
	char	command;
	
	do 
	{
		printf( "Enter command (q=quit, n=new, l=list):  " );
		scanf( "%c", &command );
		Flush();
	}
	while ( (command != 'q') && (command != 'n')
					&& (command != 'l') );
	
	printf( "\n----------\n" );
	return( command );
}


/*******************************************> ReadStruct <*/
struct CDInfo	*ReadStruct( void )
{
	struct CDInfo	*infoPtr;
	int				num;
	char			line[ kMaxLineLength ];
	
	infoPtr = malloc( sizeof( struct CDInfo ) );
	
	if ( infoPtr == NULL )
	{
		printf( "Out of memory!!!  Goodbye!\n" );
		exit( 0 );
	}
	
	printf( "Enter Artist's Name:  " );
	gets( line );
	infoPtr->artist = MallocAndCopy( line );
	
	printf( "Enter CD Title:  " );
	gets( line );
	infoPtr->title = MallocAndCopy( line );
	
	do
	{
		printf( "Enter CD Rating (1-10):  " );
		scanf( "%d", &num );
		Flush();
	}
	while ( ( num < 1 ) || ( num > 10 ) );
	
	infoPtr->rating = num;
	
	printf( "\n----------\n" );
	
	return( infoPtr );
}


/*******************************************> AddToList <*/
void	AddToList( struct CDInfo *curPtr )
{
	if ( gFirstPtr == NULL )
		gFirstPtr = curPtr;
	else
		gLastPtr->next = curPtr;
	
	gLastPtr = curPtr;
	curPtr->next = NULL;
}


/*******************************************> ListCDs <*/
void	ListCDs( void )
{
	struct CDInfo	*curPtr;
	
	if ( gFirstPtr == NULL )
	{
		printf( "No CDs have been entered yet...\n" );
		printf( "\n----------\n" );
	}
	else
	{
		for ( curPtr=gFirstPtr; curPtr!=NULL; curPtr = curPtr->next )
		{
			printf( "Artist:  %s\n", curPtr->artist );
			printf( "Title:   %s\n", curPtr->title );
			printf( "Rating:  %d\n", curPtr->rating );
	
			printf( "\n----------\n" );
		}
	}
}


/*******************************************> Flush <*/
void	Flush( void )
{
	while ( getchar() != '\n' )
		;
}


/************************************> MallocAndCopy <*/
char	*MallocAndCopy( char *line )
{
/*
	This function takes a string as a parameter and malloc()s
	a new block of memory the size of the string, with an
	extra byte for the 0-terminator.
	
	strcpy() is called to copy the string into the new
	block of memory and the pointer to the new block is
	returned...
*/
	char	*pointer;
	if ( (pointer = malloc( strlen(line)+1 )) == NULL )
	{
		printf( "Out of memory!!!  Goodbye!\n" );
		exit( 0 );
	}
	strcpy( pointer, line );
	
	return pointer;
}


/************************************> ZeroLine <*/
void	ZeroLine( char *line )
{
	int		i;
	
	for ( i=0; i<kMaxLineLength; i++ )
		line[ i ] = 0;
}