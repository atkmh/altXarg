/***********/
/* Defines */
/***********/
#define kMaxLineLength		200
#define kCDFileName			"cdData"


/***********************/
/* Struct Declarations */
/***********************/
struct CDInfo
{
	char			rating;
	char			*artist;
	char			*title;
	struct CDInfo	*next;
};


/***********************/
/* Global Declarations */
/***********************/
 extern struct CDInfo	*gFirstPtr, *gLastPtr;


/********************************/
/* Function Prototypes - main.c */
/********************************/
char			GetCommand( void );
struct CDInfo	*ReadStruct( void );
void			AddToList( struct CDInfo *curPtr );
void			ListCDs( void );
void			ListCDsInReverse( void );
void			Flush( void );
char			*MallocAndCopy( char *line );
void			ZeroLine( char *line );


/*********************************/
/* Function Prototypes - files.c */
/*********************************/
void	WriteFile( void );
void	ReadFile( void );
char	ReadStructFromFile( FILE *fp, struct CDInfo *infoPtr );