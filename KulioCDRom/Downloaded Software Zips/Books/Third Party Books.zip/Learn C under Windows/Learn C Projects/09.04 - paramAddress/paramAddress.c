#include <stdio.h>
#include "paramAddress.h"


/**************************************************> main <*/
int	main( void )
{
	struct CDInfo	myCD;
	
	printf( "Address of myCD.rating in main():               %ld\n",
			&(myCD.rating) );
	
	PrintParamInfo( &myCD, myCD );
		
	return 0;
}


/*********************************> PrintStructAddresses <*/
void	PrintParamInfo( struct CDInfo *myCDPtr,
				struct CDInfo myCDCopy )
{
	printf( "Address of myCDPtr->rating in PrintParamInfo(): %ld\n",
			&(myCDPtr->rating) );
			
	printf( "Address of myCDCopy.rating in PrintParamInfo(): %ld\n",
			&(myCDCopy.rating) );
}