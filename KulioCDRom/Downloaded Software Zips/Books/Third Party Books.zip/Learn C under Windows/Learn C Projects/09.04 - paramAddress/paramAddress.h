/***********/
/* Defines */
/***********/
#define kMaxCDs				300
#define kMaxArtistLength	50
#define kMaxTitleLength		50


/***********************/
/* Struct Declarations */
/***********************/
struct CDInfo
{
	char	rating;
	char	artist[ kMaxArtistLength + 1 ];
	char	title[ kMaxTitleLength + 1 ];
};


/***********************/
/* Function Prototypes */
/***********************/
void	PrintParamInfo( struct CDInfo *myCDPtr,
				struct CDInfo myCDCopy );