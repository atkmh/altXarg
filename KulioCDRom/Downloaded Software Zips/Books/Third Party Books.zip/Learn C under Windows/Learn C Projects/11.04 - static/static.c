#include <stdio.h>

int	StaticFunc( void );

int main( void )
{
	int		i;
	
	for ( i=1; i<=5; i++ )
		printf( "%d\n", StaticFunc() );

	return 0;
}


int	StaticFunc( void )
{
	static int	myStatic = 0;
	
	return myStatic++;
}