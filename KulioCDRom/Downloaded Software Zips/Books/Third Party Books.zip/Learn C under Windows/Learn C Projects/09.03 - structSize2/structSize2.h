/***********************/
/* Struct Declarations */
/***********************/

struct LongShortShort
{
	long	myLong;
	short	myShort1;
	short	myShort2;
};

struct ShortLongShort
{
	short	myShort1;
	long	myLong;
	short	myShort2;
};

struct DoubleChar
{
	double	myDouble;
	char	myChar;
};

struct CharDoubleChar
{
	char	myChar1;
	double	myDouble;
	char	myChar2;
};

struct DoubleCharChar
{
	double	myDouble;
	char	myChar1;
	char	myChar2;
};