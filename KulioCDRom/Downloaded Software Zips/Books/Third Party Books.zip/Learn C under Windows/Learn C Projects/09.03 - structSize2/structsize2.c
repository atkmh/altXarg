#include <stdio.h>
#include "structSize2.h"


/**************************************************> main <*/
int	main( void )
{
	printf( "char:   %ld byte\n", sizeof( char ) );
	printf( "short:  %ld bytes\n", sizeof( short ) );
	printf( "long:   %ld bytes\n", sizeof( long ) );
	printf( "double: %ld bytes\n\n", sizeof( double ) );

	printf( "LongShortShort: %ld bytes\n",
		sizeof( struct LongShortShort ) );

	printf( "ShortLongShort: %ld bytes\n",
		sizeof( struct ShortLongShort ) );

	printf( "DoubleChar:     %ld bytes\n",
		sizeof( struct DoubleChar ) );

	printf( "CharDoubleChar: %ld bytes\n",
		sizeof( struct CharDoubleChar ) );

	printf( "DoubleCharChar: %ld bytes\n",
		sizeof( struct DoubleCharChar ) );
	
	return 0;
}