#include <stdio.h>


int main( void )
{
	int		i, num;
	long	fac;

	num = 5;
	fac = 1;
	
	for ( i=1; i<=num; i++ )
		fac *= i;
	
	printf( "%d factorial is %ld.", num, fac );

	return 0;
}