#include <stdlib.h>
#include <stdio.h>
#include "treePrinter.h"

#define true 1
#define false 0

/***********************/
/* Global Definitions */
/***********************/
struct Node	*gRootNodePtr;


/**************************************************> main <*/
int	main( void )
{
	gRootNodePtr = NULL;
	
	BuildTree();
	
	printf( "Preorder:  " );
	DescendTreePreorder( gRootNodePtr );
	
	printf( "\nInorder:   " );
	DescendTreeInorder( gRootNodePtr );
	
	printf( "\nPostorder: " );
	DescendTreePostorder( gRootNodePtr );
	
	printf( "\n\nGoodbye..." );
	
	return 0;
}


/*******************************************> BuildTree <*/
void	BuildTree( void )
{
	int		num;
	FILE	*fp;
	
	if ( ( fp = fopen( kNumbersFileName, "r" ) ) == NULL )
		DoError( "Could not read numbers file!\n" );
	
	printf( "Numbers:   " );
	
	while ( GetNumberFromFile( &num, fp ) )
	{
		printf( "%d, ", num );
		AddNumberToTree( num );
	}
	
	printf( "\n-------\n" );
	
	fclose( fp );
}


/***********************************> GetNumberFromFile <*/
int	GetNumberFromFile( int *numPtr, FILE *fp )
{
	if ( fscanf( fp, "%d\n", numPtr ) == EOF )
		return false;
	else
		return true;
}


/*******************************************> DoError <*/
void	DoError( char *message )
{
	printf( "%s\n", message );
	exit( 0 );
}
