#include <stdio.h>


int	main( void )
{
	FILE	*fp;
	int	c;
	
	fp = fopen( "myfile", "r" );
	
	if ( fp != NULL )
	{
		while ( (c = fgetc( fp )) != EOF )
			putchar( c );
		
		fclose( fp );
	}

	return 0;
}