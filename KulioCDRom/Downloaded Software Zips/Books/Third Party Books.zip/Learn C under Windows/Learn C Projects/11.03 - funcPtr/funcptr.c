#include <stdio.h>

int	SquareIt( int num );

int main( void )
{
	int		(*myFuncPtr)( int );
	int		num = 5;
	
	myFuncPtr = SquareIt;
	printf( "%d squared is %d.", num,
		(*myFuncPtr)( num ) );

	return 0;
}


int	SquareIt( int num )
{
	return( num * num );
}