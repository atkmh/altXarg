#define kMaxArtistLength	50
#define kMaxTitleLength		50


/***********************/
/* Struct Declarations */
/***********************/
struct CDInfo
{
	char	rating;
	char	artist[ kMaxArtistLength + 1 ];
	char	title[ kMaxTitleLength + 1 ];
};