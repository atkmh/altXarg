#include <stdio.h>
#include "structSize.h"


/**************************************************> main <*/
int	main( void )
{
	struct CDInfo	myInfo;
	
	printf( "rating field:    %ld byte\n",
			sizeof( myInfo.rating ) );
	
	printf( "artist field:   %ld bytes\n",
			sizeof( myInfo.artist ) );
	
	printf( "title field:    %ld bytes\n",
			sizeof( myInfo.title ) );
	
	printf( "               ---------\n" );
	
	printf( "myInfo struct: %ld bytes",
			sizeof( myInfo ) );

	return 0;
}