/*------------------------
   GRAFMENU.H header file
  ------------------------*/

#define IDM_NEW     1
#define IDM_OPEN    2
#define IDM_SAVE    3
#define IDM_SAVEAS  4

#define IDM_UNDO    5
#define IDM_CUT     6
#define IDM_COPY    7
#define IDM_PASTE   8
#define IDM_DEL     9

#define IDM_COUR    10
#define IDM_ARIAL   11
#define IDM_TIMES   12

#define IDM_HELP    13
