import java.awt.*;

class testEvents extends Frame {
   Panel P1;

   testEvents() {
      super("Test Events");
      P1 = new Panel();
      setLayout(new FlowLayout());
      P1.setBackground(new Color(255,255,255));
      add(P1);
      resize(300,200);
      show();
   }

   public boolean mouseDown(Event evt, int x, int y) {
      System.out.println("X, Y = " + x + ", " + y);
      System.out.println("Event X, Y = " + evt.x + ", " + evt.y);
      return true;
   }

   public static void main(String args[]) {
      testEvents TE = new testEvents();
   }
}
