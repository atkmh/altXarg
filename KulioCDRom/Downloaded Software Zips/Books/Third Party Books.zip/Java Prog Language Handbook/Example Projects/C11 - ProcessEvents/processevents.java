import java.applet.*;
import java.awt.*;

public class testEvents4 extends Applet {
   Label L1 = new Label();
   Label L2 = new Label();
   Label L3 = new Label();

   public testEvents4() {
      setLayout(new GridLayout(2, 3));
      add(new Label("handleEvent()"));
      add(new Label("action()"));
      add(new Label("mouseMove()"));
      add(L1);
      add(L2);
      add(L3);
   }

   public boolean handleEvent(Event evt) {
      if (evt.id == Event.MOUSE_MOVE) {
         L1.setText("" + evt.when);
         this.action(evt, evt.target);
         return super.handleEvent(evt);
      } else {
         return false;
      }
   }

   public boolean action(Event evt, Object arg) {
      L2.setText("" + evt.when);
      return true;
   }   
   public boolean mouseMove(Event evt, int x, int y) { 
      L3.setText("" + evt.when);
      return true;   }

   public void init(){
      testEvents4 TN = new testEvents4();
   }
} // End Application

