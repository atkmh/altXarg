import java.awt.*;

class TestFrame extends Frame {
   TestFrame() {
      super("Menu Test");
      MenuBar mb = new MenuBar();
      Menu fileMenu = new Menu("File");
      Menu optionMenu = new Menu("Option");
      Menu helpMenu = new Menu("Help");
      fileMenu.add(new MenuItem("New"));
      fileMenu.add(new MenuItem("-"));
      fileMenu.add(new MenuItem("Open"));
      fileMenu.add(new MenuItem("Close"));
      fileMenu.add(new MenuItem("Save"));
      fileMenu.addSeparator();
      fileMenu.add(new MenuItem("Exit"));
      optionMenu.add(new CheckboxMenuItem("Large Fonts"));
      optionMenu.add(new CheckboxMenuItem("Save Settings on Exit"));
      mb.setHelpMenu(helpMenu);
      mb.add(fileMenu);
      mb.add(optionMenu);
      mb.add(helpMenu);
      setMenuBar(mb);
      resize(300,200);
      show();
   }

   public boolean action(Event evt, Object obj) {
      String label = (String)obj;
      if (evt.target instanceof MenuItem) {
         if (label.equals("Exit")) {
            System.exit(0);
            return true;
            }
      }
      return true;
   } 

   public boolean handleEvent(Event evt) {
      if (evt.id == Event.WINDOW_DESTROY) {
         System.exit(0);
         return true;
      }
      return super.handleEvent(evt);
   }
   public static void main(String args[]) {
      TestFrame tf = new TestFrame();
  }
}

