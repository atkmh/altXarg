import java.net.*;  // Must be included to use the InetAddress class

public class checkMyIP {
  public static void main(String args[]) { 
     InetAddress localA = null;
     try {
         // Returns the name of the local address
         localA = InetAddress.getLocalHost();  
      } catch (java.io.IOException e) {}

      System.out.println("The local address is " + localA);

   }
}
