import java.applet.*;
import java.awt.*;
import java.net.*;

// testNav Class
public class testNav extends Applet {
   AudioClip startClip;
   AudioClip linkClip;
   AudioClip stopClip;

   public testNav() {
      setLayout(new GridLayout(4, 1));
      add(new Button("http://www.coriolis.com"));
      add(new Button("http://www.javasoft.com"));
      add(new Button("http://www.gamelan.com"));
      add(new Button("http://www.microsoft.com"));
   }

   public boolean action(Event evt, Object arg) {
      if (evt.target instanceof Button) {
         linkClip.play();
         fetchLink((String)arg);
         return true;
      }
      return super.handleEvent(evt);
   }
      void fetchLink(String s) {
      URL tempURL = null;
      try { tempURL  = new URL(s); }
      catch(MalformedURLException e) {
         showStatus("Malformed URL Exception has been thrown!");
      }
      getAppletContext().showDocument(tempURL);
   }

   public void init(){
      startClip = getAudioClip(getCodeBase(),  "start.au");
      linkClip = getAudioClip(getCodeBase(), "link.au");
      stopClip = getAudioClip(getCodeBase(), "stop.au");
   }

   public void start(){
      testNav TN = new testNav();
      startClip.play();
   }

   public void stop(){
      stopClip.play();
   }

} // End testNav

