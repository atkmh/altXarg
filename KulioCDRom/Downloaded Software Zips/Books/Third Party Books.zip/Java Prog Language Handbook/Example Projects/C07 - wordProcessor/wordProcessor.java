import java.io.*;

public class wordProcessor extends Object {

   String fileName;
// To set the file name, go to the Edit menu and select
// Java Application Settings. Select Java Project from the popup menu
// and edit the Parameters field. That text will be passed to the
// application's main() function as args[]
          void save(String fileName) {
	System.out.print ("Saving File Procedure\n");
	try {
	        System.out.print ("Saving File " + fileName + "\n");
	        ReadAFile aFile = new ReadAFile(fileName );

	}
	catch(FileNotFoundException e) {
	   System.out.print ("Procedure to get another name and try again\n");
	   // Procedure to get another name and try again
	}
	catch(IOException e) {
	   System.out.print ("Procedure to try again\n");
	   // Procedure to try again
	}
	finally {
	   System.out.print ("Perform any cleanup\n" );
	   // Perform any cleanup
                  }
         }

   // Where execution begins in a stand-alone executable
   public static void main(String args[]) {
       wordProcessor myProgram = new wordProcessor();
       myProgram.save(args[0]);


   }
}


// Reads from a file
class  ReadAFile extends wordProcessor {

   ReadAFile(String s) throws  FileNotFoundException, IOException {
      String line;
      FileInputStream fileName  = null;
      BufferedInputStream bufferedInput = null;
      DataInputStream dataIn = null;

      try {
         fileName = new FileInputStream(s);
         bufferedInput = new BufferedInputStream(fileName);
         dataIn = new DataInputStream(bufferedInput);
      }
      catch(FileNotFoundException e) {
         System.out.println("File Not Found");
         throw e;
      }
      catch(Throwable e) {
         System.out.println("Error in opening file");
      }

      try {
         while ((line = dataIn.readLine()) != null) {
            System.out.println(line + "\n");
         }
     fileName .close();
      }
      catch(IOException e) {
         System.out.println("Error in reading file");
         throw e;
      }
   }
}
