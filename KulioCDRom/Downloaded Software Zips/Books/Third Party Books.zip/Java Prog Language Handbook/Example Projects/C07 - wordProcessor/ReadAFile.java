// Reads from a file
class  ReadAFile extends wordProcessor {

   ReadAFile(String s) throws  FileNotFoundException, IOException {
      String line;
      FileInputStream fileName  = null;
      BufferedInputStream bufferedInput = null;
      DataInputStream dataIn = null;

      try {
         fileName = new FileInputStream(s);
         bufferedInput = new BufferedInputStream(fileName);
         dataIn = new DataInputStream(bufferedInput);
      }
      catch(FileNotFoundException e) {
         System.out.println("File Not Found");
         throw e;
      }
      catch(Throwable e) {
         System.out.println("Error in opening file");
      }

      try {
         while ((line = dataIn.readLine()) != null) {
            System.out.println(line + "\n");
         }
     fileName .close();
      }
      catch(IOException e) {
         System.out.println("Error in reading file");
         throw e;
      }
   }
}
