import java.awt.*;

public class testMe extends Frame {

   public testMe() {
      super("Choice Demo");
      Choice C1 = new Choice();
      setLayout(new FlowLayout());
      add(C1);
      C1.addItem("You");
      C1.addItem("Me");
      C1.addItem("Them");
      C1.addItem("Us");
      C1.addItem("Everyone");
      resize(300, 200);
      show();
   }

   public static void main(String args[]) {
      testMe test = new testMe();
   }
}
