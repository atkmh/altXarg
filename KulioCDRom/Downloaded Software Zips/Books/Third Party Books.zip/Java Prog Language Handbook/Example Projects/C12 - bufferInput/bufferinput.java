import java.io.*;

// Reads from a file
public class  ReadAFile extends Object {
   ReadAFile(String s) {
      String line;
      FileInputStream fileName  = null;
      // Assigns the variable bufferedInput to the class 
      // BufferedInputStream
      BufferedInputStream bufferedInput = null;
      DataInputStream dataIn = null;
   
      try {
         fileName = new FileInputStream(s);
         // Creates an instance of the class BufferedInputStream named 
         // bufferedInput
         // bufferedInput receives the stream from the FileInputStream 
         // fileName as it is read
         bufferedInput = new BufferedInputStream(fileName);
         dataIn = new DataInputStream(bufferedInput);
      }
      catch(FileNotFoundException e) {
         System.out.println("File Not Found");
         return;
      }
      catch(Throwable e) {
         System.out.println("Error in opening file");
         return;
      }
   
      try {
         while ((line = dataIn.readLine()) != null) {
            System.out.println(line + "\n");
         }
         fileName .close();
      }
      catch(IOException e) {
         System.out.println("Error in reading file");
      }
   }
   
   // Where execution begins in a stand-alone executable
   public static void main(String args[]) {
       new ReadAFile(args[0]);

   }
}
