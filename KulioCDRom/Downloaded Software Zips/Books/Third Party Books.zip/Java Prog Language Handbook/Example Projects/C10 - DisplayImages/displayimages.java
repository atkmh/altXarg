import java.awt.*;
import java.applet.*;

public class testImg extends Applet {
   Image testImage;

   public void paint(Graphics g) {
      g.drawImage(testImage, 0, 0, this);
   }

   public void init() {
      testImage = getImage( getCodeBase(), "Pencil.gif" );
   }
}