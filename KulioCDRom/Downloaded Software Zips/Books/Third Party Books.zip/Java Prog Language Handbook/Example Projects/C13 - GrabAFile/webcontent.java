import java.io.*;
import java.net.*;

public class GrabAFile {
    BufferedInputStream holdingRoom1;
    String holdingRoom2;

    GrabAFile() {
    }

    GrabAFile( String userURL ) {
        URL aURL;
        InputStream rawDataIn;
        DataInputStream refinedDataIn;
        int aCharDataIn;

        try {
            aURL = new URL(userURL);
            rawDataIn = aURL.openStream();
            holdingRoom1 = new BufferedInputStream( rawDataIn );
            refinedDataIn = new DataInputStream( holdingRoom1 );

            while((aCharDataIn = refinedDataIn.read() ) >= 0 ) {
                    System.out.print((char)aCharDataIn);
            }

            System.out.print( refinedDataIn );
        } 
         catch( MalformedURLException e ) {
         	System.out.print("MalformedURLException!!\n");
         	System.out.print("Select \"Java Application Settings...\"" );
         	System.out.print(" from the Edit menu,\ngo to the" );
         	System.out.print(" Java Project panel to set up your URL...\n");
         } 
         catch( IOException e ) {} 
         catch( Exception e ) {}
    }

    public static void main(String args[]) {
        new GrabAFile(args[0]);


    }
}
