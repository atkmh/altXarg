import java.awt.*;

class testEvents extends Frame {
   testEvents() {
      super("Test Keys");
      setLayout(new FlowLayout());
      add(new Button("Hello!"));
      add(new Button("Goodbye!"));
      resize(300,200);
      show();
   }

   public boolean mouseDown(Event evt, int x, int y) {
      if (evt.target instanceof Button) {
         System.out.println((String)evt.arg);
         return true;
      } else {
         return super.mouseDown(evt, x, y);
      }
   }

   public static void main(String args[]) {
      testEvents TK = new testEvents();
   }
}


