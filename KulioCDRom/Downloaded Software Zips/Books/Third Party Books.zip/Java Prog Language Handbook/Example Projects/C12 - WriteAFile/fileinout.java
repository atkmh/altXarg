import java.io.*;

public class WriteAFile {
   WriteAFile(String s) {
      write(s);
   }

   // Writes to a file
   public void write(String s) {
      // Assigns the variable writeOut to the class FileOutputStream
      FileOutputStream writeOut = null;
      DataOutputStream dataWrite = null;

      try {
         // Creates an instanceof the class FileOutputStream named writeOut
         // writeOut receives the stream from the File designated in the 
         // variables
         writeOut = new FileOutputStream(s);
         dataWrite = new DataOutputStream(writeOut);
         dataWrite.writeChars("This is a Test");
         dataWrite.close();
      }
      catch(IOException e)  {
         System.out.println("Error in writing to file");
       }
      catch(Throwable e)  {
         System.out.println("Error in writing to file");
       }
      finally {
         System.out.println("\n\n.....creating a backup file.");
         try {
            // Recreates an instanceof the class FileOutputStream named 
            // writeOut
            // writeOut receives the stream from the File named 
            // "MyBackup.sav"
            writeOut = new FileOutputStream("MyBackup.sav");
            dataWrite = new DataOutputStream(writeOut);
            dataWrite.writeChars("This is a Test");
            dataWrite.close();
         }
         catch (IOException e) {
                  System.out.println("Error in writing backup file");
          }
      } 
   }
   // Where execution begins in a stand-alone executable
   public static void main(String args[]) {
       new WriteAFile(args[0]);

   }
}

