import java.io.*;
import java.net.*;  // Must be included to use Socket class
import java.awt.*;

// NOTE: Be sure to pass the address of the computer to connect to
// as an argument to main(). You'll want to select
// "Java Application Settings..." from the Edit menu, then select
// "Java Project" and fill in the Parameters field. You might
// try running CheckMyIP first and use that address in the 
// Parameters field. As an example, my machines IP address
// (at the time I wrote this) was 38.12.1.94 -- That's
// exactly what I put in there. I left off the leading text and
// slash and just put in the proper internet address.

// NOTE: BE SURE YOU RUN MrsServer BEFORE you start
// up MrClient...


public class mrClient extends Frame {
   mrClient() { }
   mrClient(String s) {
      // Create the text display for the application
      super("Client Application"); 
      TextArea clientScreen = new TextArea("mrClient's Screen:\n", 10, 40);
      add("Center", clientScreen);
   pack();
   show();

   Socket mrClient = null;                      
   InputStream rawDataIn = null; // Setup the input and output streams
   OutputStream rawDataOut = null;

   try {
     mrClient = new Socket(s, 10 );   // Create the socket object

     rawDataIn = mrClient.getInputStream();
     rawDataOut = mrClient.getOutputStream();
     // Create a data input stream
     DataInputStream DataIn = new DataInputStream(rawDataIn);  
     // Create a data output stream
     DataOutputStream DataOut = new DataOutputStream(rawDataOut); 
     int Value = DataIn.readInt();  // Read in data from the socket
     clientScreen.appendText( "mrClient receives -  " + Value + "\n" );

     switch(Value) {   // Determine which value has been obtained 
     // from the socket
      case 1:
        clientScreen.appendText("Your Number 1");
        DataOut.writeInt( 1 );
        break;
       case 2:
        clientScreen.appendText("Your Number 2");
        DataOut.writeInt( 2 );
        break;
       case 3:
        clientScreen.appendText("Your Shakey");
        DataOut.writeInt( 3 );
        break;
      case 4:
        clientScreen.appendText("Your a loser");
        DataOut.writeInt( 4 );
        break;
      case 5:
        clientScreen.appendText("This is my lucky number!");
        DataOut.writeInt( 5 );
        break;
      default:
        clientScreen.appendText("What was your Number?");
        DataOut.writeInt( 6 );
      }
      mrClient.close();   // Close the socket
 } 

// Handle exceptions that have occurred
catch( UnknownHostException e ) {
      clientScreen.appendText("Can't find Server");
    } 
    catch( IOException e ) {
      clientScreen.appendText("an IO Error has occurred");
    }
  }

  public static void main( String args[] ) {
      new mrClient(args[0]);
    }

     // Handle events that have occurred
     public boolean handleEvent(Event evt)
     {
        System.out.println(evt.target.toString());
        switch(evt.id)
        {
           case Event.WINDOW_DESTROY:
           {
               System.out.println("Exiting...");
               System.exit(0);
               return true;
            }
         }
      return true;
      }

}

