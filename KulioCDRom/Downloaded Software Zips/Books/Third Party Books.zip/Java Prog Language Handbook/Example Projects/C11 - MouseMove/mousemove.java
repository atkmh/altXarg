import java.awt.*;

class testEvents extends Frame {

   testEvents() {
      super("Test Events");
      resize(300,200);
      show();
   }

   public boolean mouseMove(Event evt, int x, int y) {
      setTitle("mouseMove at: " + x + ", " + y);
      return true;
   }

   public boolean mouseDrag(Event evt, int x, int y) {
      setTitle("mouseDrag at: " + x + ", " + y);
      return true;
   }

   public static void main(String args[]) {
      testEvents TE = new testEvents();
   }
}

