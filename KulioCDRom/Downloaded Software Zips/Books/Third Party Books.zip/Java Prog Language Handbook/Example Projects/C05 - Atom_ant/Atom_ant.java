class Atom_ant {

   String  superhero;

   int height;



   Atom_ant(String s, int h) {  // Declare a constructor

      superhero = s;

      height = h;

   }



   void printatom_ant() {

      System.out.print("Up and attam, " + superhero);

      System.out.println("!  The world's only " + height +

        " inch Superhero!");

    }



    public static void main(String args[])  {

       Atom_ant a;



       a =  new Atom_ant("Atom Ant" , 1); // Call the constructor

       a.printatom_ant();

       System.out.println("------");



       a = new Atom_ant("Grape Ape", 5000);

       a.printatom_ant();

       System.out.println("------");


    }

}

