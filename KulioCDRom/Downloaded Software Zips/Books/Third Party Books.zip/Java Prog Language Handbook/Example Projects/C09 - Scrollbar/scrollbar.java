import java.awt.*; 

public class ScrollTest extends Frame {
   TextField text;
   Scrollbar scroll;
   public ScrollTest() {
      super("Scroll-Text Test");
      text = new TextField(5);
      scroll = new Scrollbar(Scrollbar.VERTICAL, 0, 10, 0, 100);
      setLayout(new FlowLayout());
      add(text);
      add(scroll);
      resize(300, 200);
      show();
   }
   public boolean handleEvent(Event evt) {
      if (evt.target.equals(scroll)) {
         text.setText("" + scroll.getValue());
         } else if (evt.target.equals(text))
            {scroll.setValue(Integer.parseInt(text.getText()));
         } else if (evt.id == Event.WINDOW_DESTROY) {
         System.exit(0);
         return true;
      }
      return super.handleEvent(evt);
   }
   public static void main(String args[]) {
      ScrollTest test = new ScrollTest();
   }
} 

