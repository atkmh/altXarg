import java.awt.*;

public class testMe extends Frame {
   public testMe() {
      super("Menu Demo");
      MenuBar MB = new MenuBar();
      Menu M1 = new Menu("File");
      Menu M2 = new Menu("Options");
      Menu M3 = new Menu("More");
      MB.add(M1);
      MB.add(M2);
      MB.add(new Menu("Help"));
      M1.add(new MenuItem("Open"));
      M1.add(new MenuItem("Close"));
      M1.add(new MenuItem("Save"));
      M2.add(new MenuItem("General"));
      M2.add(M3);
      M3.add(new MenuItem("Screen"));
      M3.add(new MenuItem("Font"));
      setMenuBar(MB);
      resize(300, 200);
      show();
   }
   public static void main(String args[]) {
      testMe test = new testMe();
   }
}

