import java.awt.*;

class testKeys extends Frame {

   testKeys() {
      super("Test Keys");
      resize(300,200);
      show();
   }

   public boolean keyDown(Event evt, int key) {
      if (evt.controlDown()) {
         if (key == 24) {
            System.exit(0);
            return true;
         }
      }
      if (key == Event.F1) {
         setTitle("No help here!");
         return true;
      }
      return false;
   }

   public boolean keyUp(Event evt, int key) {
      if (key == Event.F1) {
         setTitle("Test Keys");
         return true;
      }
      return false;
   }

   public static void main(String args[]) {
      testKeys TK = new testKeys();
   }
}
