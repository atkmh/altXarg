class Atom_ant2 {

   String  superhero;

   int height;

   Boolean villain;

   void printatom_ant() {

      System.out.print("Up and attam, " + superhero);

      System.out.println("!  The world's only " + height +

	     " inch Superhero!");

    }



    public static void main(String args[])  {

       Atom_ant2 a;



       a =  new Atom_ant2();

       a.printatom_ant();

       System.out.println("------") ;



   }

}

