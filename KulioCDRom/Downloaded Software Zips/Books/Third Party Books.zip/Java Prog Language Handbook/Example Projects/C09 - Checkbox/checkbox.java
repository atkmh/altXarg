import java.awt.*;

public class testMe extends Frame {

   public testMe() {
      super("Checkbox Demo");
      Panel P1 = new Panel();
      Panel P2 = new Panel();
      CheckboxGroup G1 = new CheckboxGroup();
      setLayout(new GridLayout(1,2));
      add(P1);
      add(P2);
      P1.setLayout(new FlowLayout());
      P1.add(new Checkbox("E-Mail Tom"));
      P1.add(new Checkbox("E-Mail Jack"));
      P2.setLayout(new FlowLayout());
      P2.add(new Checkbox("Me", G1, true));
      P2.add(new Checkbox("You", G1, false));
      P2.add(new Checkbox("Them", G1, false));
      resize(300, 200);
      show();
   }

   public static void main(String args[]) {
      testMe test = new testMe();
   }
}
