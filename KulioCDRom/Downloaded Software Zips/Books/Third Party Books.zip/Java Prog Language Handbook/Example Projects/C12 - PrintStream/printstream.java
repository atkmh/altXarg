import java.io.*;

public class ProcessALine {
   public static void main(String arg[]) {
      DataInputStream aDataInput = new DataInputStream(System.in);
      String aString;

      try {
      // A Control Z exits        
        while ((aString = aDataInput.readLine()) != null) { 
            System.out.println(aString);
         }
       } catch (IOException e) {
            System.out.println("An IOException has occurred");
       }
   }
}
