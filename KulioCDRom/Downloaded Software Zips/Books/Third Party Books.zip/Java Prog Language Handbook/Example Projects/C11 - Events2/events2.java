import java.awt.*;

class testEvents extends Frame {
   myButton B1;
   myButton B2;

   testEvents() {
      super("Test Keys");
      setLayout(new FlowLayout());
      B1 = new myButton("Hello!");
      B2 = new myButton("Goodbye!");
      add(B1);
      add(B2);
      resize(300,200);
      show();
   }

   public static void main(String args[]) {
      testEvents TK = new testEvents();
   }
}

class myButton extends Button {

   myButton(String s) {
      super(s);
   }

   public boolean mouseDown(Event evt, int x, int y) {
      System.out.println((String)evt.arg);
      return true;
   }
}
