import java.awt.*;

public class mixLayout extends Frame {

   public mixLayout() {
      super("Mixed Layout Demo");
      setLayout(new BorderLayout());
      Panel top = new Panel();
      Panel bottom = new Panel();
      top.setLayout(new BorderLayout());
      top.add("Center", new TextArea("HelloWorld", 15, 5));
      bottom.setLayout(new FlowLayout());
      bottom.add(new Button("Load"));
      bottom.add(new Button("Save"));
      bottom.add(new Button("Quit"));
      add("Center", top);
      add("South", bottom);
      resize(300, 200);
      show();
   }
   public static void main(String args[]) {
      mixLayout test = new mixLayout();
   }

}
