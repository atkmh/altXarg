import java.awt.*;
import java.applet.*;

public class Lady extends Applet
{
     String str = "";

   public void init()
   {
     Button a = new Button("Me");
     Button b = new Button("Him");
       add("East", a);
       add("West", b);

   }

public boolean handleEvent(Event evt)
{
  if (evt.target instanceof Button) {
     if("Him".equals(evt.arg))
     {
Gentleman tweedledee= (Gentleman)getAppletContext().getApplet("tweedledee");
       if ( tweedledee != null) {
         return  tweedledee.handleEvent(evt);
       } else {
         return false;
       }
     }
     else if("Me".equals(evt.arg))
     {
        str ="You Clicked!!";
        repaint();
        return true;
     }
     else if("Her".equals(evt.arg))
     {
        str ="Hello Mister!!";
        repaint();
        return true;
     }
     return super.handleEvent(evt);
}
return super.handleEvent(evt);
}
     public void paint(Graphics g) {
        g.drawString(str, 60,50);
        g.drawString("The Lady", 60, 80);
     }
}


