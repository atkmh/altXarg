import java.awt.*;
import java.applet.*;

public class Gentleman extends Applet
{
     String str = "";

   public void init()
   {
     Button a = new Button("Me");
     Button b = new Button("Her");
       add("East", a);
       add("West", b);

   }

public boolean handleEvent(Event evt)
{
  if (evt.target instanceof Button) {
     if("Her".equals(evt.arg))
     {
       Lady tweedledumb= (Lady)
         getAppletContext().getApplet("tweedledumb");
       if ( tweedledumb != null) {
         return tweedledumb.handleEvent(evt);
       } else {
         return false;
       }
     }
     else if("Me".equals(evt.arg))
     {
         str ="You Clicked!!";
         repaint();
         return true;
     }
     else if("Him".equals(evt.arg))
     {
         str ="Hello Miss!!";
         repaint();
         return true;
       }
       return super.handleEvent(evt);
}
return super.handleEvent(evt);
}
   public void paint(Graphics g) {
       g.drawString(str, 60,50);
       g.drawString("The Gentleman", 60, 80);
     }
}

