import java.awt.*;
import java.lang.*;

public class MyApp2 extends Frame implements Runnable {
	static TextArea t1;
	static TextArea t2;
	
	MyApp2() {
		// Calls the parent constructor Frame(string title)
		// Same as setTitle("Duck Duck Goose");
		super("Counting example");
		
		// A new panel to the south that 4 buttons and 1 choice
		t1 = new TextArea();
		t2 = new TextArea();
		
		add("East", t1);
		add("West", t2);
		
		pack();
		show();
	}
	
	public static void main(String args[]) {
		int i = 0;
		
		MyApp2 game = new MyApp2();
		Thread person1 = new Thread(game, "duck");
		Thread person2= new Thread(game, "goose");
		
		person1.start();
		person2.start();
		
		while ((person1.isAlive()) || (person2.isAlive())) {
			++i;
			t2.setText(Integer.toString(i));
		}
		
		t2.appendText("\n Time through the loop \n\nYour It");
		person1.stop();
		person2.stop();
	}
	
	public synchronized void run() {
		int d = 0;
		int change = 0;
		
		while(d < 100) {
			t1.appendText("\n " + Thread.currentThread().getName() + " " + d );
			++d;
		}
	}
	
	public boolean handleEvent(Event evt) {
		switch(evt.id) {
			case Event.WINDOW_DESTROY: {
				System.exit(0);
				return true;
			}
			default:
				return false;
		}
	}
}