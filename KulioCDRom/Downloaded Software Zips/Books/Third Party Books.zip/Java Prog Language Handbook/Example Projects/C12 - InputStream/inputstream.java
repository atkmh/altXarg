import java.io.*;
import java.net.*;
import java.awt.*;

// Be sure to run mrsServer BEFORE you start mrClient!!!
// mrsServer is in the outputstream project. Launch it, go
// back to CodeWarrior, close the outputstream project,
// open the inputstream project and run it. You should see
// a connection in the mrsServer window.
//
// Not much to see, but a very cool concept!

public class mrClient extends Frame {
    mrClient() {
        super("Client Application");
        TextArea clientScreen = new TextArea("mrClient's Screen:\n", 10, 40);
        add("Center", clientScreen);
        pack();
        show();
        Socket mrClient = null;
        InputStream rawDataIn = null;

        try {
            mrClient = new Socket( InetAddress.getLocalHost(), 10 );

            rawDataIn = mrClient.getInputStream();
            // reads in the stream for the InputStream rawDataIn and pipes 
            // it to DataIn
            DataInputStream DataIn = new DataInputStream(rawDataIn);
            // the array of bytes is then read from the stream 
            clientScreen.appendText( "mrClient receives -  " + 
            DataIn.read() );
        } catch( UnknownHostException e ) {
        } catch( IOException e ) {
        }
    }

    public static void main(String args[]) {
    	new mrClient();
    }
}