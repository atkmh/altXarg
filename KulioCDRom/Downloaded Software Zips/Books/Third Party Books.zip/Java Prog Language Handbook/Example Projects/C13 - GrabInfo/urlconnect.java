import java.net.*;

public class GrabInfo {

    GrabInfo() {
    }

    GrabInfo( String userURL ) {
        URL aURL;
        URLConnection anotherURL;

        try {
            aURL = new URL(userURL);
            anotherURL = aURL.openConnection();
            anotherURL.connect();
            System.out.print(anotherURL.getContentType() + "\n\n");
        } catch( MalformedURLException e ) {
         	System.out.print("MalformedURLException!!\n");
         	System.out.print("Select \"Java Application Settings...\"" );
         	System.out.print(" from the Edit menu,\ngo to the" );
         	System.out.print(" Java Project panel to set up your URL...\n");
        } catch( Exception e ) {
        }
    }

    public static void main(String args[]) {
        new GrabInfo(args[0]);

/*
 * The next few lines were added to prompt you to hit Enter.
 * This prevents the console window from closing as soon as the applet
 * finishes running...
 */
 		System.out.println( "\nHit the <Enter> key..." );
		try {
			System.in.read(); 
		} catch (java.io.IOException e) {}
    }
}
