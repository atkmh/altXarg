import java.io.*;

// Reads from a file
public class  ReadAFile extends Object {
   ReadAFile(String s) {
      String line;
      FileInputStream fileName  = null;
      // Assigns the variable bufferedInput to the class BufferedInputStream
      BufferedInputStream bufferedInput = null;
      DataInputStream dataIn = null;
      LineNumberInputStream parsedData;
   
      try {
         fileName = new FileInputStream(s);
         // Creates an instanceof the class LineNumberInputStream named 
         // parsedData
         // parsedData receives the stream from the FileInputStream 
         // fileName as it is read
         parsedData = new LineNumberInputStream(fileName);
         dataIn = new DataInputStream(parsedData);
      }
      catch(FileNotFoundException e) {
         System.out.println("File Not Found");
         return;
      }
      catch(Throwable e) {
         System.out.println("Error in opening file");
         return;
      }
   
      try {
         int lineNumber;
         while ( true ) { //NOTE: The while loop was rewritten, as the book code has a slight algorithm error
            lineNumber = parsedData.getLineNumber();
            if ( ( line = dataIn.readLine() ) == null )
               break;
         
            System.out.println( lineNumber + ": " + line + "\n");
         }
         fileName .close();
      }
      catch(IOException e) {
         System.out.println("Error in reading file");
      }
   }
   
   // Where execution begins in a stand-alone executable
   public static void main(String args[]) {
       new ReadAFile(args[0]);


   }
}

