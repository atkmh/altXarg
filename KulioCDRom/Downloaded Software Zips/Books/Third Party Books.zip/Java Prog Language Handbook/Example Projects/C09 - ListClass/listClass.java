import java.awt.*;

public class testMe extends Frame {

   public testMe() {
      super("List Demo");
      List L1 = new List();
      setLayout(new FlowLayout());
      add(L1);
      L1.addItem("You");
      L1.addItem("Me");
      L1.addItem("Them");
      L1.addItem("Us");
      L1.addItem("Everyone");
      resize(300, 200);
      show();
   }

   public static void main(String args[]) {
      testMe test = new testMe();
   }
}
