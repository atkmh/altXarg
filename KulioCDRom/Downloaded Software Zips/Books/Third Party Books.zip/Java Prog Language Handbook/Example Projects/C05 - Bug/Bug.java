/*
 * Note: there are some discrepancies between this and the source in 
 * the book.
 */
 
class Atom_ant { // Simple class
	int i = 1;
}

public class Bug {
	static int i = 10;
	static Atom_ant crazyant; // Declare an object
	
	public static void main (String args[]) {
		// Create an instance of Atom_ant called crazyant
		crazyant = new Atom_ant();
		System.out.println("There are " + Bug.i + " bugs here but only " +
		  crazyant.i + " atom ant.");
		
	}
}
	


