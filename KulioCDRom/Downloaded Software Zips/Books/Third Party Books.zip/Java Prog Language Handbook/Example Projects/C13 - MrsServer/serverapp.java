import java.io.*;
import java.net.*;
import java.awt.*;

public class mrsServer extends Frame {
   TextArea serverScreen;

    mrsServer() {
     super("Server Application");
     serverScreen = new TextArea("mrsServer's Screen:\n", 10, 40);
     add("Center", serverScreen);
     pack();
     show();

     ServerSocket mrsServer = null;   // Initialize the server socket 
     Socket socketReturn = null;      // Initialize the client socket 
     InputStream rawDataIn = null;
     OutputStream rawDataOut = null;

   try {
       mrsServer = new ServerSocket( 10 );  // Create the server object
       socketReturn = mrsServer.accept();  // Wait for the client 
                                           // socket to come in
       serverScreen.appendText( "Connected to the mrsServer \n" );

       rawDataIn = socketReturn.getInputStream();
       rawDataOut = socketReturn.getOutputStream();
       DataInputStream DataIn = new DataInputStream(rawDataIn);
       DataOutputStream DataOut = new DataOutputStream(rawDataOut);
       DataOut.writeInt( 5 );
       int Value = DataIn.readInt();

       switch(Value)
       {
       case 1:
         serverScreen.appendText("You sent me Number 1");
         break;
       case 2:
         serverScreen.appendText("You sent me Number 2");
         break;
       case 3:
         serverScreen.appendText("You sent me Number 3");
         break;
       case 4:
         serverScreen.appendText("You sent me Number 4");
         break;
       case 5:
         serverScreen.appendText("You sent me Number 5");
         break;
       default:
         serverScreen.appendText("What was your Number?");
       }

       } 
       catch( UnknownHostException e ) {
         serverScreen.appendText("Can't find Server");
       } 
       catch( IOException e ) {
         serverScreen.appendText("an IO Error has occurred");
       }
    }

    public static void main( String args[] ) {
        new mrsServer();
    }

     // Handle events that have occurred
     public boolean handleEvent(Event evt)
     {
       System.out.println(evt.target.toString());
       switch(evt.id)
       {
         case Event.WINDOW_DESTROY:
         {
            System.out.println("Exiting...");
            System.exit(0);
            return true;
         }
       }
      return true;
      }
}
