import java.awt.*;   // Include the AWT

public class testWin extends Frame {   // Use the Frame class

   public testWin(){}   // Constructor

   public static void main(String args[]) {
      testWin Test = new testWin();
      Test.show();    // Display a window
      
   }
}