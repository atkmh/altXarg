import java.awt.*;

public class winTest1 extends Frame {

   public winTest1() {}

   public synchronized boolean handleEvent(Event e) {
      if (e.id == Event.WINDOW_DESTROY) {    // Has window been destroyed?
         System.exit(0);
         return true;
      }
      return super.handleEvent(e);
   }

   public static void main(String args[]) {
      winTest1 Test = new winTest1();
      Test.setTitle("Test Window");    
      Test.resize(300 ,200);
      Test.show();
   }
}
