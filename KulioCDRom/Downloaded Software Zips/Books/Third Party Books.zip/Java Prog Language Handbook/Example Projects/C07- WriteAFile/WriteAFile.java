import java.io.*;

public class WriteAFile {

WriteAFile(String s) {
   write(s);
}

// Writes to a file
public void write(String s) {
   FileOutputStream writeOut = null;
   DataOutputStream dataWrite = null;

   try {
      writeOut = new FileOutputStream(s);
      dataWrite = new DataOutputStream(writeOut);
      dataWrite.writeChars("This is a Test");
      dataWrite.close();
   }
   catch(IOException e)  {
      System.out.println("Error in writing to file");
    }
   catch(Throwable e)  {
      System.out.println("Error in writing to file");
    }
   finally {
      System.out.println("\n\n.....creating a backup file.");
      try {
         writeOut = new FileOutputStream("MyBackup.sav");
         dataWrite = new DataOutputStream(writeOut);
         dataWrite.writeChars("This is a Test");
         dataWrite.close();
      }
      catch (IOException e) {
               System.out.println("Error in writing backup file");
       }
   }
}
   // Where execution begins in a stand-alone executable
   public static void main(String args[]) {
       new WriteAFile(args[0]);


   }
}
