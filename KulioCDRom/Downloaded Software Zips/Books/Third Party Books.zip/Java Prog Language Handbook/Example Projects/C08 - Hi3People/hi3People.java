public class Hi3People implements Runnable {
	public static void main(String args[]) throws InterruptedException {
		int i1 = 0;
		int i2 = 0;
		
		Hi3People person = new Hi3People();
		Thread aThread = new Thread(person, "Person 1");
		Thread anotherThread = new Thread(person, "Person 2");
		
		aThread.start();
		anotherThread.start();
		
		while ((aThread.isAlive()) || (anotherThread.isAlive())) {
			if (aThread.isAlive()) { ++i1;} // Counter for the first thread
			if (anotherThread.isAlive()) { ++i2;} // Counter for the second thread
		}
		
		System.out.println("The time for Person1 is " + i1 + "\n");
		System.out.println("The time for Person2 is " + i2 + "\n");
		aThread.stop();
		anotherThread.stop();

	}
	
	public void run() {
		System.out.println("Hi " + Thread.currentThread().getName());
	}
}