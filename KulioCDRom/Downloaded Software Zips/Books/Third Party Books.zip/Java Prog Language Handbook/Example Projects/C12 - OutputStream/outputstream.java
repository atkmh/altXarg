import java.io.*;
import java.net.*;
import java.awt.*;

public class mrsServer extends Frame {
   TextArea serverScreen;

    mrsServer() {
        super("Server Application");
        serverScreen = new TextArea("mrsServer's Screen:\n", 10, 40);
        add("Center", serverScreen);
        pack();
        show();

        ServerSocket mrsServer = null;
        Socket socketReturn = null;
        // Assigns the variable rawDataOut to the class OutputStream
        OutputStream rawDataOut = null;

        try {
            mrsServer = new ServerSocket( 10, 2 );
            socketReturn = mrsServer.accept();
            serverScreen.appendText( "Connected to the mrsServer" );

            // Creates an instanceof the class OutputStream named          
            // rawDataOut
            // rawDataOut receives the stream from the Socket socketReturn 
            rawDataOut = socketReturn.getOutputStream();
            DataOutputStream DataOut = new DataOutputStream(rawDataOut);

            DataOut.write( 5 );
        } catch( UnknownHostException e ) {
        } catch( IOException e ) {
        }
    }
    
    public static void main(String args[]) {
    	new mrsServer();
    }
}