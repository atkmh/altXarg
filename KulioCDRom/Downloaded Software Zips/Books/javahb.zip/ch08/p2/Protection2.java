package p2;

class Protection2 extends p1.Protection {
    Protection2() {
	System.out.println("derived other package constructor");
//	System.out.println("n = " + n);		// class, package
//	System.out.println("n_pri = " + n_pri);	// class
	System.out.println("n_pro = " + n_pro);
	System.out.println("n_pripro = " + n_pripro);
	System.out.println("n_pub = " + n_pub);
    }

}

class otherpackage {
    otherpackage() {
	p1.Protection p = new p1.Protection();
	System.out.println("other package constructor");
//	System.out.println("n = " + p.n);	  // class, package
//	System.out.println("n_pri = " + p.n_pri); // class
//	System.out.println("n_pro = " + p.n_pro); // class, subclass, package
//	System.out.println("n_pripro = " + p.n_pripro); // class, subclass
	System.out.println("n_pub = " + p.n_pub);
    }
}
