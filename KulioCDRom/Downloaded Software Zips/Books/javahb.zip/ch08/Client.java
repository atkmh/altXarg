// this is different than the book... I had to make callback public because
// it defaulted to public in the Callback interface.

class Client implements Callback {
    public void callback(int p) {
	System.out.println("callback called with " + p);
    }
}
