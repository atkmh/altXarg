package p1;

public class Protection {
    int n = 1;
    private int n_pri = 2;
    protected int n_pro = 3;
    private protected int n_pripro = 4;
    public int n_pub = 5;
    public Protection() {
	System.out.println("base constructor");
	System.out.println("n = " + n);
	System.out.println("n_pri = " + n_pri);
	System.out.println("n_pro = " + n_pro);
	System.out.println("n_pripro = " + n_pripro);
	System.out.println("n_pub = " + n_pub);
    }
}

class derived extends Protection {
    derived() {
	System.out.println("derived constructor");
	System.out.println("n = " + n);
//	System.out.println("n_pri = " + n_pri);		// class
	System.out.println("n_pro = " + n_pro);
	System.out.println("n_pripro = " + n_pripro);
	System.out.println("n_pub = " + n_pub);
    }
}

class samepackage {
    samepackage() {
	Protection p = new Protection();
	System.out.println("same package constructor");
	System.out.println("n = " + p.n);
//	System.out.println("n_pri = " + p.n_pri);	// class
	System.out.println("n_pro = " + p.n_pro);
//	System.out.println("n_pripro = " + p.n_pripro);	// class, subclass
	System.out.println("n_pub = " + p.n_pub);
    }
}
