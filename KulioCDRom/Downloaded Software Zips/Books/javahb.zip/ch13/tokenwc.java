    public static void wc(FileInputStream f) throws IOException {
        StreamTokenizer tok = new StreamTokenizer(f);
        tok.resetSyntax();
        tok.wordChars(33, 255);
        tok.whitespaceChars(0, ' ');
        tok.eolIsSignificant(true);
        while (tok.ttype != tok.TT_EOF) {
            int tokenType = tok.nextToken();
            switch (tokenType) {
                case tok.TT_EOL:
                    lines++;
                    chars++;
                    break;
                case tok.TT_WORD:
                    words++;
                default: // FALLSTHROUGH
                    chars += tok.sval.length();
                    break;
            }
        }
    }
