public static void wc(InputStream f) throws IOException {
	int c=0;
	PushbackInputStream pbf = new PushbackInputStream(f);
	String whiteSpace = " \t\n\r";
	while ((c = pbf.read()) != -1) {
		chars++;
		if (c == '\n') {
			lines++;
		}
		if (whiteSpace.indexOf(c) != -1) {
			c = pbf.read();
			if (whiteSpace.indexOf(c) != -1) {
				words++;
			}
			pbf.unread(c);
		}
	}
}
