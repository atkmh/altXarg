// note: I had to rename this, since the chapter builds on Point
// and I though you'd like to see each version of Point.java

class Point0 {
    int x;
    int y;
}
