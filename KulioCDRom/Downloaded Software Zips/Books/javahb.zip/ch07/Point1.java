// note: I had to rename this, since the chapter builds on Point
// and I though you'd like to see each version of Point.java

class Point1 {
    int x;
    int y;

    public static void main(String args[]) {
	Point1 p = new Point1();
	p.x = 10;
	p.y = 20;
	System.out.println("x = " + p.x + " y = " + p.y);
    }
}
