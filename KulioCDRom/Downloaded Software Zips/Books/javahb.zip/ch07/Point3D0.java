class Point3D0 extends Point {
    int z;
    Point3D0(int x, int y, int z) {
	this.x = x;
	this.y = y;
	this.z = z;
    }
    Point3D0() {
	this(-1, -1, -1);
    }
}
