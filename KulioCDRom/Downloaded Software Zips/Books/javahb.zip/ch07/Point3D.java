class Point3D extends Point {
    int z;
    Point3D(int x, int y, int z) {
	super(x, y);	// this calls the Point(x, y) constructor
	this.z = z;
    }
    public static void main(String args[]) {
	Point3D p = new Point3D(10, 20, 30);
	System.out.println("x = " + p.x +
			   " y = " + p.y +
			   " z = " + p.z);
    }
}
