// note: I had to rename this, since the chapter builds on Point
// and I though you'd like to see each version of Point.java

class Point3 {
    int x;
    int y;

    Point3(int x, int y) {
	this.x = x;
	this.y = y;
    }
    Point3() {
	this(-1, -1);
    }
}
