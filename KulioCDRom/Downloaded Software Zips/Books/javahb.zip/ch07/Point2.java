// note: I had to rename this, since the chapter builds on Point
// and I though you'd like to see each version of Point.java

class Point2 {
    int x;
    int y;

    void init(int a, int b) {
	x = a;
	y = b;
    }
}
