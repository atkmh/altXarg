class Point {
    int x;
    int y;
    void init(int x, int y) {
	this.x = x;
	this.y = y;
    }
    public static void main(String args[]) {
	Point p = new Point();
	p.x = 10;
	p.y = 20;
	System.out.println("x = " + p.x + " y = " + p.y);
    }
}
