class Exc3 {
    public static void main(String args[]) {
	int d = 0;
	int a;
	try
	    a = 42 / d;
	catch (ArithmeticException e)
	    System.out.println("division by zero");
    }
}
