/*
 *  <applet code="HelloWorldApplet" width=100 height=40>
 *  </applet>
 *
 */
import java.applet.*;
import java.awt.*;

public class HelloWorldApplet extends Applet {

    public void paint(Graphics g) {

        g.setColor(Color.black);
        g.drawString("Hello World!", 20 ,20);
    }
}


