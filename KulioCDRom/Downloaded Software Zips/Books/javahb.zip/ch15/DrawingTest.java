/*
 *  <applet code="DrawingTest" width=400 height=400>
 *  </applet>
 *
 */
import java.applet.*;
import java.awt.*;

public class DrawingTest extends Applet {

    int testNumber = 0;
    final int tests = 9;

    public void paint(Graphics g) {
        Dimension d = size();

        g.setColor(Color.white);
        g.fillRect(0,0,d.width,d.height);

        g.setColor(Color.black);

        int xpoints[] = {25, 145, 25, 145, 25};
        int ypoints[] = {25, 25, 145, 145, 25};
        int npoints = 5;

        switch(testNumber) {
            case 0: g.drawLine(25, 25, 120, 120);
                    System.out.println("g.drawLine(25, 25, 120, 120);");
                    break;
            case 1: g.drawRect(25, 25, 120, 120);
                    System.out.println("g.drawRect(25, 25, 120, 120);");
                    break;
            case 2: g.fillRect(25, 25, 120, 120);
                    System.out.println("g.fillRect(25, 25, 120, 120);");
                    break;
            case 3: g.drawOval(25, 25, 120, 120);
                    System.out.println("g.drawOval(25, 25, 120, 120);");
                    break;
            case 4: g.fillOval(25, 25, 120, 120);
                    System.out.println("g.fillOval(25, 25, 120, 120);");
                    break;
            case 5: g.drawArc(25, 25, 120, 120, 45, 270);
                    System.out.println("g.drawArc(25, 25, 120, 120, 45, 270)");
                    break;
            case 6: g.fillArc(25, 25, 120, 120, 45, 270);
                    System.out.println("g.fillArc(25, 25, 120, 120, 45, 270)");
                    break;
            case 7: g.drawPolygon(xpoints, ypoints, npoints);
                    System.out.println("g.drawPolygon(xpoints, ypoints, npoints);");
                    break;
            case 8: g.fillPolygon(xpoints, ypoints, npoints);
                    System.out.println("g.fillPolygon(xpoints, ypoints, npoints);");
                    break;

        }

        g.setColor(Color.lightGray);
        for(int y=0; y<d.height; y=y+10) {
            g.drawLine(0,y,d.width,y);
        }
        for(int x=0; x<d.width; x=x+10) {
            g.drawLine(x, 0, x, d.height);
        }

    }

    public boolean mouseUp(java.awt.Event evt, int x, int y) {
        testNumber = (testNumber + 1) % tests;
        repaint();
        return true;
    }
}


