/*
 *  <applet code="InitOrStart" width=100 height=40>
 *  </applet>
 *
 */
import java.applet.*;
import java.awt.*;

public class InitOrStart extends Applet {

    public void init() {
        System.out.println("Initing");
    }

    public void start() {
        System.out.println("Starting");
    }
        
    public void paint(Graphics g) {
        System.out.println("Painting");
    }
        
    public void stop() {
        System.out.println("Stopping");
    }
        

}


