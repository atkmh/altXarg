/*
 *  <applet code="WhatFontsAreHere" width=100 height=40>
 *  </applet>
 *
 */
import java.applet.*;
import java.awt.*;

public class WhatFontsAreHere extends Applet {

    public void init() {
        String FontList[] = new String[1000];

        FontList = getToolkit().getFontList();

        int i = 0;

        try {
            while(FontList[i] != null) {
                System.out.println(i + ": " + FontList[i]);
                i++;
            }
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(i + " fonts are available under Java here");
        }
    }
}


