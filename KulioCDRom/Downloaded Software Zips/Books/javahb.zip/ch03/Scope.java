
public class Scope {
    public static void main(String args[]) {
	int b = 1;	// outer scope.
        {		// creates a new scope
	    int b = 2;	// compile time error...
	}
    }
}
