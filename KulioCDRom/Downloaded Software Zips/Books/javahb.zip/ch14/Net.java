import java.net.*;
import java.io.*;
import Hex;

class Net {
	static void p(String s) {
		System.out.println(s);
	}
	
	public static void main(String args[]) throws Exception {
		byte buff[] = new byte[1024];
//		InetAddress addr = InetAddress.getByName(null);
		InetAddress addr = InetAddress.getLocalHost();
//		InetAddress addr = InetAddress.getByName("ColorLink2");
//		p("LocalHost: " + Hex.byteToHex(addr.getAddress()));
		Socket s = new Socket(addr,80);

		OutputStream output = s.getOutputStream();
		InputStream input = s.getInputStream();
		String GetCmd = "GET /index.html HTTP/1.0\r\n\r\n";
		GetCmd.getBytes(0,GetCmd.length(),buff,0);
		output.write(buff);
		input.read(buff,0,buff.length);
		p(new String(buff,0));

	}
		
}
GMT