import java.net.*;

class WhatMachine {
	public static void main(String args[]) throws Exception {
		InetAddress myAddress = InetAddress.getLocalHost();
		System.out.println(myAddress);
	}
}
