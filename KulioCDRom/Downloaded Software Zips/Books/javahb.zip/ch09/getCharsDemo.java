class getCharsDemo {
    public static void main(String args[]) {
	String s = "This is an demo of the getChars method.";
	int start = 11;
	int end = 15;
	char buf[] = new char[end - start];
	s.getChars(start, end, buf, 0);
	System.out.println(buf);
    }
}

