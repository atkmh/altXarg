class insertDemo {
    public static void main(String args[]) {
	StringBuffer sb = new StringBuffer("hello world!");
	sb.insert(6, "there ");
	System.out.println(sb);
    }
}

