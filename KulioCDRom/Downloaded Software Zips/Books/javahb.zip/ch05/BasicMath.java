class BasicMath {
    public static void main(String args[]) {
	int a = 1 + 1;
	int b = a * 3;
	int c = b / 4;
	int d = b - a;
	int e = -d;
	System.out.println("a = " + a);
	System.out.println("b = " + b);
	System.out.println("c = " + c);
	System.out.println("d = " + d);
	System.out.println("e = " + e);
    }
}
