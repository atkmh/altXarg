
class CurrentThreadDemo {
    public static void main(String args[]) {
	Thread t = Thread.currentThread();
	t.setName("My Thread");
	t.setPriority(1);
	System.out.println("current thread: " + t);
	int active = t.activeCount();
	System.out.println("currently active threads: " + active);
	Thread all[] = new Thread[active];
	t.enumerate(all);
	for (int i = 0; i < active; i++) {
	    System.out.println(i + ": " + all[i]);
	}
	try {
	    for (int n = 5; n > 0; n--) {
		System.out.println("" + n);
		t.sleep(1000);
	    }
	} catch (InterruptedException e) {
	    System.out.println("interrupted");
	}
	t.dumpStack();
    }
}
