class Callme {
    void call(String msg) {
	System.out.print("[" + msg);
	try Thread.sleep(1000); catch (Exception e);
	System.out.println("]");
    }
}
class caller implements Runnable {
    String msg;
    Callme target;
    public caller(Callme t, String s) {
	target = t;
	msg = s;
	new Thread(this).start();
    }
    public void run() {
	target.call(msg);
    }
}
class Synch {
    public static void main(String args[]) {
	Callme target = new Callme();
	new caller(target, "Hello");
	new caller(target, "Synchronized");
	new caller(target, "World");
    }
}
