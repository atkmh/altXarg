// CupsAndStringGUI
//
// An instance of this class is used to manage a GUI for
// the CupsAndStrings application. Extensive use of inner classes
// is used so that Frame and other classes don't have to be
// extended in a top-level class.
//
// Important public methods are:
// getInputTextComponent() - returns a reference to the
//    TextComponent user's type messages into.
// getMainWindow() - returns a reference to the top-level Window
//    in the GUI. Use to show or hide the interface, or to set
//    its size, or to listen for CLOSE events.
// reset() - clears to remote name, and disables the user
//    input text component. Clears any display of previous
//    remote or local messages.
// setRemoteName() - sets the remote name, and re-enables the
//    user inp0ut text component.
// addRemoteMessage() - adds a remote string message to the
//    display.
// addLocalMessage() - adds a local string message to the
//    display.

import java.awt.*;
import java.awt.event.*;

public class CupsAndStringGUI {
	private Frame frame = null;
	private Label labelRemoteName = null;
	private List listRemote = null;
	private List listLocal = null;
	private TextField tfInput = null;
	
	public CupsAndStringGUI() {
		// Build the GUI out of layers of components and
		// containers.
		Panel panelInput = new Panel() {
			public Insets getInsets() {
				return new Insets(3, 3, 3, 3);
			}
		};
		panelInput.setLayout(new FlowLayout(FlowLayout.CENTER,
											5, 5));
		panelInput.add(new Label("Send message:"));
		panelInput.add(tfInput = new TextField(30));
		
		Panel panelLocal = new Panel() {
			public Insets getInsets() {
				return new Insets(3, 3, 3, 3);
			}
		};
		panelLocal.setLayout(new BorderLayout(5, 5));
		panelLocal.add("North", new Label("Your messages:"));
		panelLocal.add("Center", listLocal =
											new List());

		Panel panelRemote = new Panel() {
			public Insets getInsets() {
				return new Insets(3, 3, 3, 3);
			}
		};
		panelRemote.setLayout(new BorderLayout(5, 5));
		panelRemote.add("North", labelRemoteName =
					   new Label("<not connected>"));
		panelRemote.add("Center", listRemote =
					   new List());
		
		Panel panelMessages = new Panel() {
			public Insets getInsets() {
				return new Insets(0, 0, 0, 0);
			}
		};
		panelMessages.setLayout(new GridLayout(1, 2, 0, 0));
		panelMessages.add(panelLocal);
		panelMessages.add(panelRemote);
		
		frame = new Frame("Cups and String \"Chat\" App");
		frame.setLayout(new BorderLayout());
		frame.add("Center", panelMessages);
		frame.add("South", panelInput);
		
		reset();
	}
	
	public void reset() {
		labelRemoteName.setText("<not connected>");
		listRemote.removeAll();
		listLocal.removeAll();
		tfInput.setEnabled(false);
	}
	
	public TextField getInputTextField() {
		return tfInput;
	}
	
	public Window getMainWindow() {
		return frame;
	}
	
	public void setRemoteName(String strRemoteName) {
		labelRemoteName.setText(strRemoteName);
		tfInput.setEnabled(true);
	}
	
	public void addRemoteMessage(String strMessage) {
		listRemote.addItem(strMessage, 0);
		listLocal.addItem("", 0);
	}
	
	public void addLocalMessage(String strMessage) {
		listRemote.addItem("", 0);
		listLocal.addItem(strMessage, 0);
	}
	
	public void printComponentSizes() {
		int basex = frame.getLocation().x;
		int basey = frame.getLocation().y;
		
		java.util.Stack stack  = new java.util.Stack();
		stack.push(frame);
		
		while(!stack.isEmpty()) {
			Component c = (Component)stack.pop();
			
			if(!(c instanceof Panel)) {
				Rectangle bounds = c.getBounds();
				Point locScreen = c.getLocationOnScreen();
			
				bounds.x = locScreen.x - basex;
				bounds.y = locScreen.y - basey;
			
				System.out.println("Component " + c.getName() + ": " + bounds);
			}
			
			if(c instanceof Container) {
				Component[] ac = ((Container)c).getComponents();
				for(int ii=0 ; ii<ac.length ; ii++)
					stack.push(ac[ii]);
			}
		}
	}
}
