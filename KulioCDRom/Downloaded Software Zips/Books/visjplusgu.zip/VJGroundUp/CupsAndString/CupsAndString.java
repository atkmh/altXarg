// CupsAndString application class. This class creates the
// Java interface for a peer-to-peer message-based application.
// This class also implements the UDP-based communication between
// the two peers.
//
// This interface is defined by the class CupsAndStringGUI.
// The GUI exposes three public members: RemoteTextList,
// LocalTextList and TextInput. When new input from either
// remote or local occurs, the two List objects are updated.
// When the user places new input into the TextInput edit box,
// then the text can be sent off to the remote side of the
// conversation. The exact placement of the list boxes and
// edit box are left completely up to the CupsAndStringsGUI
// class.
//
// The program can be started up in one of two modes: waiting
// for a remote client to contact (as a server), or trying to
// contact a remote client. In either case the local application
// requires a local user name and UDP port number to use (the
// default local IP address is automatically used).
//
// Command-line syntax is:
//   CupsAndString <local-name> <local-port> _
//       [<remote-IP-address> <remote-port>]
//
// The inclusion of the second set of command-line arguments
// indicates the program is to attempt to connect to remote
// server. Without the second set of command-line arguments,
// program is to start as a server, ready to accept any
// connections.
//
// Note that there is no timeout values in this application.
// You just have to quit the application when the remote
// side is unresponsive.

import java.net.*;
import java.io.*;

import java.awt.*;
import java.awt.event.*;

public class CupsAndString
{
	static CupsAndStringGUI gui = null;
	  // Receiver and Sender are inner classes, defined
	  // below.
	static Receiver receiver = null;
	static Sender sender = null;
	static boolean fInitialPacketSent = false;
	static String strLocalName = null;
	
	static InetAddress addrRemoteClient = null;
	static int nRemoteClientPort = -1;
	
	  // Local DatagramSocket to send UDP packets
	  // out.
	static DatagramSocket localDS = null;
	
	public static final int MAX_MESSAGE_LENGTH = 256;
	
	
	// Create CupsAndStringGUI, read in command-line
	// args and initialize application accordingly.
	public static void main(String[] args)
	{
		// Read in command-line args.
		if(args.length != 2 && args.length != 4) {
			System.err.println("USAGE:");
			System.err.println("\tCupsAndStrings <local-name> <local-port> [<remote-IP-address> <remote-port>]");
			System.exit(-1);
		}
		
		InetAddress addrRemoteHost = null;
		int nRemotePort = -1;
		boolean fServer = true;
		try {
			strLocalName = args[0];
			int nLocalPort = Integer.parseInt(args[1]);
			
			localDS = new DatagramSocket(nLocalPort);
			
			if(args.length == 4) {
				String strRemoteName = args[2];
				addrRemoteHost = InetAddress.getByName(strRemoteName);
				nRemotePort = Integer.parseInt(args[3]);
				fServer = false;
			}
		} catch (NumberFormatException nfe) {
			System.err.println("Error reading numeric input parameters: " + nfe);
			System.exit(-1);
		} catch (UnknownHostException uke) {
			System.err.println("Error unknwon host: " + uke);
			System.exit(-1);
		} catch (SocketException se) {
			  System.err.println("Error setting up the local DatagramSocket: " + se);
			  System.exit(-1);
		}
		
		// Create GUI
		gui = new CupsAndStringGUI();
		new ExitListener();
		Component c = gui.getMainWindow();
		c.setSize(350, 250); // Hard-coded initial
							 // size of main window
		c.setVisible(true);
		
		gui.printComponentSizes();
		
		receiver = new Receiver();
		
		// If remote system specified, send off initial
		// packet with local user name
		if(!fServer)
			sendInitialPacket(addrRemoteHost,
							  nRemotePort);
	}
	
	// sendInitialPacket
	//
	// Sends an initial Datagram packet from the local UDP
	// DatagramSocket to a remote host. The initial packet
	// just contains the local username (passed as a parameter).
	private static void sendInitialPacket(
								   InetAddress addrRemoteHost,
								   int nRemotePort) {
		if(fInitialPacketSent)
			return;
		
		try {
			byte[] ab = strLocalName.getBytes();
			DatagramPacket dp = new DatagramPacket(ab, ab.length,
												   addrRemoteHost,
												   nRemotePort);
			
			localDS.send(dp);
			
			fInitialPacketSent = true;
		} catch (IOException ioe) {
			System.err.println("Unable to send initial packet: " + ioe);
			System.exit(-1);
		}
	}
	
	// sendFinalPacket
	//
	// If there is a sender, tell the sender to send a final
	// "QUITTING" packet.
	private static void sendFinalPacket() {
		if(sender == null)
			return;
		
		byte[] ab = "QUITTING".getBytes();
		sender.sendPacket(ab);
	}
	
	// remoteClientQuit()
	//
	// Is called by the Receiver background thread when the
	// remote client sends the "QUITTING" message. In this case
	// the remote address and port number, sender and receiver
	// must be killed. A new receiver is created. This puts
	// the app back into "server waiting for connection" mode.
	private static void remoteClientQuit() {
		receiver = null;
		sender.destroy();
		sender = null;
		addrRemoteClient = null;
		nRemoteClientPort = -1;
		fInitialPacketSent = false;
		
		receiver = new Receiver();
		
		gui.reset();
	}
	
	// remoteClientJoin()
	//
	// Called by the receiver when an initial packet is received
	// from a remote client. Task is to store the remote address
	// and port number away, and to create a new Sender. Also
	// we must update the gui with the new remote client's name.
	private static void remoteClientJoin(String strName,
								   InetAddress addrRemoteHost,
								   int nRemotePort) {
		addrRemoteClient = addrRemoteHost;
		nRemoteClientPort = nRemotePort;
		sender = new Sender();
		gui.setRemoteName(strName);
		sendInitialPacket(addrRemoteHost, nRemotePort);
	}
	
	// inner class ExitListener
	// This WindowListener implementation is just waiting for the
	// WINDOW_CLOSING event to occur (i.e., user hits close
	// button on main window. When that happens, a last packet is
	// sent to the other end of the conversation (if there is one)
	// and the application quits.
	private static class ExitListener extends WindowAdapter {
		public ExitListener() {
			// Set this listener up to listen to main
			// window, accessed through outer member "gui".
			Window w = gui.getMainWindow();
			w.addWindowListener(this);
		}
		
		public void windowClosing(WindowEvent we) {
			Window w = (Window)we.getSource();
			w.removeWindowListener(this);

			sendFinalPacket();
			
			System.out.println("Quitting from user request.");
			System.exit(0);
		}
	}
	
	// inner class Receiver
	//
	// Receives packets from a remote client. The very first
	// packet is always a packet with the remote user's name
	// in it. A packet with just the text "QUITTING" means
	// the remote user is quitting. Must call outer class
	// member "remoteClientQuit()".
	private static class Receiver implements Runnable {
		public Receiver() {
			Thread t = new Thread(this);
			t.start();
		}
		
		public void run() {
			try {
				// Maximum message length defined by outer
				// class constant MAX_MESSAGE_LENGTH.
				byte[] ab = new byte[MAX_MESSAGE_LENGTH];
				DatagramPacket dp = new DatagramPacket(ab, ab.length);
			
				// Receive initial client packet.
				localDS.receive(dp);
				
				String strRemoteName = new String(ab, 0, dp.getLength());
				remoteClientJoin(strRemoteName,
								 dp.getAddress(),
								 dp.getPort());
				strRemoteName = null;
				
				// Receive all subsequent client packets and
				// write them to the gui.
				while(true) {
					dp = new DatagramPacket(ab, ab.length);
					localDS.receive(dp);
					String strRemoteMessage = new String(ab, 0,
														 dp.getLength());
					
					// If is the "QUITTING" message from remote
					// system, call outer method remoteClientQuit()
					// and kill this thread.
					if(strRemoteMessage.equals("QUITTING")) {
						remoteClientQuit();
						break;
					}
					
					gui.addRemoteMessage(strRemoteMessage);
				}
			} catch (IOException ioe) {
				System.err.println("Error receiving remote packet: " + ioe);
				System.exit(-1);
			}
		}
	}
	
	// inner class Sender
	//
	// Listens for action events from the GUI's textbox. When
	// occurs, gets text from text box and sends to remote
	// client. Note: not runnable, but instead uses the
	// AWT-callback thread.
	private static class Sender implements ActionListener {
		TextField tf = null;
		
		public Sender() {
			tf = gui.getInputTextField();
			tf.addActionListener(this);
		}
		
		public void actionPerformed(ActionEvent ae) {
			String strMessage = tf.getText();
			tf.setText("");
			if(strMessage.length() == 0)
				return;
			
			byte[] ab = strMessage.getBytes();
			sendPacket(ab);
			
			gui.addLocalMessage(strMessage);
		}
		
		private void sendPacket(byte[] ab) {
			try {
				DatagramPacket dp = new DatagramPacket(ab, ab.length,
													   addrRemoteClient,
													   nRemoteClientPort);
				localDS.send(dp);
			} catch (IOException ioe) {
				System.err.println("Error sending packet: " + ioe);
				System.exit(-1);
			}
		}
		
		public void destroy() {
			tf.removeActionListener(this);
		}
	}
}