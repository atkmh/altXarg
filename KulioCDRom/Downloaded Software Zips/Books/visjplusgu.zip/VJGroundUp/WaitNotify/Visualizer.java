import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'Visualizer'
 * created in the main() method.
 */
public class Visualizer extends Form
{
	private Object object1, object2;
	private Object objWaitObject, objNotifyObject;
	
	public Visualizer()
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		object1 = new Object();
		object2 = new Object();
		
		objWaitObject = object1;
		objNotifyObject = object1;
		
		radioObject1Wait.setChecked(true);
		radioObject1Notify.setChecked(true);
		
		controlThread.startVisuals();
	}

	/**
	 * Visualizer overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}

	private void radioObject1Wait_checkedChanged(Object source, Event e)
	{
		objWaitObject = object1;
	}

	private void radioObject2Wait_checkedChanged(Object source, Event e)
	{
		objWaitObject = object2;
	}

	private void radioObject1Notify_checkedChanged(Object source, Event e)
	{
		objNotifyObject = object1;
	}

	private void radioObject2Notify_checkedChanged(Object source, Event e)
	{
		objNotifyObject = object2;
	}

	private void buttonWait_click(Object source, Event e)
	{
		controlThread.waitFor(this.objWaitObject);
	}

	private void buttonNotify_click(Object source, Event e)
	{
		synchronized(objNotifyObject) {
			objNotifyObject.notifyAll();
		}
	}

	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();
	GroupBox groupThread = new GroupBox();
	AnimatedCircle controlThread = new AnimatedCircle();
	RadioButton radioObject1Wait = new RadioButton();
	RadioButton radioObject2Wait = new RadioButton();
	Button buttonWait = new Button();
	GroupBox groupNotify = new GroupBox();
	RadioButton radioObject1Notify = new RadioButton();
	RadioButton radioObject2Notify = new RadioButton();
	Button buttonNotify = new Button();

	private void initForm()
	{
		this.setText("Visualizer");
		this.setAutoScaleBaseSize(new Point(5, 13));
		this.setClientSize(new Point(372, 171));

		groupThread.setLocation(new Point(8, 8));
		groupThread.setSize(new Point(360, 88));
		groupThread.setTabIndex(0);
		groupThread.setTabStop(false);
		groupThread.setText("The Thread");

		controlThread.setLocation(new Point(16, 16));
		controlThread.setSize(new Point(88, 64));
		controlThread.setTabIndex(0);
		controlThread.setText("controlThread");

		radioObject1Wait.setLocation(new Point(152, 16));
		radioObject1Wait.setSize(new Point(88, 24));
		radioObject1Wait.setTabIndex(2);
		radioObject1Wait.setText("Object 1");
		radioObject1Wait.addOnCheckedChanged(new EventHandler(this.radioObject1Wait_checkedChanged));

		radioObject2Wait.setLocation(new Point(248, 16));
		radioObject2Wait.setSize(new Point(88, 24));
		radioObject2Wait.setTabIndex(1);
		radioObject2Wait.setText("Object 2");
		radioObject2Wait.addOnCheckedChanged(new EventHandler(this.radioObject2Wait_checkedChanged));

		buttonWait.setLocation(new Point(200, 48));
		buttonWait.setSize(new Point(80, 24));
		buttonWait.setTabIndex(3);
		buttonWait.setText("wait()");
		buttonWait.addOnClick(new EventHandler(this.buttonWait_click));

		groupNotify.setLocation(new Point(8, 104));
		groupNotify.setSize(new Point(360, 64));
		groupNotify.setTabIndex(1);
		groupNotify.setTabStop(false);
		groupNotify.setText("Notification");

		radioObject1Notify.setLocation(new Point(152, 24));
		radioObject1Notify.setSize(new Point(88, 24));
		radioObject1Notify.setTabIndex(0);
		radioObject1Notify.setText("Object 1");
		radioObject1Notify.addOnCheckedChanged(new EventHandler(this.radioObject1Notify_checkedChanged));

		radioObject2Notify.setLocation(new Point(248, 24));
		radioObject2Notify.setSize(new Point(88, 24));
		radioObject2Notify.setTabIndex(1);
		radioObject2Notify.setText("Object 2");
		radioObject2Notify.addOnCheckedChanged(new EventHandler(this.radioObject2Notify_checkedChanged));

		buttonNotify.setLocation(new Point(16, 24));
		buttonNotify.setSize(new Point(104, 24));
		buttonNotify.setTabIndex(2);
		buttonNotify.setText("notify()");
		buttonNotify.addOnClick(new EventHandler(this.buttonNotify_click));

		this.setNewControls(new Control[] {
							groupNotify, 
							groupThread});
		groupThread.setNewControls(new Control[] {
								   buttonWait, 
								   radioObject2Wait, 
								   radioObject1Wait, 
								   controlThread});
		groupNotify.setNewControls(new Control[] {
								   buttonNotify, 
								   radioObject2Notify, 
								   radioObject1Notify});
	}

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main(String args[])
	{
		Application.run(new Visualizer());
	}
}
