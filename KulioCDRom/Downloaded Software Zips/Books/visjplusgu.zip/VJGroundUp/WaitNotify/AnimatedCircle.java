import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;

/**
 * This class is a visual component. The entry point for class execution
 * is the constructor.
 */
public class AnimatedCircle extends UserControl
		implements Runnable
{
	private Thread thread;
	private int timer = 0;
	private Object objWaitFor;
	
	public AnimatedCircle()
	{
		super();

		// Required for Visual J++ Form Designer support
		//
		initForm();

	}
	
	public void onPaint(Object sender, PaintEvent evt) {
		Graphics g = evt.graphics;
		int value = timer % 256;
		Brush br = new Brush(new Color(value, value, value));
		g.setBrush(br);
		g.drawArc(getDisplayRect(),
				  new Point(), new Point());
		g.fill(getDisplayRect(), br);
	}
	
	public void startVisuals() {
		thread = new Thread(this);
		thread.start();
	}
	
	public void stopVisuals() {
		thread = null;
	}
	
	public void waitFor(Object objWaitFor) {
		if(this.objWaitFor != null)
			return;
		this.objWaitFor = objWaitFor;
	}
	
	public void run() {
		try {
			while(true) {
				invalidate();
				Thread.sleep(100);
				timer += 10;
			
				if(objWaitFor != null) {
					synchronized(objWaitFor) {
						objWaitFor.wait();
						objWaitFor = null;
					}
				}
			}
		} catch (InterruptedException ie) {
		}
	}

	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();

	private void initForm()
	{
		this.setSize(new Point(106, 85));
		this.setText("AnimatedCircle");
		this.addOnPaint(new PaintEventHandler(this.onPaint));
	}

	public static class ClassInfo extends UserControl.ClassInfo
	{
		// TODO: Add your property and event infos here
	}
}
