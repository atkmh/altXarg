//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface ShapeRange
/** @com.interface(iid=9149347A-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface ShapeRange extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="Apply", addFlagsVtable=4)
      @com.parameters() */
  public void Apply();

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=9, dispid=13, type=METHOD, name="Flip", addFlagsVtable=4)
      @com.parameters([in,type=I4] FlipCmd) */
  public void Flip(int FlipCmd);

  /** @com.method(vtoffset=10, dispid=14, type=METHOD, name="IncrementLeft", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementLeft(float Increment);

  /** @com.method(vtoffset=11, dispid=15, type=METHOD, name="IncrementRotation", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementRotation(float Increment);

  /** @com.method(vtoffset=12, dispid=16, type=METHOD, name="IncrementTop", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementTop(float Increment);

  /** @com.method(vtoffset=13, dispid=17, type=METHOD, name="PickUp", addFlagsVtable=4)
      @com.parameters() */
  public void PickUp();

  /** @com.method(vtoffset=14, dispid=18, type=METHOD, name="RerouteConnections", addFlagsVtable=4)
      @com.parameters() */
  public void RerouteConnections();

  /** @com.method(vtoffset=15, dispid=19, type=METHOD, name="ScaleHeight", addFlagsVtable=4)
      @com.parameters([in,type=R4] Factor, [in,type=I4] RelativeToOriginalSize, [in,type=I4] fScale) */
  public void ScaleHeight(float Factor, int RelativeToOriginalSize, int fScale);

  /** @com.method(vtoffset=16, dispid=20, type=METHOD, name="ScaleWidth", addFlagsVtable=4)
      @com.parameters([in,type=R4] Factor, [in,type=I4] RelativeToOriginalSize, [in,type=I4] fScale) */
  public void ScaleWidth(float Factor, int RelativeToOriginalSize, int fScale);

  /** @com.method(vtoffset=17, dispid=22, type=METHOD, name="SetShapesDefaultProperties", addFlagsVtable=4)
      @com.parameters() */
  public void SetShapesDefaultProperties();

  /** @com.method(vtoffset=18, dispid=23, type=METHOD, name="Ungroup", addFlagsVtable=4)
      @com.parameters([iid=9149347A-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShapeRange Ungroup();

  /** @com.method(vtoffset=19, dispid=24, type=METHOD, name="ZOrder", addFlagsVtable=4)
      @com.parameters([in,type=I4] ZOrderCmd) */
  public void ZOrder(int ZOrderCmd);

  /** @com.method(vtoffset=20, dispid=100, type=PROPGET, name="Adjustments", addFlagsVtable=4)
      @com.parameters([iid=9149347C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Adjustments getAdjustments();

  /** @com.method(vtoffset=21, dispid=101, type=PROPGET, name="AutoShapeType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAutoShapeType();

  /** @com.method(vtoffset=22, dispid=101, type=PROPPUT, name="AutoShapeType", addFlagsVtable=4)
      @com.parameters([in,type=I4] AutoShapeType) */
  public void setAutoShapeType(int AutoShapeType);

  /** @com.method(vtoffset=23, dispid=102, type=PROPGET, name="BlackWhiteMode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBlackWhiteMode();

  /** @com.method(vtoffset=24, dispid=102, type=PROPPUT, name="BlackWhiteMode", addFlagsVtable=4)
      @com.parameters([in,type=I4] BlackWhiteMode) */
  public void setBlackWhiteMode(int BlackWhiteMode);

  /** @com.method(vtoffset=25, dispid=103, type=PROPGET, name="Callout", addFlagsVtable=4)
      @com.parameters([iid=91493485-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.CalloutFormat getCallout();

  /** @com.method(vtoffset=26, dispid=104, type=PROPGET, name="ConnectionSiteCount", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getConnectionSiteCount();

  /** @com.method(vtoffset=27, dispid=105, type=PROPGET, name="Connector", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getConnector();

  /** @com.method(vtoffset=28, dispid=106, type=PROPGET, name="ConnectorFormat", addFlagsVtable=4)
      @com.parameters([iid=91493481-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ConnectorFormat getConnectorFormat();

  /** @com.method(vtoffset=29, dispid=107, type=PROPGET, name="Fill", addFlagsVtable=4)
      @com.parameters([iid=9149347E-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.FillFormat getFill();

  /** @com.method(vtoffset=30, dispid=108, type=PROPGET, name="GroupItems", addFlagsVtable=4)
      @com.parameters([iid=9149347B-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.GroupShapes getGroupItems();

  /** @com.method(vtoffset=31, dispid=109, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getHeight();

  /** @com.method(vtoffset=32, dispid=109, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=R4] Height) */
  public void setHeight(float Height);

  /** @com.method(vtoffset=33, dispid=110, type=PROPGET, name="HorizontalFlip", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHorizontalFlip();

  /** @com.method(vtoffset=34, dispid=111, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getLeft();

  /** @com.method(vtoffset=35, dispid=111, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left) */
  public void setLeft(float Left);

  /** @com.method(vtoffset=36, dispid=112, type=PROPGET, name="Line", addFlagsVtable=4)
      @com.parameters([iid=9149347F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.LineFormat getLine();

  /** @com.method(vtoffset=37, dispid=113, type=PROPGET, name="LockAspectRatio", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLockAspectRatio();

  /** @com.method(vtoffset=38, dispid=113, type=PROPPUT, name="LockAspectRatio", addFlagsVtable=4)
      @com.parameters([in,type=I4] LockAspectRatio) */
  public void setLockAspectRatio(int LockAspectRatio);

  /** @com.method(vtoffset=39, dispid=115, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=40, dispid=115, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);

  /** @com.method(vtoffset=41, dispid=116, type=PROPGET, name="Nodes", addFlagsVtable=4)
      @com.parameters([iid=91493486-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShapeNodes getNodes();

  /** @com.method(vtoffset=42, dispid=117, type=PROPGET, name="Rotation", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getRotation();

  /** @com.method(vtoffset=43, dispid=117, type=PROPPUT, name="Rotation", addFlagsVtable=4)
      @com.parameters([in,type=R4] Rotation) */
  public void setRotation(float Rotation);

  /** @com.method(vtoffset=44, dispid=118, type=PROPGET, name="PictureFormat", addFlagsVtable=4)
      @com.parameters([iid=9149347D-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PictureFormat getPictureFormat();

  /** @com.method(vtoffset=45, dispid=119, type=PROPGET, name="Shadow", addFlagsVtable=4)
      @com.parameters([iid=91493480-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShadowFormat getShadow();

  /** @com.method(vtoffset=46, dispid=120, type=PROPGET, name="TextEffect", addFlagsVtable=4)
      @com.parameters([iid=91493482-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextEffectFormat getTextEffect();

  /** @com.method(vtoffset=47, dispid=121, type=PROPGET, name="TextFrame", addFlagsVtable=4)
      @com.parameters([iid=91493484-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextFrame getTextFrame();

  /** @com.method(vtoffset=48, dispid=122, type=PROPGET, name="ThreeD", addFlagsVtable=4)
      @com.parameters([iid=91493483-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ThreeDFormat getThreeD();

  /** @com.method(vtoffset=49, dispid=123, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTop();

  /** @com.method(vtoffset=50, dispid=123, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=R4] Top) */
  public void setTop(float Top);

  /** @com.method(vtoffset=51, dispid=124, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=52, dispid=125, type=PROPGET, name="VerticalFlip", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVerticalFlip();

  /** @com.method(vtoffset=53, dispid=126, type=PROPGET, name="Vertices", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getVertices();

  /** @com.method(vtoffset=54, dispid=127, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=55, dispid=127, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=56, dispid=128, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWidth();

  /** @com.method(vtoffset=57, dispid=128, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=R4] Width) */
  public void setWidth(float Width);

  /** @com.method(vtoffset=58, dispid=129, type=PROPGET, name="ZOrderPosition", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getZOrderPosition();

  /** @com.method(vtoffset=59, dispid=2003, type=PROPGET, name="OLEFormat", addFlagsVtable=4)
      @com.parameters([iid=91493488-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.OLEFormat getOLEFormat();

  /** @com.method(vtoffset=60, dispid=2004, type=PROPGET, name="LinkFormat", addFlagsVtable=4)
      @com.parameters([iid=91493489-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.LinkFormat getLinkFormat();

  /** @com.method(vtoffset=61, dispid=2005, type=PROPGET, name="PlaceholderFormat", addFlagsVtable=4)
      @com.parameters([iid=91493477-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PlaceholderFormat getPlaceholderFormat();

  /** @com.method(vtoffset=62, dispid=2006, type=PROPGET, name="AnimationSettings", addFlagsVtable=4)
      @com.parameters([iid=9149348B-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.AnimationSettings getAnimationSettings();

  /** @com.method(vtoffset=63, dispid=2007, type=PROPGET, name="ActionSettings", addFlagsVtable=4)
      @com.parameters([iid=9149348C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ActionSettings getActionSettings();

  /** @com.method(vtoffset=64, dispid=2008, type=PROPGET, name="Tags", addFlagsVtable=4)
      @com.parameters([iid=914934B9-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Tags getTags();

  /** @com.method(vtoffset=65, dispid=2009, type=METHOD, name="Cut", addFlagsVtable=4)
      @com.parameters() */
  public void Cut();

  /** @com.method(vtoffset=66, dispid=2010, type=METHOD, name="Copy", addFlagsVtable=4)
      @com.parameters() */
  public void Copy();

  /** @com.method(vtoffset=67, dispid=2011, type=METHOD, name="Select", addFlagsVtable=4)
      @com.parameters([in,type=I4] Replace) */
  public void Select(int Replace);

  /** @com.method(vtoffset=68, dispid=2012, type=METHOD, name="Duplicate", addFlagsVtable=4)
      @com.parameters([iid=9149347A-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShapeRange Duplicate();

  /** @com.method(vtoffset=69, dispid=2013, type=PROPGET, name="MediaType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getMediaType();

  /** @com.method(vtoffset=70, dispid=2014, type=PROPGET, name="HasTextFrame", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHasTextFrame();

  /** @com.method(vtoffset=71, dispid=2015, type=PROPGET, name="SoundFormat", addFlagsVtable=4)
      @com.parameters([iid=91493473-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SoundFormat getSoundFormat();

  /** @com.method(vtoffset=72, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] index, [iid=91493479-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shape Item(Variant index);

  /** @com.method(vtoffset=73, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=74, dispid=8, type=METHOD, name="_Index", addFlagsVtable=4)
      @com.parameters([in,type=I4] _index, [type=VARIANT] return) */
  public Variant _Index(int _index);

  /** @com.method(vtoffset=75, dispid=9, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=76, dispid=2016, type=METHOD, name="Group", addFlagsVtable=4)
      @com.parameters([iid=91493479-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shape Group();

  /** @com.method(vtoffset=77, dispid=2017, type=METHOD, name="Regroup", addFlagsVtable=4)
      @com.parameters([iid=91493479-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shape Regroup();

  /** @com.method(vtoffset=78, dispid=2018, type=METHOD, name="Align", addFlagsVtable=4)
      @com.parameters([in,type=I4] AlignCmd, [in,type=I4] RelativeTo) */
  public void Align(int AlignCmd, int RelativeTo);

  /** @com.method(vtoffset=79, dispid=2019, type=METHOD, name="Distribute", addFlagsVtable=4)
      @com.parameters([in,type=I4] DistributeCmd, [in,type=I4] RelativeTo) */
  public void Distribute(int DistributeCmd, int RelativeTo);

  /** @com.method(vtoffset=80, dispid=2020, type=METHOD, name="GetPolygonalRepresentation", addFlagsVtable=4)
      @com.parameters([in,type=U4] maxPointsInBuffer, [in,size=1,elementType=R4,type=ARRAY] pPoints, [out,size=1,elementType=I4,type=ARRAY] numPointsInPolygon, [out,elementType=I4,type=PTR] IsOpen) */
  public void GetPolygonalRepresentation(int maxPointsInBuffer, float[] pPoints, int[] numPointsInPolygon, int[] IsOpen);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149347a, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
