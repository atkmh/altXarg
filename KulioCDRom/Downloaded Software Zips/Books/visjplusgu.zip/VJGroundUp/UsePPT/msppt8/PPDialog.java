//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface PPDialog
/** @com.interface(iid=914934A0-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface PPDialog extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Style", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getStyle();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="Mode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getMode();

  /** @com.method(vtoffset=8, dispid=2004, type=PROPPUT, name="Mode", addFlagsVtable=4)
      @com.parameters([in,type=I4] Mode) */
  public void setMode(int Mode);

  /** @com.method(vtoffset=9, dispid=2005, type=PROPGET, name="HelpId", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHelpId();

  /** @com.method(vtoffset=10, dispid=2005, type=PROPPUT, name="HelpId", addFlagsVtable=4)
      @com.parameters([in,type=I4] HelpId) */
  public void setHelpId(int HelpId);

  /** @com.method(vtoffset=11, dispid=2006, type=PROPGET, name="HideOnIdle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHideOnIdle();

  /** @com.method(vtoffset=12, dispid=2006, type=PROPPUT, name="HideOnIdle", addFlagsVtable=4)
      @com.parameters([in,type=I4] HideOnIdle) */
  public void setHideOnIdle(int HideOnIdle);

  /** @com.method(vtoffset=13, dispid=2007, type=PROPGET, name="resourceDLL", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getResourceDLL();

  /** @com.method(vtoffset=14, dispid=2007, type=PROPPUT, name="resourceDLL", addFlagsVtable=4)
      @com.parameters([in,type=STRING] resourceDLL) */
  public void setResourceDLL(String resourceDLL);

  /** @com.method(vtoffset=15, dispid=2008, type=PROPGET, name="Caption", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getCaption();

  /** @com.method(vtoffset=16, dispid=2008, type=PROPPUT, name="Caption", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Caption) */
  public void setCaption(String Caption);

  /** @com.method(vtoffset=17, dispid=2009, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getLeft();

  /** @com.method(vtoffset=18, dispid=2009, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left) */
  public void setLeft(float Left);

  /** @com.method(vtoffset=19, dispid=2010, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTop();

  /** @com.method(vtoffset=20, dispid=2010, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=R4] Top) */
  public void setTop(float Top);

  /** @com.method(vtoffset=21, dispid=2011, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWidth();

  /** @com.method(vtoffset=22, dispid=2011, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=R4] Width) */
  public void setWidth(float Width);

  /** @com.method(vtoffset=23, dispid=2012, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getHeight();

  /** @com.method(vtoffset=24, dispid=2012, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=R4] Height) */
  public void setHeight(float Height);

  /** @com.method(vtoffset=25, dispid=2013, type=PROPGET, name="ClientLeft", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getClientLeft();

  /** @com.method(vtoffset=26, dispid=2014, type=PROPGET, name="ClientTop", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getClientTop();

  /** @com.method(vtoffset=27, dispid=2015, type=PROPGET, name="ClientWidth", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getClientWidth();

  /** @com.method(vtoffset=28, dispid=2016, type=PROPGET, name="ClientHeight", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getClientHeight();

  /** @com.method(vtoffset=29, dispid=2017, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=30, dispid=2017, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=31, dispid=2018, type=PROPGET, name="Controls", addFlagsVtable=4)
      @com.parameters([iid=914934A2-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPControls getControls();

  /** @com.method(vtoffset=32, dispid=2019, type=PROPGET, name="Tags", addFlagsVtable=4)
      @com.parameters([iid=914934B9-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Tags getTags();

  /** @com.method(vtoffset=33, dispid=2020, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=34, dispid=2020, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);

  /** @com.method(vtoffset=35, dispid=2021, type=PROPGET, name="Sheets", addFlagsVtable=4)
      @com.parameters([iid=914934A3-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPTabSheets getSheets();

  /** @com.method(vtoffset=36, dispid=2022, type=PROPGET, name="TabControl", addFlagsVtable=4)
      @com.parameters([iid=914934B4-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPTabControl getTabControl();

  /** @com.method(vtoffset=37, dispid=2023, type=PROPGET, name="DelayTime", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getDelayTime();

  /** @com.method(vtoffset=38, dispid=2023, type=PROPPUT, name="DelayTime", addFlagsVtable=4)
      @com.parameters([in,type=I4] DelayTime) */
  public void setDelayTime(int DelayTime);

  /** @com.method(vtoffset=39, dispid=2024, type=METHOD, name="SaveDialog", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName, [type=I4] return) */
  public int SaveDialog(String FileName);

  /** @com.method(vtoffset=40, dispid=2025, type=METHOD, name="Terminate", addFlagsVtable=4)
      @com.parameters() */
  public void Terminate();

  /** @com.method(vtoffset=41, dispid=2026, type=PROPGET, name="HWND", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHWND();

  /** @com.method(vtoffset=42, dispid=2027, type=PROPGET, name="OnTerminate", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnTerminate();

  /** @com.method(vtoffset=43, dispid=2027, type=PROPPUT, name="OnTerminate", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnTerminate) */
  public void setOnTerminate(String OnTerminate);

  /** @com.method(vtoffset=44, dispid=2028, type=PROPGET, name="OnIdle", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnIdle();

  /** @com.method(vtoffset=45, dispid=2028, type=PROPPUT, name="OnIdle", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnIdle) */
  public void setOnIdle(String OnIdle);

  /** @com.method(vtoffset=46, dispid=2029, type=PROPGET, name="OnMouseDown", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnMouseDown();

  /** @com.method(vtoffset=47, dispid=2029, type=PROPPUT, name="OnMouseDown", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnMouseDown) */
  public void setOnMouseDown(String OnMouseDown);

  /** @com.method(vtoffset=48, dispid=2030, type=PROPGET, name="OnMouseUp", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnMouseUp();

  /** @com.method(vtoffset=49, dispid=2030, type=PROPPUT, name="OnMouseUp", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnMouseUp) */
  public void setOnMouseUp(String OnMouseUp);

  /** @com.method(vtoffset=50, dispid=2031, type=PROPGET, name="OnKeyPressed", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnKeyPressed();

  /** @com.method(vtoffset=51, dispid=2031, type=PROPPUT, name="OnKeyPressed", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnKeyPressed) */
  public void setOnKeyPressed(String OnKeyPressed);

  /** @com.method(vtoffset=52, dispid=2032, type=PROPGET, name="OnTimer", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnTimer();

  /** @com.method(vtoffset=53, dispid=2032, type=PROPPUT, name="OnTimer", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnTimer) */
  public void setOnTimer(String OnTimer);

  /** @com.method(vtoffset=54, dispid=2033, type=PROPGET, name="OnActivate", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnActivate();

  /** @com.method(vtoffset=55, dispid=2033, type=PROPPUT, name="OnActivate", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnActivate) */
  public void setOnActivate(String OnActivate);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x914934a0, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
