//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface TextRange
/** @com.interface(iid=9149348F-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface TextRange extends msppt8.Collection
{
  /** @com.method(vtoffset=4, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=5, dispid=10, type=METHOD, name="_Index", addFlagsVtable=4)
      @com.parameters([in,type=I4] _index, [type=VARIANT] return) */
  public Variant _Index(int _index);

  /** @com.method(vtoffset=6, dispid=11, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=7, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=8, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=9, dispid=2003, type=PROPGET, name="ActionSettings", addFlagsVtable=4)
      @com.parameters([iid=9149348C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ActionSettings getActionSettings();

  /** @com.method(vtoffset=10, dispid=2004, type=PROPGET, name="Start", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getStart();

  /** @com.method(vtoffset=11, dispid=2005, type=PROPGET, name="Length", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLength();

  /** @com.method(vtoffset=12, dispid=2006, type=PROPGET, name="BoundLeft", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getBoundLeft();

  /** @com.method(vtoffset=13, dispid=2007, type=PROPGET, name="BoundTop", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getBoundTop();

  /** @com.method(vtoffset=14, dispid=2008, type=PROPGET, name="BoundWidth", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getBoundWidth();

  /** @com.method(vtoffset=15, dispid=2009, type=PROPGET, name="BoundHeight", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getBoundHeight();

  /** @com.method(vtoffset=16, dispid=2010, type=METHOD, name="Paragraphs", addFlagsVtable=4)
      @com.parameters([in,type=I4] Start, [in,type=I4] Length, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Paragraphs(int Start, int Length);

  /** @com.method(vtoffset=17, dispid=2011, type=METHOD, name="Sentences", addFlagsVtable=4)
      @com.parameters([in,type=I4] Start, [in,type=I4] Length, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Sentences(int Start, int Length);

  /** @com.method(vtoffset=18, dispid=2012, type=METHOD, name="Words", addFlagsVtable=4)
      @com.parameters([in,type=I4] Start, [in,type=I4] Length, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Words(int Start, int Length);

  /** @com.method(vtoffset=19, dispid=2013, type=METHOD, name="Characters", addFlagsVtable=4)
      @com.parameters([in,type=I4] Start, [in,type=I4] Length, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Characters(int Start, int Length);

  /** @com.method(vtoffset=20, dispid=2014, type=METHOD, name="Lines", addFlagsVtable=4)
      @com.parameters([in,type=I4] Start, [in,type=I4] Length, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Lines(int Start, int Length);

  /** @com.method(vtoffset=21, dispid=2015, type=METHOD, name="Runs", addFlagsVtable=4)
      @com.parameters([in,type=I4] Start, [in,type=I4] Length, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Runs(int Start, int Length);

  /** @com.method(vtoffset=22, dispid=2016, type=METHOD, name="TrimText", addFlagsVtable=4)
      @com.parameters([iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange TrimText();

  /** @com.method(vtoffset=23, dispid=0, type=PROPGET, name="Text", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getText();

  /** @com.method(vtoffset=24, dispid=0, type=PROPPUT, name="Text", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Text) */
  public void setText(String Text);

  /** @com.method(vtoffset=25, dispid=2017, type=METHOD, name="InsertAfter", addFlagsVtable=4)
      @com.parameters([in,type=STRING] NewText, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange InsertAfter(String NewText);

  /** @com.method(vtoffset=26, dispid=2018, type=METHOD, name="InsertBefore", addFlagsVtable=4)
      @com.parameters([in,type=STRING] NewText, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange InsertBefore(String NewText);

  /** @com.method(vtoffset=27, dispid=2019, type=METHOD, name="InsertDateTime", addFlagsVtable=4)
      @com.parameters([in,type=I4] DateTimeFormat, [in,type=I4] InsertAsField, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange InsertDateTime(int DateTimeFormat, int InsertAsField);

  /** @com.method(vtoffset=28, dispid=2020, type=METHOD, name="InsertSlideNumber", addFlagsVtable=4)
      @com.parameters([iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange InsertSlideNumber();

  /** @com.method(vtoffset=29, dispid=2021, type=METHOD, name="InsertSymbol", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FontName, [in,type=I4] CharNumber, [in,type=I4] Unicode, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange InsertSymbol(String FontName, int CharNumber, int Unicode);

  /** @com.method(vtoffset=30, dispid=2022, type=PROPGET, name="Font", addFlagsVtable=4)
      @com.parameters([iid=91493495-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Font getFont();

  /** @com.method(vtoffset=31, dispid=2023, type=PROPGET, name="ParagraphFormat", addFlagsVtable=4)
      @com.parameters([iid=91493496-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ParagraphFormat getParagraphFormat();

  /** @com.method(vtoffset=32, dispid=2024, type=PROPGET, name="IndentLevel", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIndentLevel();

  /** @com.method(vtoffset=33, dispid=2024, type=PROPPUT, name="IndentLevel", addFlagsVtable=4)
      @com.parameters([in,type=I4] IndentLevel) */
  public void setIndentLevel(int IndentLevel);

  /** @com.method(vtoffset=34, dispid=2025, type=METHOD, name="Select", addFlagsVtable=4)
      @com.parameters() */
  public void Select();

  /** @com.method(vtoffset=35, dispid=2026, type=METHOD, name="Cut", addFlagsVtable=4)
      @com.parameters() */
  public void Cut();

  /** @com.method(vtoffset=36, dispid=2027, type=METHOD, name="Copy", addFlagsVtable=4)
      @com.parameters() */
  public void Copy();

  /** @com.method(vtoffset=37, dispid=2028, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=38, dispid=2029, type=METHOD, name="Paste", addFlagsVtable=4)
      @com.parameters([iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Paste();

  /** @com.method(vtoffset=39, dispid=2030, type=METHOD, name="ChangeCase", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type) */
  public void ChangeCase(int Type);

  /** @com.method(vtoffset=40, dispid=2031, type=METHOD, name="AddPeriods", addFlagsVtable=4)
      @com.parameters() */
  public void AddPeriods();

  /** @com.method(vtoffset=41, dispid=2032, type=METHOD, name="RemovePeriods", addFlagsVtable=4)
      @com.parameters() */
  public void RemovePeriods();

  /** @com.method(vtoffset=42, dispid=2033, type=METHOD, name="Find", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FindWhat, [in,type=I4] After, [in,type=I4] MatchCase, [in,type=I4] WholeWords, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Find(String FindWhat, int After, int MatchCase, int WholeWords);

  /** @com.method(vtoffset=43, dispid=2034, type=METHOD, name="Replace", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FindWhat, [in,type=STRING] ReplaceWhat, [in,type=I4] After, [in,type=I4] MatchCase, [in,type=I4] WholeWords, [iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange Replace(String FindWhat, String ReplaceWhat, int After, int MatchCase, int WholeWords);

  /** @com.method(vtoffset=44, dispid=2035, type=METHOD, name="RotatedBounds", addFlagsVtable=4)
      @com.parameters([out,size=1,elementType=R4,type=ARRAY] X1, [out,size=1,elementType=R4,type=ARRAY] Y1, [out,size=1,elementType=R4,type=ARRAY] X2, [out,size=1,elementType=R4,type=ARRAY] Y2, [out,size=1,elementType=R4,type=ARRAY] X3, [out,size=1,elementType=R4,type=ARRAY] Y3, [out,size=1,elementType=R4,type=ARRAY] x4, [out,size=1,elementType=R4,type=ARRAY] y4) */
  public void RotatedBounds(float[] X1, float[] Y1, float[] X2, float[] Y2, float[] X3, float[] Y3, float[] x4, float[] y4);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149348f, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
