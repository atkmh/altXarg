//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface FileDialog
/** @com.interface(iid=914934BD-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface FileDialog extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Extensions", addFlagsVtable=4)
      @com.parameters([iid=914934BC-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.FileDialogExtensionList getExtensions();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="DefaultDirectoryRegKey", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getDefaultDirectoryRegKey();

  /** @com.method(vtoffset=8, dispid=2004, type=PROPPUT, name="DefaultDirectoryRegKey", addFlagsVtable=4)
      @com.parameters([in,type=STRING] DefaultDirectoryRegKey) */
  public void setDefaultDirectoryRegKey(String DefaultDirectoryRegKey);

  /** @com.method(vtoffset=9, dispid=2005, type=PROPGET, name="DialogTitle", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getDialogTitle();

  /** @com.method(vtoffset=10, dispid=2005, type=PROPPUT, name="DialogTitle", addFlagsVtable=4)
      @com.parameters([in,type=STRING] DialogTitle) */
  public void setDialogTitle(String DialogTitle);

  /** @com.method(vtoffset=11, dispid=2006, type=PROPGET, name="ActionButtonName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getActionButtonName();

  /** @com.method(vtoffset=12, dispid=2006, type=PROPPUT, name="ActionButtonName", addFlagsVtable=4)
      @com.parameters([in,type=STRING] ActionButtonName) */
  public void setActionButtonName(String ActionButtonName);

  /** @com.method(vtoffset=13, dispid=2007, type=PROPGET, name="IsMultiSelect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIsMultiSelect();

  /** @com.method(vtoffset=14, dispid=2007, type=PROPPUT, name="IsMultiSelect", addFlagsVtable=4)
      @com.parameters([in,type=I4] IsMultiSelect) */
  public void setIsMultiSelect(int IsMultiSelect);

  /** @com.method(vtoffset=15, dispid=2008, type=PROPGET, name="IsPrintEnabled", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIsPrintEnabled();

  /** @com.method(vtoffset=16, dispid=2008, type=PROPPUT, name="IsPrintEnabled", addFlagsVtable=4)
      @com.parameters([in,type=I4] IsPrintEnabled) */
  public void setIsPrintEnabled(int IsPrintEnabled);

  /** @com.method(vtoffset=17, dispid=2009, type=PROPGET, name="IsReadOnlyEnabled", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIsReadOnlyEnabled();

  /** @com.method(vtoffset=18, dispid=2009, type=PROPPUT, name="IsReadOnlyEnabled", addFlagsVtable=4)
      @com.parameters([in,type=I4] IsReadOnlyEnabled) */
  public void setIsReadOnlyEnabled(int IsReadOnlyEnabled);

  /** @com.method(vtoffset=19, dispid=2010, type=PROPGET, name="DirectoriesOnly", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getDirectoriesOnly();

  /** @com.method(vtoffset=20, dispid=2010, type=PROPPUT, name="DirectoriesOnly", addFlagsVtable=4)
      @com.parameters([in,type=I4] DirectoriesOnly) */
  public void setDirectoriesOnly(int DirectoriesOnly);

  /** @com.method(vtoffset=21, dispid=2011, type=PROPGET, name="InitialView", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getInitialView();

  /** @com.method(vtoffset=22, dispid=2011, type=PROPPUT, name="InitialView", addFlagsVtable=4)
      @com.parameters([in,type=I4] InitialView) */
  public void setInitialView(int InitialView);

  /** @com.method(vtoffset=23, dispid=2012, type=METHOD, name="Launch", addFlagsVtable=4)
      @com.parameters([in,iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] pUnk) */
  public void Launch(IUnknown pUnk);

  /** @com.method(vtoffset=24, dispid=2013, type=PROPGET, name="OnAction", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnAction();

  /** @com.method(vtoffset=25, dispid=2013, type=PROPPUT, name="OnAction", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnAction) */
  public void setOnAction(String OnAction);

  /** @com.method(vtoffset=26, dispid=2014, type=PROPGET, name="Files", addFlagsVtable=4)
      @com.parameters([iid=914934BA-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.FileDialogFileList getFiles();

  /** @com.method(vtoffset=27, dispid=2015, type=PROPGET, name="UseODMADlgs", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getUseODMADlgs();

  /** @com.method(vtoffset=28, dispid=2015, type=PROPPUT, name="UseODMADlgs", addFlagsVtable=4)
      @com.parameters([in,type=I4] UseODMADlgs) */
  public void setUseODMADlgs(int UseODMADlgs);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x914934bd, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
