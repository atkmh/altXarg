//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Enum: PpSlideLayout

public interface PpSlideLayout
{
  public static final int ppLayoutMixed = -2;
  public static final int ppLayoutTitle = 1;
  public static final int ppLayoutText = 2;
  public static final int ppLayoutTwoColumnText = 3;
  public static final int ppLayoutTable = 4;
  public static final int ppLayoutTextAndChart = 5;
  public static final int ppLayoutChartAndText = 6;
  public static final int ppLayoutOrgchart = 7;
  public static final int ppLayoutChart = 8;
  public static final int ppLayoutTextAndClipart = 9;
  public static final int ppLayoutClipartAndText = 10;
  public static final int ppLayoutTitleOnly = 11;
  public static final int ppLayoutBlank = 12;
  public static final int ppLayoutTextAndObject = 13;
  public static final int ppLayoutObjectAndText = 14;
  public static final int ppLayoutLargeObject = 15;
  public static final int ppLayoutObject = 16;
  public static final int ppLayoutTextAndMediaClip = 17;
  public static final int ppLayoutMediaClipAndText = 18;
  public static final int ppLayoutObjectOverText = 19;
  public static final int ppLayoutTextOverObject = 20;
  public static final int ppLayoutTextAndTwoObjects = 21;
  public static final int ppLayoutTwoObjectsAndText = 22;
  public static final int ppLayoutTwoObjectsOverText = 23;
  public static final int ppLayoutFourObjects = 24;
  public static final int ppLayoutVerticalText = 25;
  public static final int ppLayoutClipArtAndVerticalText = 26;
  public static final int ppLayoutVerticalTitleAndText = 27;
  public static final int ppLayoutVerticalTitleAndTextOverChart = 28;
}
