//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface View
/** @com.interface(iid=91493458-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface View extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="Zoom", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getZoom();

  /** @com.method(vtoffset=8, dispid=2004, type=PROPPUT, name="Zoom", addFlagsVtable=4)
      @com.parameters([in,type=I4] Zoom) */
  public void setZoom(int Zoom);

  /** @com.method(vtoffset=9, dispid=2005, type=METHOD, name="Paste", addFlagsVtable=4)
      @com.parameters() */
  public void Paste();

  /** @com.method(vtoffset=10, dispid=2006, type=PROPGET, name="Slide", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getSlide();

  /** @com.method(vtoffset=11, dispid=2006, type=PROPPUT, name="Slide", addFlagsVtable=4)
      @com.parameters([in,iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] Slide) */
  public void setSlide(Object Slide);

  /** @com.method(vtoffset=12, dispid=2007, type=METHOD, name="GotoSlide", addFlagsVtable=4)
      @com.parameters([in,type=I4] index) */
  public void GotoSlide(int index);

  /** @com.method(vtoffset=13, dispid=2008, type=PROPGET, name="DisplaySlideMiniature", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getDisplaySlideMiniature();

  /** @com.method(vtoffset=14, dispid=2008, type=PROPPUT, name="DisplaySlideMiniature", addFlagsVtable=4)
      @com.parameters([in,type=I4] DisplaySlideMiniature) */
  public void setDisplaySlideMiniature(int DisplaySlideMiniature);

  /** @com.method(vtoffset=15, dispid=2009, type=PROPGET, name="ZoomToFit", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getZoomToFit();

  /** @com.method(vtoffset=16, dispid=2009, type=PROPPUT, name="ZoomToFit", addFlagsVtable=4)
      @com.parameters([in,type=I4] ZoomToFit) */
  public void setZoomToFit(int ZoomToFit);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493458, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
