//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Enum: PpActionType

public interface PpActionType
{
  public static final int ppActionMixed = -2;
  public static final int ppActionNone = 0;
  public static final int ppActionNextSlide = 1;
  public static final int ppActionPreviousSlide = 2;
  public static final int ppActionFirstSlide = 3;
  public static final int ppActionLastSlide = 4;
  public static final int ppActionLastSlideViewed = 5;
  public static final int ppActionEndShow = 6;
  public static final int ppActionHyperlink = 7;
  public static final int ppActionRunMacro = 8;
  public static final int ppActionRunProgram = 9;
  public static final int ppActionNamedSlideShow = 10;
  public static final int ppActionOLEVerb = 11;
  public static final int ppActionPlay = 12;
}
