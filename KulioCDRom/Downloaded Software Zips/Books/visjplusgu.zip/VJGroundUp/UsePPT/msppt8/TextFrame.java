//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface TextFrame
/** @com.interface(iid=91493484-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface TextFrame extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=100, type=PROPGET, name="MarginBottom", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getMarginBottom();

  /** @com.method(vtoffset=8, dispid=100, type=PROPPUT, name="MarginBottom", addFlagsVtable=4)
      @com.parameters([in,type=R4] MarginBottom) */
  public void setMarginBottom(float MarginBottom);

  /** @com.method(vtoffset=9, dispid=101, type=PROPGET, name="MarginLeft", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getMarginLeft();

  /** @com.method(vtoffset=10, dispid=101, type=PROPPUT, name="MarginLeft", addFlagsVtable=4)
      @com.parameters([in,type=R4] MarginLeft) */
  public void setMarginLeft(float MarginLeft);

  /** @com.method(vtoffset=11, dispid=102, type=PROPGET, name="MarginRight", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getMarginRight();

  /** @com.method(vtoffset=12, dispid=102, type=PROPPUT, name="MarginRight", addFlagsVtable=4)
      @com.parameters([in,type=R4] MarginRight) */
  public void setMarginRight(float MarginRight);

  /** @com.method(vtoffset=13, dispid=103, type=PROPGET, name="MarginTop", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getMarginTop();

  /** @com.method(vtoffset=14, dispid=103, type=PROPPUT, name="MarginTop", addFlagsVtable=4)
      @com.parameters([in,type=R4] MarginTop) */
  public void setMarginTop(float MarginTop);

  /** @com.method(vtoffset=15, dispid=104, type=PROPGET, name="Orientation", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getOrientation();

  /** @com.method(vtoffset=16, dispid=104, type=PROPPUT, name="Orientation", addFlagsVtable=4)
      @com.parameters([in,type=I4] Orientation) */
  public void setOrientation(int Orientation);

  /** @com.method(vtoffset=17, dispid=2003, type=PROPGET, name="HasText", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHasText();

  /** @com.method(vtoffset=18, dispid=2004, type=PROPGET, name="TextRange", addFlagsVtable=4)
      @com.parameters([iid=9149348F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextRange getTextRange();

  /** @com.method(vtoffset=19, dispid=2005, type=PROPGET, name="Ruler", addFlagsVtable=4)
      @com.parameters([iid=91493490-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Ruler getRuler();

  /** @com.method(vtoffset=20, dispid=2006, type=PROPGET, name="HorizontalAnchor", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHorizontalAnchor();

  /** @com.method(vtoffset=21, dispid=2006, type=PROPPUT, name="HorizontalAnchor", addFlagsVtable=4)
      @com.parameters([in,type=I4] HorizontalAnchor) */
  public void setHorizontalAnchor(int HorizontalAnchor);

  /** @com.method(vtoffset=22, dispid=2007, type=PROPGET, name="VerticalAnchor", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVerticalAnchor();

  /** @com.method(vtoffset=23, dispid=2007, type=PROPPUT, name="VerticalAnchor", addFlagsVtable=4)
      @com.parameters([in,type=I4] VerticalAnchor) */
  public void setVerticalAnchor(int VerticalAnchor);

  /** @com.method(vtoffset=24, dispid=2008, type=PROPGET, name="AutoSize", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAutoSize();

  /** @com.method(vtoffset=25, dispid=2008, type=PROPPUT, name="AutoSize", addFlagsVtable=4)
      @com.parameters([in,type=I4] AutoSize) */
  public void setAutoSize(int AutoSize);

  /** @com.method(vtoffset=26, dispid=2009, type=PROPGET, name="WordWrap", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getWordWrap();

  /** @com.method(vtoffset=27, dispid=2009, type=PROPPUT, name="WordWrap", addFlagsVtable=4)
      @com.parameters([in,type=I4] WordWrap) */
  public void setWordWrap(int WordWrap);

  /** @com.method(vtoffset=28, dispid=2010, type=METHOD, name="DeleteText", addFlagsVtable=4)
      @com.parameters() */
  public void DeleteText();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493484, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
