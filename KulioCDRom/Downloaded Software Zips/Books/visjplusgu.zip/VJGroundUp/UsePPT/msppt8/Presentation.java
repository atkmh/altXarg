//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

/** @com.class(classid=91493444-5A91-11CF-8700-00AA0060263B,DynamicCasts)
    @com.interface(iid=9149349D-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL)
*/
public class Presentation implements IUnknown,com.ms.com.NoAutoScripting,msppt8._Presentation
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="SlideMaster", addFlagsVtable=4)
      @com.parameters([iid=9149346C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Master getSlideMaster();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="TitleMaster", addFlagsVtable=4)
      @com.parameters([iid=9149346C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Master getTitleMaster();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="HasTitleMaster", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getHasTitleMaster();

  /** @com.method(vtoffset=9, dispid=2006, type=METHOD, name="AddTitleMaster", addFlagsVtable=4)
      @com.parameters([iid=9149346C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Master AddTitleMaster();

  /** @com.method(vtoffset=10, dispid=2007, type=METHOD, name="ApplyTemplate", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName) */
  public native void ApplyTemplate(String FileName);

  /** @com.method(vtoffset=11, dispid=2008, type=PROPGET, name="TemplateName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getTemplateName();

  /** @com.method(vtoffset=12, dispid=2009, type=PROPGET, name="NotesMaster", addFlagsVtable=4)
      @com.parameters([iid=9149346C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Master getNotesMaster();

  /** @com.method(vtoffset=13, dispid=2010, type=PROPGET, name="HandoutMaster", addFlagsVtable=4)
      @com.parameters([iid=9149346C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Master getHandoutMaster();

  /** @com.method(vtoffset=14, dispid=2011, type=PROPGET, name="Slides", addFlagsVtable=4)
      @com.parameters([iid=91493469-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Slides getSlides();

  /** @com.method(vtoffset=15, dispid=2012, type=PROPGET, name="PageSetup", addFlagsVtable=4)
      @com.parameters([iid=91493466-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.PageSetup getPageSetup();

  /** @com.method(vtoffset=16, dispid=2013, type=PROPGET, name="ColorSchemes", addFlagsVtable=4)
      @com.parameters([iid=9149346E-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.ColorSchemes getColorSchemes();

  /** @com.method(vtoffset=17, dispid=2014, type=PROPGET, name="ExtraColors", addFlagsVtable=4)
      @com.parameters([iid=91493468-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.ExtraColors getExtraColors();

  /** @com.method(vtoffset=18, dispid=2015, type=PROPGET, name="SlideShowSettings", addFlagsVtable=4)
      @com.parameters([iid=9149345A-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.SlideShowSettings getSlideShowSettings();

  /** @com.method(vtoffset=19, dispid=2016, type=PROPGET, name="Fonts", addFlagsVtable=4)
      @com.parameters([iid=91493467-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Fonts getFonts();

  /** @com.method(vtoffset=20, dispid=2017, type=PROPGET, name="Windows", addFlagsVtable=4)
      @com.parameters([iid=91493455-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.DocumentWindows getWindows();

  /** @com.method(vtoffset=21, dispid=2018, type=PROPGET, name="Tags", addFlagsVtable=4)
      @com.parameters([iid=914934B9-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Tags getTags();

  /** @com.method(vtoffset=22, dispid=2019, type=PROPGET, name="DefaultShape", addFlagsVtable=4)
      @com.parameters([iid=91493479-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Shape getDefaultShape();

  /** @com.method(vtoffset=23, dispid=2020, type=PROPGET, name="BuiltInDocumentProperties", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native Object getBuiltInDocumentProperties();

  /** @com.method(vtoffset=24, dispid=2021, type=PROPGET, name="CustomDocumentProperties", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native Object getCustomDocumentProperties();

  /** @com.method(vtoffset=25, dispid=2022, type=PROPGET, name="VBProject", addFlagsVtable=4)
      @com.parameters([iid=0002E160-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBProject getVBProject();

  /** @com.method(vtoffset=26, dispid=2023, type=PROPGET, name="ReadOnly", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getReadOnly();

  /** @com.method(vtoffset=27, dispid=2024, type=PROPGET, name="FullName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getFullName();

  /** @com.method(vtoffset=28, dispid=2025, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getName();

  /** @com.method(vtoffset=29, dispid=2026, type=PROPGET, name="Path", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getPath();

  /** @com.method(vtoffset=30, dispid=2027, type=PROPGET, name="Saved", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getSaved();

  /** @com.method(vtoffset=31, dispid=2027, type=PROPPUT, name="Saved", addFlagsVtable=4)
      @com.parameters([in,type=I4] Saved) */
  public native void setSaved(int Saved);

  /** @com.method(vtoffset=32, dispid=2028, type=PROPGET, name="LayoutDirection", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getLayoutDirection();

  /** @com.method(vtoffset=33, dispid=2028, type=PROPPUT, name="LayoutDirection", addFlagsVtable=4)
      @com.parameters([in,type=I4] LayoutDirection) */
  public native void setLayoutDirection(int LayoutDirection);

  /** @com.method(vtoffset=34, dispid=2029, type=METHOD, name="NewWindow", addFlagsVtable=4)
      @com.parameters([iid=91493457-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.DocumentWindow NewWindow();

  /** @com.method(vtoffset=35, dispid=2030, type=METHOD, name="FollowHyperlink", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Address, [in,type=STRING] SubAddress, [in,type=BOOLEAN] NewWindow, [in,type=BOOLEAN] AddHistory, [in,type=STRING] ExtraInfo, [in,type=I4] Method, [in,type=STRING] HeaderInfo) */
  public native void FollowHyperlink(String Address, String SubAddress, boolean NewWindow, boolean AddHistory, String ExtraInfo, int Method, String HeaderInfo);

  /** @com.method(vtoffset=36, dispid=2031, type=METHOD, name="AddToFavorites", addFlagsVtable=4)
      @com.parameters() */
  public native void AddToFavorites();

  /** @com.method(vtoffset=37, dispid=2032, type=METHOD, name="Unused", addFlagsVtable=4)
      @com.parameters() */
  public native void Unused();

  /** @com.method(vtoffset=38, dispid=2033, type=PROPGET, name="PrintOptions", addFlagsVtable=4)
      @com.parameters([iid=9149345D-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.PrintOptions getPrintOptions();

  /** @com.method(vtoffset=39, dispid=2034, type=METHOD, name="PrintOut", addFlagsVtable=4)
      @com.parameters([in,type=I4] From, [in,type=I4] To, [in,type=STRING] PrintToFile, [in,type=I4] Copies, [in,type=I4] Collate) */
  public native void PrintOut(int From, int To, String PrintToFile, int Copies, int Collate);

  /** @com.method(vtoffset=40, dispid=2035, type=METHOD, name="Save", addFlagsVtable=4)
      @com.parameters() */
  public native void Save();

  /** @com.method(vtoffset=41, dispid=2036, type=METHOD, name="SaveAs", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName, [in,type=I4] FileFormat, [in,type=I4] EmbedTrueTypeFonts) */
  public native void SaveAs(String FileName, int FileFormat, int EmbedTrueTypeFonts);

  /** @com.method(vtoffset=42, dispid=2037, type=METHOD, name="SaveCopyAs", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName, [in,type=I4] FileFormat, [in,type=I4] EmbedTrueTypeFonts) */
  public native void SaveCopyAs(String FileName, int FileFormat, int EmbedTrueTypeFonts);

  /** @com.method(vtoffset=43, dispid=2038, type=METHOD, name="Export", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Path, [in,type=STRING] FilterName, [in,type=I4] ScaleWidth, [in,type=I4] ScaleHeight) */
  public native void Export(String Path, String FilterName, int ScaleWidth, int ScaleHeight);

  /** @com.method(vtoffset=44, dispid=2039, type=METHOD, name="Close", addFlagsVtable=4)
      @com.parameters() */
  public native void Close();

  /** @com.method(vtoffset=45, dispid=2040, type=METHOD, name="SetUndoText", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Text) */
  public native void SetUndoText(String Text);

  /** @com.method(vtoffset=46, dispid=2041, type=PROPGET, name="Container", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native Object getContainer();

  /** @com.method(vtoffset=47, dispid=2042, type=PROPGET, name="DisplayComments", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getDisplayComments();

  /** @com.method(vtoffset=48, dispid=2042, type=PROPPUT, name="DisplayComments", addFlagsVtable=4)
      @com.parameters([in,type=I4] DisplayComments) */
  public native void setDisplayComments(int DisplayComments);

  /** @com.method(vtoffset=49, dispid=2043, type=PROPGET, name="FarEastLineBreakLevel", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getFarEastLineBreakLevel();

  /** @com.method(vtoffset=50, dispid=2043, type=PROPPUT, name="FarEastLineBreakLevel", addFlagsVtable=4)
      @com.parameters([in,type=I4] FarEastLineBreakLevel) */
  public native void setFarEastLineBreakLevel(int FarEastLineBreakLevel);

  /** @com.method(vtoffset=51, dispid=2044, type=PROPGET, name="NoLineBreakBefore", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getNoLineBreakBefore();

  /** @com.method(vtoffset=52, dispid=2044, type=PROPPUT, name="NoLineBreakBefore", addFlagsVtable=4)
      @com.parameters([in,type=STRING] NoLineBreakBefore) */
  public native void setNoLineBreakBefore(String NoLineBreakBefore);

  /** @com.method(vtoffset=53, dispid=2045, type=PROPGET, name="NoLineBreakAfter", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getNoLineBreakAfter();

  /** @com.method(vtoffset=54, dispid=2045, type=PROPPUT, name="NoLineBreakAfter", addFlagsVtable=4)
      @com.parameters([in,type=STRING] NoLineBreakAfter) */
  public native void setNoLineBreakAfter(String NoLineBreakAfter);

  /** @com.method(vtoffset=55, dispid=2046, type=METHOD, name="UpdateLinks", addFlagsVtable=4)
      @com.parameters() */
  public native void UpdateLinks();

  /** @com.method(vtoffset=56, dispid=2047, type=PROPGET, name="SlideShowWindow", addFlagsVtable=4)
      @com.parameters([iid=91493453-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.SlideShowWindow getSlideShowWindow();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149349d, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0x91493444, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
