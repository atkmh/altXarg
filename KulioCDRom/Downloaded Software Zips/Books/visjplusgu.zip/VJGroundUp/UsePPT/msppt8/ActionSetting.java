//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface ActionSetting
/** @com.interface(iid=9149348D-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface ActionSetting extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Action", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAction();

  /** @com.method(vtoffset=7, dispid=2003, type=PROPPUT, name="Action", addFlagsVtable=4)
      @com.parameters([in,type=I4] Action) */
  public void setAction(int Action);

  /** @com.method(vtoffset=8, dispid=2004, type=PROPGET, name="ActionVerb", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getActionVerb();

  /** @com.method(vtoffset=9, dispid=2004, type=PROPPUT, name="ActionVerb", addFlagsVtable=4)
      @com.parameters([in,type=STRING] ActionVerb) */
  public void setActionVerb(String ActionVerb);

  /** @com.method(vtoffset=10, dispid=2005, type=PROPGET, name="AnimateAction", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimateAction();

  /** @com.method(vtoffset=11, dispid=2005, type=PROPPUT, name="AnimateAction", addFlagsVtable=4)
      @com.parameters([in,type=I4] AnimateAction) */
  public void setAnimateAction(int AnimateAction);

  /** @com.method(vtoffset=12, dispid=2006, type=PROPGET, name="Run", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getRun();

  /** @com.method(vtoffset=13, dispid=2006, type=PROPPUT, name="Run", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Run) */
  public void setRun(String Run);

  /** @com.method(vtoffset=14, dispid=2007, type=PROPGET, name="SlideShowName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getSlideShowName();

  /** @com.method(vtoffset=15, dispid=2007, type=PROPPUT, name="SlideShowName", addFlagsVtable=4)
      @com.parameters([in,type=STRING] SlideShowName) */
  public void setSlideShowName(String SlideShowName);

  /** @com.method(vtoffset=16, dispid=2008, type=PROPGET, name="Hyperlink", addFlagsVtable=4)
      @com.parameters([iid=91493465-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Hyperlink getHyperlink();

  /** @com.method(vtoffset=17, dispid=2009, type=PROPGET, name="SoundEffect", addFlagsVtable=4)
      @com.parameters([iid=91493472-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SoundEffect getSoundEffect();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149348d, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
