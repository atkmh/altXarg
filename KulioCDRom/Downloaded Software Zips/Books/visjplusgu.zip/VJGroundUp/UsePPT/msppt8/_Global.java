//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface _Global
/** @com.interface(iid=91493451-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface _Global extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="ActivePresentation", addFlagsVtable=4)
      @com.parameters([iid=9149349D-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=OBJECT] return) */
  public msppt8.Presentation getActivePresentation();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="ActiveWindow", addFlagsVtable=4)
      @com.parameters([iid=91493457-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.DocumentWindow getActiveWindow();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="AddIns", addFlagsVtable=4)
      @com.parameters([iid=91493460-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.AddIns getAddIns();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="Assistant", addFlagsVtable=4)
      @com.parameters([iid=000C0322-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Assistant getAssistant();

  /** @com.method(vtoffset=9, dispid=2006, type=PROPGET, name="Dialogs", addFlagsVtable=4)
      @com.parameters([iid=9149349E-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPDialogs getDialogs();

  /** @com.method(vtoffset=10, dispid=2007, type=PROPGET, name="Presentations", addFlagsVtable=4)
      @com.parameters([iid=91493462-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Presentations getPresentations();

  /** @com.method(vtoffset=11, dispid=2008, type=PROPGET, name="SlideShowWindows", addFlagsVtable=4)
      @com.parameters([iid=91493456-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SlideShowWindows getSlideShowWindows();

  /** @com.method(vtoffset=12, dispid=2009, type=PROPGET, name="Windows", addFlagsVtable=4)
      @com.parameters([iid=91493455-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.DocumentWindows getWindows();

  /** @com.method(vtoffset=13, dispid=2010, type=PROPGET, name="CommandBars", addFlagsVtable=4)
      @com.parameters([iid=000C0302-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBars getCommandBars();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493451, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
