//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface FreeformBuilder
/** @com.interface(iid=91493478-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface FreeformBuilder extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="AddNodes", addFlagsVtable=4)
      @com.parameters([in,type=I4] SegmentType, [in,type=I4] EditingType, [in,type=R4] X1, [in,type=R4] Y1, [in,type=R4] X2, [in,type=R4] Y2, [in,type=R4] X3, [in,type=R4] Y3) */
  public void AddNodes(int SegmentType, int EditingType, float X1, float Y1, float X2, float Y2, float X3, float Y3);

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="ConvertToShape", addFlagsVtable=4)
      @com.parameters([iid=91493479-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shape ConvertToShape();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493478, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
