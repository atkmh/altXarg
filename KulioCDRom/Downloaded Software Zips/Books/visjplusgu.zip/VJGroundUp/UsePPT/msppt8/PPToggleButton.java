//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface PPToggleButton
/** @com.interface(iid=914934A6-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface PPToggleButton extends msppt8.PPControl
{
  /** @com.method(vtoffset=4, dispid=1001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=1003, type=PROPGET, name="Enable", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEnable();

  /** @com.method(vtoffset=7, dispid=1003, type=PROPPUT, name="Enable", addFlagsVtable=4)
      @com.parameters([in,type=I4] Enable) */
  public void setEnable(int Enable);

  /** @com.method(vtoffset=8, dispid=1004, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=9, dispid=1004, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=10, dispid=1005, type=PROPGET, name="Focus", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFocus();

  /** @com.method(vtoffset=11, dispid=1005, type=PROPPUT, name="Focus", addFlagsVtable=4)
      @com.parameters([in,type=I4] Focus) */
  public void setFocus(int Focus);

  /** @com.method(vtoffset=12, dispid=1006, type=PROPGET, name="Label", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getLabel();

  /** @com.method(vtoffset=13, dispid=1006, type=PROPPUT, name="Label", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Label) */
  public void setLabel(String Label);

  /** @com.method(vtoffset=14, dispid=1007, type=PROPGET, name="HelpId", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHelpId();

  /** @com.method(vtoffset=15, dispid=1007, type=PROPPUT, name="HelpId", addFlagsVtable=4)
      @com.parameters([in,type=I4] HelpId) */
  public void setHelpId(int HelpId);

  /** @com.method(vtoffset=16, dispid=1008, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getLeft();

  /** @com.method(vtoffset=17, dispid=1008, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left) */
  public void setLeft(float Left);

  /** @com.method(vtoffset=18, dispid=1009, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTop();

  /** @com.method(vtoffset=19, dispid=1009, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=R4] Top) */
  public void setTop(float Top);

  /** @com.method(vtoffset=20, dispid=1010, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWidth();

  /** @com.method(vtoffset=21, dispid=1010, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=R4] Width) */
  public void setWidth(float Width);

  /** @com.method(vtoffset=22, dispid=1011, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getHeight();

  /** @com.method(vtoffset=23, dispid=1011, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=R4] Height) */
  public void setHeight(float Height);

  /** @com.method(vtoffset=24, dispid=1012, type=PROPGET, name="HWND", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHWND();

  /** @com.method(vtoffset=25, dispid=1013, type=PROPGET, name="OnSetFocus", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnSetFocus();

  /** @com.method(vtoffset=26, dispid=1013, type=PROPPUT, name="OnSetFocus", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnSetFocus) */
  public void setOnSetFocus(String OnSetFocus);

  /** @com.method(vtoffset=27, dispid=1014, type=PROPGET, name="OnKillFocus", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnKillFocus();

  /** @com.method(vtoffset=28, dispid=1014, type=PROPPUT, name="OnKillFocus", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnKillFocus) */
  public void setOnKillFocus(String OnKillFocus);

  /** @com.method(vtoffset=29, dispid=1015, type=PROPGET, name="Tags", addFlagsVtable=4)
      @com.parameters([iid=914934B9-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Tags getTags();

  /** @com.method(vtoffset=30, dispid=1016, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=31, dispid=1016, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);

  /** @com.method(vtoffset=32, dispid=2001, type=PROPGET, name="State", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getState();

  /** @com.method(vtoffset=33, dispid=2001, type=PROPPUT, name="State", addFlagsVtable=4)
      @com.parameters([in,type=I4] State) */
  public void setState(int State);

  /** @com.method(vtoffset=34, dispid=2002, type=PROPGET, name="ResourceID", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getResourceID();

  /** @com.method(vtoffset=35, dispid=2002, type=PROPPUT, name="ResourceID", addFlagsVtable=4)
      @com.parameters([in,type=I4] ResourceID) */
  public void setResourceID(int ResourceID);

  /** @com.method(vtoffset=36, dispid=2003, type=METHOD, name="Click", addFlagsVtable=4)
      @com.parameters() */
  public void Click();

  /** @com.method(vtoffset=37, dispid=2004, type=PROPGET, name="OnClick", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnClick();

  /** @com.method(vtoffset=38, dispid=2004, type=PROPPUT, name="OnClick", addFlagsVtable=4)
      @com.parameters([in,type=STRING] OnClick) */
  public void setOnClick(String OnClick);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x914934a6, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
