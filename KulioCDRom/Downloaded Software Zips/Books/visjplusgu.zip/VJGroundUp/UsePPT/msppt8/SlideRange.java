//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface SlideRange
/** @com.interface(iid=9149346B-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface SlideRange extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Shapes", addFlagsVtable=4)
      @com.parameters([iid=91493475-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shapes getShapes();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="HeadersFooters", addFlagsVtable=4)
      @com.parameters([iid=91493474-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.HeadersFooters getHeadersFooters();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="SlideShowTransition", addFlagsVtable=4)
      @com.parameters([iid=91493471-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SlideShowTransition getSlideShowTransition();

  /** @com.method(vtoffset=9, dispid=2006, type=PROPGET, name="ColorScheme", addFlagsVtable=4)
      @com.parameters([iid=9149346F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorScheme getColorScheme();

  /** @com.method(vtoffset=10, dispid=2006, type=PROPPUT, name="ColorScheme", addFlagsVtable=4)
      @com.parameters([in,iid=9149346F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] ColorScheme) */
  public void setColorScheme(msppt8.ColorScheme ColorScheme);

  /** @com.method(vtoffset=11, dispid=2007, type=PROPGET, name="Background", addFlagsVtable=4)
      @com.parameters([iid=9149347A-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShapeRange getBackground();

  /** @com.method(vtoffset=12, dispid=2008, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=13, dispid=2008, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);

  /** @com.method(vtoffset=14, dispid=2009, type=PROPGET, name="SlideID", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getSlideID();

  /** @com.method(vtoffset=15, dispid=2010, type=PROPGET, name="PrintSteps", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPrintSteps();

  /** @com.method(vtoffset=16, dispid=2011, type=METHOD, name="Select", addFlagsVtable=4)
      @com.parameters() */
  public void Select();

  /** @com.method(vtoffset=17, dispid=2012, type=METHOD, name="Cut", addFlagsVtable=4)
      @com.parameters() */
  public void Cut();

  /** @com.method(vtoffset=18, dispid=2013, type=METHOD, name="Copy", addFlagsVtable=4)
      @com.parameters() */
  public void Copy();

  /** @com.method(vtoffset=19, dispid=2014, type=PROPGET, name="Layout", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLayout();

  /** @com.method(vtoffset=20, dispid=2014, type=PROPPUT, name="Layout", addFlagsVtable=4)
      @com.parameters([in,type=I4] Layout) */
  public void setLayout(int Layout);

  /** @com.method(vtoffset=21, dispid=2015, type=METHOD, name="Duplicate", addFlagsVtable=4)
      @com.parameters([iid=9149346B-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SlideRange Duplicate();

  /** @com.method(vtoffset=22, dispid=2016, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=23, dispid=2017, type=PROPGET, name="Tags", addFlagsVtable=4)
      @com.parameters([iid=914934B9-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Tags getTags();

  /** @com.method(vtoffset=24, dispid=2018, type=PROPGET, name="SlideIndex", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getSlideIndex();

  /** @com.method(vtoffset=25, dispid=2019, type=PROPGET, name="SlideNumber", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getSlideNumber();

  /** @com.method(vtoffset=26, dispid=2020, type=PROPGET, name="DisplayMasterShapes", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getDisplayMasterShapes();

  /** @com.method(vtoffset=27, dispid=2020, type=PROPPUT, name="DisplayMasterShapes", addFlagsVtable=4)
      @com.parameters([in,type=I4] DisplayMasterShapes) */
  public void setDisplayMasterShapes(int DisplayMasterShapes);

  /** @com.method(vtoffset=28, dispid=2021, type=PROPGET, name="FollowMasterBackground", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFollowMasterBackground();

  /** @com.method(vtoffset=29, dispid=2021, type=PROPPUT, name="FollowMasterBackground", addFlagsVtable=4)
      @com.parameters([in,type=I4] FollowMasterBackground) */
  public void setFollowMasterBackground(int FollowMasterBackground);

  /** @com.method(vtoffset=30, dispid=2022, type=PROPGET, name="NotesPage", addFlagsVtable=4)
      @com.parameters([iid=9149346B-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SlideRange getNotesPage();

  /** @com.method(vtoffset=31, dispid=2023, type=PROPGET, name="Master", addFlagsVtable=4)
      @com.parameters([iid=9149346C-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Master getMaster();

  /** @com.method(vtoffset=32, dispid=2024, type=PROPGET, name="Hyperlinks", addFlagsVtable=4)
      @com.parameters([iid=91493464-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Hyperlinks getHyperlinks();

  /** @com.method(vtoffset=33, dispid=2025, type=METHOD, name="Export", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName, [in,type=STRING] FilterName, [in,type=I4] ScaleWidth, [in,type=I4] ScaleHeight) */
  public void Export(String FileName, String FilterName, int ScaleWidth, int ScaleHeight);

  /** @com.method(vtoffset=34, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] index, [iid=9149346A-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=OBJECT] return) */
  public msppt8.Slide Item(Variant index);

  /** @com.method(vtoffset=35, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=36, dispid=10, type=METHOD, name="_Index", addFlagsVtable=4)
      @com.parameters([in,type=I4] _index, [type=VARIANT] return) */
  public Variant _Index(int _index);

  /** @com.method(vtoffset=37, dispid=11, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149346b, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
