//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface Placeholders
/** @com.interface(iid=91493476-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface Placeholders extends msppt8.Collection
{
  /** @com.method(vtoffset=4, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=5, dispid=10, type=METHOD, name="_Index", addFlagsVtable=4)
      @com.parameters([in,type=I4] _index, [type=VARIANT] return) */
  public Variant _Index(int _index);

  /** @com.method(vtoffset=6, dispid=11, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=7, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=8, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=9, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=I4] index, [iid=91493479-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shape Item(int index);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493476, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
