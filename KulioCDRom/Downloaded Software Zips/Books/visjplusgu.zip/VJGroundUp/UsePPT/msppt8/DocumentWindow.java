//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface DocumentWindow
/** @com.interface(iid=91493457-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface DocumentWindow extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Selection", addFlagsVtable=4)
      @com.parameters([iid=91493454-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Selection getSelection();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="View", addFlagsVtable=4)
      @com.parameters([iid=91493458-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.View getView();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="Presentation", addFlagsVtable=4)
      @com.parameters([iid=9149349D-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=OBJECT] return) */
  public msppt8.Presentation getPresentation();

  /** @com.method(vtoffset=9, dispid=2006, type=PROPGET, name="ViewType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getViewType();

  /** @com.method(vtoffset=10, dispid=2006, type=PROPPUT, name="ViewType", addFlagsVtable=4)
      @com.parameters([in,type=I4] ViewType) */
  public void setViewType(int ViewType);

  /** @com.method(vtoffset=11, dispid=2007, type=PROPGET, name="BlackAndWhite", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBlackAndWhite();

  /** @com.method(vtoffset=12, dispid=2007, type=PROPPUT, name="BlackAndWhite", addFlagsVtable=4)
      @com.parameters([in,type=I4] BlackAndWhite) */
  public void setBlackAndWhite(int BlackAndWhite);

  /** @com.method(vtoffset=13, dispid=2008, type=PROPGET, name="Active", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getActive();

  /** @com.method(vtoffset=14, dispid=2009, type=PROPGET, name="WindowState", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getWindowState();

  /** @com.method(vtoffset=15, dispid=2009, type=PROPPUT, name="WindowState", addFlagsVtable=4)
      @com.parameters([in,type=I4] WindowState) */
  public void setWindowState(int WindowState);

  /** @com.method(vtoffset=16, dispid=0, type=PROPGET, name="Caption", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getCaption();

  /** @com.method(vtoffset=17, dispid=2010, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getLeft();

  /** @com.method(vtoffset=18, dispid=2010, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left) */
  public void setLeft(float Left);

  /** @com.method(vtoffset=19, dispid=2011, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTop();

  /** @com.method(vtoffset=20, dispid=2011, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=R4] Top) */
  public void setTop(float Top);

  /** @com.method(vtoffset=21, dispid=2012, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWidth();

  /** @com.method(vtoffset=22, dispid=2012, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=R4] Width) */
  public void setWidth(float Width);

  /** @com.method(vtoffset=23, dispid=2013, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getHeight();

  /** @com.method(vtoffset=24, dispid=2013, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=R4] Height) */
  public void setHeight(float Height);

  /** @com.method(vtoffset=25, dispid=2014, type=METHOD, name="FitToPage", addFlagsVtable=4)
      @com.parameters() */
  public void FitToPage();

  /** @com.method(vtoffset=26, dispid=2015, type=METHOD, name="Activate", addFlagsVtable=4)
      @com.parameters() */
  public void Activate();

  /** @com.method(vtoffset=27, dispid=2016, type=METHOD, name="LargeScroll", addFlagsVtable=4)
      @com.parameters([in,type=I4] Down, [in,type=I4] Up, [in,type=I4] ToRight, [in,type=I4] ToLeft) */
  public void LargeScroll(int Down, int Up, int ToRight, int ToLeft);

  /** @com.method(vtoffset=28, dispid=2017, type=METHOD, name="SmallScroll", addFlagsVtable=4)
      @com.parameters([in,type=I4] Down, [in,type=I4] Up, [in,type=I4] ToRight, [in,type=I4] ToLeft) */
  public void SmallScroll(int Down, int Up, int ToRight, int ToLeft);

  /** @com.method(vtoffset=29, dispid=2018, type=METHOD, name="NewWindow", addFlagsVtable=4)
      @com.parameters([iid=91493457-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.DocumentWindow NewWindow();

  /** @com.method(vtoffset=30, dispid=2019, type=METHOD, name="Close", addFlagsVtable=4)
      @com.parameters() */
  public void Close();

  /** @com.method(vtoffset=31, dispid=2020, type=PROPGET, name="HWND", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHWND();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493457, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
