//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface SlideShowSettings
/** @com.interface(iid=9149345A-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface SlideShowSettings extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="PointerColor", addFlagsVtable=4)
      @com.parameters([iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorFormat getPointerColor();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="NamedSlideShows", addFlagsVtable=4)
      @com.parameters([iid=9149345B-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.NamedSlideShows getNamedSlideShows();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="StartingSlide", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getStartingSlide();

  /** @com.method(vtoffset=9, dispid=2005, type=PROPPUT, name="StartingSlide", addFlagsVtable=4)
      @com.parameters([in,type=I4] StartingSlide) */
  public void setStartingSlide(int StartingSlide);

  /** @com.method(vtoffset=10, dispid=2006, type=PROPGET, name="EndingSlide", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEndingSlide();

  /** @com.method(vtoffset=11, dispid=2006, type=PROPPUT, name="EndingSlide", addFlagsVtable=4)
      @com.parameters([in,type=I4] EndingSlide) */
  public void setEndingSlide(int EndingSlide);

  /** @com.method(vtoffset=12, dispid=2007, type=PROPGET, name="AdvanceMode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAdvanceMode();

  /** @com.method(vtoffset=13, dispid=2007, type=PROPPUT, name="AdvanceMode", addFlagsVtable=4)
      @com.parameters([in,type=I4] AdvanceMode) */
  public void setAdvanceMode(int AdvanceMode);

  /** @com.method(vtoffset=14, dispid=2008, type=METHOD, name="Run", addFlagsVtable=4)
      @com.parameters([iid=91493453-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SlideShowWindow Run();

  /** @com.method(vtoffset=15, dispid=2009, type=PROPGET, name="LoopUntilStopped", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLoopUntilStopped();

  /** @com.method(vtoffset=16, dispid=2009, type=PROPPUT, name="LoopUntilStopped", addFlagsVtable=4)
      @com.parameters([in,type=I4] LoopUntilStopped) */
  public void setLoopUntilStopped(int LoopUntilStopped);

  /** @com.method(vtoffset=17, dispid=2010, type=PROPGET, name="ShowType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getShowType();

  /** @com.method(vtoffset=18, dispid=2010, type=PROPPUT, name="ShowType", addFlagsVtable=4)
      @com.parameters([in,type=I4] ShowType) */
  public void setShowType(int ShowType);

  /** @com.method(vtoffset=19, dispid=2011, type=PROPGET, name="ShowWithNarration", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getShowWithNarration();

  /** @com.method(vtoffset=20, dispid=2011, type=PROPPUT, name="ShowWithNarration", addFlagsVtable=4)
      @com.parameters([in,type=I4] ShowWithNarration) */
  public void setShowWithNarration(int ShowWithNarration);

  /** @com.method(vtoffset=21, dispid=2012, type=PROPGET, name="ShowWithAnimation", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getShowWithAnimation();

  /** @com.method(vtoffset=22, dispid=2012, type=PROPPUT, name="ShowWithAnimation", addFlagsVtable=4)
      @com.parameters([in,type=I4] ShowWithAnimation) */
  public void setShowWithAnimation(int ShowWithAnimation);

  /** @com.method(vtoffset=23, dispid=2013, type=PROPGET, name="SlideShowName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getSlideShowName();

  /** @com.method(vtoffset=24, dispid=2013, type=PROPPUT, name="SlideShowName", addFlagsVtable=4)
      @com.parameters([in,type=STRING] SlideShowName) */
  public void setSlideShowName(String SlideShowName);

  /** @com.method(vtoffset=25, dispid=2014, type=PROPGET, name="RangeType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getRangeType();

  /** @com.method(vtoffset=26, dispid=2014, type=PROPPUT, name="RangeType", addFlagsVtable=4)
      @com.parameters([in,type=I4] RangeType) */
  public void setRangeType(int RangeType);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149345a, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
