//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface HeaderFooter
/** @com.interface(iid=9149349C-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface HeaderFooter extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=7, dispid=2003, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=8, dispid=2004, type=PROPGET, name="Text", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getText();

  /** @com.method(vtoffset=9, dispid=2004, type=PROPPUT, name="Text", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Text) */
  public void setText(String Text);

  /** @com.method(vtoffset=10, dispid=2005, type=PROPGET, name="UseFormat", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getUseFormat();

  /** @com.method(vtoffset=11, dispid=2005, type=PROPPUT, name="UseFormat", addFlagsVtable=4)
      @com.parameters([in,type=I4] UseFormat) */
  public void setUseFormat(int UseFormat);

  /** @com.method(vtoffset=12, dispid=2006, type=PROPGET, name="Format", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFormat();

  /** @com.method(vtoffset=13, dispid=2006, type=PROPPUT, name="Format", addFlagsVtable=4)
      @com.parameters([in,type=I4] Format) */
  public void setFormat(int Format);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149349c, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
