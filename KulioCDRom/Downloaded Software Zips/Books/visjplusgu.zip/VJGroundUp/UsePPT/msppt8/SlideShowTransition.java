//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface SlideShowTransition
/** @com.interface(iid=91493471-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface SlideShowTransition extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="AdvanceOnClick", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAdvanceOnClick();

  /** @com.method(vtoffset=7, dispid=2003, type=PROPPUT, name="AdvanceOnClick", addFlagsVtable=4)
      @com.parameters([in,type=I4] AdvanceOnClick) */
  public void setAdvanceOnClick(int AdvanceOnClick);

  /** @com.method(vtoffset=8, dispid=2004, type=PROPGET, name="AdvanceOnTime", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAdvanceOnTime();

  /** @com.method(vtoffset=9, dispid=2004, type=PROPPUT, name="AdvanceOnTime", addFlagsVtable=4)
      @com.parameters([in,type=I4] AdvanceOnTime) */
  public void setAdvanceOnTime(int AdvanceOnTime);

  /** @com.method(vtoffset=10, dispid=2005, type=PROPGET, name="AdvanceTime", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getAdvanceTime();

  /** @com.method(vtoffset=11, dispid=2005, type=PROPPUT, name="AdvanceTime", addFlagsVtable=4)
      @com.parameters([in,type=R4] AdvanceTime) */
  public void setAdvanceTime(float AdvanceTime);

  /** @com.method(vtoffset=12, dispid=2006, type=PROPGET, name="EntryEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEntryEffect();

  /** @com.method(vtoffset=13, dispid=2006, type=PROPPUT, name="EntryEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] EntryEffect) */
  public void setEntryEffect(int EntryEffect);

  /** @com.method(vtoffset=14, dispid=2007, type=PROPGET, name="Hidden", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHidden();

  /** @com.method(vtoffset=15, dispid=2007, type=PROPPUT, name="Hidden", addFlagsVtable=4)
      @com.parameters([in,type=I4] Hidden) */
  public void setHidden(int Hidden);

  /** @com.method(vtoffset=16, dispid=2008, type=PROPGET, name="LoopSoundUntilNext", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLoopSoundUntilNext();

  /** @com.method(vtoffset=17, dispid=2008, type=PROPPUT, name="LoopSoundUntilNext", addFlagsVtable=4)
      @com.parameters([in,type=I4] LoopSoundUntilNext) */
  public void setLoopSoundUntilNext(int LoopSoundUntilNext);

  /** @com.method(vtoffset=18, dispid=2009, type=PROPGET, name="SoundEffect", addFlagsVtable=4)
      @com.parameters([iid=91493472-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SoundEffect getSoundEffect();

  /** @com.method(vtoffset=19, dispid=2010, type=PROPGET, name="Speed", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getSpeed();

  /** @com.method(vtoffset=20, dispid=2010, type=PROPPUT, name="Speed", addFlagsVtable=4)
      @com.parameters([in,type=I4] Speed) */
  public void setSpeed(int Speed);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493471, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
