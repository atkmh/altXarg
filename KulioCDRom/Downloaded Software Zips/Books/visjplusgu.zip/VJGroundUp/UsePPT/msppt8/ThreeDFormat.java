//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface ThreeDFormat
/** @com.interface(iid=91493483-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface ThreeDFormat extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="IncrementRotationX", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementRotationX(float Increment);

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="IncrementRotationY", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementRotationY(float Increment);

  /** @com.method(vtoffset=9, dispid=12, type=METHOD, name="ResetRotation", addFlagsVtable=4)
      @com.parameters() */
  public void ResetRotation();

  /** @com.method(vtoffset=10, dispid=13, type=METHOD, name="SetThreeDFormat", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetThreeDFormat) */
  public void SetThreeDFormat(int PresetThreeDFormat);

  /** @com.method(vtoffset=11, dispid=14, type=METHOD, name="SetExtrusionDirection", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetExtrusionDirection) */
  public void SetExtrusionDirection(int PresetExtrusionDirection);

  /** @com.method(vtoffset=12, dispid=100, type=PROPGET, name="Depth", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getDepth();

  /** @com.method(vtoffset=13, dispid=100, type=PROPPUT, name="Depth", addFlagsVtable=4)
      @com.parameters([in,type=R4] Depth) */
  public void setDepth(float Depth);

  /** @com.method(vtoffset=14, dispid=101, type=PROPGET, name="ExtrusionColor", addFlagsVtable=4)
      @com.parameters([iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorFormat getExtrusionColor();

  /** @com.method(vtoffset=15, dispid=102, type=PROPGET, name="ExtrusionColorType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getExtrusionColorType();

  /** @com.method(vtoffset=16, dispid=102, type=PROPPUT, name="ExtrusionColorType", addFlagsVtable=4)
      @com.parameters([in,type=I4] ExtrusionColorType) */
  public void setExtrusionColorType(int ExtrusionColorType);

  /** @com.method(vtoffset=17, dispid=103, type=PROPGET, name="Perspective", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPerspective();

  /** @com.method(vtoffset=18, dispid=103, type=PROPPUT, name="Perspective", addFlagsVtable=4)
      @com.parameters([in,type=I4] Perspective) */
  public void setPerspective(int Perspective);

  /** @com.method(vtoffset=19, dispid=104, type=PROPGET, name="PresetExtrusionDirection", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetExtrusionDirection();

  /** @com.method(vtoffset=20, dispid=105, type=PROPGET, name="PresetLightingDirection", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetLightingDirection();

  /** @com.method(vtoffset=21, dispid=105, type=PROPPUT, name="PresetLightingDirection", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetLightingDirection) */
  public void setPresetLightingDirection(int PresetLightingDirection);

  /** @com.method(vtoffset=22, dispid=106, type=PROPGET, name="PresetLightingSoftness", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetLightingSoftness();

  /** @com.method(vtoffset=23, dispid=106, type=PROPPUT, name="PresetLightingSoftness", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetLightingSoftness) */
  public void setPresetLightingSoftness(int PresetLightingSoftness);

  /** @com.method(vtoffset=24, dispid=107, type=PROPGET, name="PresetMaterial", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetMaterial();

  /** @com.method(vtoffset=25, dispid=107, type=PROPPUT, name="PresetMaterial", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetMaterial) */
  public void setPresetMaterial(int PresetMaterial);

  /** @com.method(vtoffset=26, dispid=108, type=PROPGET, name="PresetThreeDFormat", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetThreeDFormat();

  /** @com.method(vtoffset=27, dispid=109, type=PROPGET, name="RotationX", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getRotationX();

  /** @com.method(vtoffset=28, dispid=109, type=PROPPUT, name="RotationX", addFlagsVtable=4)
      @com.parameters([in,type=R4] RotationX) */
  public void setRotationX(float RotationX);

  /** @com.method(vtoffset=29, dispid=110, type=PROPGET, name="RotationY", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getRotationY();

  /** @com.method(vtoffset=30, dispid=110, type=PROPPUT, name="RotationY", addFlagsVtable=4)
      @com.parameters([in,type=R4] RotationY) */
  public void setRotationY(float RotationY);

  /** @com.method(vtoffset=31, dispid=111, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=32, dispid=111, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493483, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
