//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface ShapeNodes
/** @com.interface(iid=91493486-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface ShapeNodes extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=2, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=8, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] index, [iid=91493487-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShapeNode Item(Variant index);

  /** @com.method(vtoffset=9, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=10, dispid=11, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters([in,type=I4] index) */
  public void Delete(int index);

  /** @com.method(vtoffset=11, dispid=12, type=METHOD, name="Insert", addFlagsVtable=4)
      @com.parameters([in,type=I4] index, [in,type=I4] SegmentType, [in,type=I4] EditingType, [in,type=R4] X1, [in,type=R4] Y1, [in,type=R4] X2, [in,type=R4] Y2, [in,type=R4] X3, [in,type=R4] Y3) */
  public void Insert(int index, int SegmentType, int EditingType, float X1, float Y1, float X2, float Y2, float X3, float Y3);

  /** @com.method(vtoffset=12, dispid=13, type=METHOD, name="SetEditingType", addFlagsVtable=4)
      @com.parameters([in,type=I4] index, [in,type=I4] EditingType) */
  public void SetEditingType(int index, int EditingType);

  /** @com.method(vtoffset=13, dispid=14, type=METHOD, name="SetPosition", addFlagsVtable=4)
      @com.parameters([in,type=I4] index, [in,type=R4] X1, [in,type=R4] Y1) */
  public void SetPosition(int index, float X1, float Y1);

  /** @com.method(vtoffset=14, dispid=15, type=METHOD, name="SetSegmentType", addFlagsVtable=4)
      @com.parameters([in,type=I4] index, [in,type=I4] SegmentType) */
  public void SetSegmentType(int index, int SegmentType);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493486, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
