//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface Master
/** @com.interface(iid=9149346C-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface Master extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Shapes", addFlagsVtable=4)
      @com.parameters([iid=91493475-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Shapes getShapes();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="HeadersFooters", addFlagsVtable=4)
      @com.parameters([iid=91493474-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.HeadersFooters getHeadersFooters();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="ColorScheme", addFlagsVtable=4)
      @com.parameters([iid=9149346F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorScheme getColorScheme();

  /** @com.method(vtoffset=9, dispid=2005, type=PROPPUT, name="ColorScheme", addFlagsVtable=4)
      @com.parameters([in,iid=9149346F-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] ColorScheme) */
  public void setColorScheme(msppt8.ColorScheme ColorScheme);

  /** @com.method(vtoffset=10, dispid=2006, type=PROPGET, name="Background", addFlagsVtable=4)
      @com.parameters([iid=9149347A-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ShapeRange getBackground();

  /** @com.method(vtoffset=11, dispid=2007, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=12, dispid=2007, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);

  /** @com.method(vtoffset=13, dispid=2008, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=14, dispid=2009, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getHeight();

  /** @com.method(vtoffset=15, dispid=2010, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWidth();

  /** @com.method(vtoffset=16, dispid=2011, type=PROPGET, name="TextStyles", addFlagsVtable=4)
      @com.parameters([iid=91493498-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.TextStyles getTextStyles();

  /** @com.method(vtoffset=17, dispid=2012, type=PROPGET, name="Hyperlinks", addFlagsVtable=4)
      @com.parameters([iid=91493464-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Hyperlinks getHyperlinks();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149346c, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
