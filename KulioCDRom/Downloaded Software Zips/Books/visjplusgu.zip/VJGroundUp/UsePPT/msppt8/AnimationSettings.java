//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface AnimationSettings
/** @com.interface(iid=9149348B-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface AnimationSettings extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="DimColor", addFlagsVtable=4)
      @com.parameters([iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorFormat getDimColor();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="SoundEffect", addFlagsVtable=4)
      @com.parameters([iid=91493472-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.SoundEffect getSoundEffect();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="EntryEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEntryEffect();

  /** @com.method(vtoffset=9, dispid=2005, type=PROPPUT, name="EntryEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] EntryEffect) */
  public void setEntryEffect(int EntryEffect);

  /** @com.method(vtoffset=10, dispid=2006, type=PROPGET, name="AfterEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAfterEffect();

  /** @com.method(vtoffset=11, dispid=2006, type=PROPPUT, name="AfterEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] AfterEffect) */
  public void setAfterEffect(int AfterEffect);

  /** @com.method(vtoffset=12, dispid=2007, type=PROPGET, name="AnimationOrder", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimationOrder();

  /** @com.method(vtoffset=13, dispid=2007, type=PROPPUT, name="AnimationOrder", addFlagsVtable=4)
      @com.parameters([in,type=I4] AnimationOrder) */
  public void setAnimationOrder(int AnimationOrder);

  /** @com.method(vtoffset=14, dispid=2008, type=PROPGET, name="AdvanceMode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAdvanceMode();

  /** @com.method(vtoffset=15, dispid=2008, type=PROPPUT, name="AdvanceMode", addFlagsVtable=4)
      @com.parameters([in,type=I4] AdvanceMode) */
  public void setAdvanceMode(int AdvanceMode);

  /** @com.method(vtoffset=16, dispid=2009, type=PROPGET, name="AdvanceTime", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getAdvanceTime();

  /** @com.method(vtoffset=17, dispid=2009, type=PROPPUT, name="AdvanceTime", addFlagsVtable=4)
      @com.parameters([in,type=R4] AdvanceTime) */
  public void setAdvanceTime(float AdvanceTime);

  /** @com.method(vtoffset=18, dispid=2010, type=PROPGET, name="PlaySettings", addFlagsVtable=4)
      @com.parameters([iid=9149348E-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PlaySettings getPlaySettings();

  /** @com.method(vtoffset=19, dispid=2011, type=PROPGET, name="TextLevelEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTextLevelEffect();

  /** @com.method(vtoffset=20, dispid=2011, type=PROPPUT, name="TextLevelEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] TextLevelEffect) */
  public void setTextLevelEffect(int TextLevelEffect);

  /** @com.method(vtoffset=21, dispid=2012, type=PROPGET, name="TextUnitEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTextUnitEffect();

  /** @com.method(vtoffset=22, dispid=2012, type=PROPPUT, name="TextUnitEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] TextUnitEffect) */
  public void setTextUnitEffect(int TextUnitEffect);

  /** @com.method(vtoffset=23, dispid=2013, type=PROPGET, name="Animate", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimate();

  /** @com.method(vtoffset=24, dispid=2013, type=PROPPUT, name="Animate", addFlagsVtable=4)
      @com.parameters([in,type=I4] Animate) */
  public void setAnimate(int Animate);

  /** @com.method(vtoffset=25, dispid=2014, type=PROPGET, name="AnimateBackground", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimateBackground();

  /** @com.method(vtoffset=26, dispid=2014, type=PROPPUT, name="AnimateBackground", addFlagsVtable=4)
      @com.parameters([in,type=I4] AnimateBackground) */
  public void setAnimateBackground(int AnimateBackground);

  /** @com.method(vtoffset=27, dispid=2015, type=PROPGET, name="AnimateTextInReverse", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimateTextInReverse();

  /** @com.method(vtoffset=28, dispid=2015, type=PROPPUT, name="AnimateTextInReverse", addFlagsVtable=4)
      @com.parameters([in,type=I4] AnimateTextInReverse) */
  public void setAnimateTextInReverse(int AnimateTextInReverse);

  /** @com.method(vtoffset=29, dispid=2016, type=PROPGET, name="ChartUnitEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getChartUnitEffect();

  /** @com.method(vtoffset=30, dispid=2016, type=PROPPUT, name="ChartUnitEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] ChartUnitEffect) */
  public void setChartUnitEffect(int ChartUnitEffect);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149348b, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
