//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Enum: PpPrintRangeType

public interface PpPrintRangeType
{
  public static final int ppPrintAll = 1;
  public static final int ppPrintSelection = 2;
  public static final int ppPrintCurrent = 3;
  public static final int ppPrintSlideRange = 4;
  public static final int ppPrintNamedSlideShow = 5;
}
