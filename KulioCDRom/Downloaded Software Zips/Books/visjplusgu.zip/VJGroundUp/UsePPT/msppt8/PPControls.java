//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface PPControls
/** @com.interface(iid=914934A2-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface PPControls extends msppt8.Collection
{
  /** @com.method(vtoffset=4, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=5, dispid=10, type=METHOD, name="_Index", addFlagsVtable=4)
      @com.parameters([in,type=I4] _index, [type=VARIANT] return) */
  public Variant _Index(int _index);

  /** @com.method(vtoffset=6, dispid=11, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=7, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=8, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] index, [iid=914934A4-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPControl Item(Variant index);

  /** @com.method(vtoffset=9, dispid=2002, type=METHOD, name="AddPushButton", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934A5-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPPushButton AddPushButton(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=10, dispid=2003, type=METHOD, name="AddToggleButton", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934A6-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPToggleButton AddToggleButton(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=11, dispid=2004, type=METHOD, name="AddBitmapButton", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934A7-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPBitmapButton AddBitmapButton(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=12, dispid=2005, type=METHOD, name="AddListBox", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934A8-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPListBox AddListBox(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=13, dispid=2006, type=METHOD, name="AddCheckBox", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934AA-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPCheckBox AddCheckBox(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=14, dispid=2007, type=METHOD, name="AddRadioCluster", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934AB-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPRadioCluster AddRadioCluster(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=15, dispid=2008, type=METHOD, name="AddStaticText", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934AC-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPStaticText AddStaticText(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=16, dispid=2009, type=METHOD, name="AddEditText", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [in,type=VARIANT] VerticalScrollBar, [iid=914934AD-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPEditText AddEditText(float Left, float Top, float Width, float Height, Variant VerticalScrollBar);

  /** @com.method(vtoffset=17, dispid=2010, type=METHOD, name="AddIcon", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934AE-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPIcon AddIcon(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=18, dispid=2011, type=METHOD, name="AddBitmap", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934AF-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPBitmap AddBitmap(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=19, dispid=2012, type=METHOD, name="AddSpinner", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B0-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPSpinner AddSpinner(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=20, dispid=2013, type=METHOD, name="AddScrollBar", addFlagsVtable=4)
      @com.parameters([in,type=I4] Style, [in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B1-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPScrollBar AddScrollBar(int Style, float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=21, dispid=2014, type=METHOD, name="AddGroupBox", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B2-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPGroupBox AddGroupBox(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=22, dispid=2015, type=METHOD, name="AddDropDown", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B5-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPDropDown AddDropDown(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=23, dispid=2016, type=METHOD, name="AddDropDownEdit", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B6-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPDropDownEdit AddDropDownEdit(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=24, dispid=2017, type=METHOD, name="AddMiniature", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B7-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPSlideMiniature AddMiniature(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=25, dispid=2018, type=METHOD, name="AddFrame", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=914934B3-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPFrame AddFrame(float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=26, dispid=2019, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=27, dispid=2019, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x914934a2, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
