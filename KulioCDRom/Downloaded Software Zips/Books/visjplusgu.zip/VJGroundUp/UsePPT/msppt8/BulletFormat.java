//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface BulletFormat
/** @com.interface(iid=91493497-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface BulletFormat extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=6, dispid=0, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=7, dispid=0, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=8, dispid=2003, type=PROPGET, name="Character", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCharacter();

  /** @com.method(vtoffset=9, dispid=2003, type=PROPPUT, name="Character", addFlagsVtable=4)
      @com.parameters([in,type=I4] Character) */
  public void setCharacter(int Character);

  /** @com.method(vtoffset=10, dispid=2004, type=PROPGET, name="RelativeSize", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getRelativeSize();

  /** @com.method(vtoffset=11, dispid=2004, type=PROPPUT, name="RelativeSize", addFlagsVtable=4)
      @com.parameters([in,type=R4] RelativeSize) */
  public void setRelativeSize(float RelativeSize);

  /** @com.method(vtoffset=12, dispid=2005, type=PROPGET, name="UseTextColor", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getUseTextColor();

  /** @com.method(vtoffset=13, dispid=2005, type=PROPPUT, name="UseTextColor", addFlagsVtable=4)
      @com.parameters([in,type=I4] UseTextColor) */
  public void setUseTextColor(int UseTextColor);

  /** @com.method(vtoffset=14, dispid=2006, type=PROPGET, name="UseTextFont", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getUseTextFont();

  /** @com.method(vtoffset=15, dispid=2006, type=PROPPUT, name="UseTextFont", addFlagsVtable=4)
      @com.parameters([in,type=I4] UseTextFont) */
  public void setUseTextFont(int UseTextFont);

  /** @com.method(vtoffset=16, dispid=2007, type=PROPGET, name="Font", addFlagsVtable=4)
      @com.parameters([iid=91493495-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.Font getFont();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493497, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
