//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Enum: PpEntryEffect

public interface PpEntryEffect
{
  public static final int ppEffectMixed = -2;
  public static final int ppEffectNone = 0;
  public static final int ppEffectCut = 257;
  public static final int ppEffectCutThroughBlack = 258;
  public static final int ppEffectRandom = 513;
  public static final int ppEffectBlindsHorizontal = 769;
  public static final int ppEffectBlindsVertical = 770;
  public static final int ppEffectCheckerboardAcross = 1025;
  public static final int ppEffectCheckerboardDown = 1026;
  public static final int ppEffectCoverLeft = 1281;
  public static final int ppEffectCoverUp = 1282;
  public static final int ppEffectCoverRight = 1283;
  public static final int ppEffectCoverDown = 1284;
  public static final int ppEffectCoverLeftUp = 1285;
  public static final int ppEffectCoverRightUp = 1286;
  public static final int ppEffectCoverLeftDown = 1287;
  public static final int ppEffectCoverRightDown = 1288;
  public static final int ppEffectDissolve = 1537;
  public static final int ppEffectFade = 1793;
  public static final int ppEffectUncoverLeft = 2049;
  public static final int ppEffectUncoverUp = 2050;
  public static final int ppEffectUncoverRight = 2051;
  public static final int ppEffectUncoverDown = 2052;
  public static final int ppEffectUncoverLeftUp = 2053;
  public static final int ppEffectUncoverRightUp = 2054;
  public static final int ppEffectUncoverLeftDown = 2055;
  public static final int ppEffectUncoverRightDown = 2056;
  public static final int ppEffectRandomBarsHorizontal = 2305;
  public static final int ppEffectRandomBarsVertical = 2306;
  public static final int ppEffectStripsUpLeft = 2561;
  public static final int ppEffectStripsUpRight = 2562;
  public static final int ppEffectStripsDownLeft = 2563;
  public static final int ppEffectStripsDownRight = 2564;
  public static final int ppEffectStripsLeftUp = 2565;
  public static final int ppEffectStripsRightUp = 2566;
  public static final int ppEffectStripsLeftDown = 2567;
  public static final int ppEffectStripsRightDown = 2568;
  public static final int ppEffectWipeLeft = 2817;
  public static final int ppEffectWipeUp = 2818;
  public static final int ppEffectWipeRight = 2819;
  public static final int ppEffectWipeDown = 2820;
  public static final int ppEffectBoxOut = 3073;
  public static final int ppEffectBoxIn = 3074;
  public static final int ppEffectFlyFromLeft = 3329;
  public static final int ppEffectFlyFromTop = 3330;
  public static final int ppEffectFlyFromRight = 3331;
  public static final int ppEffectFlyFromBottom = 3332;
  public static final int ppEffectFlyFromTopLeft = 3333;
  public static final int ppEffectFlyFromTopRight = 3334;
  public static final int ppEffectFlyFromBottomLeft = 3335;
  public static final int ppEffectFlyFromBottomRight = 3336;
  public static final int ppEffectPeekFromLeft = 3337;
  public static final int ppEffectPeekFromDown = 3338;
  public static final int ppEffectPeekFromRight = 3339;
  public static final int ppEffectPeekFromUp = 3340;
  public static final int ppEffectCrawlFromLeft = 3341;
  public static final int ppEffectCrawlFromUp = 3342;
  public static final int ppEffectCrawlFromRight = 3343;
  public static final int ppEffectCrawlFromDown = 3344;
  public static final int ppEffectZoomIn = 3345;
  public static final int ppEffectZoomInSlightly = 3346;
  public static final int ppEffectZoomOut = 3347;
  public static final int ppEffectZoomOutSlightly = 3348;
  public static final int ppEffectZoomCenter = 3349;
  public static final int ppEffectZoomBottom = 3350;
  public static final int ppEffectStretchAcross = 3351;
  public static final int ppEffectStretchLeft = 3352;
  public static final int ppEffectStretchUp = 3353;
  public static final int ppEffectStretchRight = 3354;
  public static final int ppEffectStretchDown = 3355;
  public static final int ppEffectSwivel = 3356;
  public static final int ppEffectSpiral = 3357;
  public static final int ppEffectSplitHorizontalOut = 3585;
  public static final int ppEffectSplitHorizontalIn = 3586;
  public static final int ppEffectSplitVerticalOut = 3587;
  public static final int ppEffectSplitVerticalIn = 3588;
  public static final int ppEffectFlashOnceFast = 3841;
  public static final int ppEffectFlashOnceMedium = 3842;
  public static final int ppEffectFlashOnceSlow = 3843;
  public static final int ppEffectAppear = 3844;
}
