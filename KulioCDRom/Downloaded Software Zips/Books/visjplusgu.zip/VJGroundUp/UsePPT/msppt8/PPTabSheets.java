//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface PPTabSheets
/** @com.interface(iid=914934A3-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface PPTabSheets extends msppt8.Collection
{
  /** @com.method(vtoffset=4, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=5, dispid=10, type=METHOD, name="_Index", addFlagsVtable=4)
      @com.parameters([in,type=I4] _index, [type=VARIANT] return) */
  public Variant _Index(int _index);

  /** @com.method(vtoffset=6, dispid=11, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=7, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] index, [iid=914934A1-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPTabSheet Item(Variant index);

  /** @com.method(vtoffset=8, dispid=2001, type=METHOD, name="Add", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name, [iid=914934A1-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPTabSheet Add(String Name);

  /** @com.method(vtoffset=9, dispid=2002, type=PROPGET, name="ActiveSheet", addFlagsVtable=4)
      @com.parameters([iid=914934A1-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.PPTabSheet getActiveSheet();

  /** @com.method(vtoffset=10, dispid=2003, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=11, dispid=2003, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x914934a3, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
