//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface FillFormat
/** @com.interface(iid=9149347E-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface FillFormat extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="Background", addFlagsVtable=4)
      @com.parameters() */
  public void Background();

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="OneColorGradient", addFlagsVtable=4)
      @com.parameters([in,type=I4] Style, [in,type=I4] Variant, [in,type=R4] Degree) */
  public void OneColorGradient(int Style, int Variant, float Degree);

  /** @com.method(vtoffset=9, dispid=12, type=METHOD, name="Patterned", addFlagsVtable=4)
      @com.parameters([in,type=I4] Pattern) */
  public void Patterned(int Pattern);

  /** @com.method(vtoffset=10, dispid=13, type=METHOD, name="PresetGradient", addFlagsVtable=4)
      @com.parameters([in,type=I4] Style, [in,type=I4] Variant, [in,type=I4] PresetGradientType) */
  public void PresetGradient(int Style, int Variant, int PresetGradientType);

  /** @com.method(vtoffset=11, dispid=14, type=METHOD, name="PresetTextured", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetTexture) */
  public void PresetTextured(int PresetTexture);

  /** @com.method(vtoffset=12, dispid=15, type=METHOD, name="Solid", addFlagsVtable=4)
      @com.parameters() */
  public void Solid();

  /** @com.method(vtoffset=13, dispid=16, type=METHOD, name="TwoColorGradient", addFlagsVtable=4)
      @com.parameters([in,type=I4] Style, [in,type=I4] Variant) */
  public void TwoColorGradient(int Style, int Variant);

  /** @com.method(vtoffset=14, dispid=17, type=METHOD, name="UserPicture", addFlagsVtable=4)
      @com.parameters([in,type=STRING] PictureFile) */
  public void UserPicture(String PictureFile);

  /** @com.method(vtoffset=15, dispid=18, type=METHOD, name="UserTextured", addFlagsVtable=4)
      @com.parameters([in,type=STRING] TextureFile) */
  public void UserTextured(String TextureFile);

  /** @com.method(vtoffset=16, dispid=100, type=PROPGET, name="BackColor", addFlagsVtable=4)
      @com.parameters([iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorFormat getBackColor();

  /** @com.method(vtoffset=17, dispid=100, type=PROPPUT, name="BackColor", addFlagsVtable=4)
      @com.parameters([in,iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] BackColor) */
  public void setBackColor(msppt8.ColorFormat BackColor);

  /** @com.method(vtoffset=18, dispid=101, type=PROPGET, name="ForeColor", addFlagsVtable=4)
      @com.parameters([iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorFormat getForeColor();

  /** @com.method(vtoffset=19, dispid=101, type=PROPPUT, name="ForeColor", addFlagsVtable=4)
      @com.parameters([in,iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] ForeColor) */
  public void setForeColor(msppt8.ColorFormat ForeColor);

  /** @com.method(vtoffset=20, dispid=102, type=PROPGET, name="GradientColorType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getGradientColorType();

  /** @com.method(vtoffset=21, dispid=103, type=PROPGET, name="GradientDegree", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getGradientDegree();

  /** @com.method(vtoffset=22, dispid=104, type=PROPGET, name="GradientStyle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getGradientStyle();

  /** @com.method(vtoffset=23, dispid=105, type=PROPGET, name="GradientVariant", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getGradientVariant();

  /** @com.method(vtoffset=24, dispid=106, type=PROPGET, name="Pattern", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPattern();

  /** @com.method(vtoffset=25, dispid=107, type=PROPGET, name="PresetGradientType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetGradientType();

  /** @com.method(vtoffset=26, dispid=108, type=PROPGET, name="PresetTexture", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetTexture();

  /** @com.method(vtoffset=27, dispid=109, type=PROPGET, name="TextureName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getTextureName();

  /** @com.method(vtoffset=28, dispid=110, type=PROPGET, name="TextureType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTextureType();

  /** @com.method(vtoffset=29, dispid=111, type=PROPGET, name="Transparency", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTransparency();

  /** @com.method(vtoffset=30, dispid=111, type=PROPPUT, name="Transparency", addFlagsVtable=4)
      @com.parameters([in,type=R4] Transparency) */
  public void setTransparency(float Transparency);

  /** @com.method(vtoffset=31, dispid=112, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=32, dispid=113, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=33, dispid=113, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x9149347e, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
