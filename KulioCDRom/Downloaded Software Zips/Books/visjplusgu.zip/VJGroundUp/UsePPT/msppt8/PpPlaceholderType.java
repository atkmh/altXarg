//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Enum: PpPlaceholderType

public interface PpPlaceholderType
{
  public static final int ppPlaceholderMixed = -2;
  public static final int ppPlaceholderTitle = 1;
  public static final int ppPlaceholderBody = 2;
  public static final int ppPlaceholderCenterTitle = 3;
  public static final int ppPlaceholderSubtitle = 4;
  public static final int ppPlaceholderVerticalTitle = 5;
  public static final int ppPlaceholderVerticalBody = 6;
  public static final int ppPlaceholderObject = 7;
  public static final int ppPlaceholderChart = 8;
  public static final int ppPlaceholderBitmap = 9;
  public static final int ppPlaceholderMediaClip = 10;
  public static final int ppPlaceholderOrgChart = 11;
  public static final int ppPlaceholderTable = 12;
  public static final int ppPlaceholderSlideNumber = 13;
  public static final int ppPlaceholderHeader = 14;
  public static final int ppPlaceholderFooter = 15;
  public static final int ppPlaceholderDate = 16;
}
