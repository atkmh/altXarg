//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

// Dual interface ShadowFormat
/** @com.interface(iid=91493480-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL) */
public interface ShadowFormat extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="IncrementOffsetX", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementOffsetX(float Increment);

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="IncrementOffsetY", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementOffsetY(float Increment);

  /** @com.method(vtoffset=9, dispid=100, type=PROPGET, name="ForeColor", addFlagsVtable=4)
      @com.parameters([iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public msppt8.ColorFormat getForeColor();

  /** @com.method(vtoffset=10, dispid=100, type=PROPPUT, name="ForeColor", addFlagsVtable=4)
      @com.parameters([in,iid=91493452-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] ForeColor) */
  public void setForeColor(msppt8.ColorFormat ForeColor);

  /** @com.method(vtoffset=11, dispid=101, type=PROPGET, name="Obscured", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getObscured();

  /** @com.method(vtoffset=12, dispid=101, type=PROPPUT, name="Obscured", addFlagsVtable=4)
      @com.parameters([in,type=I4] Obscured) */
  public void setObscured(int Obscured);

  /** @com.method(vtoffset=13, dispid=102, type=PROPGET, name="OffsetX", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getOffsetX();

  /** @com.method(vtoffset=14, dispid=102, type=PROPPUT, name="OffsetX", addFlagsVtable=4)
      @com.parameters([in,type=R4] OffsetX) */
  public void setOffsetX(float OffsetX);

  /** @com.method(vtoffset=15, dispid=103, type=PROPGET, name="OffsetY", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getOffsetY();

  /** @com.method(vtoffset=16, dispid=103, type=PROPPUT, name="OffsetY", addFlagsVtable=4)
      @com.parameters([in,type=R4] OffsetY) */
  public void setOffsetY(float OffsetY);

  /** @com.method(vtoffset=17, dispid=104, type=PROPGET, name="Transparency", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTransparency();

  /** @com.method(vtoffset=18, dispid=104, type=PROPPUT, name="Transparency", addFlagsVtable=4)
      @com.parameters([in,type=R4] Transparency) */
  public void setTransparency(float Transparency);

  /** @com.method(vtoffset=19, dispid=105, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=20, dispid=105, type=PROPPUT, name="Type", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type) */
  public void setType(int Type);

  /** @com.method(vtoffset=21, dispid=106, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=22, dispid=106, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493480, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
