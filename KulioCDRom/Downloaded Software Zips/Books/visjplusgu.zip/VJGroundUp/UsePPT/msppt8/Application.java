//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package msppt8;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import mso97.*;

/** @com.class(classid=91493441-5A91-11CF-8700-00AA0060263B,DynamicCasts)
    @com.interface(iid=91493442-5A91-11CF-8700-00AA0060263B, thread=AUTO, type=DUAL)
*/
public class Application implements IUnknown,com.ms.com.NoAutoScripting,msppt8._Application
{
  /** @com.method(vtoffset=4, dispid=2001, type=PROPGET, name="Presentations", addFlagsVtable=4)
      @com.parameters([iid=91493462-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.Presentations getPresentations();

  /** @com.method(vtoffset=5, dispid=2002, type=PROPGET, name="Windows", addFlagsVtable=4)
      @com.parameters([iid=91493455-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.DocumentWindows getWindows();

  /** @com.method(vtoffset=6, dispid=2003, type=PROPGET, name="Dialogs", addFlagsVtable=4)
      @com.parameters([iid=9149349E-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.PPDialogs getDialogs();

  /** @com.method(vtoffset=7, dispid=2004, type=PROPGET, name="ActiveWindow", addFlagsVtable=4)
      @com.parameters([iid=91493457-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.DocumentWindow getActiveWindow();

  /** @com.method(vtoffset=8, dispid=2005, type=PROPGET, name="ActivePresentation", addFlagsVtable=4)
      @com.parameters([iid=9149349D-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=OBJECT] return) */
  public native msppt8.Presentation getActivePresentation();

  /** @com.method(vtoffset=9, dispid=2006, type=PROPGET, name="SlideShowWindows", addFlagsVtable=4)
      @com.parameters([iid=91493456-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.SlideShowWindows getSlideShowWindows();

  /** @com.method(vtoffset=10, dispid=2007, type=PROPGET, name="CommandBars", addFlagsVtable=4)
      @com.parameters([iid=000C0302-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native mso97.CommandBars getCommandBars();

  /** @com.method(vtoffset=11, dispid=2008, type=PROPGET, name="Path", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getPath();

  /** @com.method(vtoffset=12, dispid=0, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getName();

  /** @com.method(vtoffset=13, dispid=2009, type=PROPGET, name="Caption", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getCaption();

  /** @com.method(vtoffset=14, dispid=2009, type=PROPPUT, name="Caption", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Caption) */
  public native void setCaption(String Caption);

  /** @com.method(vtoffset=15, dispid=2010, type=PROPGET, name="Assistant", addFlagsVtable=4)
      @com.parameters([iid=000C0322-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native mso97.Assistant getAssistant();

  /** @com.method(vtoffset=16, dispid=2011, type=PROPGET, name="FileSearch", addFlagsVtable=4)
      @com.parameters([iid=000C0332-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native mso97.FileSearch getFileSearch();

  /** @com.method(vtoffset=17, dispid=2012, type=PROPGET, name="FileFind", addFlagsVtable=4)
      @com.parameters([iid=000C0337-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native mso97.IFind getFileFind();

  /** @com.method(vtoffset=18, dispid=2013, type=PROPGET, name="Build", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getBuild();

  /** @com.method(vtoffset=19, dispid=2014, type=PROPGET, name="Version", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getVersion();

  /** @com.method(vtoffset=20, dispid=2015, type=PROPGET, name="OperatingSystem", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getOperatingSystem();

  /** @com.method(vtoffset=21, dispid=2016, type=PROPGET, name="ActivePrinter", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getActivePrinter();

  /** @com.method(vtoffset=22, dispid=2017, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getCreator();

  /** @com.method(vtoffset=23, dispid=2018, type=PROPGET, name="AddIns", addFlagsVtable=4)
      @com.parameters([iid=91493460-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.AddIns getAddIns();

  /** @com.method(vtoffset=24, dispid=2019, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.VBE getVBE();

  /** @com.method(vtoffset=25, dispid=2020, type=METHOD, name="Help", addFlagsVtable=4)
      @com.parameters([in,type=STRING] HelpFile, [in,type=I4] ContextID) */
  public native void Help(String HelpFile, int ContextID);

  /** @com.method(vtoffset=26, dispid=2021, type=METHOD, name="Quit", addFlagsVtable=4)
      @com.parameters() */
  public native void Quit();

  /** @com.method(vtoffset=27, dispid=2022, type=METHOD, name="Run", addFlagsVtable=4)
      @com.parameters([in,type=STRING] MacroName, [in,vt=16396,type=SAFEARRAY] safeArrayOfParams, [type=VARIANT] return) */
  public native Variant Run(String MacroName, com.ms.com.SafeArray safeArrayOfParams);

  /** @com.method(vtoffset=28, dispid=2023, type=METHOD, name="FileDialog", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type, [iid=914934BD-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] return) */
  public native msppt8.FileDialog FileDialog(int Type);

  /** @com.method(vtoffset=29, dispid=2024, type=METHOD, name="LaunchSpelling", addFlagsVtable=4)
      @com.parameters([in,iid=91493457-5A91-11CF-8700-00AA0060263B,thread=AUTO,type=DISPATCH] pWindow) */
  public native void LaunchSpelling(msppt8.DocumentWindow pWindow);

  /** @com.method(vtoffset=30, dispid=2025, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public native float getLeft();

  /** @com.method(vtoffset=31, dispid=2025, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left) */
  public native void setLeft(float Left);

  /** @com.method(vtoffset=32, dispid=2026, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public native float getTop();

  /** @com.method(vtoffset=33, dispid=2026, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=R4] Top) */
  public native void setTop(float Top);

  /** @com.method(vtoffset=34, dispid=2027, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public native float getWidth();

  /** @com.method(vtoffset=35, dispid=2027, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=R4] Width) */
  public native void setWidth(float Width);

  /** @com.method(vtoffset=36, dispid=2028, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public native float getHeight();

  /** @com.method(vtoffset=37, dispid=2028, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=R4] Height) */
  public native void setHeight(float Height);

  /** @com.method(vtoffset=38, dispid=2029, type=PROPGET, name="WindowState", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getWindowState();

  /** @com.method(vtoffset=39, dispid=2029, type=PROPPUT, name="WindowState", addFlagsVtable=4)
      @com.parameters([in,type=I4] WindowState) */
  public native void setWindowState(int WindowState);

  /** @com.method(vtoffset=40, dispid=2030, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getVisible();

  /** @com.method(vtoffset=41, dispid=2030, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public native void setVisible(int Visible);

  /** @com.method(vtoffset=42, dispid=2031, type=PROPGET, name="HWND", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getHWND();

  /** @com.method(vtoffset=43, dispid=2032, type=PROPGET, name="Active", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getActive();

  /** @com.method(vtoffset=44, dispid=2033, type=METHOD, name="Activate", addFlagsVtable=4)
      @com.parameters() */
  public native void Activate();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x91493442, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0x91493441, (short)0x5a91, (short)0x11cf, (byte)0x87, (byte)0x0, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x60, (byte)0x26, (byte)0x3b);
}
