//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoPresetThreeDFormat

public interface MsoPresetThreeDFormat
{
  public static final int msoPresetThreeDFormatMixed = -2;
  public static final int msoThreeD1 = 1;
  public static final int msoThreeD2 = 2;
  public static final int msoThreeD3 = 3;
  public static final int msoThreeD4 = 4;
  public static final int msoThreeD5 = 5;
  public static final int msoThreeD6 = 6;
  public static final int msoThreeD7 = 7;
  public static final int msoThreeD8 = 8;
  public static final int msoThreeD9 = 9;
  public static final int msoThreeD10 = 10;
  public static final int msoThreeD11 = 11;
  public static final int msoThreeD12 = 12;
  public static final int msoThreeD13 = 13;
  public static final int msoThreeD14 = 14;
  public static final int msoThreeD15 = 15;
  public static final int msoThreeD16 = 16;
  public static final int msoThreeD17 = 17;
  public static final int msoThreeD18 = 18;
  public static final int msoThreeD19 = 19;
  public static final int msoThreeD20 = 20;
}
