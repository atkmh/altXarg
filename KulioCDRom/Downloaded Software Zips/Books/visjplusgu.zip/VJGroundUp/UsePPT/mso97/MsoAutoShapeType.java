//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoAutoShapeType

public interface MsoAutoShapeType
{
  public static final int msoShapeMixed = -2;
  public static final int msoShapeRectangle = 1;
  public static final int msoShapeParallelogram = 2;
  public static final int msoShapeTrapezoid = 3;
  public static final int msoShapeDiamond = 4;
  public static final int msoShapeRoundedRectangle = 5;
  public static final int msoShapeOctagon = 6;
  public static final int msoShapeIsoscelesTriangle = 7;
  public static final int msoShapeRightTriangle = 8;
  public static final int msoShapeOval = 9;
  public static final int msoShapeHexagon = 10;
  public static final int msoShapeCross = 11;
  public static final int msoShapeRegularPentagon = 12;
  public static final int msoShapeCan = 13;
  public static final int msoShapeCube = 14;
  public static final int msoShapeBevel = 15;
  public static final int msoShapeFoldedCorner = 16;
  public static final int msoShapeSmileyFace = 17;
  public static final int msoShapeDonut = 18;
  public static final int msoShapeNoSymbol = 19;
  public static final int msoShapeBlockArc = 20;
  public static final int msoShapeHeart = 21;
  public static final int msoShapeLightningBolt = 22;
  public static final int msoShapeSun = 23;
  public static final int msoShapeMoon = 24;
  public static final int msoShapeArc = 25;
  public static final int msoShapeDoubleBracket = 26;
  public static final int msoShapeDoubleBrace = 27;
  public static final int msoShapePlaque = 28;
  public static final int msoShapeLeftBracket = 29;
  public static final int msoShapeRightBracket = 30;
  public static final int msoShapeLeftBrace = 31;
  public static final int msoShapeRightBrace = 32;
  public static final int msoShapeRightArrow = 33;
  public static final int msoShapeLeftArrow = 34;
  public static final int msoShapeUpArrow = 35;
  public static final int msoShapeDownArrow = 36;
  public static final int msoShapeLeftRightArrow = 37;
  public static final int msoShapeUpDownArrow = 38;
  public static final int msoShapeQuadArrow = 39;
  public static final int msoShapeLeftRightUpArrow = 40;
  public static final int msoShapeBentArrow = 41;
  public static final int msoShapeUTurnArrow = 42;
  public static final int msoShapeLeftUpArrow = 43;
  public static final int msoShapeBentUpArrow = 44;
  public static final int msoShapeCurvedRightArrow = 45;
  public static final int msoShapeCurvedLeftArrow = 46;
  public static final int msoShapeCurvedUpArrow = 47;
  public static final int msoShapeCurvedDownArrow = 48;
  public static final int msoShapeStripedRightArrow = 49;
  public static final int msoShapeNotchedRightArrow = 50;
  public static final int msoShapePentagon = 51;
  public static final int msoShapeChevron = 52;
  public static final int msoShapeRightArrowCallout = 53;
  public static final int msoShapeLeftArrowCallout = 54;
  public static final int msoShapeUpArrowCallout = 55;
  public static final int msoShapeDownArrowCallout = 56;
  public static final int msoShapeLeftRightArrowCallout = 57;
  public static final int msoShapeUpDownArrowCallout = 58;
  public static final int msoShapeQuadArrowCallout = 59;
  public static final int msoShapeCircularArrow = 60;
  public static final int msoShapeFlowchartProcess = 61;
  public static final int msoShapeFlowchartAlternateProcess = 62;
  public static final int msoShapeFlowchartDecision = 63;
  public static final int msoShapeFlowchartData = 64;
  public static final int msoShapeFlowchartPredefinedProcess = 65;
  public static final int msoShapeFlowchartInternalStorage = 66;
  public static final int msoShapeFlowchartDocument = 67;
  public static final int msoShapeFlowchartMultidocument = 68;
  public static final int msoShapeFlowchartTerminator = 69;
  public static final int msoShapeFlowchartPreparation = 70;
  public static final int msoShapeFlowchartManualInput = 71;
  public static final int msoShapeFlowchartManualOperation = 72;
  public static final int msoShapeFlowchartConnector = 73;
  public static final int msoShapeFlowchartOffpageConnector = 74;
  public static final int msoShapeFlowchartCard = 75;
  public static final int msoShapeFlowchartPunchedTape = 76;
  public static final int msoShapeFlowchartSummingJunction = 77;
  public static final int msoShapeFlowchartOr = 78;
  public static final int msoShapeFlowchartCollate = 79;
  public static final int msoShapeFlowchartSort = 80;
  public static final int msoShapeFlowchartExtract = 81;
  public static final int msoShapeFlowchartMerge = 82;
  public static final int msoShapeFlowchartStoredData = 83;
  public static final int msoShapeFlowchartDelay = 84;
  public static final int msoShapeFlowchartSequentialAccessStorage = 85;
  public static final int msoShapeFlowchartMagneticDisk = 86;
  public static final int msoShapeFlowchartDirectAccessStorage = 87;
  public static final int msoShapeFlowchartDisplay = 88;
  public static final int msoShapeExplosion1 = 89;
  public static final int msoShapeExplosion2 = 90;
  public static final int msoShape4pointStar = 91;
  public static final int msoShape5pointStar = 92;
  public static final int msoShape8pointStar = 93;
  public static final int msoShape16pointStar = 94;
  public static final int msoShape24pointStar = 95;
  public static final int msoShape32pointStar = 96;
  public static final int msoShapeUpRibbon = 97;
  public static final int msoShapeDownRibbon = 98;
  public static final int msoShapeCurvedUpRibbon = 99;
  public static final int msoShapeCurvedDownRibbon = 100;
  public static final int msoShapeVerticalScroll = 101;
  public static final int msoShapeHorizontalScroll = 102;
  public static final int msoShapeWave = 103;
  public static final int msoShapeDoubleWave = 104;
  public static final int msoShapeRectangularCallout = 105;
  public static final int msoShapeRoundedRectangularCallout = 106;
  public static final int msoShapeOvalCallout = 107;
  public static final int msoShapeCloudCallout = 108;
  public static final int msoShapeLineCallout1 = 109;
  public static final int msoShapeLineCallout2 = 110;
  public static final int msoShapeLineCallout3 = 111;
  public static final int msoShapeLineCallout4 = 112;
  public static final int msoShapeLineCallout1AccentBar = 113;
  public static final int msoShapeLineCallout2AccentBar = 114;
  public static final int msoShapeLineCallout3AccentBar = 115;
  public static final int msoShapeLineCallout4AccentBar = 116;
  public static final int msoShapeLineCallout1NoBorder = 117;
  public static final int msoShapeLineCallout2NoBorder = 118;
  public static final int msoShapeLineCallout3NoBorder = 119;
  public static final int msoShapeLineCallout4NoBorder = 120;
  public static final int msoShapeLineCallout1BorderandAccentBar = 121;
  public static final int msoShapeLineCallout2BorderandAccentBar = 122;
  public static final int msoShapeLineCallout3BorderandAccentBar = 123;
  public static final int msoShapeLineCallout4BorderandAccentBar = 124;
  public static final int msoShapeActionButtonCustom = 125;
  public static final int msoShapeActionButtonHome = 126;
  public static final int msoShapeActionButtonHelp = 127;
  public static final int msoShapeActionButtonInformation = 128;
  public static final int msoShapeActionButtonBackorPrevious = 129;
  public static final int msoShapeActionButtonForwardorNext = 130;
  public static final int msoShapeActionButtonBeginning = 131;
  public static final int msoShapeActionButtonEnd = 132;
  public static final int msoShapeActionButtonReturn = 133;
  public static final int msoShapeActionButtonDocument = 134;
  public static final int msoShapeActionButtonSound = 135;
  public static final int msoShapeActionButtonMovie = 136;
  public static final int msoShapeBalloon = 137;
  public static final int msoShapeNotPrimitive = 138;
}
