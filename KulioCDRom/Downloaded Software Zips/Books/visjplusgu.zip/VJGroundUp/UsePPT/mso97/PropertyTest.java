//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface PropertyTest
/** @com.interface(iid=000C0333-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface PropertyTest extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=0, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=7, dispid=2, type=PROPGET, name="Condition", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCondition();

  /** @com.method(vtoffset=8, dispid=3, type=PROPGET, name="Value", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getValue();

  /** @com.method(vtoffset=9, dispid=4, type=PROPGET, name="SecondValue", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getSecondValue();

  /** @com.method(vtoffset=10, dispid=5, type=PROPGET, name="Connector", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getConnector();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0333, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
