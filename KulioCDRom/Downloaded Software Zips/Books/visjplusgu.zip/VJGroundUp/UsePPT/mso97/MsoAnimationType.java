//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoAnimationType

public interface MsoAnimationType
{
  public static final int msoAnimationIdle = 1;
  public static final int msoAnimationGreeting = 2;
  public static final int msoAnimationGoodbye = 3;
  public static final int msoAnimationBeginSpeaking = 4;
  public static final int msoAnimationCharacterSuccessMajor = 6;
  public static final int msoAnimationGetAttentionMajor = 11;
  public static final int msoAnimationGetAttentionMinor = 12;
  public static final int msoAnimationSearching = 13;
  public static final int msoAnimationPrinting = 18;
  public static final int msoAnimationGestureRight = 19;
  public static final int msoAnimationWritingNotingSomething = 22;
  public static final int msoAnimationWorkingAtSomething = 23;
  public static final int msoAnimationThinking = 24;
  public static final int msoAnimationSendingMail = 25;
  public static final int msoAnimationListensToComputer = 26;
  public static final int msoAnimationDisappear = 31;
  public static final int msoAnimationAppear = 32;
  public static final int msoAnimationGetArtsy = 100;
  public static final int msoAnimationGetTechy = 101;
  public static final int msoAnimationGetWizardy = 102;
  public static final int msoAnimationCheckingSomething = 103;
  public static final int msoAnimationLookDown = 104;
  public static final int msoAnimationLookDownLeft = 105;
  public static final int msoAnimationLookDownRight = 106;
  public static final int msoAnimationLookLeft = 107;
  public static final int msoAnimationLookRight = 108;
  public static final int msoAnimationLookUp = 109;
  public static final int msoAnimationLookUpLeft = 110;
  public static final int msoAnimationLookUpRight = 111;
  public static final int msoAnimationSaving = 112;
  public static final int msoAnimationGestureDown = 113;
  public static final int msoAnimationGestureLeft = 114;
  public static final int msoAnimationGestureUp = 115;
  public static final int msoAnimationEmptyTrash = 116;
}
