//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface PropertyTests
/** @com.interface(iid=000C0334-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface PropertyTests extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=0, type=PROPGET, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index, [in,addFlags=4,type=I4] lcid, [iid=000C0333-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.PropertyTest getItem(int Index, int lcid);

  /** @com.method(vtoffset=7, dispid=4, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=8, dispid=5, type=METHOD, name="Add", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name, [in,type=I4] Condition, [in,type=VARIANT] Value, [in,type=VARIANT] SecondValue, [in,type=I4] Connector) */
  public void Add(String Name, int Condition, Variant Value, Variant SecondValue, int Connector);

  /** @com.method(vtoffset=9, dispid=6, type=METHOD, name="Remove", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index) */
  public void Remove(int Index);

  /** @com.method(vtoffset=10, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0334, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
