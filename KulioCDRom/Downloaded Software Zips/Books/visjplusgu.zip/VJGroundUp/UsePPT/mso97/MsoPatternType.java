//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoPatternType

public interface MsoPatternType
{
  public static final int msoPatternMixed = -2;
  public static final int msoPattern5Percent = 1;
  public static final int msoPattern10Percent = 2;
  public static final int msoPattern20Percent = 3;
  public static final int msoPattern25Percent = 4;
  public static final int msoPattern30Percent = 5;
  public static final int msoPattern40Percent = 6;
  public static final int msoPattern50Percent = 7;
  public static final int msoPattern60Percent = 8;
  public static final int msoPattern70Percent = 9;
  public static final int msoPattern75Percent = 10;
  public static final int msoPattern80Percent = 11;
  public static final int msoPattern90Percent = 12;
  public static final int msoPatternDarkHorizontal = 13;
  public static final int msoPatternDarkVertical = 14;
  public static final int msoPatternDarkDownwardDiagonal = 15;
  public static final int msoPatternDarkUpwardDiagonal = 16;
  public static final int msoPatternSmallCheckerBoard = 17;
  public static final int msoPatternTrellis = 18;
  public static final int msoPatternLightHorizontal = 19;
  public static final int msoPatternLightVertical = 20;
  public static final int msoPatternLightDownwardDiagonal = 21;
  public static final int msoPatternLightUpwardDiagonal = 22;
  public static final int msoPatternSmallGrid = 23;
  public static final int msoPatternDottedDiamond = 24;
  public static final int msoPatternWideDownwardDiagonal = 25;
  public static final int msoPatternWideUpwardDiagonal = 26;
  public static final int msoPatternDashedUpwardDiagonal = 27;
  public static final int msoPatternDashedDownwardDiagonal = 28;
  public static final int msoPatternNarrowVertical = 29;
  public static final int msoPatternNarrowHorizontal = 30;
  public static final int msoPatternDashedVertical = 31;
  public static final int msoPatternDashedHorizontal = 32;
  public static final int msoPatternLargeConfetti = 33;
  public static final int msoPatternLargeGrid = 34;
  public static final int msoPatternHorizontalBrick = 35;
  public static final int msoPatternLargeCheckerBoard = 36;
  public static final int msoPatternSmallConfetti = 37;
  public static final int msoPatternZigZag = 38;
  public static final int msoPatternSolidDiamond = 39;
  public static final int msoPatternDiagonalBrick = 40;
  public static final int msoPatternOutlinedDiamond = 41;
  public static final int msoPatternPlaid = 42;
  public static final int msoPatternSphere = 43;
  public static final int msoPatternWeave = 44;
  public static final int msoPatternDottedGrid = 45;
  public static final int msoPatternDivot = 46;
  public static final int msoPatternShingle = 47;
  public static final int msoPatternWave = 48;
}
