//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoButtonSetType

public interface MsoButtonSetType
{
  public static final int msoButtonSetNone = 0;
  public static final int msoButtonSetOK = 1;
  public static final int msoButtonSetCancel = 2;
  public static final int msoButtonSetOkCancel = 3;
  public static final int msoButtonSetYesNo = 4;
  public static final int msoButtonSetYesNoCancel = 5;
  public static final int msoButtonSetBackClose = 6;
  public static final int msoButtonSetNextClose = 7;
  public static final int msoButtonSetBackNextClose = 8;
  public static final int msoButtonSetRetryCancel = 9;
  public static final int msoButtonSetAbortRetryIgnore = 10;
  public static final int msoButtonSetSearchClose = 11;
  public static final int msoButtonSetBackNextSnooze = 12;
  public static final int msoButtonSetTipsOptionsClose = 13;
  public static final int msoButtonSetYesAllNoCancel = 14;
}
