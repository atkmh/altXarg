//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoBalloonButtonType

public interface MsoBalloonButtonType
{
  public static final int msoBalloonButtonYesToAll = -15;
  public static final int msoBalloonButtonOptions = -14;
  public static final int msoBalloonButtonTips = -13;
  public static final int msoBalloonButtonClose = -12;
  public static final int msoBalloonButtonSnooze = -11;
  public static final int msoBalloonButtonSearch = -10;
  public static final int msoBalloonButtonIgnore = -9;
  public static final int msoBalloonButtonAbort = -8;
  public static final int msoBalloonButtonRetry = -7;
  public static final int msoBalloonButtonNext = -6;
  public static final int msoBalloonButtonBack = -5;
  public static final int msoBalloonButtonNo = -4;
  public static final int msoBalloonButtonYes = -3;
  public static final int msoBalloonButtonCancel = -2;
  public static final int msoBalloonButtonOK = -1;
  public static final int msoBalloonButtonNull = 0;
}
