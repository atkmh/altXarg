//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface ShapeNodes
/** @com.interface(iid=000C0319-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface ShapeNodes extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=2, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=8, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Index, [iid=000C0318-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ShapeNode Item(Variant Index);

  /** @com.method(vtoffset=9, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=10, dispid=11, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index) */
  public void Delete(int Index);

  /** @com.method(vtoffset=11, dispid=12, type=METHOD, name="Insert", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index, [in,type=I4] SegmentType, [in,type=I4] EditingType, [in,type=R4] X1, [in,type=R4] Y1, [in,type=R4] X2, [in,type=R4] Y2, [in,type=R4] X3, [in,type=R4] Y3) */
  public void Insert(int Index, int SegmentType, int EditingType, float X1, float Y1, float X2, float Y2, float X3, float Y3);

  /** @com.method(vtoffset=12, dispid=13, type=METHOD, name="SetEditingType", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index, [in,type=I4] EditingType) */
  public void SetEditingType(int Index, int EditingType);

  /** @com.method(vtoffset=13, dispid=14, type=METHOD, name="SetPosition", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index, [in,type=R4] X1, [in,type=R4] Y1) */
  public void SetPosition(int Index, float X1, float Y1);

  /** @com.method(vtoffset=14, dispid=15, type=METHOD, name="SetSegmentType", addFlagsVtable=4)
      @com.parameters([in,type=I4] Index, [in,type=I4] SegmentType) */
  public void SetSegmentType(int Index, int SegmentType);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0319, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
