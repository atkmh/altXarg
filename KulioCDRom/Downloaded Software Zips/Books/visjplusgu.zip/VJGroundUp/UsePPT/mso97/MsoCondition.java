//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoCondition

public interface MsoCondition
{
  public static final int msoConditionFileTypeAllFiles = 1;
  public static final int msoConditionFileTypeOfficeFiles = 2;
  public static final int msoConditionFileTypeWordDocuments = 3;
  public static final int msoConditionFileTypeExcelWorkbooks = 4;
  public static final int msoConditionFileTypePowerPointPresentations = 5;
  public static final int msoConditionFileTypeBinders = 6;
  public static final int msoConditionFileTypeDatabases = 7;
  public static final int msoConditionFileTypeTemplates = 8;
  public static final int msoConditionIncludes = 9;
  public static final int msoConditionIncludesPhrase = 10;
  public static final int msoConditionBeginsWith = 11;
  public static final int msoConditionEndsWith = 12;
  public static final int msoConditionIncludesNearEachOther = 13;
  public static final int msoConditionIsExactly = 14;
  public static final int msoConditionIsNot = 15;
  public static final int msoConditionYesterday = 16;
  public static final int msoConditionToday = 17;
  public static final int msoConditionTomorrow = 18;
  public static final int msoConditionLastWeek = 19;
  public static final int msoConditionThisWeek = 20;
  public static final int msoConditionNextWeek = 21;
  public static final int msoConditionLastMonth = 22;
  public static final int msoConditionThisMonth = 23;
  public static final int msoConditionNextMonth = 24;
  public static final int msoConditionAnytime = 25;
  public static final int msoConditionAnytimeBetween = 26;
  public static final int msoConditionOn = 27;
  public static final int msoConditionOnOrAfter = 28;
  public static final int msoConditionOnOrBefore = 29;
  public static final int msoConditionInTheNext = 30;
  public static final int msoConditionInTheLast = 31;
  public static final int msoConditionEquals = 32;
  public static final int msoConditionDoesNotEqual = 33;
  public static final int msoConditionAnyNumberBetween = 34;
  public static final int msoConditionAtMost = 35;
  public static final int msoConditionAtLeast = 36;
  public static final int msoConditionMoreThan = 37;
  public static final int msoConditionLessThan = 38;
  public static final int msoConditionIsYes = 39;
  public static final int msoConditionIsNo = 40;
}
