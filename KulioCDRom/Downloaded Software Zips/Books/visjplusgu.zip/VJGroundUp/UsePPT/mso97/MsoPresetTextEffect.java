//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoPresetTextEffect

public interface MsoPresetTextEffect
{
  public static final int msoTextEffectMixed = -2;
  public static final int msoTextEffect1 = 0;
  public static final int msoTextEffect2 = 1;
  public static final int msoTextEffect3 = 2;
  public static final int msoTextEffect4 = 3;
  public static final int msoTextEffect5 = 4;
  public static final int msoTextEffect6 = 5;
  public static final int msoTextEffect7 = 6;
  public static final int msoTextEffect8 = 7;
  public static final int msoTextEffect9 = 8;
  public static final int msoTextEffect10 = 9;
  public static final int msoTextEffect11 = 10;
  public static final int msoTextEffect12 = 11;
  public static final int msoTextEffect13 = 12;
  public static final int msoTextEffect14 = 13;
  public static final int msoTextEffect15 = 14;
  public static final int msoTextEffect16 = 15;
  public static final int msoTextEffect17 = 16;
  public static final int msoTextEffect18 = 17;
  public static final int msoTextEffect19 = 18;
  public static final int msoTextEffect20 = 19;
  public static final int msoTextEffect21 = 20;
  public static final int msoTextEffect22 = 21;
  public static final int msoTextEffect23 = 22;
  public static final int msoTextEffect24 = 23;
  public static final int msoTextEffect25 = 24;
  public static final int msoTextEffect26 = 25;
  public static final int msoTextEffect27 = 26;
  public static final int msoTextEffect28 = 27;
  public static final int msoTextEffect29 = 28;
  public static final int msoTextEffect30 = 29;
}
