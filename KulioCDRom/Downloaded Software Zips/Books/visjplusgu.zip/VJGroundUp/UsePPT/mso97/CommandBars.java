//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface CommandBars
/** @com.interface(iid=000C0302-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface CommandBars extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1610809344, type=PROPGET, name="ActionControl", addFlagsVtable=4)
      @com.parameters([iid=000C0308-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBarControl getActionControl();

  /** @com.method(vtoffset=7, dispid=1610809345, type=PROPGET, name="ActiveMenuBar", addFlagsVtable=4)
      @com.parameters([iid=000C0304-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBar getActiveMenuBar();

  /** @com.method(vtoffset=8, dispid=1610809346, type=METHOD, name="Add", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Name, [in,type=VARIANT] Position, [in,type=VARIANT] MenuBar, [in,type=VARIANT] Temporary, [iid=000C0304-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBar Add(Variant Name, Variant Position, Variant MenuBar, Variant Temporary);

  /** @com.method(vtoffset=9, dispid=1610809347, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=10, dispid=1610809348, type=PROPGET, name="DisplayTooltips", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getDisplayTooltips();

  /** @com.method(vtoffset=11, dispid=1610809348, type=PROPPUT, name="DisplayTooltips", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfDisplayTooltips) */
  public void setDisplayTooltips(boolean pvarfDisplayTooltips);

  /** @com.method(vtoffset=12, dispid=1610809350, type=PROPGET, name="DisplayKeysInTooltips", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getDisplayKeysInTooltips();

  /** @com.method(vtoffset=13, dispid=1610809350, type=PROPPUT, name="DisplayKeysInTooltips", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfDisplayKeys) */
  public void setDisplayKeysInTooltips(boolean pvarfDisplayKeys);

  /** @com.method(vtoffset=14, dispid=1610809352, type=METHOD, name="FindControl", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Type, [in,type=VARIANT] Id, [in,type=VARIANT] Tag, [in,type=VARIANT] Visible, [iid=000C0308-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBarControl FindControl(Variant Type, Variant Id, Variant Tag, Variant Visible);

  /** @com.method(vtoffset=15, dispid=0, type=PROPGET, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Index, [iid=000C0304-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBar getItem(Variant Index);

  /** @com.method(vtoffset=16, dispid=1610809354, type=PROPGET, name="LargeButtons", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getLargeButtons();

  /** @com.method(vtoffset=17, dispid=1610809354, type=PROPPUT, name="LargeButtons", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfLargeButtons) */
  public void setLargeButtons(boolean pvarfLargeButtons);

  /** @com.method(vtoffset=18, dispid=1610809356, type=PROPGET, name="MenuAnimationStyle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getMenuAnimationStyle();

  /** @com.method(vtoffset=19, dispid=1610809356, type=PROPPUT, name="MenuAnimationStyle", addFlagsVtable=4)
      @com.parameters([in,type=I4] pma) */
  public void setMenuAnimationStyle(int pma);

  /** @com.method(vtoffset=20, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=21, dispid=1610809359, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=22, dispid=1610809360, type=METHOD, name="ReleaseFocus", addFlagsVtable=4)
      @com.parameters() */
  public void ReleaseFocus();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0302, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
