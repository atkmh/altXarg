//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface Assistant
/** @com.interface(iid=000C0322-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Assistant extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1610809344, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=1610809345, type=METHOD, name="Move", addFlagsVtable=4)
      @com.parameters([in,type=I4] xLeft, [in,type=I4] yTop) */
  public void Move(int xLeft, int yTop);

  /** @com.method(vtoffset=8, dispid=1610809346, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=I4] pyTop) */
  public void setTop(int pyTop);

  /** @com.method(vtoffset=9, dispid=1610809346, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTop();

  /** @com.method(vtoffset=10, dispid=1610809348, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=I4] pxLeft) */
  public void setLeft(int pxLeft);

  /** @com.method(vtoffset=11, dispid=1610809348, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLeft();

  /** @com.method(vtoffset=12, dispid=1610809350, type=METHOD, name="Help", addFlagsVtable=4)
      @com.parameters() */
  public void Help();

  /** @com.method(vtoffset=13, dispid=1610809351, type=METHOD, name="StartWizard", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] On, [in,type=STRING] Callback, [in,type=I4] PrivateX, [in,type=VARIANT] Animation, [in,type=VARIANT] CustomTeaser, [in,type=VARIANT] Top, [in,type=VARIANT] Left, [in,type=VARIANT] Bottom, [in,type=VARIANT] Right, [type=I4] return) */
  public int StartWizard(boolean On, String Callback, int PrivateX, Variant Animation, Variant CustomTeaser, Variant Top, Variant Left, Variant Bottom, Variant Right);

  /** @com.method(vtoffset=14, dispid=1610809352, type=METHOD, name="EndWizard", addFlagsVtable=4)
      @com.parameters([in,type=I4] WizardID, [in,type=BOOLEAN] varfSuccess, [in,type=VARIANT] Animation) */
  public void EndWizard(int WizardID, boolean varfSuccess, Variant Animation);

  /** @com.method(vtoffset=15, dispid=1610809353, type=METHOD, name="ActivateWizard", addFlagsVtable=4)
      @com.parameters([in,type=I4] WizardID, [in,type=I4] act, [in,type=VARIANT] Animation) */
  public void ActivateWizard(int WizardID, int act, Variant Animation);

  /** @com.method(vtoffset=16, dispid=1610809354, type=METHOD, name="ResetTips", addFlagsVtable=4)
      @com.parameters() */
  public void ResetTips();

  /** @com.method(vtoffset=17, dispid=1610809355, type=PROPGET, name="NewBalloon", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getNewBalloon();

  /** @com.method(vtoffset=18, dispid=1610809356, type=PROPGET, name="BalloonError", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBalloonError();

  /** @com.method(vtoffset=19, dispid=1610809357, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getVisible();

  /** @com.method(vtoffset=20, dispid=1610809357, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfVisible) */
  public void setVisible(boolean pvarfVisible);

  /** @com.method(vtoffset=21, dispid=1610809359, type=PROPGET, name="Animation", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimation();

  /** @com.method(vtoffset=22, dispid=1610809359, type=PROPPUT, name="Animation", addFlagsVtable=4)
      @com.parameters([in,type=I4] pfca) */
  public void setAnimation(int pfca);

  /** @com.method(vtoffset=23, dispid=1610809361, type=PROPGET, name="Reduced", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getReduced();

  /** @com.method(vtoffset=24, dispid=1610809361, type=PROPPUT, name="Reduced", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfReduced) */
  public void setReduced(boolean pvarfReduced);

  /** @com.method(vtoffset=25, dispid=1610809363, type=PROPPUT, name="AssistWithHelp", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfAssistWithHelp) */
  public void setAssistWithHelp(boolean pvarfAssistWithHelp);

  /** @com.method(vtoffset=26, dispid=1610809363, type=PROPGET, name="AssistWithHelp", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getAssistWithHelp();

  /** @com.method(vtoffset=27, dispid=1610809365, type=PROPPUT, name="AssistWithWizards", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfAssistWithWizards) */
  public void setAssistWithWizards(boolean pvarfAssistWithWizards);

  /** @com.method(vtoffset=28, dispid=1610809365, type=PROPGET, name="AssistWithWizards", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getAssistWithWizards();

  /** @com.method(vtoffset=29, dispid=1610809367, type=PROPPUT, name="AssistWithAlerts", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfAssistWithAlerts) */
  public void setAssistWithAlerts(boolean pvarfAssistWithAlerts);

  /** @com.method(vtoffset=30, dispid=1610809367, type=PROPGET, name="AssistWithAlerts", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getAssistWithAlerts();

  /** @com.method(vtoffset=31, dispid=1610809369, type=PROPPUT, name="MoveWhenInTheWay", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfMove) */
  public void setMoveWhenInTheWay(boolean pvarfMove);

  /** @com.method(vtoffset=32, dispid=1610809369, type=PROPGET, name="MoveWhenInTheWay", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getMoveWhenInTheWay();

  /** @com.method(vtoffset=33, dispid=1610809371, type=PROPPUT, name="Sounds", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfSounds) */
  public void setSounds(boolean pvarfSounds);

  /** @com.method(vtoffset=34, dispid=1610809371, type=PROPGET, name="Sounds", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getSounds();

  /** @com.method(vtoffset=35, dispid=1610809373, type=PROPPUT, name="FeatureTips", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfFeatures) */
  public void setFeatureTips(boolean pvarfFeatures);

  /** @com.method(vtoffset=36, dispid=1610809373, type=PROPGET, name="FeatureTips", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getFeatureTips();

  /** @com.method(vtoffset=37, dispid=1610809375, type=PROPPUT, name="MouseTips", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfMouse) */
  public void setMouseTips(boolean pvarfMouse);

  /** @com.method(vtoffset=38, dispid=1610809375, type=PROPGET, name="MouseTips", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getMouseTips();

  /** @com.method(vtoffset=39, dispid=1610809377, type=PROPPUT, name="KeyboardShortcutTips", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfKeyboardShortcuts) */
  public void setKeyboardShortcutTips(boolean pvarfKeyboardShortcuts);

  /** @com.method(vtoffset=40, dispid=1610809377, type=PROPGET, name="KeyboardShortcutTips", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getKeyboardShortcutTips();

  /** @com.method(vtoffset=41, dispid=1610809379, type=PROPPUT, name="HighPriorityTips", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfHighPriorityTips) */
  public void setHighPriorityTips(boolean pvarfHighPriorityTips);

  /** @com.method(vtoffset=42, dispid=1610809379, type=PROPGET, name="HighPriorityTips", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getHighPriorityTips();

  /** @com.method(vtoffset=43, dispid=1610809381, type=PROPPUT, name="TipOfDay", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfTipOfDay) */
  public void setTipOfDay(boolean pvarfTipOfDay);

  /** @com.method(vtoffset=44, dispid=1610809381, type=PROPGET, name="TipOfDay", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getTipOfDay();

  /** @com.method(vtoffset=45, dispid=1610809383, type=PROPPUT, name="GuessHelp", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfGuessHelp) */
  public void setGuessHelp(boolean pvarfGuessHelp);

  /** @com.method(vtoffset=46, dispid=1610809383, type=PROPGET, name="GuessHelp", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getGuessHelp();

  /** @com.method(vtoffset=47, dispid=1610809385, type=PROPPUT, name="SearchWhenProgramming", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfSearchInProgram) */
  public void setSearchWhenProgramming(boolean pvarfSearchInProgram);

  /** @com.method(vtoffset=48, dispid=1610809385, type=PROPGET, name="SearchWhenProgramming", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getSearchWhenProgramming();

  /** @com.method(vtoffset=49, dispid=0, type=PROPGET, name="Item", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getItem();

  /** @com.method(vtoffset=50, dispid=1610809388, type=PROPGET, name="FileName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getFileName();

  /** @com.method(vtoffset=51, dispid=1610809388, type=PROPPUT, name="FileName", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setFileName(String pbstr);

  /** @com.method(vtoffset=52, dispid=1610809390, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0322, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
