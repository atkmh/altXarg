//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoControlType

public interface MsoControlType
{
  public static final int msoControlCustom = 0;
  public static final int msoControlButton = 1;
  public static final int msoControlEdit = 2;
  public static final int msoControlDropdown = 3;
  public static final int msoControlComboBox = 4;
  public static final int msoControlButtonDropdown = 5;
  public static final int msoControlSplitDropdown = 6;
  public static final int msoControlOCXDropdown = 7;
  public static final int msoControlGenericDropdown = 8;
  public static final int msoControlGraphicDropdown = 9;
  public static final int msoControlPopup = 10;
  public static final int msoControlGraphicPopup = 11;
  public static final int msoControlButtonPopup = 12;
  public static final int msoControlSplitButtonPopup = 13;
  public static final int msoControlSplitButtonMRUPopup = 14;
  public static final int msoControlLabel = 15;
  public static final int msoControlExpandingGrid = 16;
  public static final int msoControlSplitExpandingGrid = 17;
  public static final int msoControlGrid = 18;
  public static final int msoControlGauge = 19;
  public static final int msoControlGraphicCombo = 20;
}
