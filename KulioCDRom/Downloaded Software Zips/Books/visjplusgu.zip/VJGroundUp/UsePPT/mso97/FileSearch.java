//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface FileSearch
/** @com.interface(iid=000C0332-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface FileSearch extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="SearchSubFolders", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getSearchSubFolders();

  /** @com.method(vtoffset=7, dispid=1, type=PROPPUT, name="SearchSubFolders", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] SearchSubFoldersRetVal) */
  public void setSearchSubFolders(boolean SearchSubFoldersRetVal);

  /** @com.method(vtoffset=8, dispid=2, type=PROPGET, name="MatchTextExactly", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getMatchTextExactly();

  /** @com.method(vtoffset=9, dispid=2, type=PROPPUT, name="MatchTextExactly", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] MatchTextRetVal) */
  public void setMatchTextExactly(boolean MatchTextRetVal);

  /** @com.method(vtoffset=10, dispid=3, type=PROPGET, name="MatchAllWordForms", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getMatchAllWordForms();

  /** @com.method(vtoffset=11, dispid=3, type=PROPPUT, name="MatchAllWordForms", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] MatchAllWordFormsRetVal) */
  public void setMatchAllWordForms(boolean MatchAllWordFormsRetVal);

  /** @com.method(vtoffset=12, dispid=4, type=PROPGET, name="FileName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getFileName();

  /** @com.method(vtoffset=13, dispid=4, type=PROPPUT, name="FileName", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileNameRetVal) */
  public void setFileName(String FileNameRetVal);

  /** @com.method(vtoffset=14, dispid=5, type=PROPGET, name="FileType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFileType();

  /** @com.method(vtoffset=15, dispid=5, type=PROPPUT, name="FileType", addFlagsVtable=4)
      @com.parameters([in,type=I4] FileTypeRetVal) */
  public void setFileType(int FileTypeRetVal);

  /** @com.method(vtoffset=16, dispid=6, type=PROPGET, name="LastModified", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLastModified();

  /** @com.method(vtoffset=17, dispid=6, type=PROPPUT, name="LastModified", addFlagsVtable=4)
      @com.parameters([in,type=I4] LastModifiedRetVal) */
  public void setLastModified(int LastModifiedRetVal);

  /** @com.method(vtoffset=18, dispid=7, type=PROPGET, name="TextOrProperty", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getTextOrProperty();

  /** @com.method(vtoffset=19, dispid=7, type=PROPPUT, name="TextOrProperty", addFlagsVtable=4)
      @com.parameters([in,type=STRING] TextOrProperty) */
  public void setTextOrProperty(String TextOrProperty);

  /** @com.method(vtoffset=20, dispid=8, type=PROPGET, name="LookIn", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getLookIn();

  /** @com.method(vtoffset=21, dispid=8, type=PROPPUT, name="LookIn", addFlagsVtable=4)
      @com.parameters([in,type=STRING] LookInRetVal) */
  public void setLookIn(String LookInRetVal);

  /** @com.method(vtoffset=22, dispid=9, type=METHOD, name="Execute", addFlagsVtable=4)
      @com.parameters([in,type=I4] SortBy, [in,type=I4] SortOrder, [in,type=BOOLEAN] AlwaysAccurate, [type=I4] return) */
  public int Execute(int SortBy, int SortOrder, boolean AlwaysAccurate);

  /** @com.method(vtoffset=23, dispid=10, type=METHOD, name="NewSearch", addFlagsVtable=4)
      @com.parameters() */
  public void NewSearch();

  /** @com.method(vtoffset=24, dispid=11, type=PROPGET, name="FoundFiles", addFlagsVtable=4)
      @com.parameters([iid=000C0331-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.FoundFiles getFoundFiles();

  /** @com.method(vtoffset=25, dispid=12, type=PROPGET, name="PropertyTests", addFlagsVtable=4)
      @com.parameters([iid=000C0334-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.PropertyTests getPropertyTests();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0332, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
