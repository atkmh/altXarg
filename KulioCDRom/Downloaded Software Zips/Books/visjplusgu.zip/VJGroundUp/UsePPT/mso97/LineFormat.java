//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface LineFormat
/** @com.interface(iid=000C0317-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface LineFormat extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=100, type=PROPGET, name="BackColor", addFlagsVtable=4)
      @com.parameters([iid=000C0312-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ColorFormat getBackColor();

  /** @com.method(vtoffset=8, dispid=100, type=PROPPUT, name="BackColor", addFlagsVtable=4)
      @com.parameters([in,iid=000C0312-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] BackColor) */
  public void setBackColor(mso97.ColorFormat BackColor);

  /** @com.method(vtoffset=9, dispid=101, type=PROPGET, name="BeginArrowheadLength", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBeginArrowheadLength();

  /** @com.method(vtoffset=10, dispid=101, type=PROPPUT, name="BeginArrowheadLength", addFlagsVtable=4)
      @com.parameters([in,type=I4] BeginArrowheadLength) */
  public void setBeginArrowheadLength(int BeginArrowheadLength);

  /** @com.method(vtoffset=11, dispid=102, type=PROPGET, name="BeginArrowheadStyle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBeginArrowheadStyle();

  /** @com.method(vtoffset=12, dispid=102, type=PROPPUT, name="BeginArrowheadStyle", addFlagsVtable=4)
      @com.parameters([in,type=I4] BeginArrowheadStyle) */
  public void setBeginArrowheadStyle(int BeginArrowheadStyle);

  /** @com.method(vtoffset=13, dispid=103, type=PROPGET, name="BeginArrowheadWidth", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBeginArrowheadWidth();

  /** @com.method(vtoffset=14, dispid=103, type=PROPPUT, name="BeginArrowheadWidth", addFlagsVtable=4)
      @com.parameters([in,type=I4] BeginArrowheadWidth) */
  public void setBeginArrowheadWidth(int BeginArrowheadWidth);

  /** @com.method(vtoffset=15, dispid=104, type=PROPGET, name="DashStyle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getDashStyle();

  /** @com.method(vtoffset=16, dispid=104, type=PROPPUT, name="DashStyle", addFlagsVtable=4)
      @com.parameters([in,type=I4] DashStyle) */
  public void setDashStyle(int DashStyle);

  /** @com.method(vtoffset=17, dispid=105, type=PROPGET, name="EndArrowheadLength", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEndArrowheadLength();

  /** @com.method(vtoffset=18, dispid=105, type=PROPPUT, name="EndArrowheadLength", addFlagsVtable=4)
      @com.parameters([in,type=I4] EndArrowheadLength) */
  public void setEndArrowheadLength(int EndArrowheadLength);

  /** @com.method(vtoffset=19, dispid=106, type=PROPGET, name="EndArrowheadStyle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEndArrowheadStyle();

  /** @com.method(vtoffset=20, dispid=106, type=PROPPUT, name="EndArrowheadStyle", addFlagsVtable=4)
      @com.parameters([in,type=I4] EndArrowheadStyle) */
  public void setEndArrowheadStyle(int EndArrowheadStyle);

  /** @com.method(vtoffset=21, dispid=107, type=PROPGET, name="EndArrowheadWidth", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEndArrowheadWidth();

  /** @com.method(vtoffset=22, dispid=107, type=PROPPUT, name="EndArrowheadWidth", addFlagsVtable=4)
      @com.parameters([in,type=I4] EndArrowheadWidth) */
  public void setEndArrowheadWidth(int EndArrowheadWidth);

  /** @com.method(vtoffset=23, dispid=108, type=PROPGET, name="ForeColor", addFlagsVtable=4)
      @com.parameters([iid=000C0312-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ColorFormat getForeColor();

  /** @com.method(vtoffset=24, dispid=108, type=PROPPUT, name="ForeColor", addFlagsVtable=4)
      @com.parameters([in,iid=000C0312-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] ForeColor) */
  public void setForeColor(mso97.ColorFormat ForeColor);

  /** @com.method(vtoffset=25, dispid=109, type=PROPGET, name="Pattern", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPattern();

  /** @com.method(vtoffset=26, dispid=109, type=PROPPUT, name="Pattern", addFlagsVtable=4)
      @com.parameters([in,type=I4] Pattern) */
  public void setPattern(int Pattern);

  /** @com.method(vtoffset=27, dispid=110, type=PROPGET, name="Style", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getStyle();

  /** @com.method(vtoffset=28, dispid=110, type=PROPPUT, name="Style", addFlagsVtable=4)
      @com.parameters([in,type=I4] Style) */
  public void setStyle(int Style);

  /** @com.method(vtoffset=29, dispid=111, type=PROPGET, name="Transparency", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTransparency();

  /** @com.method(vtoffset=30, dispid=111, type=PROPPUT, name="Transparency", addFlagsVtable=4)
      @com.parameters([in,type=R4] Transparency) */
  public void setTransparency(float Transparency);

  /** @com.method(vtoffset=31, dispid=112, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=32, dispid=112, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=33, dispid=113, type=PROPGET, name="Weight", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWeight();

  /** @com.method(vtoffset=34, dispid=113, type=PROPPUT, name="Weight", addFlagsVtable=4)
      @com.parameters([in,type=R4] Weight) */
  public void setWeight(float Weight);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0317, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
