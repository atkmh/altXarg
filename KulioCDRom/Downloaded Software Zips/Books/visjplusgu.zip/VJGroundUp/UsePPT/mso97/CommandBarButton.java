//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface CommandBarButton
/** @com.interface(iid=000C030E-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface CommandBarButton extends mso97.CommandBarControl
{
  /** @com.method(vtoffset=4, dispid=4294962296, type=PROPGET, name="accParent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getAccParent();

  /** @com.method(vtoffset=5, dispid=4294962295, type=PROPGET, name="accChildCount", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAccChildCount();

  /** @com.method(vtoffset=6, dispid=4294962294, type=PROPGET, name="accChild", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getAccChild(Variant varChild);

  /** @com.method(vtoffset=7, dispid=4294962293, type=PROPGET, name="accName", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccName(Variant varChild);

  /** @com.method(vtoffset=8, dispid=4294962292, type=PROPGET, name="accValue", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccValue(Variant varChild);

  /** @com.method(vtoffset=9, dispid=4294962291, type=PROPGET, name="accDescription", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccDescription(Variant varChild);

  /** @com.method(vtoffset=10, dispid=4294962290, type=PROPGET, name="accRole", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=VARIANT] return) */
  public Variant getAccRole(Variant varChild);

  /** @com.method(vtoffset=11, dispid=4294962289, type=PROPGET, name="accState", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=VARIANT] return) */
  public Variant getAccState(Variant varChild);

  /** @com.method(vtoffset=12, dispid=4294962288, type=PROPGET, name="accHelp", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccHelp(Variant varChild);

  /** @com.method(vtoffset=13, dispid=4294962287, type=PROPGET, name="accHelpTopic", addFlagsVtable=4)
      @com.parameters([out,size=1,elementType=STRING,type=ARRAY] pszHelpFile, [in,type=VARIANT] varChild, [type=I4] return) */
  public int getAccHelpTopic(String[] pszHelpFile, Variant varChild);

  /** @com.method(vtoffset=14, dispid=4294962286, type=PROPGET, name="accKeyboardShortcut", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccKeyboardShortcut(Variant varChild);

  /** @com.method(vtoffset=15, dispid=4294962285, type=PROPGET, name="accFocus", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getAccFocus();

  /** @com.method(vtoffset=16, dispid=4294962284, type=PROPGET, name="accSelection", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getAccSelection();

  /** @com.method(vtoffset=17, dispid=4294962283, type=PROPGET, name="accDefaultAction", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccDefaultAction(Variant varChild);

  /** @com.method(vtoffset=18, dispid=4294962282, type=METHOD, name="accSelect", addFlagsVtable=4)
      @com.parameters([in,type=I4] flagsSelect, [in,type=VARIANT] varChild) */
  public void accSelect(int flagsSelect, Variant varChild);

  /** @com.method(vtoffset=19, dispid=4294962281, type=METHOD, name="accLocation", addFlagsVtable=4)
      @com.parameters([out,size=1,elementType=I4,type=ARRAY] pxLeft, [out,size=1,elementType=I4,type=ARRAY] pyTop, [out,size=1,elementType=I4,type=ARRAY] pcxWidth, [out,size=1,elementType=I4,type=ARRAY] pcyHeight, [in,type=VARIANT] varChild) */
  public void accLocation(int[] pxLeft, int[] pyTop, int[] pcxWidth, int[] pcyHeight, Variant varChild);

  /** @com.method(vtoffset=20, dispid=4294962280, type=METHOD, name="accNavigate", addFlagsVtable=4)
      @com.parameters([in,type=I4] navDir, [in,type=VARIANT] varStart, [type=VARIANT] return) */
  public Variant accNavigate(int navDir, Variant varStart);

  /** @com.method(vtoffset=21, dispid=4294962279, type=METHOD, name="accHitTest", addFlagsVtable=4)
      @com.parameters([in,type=I4] xLeft, [in,type=I4] yTop, [type=VARIANT] return) */
  public Variant accHitTest(int xLeft, int yTop);

  /** @com.method(vtoffset=22, dispid=4294962278, type=METHOD, name="accDoDefaultAction", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild) */
  public void accDoDefaultAction(Variant varChild);

  /** @com.method(vtoffset=23, dispid=4294962293, type=PROPPUT, name="accName", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [in,type=STRING] pszName) */
  public void setAccName(Variant varChild, String pszName);

  /** @com.method(vtoffset=24, dispid=4294962292, type=PROPPUT, name="accValue", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [in,type=STRING] pszValue) */
  public void setAccValue(Variant varChild, String pszValue);

  /** @com.method(vtoffset=25, dispid=1610809344, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=26, dispid=1610809345, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=27, dispid=1610874880, type=PROPGET, name="BeginGroup", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getBeginGroup();

  /** @com.method(vtoffset=28, dispid=1610874880, type=PROPPUT, name="BeginGroup", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfBeginGroup) */
  public void setBeginGroup(boolean pvarfBeginGroup);

  /** @com.method(vtoffset=29, dispid=1610874882, type=PROPGET, name="BuiltIn", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getBuiltIn();

  /** @com.method(vtoffset=30, dispid=1610874883, type=PROPGET, name="Caption", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getCaption();

  /** @com.method(vtoffset=31, dispid=1610874883, type=PROPPUT, name="Caption", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrCaption) */
  public void setCaption(String pbstrCaption);

  /** @com.method(vtoffset=32, dispid=1610874885, type=PROPGET, name="Control", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getControl();

  /** @com.method(vtoffset=33, dispid=1610874886, type=METHOD, name="Copy", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Bar, [in,type=VARIANT] Before, [iid=000C0308-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBarControl Copy(Variant Bar, Variant Before);

  /** @com.method(vtoffset=34, dispid=1610874887, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Temporary) */
  public void Delete(Variant Temporary);

  /** @com.method(vtoffset=35, dispid=1610874888, type=PROPGET, name="DescriptionText", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getDescriptionText();

  /** @com.method(vtoffset=36, dispid=1610874888, type=PROPPUT, name="DescriptionText", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrText) */
  public void setDescriptionText(String pbstrText);

  /** @com.method(vtoffset=37, dispid=1610874890, type=PROPGET, name="Enabled", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getEnabled();

  /** @com.method(vtoffset=38, dispid=1610874890, type=PROPPUT, name="Enabled", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfEnabled) */
  public void setEnabled(boolean pvarfEnabled);

  /** @com.method(vtoffset=39, dispid=1610874892, type=METHOD, name="Execute", addFlagsVtable=4)
      @com.parameters() */
  public void Execute();

  /** @com.method(vtoffset=40, dispid=1610874893, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHeight();

  /** @com.method(vtoffset=41, dispid=1610874893, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=I4] pdy) */
  public void setHeight(int pdy);

  /** @com.method(vtoffset=42, dispid=1610874895, type=PROPGET, name="HelpContextId", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHelpContextId();

  /** @com.method(vtoffset=43, dispid=1610874895, type=PROPPUT, name="HelpContextId", addFlagsVtable=4)
      @com.parameters([in,type=I4] pid) */
  public void setHelpContextId(int pid);

  /** @com.method(vtoffset=44, dispid=1610874897, type=PROPGET, name="HelpFile", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getHelpFile();

  /** @com.method(vtoffset=45, dispid=1610874897, type=PROPPUT, name="HelpFile", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrFilename) */
  public void setHelpFile(String pbstrFilename);

  /** @com.method(vtoffset=46, dispid=1610874899, type=PROPGET, name="Id", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getId();

  /** @com.method(vtoffset=47, dispid=1610874900, type=PROPGET, name="Index", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIndex();

  /** @com.method(vtoffset=48, dispid=1610874901, type=PROPGET, name="InstanceId", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getInstanceId();

  /** @com.method(vtoffset=49, dispid=1610874902, type=METHOD, name="Move", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Bar, [in,type=VARIANT] Before, [iid=000C0308-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBarControl Move(Variant Bar, Variant Before);

  /** @com.method(vtoffset=50, dispid=1610874903, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLeft();

  /** @com.method(vtoffset=51, dispid=1610874904, type=PROPGET, name="OLEUsage", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getOLEUsage();

  /** @com.method(vtoffset=52, dispid=1610874904, type=PROPPUT, name="OLEUsage", addFlagsVtable=4)
      @com.parameters([in,type=I4] pcou) */
  public void setOLEUsage(int pcou);

  /** @com.method(vtoffset=53, dispid=1610874906, type=PROPGET, name="OnAction", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getOnAction();

  /** @com.method(vtoffset=54, dispid=1610874906, type=PROPPUT, name="OnAction", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrOnAction) */
  public void setOnAction(String pbstrOnAction);

  /** @com.method(vtoffset=55, dispid=1610874908, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=000C0304-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBar getParent();

  /** @com.method(vtoffset=56, dispid=1610874909, type=PROPGET, name="Parameter", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getParameter();

  /** @com.method(vtoffset=57, dispid=1610874909, type=PROPPUT, name="Parameter", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrParam) */
  public void setParameter(String pbstrParam);

  /** @com.method(vtoffset=58, dispid=1610874911, type=PROPGET, name="Priority", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPriority();

  /** @com.method(vtoffset=59, dispid=1610874911, type=PROPPUT, name="Priority", addFlagsVtable=4)
      @com.parameters([in,type=I4] pnPri) */
  public void setPriority(int pnPri);

  /** @com.method(vtoffset=60, dispid=1610874913, type=METHOD, name="Reset", addFlagsVtable=4)
      @com.parameters() */
  public void Reset();

  /** @com.method(vtoffset=61, dispid=1610874914, type=METHOD, name="SetFocus", addFlagsVtable=4)
      @com.parameters() */
  public void SetFocus();

  /** @com.method(vtoffset=62, dispid=1610874915, type=PROPGET, name="Tag", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getTag();

  /** @com.method(vtoffset=63, dispid=1610874915, type=PROPPUT, name="Tag", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrTag) */
  public void setTag(String pbstrTag);

  /** @com.method(vtoffset=64, dispid=1610874917, type=PROPGET, name="TooltipText", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getTooltipText();

  /** @com.method(vtoffset=65, dispid=1610874917, type=PROPPUT, name="TooltipText", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrTooltip) */
  public void setTooltipText(String pbstrTooltip);

  /** @com.method(vtoffset=66, dispid=1610874919, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTop();

  /** @com.method(vtoffset=67, dispid=1610874920, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=68, dispid=1610874921, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getVisible();

  /** @com.method(vtoffset=69, dispid=1610874921, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfVisible) */
  public void setVisible(boolean pvarfVisible);

  /** @com.method(vtoffset=70, dispid=1610874923, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getWidth();

  /** @com.method(vtoffset=71, dispid=1610874923, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=I4] pdx) */
  public void setWidth(int pdx);

  /** @com.method(vtoffset=72, dispid=1610874925, type=METHOD, name="Reserved1", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved1();

  /** @com.method(vtoffset=73, dispid=1610874926, type=METHOD, name="Reserved2", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved2();

  /** @com.method(vtoffset=74, dispid=1610874927, type=METHOD, name="Reserved3", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved3();

  /** @com.method(vtoffset=75, dispid=1610874928, type=METHOD, name="Reserved4", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved4();

  /** @com.method(vtoffset=76, dispid=1610874929, type=METHOD, name="Reserved5", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved5();

  /** @com.method(vtoffset=77, dispid=1610874930, type=METHOD, name="Reserved6", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved6();

  /** @com.method(vtoffset=78, dispid=1610874931, type=METHOD, name="Reserved7", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved7();

  /** @com.method(vtoffset=79, dispid=1610874932, type=METHOD, name="Reserved8", addFlagsVtable=4)
      @com.parameters() */
  public void Reserved8();

  /** @com.method(vtoffset=80, dispid=1610940416, type=PROPGET, name="BuiltInFace", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getBuiltInFace();

  /** @com.method(vtoffset=81, dispid=1610940416, type=PROPPUT, name="BuiltInFace", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfBuiltIn) */
  public void setBuiltInFace(boolean pvarfBuiltIn);

  /** @com.method(vtoffset=82, dispid=1610940418, type=METHOD, name="CopyFace", addFlagsVtable=4)
      @com.parameters() */
  public void CopyFace();

  /** @com.method(vtoffset=83, dispid=1610940419, type=PROPGET, name="FaceId", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFaceId();

  /** @com.method(vtoffset=84, dispid=1610940419, type=PROPPUT, name="FaceId", addFlagsVtable=4)
      @com.parameters([in,type=I4] pid) */
  public void setFaceId(int pid);

  /** @com.method(vtoffset=85, dispid=1610940421, type=METHOD, name="PasteFace", addFlagsVtable=4)
      @com.parameters() */
  public void PasteFace();

  /** @com.method(vtoffset=86, dispid=1610940422, type=PROPGET, name="ShortcutText", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getShortcutText();

  /** @com.method(vtoffset=87, dispid=1610940422, type=PROPPUT, name="ShortcutText", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrText) */
  public void setShortcutText(String pbstrText);

  /** @com.method(vtoffset=88, dispid=1610940424, type=PROPGET, name="State", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getState();

  /** @com.method(vtoffset=89, dispid=1610940424, type=PROPPUT, name="State", addFlagsVtable=4)
      @com.parameters([in,type=I4] pstate) */
  public void setState(int pstate);

  /** @com.method(vtoffset=90, dispid=1610940426, type=PROPGET, name="Style", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getStyle();

  /** @com.method(vtoffset=91, dispid=1610940426, type=PROPPUT, name="Style", addFlagsVtable=4)
      @com.parameters([in,type=I4] pstyle) */
  public void setStyle(int pstyle);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc030e, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
