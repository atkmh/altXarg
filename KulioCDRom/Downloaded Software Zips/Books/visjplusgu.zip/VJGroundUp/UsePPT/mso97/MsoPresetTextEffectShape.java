//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoPresetTextEffectShape

public interface MsoPresetTextEffectShape
{
  public static final int msoTextEffectShapeMixed = -2;
  public static final int msoTextEffectShapePlainText = 1;
  public static final int msoTextEffectShapeStop = 2;
  public static final int msoTextEffectShapeTriangleUp = 3;
  public static final int msoTextEffectShapeTriangleDown = 4;
  public static final int msoTextEffectShapeChevronUp = 5;
  public static final int msoTextEffectShapeChevronDown = 6;
  public static final int msoTextEffectShapeRingInside = 7;
  public static final int msoTextEffectShapeRingOutside = 8;
  public static final int msoTextEffectShapeArchUpCurve = 9;
  public static final int msoTextEffectShapeArchDownCurve = 10;
  public static final int msoTextEffectShapeCircleCurve = 11;
  public static final int msoTextEffectShapeButtonCurve = 12;
  public static final int msoTextEffectShapeArchUpPour = 13;
  public static final int msoTextEffectShapeArchDownPour = 14;
  public static final int msoTextEffectShapeCirclePour = 15;
  public static final int msoTextEffectShapeButtonPour = 16;
  public static final int msoTextEffectShapeCurveUp = 17;
  public static final int msoTextEffectShapeCurveDown = 18;
  public static final int msoTextEffectShapeCanUp = 19;
  public static final int msoTextEffectShapeCanDown = 20;
  public static final int msoTextEffectShapeWave1 = 21;
  public static final int msoTextEffectShapeWave2 = 22;
  public static final int msoTextEffectShapeDoubleWave1 = 23;
  public static final int msoTextEffectShapeDoubleWave2 = 24;
  public static final int msoTextEffectShapeInflate = 25;
  public static final int msoTextEffectShapeDeflate = 26;
  public static final int msoTextEffectShapeInflateBottom = 27;
  public static final int msoTextEffectShapeDeflateBottom = 28;
  public static final int msoTextEffectShapeInflateTop = 29;
  public static final int msoTextEffectShapeDeflateTop = 30;
  public static final int msoTextEffectShapeDeflateInflate = 31;
  public static final int msoTextEffectShapeDeflateInflateDeflate = 32;
  public static final int msoTextEffectShapeFadeRight = 33;
  public static final int msoTextEffectShapeFadeLeft = 34;
  public static final int msoTextEffectShapeFadeUp = 35;
  public static final int msoTextEffectShapeFadeDown = 36;
  public static final int msoTextEffectShapeSlantUp = 37;
  public static final int msoTextEffectShapeSlantDown = 38;
  public static final int msoTextEffectShapeCascadeUp = 39;
  public static final int msoTextEffectShapeCascadeDown = 40;
}
