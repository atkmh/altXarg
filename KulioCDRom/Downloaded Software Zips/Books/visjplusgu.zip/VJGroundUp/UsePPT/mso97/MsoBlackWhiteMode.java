//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoBlackWhiteMode

public interface MsoBlackWhiteMode
{
  public static final int msoBlackWhiteMixed = -2;
  public static final int msoBlackWhiteAutomatic = 1;
  public static final int msoBlackWhiteGrayScale = 2;
  public static final int msoBlackWhiteLightGrayScale = 3;
  public static final int msoBlackWhiteInverseGrayScale = 4;
  public static final int msoBlackWhiteGrayOutline = 5;
  public static final int msoBlackWhiteBlackTextAndLine = 6;
  public static final int msoBlackWhiteHighContrast = 7;
  public static final int msoBlackWhiteBlack = 8;
  public static final int msoBlackWhiteWhite = 9;
  public static final int msoBlackWhiteDontShow = 10;
}
