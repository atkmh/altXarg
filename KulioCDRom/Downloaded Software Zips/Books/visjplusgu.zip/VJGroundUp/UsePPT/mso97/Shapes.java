//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface Shapes
/** @com.interface(iid=000C031E-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Shapes extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=2, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=8, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Index, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape Item(Variant Index);

  /** @com.method(vtoffset=9, dispid=4294967292, type=PROPGET, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown get_NewEnum();

  /** @com.method(vtoffset=10, dispid=10, type=METHOD, name="AddCallout", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type, [in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddCallout(int Type, float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=11, dispid=11, type=METHOD, name="AddConnector", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type, [in,type=R4] BeginX, [in,type=R4] BeginY, [in,type=R4] EndX, [in,type=R4] EndY, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddConnector(int Type, float BeginX, float BeginY, float EndX, float EndY);

  /** @com.method(vtoffset=12, dispid=12, type=METHOD, name="AddCurve", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] SafeArrayOfPoints, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddCurve(Variant SafeArrayOfPoints);

  /** @com.method(vtoffset=13, dispid=13, type=METHOD, name="AddLabel", addFlagsVtable=4)
      @com.parameters([in,type=I4] Orientation, [in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddLabel(int Orientation, float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=14, dispid=14, type=METHOD, name="AddLine", addFlagsVtable=4)
      @com.parameters([in,type=R4] BeginX, [in,type=R4] BeginY, [in,type=R4] EndX, [in,type=R4] EndY, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddLine(float BeginX, float BeginY, float EndX, float EndY);

  /** @com.method(vtoffset=15, dispid=15, type=METHOD, name="AddPicture", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName, [in,type=I4] LinkToFile, [in,type=I4] SaveWithDocument, [in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddPicture(String FileName, int LinkToFile, int SaveWithDocument, float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=16, dispid=16, type=METHOD, name="AddPolyline", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] SafeArrayOfPoints, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddPolyline(Variant SafeArrayOfPoints);

  /** @com.method(vtoffset=17, dispid=17, type=METHOD, name="AddShape", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type, [in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddShape(int Type, float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=18, dispid=18, type=METHOD, name="AddTextEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetTextEffect, [in,type=STRING] Text, [in,type=STRING] FontName, [in,type=R4] FontSize, [in,type=I4] FontBold, [in,type=I4] FontItalic, [in,type=R4] Left, [in,type=R4] Top, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddTextEffect(int PresetTextEffect, String Text, String FontName, float FontSize, int FontBold, int FontItalic, float Left, float Top);

  /** @com.method(vtoffset=19, dispid=19, type=METHOD, name="AddTextbox", addFlagsVtable=4)
      @com.parameters([in,type=I4] Orientation, [in,type=R4] Left, [in,type=R4] Top, [in,type=R4] Width, [in,type=R4] Height, [iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape AddTextbox(int Orientation, float Left, float Top, float Width, float Height);

  /** @com.method(vtoffset=20, dispid=20, type=METHOD, name="BuildFreeform", addFlagsVtable=4)
      @com.parameters([in,type=I4] EditingType, [in,type=R4] X1, [in,type=R4] Y1, [iid=000C0315-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.FreeformBuilder BuildFreeform(int EditingType, float X1, float Y1);

  /** @com.method(vtoffset=21, dispid=21, type=METHOD, name="Range", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Index, [iid=000C031D-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ShapeRange Range(Variant Index);

  /** @com.method(vtoffset=22, dispid=22, type=METHOD, name="SelectAll", addFlagsVtable=4)
      @com.parameters() */
  public void SelectAll();

  /** @com.method(vtoffset=23, dispid=100, type=PROPGET, name="Background", addFlagsVtable=4)
      @com.parameters([iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape getBackground();

  /** @com.method(vtoffset=24, dispid=101, type=PROPGET, name="Default", addFlagsVtable=4)
      @com.parameters([iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape getDefault();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc031e, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
