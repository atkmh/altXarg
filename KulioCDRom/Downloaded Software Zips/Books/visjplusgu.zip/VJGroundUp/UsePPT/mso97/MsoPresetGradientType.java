//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoPresetGradientType

public interface MsoPresetGradientType
{
  public static final int msoPresetGradientMixed = -2;
  public static final int msoGradientEarlySunset = 1;
  public static final int msoGradientLateSunset = 2;
  public static final int msoGradientNightfall = 3;
  public static final int msoGradientDaybreak = 4;
  public static final int msoGradientHorizon = 5;
  public static final int msoGradientDesert = 6;
  public static final int msoGradientOcean = 7;
  public static final int msoGradientCalmWater = 8;
  public static final int msoGradientFire = 9;
  public static final int msoGradientFog = 10;
  public static final int msoGradientMoss = 11;
  public static final int msoGradientPeacock = 12;
  public static final int msoGradientWheat = 13;
  public static final int msoGradientParchment = 14;
  public static final int msoGradientMahogany = 15;
  public static final int msoGradientRainbow = 16;
  public static final int msoGradientRainbowII = 17;
  public static final int msoGradientGold = 18;
  public static final int msoGradientGoldII = 19;
  public static final int msoGradientBrass = 20;
  public static final int msoGradientChrome = 21;
  public static final int msoGradientChromeII = 22;
  public static final int msoGradientSilver = 23;
  public static final int msoGradientSapphire = 24;
}
