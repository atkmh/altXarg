//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface Shape
/** @com.interface(iid=000C031C-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Shape extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="Apply", addFlagsVtable=4)
      @com.parameters() */
  public void Apply();

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=9, dispid=12, type=METHOD, name="Duplicate", addFlagsVtable=4)
      @com.parameters([iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape Duplicate();

  /** @com.method(vtoffset=10, dispid=13, type=METHOD, name="Flip", addFlagsVtable=4)
      @com.parameters([in,type=I4] FlipCmd) */
  public void Flip(int FlipCmd);

  /** @com.method(vtoffset=11, dispid=14, type=METHOD, name="IncrementLeft", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementLeft(float Increment);

  /** @com.method(vtoffset=12, dispid=15, type=METHOD, name="IncrementRotation", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementRotation(float Increment);

  /** @com.method(vtoffset=13, dispid=16, type=METHOD, name="IncrementTop", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementTop(float Increment);

  /** @com.method(vtoffset=14, dispid=17, type=METHOD, name="PickUp", addFlagsVtable=4)
      @com.parameters() */
  public void PickUp();

  /** @com.method(vtoffset=15, dispid=18, type=METHOD, name="RerouteConnections", addFlagsVtable=4)
      @com.parameters() */
  public void RerouteConnections();

  /** @com.method(vtoffset=16, dispid=19, type=METHOD, name="ScaleHeight", addFlagsVtable=4)
      @com.parameters([in,type=R4] Factor, [in,type=I4] RelativeToOriginalSize, [in,type=I4] fScale) */
  public void ScaleHeight(float Factor, int RelativeToOriginalSize, int fScale);

  /** @com.method(vtoffset=17, dispid=20, type=METHOD, name="ScaleWidth", addFlagsVtable=4)
      @com.parameters([in,type=R4] Factor, [in,type=I4] RelativeToOriginalSize, [in,type=I4] fScale) */
  public void ScaleWidth(float Factor, int RelativeToOriginalSize, int fScale);

  /** @com.method(vtoffset=18, dispid=21, type=METHOD, name="Select", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Replace) */
  public void Select(Variant Replace);

  /** @com.method(vtoffset=19, dispid=22, type=METHOD, name="SetShapesDefaultProperties", addFlagsVtable=4)
      @com.parameters() */
  public void SetShapesDefaultProperties();

  /** @com.method(vtoffset=20, dispid=23, type=METHOD, name="Ungroup", addFlagsVtable=4)
      @com.parameters([iid=000C031D-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ShapeRange Ungroup();

  /** @com.method(vtoffset=21, dispid=24, type=METHOD, name="ZOrder", addFlagsVtable=4)
      @com.parameters([in,type=I4] ZOrderCmd) */
  public void ZOrder(int ZOrderCmd);

  /** @com.method(vtoffset=22, dispid=100, type=PROPGET, name="Adjustments", addFlagsVtable=4)
      @com.parameters([iid=000C0310-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Adjustments getAdjustments();

  /** @com.method(vtoffset=23, dispid=101, type=PROPGET, name="AutoShapeType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAutoShapeType();

  /** @com.method(vtoffset=24, dispid=101, type=PROPPUT, name="AutoShapeType", addFlagsVtable=4)
      @com.parameters([in,type=I4] AutoShapeType) */
  public void setAutoShapeType(int AutoShapeType);

  /** @com.method(vtoffset=25, dispid=102, type=PROPGET, name="BlackWhiteMode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBlackWhiteMode();

  /** @com.method(vtoffset=26, dispid=102, type=PROPPUT, name="BlackWhiteMode", addFlagsVtable=4)
      @com.parameters([in,type=I4] BlackWhiteMode) */
  public void setBlackWhiteMode(int BlackWhiteMode);

  /** @com.method(vtoffset=27, dispid=103, type=PROPGET, name="Callout", addFlagsVtable=4)
      @com.parameters([iid=000C0311-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CalloutFormat getCallout();

  /** @com.method(vtoffset=28, dispid=104, type=PROPGET, name="ConnectionSiteCount", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getConnectionSiteCount();

  /** @com.method(vtoffset=29, dispid=105, type=PROPGET, name="Connector", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getConnector();

  /** @com.method(vtoffset=30, dispid=106, type=PROPGET, name="ConnectorFormat", addFlagsVtable=4)
      @com.parameters([iid=000C0313-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ConnectorFormat getConnectorFormat();

  /** @com.method(vtoffset=31, dispid=107, type=PROPGET, name="Fill", addFlagsVtable=4)
      @com.parameters([iid=000C0314-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.FillFormat getFill();

  /** @com.method(vtoffset=32, dispid=108, type=PROPGET, name="GroupItems", addFlagsVtable=4)
      @com.parameters([iid=000C0316-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.GroupShapes getGroupItems();

  /** @com.method(vtoffset=33, dispid=109, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getHeight();

  /** @com.method(vtoffset=34, dispid=109, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=R4] Height) */
  public void setHeight(float Height);

  /** @com.method(vtoffset=35, dispid=110, type=PROPGET, name="HorizontalFlip", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHorizontalFlip();

  /** @com.method(vtoffset=36, dispid=111, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getLeft();

  /** @com.method(vtoffset=37, dispid=111, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=R4] Left) */
  public void setLeft(float Left);

  /** @com.method(vtoffset=38, dispid=112, type=PROPGET, name="Line", addFlagsVtable=4)
      @com.parameters([iid=000C0317-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.LineFormat getLine();

  /** @com.method(vtoffset=39, dispid=113, type=PROPGET, name="LockAspectRatio", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLockAspectRatio();

  /** @com.method(vtoffset=40, dispid=113, type=PROPPUT, name="LockAspectRatio", addFlagsVtable=4)
      @com.parameters([in,type=I4] LockAspectRatio) */
  public void setLockAspectRatio(int LockAspectRatio);

  /** @com.method(vtoffset=41, dispid=115, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=42, dispid=115, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Name) */
  public void setName(String Name);

  /** @com.method(vtoffset=43, dispid=116, type=PROPGET, name="Nodes", addFlagsVtable=4)
      @com.parameters([iid=000C0319-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ShapeNodes getNodes();

  /** @com.method(vtoffset=44, dispid=117, type=PROPGET, name="Rotation", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getRotation();

  /** @com.method(vtoffset=45, dispid=117, type=PROPPUT, name="Rotation", addFlagsVtable=4)
      @com.parameters([in,type=R4] Rotation) */
  public void setRotation(float Rotation);

  /** @com.method(vtoffset=46, dispid=118, type=PROPGET, name="PictureFormat", addFlagsVtable=4)
      @com.parameters([iid=000C031A-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.PictureFormat getPictureFormat();

  /** @com.method(vtoffset=47, dispid=119, type=PROPGET, name="Shadow", addFlagsVtable=4)
      @com.parameters([iid=000C031B-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ShadowFormat getShadow();

  /** @com.method(vtoffset=48, dispid=120, type=PROPGET, name="TextEffect", addFlagsVtable=4)
      @com.parameters([iid=000C031F-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.TextEffectFormat getTextEffect();

  /** @com.method(vtoffset=49, dispid=121, type=PROPGET, name="TextFrame", addFlagsVtable=4)
      @com.parameters([iid=000C0320-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.TextFrame getTextFrame();

  /** @com.method(vtoffset=50, dispid=122, type=PROPGET, name="ThreeD", addFlagsVtable=4)
      @com.parameters([iid=000C0321-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.ThreeDFormat getThreeD();

  /** @com.method(vtoffset=51, dispid=123, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTop();

  /** @com.method(vtoffset=52, dispid=123, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=R4] Top) */
  public void setTop(float Top);

  /** @com.method(vtoffset=53, dispid=124, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=54, dispid=125, type=PROPGET, name="VerticalFlip", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVerticalFlip();

  /** @com.method(vtoffset=55, dispid=126, type=PROPGET, name="Vertices", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getVertices();

  /** @com.method(vtoffset=56, dispid=127, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getVisible();

  /** @com.method(vtoffset=57, dispid=127, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=I4] Visible) */
  public void setVisible(int Visible);

  /** @com.method(vtoffset=58, dispid=128, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getWidth();

  /** @com.method(vtoffset=59, dispid=128, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=R4] Width) */
  public void setWidth(float Width);

  /** @com.method(vtoffset=60, dispid=129, type=PROPGET, name="ZOrderPosition", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getZOrderPosition();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc031c, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
