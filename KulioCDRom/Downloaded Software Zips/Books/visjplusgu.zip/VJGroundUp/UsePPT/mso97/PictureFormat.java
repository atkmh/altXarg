//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface PictureFormat
/** @com.interface(iid=000C031A-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface PictureFormat extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="IncrementBrightness", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementBrightness(float Increment);

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="IncrementContrast", addFlagsVtable=4)
      @com.parameters([in,type=R4] Increment) */
  public void IncrementContrast(float Increment);

  /** @com.method(vtoffset=9, dispid=100, type=PROPGET, name="Brightness", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getBrightness();

  /** @com.method(vtoffset=10, dispid=100, type=PROPPUT, name="Brightness", addFlagsVtable=4)
      @com.parameters([in,type=R4] Brightness) */
  public void setBrightness(float Brightness);

  /** @com.method(vtoffset=11, dispid=101, type=PROPGET, name="ColorType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getColorType();

  /** @com.method(vtoffset=12, dispid=101, type=PROPPUT, name="ColorType", addFlagsVtable=4)
      @com.parameters([in,type=I4] ColorType) */
  public void setColorType(int ColorType);

  /** @com.method(vtoffset=13, dispid=102, type=PROPGET, name="Contrast", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getContrast();

  /** @com.method(vtoffset=14, dispid=102, type=PROPPUT, name="Contrast", addFlagsVtable=4)
      @com.parameters([in,type=R4] Contrast) */
  public void setContrast(float Contrast);

  /** @com.method(vtoffset=15, dispid=103, type=PROPGET, name="CropBottom", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getCropBottom();

  /** @com.method(vtoffset=16, dispid=103, type=PROPPUT, name="CropBottom", addFlagsVtable=4)
      @com.parameters([in,type=R4] CropBottom) */
  public void setCropBottom(float CropBottom);

  /** @com.method(vtoffset=17, dispid=104, type=PROPGET, name="CropLeft", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getCropLeft();

  /** @com.method(vtoffset=18, dispid=104, type=PROPPUT, name="CropLeft", addFlagsVtable=4)
      @com.parameters([in,type=R4] CropLeft) */
  public void setCropLeft(float CropLeft);

  /** @com.method(vtoffset=19, dispid=105, type=PROPGET, name="CropRight", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getCropRight();

  /** @com.method(vtoffset=20, dispid=105, type=PROPPUT, name="CropRight", addFlagsVtable=4)
      @com.parameters([in,type=R4] CropRight) */
  public void setCropRight(float CropRight);

  /** @com.method(vtoffset=21, dispid=106, type=PROPGET, name="CropTop", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getCropTop();

  /** @com.method(vtoffset=22, dispid=106, type=PROPPUT, name="CropTop", addFlagsVtable=4)
      @com.parameters([in,type=R4] CropTop) */
  public void setCropTop(float CropTop);

  /** @com.method(vtoffset=23, dispid=107, type=PROPGET, name="TransparencyColor", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTransparencyColor();

  /** @com.method(vtoffset=24, dispid=107, type=PROPPUT, name="TransparencyColor", addFlagsVtable=4)
      @com.parameters([in,type=I4] TransparencyColor) */
  public void setTransparencyColor(int TransparencyColor);

  /** @com.method(vtoffset=25, dispid=108, type=PROPGET, name="TransparentBackground", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTransparentBackground();

  /** @com.method(vtoffset=26, dispid=108, type=PROPPUT, name="TransparentBackground", addFlagsVtable=4)
      @com.parameters([in,type=I4] TransparentBackground) */
  public void setTransparentBackground(int TransparentBackground);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc031a, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
