//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface Balloon
/** @com.interface(iid=000C0324-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Balloon extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1610809344, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=1610809345, type=PROPGET, name="Checkboxes", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getCheckboxes();

  /** @com.method(vtoffset=8, dispid=1610809346, type=PROPGET, name="Labels", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getLabels();

  /** @com.method(vtoffset=9, dispid=1610809347, type=PROPPUT, name="BalloonType", addFlagsVtable=4)
      @com.parameters([in,type=I4] pbty) */
  public void setBalloonType(int pbty);

  /** @com.method(vtoffset=10, dispid=1610809347, type=PROPGET, name="BalloonType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBalloonType();

  /** @com.method(vtoffset=11, dispid=1610809349, type=PROPPUT, name="Icon", addFlagsVtable=4)
      @com.parameters([in,type=I4] picn) */
  public void setIcon(int picn);

  /** @com.method(vtoffset=12, dispid=1610809349, type=PROPGET, name="Icon", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIcon();

  /** @com.method(vtoffset=13, dispid=1610809351, type=PROPPUT, name="Heading", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setHeading(String pbstr);

  /** @com.method(vtoffset=14, dispid=1610809351, type=PROPGET, name="Heading", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getHeading();

  /** @com.method(vtoffset=15, dispid=1610809353, type=PROPPUT, name="Text", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setText(String pbstr);

  /** @com.method(vtoffset=16, dispid=1610809353, type=PROPGET, name="Text", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getText();

  /** @com.method(vtoffset=17, dispid=1610809355, type=PROPPUT, name="Mode", addFlagsVtable=4)
      @com.parameters([in,type=I4] pmd) */
  public void setMode(int pmd);

  /** @com.method(vtoffset=18, dispid=1610809355, type=PROPGET, name="Mode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getMode();

  /** @com.method(vtoffset=19, dispid=1610809357, type=PROPPUT, name="Animation", addFlagsVtable=4)
      @com.parameters([in,type=I4] pfca) */
  public void setAnimation(int pfca);

  /** @com.method(vtoffset=20, dispid=1610809357, type=PROPGET, name="Animation", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAnimation();

  /** @com.method(vtoffset=21, dispid=1610809359, type=PROPPUT, name="Button", addFlagsVtable=4)
      @com.parameters([in,type=I4] psbs) */
  public void setButton(int psbs);

  /** @com.method(vtoffset=22, dispid=1610809359, type=PROPGET, name="Button", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getButton();

  /** @com.method(vtoffset=23, dispid=1610809361, type=PROPPUT, name="Callback", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setCallback(String pbstr);

  /** @com.method(vtoffset=24, dispid=1610809361, type=PROPGET, name="Callback", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getCallback();

  /** @com.method(vtoffset=25, dispid=1610809363, type=PROPPUT, name="Private", addFlagsVtable=4)
      @com.parameters([in,type=I4] plPrivate) */
  public void setPrivate(int plPrivate);

  /** @com.method(vtoffset=26, dispid=1610809363, type=PROPGET, name="Private", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPrivate();

  /** @com.method(vtoffset=27, dispid=1610809365, type=METHOD, name="SetAvoidRectangle", addFlagsVtable=4)
      @com.parameters([in,type=I4] Left, [in,type=I4] Top, [in,type=I4] Right, [in,type=I4] Bottom) */
  public void SetAvoidRectangle(int Left, int Top, int Right, int Bottom);

  /** @com.method(vtoffset=28, dispid=1610809366, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=29, dispid=1610809367, type=METHOD, name="Show", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int Show();

  /** @com.method(vtoffset=30, dispid=1610809368, type=METHOD, name="Close", addFlagsVtable=4)
      @com.parameters() */
  public void Close();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0324, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
