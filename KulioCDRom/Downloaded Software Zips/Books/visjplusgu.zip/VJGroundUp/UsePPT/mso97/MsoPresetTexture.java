//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoPresetTexture

public interface MsoPresetTexture
{
  public static final int msoPresetTextureMixed = -2;
  public static final int msoTexturePapyrus = 1;
  public static final int msoTextureCanvas = 2;
  public static final int msoTextureDenim = 3;
  public static final int msoTextureWovenMat = 4;
  public static final int msoTextureWaterDroplets = 5;
  public static final int msoTexturePaperBag = 6;
  public static final int msoTextureFishFossil = 7;
  public static final int msoTextureSand = 8;
  public static final int msoTextureGreenMarble = 9;
  public static final int msoTextureWhiteMarble = 10;
  public static final int msoTextureBrownMarble = 11;
  public static final int msoTextureGranite = 12;
  public static final int msoTextureNewsprint = 13;
  public static final int msoTextureRecycledPaper = 14;
  public static final int msoTextureParchment = 15;
  public static final int msoTextureStationery = 16;
  public static final int msoTextureBlueTissuePaper = 17;
  public static final int msoTexturePinkTissuePaper = 18;
  public static final int msoTexturePurpleMesh = 19;
  public static final int msoTextureBouquet = 20;
  public static final int msoTextureCork = 21;
  public static final int msoTextureWalnut = 22;
  public static final int msoTextureOak = 23;
  public static final int msoTextureMediumWood = 24;
}
