//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface CalloutFormat
/** @com.interface(iid=000C0311-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface CalloutFormat extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="AutomaticLength", addFlagsVtable=4)
      @com.parameters() */
  public void AutomaticLength();

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="CustomDrop", addFlagsVtable=4)
      @com.parameters([in,type=R4] Drop) */
  public void CustomDrop(float Drop);

  /** @com.method(vtoffset=9, dispid=12, type=METHOD, name="CustomLength", addFlagsVtable=4)
      @com.parameters([in,type=R4] Length) */
  public void CustomLength(float Length);

  /** @com.method(vtoffset=10, dispid=13, type=METHOD, name="PresetDrop", addFlagsVtable=4)
      @com.parameters([in,type=I4] DropType) */
  public void PresetDrop(int DropType);

  /** @com.method(vtoffset=11, dispid=100, type=PROPGET, name="Accent", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAccent();

  /** @com.method(vtoffset=12, dispid=100, type=PROPPUT, name="Accent", addFlagsVtable=4)
      @com.parameters([in,type=I4] Accent) */
  public void setAccent(int Accent);

  /** @com.method(vtoffset=13, dispid=101, type=PROPGET, name="Angle", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAngle();

  /** @com.method(vtoffset=14, dispid=101, type=PROPPUT, name="Angle", addFlagsVtable=4)
      @com.parameters([in,type=I4] Angle) */
  public void setAngle(int Angle);

  /** @com.method(vtoffset=15, dispid=102, type=PROPGET, name="AutoAttach", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAutoAttach();

  /** @com.method(vtoffset=16, dispid=102, type=PROPPUT, name="AutoAttach", addFlagsVtable=4)
      @com.parameters([in,type=I4] AutoAttach) */
  public void setAutoAttach(int AutoAttach);

  /** @com.method(vtoffset=17, dispid=103, type=PROPGET, name="AutoLength", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAutoLength();

  /** @com.method(vtoffset=18, dispid=104, type=PROPGET, name="Border", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBorder();

  /** @com.method(vtoffset=19, dispid=104, type=PROPPUT, name="Border", addFlagsVtable=4)
      @com.parameters([in,type=I4] Border) */
  public void setBorder(int Border);

  /** @com.method(vtoffset=20, dispid=105, type=PROPGET, name="Drop", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getDrop();

  /** @com.method(vtoffset=21, dispid=106, type=PROPGET, name="DropType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getDropType();

  /** @com.method(vtoffset=22, dispid=107, type=PROPGET, name="Gap", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getGap();

  /** @com.method(vtoffset=23, dispid=107, type=PROPPUT, name="Gap", addFlagsVtable=4)
      @com.parameters([in,type=R4] Gap) */
  public void setGap(float Gap);

  /** @com.method(vtoffset=24, dispid=108, type=PROPGET, name="Length", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getLength();

  /** @com.method(vtoffset=25, dispid=109, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=26, dispid=109, type=PROPPUT, name="Type", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type) */
  public void setType(int Type);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0311, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
