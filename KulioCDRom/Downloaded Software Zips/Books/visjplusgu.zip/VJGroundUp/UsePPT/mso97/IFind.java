//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface IFind
/** @com.interface(iid=000C0337-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface IFind extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=0, type=PROPGET, name="SearchPath", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getSearchPath();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=6, dispid=1610743810, type=PROPGET, name="SubDir", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getSubDir();

  /** @com.method(vtoffset=7, dispid=1610743811, type=PROPGET, name="Title", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getTitle();

  /** @com.method(vtoffset=8, dispid=1610743812, type=PROPGET, name="Author", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getAuthor();

  /** @com.method(vtoffset=9, dispid=1610743813, type=PROPGET, name="Keywords", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getKeywords();

  /** @com.method(vtoffset=10, dispid=1610743814, type=PROPGET, name="Subject", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getSubject();

  /** @com.method(vtoffset=11, dispid=1610743815, type=PROPGET, name="Options", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getOptions();

  /** @com.method(vtoffset=12, dispid=1610743816, type=PROPGET, name="MatchCase", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getMatchCase();

  /** @com.method(vtoffset=13, dispid=1610743817, type=PROPGET, name="Text", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getText();

  /** @com.method(vtoffset=14, dispid=1610743818, type=PROPGET, name="PatternMatch", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getPatternMatch();

  /** @com.method(vtoffset=15, dispid=1610743819, type=PROPGET, name="DateSavedFrom", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getDateSavedFrom();

  /** @com.method(vtoffset=16, dispid=1610743820, type=PROPGET, name="DateSavedTo", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getDateSavedTo();

  /** @com.method(vtoffset=17, dispid=1610743821, type=PROPGET, name="SavedBy", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getSavedBy();

  /** @com.method(vtoffset=18, dispid=1610743822, type=PROPGET, name="DateCreatedFrom", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getDateCreatedFrom();

  /** @com.method(vtoffset=19, dispid=1610743823, type=PROPGET, name="DateCreatedTo", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getDateCreatedTo();

  /** @com.method(vtoffset=20, dispid=1610743824, type=PROPGET, name="View", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getView();

  /** @com.method(vtoffset=21, dispid=1610743825, type=PROPGET, name="SortBy", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getSortBy();

  /** @com.method(vtoffset=22, dispid=1610743826, type=PROPGET, name="ListBy", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getListBy();

  /** @com.method(vtoffset=23, dispid=1610743827, type=PROPGET, name="SelectedFile", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getSelectedFile();

  /** @com.method(vtoffset=24, dispid=1610743828, type=PROPGET, name="Results", addFlagsVtable=4)
      @com.parameters([iid=000C0338-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.IFoundFiles getResults();

  /** @com.method(vtoffset=25, dispid=1610743829, type=METHOD, name="Show", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int Show();

  /** @com.method(vtoffset=26, dispid=0, type=PROPPUT, name="SearchPath", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setSearchPath(String pbstr);

  /** @com.method(vtoffset=27, dispid=1610743809, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setName(String pbstr);

  /** @com.method(vtoffset=28, dispid=1610743810, type=PROPPUT, name="SubDir", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] retval) */
  public void setSubDir(boolean retval);

  /** @com.method(vtoffset=29, dispid=1610743811, type=PROPPUT, name="Title", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setTitle(String pbstr);

  /** @com.method(vtoffset=30, dispid=1610743812, type=PROPPUT, name="Author", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setAuthor(String pbstr);

  /** @com.method(vtoffset=31, dispid=1610743813, type=PROPPUT, name="Keywords", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setKeywords(String pbstr);

  /** @com.method(vtoffset=32, dispid=1610743814, type=PROPPUT, name="Subject", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setSubject(String pbstr);

  /** @com.method(vtoffset=33, dispid=1610743815, type=PROPPUT, name="Options", addFlagsVtable=4)
      @com.parameters([in,type=I4] penmOptions) */
  public void setOptions(int penmOptions);

  /** @com.method(vtoffset=34, dispid=1610743816, type=PROPPUT, name="MatchCase", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] retval) */
  public void setMatchCase(boolean retval);

  /** @com.method(vtoffset=35, dispid=1610743817, type=PROPPUT, name="Text", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setText(String pbstr);

  /** @com.method(vtoffset=36, dispid=1610743818, type=PROPPUT, name="PatternMatch", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] retval) */
  public void setPatternMatch(boolean retval);

  /** @com.method(vtoffset=37, dispid=1610743819, type=PROPPUT, name="DateSavedFrom", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] pdatSavedFrom) */
  public void setDateSavedFrom(Variant pdatSavedFrom);

  /** @com.method(vtoffset=38, dispid=1610743820, type=PROPPUT, name="DateSavedTo", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] pdatSavedTo) */
  public void setDateSavedTo(Variant pdatSavedTo);

  /** @com.method(vtoffset=39, dispid=1610743821, type=PROPPUT, name="SavedBy", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstr) */
  public void setSavedBy(String pbstr);

  /** @com.method(vtoffset=40, dispid=1610743822, type=PROPPUT, name="DateCreatedFrom", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] pdatCreatedFrom) */
  public void setDateCreatedFrom(Variant pdatCreatedFrom);

  /** @com.method(vtoffset=41, dispid=1610743823, type=PROPPUT, name="DateCreatedTo", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] pdatCreatedTo) */
  public void setDateCreatedTo(Variant pdatCreatedTo);

  /** @com.method(vtoffset=42, dispid=1610743824, type=PROPPUT, name="View", addFlagsVtable=4)
      @com.parameters([in,type=I4] penmView) */
  public void setView(int penmView);

  /** @com.method(vtoffset=43, dispid=1610743825, type=PROPPUT, name="SortBy", addFlagsVtable=4)
      @com.parameters([in,type=I4] penmSortBy) */
  public void setSortBy(int penmSortBy);

  /** @com.method(vtoffset=44, dispid=1610743826, type=PROPPUT, name="ListBy", addFlagsVtable=4)
      @com.parameters([in,type=I4] penmListBy) */
  public void setListBy(int penmListBy);

  /** @com.method(vtoffset=45, dispid=1610743827, type=PROPPUT, name="SelectedFile", addFlagsVtable=4)
      @com.parameters([in,type=I4] pintSelectedFile) */
  public void setSelectedFile(int pintSelectedFile);

  /** @com.method(vtoffset=46, dispid=1610743850, type=METHOD, name="Execute", addFlagsVtable=4)
      @com.parameters() */
  public void Execute();

  /** @com.method(vtoffset=47, dispid=1610743851, type=METHOD, name="Load", addFlagsVtable=4)
      @com.parameters([in,type=STRING] bstrQueryName) */
  public void Load(String bstrQueryName);

  /** @com.method(vtoffset=48, dispid=1610743852, type=METHOD, name="Save", addFlagsVtable=4)
      @com.parameters([in,type=STRING] bstrQueryName) */
  public void Save(String bstrQueryName);

  /** @com.method(vtoffset=49, dispid=1610743853, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters([in,type=STRING] bstrQueryName) */
  public void Delete(String bstrQueryName);

  /** @com.method(vtoffset=50, dispid=1610743854, type=PROPGET, name="FileType", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFileType();

  /** @com.method(vtoffset=51, dispid=1610743854, type=PROPPUT, name="FileType", addFlagsVtable=4)
      @com.parameters([in,type=I4] plFileType) */
  public void setFileType(int plFileType);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0337, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
