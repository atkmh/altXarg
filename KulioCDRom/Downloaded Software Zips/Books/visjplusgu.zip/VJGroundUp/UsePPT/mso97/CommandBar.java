//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface CommandBar
/** @com.interface(iid=000C0304-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface CommandBar extends mso97._IMsoOleAccDispObj
{
  /** @com.method(vtoffset=4, dispid=4294962296, type=PROPGET, name="accParent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getAccParent();

  /** @com.method(vtoffset=5, dispid=4294962295, type=PROPGET, name="accChildCount", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAccChildCount();

  /** @com.method(vtoffset=6, dispid=4294962294, type=PROPGET, name="accChild", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getAccChild(Variant varChild);

  /** @com.method(vtoffset=7, dispid=4294962293, type=PROPGET, name="accName", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccName(Variant varChild);

  /** @com.method(vtoffset=8, dispid=4294962292, type=PROPGET, name="accValue", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccValue(Variant varChild);

  /** @com.method(vtoffset=9, dispid=4294962291, type=PROPGET, name="accDescription", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccDescription(Variant varChild);

  /** @com.method(vtoffset=10, dispid=4294962290, type=PROPGET, name="accRole", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=VARIANT] return) */
  public Variant getAccRole(Variant varChild);

  /** @com.method(vtoffset=11, dispid=4294962289, type=PROPGET, name="accState", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=VARIANT] return) */
  public Variant getAccState(Variant varChild);

  /** @com.method(vtoffset=12, dispid=4294962288, type=PROPGET, name="accHelp", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccHelp(Variant varChild);

  /** @com.method(vtoffset=13, dispid=4294962287, type=PROPGET, name="accHelpTopic", addFlagsVtable=4)
      @com.parameters([out,size=1,elementType=STRING,type=ARRAY] pszHelpFile, [in,type=VARIANT] varChild, [type=I4] return) */
  public int getAccHelpTopic(String[] pszHelpFile, Variant varChild);

  /** @com.method(vtoffset=14, dispid=4294962286, type=PROPGET, name="accKeyboardShortcut", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccKeyboardShortcut(Variant varChild);

  /** @com.method(vtoffset=15, dispid=4294962285, type=PROPGET, name="accFocus", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getAccFocus();

  /** @com.method(vtoffset=16, dispid=4294962284, type=PROPGET, name="accSelection", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getAccSelection();

  /** @com.method(vtoffset=17, dispid=4294962283, type=PROPGET, name="accDefaultAction", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [type=STRING] return) */
  public String getAccDefaultAction(Variant varChild);

  /** @com.method(vtoffset=18, dispid=4294962282, type=METHOD, name="accSelect", addFlagsVtable=4)
      @com.parameters([in,type=I4] flagsSelect, [in,type=VARIANT] varChild) */
  public void accSelect(int flagsSelect, Variant varChild);

  /** @com.method(vtoffset=19, dispid=4294962281, type=METHOD, name="accLocation", addFlagsVtable=4)
      @com.parameters([out,size=1,elementType=I4,type=ARRAY] pxLeft, [out,size=1,elementType=I4,type=ARRAY] pyTop, [out,size=1,elementType=I4,type=ARRAY] pcxWidth, [out,size=1,elementType=I4,type=ARRAY] pcyHeight, [in,type=VARIANT] varChild) */
  public void accLocation(int[] pxLeft, int[] pyTop, int[] pcxWidth, int[] pcyHeight, Variant varChild);

  /** @com.method(vtoffset=20, dispid=4294962280, type=METHOD, name="accNavigate", addFlagsVtable=4)
      @com.parameters([in,type=I4] navDir, [in,type=VARIANT] varStart, [type=VARIANT] return) */
  public Variant accNavigate(int navDir, Variant varStart);

  /** @com.method(vtoffset=21, dispid=4294962279, type=METHOD, name="accHitTest", addFlagsVtable=4)
      @com.parameters([in,type=I4] xLeft, [in,type=I4] yTop, [type=VARIANT] return) */
  public Variant accHitTest(int xLeft, int yTop);

  /** @com.method(vtoffset=22, dispid=4294962278, type=METHOD, name="accDoDefaultAction", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild) */
  public void accDoDefaultAction(Variant varChild);

  /** @com.method(vtoffset=23, dispid=4294962293, type=PROPPUT, name="accName", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [in,type=STRING] pszName) */
  public void setAccName(Variant varChild, String pszName);

  /** @com.method(vtoffset=24, dispid=4294962292, type=PROPPUT, name="accValue", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] varChild, [in,type=STRING] pszValue) */
  public void setAccValue(Variant varChild, String pszValue);

  /** @com.method(vtoffset=25, dispid=1610809344, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=26, dispid=1610809345, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=27, dispid=1610874880, type=PROPGET, name="BuiltIn", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getBuiltIn();

  /** @com.method(vtoffset=28, dispid=1610874881, type=PROPGET, name="Context", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getContext();

  /** @com.method(vtoffset=29, dispid=1610874881, type=PROPPUT, name="Context", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrContext) */
  public void setContext(String pbstrContext);

  /** @com.method(vtoffset=30, dispid=1610874883, type=PROPGET, name="Controls", addFlagsVtable=4)
      @com.parameters([iid=000C0306-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBarControls getControls();

  /** @com.method(vtoffset=31, dispid=1610874884, type=METHOD, name="Delete", addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=32, dispid=1610874885, type=PROPGET, name="Enabled", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getEnabled();

  /** @com.method(vtoffset=33, dispid=1610874885, type=PROPPUT, name="Enabled", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfEnabled) */
  public void setEnabled(boolean pvarfEnabled);

  /** @com.method(vtoffset=34, dispid=1610874887, type=METHOD, name="FindControl", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Type, [in,type=VARIANT] Id, [in,type=VARIANT] Tag, [in,type=VARIANT] Visible, [in,type=VARIANT] Recursive, [iid=000C0308-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBarControl FindControl(Variant Type, Variant Id, Variant Tag, Variant Visible, Variant Recursive);

  /** @com.method(vtoffset=35, dispid=1610874888, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHeight();

  /** @com.method(vtoffset=36, dispid=1610874888, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=I4] pdy) */
  public void setHeight(int pdy);

  /** @com.method(vtoffset=37, dispid=1610874890, type=PROPGET, name="Index", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getIndex();

  /** @com.method(vtoffset=38, dispid=1610874891, type=PROPGET, name="InstanceId", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getInstanceId();

  /** @com.method(vtoffset=39, dispid=1610874892, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLeft();

  /** @com.method(vtoffset=40, dispid=1610874892, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=I4] pxpLeft) */
  public void setLeft(int pxpLeft);

  /** @com.method(vtoffset=41, dispid=1610874894, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=42, dispid=1610874894, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrName) */
  public void setName(String pbstrName);

  /** @com.method(vtoffset=43, dispid=1610874896, type=PROPGET, name="NameLocal", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getNameLocal();

  /** @com.method(vtoffset=44, dispid=1610874896, type=PROPPUT, name="NameLocal", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrNameLocal) */
  public void setNameLocal(String pbstrNameLocal);

  /** @com.method(vtoffset=45, dispid=1610874898, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=46, dispid=1610874899, type=PROPGET, name="Position", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPosition();

  /** @com.method(vtoffset=47, dispid=1610874899, type=PROPPUT, name="Position", addFlagsVtable=4)
      @com.parameters([in,type=I4] ppos) */
  public void setPosition(int ppos);

  /** @com.method(vtoffset=48, dispid=1610874901, type=PROPGET, name="RowIndex", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getRowIndex();

  /** @com.method(vtoffset=49, dispid=1610874901, type=PROPPUT, name="RowIndex", addFlagsVtable=4)
      @com.parameters([in,type=I4] piRow) */
  public void setRowIndex(int piRow);

  /** @com.method(vtoffset=50, dispid=1610874903, type=PROPGET, name="Protection", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getProtection();

  /** @com.method(vtoffset=51, dispid=1610874903, type=PROPPUT, name="Protection", addFlagsVtable=4)
      @com.parameters([in,type=I4] pprot) */
  public void setProtection(int pprot);

  /** @com.method(vtoffset=52, dispid=1610874905, type=METHOD, name="Reset", addFlagsVtable=4)
      @com.parameters() */
  public void Reset();

  /** @com.method(vtoffset=53, dispid=1610874906, type=METHOD, name="ShowPopup", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] x, [in,type=VARIANT] y) */
  public void ShowPopup(Variant x, Variant y);

  /** @com.method(vtoffset=54, dispid=1610874907, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTop();

  /** @com.method(vtoffset=55, dispid=1610874907, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=I4] pypTop) */
  public void setTop(int pypTop);

  /** @com.method(vtoffset=56, dispid=1610874909, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=57, dispid=1610874910, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getVisible();

  /** @com.method(vtoffset=58, dispid=1610874910, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pvarfVisible) */
  public void setVisible(boolean pvarfVisible);

  /** @com.method(vtoffset=59, dispid=1610874912, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getWidth();

  /** @com.method(vtoffset=60, dispid=1610874912, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=I4] pdx) */
  public void setWidth(int pdx);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0304, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
