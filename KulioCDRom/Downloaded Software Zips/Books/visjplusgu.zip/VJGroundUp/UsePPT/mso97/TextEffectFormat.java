//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface TextEffectFormat
/** @com.interface(iid=000C031F-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface TextEffectFormat extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="ToggleVerticalText", addFlagsVtable=4)
      @com.parameters() */
  public void ToggleVerticalText();

  /** @com.method(vtoffset=8, dispid=100, type=PROPGET, name="Alignment", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getAlignment();

  /** @com.method(vtoffset=9, dispid=100, type=PROPPUT, name="Alignment", addFlagsVtable=4)
      @com.parameters([in,type=I4] Alignment) */
  public void setAlignment(int Alignment);

  /** @com.method(vtoffset=10, dispid=101, type=PROPGET, name="FontBold", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFontBold();

  /** @com.method(vtoffset=11, dispid=101, type=PROPPUT, name="FontBold", addFlagsVtable=4)
      @com.parameters([in,type=I4] FontBold) */
  public void setFontBold(int FontBold);

  /** @com.method(vtoffset=12, dispid=102, type=PROPGET, name="FontItalic", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getFontItalic();

  /** @com.method(vtoffset=13, dispid=102, type=PROPPUT, name="FontItalic", addFlagsVtable=4)
      @com.parameters([in,type=I4] FontItalic) */
  public void setFontItalic(int FontItalic);

  /** @com.method(vtoffset=14, dispid=103, type=PROPGET, name="FontName", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getFontName();

  /** @com.method(vtoffset=15, dispid=103, type=PROPPUT, name="FontName", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FontName) */
  public void setFontName(String FontName);

  /** @com.method(vtoffset=16, dispid=104, type=PROPGET, name="FontSize", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getFontSize();

  /** @com.method(vtoffset=17, dispid=104, type=PROPPUT, name="FontSize", addFlagsVtable=4)
      @com.parameters([in,type=R4] FontSize) */
  public void setFontSize(float FontSize);

  /** @com.method(vtoffset=18, dispid=105, type=PROPGET, name="KernedPairs", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getKernedPairs();

  /** @com.method(vtoffset=19, dispid=105, type=PROPPUT, name="KernedPairs", addFlagsVtable=4)
      @com.parameters([in,type=I4] KernedPairs) */
  public void setKernedPairs(int KernedPairs);

  /** @com.method(vtoffset=20, dispid=106, type=PROPGET, name="NormalizedHeight", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getNormalizedHeight();

  /** @com.method(vtoffset=21, dispid=106, type=PROPPUT, name="NormalizedHeight", addFlagsVtable=4)
      @com.parameters([in,type=I4] NormalizedHeight) */
  public void setNormalizedHeight(int NormalizedHeight);

  /** @com.method(vtoffset=22, dispid=107, type=PROPGET, name="PresetShape", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetShape();

  /** @com.method(vtoffset=23, dispid=107, type=PROPPUT, name="PresetShape", addFlagsVtable=4)
      @com.parameters([in,type=I4] PresetShape) */
  public void setPresetShape(int PresetShape);

  /** @com.method(vtoffset=24, dispid=108, type=PROPGET, name="PresetTextEffect", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getPresetTextEffect();

  /** @com.method(vtoffset=25, dispid=108, type=PROPPUT, name="PresetTextEffect", addFlagsVtable=4)
      @com.parameters([in,type=I4] Preset) */
  public void setPresetTextEffect(int Preset);

  /** @com.method(vtoffset=26, dispid=109, type=PROPGET, name="RotatedChars", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getRotatedChars();

  /** @com.method(vtoffset=27, dispid=109, type=PROPPUT, name="RotatedChars", addFlagsVtable=4)
      @com.parameters([in,type=I4] RotatedChars) */
  public void setRotatedChars(int RotatedChars);

  /** @com.method(vtoffset=28, dispid=110, type=PROPGET, name="Text", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getText();

  /** @com.method(vtoffset=29, dispid=110, type=PROPPUT, name="Text", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Text) */
  public void setText(String Text);

  /** @com.method(vtoffset=30, dispid=111, type=PROPGET, name="Tracking", addFlagsVtable=4)
      @com.parameters([type=R4] return) */
  public float getTracking();

  /** @com.method(vtoffset=31, dispid=111, type=PROPPUT, name="Tracking", addFlagsVtable=4)
      @com.parameters([in,type=R4] Tracking) */
  public void setTracking(float Tracking);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc031f, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
