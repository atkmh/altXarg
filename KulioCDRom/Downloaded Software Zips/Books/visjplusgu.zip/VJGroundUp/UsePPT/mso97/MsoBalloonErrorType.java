//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Enum: MsoBalloonErrorType

public interface MsoBalloonErrorType
{
  public static final int msoBalloonErrorNone = 0;
  public static final int msoBalloonErrorOther = 1;
  public static final int msoBalloonErrorTooBig = 2;
  public static final int msoBalloonErrorOutOfMemory = 3;
  public static final int msoBalloonErrorBadPictureRef = 4;
  public static final int msoBalloonErrorBadReference = 5;
  public static final int msoBalloonErrorButtonlessModal = 6;
  public static final int msoBalloonErrorButtonModeless = 7;
  public static final int msoBalloonErrorBadCharacter = 8;
}
