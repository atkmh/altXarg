//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// Dual interface ConnectorFormat
/** @com.interface(iid=000C0313-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface ConnectorFormat extends mso97._IMsoDispObj
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="Creator", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();

  /** @com.method(vtoffset=6, dispid=1, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=7, dispid=10, type=METHOD, name="BeginConnect", addFlagsVtable=4)
      @com.parameters([in,iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] ConnectedShape, [in,type=I4] ConnectionSite) */
  public void BeginConnect(mso97.Shape ConnectedShape, int ConnectionSite);

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="BeginDisconnect", addFlagsVtable=4)
      @com.parameters() */
  public void BeginDisconnect();

  /** @com.method(vtoffset=9, dispid=12, type=METHOD, name="EndConnect", addFlagsVtable=4)
      @com.parameters([in,iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] ConnectedShape, [in,type=I4] ConnectionSite) */
  public void EndConnect(mso97.Shape ConnectedShape, int ConnectionSite);

  /** @com.method(vtoffset=10, dispid=13, type=METHOD, name="EndDisconnect", addFlagsVtable=4)
      @com.parameters() */
  public void EndDisconnect();

  /** @com.method(vtoffset=11, dispid=100, type=PROPGET, name="BeginConnected", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBeginConnected();

  /** @com.method(vtoffset=12, dispid=101, type=PROPGET, name="BeginConnectedShape", addFlagsVtable=4)
      @com.parameters([iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape getBeginConnectedShape();

  /** @com.method(vtoffset=13, dispid=102, type=PROPGET, name="BeginConnectionSite", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getBeginConnectionSite();

  /** @com.method(vtoffset=14, dispid=103, type=PROPGET, name="EndConnected", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEndConnected();

  /** @com.method(vtoffset=15, dispid=104, type=PROPGET, name="EndConnectedShape", addFlagsVtable=4)
      @com.parameters([iid=000C031C-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.Shape getEndConnectedShape();

  /** @com.method(vtoffset=16, dispid=105, type=PROPGET, name="EndConnectionSite", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getEndConnectionSite();

  /** @com.method(vtoffset=17, dispid=106, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=18, dispid=106, type=PROPPUT, name="Type", addFlagsVtable=4)
      @com.parameters([in,type=I4] Type) */
  public void setType(int Type);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xc0313, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
