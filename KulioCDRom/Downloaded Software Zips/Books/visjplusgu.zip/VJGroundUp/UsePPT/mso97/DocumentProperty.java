//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package mso97;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import vbeext1.*;
import msppt8.*;

// VTable-only interface DocumentProperty
/** @com.interface(iid=2DF8D04E-5BFA-101B-BDE5-00AA0044DE52, thread=AUTO) */
public interface DocumentProperty extends IUnknown
{
  /** @com.method(vtoffset=4, returntype=VOID)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getParent();

  /** @com.method(vtoffset=5, addFlagsVtable=4)
      @com.parameters() */
  public void Delete();

  /** @com.method(vtoffset=6, addFlagsVtable=4)
      @com.parameters([in,type=I4] lcid, [type=STRING] return) */
  public String getName(int lcid);

  /** @com.method(vtoffset=7, addFlagsVtable=4)
      @com.parameters([in,type=I4] lcid, [in,type=STRING] pbstrRetVal) */
  public void setName(int lcid, String pbstrRetVal);

  /** @com.method(vtoffset=8, addFlagsVtable=4)
      @com.parameters([in,type=I4] lcid, [type=VARIANT] return) */
  public Variant getValue(int lcid);

  /** @com.method(vtoffset=9, addFlagsVtable=4)
      @com.parameters([in,type=I4] lcid, [in,type=VARIANT] pvargRetVal) */
  public void setValue(int lcid, Variant pvargRetVal);

  /** @com.method(vtoffset=10, addFlagsVtable=4)
      @com.parameters([in,type=I4] lcid, [type=I4] return) */
  public int getType(int lcid);

  /** @com.method(vtoffset=11, addFlagsVtable=4)
      @com.parameters([in,type=I4] lcid, [in,type=I4] ptypeRetVal) */
  public void setType(int lcid, int ptypeRetVal);

  /** @com.method(vtoffset=12, addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getLinkToContent();

  /** @com.method(vtoffset=13, addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pfLinkRetVal) */
  public void setLinkToContent(boolean pfLinkRetVal);

  /** @com.method(vtoffset=14, addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getLinkSource();

  /** @com.method(vtoffset=15, addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrSourceRetVal) */
  public void setLinkSource(String pbstrSourceRetVal);

  /** @com.method(vtoffset=16, addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getApplication();

  /** @com.method(vtoffset=17, addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCreator();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2df8d04e, (short)0x5bfa, (short)0x101b, (byte)0xbd, (byte)0xe5, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x44, (byte)0xde, (byte)0x52);
}
