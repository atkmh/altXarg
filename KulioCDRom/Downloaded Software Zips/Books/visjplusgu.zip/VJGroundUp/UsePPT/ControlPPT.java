import msppt8.*;
import mso97.*;

public class ControlPPT
{
	public static void main(String[] args)
	{
		try {
			_Application app = (_Application)(new Application());
			app.setVisible(1);
			app.setWindowState(PpWindowState.ppWindowMaximized);
			
			Presentations ps =
					app.getPresentations();
			Presentation pres = ps.Add(0);
			
			Slides slides = pres.getSlides();
			Slide slide = slides.Add(1, PpSlideLayout.ppLayoutText);
			
			msppt8.Shapes shapes = slide.getShapes();
			msppt8.Shape textbox = shapes.AddTextbox(
											  MsoTextOrientation.msoTextOrientationHorizontal,
											  100, 100, 400, 60);
			textbox.getTextFrame().getTextRange().setText("Test Text");
			
			System.in.read();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
											  
	}
}
