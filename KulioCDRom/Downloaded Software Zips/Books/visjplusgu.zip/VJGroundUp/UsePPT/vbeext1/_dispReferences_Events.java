//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dispatch-only interface _dispReferences_Events
/** @com.interface(iid=CDDE3804-2064-11CF-867F-00AA005FF34A, thread=AUTO, type=DISPATCH) */
public interface _dispReferences_Events extends IUnknown
{
  /** @com.method(dispid=0, type=METHOD, name="ItemAdded", returntype=VOID)
      @com.parameters([in,type=DISPATCH] Reference) */
  public void ItemAdded(vbeext1.Reference Reference);

  /** @com.method(dispid=1, type=METHOD, name="ItemRemoved", returntype=VOID)
      @com.parameters([in,type=DISPATCH] Reference) */
  public void ItemRemoved(vbeext1.Reference Reference);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xcdde3804, (short)0x2064, (short)0x11cf, (byte)0x86, (byte)0x7f, (byte)0x0, (byte)0xaa, (byte)0x0, (byte)0x5f, (byte)0xf3, (byte)0x4a);
}
