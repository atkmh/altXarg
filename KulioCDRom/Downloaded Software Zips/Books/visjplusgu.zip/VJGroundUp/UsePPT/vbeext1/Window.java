//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface Window
/** @com.interface(iid=0002E16B-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Window extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=1, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.VBE getVBE();

  /** @com.method(vtoffset=5, dispid=2, type=PROPGET, name="Collection", addFlagsVtable=4)
      @com.parameters([iid=0002E16A-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.Windows getCollection();

  /** @com.method(vtoffset=6, dispid=99, type=METHOD, name="Close", addFlagsVtable=4)
      @com.parameters() */
  public void Close();

  /** @com.method(vtoffset=7, dispid=100, type=PROPGET, name="Caption", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getCaption();

  /** @com.method(vtoffset=8, dispid=106, type=PROPGET, name="Visible", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getVisible();

  /** @com.method(vtoffset=9, dispid=106, type=PROPPUT, name="Visible", addFlagsVtable=4)
      @com.parameters([in,type=BOOLEAN] pfVisible) */
  public void setVisible(boolean pfVisible);

  /** @com.method(vtoffset=10, dispid=101, type=PROPGET, name="Left", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getLeft();

  /** @com.method(vtoffset=11, dispid=101, type=PROPPUT, name="Left", addFlagsVtable=4)
      @com.parameters([in,type=I4] plLeft) */
  public void setLeft(int plLeft);

  /** @com.method(vtoffset=12, dispid=103, type=PROPGET, name="Top", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getTop();

  /** @com.method(vtoffset=13, dispid=103, type=PROPPUT, name="Top", addFlagsVtable=4)
      @com.parameters([in,type=I4] plTop) */
  public void setTop(int plTop);

  /** @com.method(vtoffset=14, dispid=105, type=PROPGET, name="Width", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getWidth();

  /** @com.method(vtoffset=15, dispid=105, type=PROPPUT, name="Width", addFlagsVtable=4)
      @com.parameters([in,type=I4] plWidth) */
  public void setWidth(int plWidth);

  /** @com.method(vtoffset=16, dispid=107, type=PROPGET, name="Height", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHeight();

  /** @com.method(vtoffset=17, dispid=107, type=PROPPUT, name="Height", addFlagsVtable=4)
      @com.parameters([in,type=I4] plHeight) */
  public void setHeight(int plHeight);

  /** @com.method(vtoffset=18, dispid=109, type=PROPGET, name="WindowState", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getWindowState();

  /** @com.method(vtoffset=19, dispid=109, type=PROPPUT, name="WindowState", addFlagsVtable=4)
      @com.parameters([in,type=I4] plWindowState) */
  public void setWindowState(int plWindowState);

  /** @com.method(vtoffset=20, dispid=111, type=METHOD, name="SetFocus", addFlagsVtable=4)
      @com.parameters() */
  public void SetFocus();

  /** @com.method(vtoffset=21, dispid=112, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=22, dispid=113, type=METHOD, name="SetKind", addFlagsVtable=4)
      @com.parameters([in,type=I4] eKind) */
  public void SetKind(int eKind);

  /** @com.method(vtoffset=23, dispid=116, type=PROPGET, name="LinkedWindows", addFlagsVtable=4)
      @com.parameters([iid=0002E16C-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.LinkedWindows getLinkedWindows();

  /** @com.method(vtoffset=24, dispid=117, type=PROPGET, name="LinkedWindowFrame", addFlagsVtable=4)
      @com.parameters([iid=0002E16B-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Window getLinkedWindowFrame();

  /** @com.method(vtoffset=25, dispid=118, type=METHOD, name="Detach", addFlagsVtable=4)
      @com.parameters() */
  public void Detach();

  /** @com.method(vtoffset=26, dispid=119, type=METHOD, name="Attach", addFlagsVtable=4)
      @com.parameters([in,type=I4] lWindowHandle) */
  public void Attach(int lWindowHandle);

  /** @com.method(vtoffset=27, dispid=120, type=PROPGET, name="HWnd", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getHWnd();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e16b, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
