//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface Events
/** @com.interface(iid=0002E167-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Events extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=202, type=PROPGET, name="ReferencesEvents", addFlagsVtable=4)
      @com.parameters([in,iid=0002E160-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] VBProject, [iid=0002E11A-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.ReferencesEvents getReferencesEvents(vbeext1.VBProject VBProject);

  /** @com.method(vtoffset=5, dispid=205, type=PROPGET, name="CommandBarEvents", addFlagsVtable=4)
      @com.parameters([in,iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] CommandBarControl, [iid=0002E130-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.CommandBarEvents getCommandBarEvents(Object CommandBarControl);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e167, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
