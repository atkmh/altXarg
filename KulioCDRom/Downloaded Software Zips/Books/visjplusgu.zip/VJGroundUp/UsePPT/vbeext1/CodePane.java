//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

/** @com.class(classid=0002E178-0000-0000-C000-000000000046,DynamicCasts)
    @com.interface(iid=0002E176-0000-0000-C000-000000000046, thread=AUTO, type=DUAL)
*/
public class CodePane implements IUnknown,com.ms.com.NoAutoScripting,vbeext1._CodePane
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Collection", addFlagsVtable=4)
      @com.parameters([iid=0002E172-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.CodePanes getCollection();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.VBE getVBE();

  /** @com.method(vtoffset=6, dispid=1610743810, type=PROPGET, name="Window", addFlagsVtable=4)
      @com.parameters([iid=0002E16B-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.Window getWindow();

  /** @com.method(vtoffset=7, dispid=1610743811, type=METHOD, name="GetSelection", addFlagsVtable=4)
      @com.parameters([out,size=1,elementType=I4,type=ARRAY] StartLine, [out,size=1,elementType=I4,type=ARRAY] StartColumn, [out,size=1,elementType=I4,type=ARRAY] EndLine, [out,size=1,elementType=I4,type=ARRAY] EndColumn) */
  public native void GetSelection(int[] StartLine, int[] StartColumn, int[] EndLine, int[] EndColumn);

  /** @com.method(vtoffset=8, dispid=1610743812, type=METHOD, name="SetSelection", addFlagsVtable=4)
      @com.parameters([in,type=I4] StartLine, [in,type=I4] StartColumn, [in,type=I4] EndLine, [in,type=I4] EndColumn) */
  public native void SetSelection(int StartLine, int StartColumn, int EndLine, int EndColumn);

  /** @com.method(vtoffset=9, dispid=1610743813, type=PROPGET, name="TopLine", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getTopLine();

  /** @com.method(vtoffset=10, dispid=1610743813, type=PROPPUT, name="TopLine", addFlagsVtable=4)
      @com.parameters([in,type=I4] TopLine) */
  public native void setTopLine(int TopLine);

  /** @com.method(vtoffset=11, dispid=1610743815, type=PROPGET, name="CountOfVisibleLines", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getCountOfVisibleLines();

  /** @com.method(vtoffset=12, dispid=1610743816, type=PROPGET, name="CodeModule", addFlagsVtable=4)
      @com.parameters([iid=0002E16E-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.CodeModule getCodeModule();

  /** @com.method(vtoffset=13, dispid=1610743817, type=METHOD, name="Show", addFlagsVtable=4)
      @com.parameters() */
  public native void Show();

  /** @com.method(vtoffset=14, dispid=1610743818, type=PROPGET, name="CodePaneView", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getCodePaneView();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e176, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0x2e178, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
