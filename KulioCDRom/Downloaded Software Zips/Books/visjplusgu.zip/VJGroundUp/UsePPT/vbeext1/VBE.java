//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface VBE
/** @com.interface(iid=0002E166-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface VBE extends vbeext1.Application
{
  /** @com.method(vtoffset=4, dispid=100, type=PROPGET, name="Version", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getVersion();

  /** @com.method(vtoffset=5, dispid=107, type=PROPGET, name="VBProjects", addFlagsVtable=4)
      @com.parameters([iid=0002E165-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.VBProjects getVBProjects();

  /** @com.method(vtoffset=6, dispid=108, type=PROPGET, name="CommandBars", addFlagsVtable=4)
      @com.parameters([iid=000C0302-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public mso97.CommandBars getCommandBars();

  /** @com.method(vtoffset=7, dispid=109, type=PROPGET, name="CodePanes", addFlagsVtable=4)
      @com.parameters([iid=0002E172-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.CodePanes getCodePanes();

  /** @com.method(vtoffset=8, dispid=110, type=PROPGET, name="Windows", addFlagsVtable=4)
      @com.parameters([iid=0002E16A-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.Windows getWindows();

  /** @com.method(vtoffset=9, dispid=111, type=PROPGET, name="Events", addFlagsVtable=4)
      @com.parameters([iid=0002E167-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Events getEvents();

  /** @com.method(vtoffset=10, dispid=201, type=PROPGET, name="ActiveVBProject", addFlagsVtable=4)
      @com.parameters([iid=0002E160-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.VBProject getActiveVBProject();

  /** @com.method(vtoffset=11, dispid=201, type=PROPPUTREF, name="ActiveVBProject", addFlagsVtable=4)
      @com.parameters([in,iid=0002E160-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] lppptReturn) */
  public void setActiveVBProject(vbeext1.VBProject lppptReturn);

  /** @com.method(vtoffset=12, dispid=202, type=PROPGET, name="SelectedVBComponent", addFlagsVtable=4)
      @com.parameters([iid=0002E164-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.VBComponent getSelectedVBComponent();

  /** @com.method(vtoffset=13, dispid=204, type=PROPGET, name="MainWindow", addFlagsVtable=4)
      @com.parameters([iid=0002E16B-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Window getMainWindow();

  /** @com.method(vtoffset=14, dispid=205, type=PROPGET, name="ActiveWindow", addFlagsVtable=4)
      @com.parameters([iid=0002E16B-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Window getActiveWindow();

  /** @com.method(vtoffset=15, dispid=206, type=PROPGET, name="ActiveCodePane", addFlagsVtable=4)
      @com.parameters([iid=0002E176-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.CodePane getActiveCodePane();

  /** @com.method(vtoffset=16, dispid=206, type=PROPPUTREF, name="ActiveCodePane", addFlagsVtable=4)
      @com.parameters([in,iid=0002E176-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] ppCodePane) */
  public void setActiveCodePane(vbeext1.CodePane ppCodePane);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e166, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
