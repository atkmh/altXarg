//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface SelectedComponents
/** @com.interface(iid=BE39F3D4-1B13-11D0-887F-00A0C90F2744, thread=AUTO, type=DUAL) */
public interface SelectedComponents extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=I4] index, [iid=0002E163-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.Component Item(int index);

  /** @com.method(vtoffset=5, dispid=1, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=0002E158-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Application getApplication();

  /** @com.method(vtoffset=6, dispid=2, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=0002E160-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.VBProject getParent();

  /** @com.method(vtoffset=7, dispid=10, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCount();

  /** @com.method(vtoffset=8, dispid=4294967292, type=METHOD, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown _NewEnum();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0xbe39f3d4, (short)0x1b13, (short)0x11d0, (byte)0x88, (byte)0x7f, (byte)0x0, (byte)0xa0, (byte)0xc9, (byte)0xf, (byte)0x27, (byte)0x44);
}
