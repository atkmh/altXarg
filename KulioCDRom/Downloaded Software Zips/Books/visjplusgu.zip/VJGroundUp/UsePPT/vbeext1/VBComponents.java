//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

/** @com.class(classid=BE39F3D7-1B13-11D0-887F-00A0C90F2744,DynamicCasts)
    @com.interface(iid=0002E162-0000-0000-C000-000000000046, thread=AUTO, type=DUAL)
*/
public class VBComponents implements IUnknown,com.ms.com.NoAutoScripting,vbeext1._VBComponents
{
  /** @com.method(vtoffset=4, dispid=0, type=METHOD, name="Item", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] index, [iid=0002E164-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBComponent Item(Variant index);

  /** @com.method(vtoffset=5, dispid=2, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=0002E160-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBProject getParent();

  /** @com.method(vtoffset=6, dispid=10, type=PROPGET, name="Count", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getCount();

  /** @com.method(vtoffset=7, dispid=4294967292, type=METHOD, name="_NewEnum", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native IUnknown _NewEnum();

  /** @com.method(vtoffset=8, dispid=11, type=METHOD, name="Remove", addFlagsVtable=4)
      @com.parameters([in,iid=0002E164-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] VBComponent) */
  public native void Remove(vbeext1.VBComponent VBComponent);

  /** @com.method(vtoffset=9, dispid=12, type=METHOD, name="Add", addFlagsVtable=4)
      @com.parameters([in,type=I4] ComponentType, [iid=0002E164-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBComponent Add(int ComponentType);

  /** @com.method(vtoffset=10, dispid=13, type=METHOD, name="Import", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName, [iid=0002E164-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBComponent Import(String FileName);

  /** @com.method(vtoffset=11, dispid=20, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.VBE getVBE();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e162, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0xbe39f3d7, (short)0x1b13, (short)0x11d0, (byte)0x88, (byte)0x7f, (byte)0x0, (byte)0xa0, (byte)0xc9, (byte)0xf, (byte)0x27, (byte)0x44);
}
