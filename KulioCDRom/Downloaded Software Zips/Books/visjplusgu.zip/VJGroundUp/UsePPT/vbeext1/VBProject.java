//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

/** @com.class(classid=0002E169-0000-0000-C000-000000000046,DynamicCasts)
    @com.interface(iid=0002E160-0000-0000-C000-000000000046, thread=AUTO, type=DUAL)
*/
public class VBProject implements IUnknown,com.ms.com.NoAutoScripting,vbeext1._VBProject
{
  /** @com.method(vtoffset=4, dispid=1, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=0002E158-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.Application getApplication();

  /** @com.method(vtoffset=5, dispid=2, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=0002E158-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.Application getParent();

  /** @com.method(vtoffset=6, dispid=116, type=PROPGET, name="HelpFile", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getHelpFile();

  /** @com.method(vtoffset=7, dispid=116, type=PROPPUT, name="HelpFile", addFlagsVtable=4)
      @com.parameters([in,type=STRING] lpbstrHelpFile) */
  public native void setHelpFile(String lpbstrHelpFile);

  /** @com.method(vtoffset=8, dispid=117, type=PROPGET, name="HelpContextID", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getHelpContextID();

  /** @com.method(vtoffset=9, dispid=117, type=PROPPUT, name="HelpContextID", addFlagsVtable=4)
      @com.parameters([in,type=I4] lpdwContextID) */
  public native void setHelpContextID(int lpdwContextID);

  /** @com.method(vtoffset=10, dispid=118, type=PROPGET, name="Description", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getDescription();

  /** @com.method(vtoffset=11, dispid=118, type=PROPPUT, name="Description", addFlagsVtable=4)
      @com.parameters([in,type=STRING] lpbstrDescription) */
  public native void setDescription(String lpbstrDescription);

  /** @com.method(vtoffset=12, dispid=119, type=PROPGET, name="Mode", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getMode();

  /** @com.method(vtoffset=13, dispid=120, type=PROPGET, name="References", addFlagsVtable=4)
      @com.parameters([iid=0002E17A-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.References getReferences();

  /** @com.method(vtoffset=14, dispid=121, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public native String getName();

  /** @com.method(vtoffset=15, dispid=121, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] lpbstrName) */
  public native void setName(String lpbstrName);

  /** @com.method(vtoffset=16, dispid=122, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.VBE getVBE();

  /** @com.method(vtoffset=17, dispid=123, type=PROPGET, name="Collection", addFlagsVtable=4)
      @com.parameters([iid=0002E165-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBProjects getCollection();

  /** @com.method(vtoffset=18, dispid=131, type=PROPGET, name="Protection", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public native int getProtection();

  /** @com.method(vtoffset=19, dispid=133, type=PROPGET, name="Saved", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public native boolean getSaved();

  /** @com.method(vtoffset=20, dispid=135, type=PROPGET, name="VBComponents", addFlagsVtable=4)
      @com.parameters([iid=0002E162-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public native vbeext1.VBComponents getVBComponents();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e160, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0x2e169, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
