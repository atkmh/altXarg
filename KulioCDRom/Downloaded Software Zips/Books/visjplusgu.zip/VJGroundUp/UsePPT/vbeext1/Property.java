//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface Property
/** @com.interface(iid=0002E18C-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface Property extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=0, type=PROPGET, name="Value", addFlagsVtable=4)
      @com.parameters([type=VARIANT] return) */
  public Variant getValue();

  /** @com.method(vtoffset=5, dispid=0, type=PROPPUT, name="Value", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] lppvReturn) */
  public void setValue(Variant lppvReturn);

  /** @com.method(vtoffset=6, dispid=3, type=PROPGET, name="IndexedValue", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Index1, [in,type=VARIANT] Index2, [in,type=VARIANT] Index3, [in,type=VARIANT] Index4, [type=VARIANT] return) */
  public Variant getIndexedValue(Variant Index1, Variant Index2, Variant Index3, Variant Index4);

  /** @com.method(vtoffset=7, dispid=3, type=PROPPUT, name="IndexedValue", addFlagsVtable=4)
      @com.parameters([in,type=VARIANT] Index1, [in,type=VARIANT] Index2, [in,type=VARIANT] Index3, [in,type=VARIANT] Index4, [in,type=VARIANT] lppvReturn) */
  public void setIndexedValue(Variant Index1, Variant Index2, Variant Index3, Variant Index4, Variant lppvReturn);

  /** @com.method(vtoffset=8, dispid=4, type=PROPGET, name="NumIndices", addFlagsVtable=4)
      @com.parameters([type=I2] return) */
  public short getNumIndices();

  /** @com.method(vtoffset=9, dispid=1, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=0002E158-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Application getApplication();

  /** @com.method(vtoffset=10, dispid=2, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=0002E188-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.Properties getParent();

  /** @com.method(vtoffset=11, dispid=40, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=12, dispid=41, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.VBE getVBE();

  /** @com.method(vtoffset=13, dispid=42, type=PROPGET, name="Collection", addFlagsVtable=4)
      @com.parameters([iid=0002E188-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.Properties getCollection();

  /** @com.method(vtoffset=14, dispid=45, type=PROPGET, name="Object", addFlagsVtable=4)
      @com.parameters([iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public IUnknown getObject();

  /** @com.method(vtoffset=15, dispid=45, type=PROPPUTREF, name="Object", addFlagsVtable=4)
      @com.parameters([in,iid=00000000-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] lppunk) */
  public void setObject(IUnknown lppunk);


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e18c, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
