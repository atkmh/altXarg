//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

/** @com.class(classid=32CDF9E0-1602-11CE-BFDC-08002B2B8CDA,DynamicCasts)
    @com.interface(iid=0002E159-0000-0000-C000-000000000046, thread=AUTO, type=DUAL)
*/
public class ProjectTemplate implements IUnknown,com.ms.com.NoAutoScripting,vbeext1._ProjectTemplate
{
  /** @com.method(vtoffset=4, dispid=1, type=PROPGET, name="Application", addFlagsVtable=4)
      @com.parameters([iid=0002E158-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.Application getApplication();

  /** @com.method(vtoffset=5, dispid=2, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=0002E158-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public native vbeext1.Application getParent();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e159, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);

  public static final com.ms.com._Guid clsid = new com.ms.com._Guid((int)0x32cdf9e0, (short)0x1602, (short)0x11ce, (byte)0xbf, (byte)0xdc, (byte)0x8, (byte)0x0, (byte)0x2b, (byte)0x2b, (byte)0x8c, (byte)0xda);
}
