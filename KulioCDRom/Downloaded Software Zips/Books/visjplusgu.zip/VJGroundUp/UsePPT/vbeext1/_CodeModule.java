//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface _CodeModule
/** @com.interface(iid=0002E16E-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface _CodeModule extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=1610743808, type=PROPGET, name="Parent", addFlagsVtable=4)
      @com.parameters([iid=0002E164-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.VBComponent getParent();

  /** @com.method(vtoffset=5, dispid=1610743809, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.VBE getVBE();

  /** @com.method(vtoffset=6, dispid=0, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=7, dispid=0, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrName) */
  public void setName(String pbstrName);

  /** @com.method(vtoffset=8, dispid=1610743812, type=METHOD, name="AddFromString", addFlagsVtable=4)
      @com.parameters([in,type=STRING] String) */
  public void AddFromString(String String);

  /** @com.method(vtoffset=9, dispid=1610743813, type=METHOD, name="AddFromFile", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName) */
  public void AddFromFile(String FileName);

  /** @com.method(vtoffset=10, dispid=1610743814, type=PROPGET, name="Lines", addFlagsVtable=4)
      @com.parameters([in,type=I4] StartLine, [in,type=I4] Count, [type=STRING] return) */
  public String getLines(int StartLine, int Count);

  /** @com.method(vtoffset=11, dispid=1610743815, type=PROPGET, name="CountOfLines", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCountOfLines();

  /** @com.method(vtoffset=12, dispid=1610743816, type=METHOD, name="InsertLines", addFlagsVtable=4)
      @com.parameters([in,type=I4] Line, [in,type=STRING] String) */
  public void InsertLines(int Line, String String);

  /** @com.method(vtoffset=13, dispid=1610743817, type=METHOD, name="DeleteLines", addFlagsVtable=4)
      @com.parameters([in,type=I4] StartLine, [in,type=I4] Count) */
  public void DeleteLines(int StartLine, int Count);

  /** @com.method(vtoffset=14, dispid=1610743818, type=METHOD, name="ReplaceLine", addFlagsVtable=4)
      @com.parameters([in,type=I4] Line, [in,type=STRING] String) */
  public void ReplaceLine(int Line, String String);

  /** @com.method(vtoffset=15, dispid=1610743819, type=PROPGET, name="ProcStartLine", addFlagsVtable=4)
      @com.parameters([in,type=STRING] ProcName, [in,type=I4] ProcKind, [type=I4] return) */
  public int getProcStartLine(String ProcName, int ProcKind);

  /** @com.method(vtoffset=16, dispid=1610743820, type=PROPGET, name="ProcCountLines", addFlagsVtable=4)
      @com.parameters([in,type=STRING] ProcName, [in,type=I4] ProcKind, [type=I4] return) */
  public int getProcCountLines(String ProcName, int ProcKind);

  /** @com.method(vtoffset=17, dispid=1610743821, type=PROPGET, name="ProcBodyLine", addFlagsVtable=4)
      @com.parameters([in,type=STRING] ProcName, [in,type=I4] ProcKind, [type=I4] return) */
  public int getProcBodyLine(String ProcName, int ProcKind);

  /** @com.method(vtoffset=18, dispid=1610743822, type=PROPGET, name="ProcOfLine", addFlagsVtable=4)
      @com.parameters([in,type=I4] Line, [out,elementType=I4,type=PTR] ProcKind, [type=STRING] return) */
  public String getProcOfLine(int Line, int[] ProcKind);

  /** @com.method(vtoffset=19, dispid=1610743823, type=PROPGET, name="CountOfDeclarationLines", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getCountOfDeclarationLines();

  /** @com.method(vtoffset=20, dispid=1610743824, type=METHOD, name="CreateEventProc", addFlagsVtable=4)
      @com.parameters([in,type=STRING] EventName, [in,type=STRING] ObjectName, [type=I4] return) */
  public int CreateEventProc(String EventName, String ObjectName);

  /** @com.method(vtoffset=21, dispid=1610743825, type=METHOD, name="Find", addFlagsVtable=4)
      @com.parameters([in,type=STRING] Target, [in,out,size=1,elementType=I4,type=ARRAY] StartLine, [in,out,size=1,elementType=I4,type=ARRAY] StartColumn, [in,out,size=1,elementType=I4,type=ARRAY] EndLine, [in,out,size=1,elementType=I4,type=ARRAY] EndColumn, [in,type=BOOLEAN] WholeWord, [in,type=BOOLEAN] MatchCase, [in,type=BOOLEAN] PatternSearch, [type=BOOLEAN] return) */
  public boolean Find(String Target, int[] StartLine, int[] StartColumn, int[] EndLine, int[] EndColumn, boolean WholeWord, boolean MatchCase, boolean PatternSearch);

  /** @com.method(vtoffset=22, dispid=1610743826, type=PROPGET, name="CodePane", addFlagsVtable=4)
      @com.parameters([iid=0002E176-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.CodePane getCodePane();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e16e, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
