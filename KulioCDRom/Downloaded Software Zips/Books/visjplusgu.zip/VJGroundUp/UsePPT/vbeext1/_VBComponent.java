//
// Auto-generated using JActiveX.EXE 5.00.2748
//   ("D:\Program Files\Microsoft Visual Studio\VJ98\jactivex.exe"   /w /xi /X:rkc /l "C:\TEMP\jvc1E.tmp" /nologo /d "D:\Doc\Osborne\VJ\Samples\COM\UseAccess" "D:\Program Files\Microsoft Office\Office\msppt8.olb")
//
// WARNING: Do not remove the comments that include "@com" directives.
// This source file must be compiled by a @com-aware compiler.
// If you are using the Microsoft Visual J++ compiler, you must use
// version 1.02.3920 or later. Previous versions will not issue an error
// but will not generate COM-enabled class files.
//

package vbeext1;

import com.ms.com.*;
import com.ms.com.IUnknown;
import com.ms.com.Variant;
import mso97.*;
import msppt8.*;

// Dual interface _VBComponent
/** @com.interface(iid=0002E164-0000-0000-C000-000000000046, thread=AUTO, type=DUAL) */
public interface _VBComponent extends IUnknown
{
  /** @com.method(vtoffset=4, dispid=10, type=PROPGET, name="Saved", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getSaved();

  /** @com.method(vtoffset=5, dispid=48, type=PROPGET, name="Name", addFlagsVtable=4)
      @com.parameters([type=STRING] return) */
  public String getName();

  /** @com.method(vtoffset=6, dispid=48, type=PROPPUT, name="Name", addFlagsVtable=4)
      @com.parameters([in,type=STRING] pbstrReturn) */
  public void setName(String pbstrReturn);

  /** @com.method(vtoffset=7, dispid=49, type=PROPGET, name="Designer", addFlagsVtable=4)
      @com.parameters([iid=00020400-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public Object getDesigner();

  /** @com.method(vtoffset=8, dispid=50, type=PROPGET, name="CodeModule", addFlagsVtable=4)
      @com.parameters([iid=0002E16E-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.CodeModule getCodeModule();

  /** @com.method(vtoffset=9, dispid=51, type=PROPGET, name="Type", addFlagsVtable=4)
      @com.parameters([type=I4] return) */
  public int getType();

  /** @com.method(vtoffset=10, dispid=52, type=METHOD, name="Export", addFlagsVtable=4)
      @com.parameters([in,type=STRING] FileName) */
  public void Export(String FileName);

  /** @com.method(vtoffset=11, dispid=53, type=PROPGET, name="VBE", addFlagsVtable=4)
      @com.parameters([iid=0002E166-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.VBE getVBE();

  /** @com.method(vtoffset=12, dispid=54, type=PROPGET, name="Collection", addFlagsVtable=4)
      @com.parameters([iid=0002E162-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.VBComponents getCollection();

  /** @com.method(vtoffset=13, dispid=55, type=PROPGET, name="HasOpenDesigner", addFlagsVtable=4)
      @com.parameters([type=BOOLEAN] return) */
  public boolean getHasOpenDesigner();

  /** @com.method(vtoffset=14, dispid=56, type=PROPGET, name="Properties", addFlagsVtable=4)
      @com.parameters([iid=0002E188-0000-0000-C000-000000000046,thread=AUTO,type=OBJECT] return) */
  public vbeext1.Properties getProperties();

  /** @com.method(vtoffset=15, dispid=57, type=METHOD, name="DesignerWindow", addFlagsVtable=4)
      @com.parameters([iid=0002E16B-0000-0000-C000-000000000046,thread=AUTO,type=DISPATCH] return) */
  public vbeext1.Window DesignerWindow();

  /** @com.method(vtoffset=16, dispid=60, type=METHOD, name="Activate", addFlagsVtable=4)
      @com.parameters() */
  public void Activate();


  public static final com.ms.com._Guid iid = new com.ms.com._Guid((int)0x2e164, (short)0x0, (short)0x0, (byte)0xc0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x0, (byte)0x46);
}
