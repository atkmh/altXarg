// Form1.java

import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;

/**
* This class can take a variable number of parameters on the command
* line. Program execution begins with the main() method. The class
* constructor is not invoked unless an object of type 'Form1'
* created in the main() method.
*/
public class Form1 extends Form
{
	private void theButton_click(Object sender, Event e)
	{
		new ListFiller(theListbox);
	}

	public Form1()
	{
		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
	}

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main(String args[])
	{
		Application.run(new Form1());
	}

	/**
	* NOTE: The following code is required by the Visual J++ form
	* designer.  It can be modified using the form editor.  Do not
	* modify it using the code editor.
	*/

	Container components = new Container();
	ListBox theListbox = new ListBox();
	Button theButton = new Button();

	private void initForm()
	{
		this.setText("Virtual Memory Lister");
		this.setAutoScaleBaseSize(13);
		this.setAutoScroll(true);
		this.setClientSize(new Point(418, 267));

		theListbox.setFont(new Font("Courier", 10.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		theListbox.setLocation(new Point(8, 8));
		theListbox.setSize(new Point(400, 212));
		theListbox.setTabIndex(0);
		theListbox.setText("");
		theListbox.setColumnWidth(400);
		theListbox.setItemHeight(13);
		theListbox.setUseTabStops(true);

		theButton.setLocation(new Point(120, 230));
		theButton.setSize(new Point(180, 30));
		theButton.setTabIndex(1);
		theButton.setText("Show Memory");
		theButton.addOnClick(new EventHandler(this.theButton_click));

		this.setNewControls(new Control[] {
							theButton, 
							theListbox});
	}
	// NOTE: End of form designer support code

	public static class ClassInfo extends Form.ClassInfo
	{
		// TODO: Add your property and event infos here
	}
}
