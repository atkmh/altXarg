//ListFiller

public class ListFiller implements Runnable
{
	public static final int PAGE_EXECUTE = 0x10;
	public static final int PAGE_EXECUTE_READ = 0x20;
	public static final int PAGE_EXECUTE_READWRITE = 0x40;
	public static final int PAGE_READONLY = 0x02;
	public static final int PAGE_READWRITE = 0x04;
	
	public static final int MEM_COMMIT = 0x1000;
	public static final int MEM_FREE = 0x10000;
	public static final int MEM_RESERVE = 0x2000;

	private com.ms.wfc.ui.ListBox theList;
	
	public ListFiller(com.ms.wfc.ui.ListBox l) {
		theList = l;
		
		Thread t = new Thread(this);
		t.start();
	}
	
	public void run() {
		try {
			int lpAddress = 0x00;
			
			com.ms.win32.MEMORY_BASIC_INFORMATION info =
					new com.ms.win32.MEMORY_BASIC_INFORMATION();
			
			while(true) {
				VirtualQuery(lpAddress, info, com.ms.dll.DllLib.sizeOf(info));
				
				// First column is base address
				String str = "" + Integer.toHexString(lpAddress);
				
				// Second column is alloc base
				str += ", " + Integer.toHexString(info.RegionSize);

				// Third column is Read/Write/Execute
				boolean fExecute = 0 != (info.AllocationProtect
										 & (PAGE_EXECUTE |
											PAGE_EXECUTE_READ |
											PAGE_EXECUTE_READWRITE));
				boolean fRead = 0 != (info.AllocationProtect
									  & (PAGE_EXECUTE_READ |
										 PAGE_EXECUTE_READWRITE |
										 PAGE_READONLY |
										 PAGE_READWRITE));
				boolean fWrite = 0 != (info.AllocationProtect
									   & (PAGE_EXECUTE_READWRITE |
										  PAGE_READWRITE));
				
				str += ", " + (fRead ? "R" : " ") +
					   (fWrite ? "W" : " ") +
					   (fExecute ? "X" : " ");
				
				// Fourth column is Commit, Free or Res.
				if(info.State == MEM_COMMIT)
					str += ", Commit";
				else if(info.State == MEM_FREE)
					str += ", Free";
				else if(info.State == MEM_RESERVE)
					str += ", Reserved";
				else
					str += ", <Unknown>";
				
				theList.addItem(str);
				
				// Increment lpAddress by region size.
				lpAddress += info.RegionSize;
			}
		} catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}
	
	/**
	 * @dll.import("KERNEL32",auto) 
	 */
	public static native int VirtualQuery(int lpAddress, com.ms.win32.MEMORY_BASIC_INFORMATION lpBuffer, int dwLength);
}
