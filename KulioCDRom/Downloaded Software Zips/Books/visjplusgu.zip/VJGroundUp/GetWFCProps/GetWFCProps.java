// GetWFCProps.java

import com.ms.wfc.core.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'Class1'
 * created in the main() method.
 */
public class GetWFCProps
{
	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main (String[] args)
	{
		try {
			final String strClassInfoClass = (args.length!=0 ? args[0] : "com.ms.wfc.ui.Control$ClassInfo");
			Class classInfo = Class.forName(strClassInfoClass);
		
			IProperties ip = new IProperties() {
				public void add(PropertyInfo pi) {
					System.out.println(" Property \"" + pi.getName() + "\"" +
									   " (" + pi.getType().getName() + ")");
				}
				
				public void remove(PropertyInfo pi) { }
			};
			
			System.out.println("Printing properties for your class...");
			ClassInfo ci = (ClassInfo)classInfo.newInstance();
			ci.getProperties(ip);
			
			System.in.read();
		} catch (Exception e) {
			System.err.println("Error: " + e);
			e.printStackTrace();
		}
	}
}
